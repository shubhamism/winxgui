/* -------------------------------------------------------------------------
// WINX: a C++ template GUI library - MOST SIMPLE BUT EFFECTIVE
// 
// This file is a part of the WINX Library.
// The use and distribution terms for this software are covered by the
// Common Public License 1.0 (http://opensource.org/licenses/cpl.php)
// which can be found in the file CPL.txt at this distribution. By using
// this software in any fashion, you are agreeing to be bound by the terms
// of this license. You must not remove this notice, or any other, from
// this software.
// 
// Module: stdext/pat/PatriciaTrie.h
// Creator: xushiwei
// Email: xushiweizh@gmail.com
// Date: 2006-8-18 18:56:07
// 
// $Id: PatriciaTrie.h 2008-8-6 6:13:39 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef STDEXT_PAT_PATRICIATRIE_H
#define STDEXT_PAT_PATRICIATRIE_H

#ifndef STDEXT_BASIC_H
#include "../Basic.h"
#endif

NS_STDEXT_BEGIN

// -------------------------------------------------------------------------
// class MarkablePtr

#define WINX_MARKABLE_PTR_MARK_	(1 << (sizeof(size_t) * 8 - 1))

template <class Ptr>
class MarkablePtr
{
private:
	size_t m_data;

public:
	MarkablePtr() : m_data(0) {}
	MarkablePtr(Ptr p) : m_data((size_t)p) {
		WINX_STATIC_ASSERT(sizeof(Ptr) == sizeof(size_t));
		WINX_ASSERT(p >= 0);
	}
	
	Ptr winx_call get() const {
		return m_data & ~WINX_MARKABLE_PTR_MARK_;
	}
	
	size_t winx_call marked() const {
		return m_data & WINX_MARKABLE_PTR_MARK_;
	}
	
	void winx_call mark() const {
		m_data |= WINX_MARKABLE_PTR_MARK_;
	}

	void winx_call unmark() const {
		m_data &= ~WINX_MARKABLE_PTR_MARK_;
	}
};

// -------------------------------------------------------------------------
// PatriciaTrieNode

struct PatriciaTrieNode_
{
	size_t iBit; // iBit >= 0: Node; iBit < 0: Leaf
	PatriciaTrieNode_* left;
	PatriciaTrieNode_* right;
};

template <class ValueT>
struct PatriciaTrieLeaf_ {
	MarkablePtr<ValueT*> p;
};

// -------------------------------------------------------------------------
// BitOpTraits

template <class ValT>
struct BitOpTraits {
};

template <>
struct BitOpTraits<std::string>
{
	static int winx_call bit(const std::string& val, const size_t iBit)
	{
		const size_t i = iBit >> 3;
		if (i < val.size())
			return (val[i] >> iBit) & 1;
		return -1; // undefined
	}
	
	static bool winx_call eq(
		const std::string& a, const std::string& b, size_t& iBitFirstDiff, int& aBit)
	{
		const size_t n = MIN(a.size(), b.size());
		while (size_t i = 0; i < n; ++i) {
			
		}
	}
};

// -------------------------------------------------------------------------
// class PatriciaTrie

template <
	class ValueT,
	class SelectKeyT,
	class AllocT = ScopedAlloc>
class PatriciaTrie
{
public:
	typedef ValueT value_type;
	typedef typename SelectKeyT::result_type key_type;
	
private:
	PatriciaTrieNode_ m_head;
	AllocT& m_alloc;
	SelectKeyT m_selectKey;
	
	typedef BitOpTraits<key_type> BitOpT;

public:
	PatriciaTrie(AllocT& alloc) : m_alloc(alloc) {
		m_head = NULL;
	}

	void insert(const ValueT& val) {
		const key_type& key = m_selectKey(val);

	}

template <class T>
int nPatriciaTrie<T>::bit_first_different(nPatriciaTrieKey k1, nPatriciaTrieKey k2) {
    if (!k1 || !k2)
        return 0; // First bit is different!
	int n = 0;
	int d = 0;
	while (	(k1[n] == k2[n]) &&
			(k1[n] != 0) &&
			(k2[n] != 0) )
		n++;
	while (bit_get(&k1[n], d) == bit_get(&k2[n], d))
		d++;
	return ((n << 3) + d);
}

template <class T>
nPatriciaTrieNode<T>* nPatriciaTrie<T>::Insert(nPatriciaTrieKey k, T d) {
	
	nPatriciaTrieNode<T> *p, *t, *x;

	// Start at the root
	p = head;
	t = (nPatriciaTrieNode<T>*)(p->right);

	// Navigate down the tree and look for the key
	while (p->bit_index < t->bit_index) {
		p = t;
		t = (nPatriciaTrieNode<T>*)(bit_get(k, t->bit_index) ? t->right : t->left);
	}

	// Is the key already in the tree?
	if (key_compare(k, t->key))
		return NULL; // Already in the tree!

	// Find the first bit that does not match.
	int i = bit_first_different(k, t->key);

	// Find the appropriate place in the tree where
	// the node has to be inserted
	p  = head;
	x  = (nPatriciaTrieNode<T>*)(p->right);
	while ( ( p->bit_index < x->bit_index ) &&
			( x->bit_index < i) ) {
		p = x;
		x = (nPatriciaTrieNode<T>*)(bit_get(k, x->bit_index) ? x->right : x->left);
	}

	// Allocate a new node and initialize it.
	t = new nPatriciaTrieNode<T>();
	t->Initialize(k, d, i, (bit_get(k, i) ? x : t), (bit_get(k, i) ? t : x));

	// Rewire
	if (bit_get(k, p->bit_index))
		p->right = t;
	else
		p->left = t;

	// Return the newly created node
	return t;

}
	// Name:	Lookup(key)
	// Args:	key : nPatriciaTrieKey
	// Return:	T
	// Purpose:	Search for the given key, and return the data associated
	//          with it (or NULL).
	virtual T                       Lookup(nPatriciaTrieKey);

	// Name:	LookupNode(key)
	// Args:	key : nPatriciaTrieKey
	// Return:	T
	// Purpose:	Search for the given key, and return the node that
	//          contains it (or NULL).
	virtual nPatriciaTrieNode<T>*   LookupNode(nPatriciaTrieKey);

	// Name:	Delete(key)
	// Args:	key : nPatriciaTrieKey
	// Return:	bool
	// Purpose:	Remove the node containing the given key. Return
    //          true if the operation succeeded, false otherwise.
	virtual bool                    Delete(nPatriciaTrieKey);
};

//----------------------------------------------------------------------------
template <class T>
nPatriciaTrie<T>::nPatriciaTrie() {
	// Create the head of the structure. The head is never moved
	// around in the trie (i.e. it always stays at the top of the structure).
    // This prevents further complications having to do with node removal.
	head = new nPatriciaTrieNode<T>();
#define ZEROTAB_SIZE 256
	head->key = (char*)calloc(ZEROTAB_SIZE, 1);
}

//----------------------------------------------------------------------------
template <class T>
nPatriciaTrie<T>::~nPatriciaTrie() {
	recursive_remove(head);
}
//----------------------------------------------------------------------------
template <class T>
nPatriciaTrieNode<T>* nPatriciaTrie<T>::LookupNode(nPatriciaTrieKey k) {

	nPatriciaTrieNode<T>* p;
	nPatriciaTrieNode<T>* x;

	// Start at the root.
    p = head;
	x = (nPatriciaTrieNode<T>*)(head->right);

	// Go down the Patricia structure until an upward
	// link is encountered.
	while (p->bit_index < x->bit_index) {
		p = x;
		x = (nPatriciaTrieNode<T>*)(bit_get(k, x->bit_index) ? x->right : x->left);
	}

	// Perform a full string comparison, and return NULL if
	// the key is not found at this location in the structure.
	if (!key_compare(k, x->key))
		return NULL;

	// Return the node
	return x;

}

//----------------------------------------------------------------------------
template <class T>
bool nPatriciaTrie<T>::Delete(nPatriciaTrieKey k) {

	nPatriciaTrieNode<T> *p, *t, *x, *pp, *lp;
	int bp, bl, br;
	char* key = NULL;

	// Start at the root
	p  = head;
	t  = (nPatriciaTrieNode<T>*)(p->right);

	// Navigate down the tree and look for the key
	while (p->bit_index < t->bit_index) {
		pp = p;
		p  = t;
		t  = (nPatriciaTrieNode<T>*)(bit_get(k, t->bit_index) ? t->right : t->left);
	}

	// Is the key in the tree? If not, get out!
	if (!key_compare(k, t->key))
		return false; // The key could not be found!

	// Copy p's key to t
	if (t != p)
		key_copy(p, t);

	// Is p a leaf?
	bp = p->bit_index;
	bl = ((nPatriciaTrieNode<T>*)(p->left))->bit_index;
	br = ((nPatriciaTrieNode<T>*)(p->right))->bit_index;

	if ((bl > bp) || (br > bp)) {
		
        // There is at least one downward edge.

		if (p != t) {
			
			// Look for a new (intermediate) key
			key = strdup(p->key);

			lp = p;
			x  = (nPatriciaTrieNode<T>*)(bit_get(key, p->bit_index) ? p->right : p->left);
      
			while (lp->bit_index < x->bit_index) {
				lp = x;
				x  = (nPatriciaTrieNode<T>*)(bit_get(key, x->bit_index) ? x->right : x->left);
			}

			// If the intermediate key was not found, we have a problem..
            if (!key_compare(key, x->key)) {
                free(key);
				return false; // The key could not be found!
            }

			// Rewire the leaf (lp) to point to t
			if (bit_get(key, lp->bit_index))
				lp->right = t;
			else
				lp->left = t;

		}

		// Rewire the parent to point to the real child of p
		if (pp != p) {
			nPatriciaTrieNode<T>* ch = (nPatriciaTrieNode<T>*)(bit_get(k, p->bit_index) ? p->left : p->right);
			if (bit_get(k, pp->bit_index))
				pp->right = ch;
			else
				pp->left = ch;
		}

        // We no longer need 'key'
        free(key);
        key = NULL;
	
	} else {

		// Both edges (left, right) are pointing upwards or to the node (self-edges).
    
		// Rewire the parent
		if (pp != p) {
			nPatriciaTrieNode<T>* blx = (nPatriciaTrieNode<T>*)(p->left);
			nPatriciaTrieNode<T>* brx = (nPatriciaTrieNode<T>*)(p->right);
			if (bit_get(k, pp->bit_index))
				pp->right = (((blx == brx) && (blx == p)) ? pp : ((blx==p)?brx:blx));
			else
				pp->left  = (((blx == brx) && (blx == p)) ? pp : ((blx==p)?brx:blx));
		}

	}

	// Deallocate p (no longer needed)
	delete p;

	// Success!
	return true;

}

//----------------------------------------------------------------------------
template <class T>
void nPatriciaTrie<T>::recursive_remove(nPatriciaTrieNode<T>* root) {

	nPatriciaTrieNode<T>* l = (nPatriciaTrieNode<T>*)root->left;
	nPatriciaTrieNode<T>* r = (nPatriciaTrieNode<T>*)root->right;

	// Remove the left branch
	if ( (l->bit_index >= root->bit_index) && (l != root) && (l != head) )
		recursive_remove(l);

	// Remove the right branch
	if ( (r->bit_index >= root->bit_index) && (r != root) && (r != head) )
		recursive_remove(r);

	// Remove the root
	delete root;

}

//----------------------------------------------------------------------------
template <class T>
int nPatriciaTrie<T>::bit_get(nPatriciaTrieKey bit_stream, int n) {
  if (n < 0) return 2; // "pseudo-bit" with a value of 2.
  int k = (n & 0x7);
  return ( (*(bit_stream + (n >> 3))) >> k) & 0x1;
}

//----------------------------------------------------------------------------
template <class T>
bool nPatriciaTrie<T>::key_compare(nPatriciaTrieKey k1, nPatriciaTrieKey k2) {
    if (!k1 || !k2)
        return false;
	return (strcmp((char*)k1, (char*)k2) == 0);
}

//----------------------------------------------------------------------------
template <class T>
void nPatriciaTrie<T>::key_copy(nPatriciaTrieNode<T>* src, nPatriciaTrieNode<T>* dest) {

	if (src == dest)
		return;

	// Copy the key from src to dest
	if (strlen(dest->key) < strlen(src->key))
		dest->key = (nPatriciaTrieKey)realloc(dest->key, 1 + strlen(src->key));
	strcpy(dest->key, src->key);

	// Copy the data from src to dest
	dest->data = src->data;

	// How about the bit index?
	//dest->bit_index = src->bit_index;
	
}

// -------------------------------------------------------------------------
// $Log: Map.h,v $

NS_STDEXT_END

#endif /* STDEXT_PAT_PATRICIATRIE_H */

