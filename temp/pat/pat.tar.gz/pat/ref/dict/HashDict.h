/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/HashDict.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-7-21 10:16:18
//	��������	��	
//
//	$Id: HashDict.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __DATAMINING_DICT_HASHDICT_H__
#define __DATAMINING_DICT_HASHDICT_H__

#pragma pack(1)

/* -----------------------------------------------------------------------*\

Hash�ֵ�:

struct HashDictFile
{
	UINT32	signature;
	UINT16	dataSize;
	UINT16	keyBytesLim;
	UINT32	conflictBytesLim;
	UINT32	bucket;
	BUCKETINFO info[bucket];
	BUCKET	data[];
};

struct BUCKETINFO
{
	UINT32	confict	:8;
	UINT32	offset	:24;
};

struct BUCKET
{
	UINT16	len[conflict];
	HASHITEM item[conflict];
};

struct HASHITEM
{
	UINT8	key[len];
	UINT8	val[dataSize];
};

\* -----------------------------------------------------------------------*/

#define _DM_HASH_DICT_CONFLICT_BITS						8
#define _DM_HASH_DICT_CONFLICT_MAX						(1 << _DM_HASH_DICT_CONFLICT_BITS)
#define _DM_HASH_DICT_CONFLICT_MASK						(_DM_HASH_DICT_CONFLICT_MAX - 1)

#define _DM_HASH_DICT_OFFSET_BITS						(32 - _DM_HASH_DICT_CONFLICT_BITS)
#define _DM_HASH_DICT_OFFSET_MAX						(1 << _DM_HASH_DICT_OFFSET_BITS)

#define _DM_HASH_DICT_BUCKET_INFO(offset, conflict)		(((offset) << _DM_HASH_DICT_CONFLICT_BITS) | (conflict))
#define _DM_HASH_DICT_OFFSET(bucket)					((bucket) >> _DM_HASH_DICT_CONFLICT_BITS)
#define _DM_HASH_DICT_CONFLICT(bucket)					((bucket) & _DM_HASH_DICT_CONFLICT_MASK)

inline UINT32 _HashDictBucketInfo(UINT offset, UINT conflict)
{
	WINX_ASSERT(offset < _DM_HASH_DICT_OFFSET_MAX);
	WINX_ASSERT(conflict < _DM_HASH_DICT_CONFLICT_MAX);
	return _DM_HASH_DICT_BUCKET_INFO(offset, conflict);
}

#if defined(_DEBUG)
#undef _DM_HASH_DICT_BUCKET_INFO
#define _DM_HASH_DICT_BUCKET_INFO(offset, conflict)		_HashDictBucketInfo(offset, conflict)
#endif

// -------------------------------------------------------------------------
// class HashDict

template <class Config>
class HashDictT
{
private:
	typedef UINT32 BUCKETINFO;
	typedef typename Config::HEADER HEADER;

	enum { signature = Config::signature };
	enum { roundSize = Config::roundSize };
	enum { dataSize = Config::dataSize };
	enum { keyBytesLim = sizeof(keylen_type) };

public:
};

// -------------------------------------------------------------------------
// class HashDictWr

template <class Config>
class HashDictWrT : public __std::hash_map<
	typename Config::key_type, typename Config::data_type, typename Config::hasher>
{
public:
	typedef typename Config::key_type key_type;
	typedef typename Config::data_type data_type;
	typedef typename Config::hasher hasher;
	typedef typename Config::keylen_type keylen_type;

private:
	typedef __std::hash_map<key_type, data_type, hasher> Impl;

	typedef UINT32 BUCKETINFO;
	typedef typename Config::HEADER HEADER;

	enum { signature = Config::signature };
	enum { roundSize = Config::roundSize };
	enum { dataSize = Config::dataSize };

public:
	enum { keyBytesLim = sizeof(keylen_type) };
	enum { keySizeLim = 1 << 8*keyBytesLim };

public:
	template <class LogT>
	void trace(LogT& log, void* param = NULL) const
	{
		log.trace("bucket_count = %d\n", bucket_count());

		INT iBucket = -1;
		UINT conflictLim = 0;
		UINT nElems_in_bucket = 0;
		for (const_iterator it = begin(); it != end(); ++it)
		{
			if (nElems_in_bucket == 0) // next bucket
			{
				do {
					++iBucket;
					nElems_in_bucket = elems_in_bucket(iBucket);
				}
				while (nElems_in_bucket == 0);
				if (conflictLim < nElems_in_bucket)
					conflictLim = nElems_in_bucket;
				log.trace("elems_in_bucket(%d) = %d\n", iBucket, nElems_in_bucket);
			}
			--nElems_in_bucket;
			Config::trace(log, *it, param);
		}
		log.trace("conflictLim = %d\n", conflictLim);
	}

public:
	HRESULT save(
		IN LPCWSTR szFile,
		IN DWORD grfMode = STGM_SHARE_EXCLUSIVE|STGM_WRITE|STGM_CREATE) const
	{
		IStream* pstm;
		HRESULT hr = SHCreateStreamOnFileW(szFile, grfMode, &pstm);
		if (SUCCEEDED(hr))
		{
			hr = save(pstm);
			pstm->Release();
		}
		return hr;
	}

	HRESULT save(
		IN LPCSTR szFile,
		IN DWORD grfMode = STGM_SHARE_EXCLUSIVE|STGM_WRITE|STGM_CREATE) const
	{
		IStream* pstm;
		HRESULT hr = SHCreateStreamOnFileA(szFile, grfMode, &pstm);
		if (SUCCEEDED(hr))
		{
			hr = save(pstm);
			pstm->Release();
		}
		return hr;
	}

	HRESULT save(IN IStream* pstmOut) const
	{
		HEADER header;
		header.signature = signature;
		header.dataSize = dataSize;
		header.keyBytesLim = keyBytesLim;
		header.bucket = bucket_count();

		UINT32 fc = sizeof(UINT32) * header.bucket;
		UINT32* fcs = (UINT32*)malloc(fc);
		UINT32* fcsBegin = fcs;

		fc += sizeof(HEADER);
		LARGE_INTEGER offset;
		LISet32(offset, fc);
		pstmOut->Seek(offset, SEEK_SET, NULL);

		UINT conflictBytesLim = 0;
		INT iBucket = -1;
		UINT iElem_in_bucket, nElems_in_bucket = 0;
		std::vector<char> buf;
		for (const_iterator it = begin(); it != end(); ++it)
		{
			if (nElems_in_bucket == 0) // next bucket
			{
				for (;;) {
					++iBucket;
					nElems_in_bucket = elems_in_bucket(iBucket);
					if (nElems_in_bucket != 0)
						break;
					*fcs++ = 0;
				}
				*fcs++ = _DM_HASH_DICT_BUCKET_INFO(fc, nElems_in_bucket);
				iElem_in_bucket = 0;
				buf.clear();
				buf.resize(keyBytesLim*nElems_in_bucket);
			}
			--nElems_in_bucket;
			{
				UINT keylen = Config::write(buf, *it);
				WINX_ASSERT(keylen < keySizeLim); // --> ���������������ζ��д�������ļ�����
				keylen_type* bufStart = (keylen_type*)&*buf.begin();
				bufStart[iElem_in_bucket++] = (keylen_type)keylen;
				if (nElems_in_bucket == 0)
				{
					UINT len = ROUND(buf.size(), roundSize);
					buf.resize(len);
					//pstmOut->Write(bufStart, len, NULL);
					// --> bugfix: ���ڵ�����buf.resize(len)���ʴ�bufStart������Ч�ˡ�
					pstmOut->Write(&*buf.begin(), len, NULL);
					fc += len;
					if (conflictBytesLim < len)
						conflictBytesLim = len;
				}
			}
		}
		WINX_ASSERT((char*)fcs - (char*)fcsBegin <= sizeof(UINT32)*header.bucket);

		header.conflictBytesLim = conflictBytesLim;
		LISet32(offset, 0);
		pstmOut->Seek(offset, SEEK_SET, NULL);
		pstmOut->Write(&header, sizeof(header), NULL);
		pstmOut->Write(fcsBegin, (char*)fcs - (char*)fcsBegin, NULL);
		free(fcsBegin);
		return S_OK;
	}

public:
	HRESULT load(
		IN LPCWSTR szFile,
		IN DWORD grfMode = STGM_SHARE_DENY_WRITE|STGM_READ)
	{
		IStream* pstm;
		HRESULT hr = SHCreateStreamOnFileW(szFile, grfMode, &pstm);
		if (SUCCEEDED(hr))
		{
			hr = load(pstm);
			pstm->Release();
		}
		return hr;
	}

	HRESULT load(
		IN LPCSTR szFile,
		IN DWORD grfMode = STGM_SHARE_DENY_WRITE|STGM_READ)
	{
		IStream* pstm;
		HRESULT hr = SHCreateStreamOnFileA(szFile, grfMode, &pstm);
		if (SUCCEEDED(hr))
		{
			hr = load(pstm);
			pstm->Release();
		}
		return hr;
	}

	HRESULT load(IN IStream* pstmIn)
	{
		HEADER header;
		pstmIn->Read(&header, sizeof(header), NULL);
		if (header.signature != signature ||
			header.keyBytesLim != keyBytesLim ||
			header.dataSize != dataSize)
		{
			return HRESULT_FROM_WIN32(ERROR_BAD_FORMAT);
		}

		HRESULT hr = HRESULT_FROM_WIN32(ERROR_READ_FAULT);
		ULONG cbRead, cb = sizeof(UINT32) * header.bucket;
		UINT32* fcs = (UINT32*)malloc(cb);
		pstmIn->Read(fcs, cb, &cbRead);
		if (cb != cbRead)
		{
			free(fcs);
			return hr;
		}

		char* buf = (char*)malloc(header.conflictBytesLim);
		for (UINT i = 0; i < header.bucket; ++i)
		{
			UINT32 conflict = _DM_HASH_DICT_CONFLICT(fcs[i]);
			if (conflict == 0)
				continue;

			cb = conflict*sizeof(keylen_type);
			pstmIn->Read(buf, cb, &cbRead);
			if (cb != cbRead)
				goto lzReadError;

			UINT32 j;
			keylen_type* len = (keylen_type*)buf;
			const char* bufStart = (const char*)(len + conflict);
			
			for (j = 0; j < conflict; ++j)
				cbRead += (len[j] + dataSize);
			cb = ROUND(cbRead, roundSize) - cb;

			pstmIn->Read((char*)bufStart, cb, &cbRead);
			if (cb != cbRead)
				goto lzReadError;

			for (j = 0; j < conflict; ++j)
				bufStart = Config::read(*this, bufStart, len[j]);
		}
		hr = S_OK;

lzReadError:
		free(fcs);
		free(buf);
		return hr;
	}
};

// -------------------------------------------------------------------------
// class HashDictWr

template <class E, class DataT, int Sign, class KeyLenT>
struct HashDictConfig
{
	typedef std::basic_string<E> key_type;
	typedef DataT data_type;
	typedef KeyLenT keylen_type;
	
	typedef __std::hash<key_type> hasher;

	struct HEADER
	{
		UINT32	signature;
		UINT16	dataSize;
		UINT16	keyBytesLim;
		UINT32	conflictBytesLim;
		UINT32	bucket;
	};

	enum { signature1 = 0x1345 };
	enum { signature2 = Sign };
	enum { signature = MAKELONG(signature1, signature2) };
	enum { roundSize = 4 };
	enum { dataSize = sizeof(data_type) };

	template <class LogT, class ValT>
	static void trace(LogT& log, const ValT& v, void* param)
	{
		log.trace(L"    (\"%s\", %d)\n", v.first.c_str(), v.second);
	}

	template <class ContT>
	static const char* read(ContT& cont, const char* bufStart, keylen_type len)
	{
		key_type key((const E*)bufStart, len/sizeof(E));
		const data_type& data = *(const data_type*)(bufStart + len);
		cont.insert(typename ContT::value_type(key, data));
		return bufStart + len + sizeof(data_type);
	}

	template <class ValT>
	static UINT write(std::vector<char>& buf, const ValT& v)
	{
		UINT len = sizeof(E)*v.first.size();
		const char* data = (const char*)&*v.first.begin();
		buf.insert(buf.end(), data, data+len);
		data = (const char*)&v.second;
		buf.insert(buf.end(), data, data + sizeof(data_type));
		return len;
	}
};

template <class E, class DataT, int Sign = 0x3425, class KeyLenT = UINT16>
class HashDictWr : public HashDictWrT< HashDictConfig<E, DataT, Sign, KeyLenT> >
{
};

// -------------------------------------------------------------------------
// class TestHashDictWr

template <class Unused>
class TestHashDictWr
{
public:
	#define _TEST_DIC_NAME_		"/__test__.dic"

	static void save()
	{
		StdoutLog log;
		HashDictWr<WCHAR, UINT32> wr;
		wr[L"abc"] = 1;
		wr[L"abcd"] = 2;
		wr[L"abcde"] = 3;
		wr.trace(log);
		wr.save(_TEST_DIC_NAME_);
	}

	static void load()
	{
		StdoutLog log;
		HashDictWr<WCHAR, UINT32> wr;
		log.trace("--------> loading test.dic\n");
		wr.load(_TEST_DIC_NAME_);
		wr.trace(log);
		remove(_TEST_DIC_NAME_);
	}

	static void doTest()
	{
		save();
		load();
	}
};

// -------------------------------------------------------------------------
//	$Log: HashDict.h,v $
//	Revision 1.11  2006/08/13 01:22:38  xushiwei
//	_HashDictBucketInfo
//	
//	Revision 1.10  2006/08/05 06:44:58  xushiwei
//	signature
//	
//	Revision 1.9  2006/08/04 05:54:10  xushiwei
//	Config::dataSize
//	
//	Revision 1.8  2006/08/02 08:08:26  xushiwei
//	trace���Ӳ���: param
//	
//	Revision 1.7  2006/07/27 08:23:11  xushiwei
//	keySizeLim - ���ʹ�����⡣
//	ע�⣬����û������insert�Ⱥ�����HashDictWrT�಻���������������
//	
//	Revision 1.6  2006/07/27 07:57:18  xushiwei
//	bugfix: ����resize����bufStart��Ч���⡣
//	
//	Revision 1.5  2006/07/25 03:32:59  xushiwei
//	���԰���
//	
//	Revision 1.4  2006/07/25 01:52:02  xushiwei
//	HashDict��ɶ��� -- δ�Ż�
//	
//	Revision 1.3  2006/07/24 07:53:24  xushiwei
//	HashDict���д�����
//	
//	Revision 1.1  2006/07/21 02:11:55  xushiwei
//	file format description
//	

#pragma pack()

#endif /* __DATAMINING_DICT_HASHDICT_H__ */
