/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/PatDict.h
//	������		��	������
//	����ʱ��	��	7/31/2006 3:19:55 PM
//	��������	��	
//
//	$Id: PatDict.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __DATAMINING_DICT_PATDICT_H__
#define __DATAMINING_DICT_PATDICT_H__
#include "winx/io/FileMappingEx.h"
#pragma pack(2)
// -------------------------------------------------------------------------




#define ISLEAFNODE(nIdx)	(nIdx < 0)
#define	LEAFNODEMASK		(0x7fffffff)
#define ASLEAFNODE			(0x80000000)

template<class E, class Type>
class PatDict
{

private:
	typedef winx::FileMappingT<winx::FileMappingReadWrite> FileMappingEx;
	typedef winx::FileMappingEx::pos_type pos_type;
	

public:
	enum { SegmentBits = FileMappingEx::AllocationGranularityBits};
	enum { SegmentSize = 1 << SegmentBits };
	enum { SegmentMask = SegmentSize - 1 };
	enum { MAXWORDLEN = 256};
	enum { STACKSIZE = MAXWORDLEN << 3 };
	enum { LEFT, RIGHT };
	enum { PATSIGNATURE = 0xf0f0f0f0 };
	enum { RESERVESIZE = 1 << 16};
	enum { WORDINFOSIZE = 24 };
	enum { EBITS = 2 + sizeof(E) };
	enum { EMASK = (1<<EBITS) - 1 };
	enum { ESIZE  = sizeof(E) };

	struct PatDataNode {
		short m_cmpBit;
		int m_left, m_right;
		PatDataNode():m_cmpBit(0),m_left(0), m_right(0){};
	};

private:

	int					m_nCount;
	int					m_nRootIdx;
	mutable int			m_nCurWordLen;
	PatDataNode			tempNode;
	std::vector<UINT32>	m_vect;
	std::vector<Type>	m_cach;
	FileMappingEx		m_fm;
	mutable FileMappingEx::AccessBuffer<SegmentBits+1> m_fmNodesAccess;
	mutable FileMappingEx::AccessBuffer<SegmentBits> m_fmWordsAccess;
	FileMappingEx::AllocBuffer<SegmentBits> m_fmNodesAlloc;
	FileMappingEx::AllocBuffer<SegmentBits> m_fmWordsAlloc;
	
public:

	PatDict()
	{
		m_nCount		= 0;
		m_nRootIdx		= 0;
		m_cach.reserve(RESERVESIZE);
	};
	~PatDict()
	{
		close();
	}
	HRESULT open(LPCTSTR szFileNameOfNodes)
	{
		HRESULT hr = m_fm.open(szFileNameOfNodes);
		if (FAILED(hr))
			return hr;
		m_fmNodesAccess.init(m_fm);
		m_fmWordsAccess.init(m_fm);
		m_fmNodesAlloc.init(m_fm);
		m_fmWordsAlloc.init(m_fm);

		//todo read info
		char* pBuf;
		pBuf = m_fmNodesAccess.view(0);
		if (*(int*)pBuf == PATSIGNATURE)
		{
			pBuf += 4;
			m_nRootIdx = *(int*)pBuf;
			pBuf += 4;
			m_nCount = *(int*)pBuf;
			pBuf += 4;
			winx::SegmentAllocInfo info;
			info = *(winx::SegmentAllocInfo*)pBuf;
			m_fmNodesAlloc.initBuffer(info);
			pBuf += sizeof(winx::SegmentAllocInfo);
			info = *(winx::SegmentAllocInfo*)pBuf;
			m_fmWordsAlloc.initBuffer(info);
		}
		else 
		{
			winx::SegmentAllocInfo info = { 0, SegmentSize - 12 - sizeof(winx::SegmentAllocInfo)*2};
			m_fmNodesAlloc.initBuffer(info);
			m_fmWordsAlloc.initBuffer(1);
		}
		
		hr = S_OK;
		return hr;	
	}

	int good() const
	{
		return m_fm.good();
	}

	void close()
	{
		if (good())
		{
			flush();
			m_fmNodesAccess.close();
			m_fmWordsAccess.close();
			m_fmNodesAlloc.close();
			m_fmWordsAlloc.close();
			m_fm.close();
		}
	}

	void flush()
	{
		char* pBuf = m_fmNodesAccess.view(0);
		*(int*)pBuf = PATSIGNATURE;
		pBuf += 4;
		*(int*)pBuf = m_nRootIdx;
		pBuf += 4;
		*(int*)pBuf = m_nCount;
		pBuf += 4;
		winx::SegmentAllocInfo info;
		m_fmNodesAlloc.getAllocInfo(info);
		memcpy(pBuf, &info, sizeof(winx::SegmentAllocInfo));
		pBuf += sizeof(winx::SegmentAllocInfo);
		m_fmWordsAlloc.getAllocInfo(info);
		memcpy(pBuf, &info, sizeof(winx::SegmentAllocInfo));
		m_fmNodesAccess.flush();
		m_fmNodesAlloc.flush();
		m_fmWordsAccess.flush();
		m_fmWordsAlloc.flush();	
	}

	template <class PostT>
	void Insert(const E* key, int len, Type& value, PostT& post)
	{
		m_nCurWordLen	=	len;

		if (!m_nRootIdx)
		{
			value.wordInfo = post.allocWordInfo();
			m_nRootIdx = NewDataNode(key, value);
			return;
		}
		
		PatDataNode* p = NULL; 
		int nNowIdx = m_nRootIdx;
		while (!ISLEAFNODE(nNowIdx))
		{
			p = (PatDataNode*)m_fmNodesAccess.view(nNowIdx);
			if (Bit(key, p->m_cmpBit))
				nNowIdx = p->m_right;
			else
				nNowIdx = p->m_left;
		}
		char* pBuf = m_fmWordsAccess.view(nNowIdx&LEAFNODEMASK);

		int cmpBit = FindFirstDiffBit((const E*)(pBuf+WORDINFOSIZE), key);

		if (cmpBit >= ((m_nCurWordLen+1)<<(EBITS)))		// Key already in dict
		{
			Type *pValuePos = (Type*)pBuf;
			Type tmp = *pValuePos;
			tmp.cacheDocs = 0;
			tmp.i8DocBase = post.get_i8DocBase();
			while (m_cach.size() <= pValuePos->wordInfo)
			{
				m_cach.push_back(tmp);
			}
			WINX_ASSERT(pValuePos->wordInfo < m_cach.size());
			if (!m_cach[pValuePos->wordInfo].cacheDocs)
				m_vect.push_back(pValuePos->wordInfo);
			if (!(m_cach[pValuePos->wordInfo].cacheDocs&value.cacheDocs))
			{
				m_cach[pValuePos->wordInfo].cacheDocs |= value.cacheDocs;
				++m_cach[pValuePos->wordInfo].count;
				++pValuePos->count;
			}
			return;
		}
		int nLastNodeIdx = 0;
		nNowIdx = m_nRootIdx;
		int dir = -1;
		while (!ISLEAFNODE(nNowIdx)) 
		{
			p = (PatDataNode*)m_fmNodesAccess.view(nNowIdx);
			if (cmpBit < p->m_cmpBit)
				break;
			nLastNodeIdx = nNowIdx;
			if (Bit(key, p->m_cmpBit))
			{
				nNowIdx = p->m_right;
				dir = RIGHT;
			}
			else
			{
				nNowIdx = p->m_left;
				dir = LEFT;
			}
		}
		value.wordInfo = post.allocWordInfo();
		int nTmpIdx = NewDataNode(key, value);
		nTmpIdx = Bit(key, cmpBit) ? NewIntNode(cmpBit, nNowIdx, nTmpIdx) : NewIntNode(cmpBit, nTmpIdx, nNowIdx);
		
		if (nNowIdx == m_nRootIdx)
		{

			m_nRootIdx = nTmpIdx;
			return ;
		}
		else
		{
			p = (PatDataNode *) (m_fmNodesAccess.view(nLastNodeIdx));

			if (LEFT == dir)
				p->m_left = nTmpIdx;
			else
				p->m_right = nTmpIdx;
		}
		return ;
	}

	bool FindValue(const E* key, int nLen, Type& value) const
	{
		if (!m_nRootIdx)
			return false;
		if (nLen >= MAXWORDLEN)
			return false;
		m_nCurWordLen = nLen;
		PatDataNode* p = NULL; 
		int nNowIdx = m_nRootIdx;
		while (!ISLEAFNODE(nNowIdx))
		{
			p = (PatDataNode*)m_fmNodesAccess.view(nNowIdx);
			if (Bit(key, p->m_cmpBit))
				nNowIdx = p->m_right;
			else
				nNowIdx = p->m_left;
		}
		char* pBuf = m_fmWordsAccess.view(nNowIdx&LEAFNODEMASK);
		if (!Mycmp((const E*)(pBuf+WORDINFOSIZE),key))
			return false;
		else
		{
			Type* tmp = (Type*) pBuf;
			value.wordInfo = tmp->wordInfo;
			value.count = tmp->count;
			value.i8DocBase = tmp->i8DocBase;
			//memcpy(&value, pBuf, WORDINFOSIZE);
			return true;
		}
	}
	


	// -------------------------------------------------------------------------
	// ����		: SamePrefixWords
	// ����		: Find words have same prefix
	// ����ֵ	: void 
	// ����		: const char * key
	// ����		: std::vector<std::pair<const char*, Type> > & words
	// ��ע		: 
	// -------------------------------------------------------------------------
	bool SamePrefixWords(const E* key, int len, std::vector<std::pair<std::basic_string<E>, Type> > & words) const 
	{
		
		m_nCurWordLen = len;
		if (!m_nRootIdx || len > MAXWORDLEN)
			return false;
		
		PatDataNode* p = NULL; 
		int nNowIdx = m_nRootIdx;
		while (!ISLEAFNODE(nNowIdx))
		{
			p = (PatDataNode*)m_fmNodesAccess.view(nNowIdx);
			if (Bit(key, p->m_cmpBit))
				nNowIdx = p->m_right;
			else
				nNowIdx = p->m_left;
		}
		char* pBuf = m_fmWordsAccess.view(nNowIdx&LEAFNODEMASK);

		int cmpBit = FindFirstDiffBit((const E*)(pBuf+WORDINFOSIZE), key);

		if (cmpBit < (len)<<(EBITS))
			return false;
		
		nNowIdx = m_nRootIdx;
		while (!ISLEAFNODE(nNowIdx))
		{
			p = (PatDataNode*)m_fmNodesAccess.view(nNowIdx);
			if ((len*(1<<EBITS)) <= p->m_cmpBit)
				break;
			if (Bit(key, p->m_cmpBit))
				nNowIdx = p->m_right;
			else
				nNowIdx = p->m_left;
		}
		
		std::deque<int> st;
		st.push_front(nNowIdx);
		p = NULL;
		int now = 0;
		while (!st.empty()) 
		{
			now = st.front();
			st.pop_front();
			if (ISLEAFNODE(now))
			{
				Type value;
				char* pKey = m_fmWordsAccess.view(now&LEAFNODEMASK);
				Type* tmp = (Type*) pKey;
				value.wordInfo = tmp->wordInfo;
				value.count = tmp->count;
				value.i8DocBase = tmp->i8DocBase;
				std::basic_string<E> str = (const E*)(pKey+WORDINFOSIZE);
				words.push_back(std::make_pair(str, value));
			}
			else
			{
				p = (PatDataNode *) (m_fmNodesAccess.view(now));			
				st.push_front(p->m_right);
				st.push_front(p->m_left);
			}
		}
		return true;
	}
	
	template <class PostT>
	bool Update(PostT& post, UINT32 maxDocId, INT32 nCount)
	{
		int nSize = m_vect.size();
		WINX_ASSERT(nSize <= m_cach.size());
		for (int i = 0; i < nSize; ++i)
		{
			int nIdx = m_vect[i]; 
			WINX_ASSERT(nIdx >= 0 && nIdx < m_cach.size());
			WINX_ASSERT(m_cach[nIdx].cacheDocs != 0);
			post.addTempIndex(m_cach[nIdx], nCount, post.get_i8DocBase() - m_cach[nIdx].i8DocBase);
			m_cach[nIdx].i8DocBase = post.get_i8DocBase(maxDocId);
			m_cach[nIdx].cacheDocs = 0;
		}
		m_vect.clear();
		return true;
	}

	int size() const
	{
		return m_nCount;
	}
	
	template <class LogT>
	void Trace(LogT& log, void* param = NULL) const
	{
		//todo
		if (!m_nRootIdx)
			return;
		int nCnt = 0;
		std::deque<int> st;
		st.push_front(m_nRootIdx);
		PatDataNode* p = NULL;
		int now = 0;
		while (!st.empty()) 
		{
			now = st.front();
			st.pop_front();
			if (ISLEAFNODE(now))
			{
				char* pKey = m_fmWordsAccess.view(now&LEAFNODEMASK);
				nCnt++;
				log.trace("%04x\n", pKey+WORDINFOSIZE);
			}
			else
			{
				p = (PatDataNode *) (m_fmNodesAccess.view(now));			
				st.push_front(p->m_right);
				st.push_front(p->m_left);
			}
		}
		if (nCnt != m_nCount)
			log.trace("There is something wrong in patdict\n");
		else
			log.trace("All right\n");
		log.trace("The size of m_cach is %d\n",m_cach.size());
	}

protected:

	int NewDataNode(const E* key, Type& value)
	{
		++m_nCount;
		pos_type fc;
		UINT8* pBuf = (UINT8*)m_fmWordsAlloc.allocData((m_nCurWordLen + 1) * ESIZE + WORDINFOSIZE, fc);
		memcpy(pBuf, &value, WORDINFOSIZE);
		memcpy(pBuf+WORDINFOSIZE, key, (m_nCurWordLen + 1) * ESIZE);
		while (m_cach.size() < value.wordInfo)
		{
			m_cach.push_back(value);
		}
		m_cach.push_back(value);
		m_vect.push_back(m_cach.size()-1);	
		WINX_ASSERT(value.wordInfo == m_cach.size()-1);

		return fc|ASLEAFNODE;
	}	

	int NewIntNode(int cmpBit, int left, int right)
	{
		PatDataNode tempNode;
		tempNode.m_cmpBit = cmpBit;
		tempNode.m_left	= left;
		tempNode.m_right = right;
		pos_type fc;
		char* pBuf = m_fmNodesAlloc.allocData(sizeof(PatDataNode), fc);
		*(PatDataNode*)pBuf = tempNode;
		
		return fc;
	}

	inline bool Bit(const E* key, int cmpBit) const
	{
		if (cmpBit >= ((m_nCurWordLen+1)<<(EBITS)))
			return false;
		
		return (key[cmpBit>>(EBITS)] & (1<<(cmpBit&EMASK))) != 0;
	}

	inline int FindFirstDiffBit(const E* dest, const E * key) const
	{
		int cmpBit = 0;
		
		while (*key && *dest == *key)
		{
			cmpBit += (1<<EBITS);
			++key;
			++dest;
		}
		int i = 0;
		for (; i < (1<<EBITS) && (*dest&(1<<i)) == (*key&(1<<i)); ++i);

		cmpBit += i;

		return cmpBit;
	}

	bool Mycmp(const E* buf1, const E* buf2) const
	{
		if (sizeof(E) == 1)
			return strcmp((const char*)buf1, (const char*)buf2) == 0;
		else
			return wcscmp((const wchar_t*)buf1, (const wchar_t*)buf2) == 0;
	}

};
// -------------------------------------------------------------------------


// -------------------------------------------------------------------------
//	$Log: PatDict.h,v $
//	Revision 1.35  2006/10/24 01:51:18  guolijing
//	*** empty log message ***
//	
//	Revision 1.34  2006/10/13 08:17:43  guolijing
//	buf fixed
//	
//	Revision 1.33  2006/09/28 06:19:58  guolijing
//	����close
//	
//	Revision 1.32  2006/09/22 11:33:53  guolijing
//	֧��OR ���߼��ǲ���: | ����OR���� -��ʾ�߼��ǲ���
//	����: ��ɽ | ��˾  - ����
//	�������͹ؼ�Ҫ�пո�ֿ�
//	
//	Revision 1.31  2006/09/20 06:25:23  guolijing
//	BUG FIXED
//	
//	Revision 1.30  2006/09/07 07:03:29  guolijing
//	*** empty log message ***
//	
//	Revision 1.29  2006/09/07 06:45:04  guolijing
//	bugfixed
//	
//	Revision 1.28  2006/09/07 06:07:08  guolijing
//	*** empty log message ***
//	
//	Revision 1.27  2006/09/07 02:39:04  helijun
//	1����ɽ������ķִ�
//	2����ɽ��������ı��ļ����������Լ�������
//	
//	Revision 1.26  2006/09/07 00:53:08  guolijing
//	*** empty log message ***
//	
//	Revision 1.25  2006/09/05 02:10:36  guolijing
//	bugfixed
//	
//	Revision 1.24  2006/09/05 01:35:45  guolijing
//	*** empty log message ***
//	
//	Revision 1.23  2006/09/01 05:27:02  guolijing
//	bugfixed
//	
//	Revision 1.22  2006/09/01 05:01:15  xushiwei
//	�л���PatDict��
//	
//	Revision 1.21  2006/08/18 00:48:30  guolijing
//	��cach�����ڴ���,����д��.
//	
//	Revision 1.19  2006/08/16 07:01:48  guolijing
//	*** empty log message ***
//	
//	Revision 1.18  2006/08/14 10:29:35  guolijing
//	����FILEMAPPINGEX
//	
//	Revision 1.17  2006/08/12 09:32:40  guolijing
//	*** empty log message ***
//	
//	Revision 1.16  2006/08/12 08:45:37  xushiwei
//	ϸ��bugfix
//	
//	Revision 1.15  2006/08/12 08:40:09  guolijing
//	���ù����ڴ�
//	
//	Revision 1.14  2006/08/10 00:57:56  guolijing
//	*** empty log message ***
//	
//	Revision 1.13  2006/08/07 12:16:17  guolijing
//	��PAT��insert�еĵݹ���ø�Ϊѭ��,�Ա���֧�ֶ���̵���
//	
//	Revision 1.12  2006/08/07 12:04:38  guolijing
//	*** empty log message ***
//	
//	Revision 1.11  2006/08/07 00:44:01  guolijing
//	*** empty log message ***
//	
//	Revision 1.10  2006/08/06 04:14:28  guolijing
//	*** empty log message ***
//	
//	Revision 1.9  2006/08/05 04:28:43  xushiwei
//	DictWrItem�м���i8DocBase���Ա��Ż����ŵ��ĸ��¡�
//	�μ�: DictionaryWr::update������
//	�޸�: addTempIndex���������һ������: i8DocBaseDelta
//	
//	Revision 1.7  2006/08/04 13:17:49  guolijing
//	*** empty log message ***
//	
//	Revision 1.6  2006/08/04 09:44:12  guolijing
//	*** empty log message ***
//	
//	Revision 1.5  2006/08/04 06:31:06  xushiwei
//	size
//	
//	Revision 1.4  2006/08/03 09:25:01  guolijing
//	*** empty log message ***
//	
//	Revision 1.3  2006/08/03 01:43:18  guolijing
//	*** empty log message ***
//	
//	Revision 1.2  2006/08/02 07:20:15  guolijing
//	*** empty log message ***
//	
//	Revision 1.1  2006/08/02 06:43:35  xushiwei
//	class PatDict;
//	
#pragma pack()
#endif /* __DATAMINING_DICT_PATDICT_H__ */
