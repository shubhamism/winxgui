/* -------------------------------------------------------------------------
//	�ļ���		��	BPlusTree.h
//	������		��	������
//	����ʱ��	��	2006-10-9 14:26:14
//	��������	��	
//
//	$Id: BPlusTree.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __DATAMINING_DICT_BPLUSTREE_H__
#define __DATAMINING_DICT_BPLUSTREE_H__

//#define TEST_BPLUSTREE

// -------------------------------------------------------------------------
#pragma pack(1)


// -------------------------------------------------------------------------
//class BPlusTreeBase

template <class KeyType, class DataType, int Order,int Sign = 0xbeeb, int BlkBits = 12,bool MultiKey = false, class POST = UINT32>
class BPlusTreeBase
{
	
protected:
	enum { SegmentBits = BlkBits };
	enum { SegmentSize = 1 << SegmentBits };
	enum { BPlusTreeHeader_Pos = sizeof(winx::_DiskMemPoolFileHeader) + 4 };
	
	typedef winx::DiskMemPoolT<Sign, SegmentBits, POST> DiskMemPoolT;
	typedef DiskMemPoolT::pos_type Page; 
	typedef Page _LeafPagePos;
	typedef Page _IndexPagePos;

	enum { _FileSizeLim_ = 1 << 30};
	enum { LeafPageSize = (sizeof(KeyType) + sizeof(DataType)) * Order + sizeof(int) + sizeof(_LeafPagePos) * 3 };
	enum { IndexPageSize = (sizeof(KeyType) + sizeof(Page)) * Order + sizeof(Page) + sizeof(int) };

	// -------------------------------------------------------------------------
	//struct LeafPage
	// Used in the BPlusTree.  As LeafNode.
	template <class KeyType, class DataType, int Order>
	struct LeafPageT
	{
		// it means the number of elements in data
		int size;
		
		KeyType keys[Order];

		// Data is the actual data, while next is the pointer to the next leaf (for B+)
		DataType data[Order];
		_LeafPagePos cur;
		_LeafPagePos next;
		_LeafPagePos previous;
		void init()
		{
			size = 0;
			cur = next = previous = 0;
		}
	};

	// -------------------------------------------------------------------------
	//struct IndexPage
	template <class KeyType, int Order>
	struct IndexPageT
	{
		//it means the number of keys and is one less than the number of children pointers.
		int size;

		KeyType keys[Order];

		//Pointers to the children of this node.
		Page children[Order+1];
	};
	
	struct ReturnAction
	{
		KeyType key1;
		KeyType key2;
		enum
		{
			NO_ACTION,
			REPLACE_KEY1_WITH_KEY2,
			PUSH_KEY_TO_PARENT,
			SET_BRANCH_KEY,
		} action; // 0=none, 1=replace key1 with key2
	};

	struct  BPlusTreeHeader
	{
		int created;
		int depth;
		UINT32 keyCnt;
		UINT32 indexPageCnt;
		UINT32 leafPageCnt;
		Page root, leftmostLeaf;
	};

	typedef LeafPageT<KeyType, DataType, Order> LeafPage;
	typedef IndexPageT<KeyType, Order> IndexPage;
	
public:
	BPlusTreeBase()
	{

	}

	~BPlusTreeBase()
	{
		close();
	}

	HRESULT open(LPCTSTR szFile)
	{
		HRESULT hr = m_pagePool.open(szFile);
		if (FAILED(hr))
			return hr;
		BPlusTreeHeader* hdr = (BPlusTreeHeader*)m_pagePool.view(BPlusTreeHeader_Pos, sizeof(BPlusTreeHeader));
		_loadHeader(*hdr);
		return hr;
	}

	void close()
	{
		if (m_pagePool.good())
		{
			flush();
			m_pagePool.close();
		}
		
	}

	bool get(const KeyType& key, DataType &out) const
	{
		if (0 == m_head.root)
			return false;

		_LeafPagePos _leaf = getLeafFromKey(key);
		int childIndex;
		LeafPage *leaf = (LeafPage*)m_pagePool.view(_leaf, LeafPageSize);
		if (getIndexOf(key, leaf, &childIndex))
		{
			out = leaf->data[childIndex];
			return true;
		}
		return false;
	}

	bool insert(const KeyType& key, const DataType &data, bool bReplaceOldData = true)
	{
		m_bReplaceOldData = bReplaceOldData;

		if (0 == m_head.root)
		{
			// Allocate root and make root as leaf
			LeafPage *root = (LeafPage*)m_pagePool.allocData(LeafPageSize, m_head.root);
			 
			m_head.leftmostLeaf = m_head.root;
			m_head.depth = 1;
			m_head.keyCnt = 1;
			m_head.leafPageCnt = 1;
			m_head.indexPageCnt = 0;
			root->size = 1;
			root->keys[0] = key;
			root->data[0] = data;
			root->next = 0;
			root->previous = 0;
			root->cur = m_head.root;
		}
		else
		{
			bool success = true;
			ReturnAction returnAction;
			returnAction.action = ReturnAction::NO_ACTION;

			Page _newPage = insertBranchDown(key, 
				data, 
				m_head.root, 
				&returnAction, 
				&success, 
				m_head.depth);
			
			if (success == false)
				return false;

			if (_newPage)
			{
				WINX_ASSERT(returnAction.action == ReturnAction::PUSH_KEY_TO_PARENT);

				// propagate the root
				_IndexPagePos tmp = m_head.root;

				IndexPage* newRoot = (IndexPage*)m_pagePool.allocData(IndexPageSize, m_head.root);
				
				newRoot->size = 1;
				newRoot->keys[0] = returnAction.key1;
				newRoot->children[0] = tmp;
				newRoot->children[1] = _newPage;
				
				m_head.depth++;
				m_head.indexPageCnt++;
			}
		}
		
		return true;
	}

	void validLeaves()
	{
		int cnt = 0;
		int keyCnt = 0;
		KeyType minKey;
		Page _curPage = m_head.leftmostLeaf;
		Page pre = 0;
		while (_curPage)
		{
			cnt++;
			
			LeafPage* leaf = (LeafPage*)m_pagePool.view(_curPage, LeafPageSize);
			
			ASSERT(leaf->previous == pre);
			pre = _curPage;
			_curPage = leaf->next;
			keyCnt += leaf->size;
			if (0 == leaf->size)
				continue;
			if (cnt > 1)
				WINX_ASSERT(!(leaf->keys[0] < minKey));
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
			minKey = leaf->keys[leaf->size-1];
		}
		WINX_ASSERT(cnt == m_head.leafPageCnt);
		WINX_ASSERT(keyCnt == m_head.keyCnt);
	}

	void flush()
	{
		BPlusTreeHeader* hdr = (BPlusTreeHeader*)m_pagePool.view(BPlusTreeHeader_Pos, SegmentSize);
		_fillHeader(*hdr);
		m_pagePool.flush();
	}

	unsigned size() const
	{
		return m_head.keyCnt;
	}

	bool empty(void) const
	{
		return  0 == m_head.keyCnt;
	}

	void validateTree()
	{
		int cntLeafPg = 0;
		int cntIndxPg = 0;
		int cntKey = 0;
		WINX_ASSERT(m_head.depth >= 0);
		std::deque<std::pair<Page, int> > Q;
		Q.push_back(std::make_pair(m_head.root, m_head.depth));
		std::map<Page, bool> myMap;
		while (!Q.empty())
		{
			std::pair<Page, int> cur = Q.front();
			Q.pop_front();
			if (cur.second > 1)
			{
				cntIndxPg++;
				IndexPage* indexPg =(IndexPage*) m_pagePool.view(cur.first, IndexPageSize);
				WINX_ASSERT(indexPg->size >= Order/2 && indexPg->size <= Order);
				for (int i = 1; i < indexPg->size; ++i)
				{
					WINX_ASSERT(indexPg->keys[i-1] < indexPg->keys[i]);
				}
				for (int i = 0; i <= indexPg->size; ++i)
				{
					if (myMap.find(indexPg->children[i]) == myMap.end())
					{
						Q.push_back(std::make_pair(indexPg->children[i], cur.second - 1));
						myMap[indexPg->children[i]] = 1;
					}
				}
			}
			else if (cur.second == 1)
			{
				cntLeafPg++;
				LeafPage* leaf = (LeafPage*)m_pagePool.view(cur.first, LeafPageSize);
		
				WINX_ASSERT(leaf->size >= 0);
				cntKey += leaf->size;
				for (int i = 1; i < leaf->size; ++i)
				{
					WINX_ASSERT(leaf->keys[i-1] < leaf->keys[i]);
				}
			}
			else
			{
				WINX_ASSERT(0);
			}

		}	

	}

	void depth() const
	{
		return m_head.depth;
	}

	template <class FunctorT>
	void forEachData(FunctorT& doIt) 
	{
		Page _curPage = m_head.leftmostLeaf;
		while (_curPage)
		{
			LeafPage* leaf = (LeafPage*)m_pagePool.view(_curPage, LeafPageSize);
			_curPage = leaf->next;
			for (int i = 0; i < leaf->size; ++i)
			{
				doIt(leaf->data[i]);
			}
		}
	}

	bool erase(const KeyType& key)
	{
		//��ʱ���ṩMultiKey��ɾ��
		if (MultiKey)
		{
			ASSERT(0);
			return false;
		}
		DataType tmp;
		return erase(key, tmp);
	}

	bool erase(const KeyType& key, DataType &out)
	{
		//the tree is empty
		if (0 == m_head.depth) 
			return true;

		_LeafPagePos _leaf = getLeafFromKey(key);
		int childIndex;
		LeafPage *leaf = (LeafPage*)m_pagePool.view(_leaf, LeafPageSize);
		if (getIndexOf(key, leaf, &childIndex))
		{
			out = leaf->data[childIndex];
			DeleteFromPageAtIndex(childIndex,leaf);
			m_head.keyCnt--;
			return true;
		}
		return false;
	}


protected:

	_LeafPagePos getLeafFromKey(const KeyType& key) const
	{
		if (1 == m_head.depth)
			return m_head.root;
		int childIndex = 0;
		_IndexPagePos _curPage = m_head.root;
		IndexPage *pIndexPg = NULL;
		int depth = m_head.depth;
		
		while (--depth > 0)
		{
			WINX_ASSERT(_curPage < _FileSizeLim_);
			pIndexPg = (IndexPage*)m_pagePool.view(_curPage, IndexPageSize);
			
			// When searching, if we match the exact key we go down the pointer after that index
			 if (getIndexOf(key, pIndexPg, &childIndex))
				++childIndex;
			_curPage = pIndexPg->children[childIndex];
		}
		return _curPage;
	}

	bool getIndexOf(const KeyType& key, const IndexPage *page, int *out) const
	{
		WINX_ASSERT(page->size >= 0);
		WINX_ASSERT(page->size <= Order);
		WINX_ASSERT(page != NULL);
		if (0 == page->size)
			return false;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < page->size; ++i)
			{
				WINX_ASSERT(!(page->keys[i] < page->keys[i-1]));
			}
#endif

		int midIndex, upperBound, lowerBound;
		upperBound = page->size-1;
		lowerBound=0;
		midIndex = page->size/2;

		while (1)
		{
			if (key == page->keys[midIndex])
			{
				*out = midIndex;
				return true;
			}
			else if (key < page->keys[midIndex])
				upperBound = midIndex-1;
			else
				lowerBound = midIndex+1;

			midIndex = lowerBound+(upperBound-lowerBound)/2;

			if (lowerBound > upperBound)
			{
				*out = lowerBound;
				return false; // No match
			}
		}

		//never got there, just for voiding warning.
		WINX_ASSERT(0);
		return false;
	}

	bool getIndexOf(const KeyType& key, const LeafPage *leaf, int *out) const
	{
		WINX_ASSERT(leaf->size >= 0);
		WINX_ASSERT(leaf != NULL);
		if (0 == leaf->size)
			return false;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
#endif

		int midIndex, upperBound, lowerBound;
		upperBound = leaf->size-1;
		lowerBound=0;
		midIndex = leaf->size/2;

		while (1)
		{
			if (key == leaf->keys[midIndex])
			{
				*out = midIndex;
				return true;
			}
			else if (key < leaf->keys[midIndex])
				upperBound = midIndex-1;
			else
				lowerBound = midIndex+1;

			midIndex = lowerBound+(upperBound-lowerBound)/2;

			if (lowerBound > upperBound)
			{
				*out = lowerBound;
				return false; // No match
			}
		}

		//never got there, just for voiding warning.
		WINX_ASSERT(0);
		return false;
	}

	Page insertBranchDown(const KeyType& key, const DataType &data, Page _curPg, ReturnAction *returnAction, bool *success, int depth)
	{
		//if current page is leafpage
		if (1 == depth)
		{
			WINX_ASSERT(_curPg < _FileSizeLim_);
			LeafPage *leaf = (LeafPage*)m_pagePool.view(_curPg, LeafPageSize);

			int insertionIndex = 0;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
#endif
	
			if (getIndexOf(key, leaf, &insertionIndex) && !MultiKey)// Already exists
			{
				if (m_bReplaceOldData)
				{
					leaf->data[insertionIndex] = data;
					*success = true;
				}
				else
				{
					*success = false;
				}
				return 0;	
			}
			
			*success = true;
			m_head.keyCnt++;
			return insertIntoNode(key, data, insertionIndex, leaf, returnAction);
		}
		else
		{
			WINX_ASSERT(_curPg < _FileSizeLim_);
			IndexPage *curIndexPg = (IndexPage*)m_pagePool.view(_curPg, IndexPageSize);
			
			int childIndex = 0;
			int branchIdex = 0;

			if (getIndexOf(key, curIndexPg, &childIndex))
			{
				branchIdex = childIndex + 1;
			}
			else
			{
				branchIdex = childIndex;
			}

			Page _newPage = insertBranchDown(key,
				data, 
				curIndexPg->children[branchIdex], 
				returnAction, 
				success,
				--depth);

			if (_newPage)
			{
				return insertIntoNode(_newPage, _curPg, returnAction, branchIdex);	
			}
		}
		return 0;
	}

	Page insertIntoNode(const KeyType& key, const DataType &data, int insertionIndex,  LeafPage* leaf, ReturnAction *returnAction)
	{
		WINX_ASSERT(insertionIndex >= 0 && insertionIndex <= leaf->size);
		WINX_ASSERT(leaf->size <= Order);
		WINX_ASSERT(leaf != NULL);
		

		if (leaf->size < Order)
		{
			for (int i = leaf->size; i > insertionIndex; --i)
			{
				leaf->keys[i]  = leaf->keys[i-1]; 
				leaf->data[i] = leaf->data[i-1];
			}
			leaf->keys[insertionIndex] = key;
			leaf->data[insertionIndex] = data;
			leaf->size++;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
#endif
			return 0;
		}
		else
		{
			m_head.leafPageCnt++;
			return splitNode(key, data, insertionIndex, leaf, returnAction);
		}
	}

	Page insertIntoNode(Page _childPage, _IndexPagePos _curPg, ReturnAction* returnAction, int insertionIndex)
	{
		WINX_ASSERT(insertionIndex >= 0);
		WINX_ASSERT(_childPage != 0 && _curPg != 0);
		WINX_ASSERT(returnAction->action == ReturnAction::PUSH_KEY_TO_PARENT);

		IndexPage *curPg = (IndexPage*)m_pagePool.view(_curPg, IndexPageSize); 
		WINX_ASSERT(insertionIndex <= curPg->size);
		WINX_ASSERT(curPg->size <= Order);

		if (curPg->size < Order)
		{
			for (int i = curPg->size; i > insertionIndex; --i)
			{
				curPg->keys[i]  = curPg->keys[i-1]; 
				curPg->children[i+1] = curPg->children[i];
			}
			curPg->keys[insertionIndex] = returnAction->key1;
			curPg->children[insertionIndex+1] = _childPage;
			curPg->size++;
			
#ifdef TEST_BPLUSTREE
			for (int i = 1; i < curPg->size; ++i)
			{
				WINX_ASSERT(!(curPg->keys[i] < curPg->keys[i-1]));
			}
#endif

			return 0;
		}
		else
		{
			m_head.indexPageCnt++;
			return splitNode(_childPage, curPg, returnAction, insertionIndex);
		}
	}

	Page splitNode(const KeyType& key, const DataType &data, int insertionIndex, LeafPage* leaf, ReturnAction *returnAction)
	{
		WINX_ASSERT(leaf->size == Order);
		WINX_ASSERT(insertionIndex >= 0);
		WINX_ASSERT(returnAction != NULL);

		static LeafPage tmpLeaf;
		_LeafPagePos _newLeafPg = 0;
		//if insertionIndex at left half of the leaf
		if (insertionIndex < (Order+1)/2)
		{	
			//copy right half to the tmpLeaf
			for (int i = Order/2, j = 0; i < Order; ++i, ++j)
			{
				tmpLeaf.keys[j] = leaf->keys[i];
				tmpLeaf.data[j] = leaf->data[i];
			}
			leaf->size = Order/2;
			insertIntoNode(key, data, insertionIndex, leaf, returnAction);

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
#endif
			_LeafPagePos _cur = leaf->cur;
			_LeafPagePos _next = leaf->next;

			//allocate new page
			LeafPage *newPage = (LeafPage*)m_pagePool.allocData(LeafPageSize, _newLeafPg);
			newPage->init();

			int size = Order - Order/2;
			newPage->size = size;
			newPage->previous = _cur;
			newPage->next = _next;
			newPage->cur = _newLeafPg;
			
			//copy the right half to newPage
			for (int i = 0; i < size; ++i)
			{
				newPage->keys[i] = tmpLeaf.keys[i];
				newPage->data[i] = tmpLeaf.data[i];
			}

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < newPage->size; ++i)
			{
				WINX_ASSERT(!(newPage->keys[i] < newPage->keys[i-1]));
			}
#endif

			returnAction->key1 = newPage->keys[0];
			returnAction->action = ReturnAction::PUSH_KEY_TO_PARENT;

			leaf = (LeafPage*)m_pagePool.view(_cur, LeafPageSize);
			leaf->next = _newLeafPg;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
#endif

			if (_next)
			{
				leaf = (LeafPage*)m_pagePool.view(_next, LeafPageSize);
				leaf->previous = _newLeafPg;
			
#ifdef TEST_BPLUSTREE
				for (int i = 1; i < leaf->size; ++i)
				{
					WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
				}
#endif
			}
			
		}
		else
		{
			//copy right half sub 1 to the tmpLeaf
			for (int i = (Order+1)/2 , j = 0; i < Order; ++i, ++j)
			{
				tmpLeaf.keys[j] = leaf->keys[i];
				tmpLeaf.data[j] = leaf->data[i];
			}
			leaf->size = (Order+1)/2;

			_LeafPagePos _cur = leaf->cur;
			_LeafPagePos _next = leaf->next;

			//allocate new page
			LeafPage *newPage = (LeafPage*)m_pagePool.allocData(LeafPageSize, _newLeafPg);
			newPage->init();

			int size = Order - (Order+1)/2;
			insertionIndex -= (Order+1)/2;
			WINX_ASSERT(insertionIndex >= 0 && insertionIndex <= size);
			newPage->size = size + 1;
			newPage->previous = _cur;
			newPage->next = _next;
			newPage->cur = _newLeafPg;
			
			//copy the right half to newPage
			for (int i = size; i > insertionIndex ; --i)
			{
				newPage->keys[i] = tmpLeaf.keys[i-1];
				newPage->data[i] = tmpLeaf.data[i-1];
			}

			newPage->keys[insertionIndex] = key;
			newPage->data[insertionIndex] = data;

			for (int i = 0; i < insertionIndex; ++i)
			{
				newPage->keys[i] = tmpLeaf.keys[i];
				newPage->data[i] = tmpLeaf.data[i];
			}

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < newPage->size; ++i)
			{
				WINX_ASSERT(!(newPage->keys[i] < newPage->keys[i-1]));
			}
#endif
	
			returnAction->key1 = newPage->keys[0];
			returnAction->action = ReturnAction::PUSH_KEY_TO_PARENT;
			
			leaf = (LeafPage*)m_pagePool.view(_cur, LeafPageSize);
			leaf->next = _newLeafPg;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < leaf->size; ++i)
			{
				WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
			}
#endif
			if (_next)
			{
				leaf = (LeafPage*)m_pagePool.view(_next, LeafPageSize);
				leaf->previous = _newLeafPg;
			
#ifdef TEST_BPLUSTREE
				for (int i = 1; i < leaf->size; ++i)
				{
					WINX_ASSERT(!(leaf->keys[i] < leaf->keys[i-1]));
				}
#endif
			}
			

		}
		return _newLeafPg;
	}

	Page splitNode(const Page &_childPage, IndexPage* indexPg, ReturnAction *returnAction, int insertionIndex)
	{
		WINX_ASSERT(indexPg->size == Order);
		WINX_ASSERT(insertionIndex >= 0);
		WINX_ASSERT(returnAction->action == ReturnAction::PUSH_KEY_TO_PARENT);

		//in case stack overflow, using heap memory
		static IndexPage tmpIndexPg;
		_IndexPagePos _newIndexPg = 0;

		//if insertionIndex at left half of the indexPg
		if (insertionIndex < (Order+1)/2)
		{	
			//copy right half to the tmpIndexPg
			for (int i = Order/2, j = 0; i < Order; ++i, ++j)
			{
				tmpIndexPg.keys[j] = indexPg->keys[i];
				tmpIndexPg.children[j] = indexPg->children[i];
			}
			int size = Order - Order/2;
			tmpIndexPg.children[size] = indexPg->children[Order];

			indexPg->size = Order/2;
			
			for (int i = indexPg->size; i > insertionIndex; --i)
			{
				indexPg->keys[i]  = indexPg->keys[i-1]; 
				indexPg->children[i+1] = indexPg->children[i];
			}
			indexPg->keys[insertionIndex] = returnAction->key1;
			indexPg->children[insertionIndex+1] = _childPage;
			indexPg->size++;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < indexPg->size; ++i)
			{
				WINX_ASSERT(!(indexPg->keys[i] < indexPg->keys[i-1]));
			}
#endif
			
			//allocate new page
			IndexPage *newPage = (IndexPage*)m_pagePool.allocData(IndexPageSize, _newIndexPg);

			
			newPage->size = size;
			
			//copy the right half to newPage
			for (int i = 0; i < size; ++i)
			{
				newPage->keys[i] = tmpIndexPg.keys[i];
				newPage->children[i] = tmpIndexPg.children[i];
			}
			newPage->children[size] = tmpIndexPg.children[size];

			returnAction->key1 = newPage->keys[0];
			returnAction->action = ReturnAction::PUSH_KEY_TO_PARENT;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < newPage->size; ++i)
			{
				WINX_ASSERT(!(newPage->keys[i] < newPage->keys[i-1]));
			}
#endif

		}
		else
		{
			//copy right half sub 1 to the tmpIndexPg
			for (int i = (Order+1)/2, j = 0; i < Order; ++i, ++j)
			{
				tmpIndexPg.keys[j] = indexPg->keys[i];
				tmpIndexPg.children[j] = indexPg->children[i];
			}
			int size = Order - (Order+1)/2;
			tmpIndexPg.children[size] = indexPg->children[Order];
			indexPg->size = (Order+1)/2;
			

			//allocate new page
			IndexPage *newPage = (IndexPage*)m_pagePool.allocData(IndexPageSize, _newIndexPg);
			
			newPage->size = size + 1;
			insertionIndex -= (Order+1)/2;
			WINX_ASSERT(insertionIndex >=0 && insertionIndex < newPage->size);
			for (int i = size; i > insertionIndex ; --i)
			{
				newPage->keys[i] = tmpIndexPg.keys[i-1];
				newPage->children[i+1] = tmpIndexPg.children[i];
			}

			newPage->keys[insertionIndex] = returnAction->key1;
			newPage->children[insertionIndex+1] = _childPage;

			for (int i = 0; i < insertionIndex; ++i)
			{
				newPage->keys[i] = tmpIndexPg.keys[i];
				newPage->children[i] = tmpIndexPg.children[i];
			}
			newPage->children[insertionIndex] = tmpIndexPg.children[insertionIndex];


			returnAction->key1 = newPage->keys[0];
			returnAction->action = ReturnAction::PUSH_KEY_TO_PARENT;

#ifdef TEST_BPLUSTREE
			for (int i = 1; i < newPage->size; ++i)
			{
				WINX_ASSERT(!(newPage->keys[i] < newPage->keys[i-1]));
			}
#endif
		}
		
		return _newIndexPg;
	}

	void DeleteFromPageAtIndex(int deletionIndex, LeafPage* leaf)
	{
		WINX_ASSERT(deletionIndex >= 0 && deletionIndex < leaf->size);
		for (int i = deletionIndex; i < leaf->size - 1; ++i)
		{
			leaf->keys[i] = leaf->keys[i+1];
			leaf->data[i] = leaf->data[i+1];
		}
		leaf->size--;
	}
	void DeleteFromPageAtIndex(int deletionIndex, IndexPage* indexPg)
	{
		WINX_ASSERT(deletionIndex >= 0 && deletionIndex < indexPg->size);
		for (int i = deletionIndex; i < indexPg->size - 1; ++i)
		{
			indexPg->keys[i] = indexPg->keys[i+1];
			indexPg->children[i+1] = indexPg->children[i+2];
		}
		indexPg->size--;
	}


private:
	void _loadHeader(const BPlusTreeHeader& hdr)
	{
		m_head = hdr;
		if (m_head.depth == 0 && m_head.root == 0 && m_head.created == 0)
		{
			Page tmp;
			m_pagePool.allocData(sizeof(m_head), tmp);
			WINX_ASSERT(tmp == BPlusTreeHeader_Pos);
			m_head.created = 1;
		}
	}
	void _fillHeader(BPlusTreeHeader& hdr)
	{
		hdr = m_head;
	}

protected:
	bool m_bReplaceOldData;
	mutable DiskMemPoolT m_pagePool;
	BPlusTreeHeader m_head;
};

// -------------------------------------------------------------------------
//class BPlusTree
template <class KeyType, class DataType, int Order, int Sign = 0xbeeb, int BlkBits = 12, class POST = UINT32>
class BPlusTree : public BPlusTreeBase<KeyType, DataType, Order, Sign, BlkBits, false, POST> 
{

};

// -------------------------------------------------------------------------
//class MultiBPlusTree
template <class KeyType, class DataType, int Order, int Sign = 0x1109, int BlkBits = 12, class POST = UINT32>
class MultiBPlusTree : public BPlusTreeBase<KeyType, UINT64, Order, Sign, BlkBits, true, POST> 
{
	typedef BPlusTreeBase<KeyType, UINT64, Order, Sign, BlkBits, true, POST> Base;

public:
	template<class Container>
	bool get(const KeyType& key, Container &con) const
	{
		if (0 == m_head.root)
			return false;

		_LeafPagePos _leaf = getLeafFromKey(key);
		int childIndex;
		LeafPage *leaf = (LeafPage*)m_pagePool.view(_leaf, LeafPageSize);
		if (getIndexOf(key, leaf, &childIndex))
		{
			bool right = true;
			bool left = true;
			
			ASSERT(leaf != NULL);
			for (int i = childIndex; i < leaf->size; ++i)
			{
				if (leaf->keys[i] == key)
				{
					con.push_back(leaf->data[i]);
				}
				else
				{
					right = false;
					break;
				}
			}

			for (int i = childIndex - 1; i >= 0; --i)
			{
				if (leaf->keys[i] == key)
				{
					con.push_back(leaf->data[i]);
				}
				else
				{
					left = false;
					break;
				}
			}
			
			_LeafPagePos leftPage = leaf->previous;
			_LeafPagePos rightPage = leaf->next;

			while (right && rightPage)
			{
				LeafPage *rLeaf = (LeafPage*)m_pagePool.view(rightPage, LeafPageSize);
				for (int i = 0; i < rLeaf->size; ++i)
				{
					if (rLeaf->keys[i] == key)
					{
						con.push_back(rLeaf->data[i]);
					}
					else
					{
						right = false;
						break;
					}
					
				}
				rightPage = rLeaf->next;
			}

			while (left && leftPage)
			{
				LeafPage *lLeaf = (LeafPage*)m_pagePool.view(leftPage, LeafPageSize);
				for (int i = lLeaf->size - 1 ; i >= 0; --i)
				{
					if (lLeaf->keys[i] == key)
					{
						con.push_back(lLeaf->data[i]);
					}
					else
					{
						left = false;
						break;
					}
				}
				leftPage = lLeaf->previous; 
			}

			return true;
		}
		return false;
	}

};


// -------------------------------------------------------------------------
//class ValuespPageInfo
// 
// template <int PageSize, int ValueSize>
// class ValuespPageInfo
// {
// public:
// 	typedef UINT64 pos_type;
// 	typedef  ValuespPageInfo<PageSize, ValueSize> ValuespPageInfoT;
// 	enum { NValuePerSegmentMax = (PageSize - 20)/ValueSize };
// 	UINT32 m_valueCnt;
// 	pos_type m_nextPage;
// 	pos_type m_lastPage;
// 	ValuespPageInfo(): m_valueCnt(0), m_nextPage(0), m_lastPage(0) {}
//};

// -------------------------------------------------------------------------
//class MultiBPlusTree
/*template <class KeyType, class DataType, int Order, int Sign = 0x1109, int BlkBits = 12, int PageSize = 1 << BlkBits>
class MultiBPlusTree : public BPlusTreeBase<KeyType, UINT64, Order, Sign, BlkBits> 
{
protected:
	typedef ValuespPageInfo<PageSize, sizeof(DataType)> ValuespPageInfoT;
	typedef BPlusTreeBase<KeyType, UINT64, Order, Sign, BlkBits> Base;
	typedef Base::Page Page;
	
	enum {NValuePerSegmentMax = ValuespPageInfoT::NValuePerSegmentMax};
	

public: 

	bool insert(const KeyType& key, const DataType &data)
	{
		Page page = 0;
		if (Base::get(key, page))
		{
			return insertMultiValue(page, data);
		}
		ValuespPageInfoT* pInfo =(ValuespPageInfoT*) m_pagePool.allocData(PageSize, page);
		pInfo->m_nextPage = 0;
		pInfo->m_valueCnt = 1;
		pInfo->m_lastPage = page;
		DataType* pData = (DataType*)(pInfo + 1);
		*pData = data;
		return Base::insert(key, page); 
		
	}
	
	template<class Container>
	bool get(const KeyType& key, Container& container)
	{
		Page page = 0;
		if (Base::get(key, page))
		{
			getMultiValue(page,container);
			return true;
		}
		return false;
	}

private: 

	bool insertMultiValue(Page curPage, const DataType& data)
	{
		ValuespPageInfoT* pInfo = NULL;
		pInfo = (ValuespPageInfoT*)m_pagePool.view(curPage,PageSize);
		Page firstPage = curPage;
		
		if (curPage != pInfo->m_lastPage)
		{
			curPage = pInfo->m_lastPage;
			pInfo = (ValuespPageInfoT*)m_pagePool.view(curPage,PageSize);
		}

		if (pInfo->m_valueCnt < NValuePerSegmentMax)
		{
			DataType* pData = (DataType*)(pInfo + 1);
			pData += pInfo->m_valueCnt;
			*pData = data;
			pInfo->m_valueCnt++;
		}
		else
		{
			Page nextPage = 0;
			ValuespPageInfoT* pInfo = (ValuespPageInfoT*)m_pagePool.allocData(PageSize, nextPage);
			
			pInfo->m_nextPage = 0;
			pInfo->m_valueCnt = 1;
			DataType* pData = (DataType*)(pInfo + 1);
			*pData = data;
			
			pInfo = (ValuespPageInfoT*)m_pagePool.view(curPage, sizeof(ValuespPageInfoT));
			pInfo->m_nextPage = nextPage;
			
			if (firstPage != curPage)
				pInfo = (ValuespPageInfoT*)m_pagePool.view(firstPage, sizeof(ValuespPageInfoT));
				
			pInfo->m_lastPage = nextPage;
			
		}
		return true;
	}

	template<class Container>
	void getMultiValue(Page curPage, Container& container)
	{
		while (curPage)
		{
			ValuespPageInfoT* pInfo = (ValuespPageInfoT*)m_pagePool.view(curPage, PageSize);
			DataType* pData = (DataType*)(pInfo + 1);
			for (int i = 0; i < pInfo->m_valueCnt; ++i)
			{
				container.push_back(*pData);
				pData++;
			}
			
			curPage = pInfo->m_nextPage;
		}
	} 
	
};
*/
// -------------------------------------------------------------------------
//class TestBPlusTree

#if (0)
#define TEST_BPLUSTREE
#endif

#if defined(TEST_BPLUSTREE)

#define _TESTBPLUSTREE_FILENAME_ "/TestBPlusTree.out"
#define _TESTBPLUSTREE_MAXNUM_  100000
#include <time.h>
class TestBPlusTree
{
public:
	class DoList: public winx::FindFileDo
	{
	private:
		struct MD5CODE 
		{
			int code[4];
			bool operator < (const MD5CODE& rhs) const
			{
				for (int i = 0; i < 4; ++i)
				{
					if (code[i] != rhs.code[i])
						return code[i] < rhs.code[i];
				}
				return false;
			}
			bool operator == (const MD5CODE& rhs) const
			{
				for (int i = 0; i < 4; ++i)
				{
					if (code[i] != rhs.code[i])
						return false;
				}
				return true;
			}
		};

	public:
		DoList(): m_fileCnt(0)
		{
			m_bTree.open(_TESTBPLUSTREE_FILENAME_);
		}
		void onDir(const WTL::CFindFile& finder)
		{
			if (_tcscmp(finder.m_fd.cFileName, _T("CVS")) != 0)
			{
				winx::Dir(finder.GetFilePath(), *this);
			}
		}

		void onFile(const WTL::CFindFile& finder)
		{
			LPCTSTR szExt = PathFindExtension(finder.m_fd.cFileName);
			if (szExt == NULL)
				return;

			WTL::CString strFile = finder.GetFilePath();
			LPTSTR szFile = strFile.GetBuffer(strFile.GetLength());
			
			//wchar_t wszFile[MAX_PATH];
			//memset(wszFile, 0, MAX_PATH);
			//::MultiByteToWideChar(CP_ACP, 0, szFile, strFile.GetLength(), wszFile, MAX_PATH);
			
			m_md5.MD5Update((unsigned char*)szFile, sizeof(szFile[0]) * strFile.GetLength());
			MD5CODE tmp;
			m_md5.MD5Final((unsigned char*)tmp.code);
			FILETIME modifyTime;
			BOOL f = winx::GetFileModifyTime(szFile, &modifyTime);
			if (!f)
				return;
			printf("Now file: %s\r\n", szFile);
			m_fileCnt++;
			m_bTree.insert(tmp, modifyTime);
			m_map[tmp] = modifyTime;
			
		}
		void validata()
		{
			WINX_ASSERT(m_map.size() == m_bTree.size());
			printf("fileCnt is %d, btree size is %d\n", m_fileCnt, m_bTree.size());
			if (m_fileCnt != m_bTree.size())
			{
				printf("some path have the same MD5CODE\n");
			}
			std::map<MD5CODE, FILETIME>::iterator it = m_map.begin();
			for (; it != m_map.end(); ++it)
			{
				FILETIME tmp;
				if (m_bTree.get(it->first, tmp))
				{
					if (tmp.dwHighDateTime != it->second.dwHighDateTime
						|| tmp.dwLowDateTime != it->second.dwLowDateTime)
						WINX_ASSERT(0);
				}
				else
					WINX_ASSERT(0);
			}
				
		}
	private:
		MD5_CTX m_md5;
		std::map<MD5CODE, FILETIME> m_map;
		BPlusTree<MD5CODE, FILETIME, 100> m_bTree;
		int m_fileCnt;

	};
	struct JustForTest 
	{
		int b;
		template<class ValT>
		void operator() (const ValT& a) 
		{
			b = a;
		}
	};
	static void doTestIntInt()
	{
		DeleteFile(_TESTBPLUSTREE_FILENAME_);
		BPlusTree<int, int, 100> myTree;
		std::map<int, int> myMap;

		HRESULT hr = myTree.open(_TESTBPLUSTREE_FILENAME_);
		if (FAILED(hr))
			return;
		srand((unsigned)time(NULL));

		for (int i = 0;  i < _TESTBPLUSTREE_MAXNUM_; ++i)
		{
		
			int num = rand() * rand();
			bool f = false;
			myMap[num] = i;
			myTree.insert(num, i);
		}
		myTree.validateTree();
		myTree.validLeaves();
		for (std::map<int, int>::iterator it = myMap.begin(); it != myMap.end(); ++it)
		{
			int num = it->second;
			if (myTree.get(it->first,num))
			{
				if (num != it->second)
					printf("get worong value\n");
			}
			else
			{
				printf("can't get key\n");
			}
		}
		printf("map size is %d\nb+tree size is %d\n", myMap.size(), myTree.size());
		WINX_ASSERT(myMap.size() == myTree.size());
		myTree.close();
		hr = myTree.open(_TESTBPLUSTREE_FILENAME_);
		if (FAILED(hr))
			return;
		for (int i = 0;  i < _TESTBPLUSTREE_MAXNUM_; ++i)
		{
		
			int num = rand() * rand();
			bool f = false;
			myMap[num] = i;
			myTree.insert(num, i);
		}
		myTree.validateTree();
		myTree.validLeaves();
		for (std::map<int, int>::iterator it = myMap.begin(); it != myMap.end(); ++it)
		{
			int num;
			if (myTree.get(it->first,num))
			{
				if (num != it->second)
					printf("get worong value\n");
			}
			else
			{
				printf("can't get key\n");
			}
		}
		printf("map size is %d\nb+tree size is %d\n", myMap.size(), myTree.size());
		for (std::map<int, int>::iterator it = myMap.begin(); it != myMap.end(); ++it)
		{
			if (!myTree.erase(it->first))
			{
				printf("cannot erase..");
			}
		}
		for (std::map<int, int>::iterator it = myMap.begin(); it != myMap.end(); ++it)
		{
			int num;
			if (myTree.get(it->first,num))
			{
				printf("wrong..");
			}
		}
		myTree.validateTree();
		JustForTest doIt;
		myTree.forEachData(doIt);
		printf("All done..\n");
	}

	static doTestList()
	{
		DeleteFile(_TESTBPLUSTREE_FILENAME_);
		DoList dolist;
		winx::Dir(_T("D:"), dolist);
		dolist.validata();
		
	}

	void static doTestSpeed()
	{
		DeleteFile(_TESTBPLUSTREE_FILENAME_);
		BPlusTree<int, int, 125> myTree;
		std::map<int, int> myMap;
		std::vector<int> v;

		HRESULT hr = myTree.open(_TESTBPLUSTREE_FILENAME_);
		if (FAILED(hr))
			return;
		srand((unsigned)time(NULL));

		for (int i = 0;  i < 1000000; ++i)
		{
		
			int num = rand() * rand();
			v.push_back(num);
		}
		winx::PerformanceCounter counter;
		winx::StdoutLog log;
		counter.start();
		for (int i = 0; i < v.size(); ++i)
		{
			myMap[v[i]] = i;
		}
		counter.trace(log);
		counter.start();
		for (int i = 0; i < v.size(); ++i)
		{
			myTree.insert(v[i], i);
		}
		counter.trace(log);
	}

	static void doTest()
	{
		doTestIntInt();
		//doTestSpeed();
		//doTestList();
	}
};

// -------------------------------------------------------------------------
//class TestMultiBPlusTree

class TestMultiBPlusTree
{
private:
	enum { TestMax = 100 };
	enum { MAXN =  1000000 };
	typedef std::multimap <int, int> IntMMap;
    typedef IntMMap :: const_iterator CIT;
	typedef std::pair<int, int> Int_Pair;
	typedef std::pair<IntMMap::const_iterator, IntMMap::const_iterator> PCIT;

public:
	static void doTest()
	{
		for (int test = 0; test < TestMax; ++test)
		{
			int num = MAXN;
			printf("Test %d, total %d value\n", test, num);
			DeleteFile(_TESTBPLUSTREE_FILENAME_);
			MultiBPlusTree<int, int, 496> btree;
			std::multimap<int, int> mymap;
			HRESULT hr = btree.open(_TESTBPLUSTREE_FILENAME_);
			if (FAILED(hr))
			{
				printf("cann't open the file\n");
				return;
			}
			srand((unsigned)time(NULL));
			
			int  k = 0;
			for (int i = 0; i < num; ++i)
			{
				if ((++k%10000) == 0)
					printf("%.1f%\n", k/10000.0);
				int a = rand() % 10000;
				int b = rand();
				mymap.insert(Int_Pair(a, b));
				WINX_ASSERT(btree.insert(a, b));
			}
			
			ASSERT(btree.size() == mymap.size());

			btree.validLeaves();

			k = 0;
			for (int i = 0; i < 10000; ++i)
			{
				int a = i;
				PCIT r = mymap.equal_range(a);
				std::vector<int> v1, v2;
				while (r.first != r.second)
				{
					v1.push_back((r.first->second));
					r.first++;
				}
				std::sort(v1.begin(), v1.end());
				btree.get(a, v2);
				std::sort(v2.begin(), v2.end());
				
				WINX_ASSERT(v1.size() == v2.size());

				for (int j = 0; j < v1.size(); ++j)
					WINX_ASSERT(v1[j] == v2[j]);
			}	
		}
	}
};

#endif // defined(TEST_BPLUSTREE)

// -------------------------------------------------------------------------
//	$Log: BPlusTree.h,v $
//	Revision 1.9  2006/11/29 00:57:24  guolijing
//	�ṩ����
//	
//	Revision 1.8  2006/11/14 06:43:01  guolijing
//	Bugfixed
//	
//	Revision 1.7  2006/11/13 04:49:42  guolijing
//	*** empty log message ***
//	
//	Revision 1.6  2006/11/10 03:38:44  xushiwei
//	ASSERT -> WINX_ASSERT
//	
//	Revision 1.5  2006/11/10 01:31:16  xushiwei
//	TEST_BPLUSTREE
//	
//	Revision 1.4  2006/11/09 08:01:54  guolijing
//	����MultiBPlusTree
//	
//	Revision 1.3  2006/10/24 01:50:54  guolijing
//	bug fixed
//	��ԭ����BPlusTree�ĳ�BPlusTreeBase
//	Ϊ��ͨ�÷��ṩBPlusTree��
//	Ϊ����ר���ṩBPlusTreeBase
//	
//	Revision 1.2  2006/10/13 08:27:20  guolijing
//	*** empty log message ***
//	
//	Revision 1.1  2006/10/13 08:18:53  guolijing
//	B+���������insert get
//	
#pragma pack()
#endif /* __DATAMINING_DICT_BPLUSTREE_H__ */
