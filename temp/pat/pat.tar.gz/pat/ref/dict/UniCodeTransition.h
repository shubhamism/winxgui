/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/UniCodeTransition.h
//	������		��	������
//	����ʱ��	��	8/30/2006 4:04:44 PM
//	��������	��	
//
//	$Id: UniCodeTransition.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __UNICODETRANSITION_H__
#define __UNICODETRANSITION_H__

// -------------------------------------------------------------------------

struct PunctuactionRange
{
	unsigned short begin;
	unsigned short end;
};

const static PunctuactionRange g_RangTable[] = 
{
	{0x0000, 0x00FF},
	{0x0300, 0x036F},
	{0x1D00, 0x1DFF},
	{0x2000, 0x2BFF},
	{0x2E00, 0x2E7F},
	{0x3000, 0x303F},
	{0x3200, 0x33FF},
	{0x4DC0, 0x4DFF},
	{0xA700, 0xA71F},
	{0xFB50, 0xFDFF},
	{0xFE00, 0xFE2F},
	{0xFF00, 0xFFFF}
};

class UnicodeTransition
{
private:
	enum { CHINESECHARACTERSETSIZE = 20992 };

public:
	static bool isChineseCharacter(const wchar_t* pCh)
	{
		ASSERT(pCh);
		if (NULL == pCh && wcslen(pCh) <= 0)
			return false;

		return getIndex(pCh) != -1;
	}

	static bool isPunctuaction(const wchar_t* pCh)
	{
		ASSERT(pCh);
		if (pCh != NULL)
		{
			int num = sizeof(g_RangTable)/sizeof(g_RangTable[0]);
			wchar_t value = *pCh;
			for (int i = 0; i < num; ++i)
			{
				if (value >= g_RangTable[i].begin && value <= g_RangTable[i].end)
					return true;
			}
		}

		return false;
	}

	static int getIndex(const wchar_t* pCh)
	{
		ASSERT(pCh);
		if (NULL == pCh && wcslen(pCh) <= 0)
			return -1;

		if (*pCh < 0x4E00 || *pCh > 0x9FFF)
			return -1;
		else
			return *pCh - 0X4E00 + 1;
	}

	static wchar_t getUnicode(int idx)
	{
		if (idx < 1 || idx >  CHINESECHARACTERSETSIZE)
			return -1;
		else
			return idx + 0X4E00 - 1;
	}
};

// -------------------------------------------------------------------------
//	$Log: UniCodeTransition.h,v $
//	Revision 1.2  2006/09/28 06:21:18  guolijing
//	�Ż� isPunctuaction
//	
//	Revision 1.1  2006/09/14 07:53:07  helijun
//	���ִ��ֵ��Ƶ�datamining/dictĿ¼
//	
//	Revision 1.8  2006/09/12 04:42:13  helijun
//	���ӱ�����ʶ�𣬲��ڷִ��н������Ź��ˣ���������ʶ�����ֶ�����������
//	
//	Revision 1.7  2006/09/06 02:07:32  helijun
//	*** empty log message ***
//	
//	Revision 1.6  2006/09/04 09:04:08  helijun
//	*** empty log message ***
//	
//	Revision 1.5  2006/09/04 03:28:11  guolijing
//	*** empty log message ***
//	
//	Revision 1.4  2006/09/04 03:15:08  guolijing
//	*** empty log message ***
//	
//	Revision 1.3  2006/09/04 01:39:12  guolijing
//	*** empty log message ***
//	
//	Revision 1.2  2006/09/04 01:37:27  guolijing
//	ifu/segmention/
//	
//	Revision 1.1  2006/09/04 00:49:44  guolijing
//	*** empty log message ***
//	
//	Revision 1.2  2006/09/04 00:49:23  guolijing
//	*** empty log message ***
//	
//	Revision 1.1  2006/09/03 07:36:54  guolijing
//	UNICODE �汾��˫����
//	

#endif /* __UNICODETRANSITION_H__ */
