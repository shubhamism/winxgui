/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/HashTrieBuilder.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-7-16 23:48:42
//	��������	��	
//
//	$Id: HashTrieBuilder.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __DATAMINING_DICT_HASHTRIEBUILDER_H__
#define __DATAMINING_DICT_HASHTRIEBUILDER_H__

#ifndef _VECTOR_
#include <vector>
#endif

#ifndef _ALGORITHM_
#include <algorithm>
#endif

// -------------------------------------------------------------------------
// class HashTrieBuilder

template <class SizeT>
struct HashTrieNodeHeaderT
{
	SizeT count;
	SizeT layout;
	SizeT conflict;
};

template <class E, int ConflictLim = 0, int InvalidChar = '\0'>
class HashTrieBuilder
{
public:
	typedef E CharT;
	typedef UINT SizeT;

private:
	typedef TrieTree<CharT> TrieT;
	typedef SizeT InfoT;
	struct PairT
	{
		CharT first;
		InfoT second;
	};

	struct HashNodeT : public HashTrieNodeHeaderT<SizeT>
	{
		PairT childs[1];
	};

private:
	typedef std::map<CharT, InfoT> FirstCharMap;
	std::AutoFreeAlloc m_alloc;
	FirstCharMap m_first;
	
private:
	typedef std::RecycleBuffer<char> BufferT;
	typedef typename TrieT::NodeT NodeT;
	typedef typename NodeT::const_iterator It;
	
	static SizeT __layout(const NodeT* node, BufferT& buf, SizeT& conflict)
	{
		SizeT layout = node->size();
lzRetry:
		char* used = buf.reserve(layout);
		ZeroMemory(used, layout);
		conflict = 0;
		for (It it = node->begin(); it != node->end(); ++it)
		{
			SizeT index = (*it).first % layout;
			if (used[index] > ConflictLim)
			{
				++layout;
				goto lzRetry;
			}
			if (used[index])
				++conflict;
			++used[index];
		}
		return layout + conflict;
	}

	template <class StatT>
	InfoT __build(InfoT infoTrie, BufferT& buf, StatT& stat, CharT chStat)
	{
		InfoT info = TrieT::isWord(infoTrie);
		NodeT* nodeTrie = TrieT::nodePtr(infoTrie);
		if (nodeTrie)
		{
			SizeT conflict = 0;
			SizeT count = nodeTrie->size();
			SizeT layout = count > 1 ? __layout(nodeTrie, buf, conflict) : count;
			SizeT cb = sizeof(HashNodeT)-sizeof(PairT) + sizeof(PairT)*layout;
			HashNodeT* node = (HashNodeT*)(void*)STD_ALLOC_ARRAY(m_alloc, char, cb);
			ZeroMemory(node, cb);
			node->count = count;
			node->layout = layout;
			node->conflict = conflict;
			stat.add(*node, chStat);
			SizeT conflict_index = layout;
			for (It it = nodeTrie->begin(); it != nodeTrie->end(); ++it)
			{
				CharT ch = (*it).first;
				SizeT index = ch % (layout - conflict);
				if (node->childs[index].first)
					index = --conflict_index;
				node->childs[index].first = ch;
				node->childs[index].second = __build((*it).second, buf, stat, ch);
			}
			TrieT::makeNode(info, (NodeT*)node);
		}
		return info;
	}

public:
	template <class StatT>
	HashTrieBuilder(const TrieT& trie, StatT& stat)
	{
		BufferT buf;
		NodeT* nodeTrie = TrieT::nodePtr(trie.root());
		if (nodeTrie)
		{
			for (It it = nodeTrie->begin(); it != nodeTrie->end(); ++it)
			{
				CharT ch = (*it).first;
				InfoT info = __build((*it).second, buf, stat, ch);
				m_first.insert(FirstCharMap::value_type(ch, info));
			}
			stat.finish();
		}
	}

private:
	template <class LogT>
	static void __trace(InfoT info, LogT& log, bool done[], size_t nlevel)
	{
		const CharT fmt[] = { '%', 'c', '%', 'c', '\n', '\0' };
		const HashNodeT* node = (const HashNodeT*)TrieT::nodePtr(info);
		for (SizeT i = 0, j = 0; i < node->layout; ++i)
		{
			const PairT& value = node->childs[i];
			if (value.first == InvalidChar)
				continue;
			done[nlevel] = (++j != node->count);
			for (size_t i = 0; i < nlevel; ++i)
			{
				log.trace(done[i] ? "����" : "����");
			}
			log.trace(done[nlevel] ? "����" : "����");
			log.trace(fmt, value.first, TrieT::isWord(value.second) ? '*':' ');
			if (TrieT::nodePtr(value.second))
			{
				__trace(value.second, log, done, nlevel+1);
			}
		}
	}
	
public:
	template <class LogT>
	void trace(LogT& log) const
	{
		log.trace("$/\n");
		bool done[128];
		for (FirstCharMap::const_iterator it = m_first.begin(); it != m_first.end(); )
		{
			const CharT fmt[] = { '%', 'c', '\n', '\0' };
			const FirstCharMap::value_type value = *it;
			done[0] = (++it != m_first.end());
			log.trace(done[0] ? "����" : "����");
			log.trace(fmt, value.first);
			if (TrieT::nodePtr(value.second))
			{
				__trace(value.second, log, done, 1);
			}
		}
	}
};

// -------------------------------------------------------------------------
// class HashTrieStat

template <class CharT, class ProgressT>
class HashTrieStat
{
private:
	typedef UINT SizeT;
	typedef HashTrieNodeHeaderT<SizeT> HeaderT;

	struct DataT : HeaderT
	{
		CharT ch;
		bool operator<(const DataT& b) const {
			if (conflict != b.conflict)
				return conflict > b.conflict;
			if (layout != b.layout)
				return layout > b.layout;
			return count > b.count;
		}
	};

	typedef std::vector<DataT> Datas;
	
	SizeT m_layout;
	SizeT m_count;
	Datas m_data;
	ProgressT& m_progress;
	
public:
	HashTrieStat(ProgressT& progress)
		: m_progress(progress), m_layout(0), m_count(0)
	{
	}

	void add(const HeaderT& node, CharT chStat)
	{
		m_layout += node.layout;
		m_count += node.count;
		if (node.count*2 < node.layout)
		{
			m_progress.step();
		}
		DataT data;
		(HeaderT&)data = node;
		data.ch = chStat;
		m_data.push_back(data);
	}

	void finish()
	{
		std::sort(m_data.begin(), m_data.end());
	}

	template <class LogT>
	void trace(LogT& log) const
	{
		log.trace(
			"total layout=%d, count=%d, extra=%d(%.2lf%%)\n",
			m_layout, m_count, m_layout-m_count,
			(double)(m_layout-m_count)/m_count*100);
		for (Datas::const_iterator it = m_data.begin(); it != m_data.end(); ++it)
		{
			const DataT& node = *it;
			log.trace(
				"count=%d, layout=%d conflict=%d %C\n",
				node.count, node.layout, node.conflict, node.ch);
		}
	}
};

// -------------------------------------------------------------------------
// TestHashTrieBuilder

template <class Unused>
class TestHashTrieBuilder
{
public:
	TestHashTrieBuilder()
	{
		StderrLog errlog;	
		setlocale(LC_ALL, "");
		
		TrieTree<WCHAR> trie;
		buildTrie(trie, "data.txt", errlog);
		errlog.trace("\nbuildTrie done!\n");
		
		HashTrieStat<WCHAR, StderrLog> stat(errlog);
		
		HashTrieBuilder<WCHAR, 2> hashTrie(trie, stat);
		StdFileLog logHashDict("HashTrie.log");
		hashTrie.trace(logHashDict);
		
		errlog.trace("\nbuildHashTrie done!\n");
		
		StdFileLog log("HashTrieBuilder.log");
		stat.trace(log);
	}
};

// -------------------------------------------------------------------------
//	$Log: HashTrieBuilder.h,v $
//	Revision 1.1  2006/07/17 02:20:39  xushiwei
//	class HashTrieBuilder - just a test
//	

#endif /* __DATAMINING_DICT_HASHTRIEBUILDER_H__ */
