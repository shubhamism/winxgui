/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/TrieBuilder.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-7-16 23:57:19
//	��������	��	
//
//	$Id: TrieBuilder.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __DATAMINING_DICT_TRIEBUILDER_H__
#define __DATAMINING_DICT_TRIEBUILDER_H__

#if (0)
// -------------------------------------------------------------------------
// class TrieBuilder

template <class E>
class TrieBuilder
{
public:
	typedef TrieTree<E> TrieT;
	typedef typename TrieT::NodeT NodeT;

	typedef E CharT;
	typedef INT BaseT;
	typedef INT CheckT;
	
	struct ItemT
	{
		BaseT base;
		//--> check!=0(�Ѿ�ʹ��):
		//	word = (base[prefix] >> 1) + ch;
		//	isWord = (base[word] & 1);
		//--> check==0(δʹ��):
		//	base[]ָ����һ��δʹ��������ײ���
	
		CheckT check;
		//--> check=0��ʾδʹ�á�check[word] = word - prefix;

		ItemT() : base(0), check(0)
		{
		}
	};
	
private:
	typedef std::vector<ItemT> Items;

	Items m_data;
	BaseT m_itemUnused;

public:
	TrieBuilder() : m_itemUnused(0)
	{
	}

private:
	bool __test_used(BaseT item)
	{
		MEMORY_ASSERT(item < m_data.size());
		return m_data[item].check != 0;
	}

	bool __test_base(const NodeT& node, BaseT base)
	{
		MEMORY_ASSERT(!__test_used(base));

		CharT ch = (*node.begin()).first;
		for (NodeT::const_iterator it = node.begin(); ++it != node.end(); )
		{
			BaseT item = ((*it).first - ch) + base;
			if (item >= m_data.size())
				return true;
			if (m_data[item].check != 0)
				return false;
		}
		return true;
	}

	BaseT& __last_unused(BaseT word)
	{
		while (m_data[--word].check != 0)
			if (word == 0)
				return ;
		return m_data[word];
	}

	BaseT __next_unused(BaseT word)
	{
	}

	BaseT& __unused_head(BaseT word)
	{
		while (m_data[word].base == 0)
			--word;
		return m_data[temp].word;
	}

	void __insert(InfoT info, BaseT prefix, BaseT word)
	{
		const NodeT& node = TrieT::nodeRef(info);

		CharT ch = (*node.begin()).first;
		
		NodeT::const_iterator last = node.end();
		CharT chLast = *(--last);
		BaseT wordLast = word + (chLast - ch);
		
		BaseT sizeOld = m_data.size();
		if (wordLast >= sizeOld)
		{
			m_data[sizeOld].base = ++wordLast;
			m_data.resize(wordLast);
		}

		m_data[prefix].base = TrieT::isWord(info) | ((word - ch) << 1);

		enum { InvalidBase = 0 };
		for (NodeT::const_iterator it = node.begin(); it != node.end(); ++it)
		{
			BaseT word2 = (word - ch) + (*it).first;
			MEMORY_ASSERT(!__test_used(word2));

			BaseT temp = m_data[word2].base;
			m_data[word2].check = word2 - prefix;
			m_data[word2].base = InvalidBase;
			if (temp) {
				BaseT& lastUnused = __last_unused(word2);
				BaseT& nextUnused = __next_unused(word2);
			}
				 = temp;
			else {
				++word2;
				if (word2 < m_data.size() && !__test_used(word2))
					__unused_head(word2-2) = word2;
			}
		}
	}

	void __insert(const NodeT& node, BaseT prefix)
	{
		BaseT next, item = m_itemUnused;
		BaseT count = m_data.size();
		while (item < count)
		{
			next = m_data[item];
			for (;;)
			{
				if (__test_base(node, item))
				{
					__insert(node, prefix, item);
					return;
				}
				if (__test_used(node, ++item))
					break;
			}
			item = next;
		}
		__insert(node, prefix, count);
	}

public:
	void insert()
	{
		typedef NodeT::value_type DataT;
		typedef std::vector<const DataT*> Datas;
		Datas data;
		data.reserve(node.size());
		for (DataT::const_iterator it = node.begin(); it != node.end(); ++it)
		{

		}
		std::for_each(
			node.begin(),
			node.end(),
			std::inserter(data, data.end())
			);
	}

	void build(const TrieT& trie)
	{
		insert(TrieT::nodeRef(trie.root()));
	}
};

#endif
// -------------------------------------------------------------------------
//	$Log: TrieBuilder.h,v $
//	Revision 1.2  2006/07/24 07:51:44  xushiwei
//	HashDict���д�����
//	
//	Revision 1.1  2006/07/17 02:21:08  xushiwei
//	class TrieBuilder - not complete
//	

#endif /* __DATAMINING_DICT_TRIEBUILDER_H__ */
