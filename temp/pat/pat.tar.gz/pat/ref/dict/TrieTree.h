/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/TrieTree.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-7-16 23:45:34
//	��������	��	
//
//	$Id: TrieTree.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __DATAMINING_DICT_TRIETREE_H__
#define __DATAMINING_DICT_TRIETREE_H__

#ifndef _MAP_
#include <map>
#endif

// -------------------------------------------------------------------------
// class TrieTree

template <class E>
class TrieTree
{
public:
	typedef E CharT;
	typedef UINT InfoT;
	typedef std::map<CharT, InfoT> NodeT;

private:
	InfoT m_root;
	std::AutoFreeAlloc m_alloc;

public:
	static UINT isWord(InfoT info) {
		return (info & 1);
	}

	static void makeWord(InfoT& info) {
		info |= 1;
	}

	static NodeT* nodePtr(InfoT info) {
		return (NodeT*)(info >> 1);
	}
	
	static NodeT& nodeRef(InfoT info) {
		return *(NodeT*)(info >> 1);
	}
	
	static void makeNode(InfoT& info, NodeT* node) {
		UINT nodeVal = (UINT)node;
		MEMORY_ASSERT((INT)nodeVal > 0);
		info |= (nodeVal << 1);
	}

	static INT distance(const NodeT* node) {
		if (node) {
			MEMORY_ASSERT(!node->empty());
			NodeT::const_iterator last = node->end();
			CharT ch1 = (*node->begin()).first;
			CharT ch2 = (*--last).first;
			return ch2 - ch1;
		}
		return -1;
	}
	
	InfoT root() const {
		return m_root;
	}
	
public:
	TrieTree()
	{
		m_root = 0;
	}

	template <class CharIt>
	void insert(CharIt first, CharIt last)
	{
		InfoT* info = &m_root;
		for (; first != last; ++first)
		{
			if (nodePtr(*info) == NULL)
			{
				NodeT* node = STD_NEW(m_alloc, NodeT);
				makeNode(*info, node);
			}
			info = &nodeRef(*info)[*first];
		}
		makeWord(*info);
	}

	void insert(const CharT* word)
	{
		insert(word, word + std::char_traits<CharT>::length(word));
	}

private:
	template <class LogT>
	static void __trace(InfoT info, LogT& log, bool done[], size_t nlevel)
	{
		const CharT fmt[] = { '%', 'c', '%', 'c', '\n', '\0' };
		const NodeT& node = nodeRef(info);
		for (NodeT::const_iterator it = node.begin(); it != node.end(); )
		{
			const NodeT::value_type& value = *it;
			done[nlevel] = (++it != node.end());
			for (size_t i = 0; i < nlevel; ++i)
			{
				log.trace(done[i] ? "����" : "����");
			}
			log.trace(done[nlevel] ? "����" : "����");
			log.trace(fmt, value.first, isWord(value.second) ? '*':' ');
			if (nodePtr(value.second))
			{
				__trace(value.second, log, done, nlevel+1);
			}
		}
	}

public:
	template <class LogT>
	void trace(LogT& log)
	{
		log.trace("$/\n");
		if (m_root)
		{
			bool done[128];
			__trace(m_root, log, done, 0);
		}
	}
};

// -------------------------------------------------------------------------
// buildTrie

template <class TrieT, class ProgressT>
inline void buildTrie(TrieT& trie, FILE* fp, ProgressT& progress)
{
	int tick = 0;
	int weight;
	char gbk[256];
	WCHAR word[256];
	while (fscanf(fp, "%d%s", &weight, gbk) == 2)
	{
		if (!(++tick & 0x7ff))
			progress.step();
		MultiByteToWideChar(936, 0, gbk, -1, word, 256);
		trie.insert(word);
	}
}

template <class TrieT, class ProgressT>
inline void buildTrie(TrieT& trie, LPCSTR szFile, ProgressT& progress)
{
	FILE* fp = fopen(szFile, "r");
	if (fp != NULL)
	{
		buildTrie(trie, fp, progress);
		fclose(fp);
	}
}

// -------------------------------------------------------------------------
//	$Log: TrieTree.h,v $
//	Revision 1.1  2006/07/17 02:20:17  xushiwei
//	class TrieTree
//	

#endif /* __DATAMINING_DICT_TRIETREE_H__ */
