/* -------------------------------------------------------------------------
//	�ļ���		��	datamining/dict/KTrieItem.h
//	������		��	������
//	����ʱ��	��	8/28/2006 11:15:13 AM
//	��������	��	
//
//	$Id: KTrieItem.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __KTRIEITEM_H__
#define __KTRIEITEM_H__

// -------------------------------------------------------------------------

#define ISKWORD (0x80000000)
#define ISBEGINOFKWORD (0x40000000)
#define KWORDMASK (0x3fffffff)
#define CHINESECHARACTERSETSIZE (20992)
#ifndef LPWSTR
typedef wchar_t* LPWSTR;
#endif

#ifdef TEXTSEGMENT_NSHORTPATH
typedef int KTrieItem_WordInfo;
#endif


class KTrieItem
{
public:
	int base;
	int check;
	KTrieItem_WordInfo info;
	KTrieItem(): base(0), check(0) {};
};

// -------------------------------------------------------------------------
//	$Log: KTrieItem.h,v $
//	Revision 1.1  2006/09/14 07:53:07  helijun
//	���ִ��ֵ��Ƶ�datamining/dictĿ¼
//	
//	Revision 1.7  2006/09/04 02:57:42  guolijing
//	�����ڴ�ṹ��WordInfo
//	
//	Revision 1.6  2006/09/04 02:10:48  guolijing
//	SEGMENT_NSHORTPATH -> TEXTSEGMENT_NSHORTPATH
//	
//	Revision 1.5  2006/09/04 02:09:30  guolijing
//	WORDINFO -> WordInfo
//	
//	Revision 1.4  2006/09/04 02:07:39  guolijing
//	SEGMENT_NSHORTPATH
//	
//	Revision 1.3  2006/09/04 02:03:52  guolijing
//	KTrie_Value_Type -> WORDINFO
//	val -> info
//	
//	Revision 1.2  2006/09/04 01:37:27  guolijing
//	ifu/segmention/
//	
//	Revision 1.1  2006/09/04 00:59:42  guolijing
//	*** empty log message ***
//	
//	Revision 1.1  2006/09/03 07:36:54  guolijing
//	UNICODE �汾��˫����
//	

#endif /* __KTRIEITEM_H__ */
