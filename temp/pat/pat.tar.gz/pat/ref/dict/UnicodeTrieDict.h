/* -------------------------------------------------------------------------
//	�ļ���		��	ifu/segmention/UnicodeTrieDict.h
//	������		��	������
//	����ʱ��	��	2006-8-31 11:12:26
//	��������	��	
//
//	$Id: UnicodeTrieDict.h 2 2008-07-14 03:41:05Z 315brand $
// -----------------------------------------------------------------------*/
#ifndef __UNICODETRIEDICT_H__
#define __UNICODETRIEDICT_H__

#ifndef __UNICODETRANSITION_H__
#include "UnicodeTransition.h"
#endif

#ifndef __KTRIEITEM_H__
#include "KTrieItem.h"
#endif


// -------------------------------------------------------------------------

#ifndef for
#define for if(0); else for
#endif


struct WordInfo{
	int weight;
	int idx;
	bool isPrefix;
};

class UnicodeTrieDict
{
private:

	KTrieItem* items;
	int nSize;

public:

	UnicodeTrieDict()
	{
		items = NULL;
		nSize = 0;
	}

	~UnicodeTrieDict()
	{
		if (items)
			delete items;
	}

	bool good()
	{
		return items != NULL && nSize > 0;
	}

	bool open(const wchar_t* fileName)
	{
		ASSERT(NULL == items);
		
		FILE *fp = _wfopen(fileName, L"rb");
		if (NULL == fp)
			return false;

		fread(&nSize, sizeof(int), 1, fp);
		items = new KTrieItem[nSize];
		if (NULL == items)
			return false;

		fread(items, sizeof(KTrieItem), nSize, fp);
		fclose(fp);

		for (int i = 0; i < nSize; ++i)
		{
			if (items[i].base > nSize)
				return false;
		}

		return true;
	}

	void close()
	{
		if (items)
			delete items;
		items = NULL;
		nSize = 0;
	}

	bool isWord(const wchar_t* word, int len, int* weight = NULL, int* index = NULL, bool* isPrefix = NULL)
	{
		WordInfo info;
		bool bWord = isWord(word, len, &info);

		if (weight) {
			*weight = info.weight;
		}
		if (index) {
			*weight = info.idx;
		}
		if (isPrefix) {
			*weight = info.isPrefix;
		}
		
		return bWord;
	}

	bool isWord(const wchar_t* word, int len, WordInfo* info)
	{
		if (NULL == items)
			return false;
		ASSERT(word != NULL);
		ASSERT(len > 0);	
		if (NULL == word || len <= 0)
			return false;
		if (info)
			info->isPrefix = false;

		int pos = UnicodeTransition::getIndex(word);
		int lastPos = 0;
		if (pos >= nSize || !(items[pos].check & ISBEGINOFKWORD))
			return false;

		for (int i = 1; i < len; ++i)
		{
			int idx = UnicodeTransition::getIndex(word+i);
			if (-1 == idx)
				return false;
			lastPos = pos;
			pos = items[pos].base + idx;
			if (pos >= nSize || lastPos != (items[pos].check & (KWORDMASK)))
				return false;
		}

		if (info)
		{
			info->isPrefix = true;
			info->idx = pos;
		}

		if (items[pos].check & ISKWORD)
		{
			if (info)
				info->weight = items[pos].info;
			return true;
		}
		else
			return false;
		
	}

	bool isWord(int baseIdx, const wchar_t* word, int* weight = NULL, int* index = NULL, bool* isPrefix = NULL)
	{
		WordInfo info;
		bool bWord = isWord(baseIdx, word, &info);

		if (weight) {
			*weight = info.weight;
		}
		if (index) {
			*weight = info.idx;
		}
		if (isPrefix) {
			*weight = info.isPrefix;
		}

		return bWord;
	}

	bool isWord(int baseIdx, const wchar_t* word, WordInfo* info)
	{
		if (NULL == items)
			return false;
		ASSERT(word != NULL);
		ASSERT(baseIdx < nSize);
		if (NULL == word)
			return false;
		if (info)
				info->isPrefix = false;
		if (baseIdx >= nSize || UnicodeTransition::getIndex(word) == -1)
			return false;

		int pos = baseIdx;
		int lastPos = pos;
		pos = items[pos].base + UnicodeTransition::getIndex(word);
		if (pos >= nSize || lastPos != (items[pos].check & (KWORDMASK)))
			return false;

		if (info)
		{
			info->isPrefix = true;
			info->idx = pos;
		}
		if (items[pos].check & ISKWORD)
		{
			if (info)
				info->weight = items[pos].info;
			return true;
		}
		else
			return false;
	}

	bool getWordInfo(const wchar_t* word, int len, WordInfo* info)
	{
		if (NULL == items)
			return false;
		ASSERT(info != NULL);
		ASSERT(word != NULL);
		ASSERT(len > 0);
		if (NULL == word || len <= 0 || NULL == info)
			return false;
		
		if (info)
			info->isPrefix = false;

		std::vector<int> v;
		for (int i = 0; i < len; ++i)
		{
			int idx = UnicodeTransition::getIndex(word+i);
			if (-1 == idx)
				return false;
			v.push_back(idx);
		}

		if (v.size() == 0)
			return false;
		int pos = v[0];
		int lastPos = 0;
		if (pos >= nSize || !(items[pos].check&ISBEGINOFKWORD))
			return false;

		for (int i = 1; i < v.size(); ++i)
		{
			lastPos = pos;
			pos = items[pos].base + v[i];
			if (pos >= nSize || lastPos != (items[pos].check&(KWORDMASK)))
				return false;
		}
		if (info)
		{
			info->isPrefix = true;
			lastPos = pos;
		}
		
		if (items[pos].check&ISKWORD)
		{
			if (info)
				info->weight = items[pos].info;
			return true;
		}

		return false;
	}

	int size()
	{
		return nSize;
	}

	KTrieItem& item(int nIdx)
	{ 
		ASSERT(NULL != items);
		ASSERT(nIdx < nSize);
		return items[nIdx];
	}
	
	KTrieItem& operator[] (int nIdx)
	{
		ASSERT(NULL != items);
		ASSERT(nIdx < nSize);
		return items[nIdx];
	}
};

// -------------------------------------------------------------------------
//	$Log: UnicodeTrieDict.h,v $
//	Revision 1.3  2006/09/28 06:21:53  guolijing
//	ASSERT(NULL == items);
//	
//	Revision 1.2  2006/09/20 06:25:10  guolijing
//	����close�����Զ�Ӧopen
//	
//	Revision 1.1  2006/09/14 07:53:07  helijun
//	���ִ��ֵ��Ƶ�datamining/dictĿ¼
//	
//	Revision 1.15  2006/09/12 04:42:13  helijun
//	���ӱ�����ʶ�𣬲��ڷִ��н������Ź��ˣ���������ʶ�����ֶ�����������
//	
//	Revision 1.14  2006/09/04 06:06:12  helijun
//	*** empty log message ***
//	
//	Revision 1.13  2006/09/04 06:00:34  helijun
//	insert:
//	1:bool isWord(const wchar_t* word, int len, int* weight = NULL, int* index = NULL, bool* isPrefix = NULL)
//	2:bool isWord(int baseIdx, const wchar_t* word, , int* weight = NULL, int* index = NULL, bool* isPrefix = NULL)
//	
//	Revision 1.12  2006/09/04 05:54:15  guolijing
//	*** empty log message ***
//	
//	Revision 1.11  2006/09/04 03:28:11  guolijing
//	*** empty log message ***
//	
//	Revision 1.10  2006/09/04 03:15:08  guolijing
//	*** empty log message ***
//	
//	Revision 1.9  2006/09/04 02:57:42  guolijing
//	�����ڴ�ṹ��WordInfo
//	
//	Revision 1.8  2006/09/04 02:09:30  guolijing
//	WORDINFO -> WordInfo
//	
//	Revision 1.7  2006/09/04 02:05:30  guolijing
//	ASSERT(word != NULL)
//	
//	Revision 1.6  2006/09/04 02:03:52  guolijing
//	KTrie_Value_Type -> WordInfo
//	val -> info
//	
//	Revision 1.5  2006/09/04 01:37:27  guolijing
//	ifu/segmention/
//	
//	Revision 1.4  2006/09/04 01:32:25  guolijing
//	�ɵ�kword
//	
//	Revision 1.3  2006/09/04 01:26:11  guolijing
//	*** empty log message ***
//	
//	Revision 1.2  2006/09/04 00:57:08  guolijing
//	*** empty log message ***
//	
//	Revision 1.2  2006/09/04 00:49:23  guolijing
//	*** empty log message ***
//	
//	Revision 1.1  2006/09/03 07:36:54  guolijing
//	UNICODE �汾��˫����
//	

#endif /* __UNICODETRIEDICT_H__ */
