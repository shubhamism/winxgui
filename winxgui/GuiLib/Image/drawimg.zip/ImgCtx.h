//	Project: DrawImg
//	File:    ImgCtx.h
//	Author:  Paul Bludov
//	Date:    08/24/2001
//
//	Description:
//		Sample class for loading and displaying images using IImgCtx interface
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#ifndef __IMGCTX_H__
#define __IMGCTX_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//@//////////////////////////////////////////////////////////////////////////
// If you got a compiler errors here, you should update your PSDK,
// or download this file from 
// http://msdn.microsoft.com/downloads/samples/internet/libraries/ie6_lib/
/////////////////////////////////////////////////////////////////////////////

#include <IImgCtx.h> // IImgCtx declaration

//@//////////////////////////////////////////////////////////////////////////
//	CImgCtxImage

class ATL_NO_VTABLE CImgCtxImage :
	public CChildFrame<CImgCtxImage>
{

	// IImgCtx object used to load and render images
	CComPtr<IImgCtx> m_pImage;

public:

	// Overrides
	static LPCTSTR GetMethodName()
	{
		return _T("ImgCtx");
	}

	void Destroy()
	{
		m_pImage.Release();
	}

	// Implementation
	HRESULT DrawImg(HDC hdc, RECT& rcBounds)
	{
		if (m_pImage)
		{
			// Check download state
			DWORD dwState = 0;
			HRESULT hr = m_pImage->GetStateInfo(&dwState, NULL, true);
			if (SUCCEEDED(hr))
			{
				if (IMGLOAD_LOADING & dwState)
				{
					// Still loading - wait 50 msec and request again
					::DrawText(hdc, _T("Loading, please wait..."), -1, &rcBounds, DT_SINGLELINE);
					::Sleep(50);
					Invalidate(false);

					hr = S_FALSE;
				}
				else if (IMGLOAD_COMPLETE & dwState)
				{
					// Download successfully complete
					hr = m_pImage->Draw(
						hdc,				// [in] Handle of device context on which to render the image
						&rcBounds			// [in] Position and dimensions
						);
				}
				else
				{
					// Download failed
					hr = E_UNEXPECTED;
				}
			}
			return hr;
		}

		return E_UNEXPECTED;
	}

	HRESULT Load(LPCTSTR szFile)
	{
		// Create IImgCtx object
		HRESULT hr = ::CoCreateInstance(CLSID_IImgCtx, NULL, CLSCTX_ALL, IID_IImgCtx, (void**)&m_pImage);
		if (SUCCEEDED(hr))
		{
			// Load URL
			USES_CONVERSION;
			hr = m_pImage->Load(
					T2COLE(szFile),			// [in] URL
					0						// [in] Flags and preffered color format
					);
		}

		return hr;
	}
};

#endif	__IMGCTX_H__

//@//////////////////////////////////////////////////////////////////////////
//	End Of File ImgCtx.h
