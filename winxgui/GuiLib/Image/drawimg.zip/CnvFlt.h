//	Project: DrawImg
//	File:    CnvFlt.h
//	Author:  Paul Bludov
//	Date:    08/25/2001
//
//	Description:
//		NONE
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#ifndef __CNVFLT_H__
#define __CNVFLT_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <AtlMisc.h>

#define __THROW_BAD_ALLOC \
	::MessageBox(NULL, _T("STL: Out of memory!!!\n"), NULL, MB_OK | MB_ICONSTOP); \
	::ExitProcess(-5);

#include <stl_config.h>

#ifdef __SGI_STL_NO_ARROW_OPERATOR
#undef __SGI_STL_NO_ARROW_OPERATOR	// Hacks: MS C++ compiler support operator->
#endif

#include <map>

class ATL_NO_VTABLE CCnvFilterMapper
{
	typedef __STD::map<CAdapt<CString>, CAdapt<CString> > Ext2Filter_t;
	Ext2Filter_t m_mapExt2Filter;

	static HRESULT CALLBACK AddFilerToList(LPCTSTR szExtensions,
			LPCTSTR szFilter, LPCTSTR szDescription, LPVOID pArg)
	{
		if (NULL == szExtensions || NULL == szFilter || 1 >= ::lstrlen(szExtensions))
			return E_UNEXPECTED;

		CCnvFilterMapper *pThis = (CCnvFilterMapper *)pArg;
		ATLASSERT(pThis);

		LPCTSTR szLast = szExtensions;
		for(LPCTSTR szSpace = szLast + 1; *szSpace; szSpace++)
			if (L' ' == *szSpace)
			{
				CString strExt(szLast, szSpace - szLast);
				strExt.MakeLower();
				pThis->m_mapExt2Filter[strExt] = CString(szFilter);
				szLast = ++szSpace;
			}

		pThis->m_mapExt2Filter[CString(szLast)] = CString(szFilter);

		return S_OK;

	}

public:
	CCnvFilterMapper()
	{
		EnumFormats(AddFilerToList, LPVOID(this));
	}

	typedef HRESULT (CALLBACK *EnumFormatsProc)(LPCTSTR szExtensions,
			LPCTSTR szFilter, LPCTSTR szDescription, LPVOID pArg);

	HMODULE LoadFilter(LPCTSTR szFile)
	{
		Ext2Filter_t::iterator iFilter = m_mapExt2Filter.end();
#ifdef _UNICODE
		LPCTSTR szExt = wcschr(szFile, L'.');
#else
		LPCTSTR szExt = strchr(szFile, '.');
#endif

		if (szExt)
		{
			CString strExt(szExt+1);
			strExt.MakeLower();

			iFilter = m_mapExt2Filter.find(strExt);
		}

		if (m_mapExt2Filter.end() == iFilter)
			return NULL;

		return ::LoadLibrary(iFilter->second.m_T);
	}

	HRESULT EnumFormats(EnumFormatsProc proc, LPVOID pArg)
	{
		CRegKey keyRoot;

		LONG nRetRoot =  keyRoot.Open(HKEY_LOCAL_MACHINE,
				_T("SOFTWARE\\Microsoft\\Shared Tools\\Graphics Filters\\Import"), KEY_READ);

		int nSubKey = 0; 
		while(ERROR_SUCCESS == nRetRoot)
		{
			TCHAR szFormatName[32];
			DWORD dwLen = sizeof(szFormatName) / sizeof(szFormatName[0]);
			FILETIME ftLastWriteTime;

			nRetRoot = RegEnumKeyEx(keyRoot, nSubKey++, szFormatName, &dwLen, NULL, NULL, NULL, &ftLastWriteTime);
			
			if (ERROR_SUCCESS == nRetRoot)
			{
				CRegKey keyFilter;
				LONG nRetFilter = keyFilter.Open(keyRoot, szFormatName, KEY_READ);
				if (ERROR_SUCCESS != nRetFilter)
					continue;

				CString strFilter, strExt, strDesc;
				TCHAR szBuffer[MAX_PATH];
				DWORD dwLen = MAX_PATH;

				nRetFilter = keyFilter.QueryValue(szBuffer, _T("Path"), &dwLen);
				if (ERROR_SUCCESS == nRetFilter)
					strFilter = szBuffer;
				else
					continue;

				dwLen = MAX_PATH;

				nRetFilter = keyFilter.QueryValue(szBuffer, _T("Name"), &dwLen);
				if (ERROR_SUCCESS == nRetFilter)
					strDesc = szBuffer;

				dwLen = MAX_PATH;
				nRetFilter = keyFilter.QueryValue(szBuffer, _T("ExtensionsEx"), &dwLen);
				if (ERROR_SUCCESS != nRetFilter)
				{
					dwLen = MAX_PATH;
					nRetFilter = keyFilter.QueryValue(szBuffer, _T("Extensions"), &dwLen);
				}
				
				if (ERROR_SUCCESS == nRetFilter)
					strExt = szBuffer;
				else
					continue;

				if (S_OK != proc(strExt, strFilter, strDesc, pArg))
					break;
			}
		}

		return S_OK;
	}
};

#endif	__CNVFLT_H__

//@//////////////////////////////////////////////////////////////////////////
//	End Of File CnvFlt.h
