//	Copyright (C) 2001, Lionhearth Technologies, Inc.
//
//	Project: DrawImg
//	File:    MainFrm.cpp
//	Author:  Paul Bludov
//	Date:    08/24/2001
//
//	Description:
//		NONE
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MainFrm.h"

// Load methods
#include "DxTrans.h"
#include "OleLoad.h"
#include "ImgCtx.h"
#include "GDIp.h"
#include "CnvOld.h"
#include "CnvNew.h"

//@//////////////////////////////////////////////////////////////////////////
template <class T>
HRESULT CreateChild(LPCTSTR szFile, HWND hWndParent, T *pDummyToAvoidCompilerBug = NULL)
{
	HRESULT hr = E_OUTOFMEMORY;

	LPTSTR szTitle = (LPTSTR)alloca(::lstrlen(szFile) * sizeof(TCHAR) + ::lstrlen(T::GetMethodName())  * sizeof(TCHAR) + sizeof(_T(" - ")));
	if (szTitle)
	{
		::lstrcpy(szTitle, T::GetMethodName());
		::lstrcat(szTitle, _T(" - "));
		::lstrcat(szTitle, szFile);
	}

	T* pChild = new T;
	if (pChild->CreateEx(hWndParent, NULL, szTitle))
		hr = pChild->Load(szFile);

	return hr;
}

LRESULT CMainFrame::OnFileOpen(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CFileDialog fileDlg(true, NULL, NULL,
		OFN_EXPLORER | OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		_T("All files\x0*.*\x0"), m_hWnd);

	if (IDOK == fileDlg.DoModal(m_hWnd))
	{
		CreateChild<COleLoadPictureImage>(fileDlg.m_szFileName, m_hWndClient);

		HMODULE hGDIPlus = ::LoadLibrary(_T("GDIPlus.dll"));
		if (hGDIPlus)
		{
			CreateChild<CGDIPlusImage>(fileDlg.m_szFileName, m_hWndClient);
			::FreeLibrary(hGDIPlus);
		}

		CreateChild<CDXTransformImage>(fileDlg.m_szFileName, m_hWndClient);
		CreateChild<CImgCtxImage>(fileDlg.m_szFileName, m_hWndClient);
		CreateChild<CGraphicsConverterOldStyleImage>(fileDlg.m_szFileName, m_hWndClient);
		CreateChild<CGraphicsConverterNewStyleImage>(fileDlg.m_szFileName, m_hWndClient);

	}

	return 0;
}


//@//////////////////////////////////////////////////////////////////////////
//	End Of File MainFrm.cpp
