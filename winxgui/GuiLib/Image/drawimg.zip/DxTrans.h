//	Project: DrawImg
//	File:    DxTrans.h
//	Author:  Paul Bludov
//	Date:    08/24/2001
//
//	Description:
//		Sample class for loading and displaying images using DirectXTransform
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#ifndef __DXTRANS_H__
#define __DXTRANS_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <dxtrans.h> // DXTransform declaration

//@//////////////////////////////////////////////////////////////////////////
//	CDXTransformImage

class ATL_NO_VTABLE CDXTransformImage :
	public CChildFrame<CDXTransformImage>
{
	// IDXDCLock object used to obtain our surface DC
	CComPtr<IDXDCLock> m_pDCLock;

public:

	// Overrides
	static LPCTSTR GetMethodName()
	{
		return _T("DxTransform");
	}

	void Destroy()
	{
		m_pDCLock.Release();
	}

	// Implementation
	HRESULT DrawImg(HDC hdc, const RECT& rcBounds)
	{
		if (m_pDCLock)
		{
			HDC hdcImage = m_pDCLock->GetDC();

			// Get the bitmap
			HGDIOBJ hObj = ::GetCurrentObject(hdcImage, OBJ_BITMAP);
			BITMAP bm = {0};

			// Get the size of the bitmap
			if (hObj && ::GetObject(hObj, sizeof(BITMAP), &bm))
			{
				// Draw the image
				return ::StretchBlt(
					hdc,
					rcBounds.left, rcBounds.top,
					rcBounds.right - rcBounds.left,
					rcBounds.bottom - rcBounds.top,
					hdcImage,
					0, 0,
					bm.bmWidth, bm.bmHeight,
					SRCCOPY
					) ? S_OK : E_FAIL;
			}
		}

		return E_UNEXPECTED;
	}

	HRESULT Load(LPCTSTR szFile)
	{
		CComPtr<IDXTransformFactory> pTransFact;
		CComPtr<IDXSurfaceFactory> pSurfFact;

		// Create the Transform Factory.
		HRESULT hr = ::CoCreateInstance(CLSID_DXTransformFactory, NULL,
			CLSCTX_INPROC, IID_IDXTransformFactory,	(void **)&pTransFact);

		if (SUCCEEDED(hr))
			hr = pTransFact->QueryService(SID_SDXSurfaceFactory,
					IID_IDXSurfaceFactory, (void **)&pSurfFact);

		if (SUCCEEDED(hr))
		{
			CComBSTR bstrFile(szFile);
			CComPtr<IDXSurface> pDXSurf;

			// Load DX surface.
			hr = pSurfFact->LoadImage(bstrFile, NULL, NULL,
				NULL, IID_IDXSurface, (void**)&pDXSurf);

			if (SUCCEEDED(hr))
			{
				// Get IDXDCLock object 
				hr = pDXSurf->LockSurfaceDC(NULL, INFINITE, DXLOCKF_READ, &m_pDCLock);
			}
		}

		return hr;
	}
};

#endif	__DXTRANS_H__

//@//////////////////////////////////////////////////////////////////////////
//	End Of File DxTrans.h
