//	Project: DrawImg
//	File:    OleLoad.h
//	Author:  Paul Bludov
//	Date:    08/24/2001
//
//	Description:
//		Sample class for loading and displaying images using ::OleLoadPicture()
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#ifndef __OLELOAD_H__
#define __OLELOAD_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//@//////////////////////////////////////////////////////////////////////////
//	COleLoadPictureImage

class ATL_NO_VTABLE COleLoadPictureImage :
	public CChildFrame<COleLoadPictureImage>
{

	// IPicture object used to load and render images
	CComPtr<IPicture> m_pPicture;

public:

	// Overrides
	static LPCTSTR GetMethodName()
	{
		return _T("OleLoadPicture");
	}

	void Destroy()
	{
		m_pPicture.Release();
	}

	// Implementation
	HRESULT DrawImg(HDC hdc, const RECT& rcBounds)
	{
		if (m_pPicture)
		{
			// Get the width and the height of the picture
			long hmWidth = 0, hmHeight = 0;
			m_pPicture->get_Width(&hmWidth);
			m_pPicture->get_Height(&hmHeight);

			// Convert himetric to pixels
			int nWidth	= MulDiv(hmWidth, ::GetDeviceCaps(hdc, LOGPIXELSX), HIMETRIC_INCH);
			int nHeight	= MulDiv(hmHeight, ::GetDeviceCaps(hdc, LOGPIXELSY), HIMETRIC_INCH);

			// Display the picture using IPicture::Render
			return m_pPicture->Render(
				hdc,							// [in] Handle of device context on which to render the image
				rcBounds.left,					// [in] Horizontal position of image in hdc
				rcBounds.top,					// [in] Vertical position of image in hdc
				rcBounds.right - rcBounds.left,	// [in] Horizontal dimension of destination rectangle
				rcBounds.bottom - rcBounds.top, // [in] Vertical dimension of destination rectangle
				0,								// [in] Horizontal offset in source picture
				hmHeight,						// [in] Vertical offset in source picture
				hmWidth,						// [in] Amount to copy horizontally in source picture
				-hmHeight,						// [in] Amount to copy vertically in source picture
				&rcBounds						// [in, optional] Pointer to position of destination for a metafile hdc
				);
		}

		return E_UNEXPECTED;
	}

	HRESULT Load(LPCTSTR szFile)
	{
		CComPtr<IStream> pStream;
		
		// Load the file to a memory stream
		HRESULT hr = FileToStream(szFile, &pStream);

		if (SUCCEEDED(hr))
		{
			// Decode the picture
			hr = ::OleLoadPicture(
					pStream,			// [in] Pointer to the stream that contains picture's data
					0,					// [in] Number of bytes read from the stream (0 == entire)
					true,				// [in] Loose original format if true
					IID_IPicture,		// [in] Requested interface
					(void**)&m_pPicture // [out] IPictire object on success
					);
		}

		return hr;
	}
};

#endif	__OLELOAD_H__

//@//////////////////////////////////////////////////////////////////////////
//	End Of File OleLoad.h
