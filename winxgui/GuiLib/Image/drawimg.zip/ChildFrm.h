// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDFRM_H__34F28C3E_608A_444C_B96A_91EA6D63D743__INCLUDED_)
#define AFX_CHILDFRM_H__34F28C3E_608A_444C_B96A_91EA6D63D743__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

template <class T>
class CChildFrame : public CMDIChildWindowImpl<CChildFrame>
{
	static HBRUSH GetBrush()
	{
		LOGBRUSH lb = {BS_HATCHED, RGB(92, 92, 92), HS_FDIAGONAL};
		return ::CreateBrushIndirect(&lb) - 1;
	}

public:
	DECLARE_FRAME_WND_CLASS_EX(_T("DrawImg"), IDR_MDICHILD, CS_HREDRAW | CS_VREDRAW, GetBrush())

	virtual void OnFinalMessage(HWND /*hWnd*/)
	{
		T* pT = static_cast<T*>(this);
		pT->Destroy();
		delete this;
	}

	BEGIN_MSG_MAP(CChildFrame)
		MESSAGE_HANDLER(WM_FORWARDMSG, OnForwardMsg)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		CHAIN_MSG_MAP(CMDIChildWindowImpl<CChildFrame>)
	END_MSG_MAP()

	LRESULT OnForwardMsg(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
	{
		LPMSG pMsg = (LPMSG)lParam;

		return CMDIChildWindowImpl<CChildFrame>::PreTranslateMessage(pMsg);
	}

	LRESULT OnPaint(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CPaintDC dc(m_hWnd);
		RECT rc;
		GetClientRect(&rc);

		T* pT = static_cast<T*>(this);
		HRESULT hr = pT->DrawImg(dc, rc);
		if (E_UNEXPECTED == hr)
			dc.DrawText(_T("Load failed!"), -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

		return S_OK;
	}
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDFRM_H__34F28C3E_608A_444C_B96A_91EA6D63D743__INCLUDED_)
