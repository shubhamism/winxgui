//	Project: DrawImg
//	File:    CnvOld.h
//	Author:  Paul Bludov
//	Date:    08/24/2001
//
//	Description:
//		Old and BAD technique for loading images
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#ifndef __CNVOLD_H__
#define __CNVOLD_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//@//////////////////////////////////////////////////////////////////////////
//	CGraphicsConverterOldStyleImage

class ATL_NO_VTABLE CGraphicsConverterOldStyleImage :
	public CChildFrame<CGraphicsConverterOldStyleImage>
{
	HBITMAP m_hBmp;

public:
	CGraphicsConverterOldStyleImage() : m_hBmp(NULL) {}

	static LPCTSTR GetMethodName()
	{
		return _T("Graphics converter old style");
	}

	void Destroy()
	{
		if (m_hBmp)
		{
			::DeleteObject(m_hBmp);
			m_hBmp = NULL;
		}
	}

	HRESULT DrawImg(HDC hdc, const RECT& rcBounds)
	{
		if (m_hBmp)
		{
			HDC hdcMem = ::CreateCompatibleDC(hdc);
			if (hdcMem)
			{
				BITMAP bm = {0};

				// Get the size of the bitmap
				if (::GetObject(m_hBmp, sizeof(BITMAP), &bm))
				{
					::SelectObject(hdcMem, m_hBmp);
					// Draw the image
					::StretchBlt(
						hdc,
						rcBounds.left, rcBounds.top,
						rcBounds.right - rcBounds.left,
						rcBounds.bottom - rcBounds.top,
						hdcMem,
						0, 0,
						bm.bmWidth, bm.bmHeight,
						SRCCOPY
						) ? S_OK : E_FAIL;
				}
				::DeleteDC(hdcMem);
			}
			return S_OK;
		}

		return E_UNEXPECTED;
	}

	HRESULT Load(LPCTSTR szFile)
	{
		HMODULE hModule = g_pMapExtToFilter->LoadFilter(szFile);

		if (NULL == hModule)
			return E_FAIL;

		struct GrphFile
		{
			enum MSFF_CLASS
			{
				MSFF_1BITMONO = 0,
				MSFF_8BITPAL = 2,
				MSFF_24BITBGR = 3,
				MSFF_32BITRGBA = 5,
			};

			enum MSFF_SEQUENCE
			{
				MSFFS_PLAIN = 0,			//	Best case
				MSFFS_UPSIDEDOWN = 1,		//	(BMP)
				MSFFS_INTERLACED = 2,		//	(GIF)
				MSFFS_INTERLACEDSQUARE = 3,	//	(PNG)
			};

			enum MSFF_CONTROL
			{
				MSSFC
			};

			DWORD	dwReserved; //not used

			LONG	nWidth,
					nHeight;

			DWORD	dwHeight2;
			DWORD	dwClass;

			WORD	wBitsPerChannel; //8

			DWORD	dwCompression; //0
			DWORD	dwSequence; //0

			bool IsBGR() const
			{
				return MSFF_24BITBGR == dwClass;
			}

			bool IsMono() const
			{
				return MSFF_1BITMONO == dwClass;
			}

			bool IsPal() const
			{
				return MSFF_8BITPAL == dwClass || MSFF_1BITMONO == dwClass;
			}

			LONG GetByteWidth() const
			{
				return nWidth * (GetBPP() >> 3);
			}

			WORD GetBPP() const
			{
				switch(dwClass)
				{

				case MSFF_1BITMONO:
	//			case 1:
				case MSFF_8BITPAL:
					return 8;

	//			case 11:
	//				return wBitsPerChannel * 2;

				case MSFF_24BITBGR:
	//			case 4:
	//			case 8:
	//			case 9:
					return wBitsPerChannel * 3;

				case MSFF_32BITRGBA:
	//			case 6:
	//			case 7:
					return wBitsPerChannel * 4;
				}

				return -1;
			}
		};

		typedef HANDLE (__cdecl *MSFFOpen_t)(GrphFile *pFile, LPCSTR szFileName, BOOL bWriteEnabled);
		typedef int (__cdecl *MSFFClose_t)(HANDLE hPicture);
		typedef int (__cdecl *MSFFGetLine_t)(DWORD dwLines, LPVOID pBuffer, DWORD dwSize, HANDLE hPicture);
		typedef int (__cdecl *MSFFControl_t)(DWORD dwFunc, DWORD dwReserved1, DWORD dwReserved2, LPVOID pBuffer, HANDLE hPicture);

		MSFFOpen_t		pMSFFOpen = (MSFFOpen_t)::GetProcAddress(hModule, "MSFFOpen");
		MSFFClose_t		pMSFFClose = (MSFFClose_t)::GetProcAddress(hModule, "MSFFClose");
		MSFFGetLine_t	pMSFFGetLine = (MSFFGetLine_t)::GetProcAddress(hModule, "MSFFGetLine");
		MSFFControl_t	pMSFFControl = (MSFFControl_t)::GetProcAddress(hModule, "MSFFControl");

		if (!pMSFFOpen && !pMSFFGetLine)
		{
			::FreeLibrary(hModule);
			return E_UNEXPECTED;
		}

		GrphFile file = {0};

		USES_CONVERSION;
		HANDLE hPicture = pMSFFOpen(&file, T2CA(szFile), FALSE);

		if (hPicture < 0)
		{
			::FreeLibrary(hModule);
			return E_FAIL;
		}

		ATLASSERT(file.dwClass == 0 || file.dwClass == 2 ||
					file.dwClass == 3 || file.dwClass == 5);

		ATLTRACE("Image class %d\n", file.dwClass);

		if (file.wBitsPerChannel < 8)
			file.wBitsPerChannel = 8;

		LPVOID pBits = NULL;
		BITMAPINFO *pBMInfo = (BITMAPINFO*)alloca(sizeof(BITMAPINFOHEADER) + 256 * sizeof(RGBQUAD));
		pBMInfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		pBMInfo->bmiHeader.biWidth = file.nWidth;
		pBMInfo->bmiHeader.biHeight = -file.nHeight;
		pBMInfo->bmiHeader.biPlanes = 1;
		pBMInfo->bmiHeader.biBitCount = file.GetBPP();
		pBMInfo->bmiHeader.biCompression = BI_RGB;
		pBMInfo->bmiHeader.biSizeImage = 0;
		pBMInfo->bmiHeader.biXPelsPerMeter = 0;
		pBMInfo->bmiHeader.biYPelsPerMeter = 0;
		pBMInfo->bmiHeader.biClrUsed = 256;
		pBMInfo->bmiHeader.biClrImportant = 0;

		BYTE bColorKey = 0xFF;
		pMSFFControl(0x14, 0, 0, &bColorKey, hPicture);

		if (file.IsPal() && pMSFFControl)
		{
			BYTE pPal[256 * 3];
			pMSFFControl(2, 0, 0, pPal, hPicture);

			if (file.IsMono())
			{
					pBMInfo->bmiColors[0].rgbRed = pPal[0];
					pBMInfo->bmiColors[0].rgbGreen = pPal[1];
					pBMInfo->bmiColors[0].rgbBlue = pPal[2];
					pBMInfo->bmiColors[0].rgbReserved = 0;

					pBMInfo->bmiColors[0xFF].rgbRed = pPal[3];
					pBMInfo->bmiColors[0xFF].rgbGreen = pPal[4];
					pBMInfo->bmiColors[0xFF].rgbBlue = pPal[5];
					pBMInfo->bmiColors[0xFF].rgbReserved = 0;
			}
			else
			{
				for(int i = 0; i < 256; i++)
				{
					pBMInfo->bmiColors[i].rgbRed = pPal[i*3 + 0];
					pBMInfo->bmiColors[i].rgbGreen = pPal[i*3 + 1];
					pBMInfo->bmiColors[i].rgbBlue = pPal[i*3 + 2];
					pBMInfo->bmiColors[i].rgbReserved = 0;
				}
			}
		}

		HDC hdcDesktop = ::GetDC(NULL);

		DWORD dwBytes = (file.nWidth + 3) & ~3;
		dwBytes*= file.nHeight * 4;
		pBits = malloc(dwBytes);

		if (!pBits)
		{
			::FreeLibrary(hModule);
			return E_OUTOFMEMORY;
		}

		if ((file.nWidth & 0x03) || file.dwSequence)
		{
			DWORD dwAlighedWidth = (file.GetByteWidth() + 3) >> 2;
			if (0 == file.dwSequence)
			{
				LPDWORD pAligned = LPDWORD(pBits);
				for(int i = 0; i < file.nHeight; i++)
				{
					pMSFFGetLine(1, pAligned, file.GetByteWidth(), hPicture);
					pAligned += dwAlighedWidth;
				}
			}
			else if (1 == file.dwSequence)	// Upside-down BMP
			{
				for(int i = file.nHeight - 1; i >= 0; i--)
				{
					LPDWORD pAligned = LPDWORD(pBits) + dwAlighedWidth * i;
					pMSFFGetLine(1, pAligned, file.GetByteWidth(), hPicture);
				}
			}
			else if (2 == file.dwSequence)	// Interlaced GIF
			{
				const int passcount = 4;
				int starts[passcount] = {0, 4, 2, 1};
				int intervals[passcount] = {8, 8, 4, 2};

				for (unsigned int pass = 0; pass < passcount; ++pass)
				{
					for (unsigned int i = starts [pass]; i < file.nHeight; i += intervals[pass])
					{
						LPDWORD pAligned = LPDWORD(pBits) + dwAlighedWidth * i;
						pMSFFGetLine(1, pAligned, file.GetByteWidth(), hPicture);
					}
				}
			}
			else if (3 == file.dwSequence)	// Interlaced PNG
			{
				const int passcount = 7;
				struct InterlaceInfo
				{
					unsigned int row_interval;
					unsigned int col_interval;
					unsigned int start_row;
					unsigned int start_col;
				} intervals[passcount] =
				{
					{ 8, 8, 0, 0, },
					{ 8, 8, 0, 4, },
					{ 8, 4, 4, 0, },
					{ 4, 4, 0, 2, },
					{ 4, 2, 2, 0, },
					{ 2, 2, 0, 1, },
					{ 2, 1, 1, 0, },
				};

				dwAlighedWidth <<= 2;
				LPBYTE pByteBits = LPBYTE(pBits);

				for (unsigned int pass = 0; pass < passcount; ++pass)
				{
					for (unsigned int i = intervals[pass].start_row;
							i < file.nHeight;
							i += intervals[pass].row_interval)
					{
						PBYTE pBuffer = (PBYTE)alloca(file.nWidth);
						pMSFFGetLine(1, pBuffer, file.GetByteWidth(), hPicture);

						for (unsigned int j = intervals[pass].start_col;
								j < file.nWidth;
								j += intervals[pass].col_interval)
						{
							pByteBits[i * dwAlighedWidth + j] = *pBuffer++;
						}
					}
				}
			}
		}
		else
		{
			pMSFFGetLine(file.nHeight, pBits, file.nWidth * file.nHeight * 4, hPicture);
		}

		if (file.IsBGR())
		{
			for(LPBYTE pSwap = LPBYTE(pBits);
				pSwap < LPBYTE(pBits) + file.GetByteWidth() * file.nHeight;
				pSwap += 3)
			{
				BYTE bTmp = pSwap[2];
				pSwap[2] = pSwap[0];
				pSwap[0] = bTmp;
			}
		}

		
		HBITMAP bmpMem = ::CreateCompatibleBitmap(hdcDesktop, file.nWidth, file.nHeight);
		HDC hdcMem = ::CreateCompatibleDC(hdcDesktop);

		HBITMAP bmpOld = (HBITMAP)::SelectObject(hdcMem, bmpMem);

		::StretchDIBits(hdcMem, 0, 0, file.nWidth, file.nHeight, 
						0, 0, file.nWidth, file.nHeight,
						pBits, pBMInfo, 
						DIB_RGB_COLORS, SRCCOPY);

		::SelectObject(hdcMem, bmpOld);

		m_hBmp = bmpMem;
		
		::FreeLibrary(hModule);

		return S_OK;
	}
};

#endif	__CNVOLD_H__

//@//////////////////////////////////////////////////////////////////////////
//	End Of File CnvOld.h
