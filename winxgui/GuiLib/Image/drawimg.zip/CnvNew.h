//	Project: DrawImg
//	File:    CnvOld.h
//	Author:  Paul Bludov
//	Date:    08/24/2001
//
//	Description:
//		New technique for loading images
//
//	Update History:
//		NONE
//
//@//////////////////////////////////////////////////////////////////////////

#ifndef __CNVNEW_H__
#define __CNVNEW_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//@//////////////////////////////////////////////////////////////////////////
//	CGraphicsConverterNewStyleImage

class ATL_NO_VTABLE CGraphicsConverterNewStyleImage :
	public CChildFrame<CGraphicsConverterNewStyleImage>
{
	struct ImgInfo
	{
		HMETAFILE hObj;
		RECT	rc;
		WORD	wDPI;
	} m_Image;

public:
	CGraphicsConverterNewStyleImage()
	{
		::ZeroMemory(&m_Image, sizeof(ImgInfo));
	}

	static LPCTSTR GetMethodName()
	{
		return _T("Graphics converter new style");
	}

	void Destroy()
	{
		if (m_Image.hObj)
			::DeleteObject(m_Image.hObj);

		::ZeroMemory(&m_Image, sizeof(ImgInfo));
	}

	HRESULT DrawImg(HDC hdc, const RECT& rcBounds)
	{
		if (m_Image.hObj)
		{
			::SetMapMode(hdc, MM_ANISOTROPIC);
			::SetViewportExtEx(hdc,
				rcBounds.right - rcBounds.left,
				rcBounds.bottom - rcBounds.top,
				NULL);
			::PlayMetaFile(hdc, m_Image.hObj);
			
			return S_OK;
		}

		return E_UNEXPECTED;
	}

	HRESULT Load(LPCTSTR szFile)
	{
		HMODULE hModule = g_pMapExtToFilter->LoadFilter(szFile);

		if (NULL == hModule)
			return E_FAIL;

		struct NameStruct
		{
			DWORD	dwHead[2];
			char	szName[MAX_PATH];
			DWORD	dwTail[2];
		};

		typedef DWORD (__stdcall *GetFilterInfo_t)(DWORD dwVersion, DWORD dwReserved, HGLOBAL *phFilterData, DWORD dwReserved2);
		typedef DWORD (__stdcall *SetFilterPref_t)(HGLOBAL hFilterData, LPCSTR szOption, LPCSTR szValue, DWORD dwReserved2, DWORD dwReserved1);
		typedef DWORD (__stdcall *ImportGr_t)(DWORD dwReserved, NameStruct *pFile, ImgInfo *pInfo, HGLOBAL hFilterData);

		GetFilterInfo_t pGetFilterInfo = (GetFilterInfo_t)::GetProcAddress(hModule, "GetFilterInfo");
		SetFilterPref_t pSetFilterPref = (SetFilterPref_t)::GetProcAddress(hModule, "SetFilterPref");

		ImportGr_t pImportGr = (ImportGr_t)::GetProcAddress(hModule, "ImportGr");
		if (NULL == pImportGr)
			pImportGr = (ImportGr_t)::GetProcAddress(hModule, "ImportGR");

		if (pImportGr)
		{
			NameStruct name = {0};
			HGLOBAL hFilterData = NULL;

			if (pGetFilterInfo)
			{
				DWORD dwVer = pGetFilterInfo(2, 0, &hFilterData, 0x00170000);
				ATLASSERT(2 == dwVer);

				if (2 != dwVer)
				{
					::FreeLibrary(hModule);
					return E_UNEXPECTED;
				}
			}

			//	PB 01/26/2001 Turn off dialogs
			if (pSetFilterPref)
			{
				pSetFilterPref(hFilterData, "ShowProgressDialog", "No", 2, 1);
				pSetFilterPref(hFilterData, "ShowOptionsDialog", "No", 2, 1);
			}

			USES_CONVERSION;
			::lstrcpynA(name.szName, T2CA(szFile), MAX_PATH);

			DWORD dwRet = pImportGr(0, &name, &m_Image, hFilterData);
			
			if (hFilterData)
				::GlobalFree(hFilterData);

			if (0 != dwRet || NULL == m_Image.hObj)
			{
				::FreeLibrary(hModule);
				return E_FAIL;
			}

			if (OBJ_METAFILE != ::GetObjectType(m_Image.hObj))
			{
				HGLOBAL hObj = (HGLOBAL)m_Image.hObj;
				LPBYTE pObj = (LPBYTE)::GlobalLock(hObj);

				m_Image.hObj = ::SetMetaFileBitsEx(::GlobalSize(hObj), pObj);

				::GlobalUnlock(hObj);
				::GlobalFree(hObj);
			}

			if (NULL == m_Image.hObj)
			{
				::FreeLibrary(hModule);
				return E_FAIL;
			}

			return S_OK;
		}
		
		::FreeLibrary(hModule);
		return E_UNEXPECTED;
	}
};

#endif	__CNVNEW_H__

//@//////////////////////////////////////////////////////////////////////////
//	End Of File CnvNew.h
