

var gBVType='firefox',gBVVersion='20',gOSType='windows nt 5';

/* This source code is Copyright (c) Vibrant Media 2001-2008 and forms part of the
patented Vibrant Media product "IntelliTXT" (sm). */
function cpl(s){
var p=s.indexOf(' '),c=1;
while(p>=0){
p=s.indexOf(' ',p+1);
c++;}
return c;
}

function iG(){
gHN=new Array();
gAN=new Array();

gSN=new Array('<b>','<h1>','<h2>','<h3>','<h4>','<h5>','<strong>','<em>','<i>','cpp-keyword','cpp-literal','cpp-comment','!ForumTable','smalltext','!no-vmads');
gUPN=new Array('<b>','<i>','<u>');
gBPN=new Array();
}

function kwM(){
var ad=fABDID(aAD,gDI);
if(null==ad)return;
window.status=ad.t.replace(/\&pound\;/, '?');
}
var gCLM=1,
gK=new Array(),
gKE=new Array(),
gKL=new Array(),
gOHk=new Array();
gITXTNIdx=0;
for(var i=0;i<gK.length;i++)gKL[i]=cpl(gK[i]);
function pKWL(){
itxtprep();
hIT(aAD,aKW,gSI);
}

document.gEsBCN=function(cl){
var retnode=[],myclass=new RegExp('\\b'+cl+'\\b'),elem=this.getElementsByTagName('*');
for(var i=0;i<elem.length;i++){if(myclass.test(elem[i].className)) retnode.push(elem[i]);}
return retnode;
};
function doIt(){

ipartid=1369;
ibid=2745;
ipid=5102;
t_s='20080226023126';
mk=3;
server='codeproject.us.intellitxt.com';
cc='us';
rcc='cn';
itxtreg='--';
itxtdma='0';
ulS='font-weight:normal;font-size:100%;text-decoration:underline;border-bottom:darkgreen 0.075em solid;padding-bottom: 1px;color:darkgreen;background-color:transparent;;padding-bottom:1px';
hS='font-weight:normal;font-size:100%;text-decoration:underline;border-bottom:darkgreen 0.2em solid;padding-bottom: 1px;color:darkgreen;background-color:transparent;;padding-bottom:1px';
iEulS='';
iEhS='';
sWTU='http://www.codeproject.com/info/intelliTXT.asp';
sIEWTU='';
iCF=0;
gDBL=0;
kwpn=1.0;
kwpp=-1.0;
kwp=0;
gSkp=0;
ppp=false;
gTI='';
gEATI=0;
gATIr='http://images.intellitxt.com/ast/adTypes/';
gATIs='height:10px;width:10px;position:relative;top:1px;left:1px;padding:0;margin:0;float:none;border:0;';
gCTS=0;
gIAA=0;

gODT='';
gHkCap=1;
gATIg= new parr('');gATIg.set(0,'3.gif');
gFTTm= new parr('');gFTTm.set(17,'preloader.swf$$320$$200$$8');gFTTm.set(34,'preloader.swf$$320$$200$$8');gFTTm.set(32,'preloader.swf$$320$$200$$8');gFTTm.set(48,'preloader.swf$$300$$250$$8');gFTTm.set(54,'preloader.swf$$320$$250$$8');gFTTm.set(53,'preloader.swf$$320$$250$$8');gFTTm.set(52,'preloader.swf$$320$$250$$8');gFTTm.set(25,'preloader.swf$$320$$200$$8');gFTTm.set(58,'preloader.swf$$320$$230$$8');gFTTm.set(46,'preloader.swf$$320$$200$$8');gFTTm.set(63,'preloader.swf$$320$$200$$8');gFTTm.set(60,'preloader.swf$$320$$230$$8');

gFTTr='http://images.intellitxt.com/ast/allflash_adunit/prod/';
gFOJBG='#FFFFFF';

gTrkImg=null;

gFFMF='0';
gSVURL='';
gSVIMG='';
gFdBck='';
gSI=1;
gSID='584ea3a83c6d6fd73bf0676e8fd56f76';
gMiFo=0;
mTL=50;
gDrag=1;
gMSNsb=-1;
gMSNlg=0;
gOFlt=0;
gIRB=0;
gTTt=1500;
gDASB=3;
gAUAT=0;
gHLN=1;
gKWPF=0;
gPVU='535C2AD154EA4151ADBBF8610CF298D9';
gPVM='72565cb8969f3044f2cf1598f05d65da';
gMImgW=180;
gMImgH=200;
gENC='utf-8';
iTTC=0;
gCSc='';

gLCL=19237;
var tTXT='',aIEE,dDate='';

if(tTXT.length==0)tTXT=document.title;

if('v1'==gCM)mTL=0;
ndbST=new Date().getTime();
iDW();
if(gCM=='v1')
gITXTN=gIA2();
else
gITXTN=gIA(gdB, gCM, 0);
// process image ALT tags and use the text already found if required
if(gIMGo)
{

var aIMT=new Array();

// process the image ALT tags, the areas of interest, and the current text node
gITXTN=gIAT(180,200,aIMT,tTXT,gITXTN,10);
}
else
skippinder();
var bCF=0;

var aCs=new Array();
if(gIMGo)
gCntIAT(aCs);
else
gCntIP(aCs);

var dtc=0;

if(dtc)dbM('<font color=red>Document title has changed - need to refresh</font>',1);
if((dtc)||((false && ((bCF==1 && gCL) || (gIRB==1 && bCF==0 && gCL>=(gLCL * 1.1)) || (gDTo==false && gIRB==1 && bCF==0 && Math.abs(gCL-gLCL)>=(gLCL * 10) / 100))))) {
gINt=' zxz ';
for(var i=0;i<aCs.length;i++)
    gINt+=aCs[i];

var p=new Object();
p.ipid=ipid;
p.sid=gSID;
p.nbc=iNBc;
p.enc=gENC;
p.tx=gINt;
p.pagecl=92159;
p.cc=cc;
p.rcc=rcc;
p.reg=itxtreg;
p.dma=itxtdma;
p.dfr=false;
p.fdt=0;
p.ign86=false;
p.cf=iCF;
p.mk=mk;
p.kwpn=kwpn;
p.ppp=ppp;
p.kwpp=kwpp;
p.kwp=kwp;
p.si=gSI;
p.dfc=iDFC;
p.rp=bYCR;
p.so=iSo;
p.adi=iADi;
p.irb=gIRB;
p.ims=2;
p.iek=0;
p.iel=2;
p.ieak=0;
p.ieix=true;
p.iedm=0;
p.ttxt=encodeURIComponent(tTXT.replace(/\n/,' '));
while (p.ttxt.indexOf('\'')>-1) p.ttxt=p.ttxt.replace('\'', '%27');
p.auat=0;
p.lpgv=1;
p.ddate=dDate;
p.pvu=gPVU;
p.pvm=gPVM;
p.ias=itxtIas;

p.ru=encodeURIComponent(sRU);
cAs(server,p);
} else if (gCL)

 {

if((gITXTN==null)||(gITXTN!=null && gITXTN.length==0))
{
if(gIMGo)
gITXTN=gIAT(gMImgW,gMImgH);
else
gITXTN=gIA(gdB,gCM,0);
}
if(gITXTN!=null && gITXTN.length)
if(gCL>0) rKWL(250);

}
}
var ndbST,
iRCLM=1,
iDFC=0,
iTTl=1,
iTTp=0,
iSo=0,
iNBc=0,
iADi=0,
sRU='http://www.codeproject.com/KB/cpp/FastDelegate.aspx',
gMR=1000,
bWAC=0,
bYCR=0,
gMNC=255,
gTTD=50,
iIEK=0,
iIEL=2,
iIENW=0,
sIETS='font-size:12px;font-weight:bold;font-family:Verdana,Arial,Helvetica;color:#000000;text-decoration:none;',
sIEFH='',
sIESBC='',
sIETBC='',
iIEFHT=0,
ieslu='',
iessu='',
iesbu='',
iesfid='',
iesfin='',
iesfig='',
iett='The Code Project',
iDAH=0,
gFES=0,
gSDCv=0,
gFAo=1,
gPmoe=0,
gIMGo=false,
gIMGiC=true,
gIMGuA=false,
gIMGuAOI=false,
gIMGsI=true,
gIMGdmf=function(s){return s;},
gDr1AT='',
gDr1lu='Click to show Site Results',
gDr1lc='Click to hide Site Results',
gDr1lg='3b.gif',
gDr2AT='',
gDr2lu='Click to show Web Search',
gDr2lc='Click to hide Web Search',
gDr2lg='2b.gif',
gImgMP=10,
gDrFP='http://images.intellitxt.com/ast/js/vm/drawers_200802131210.js', // WB401: need drawers fun path in itxtprep to call out drawers on per-channel or per-campaign
gTlpC=new Object();
gTlpC.tttc='#000099';gTlpC.ttht='#0000DE';
gTlpC.ttdc='#000000';gTlpC.tthdc='#000000';
gTlpC.ttac='#008000';gTlpC.ttha='#008000';
gTlpC.ttbg='#F0F0F0';gTlpC.tthv='#FFFFFF';
var sspl='Advertisement',
swti='What\'s this?',
slm='LEARN MORE',
ssch='Searching...',
sbn='Buy now',
scls='Close',
sCC='$',
sEet='End time',
sEcb='Place bid',
sEsn='Seller',
iert='Related Articles';
var gNeedProtos=1;

var itxtInited=0;
function startIntelliTXT() {

if (itxtInited) return;

itxtInited=1;
itxtLES('http://images.intellitxt.com/ast/js/vm/func_200802131210.js');
}
startIntelliTXT();

