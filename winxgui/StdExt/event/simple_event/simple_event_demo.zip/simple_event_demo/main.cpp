#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#endif

#include <cstdlib>

#ifdef _MSC_VER
#include <crtdbg.h>
#endif

#include <iostream>
#include <string>
#include "Event.hpp"

#ifdef _MSC_VER

#define DEBUG_NEW new(_NORMAL_BLOCK, THIS_FILE, __LINE__)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#endif


using namespace std;


class Edit {
	string s_;
public:
	// define event type 'TextChanged'
	EVENT_TYPE(TextChanged, (string s), (s));

	TextChanged changed;

	void set(string s)
	{
		s_ = s;

		// fire 'changed' event when the content of Edit is altered
		changed.fire(s_);
	}
};

class Dialog {
	Edit edit_;
public:
	void OnEditChanged(string s)
	{
		cout << "text in edit is : " << s << endl;
	}

	Dialog()
	{
		//edit_.changed.addListener(this, OnEditChanged);	// vc7.1
		edit_.changed.addListener(this, &Dialog::OnEditChanged);
	}

	void input(string s)
	{
		edit_.set(s);
	}

};


void example1()
{
	Dialog dlg;
	dlg.input("some text");
	dlg.input("another text");
}

//-----------------------------------
/*
class AbstractSomeEventHandler : public AbstractEventHandlerBase {
public:
	virtual void execute (int x, int y) = 0;
};

template <class Target, class MF> class SomeEventHandler : public EventHandler<Target, MF, AbstractSomeEventHandler> {
	typedef EventHandler<Target, MF, AbstractSomeEventHandler> Base;
public:
	SomeEventHandler(Target* target, MF mf) : Base(target, mf)
	{
	}
	void execute (int x, int y) {
		(Base::target_->*Base::mf_) (x, y); }
};

template <class Functor> class SomeEventFunctorHandler : public EventFunctorHandler<Functor, AbstractSomeEventHandler> {
	typedef EventFunctorHandler<Functor, AbstractSomeEventHandler> Base;
public:
	SomeEventFunctorHandler(Functor& f) : Base(f)
	{
	}
	void execute (int x, int y) {
		Base::f_ (x, y);
	} 
};

class SomeEvent : public Event<AbstractSomeEventHandler, SomeEventHandler, SomeEventFunctorHandler> {
public:
	void fire (int x, int y)
	{
		for (Handlers::iterator i = handlers_.begin(); i != handlers_.end(); ++i)
			(*i)->execute (x, y);
	}
};;
*/
//------------------------------------
EVENT_TYPE(SomeEvent, (int x, int y), (x, y));
SomeEvent event1;

// function object
class Foo {
public:
	void operator()(int a, int b)
	{
		cout << "function object: " << a << '+' << b << '=' << a + b << endl;
	}
};

// ordinary function
void bar(int a, int b)
{
	cout << "function: " << a << '+' << b << '=' << a + b << endl;
}

void example2()
{
	Foo foo1;
	// connect to a function object
	SomeEvent::Connection c1(event1.addListener(foo1));

	SomeEvent::Connection c2;
	// connect to an ordinary function
	c2 = event1.addListener(bar);

	//SomeEvent::Connection c3(c1);	// error: copy construction is not permitted

	//c1 = c2;	// error: assignment is not permitted

	event1.fire(1, 2);

	{
		Foo foo2;
		SomeEvent::Connection c4(event1.addListener(foo2));

		// create an anonymous connection
		event1.addListener(bar);

		event1.fire(3, 4);

		// c4 break up automaticly
	}

	c1.disconnect();
	event1.fire(5, 6);

}

// connection's lifetime longer than event, no problem!
void example3()
{
	SomeEvent::Connection c;

	{
		SomeEvent event2;
		c = event2.addListener(bar);
		event2.fire(9, 9);
	}
	// you can invoke c.disconnect() explicitly or
	// rely on c's destructor to do it
}

int main()
{
#ifdef _MSC_VER
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
	
	example1();
	example2();
	example3();

	system("PAUSE");	
}
