/* -------------------------------------------------------------------------
//	�ļ���		��	draw_nodeid.h
//	������		��	SongErwei
//	����ʱ��	��	2006-9-21 17:23:43
//	��������	��	
//
// -----------------------------------------------------------------------*/

//enum RFNodeID
//{
//	NID_draw_XML_begin,
	
	NID_draw_cSld,
	NID_draw_spTree,
	
	NID_draw_nvGrpSpPr,
	NID_draw_cNvGrpSpPr ,
	NID_draw_nvPr,
	NID_draw_grpSpPr,

	NID_draw_sp,
	NID_draw_nvSpPr,
	NID_draw_cNvPr ,
	NID_draw_cNvSpPr,
	NID_draw_spPr,
	NID_draw_xfrm,
	NID_draw_off,
	NID_draw_ext,
	NID_draw_prstGeom ,
	NID_draw_avLst,
	
	NID_draw_solidFill,
	NID_draw_gradFill,
	NID_draw_pattFill,

	NID_draw_sysClr,
	NID_draw_srgbClr,
	NID_draw_schemeClr,

	NID_draw_fgClr,
	NID_draw_bgClr,

//	NID_draw_XML_end
//};