/* -------------------------------------------------------------------------
//	�ļ���		��	xmltypes.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-16 9:59:01
//	��������	��	
//
//	$Id: xmltypes.h,v 1.2 2005/02/06 02:51:17 xushiwei Exp $
//-----------------------------------------------------------------------*/
#ifndef __IO_XMLTYPES_H__
#define __IO_XMLTYPES_H__

#if !defined(XMLPARSER_BACKWARD_COMPAT)
#error "���ļ��Ѿ���ʱ!"
#endif

// -------------------------------------------------------------------------

#if !defined(xmlchar_t)
#define xmlchar_t

typedef char	xmlchar;
typedef int		xmlint;

#endif // xmlchar_t

// -------------------------------------------------------------------------

#ifndef	__xmlentity_template
#define __xmlentity_template	// template <class xmlchar, class xmlint>
#endif

#if !defined(xml_entity_t)
#define xml_entity_t			__xml_entity_t	// <xmlchar, xmlint>

__xmlentity_template
struct __xml_entity_t
{
	const xmlchar* entity;
	xmlint ch_entity;
};

#endif // xml_entity_t

// -------------------------------------------------------------------------
// $Log: xmltypes.h,v $
// Revision 1.2  2005/02/06 02:51:17  xushiwei
// ���ļ��Ѿ���ʱ! ��ʹ��<kso/io/xml/parser.h>
//

#endif /* __XMLTYPES_H__ */
