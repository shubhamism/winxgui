// -------------------------------------------------------------------------
//	�ļ���		��	xmlparser.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-9 23:10:53
//	��������	��	
//
//	$Id: xmlparser.h,v 1.2 2005/02/06 02:51:17 xushiwei Exp $
// -------------------------------------------------------------------------
#ifndef __IO_XMLPARSER_H__
#define __IO_XMLPARSER_H__

#if (0)
#define XMLPARSER_BACKWARD_COMPAT
#endif

#if !defined(XMLPARSER_BACKWARD_COMPAT)
#error "���ļ��Ѿ���ʱ! ��ʹ��<kso/io/xml/parser.h>"
#endif

#ifndef __IO_XMLTYPES_H__
#include "xmltypes.h"
#endif

/* -------------------------------------------------------------------------
 һ��XML��������
	1��Prolog (XML����, ����ָ��, DTD)
		1) XML����������ָ��
			<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
			<?xml-stylesheet type="" href=""?>
		2) DTD
			<!DOCTYPE root-tag[
			<!ELEMENT tag tag-desc>
			<
			]>
	2��ע��
		<!--comment-->
	3�����ֿռ�
	4����� <tag> ... </tag>
	   ��Ԫ�� <empty-tag/>
 ������������������ĺϷ���:
	��ĸ, ����(������ͷһ��), �»���(_), ����(-), ���(.), ð��(:)

 ����ʵ������
	&lt;	<		&gt;	>
	&apos;	'		&quot;	"
	&amp;	&
// -----------------------------------------------------------------------*/

#define __xmlparser_template

#ifndef __xmlparser_template
#define __xmlparser_template												\
	template<class xmlchar, class xmlint, class xmlsource, class xmlhandler, class xmlstring>
#endif

#ifndef __xmlparser_template_inline
#define __xmlparser_template_inline	__xmlparser_template inline
#endif

#define __xmlsym_max			128
#define __xmlval_max			1024
#define __xmleof				(-1)

#define xmlIsContent(prop)		(*(prop) == 0)

// -------------------------------------------------------------------------
// interface xmlhandler:

#if !defined(xmlhandler_t)
#define xmlhandler_t	__xmlhandler_t

struct __xmlhandler_t
{
	// -------> ע: ����ֻҪ����S_OK�����쳣, ��xmlparser_bugfix.txt, ��6)����
	virtual STDMETHODIMP StartTag(const xmlchar* tag) = 0;
	virtual STDMETHODIMP AddProp(const xmlchar* prop, const xmlchar* val) = 0;
	virtual STDMETHODIMP EndTag(const xmlchar* tag) = 0;
};

#define _xmlStartTag(tag, handler)			(handler)->StartTag(tag)
#define _xmlAddProp(prop, val, handler)		(handler)->AddProp(prop, val)
#define _xmlEndTag(tag, handler)			(handler)->EndTag(tag)

#endif // interface xmlhandler

typedef	xmlhandler_t* xmlhandler;

// -------------------------------------------------------------------------
// interface xmlsource:

#if !defined(xmlsource_t)
#define xmlsource_t		struct __xmlsource_t

struct __xmlsource_t
{
	FILE* fp;
	xmlint chPeek;
	const xml_entity_t* pentities;
	unsigned nentities;
};

__xmlparser_template_inline
STDMETHODIMP_(void) xmlSourceInit(
	xmlsource_t* src,
	FILE* fp,
	const xml_entity_t* pentities,
	unsigned nentities
	)
{
	src->fp	= fp;
	src->chPeek = __xmleof;
	src->pentities  = pentities;
	src->nentities  = nentities;	
}

__xmlparser_template
STDMETHODIMP_(xmlint) xmlGetChar(xmlsource_t* src)
{
	xmlint chPeek;
	if (src->chPeek == __xmleof)
	{
		return fgetc(src->fp);
	}
	else
	{
		chPeek = src->chPeek;
		src->chPeek = __xmleof;
		return chPeek;
	}
}

__xmlparser_template
STDMETHODIMP_(xmlint) xmlPeekChar(xmlsource_t* src)
{
	if (src->chPeek == __xmleof)
	{
		src->chPeek = fgetc(src->fp);
	}
	return src->chPeek;
}

#endif	// interface xmlsource

typedef	xmlsource_t*	xmlsource;

// -------------------------------------------------------------------------
// internal interface xmlstring:

#if !defined(xmlstring_t) && defined(Uses_XmlFixString)
#define xmlstring_t		struct __xmlstring_t

struct __xmlstring_t
{
	xmlchar str[__xmlval_max];
	int cch;
};

__xmlparser_template_inline
STDMETHODIMP_(void) xmlStringInit(xmlstring_t* pval)
{
	pval->cch = 0;
}

__xmlparser_template_inline
STDMETHODIMP_(void) xmlStringAdd(xmlstring_t* pval, xmlchar ch)
{
	if (pval->cch < __xmlval_max-2)
	{
		pval->str[pval->cch++] = ch;
	}
}

__xmlparser_template_inline
STDMETHODIMP_(const xmlchar*) xmlStringPtr(xmlstring_t* pval)
{
	pval->str[pval->cch] = 0;
	return pval->str;
}

#endif	// interface xmlstring

typedef	xmlstring_t		xmlstring;

// -------------------------------------------------------------------------

__xmlparser_template
STDMETHODIMP xmlLookupChar(xmlsource src, xmlint ch_lookup)
{
	xmlint ch;
	while ((ch = xmlGetChar(src)) != ch_lookup)
	{
		if (ch == __xmleof)
			return S_FALSE;
	}
	return S_OK;
}

__xmlparser_template_inline
STDMETHODIMP_(int) xmlIsWhite(xmlint ch)
{
	switch (ch)
	{
	case ' ':	case '\t':	case '\r':	case '\n':	return TRUE;
	default:	return FALSE;
	}
}

__xmlparser_template
STDMETHODIMP_(void) xmlSkipWhites(xmlsource src)
{
	xmlint ch;

lzLoop:
	ch = xmlPeekChar(src);
	if (xmlIsWhite(ch))
	{
		xmlGetChar(src);
		goto lzLoop;
	}
}

__xmlparser_template
STDMETHODIMP xmlParseSymbol(xmlchar* sym, xmlsource src)
{
	int i, icnt = 0;
	xmlint ch;
	static const xmlint g_sym_chars[] =
	{
		'a', 'b', 'c', 'd', 'e', 'f', 'g',
		'h', 'i', 'j', 'k', 'l', 'm', 'n',
		'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
		'A', 'B', 'C', 'D', 'E', 'F', 'G',
		'H', 'I', 'J', 'K', 'L', 'M', 'N',
		'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
		'-', '_', ':', '.',
		'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'
	};
	xmlSkipWhites(src);
	
	// 1) get first char, can't be '0' - '9':
	ch = xmlPeekChar(src);
	for (i = 0; i < countof(g_sym_chars) - 10; ++i)
	{
		if (g_sym_chars[i] == ch)
		{
			xmlGetChar(src);
			goto lzStep2;
		}
	}
	return E_XML_INVALID_SYMBOL;

lzStep2:
	// 2) get others
	if (icnt < __xmlsym_max-2)
	{
		sym[icnt++] = (xmlchar)ch;
	}
	for (;;)
	{
		ch = xmlPeekChar(src);
		for (i = 0; i < countof(g_sym_chars); ++i)
		{
			if (g_sym_chars[i] == ch)
			{
				xmlGetChar(src);
				goto lzStep2;
			}
		}
		sym[icnt] = 0;
		return S_OK;
	}
}

__xmlparser_template_inline
STDMETHODIMP_(int) xmlStrCmp(const xmlchar* src, const xmlchar* dst)
{
	int ret = 0 ;
	
	while( ! (ret = (int)(*src - *dst)) && *dst)
		++src, ++dst;
	
	return ret;
}

// &#119;
__xmlparser_template_inline
STDMETHODIMP xmlParseEntityDec(xmlsource src, xmlint* pentity)
{
	xmlint ch, val = 0;
	
lzLoop:
	ch = xmlGetChar(src);
	if (ch >= '0' && ch <= '9')
	{
		val += val*10 + ch - '0';
		goto lzLoop;
	}
	ASSERT_ONCE(ch == ';');

	*pentity = val;
	return (ch == ';' ? S_OK : E_XML_INVALID_ENTITY);
}

// &#x0d;
__xmlparser_template_inline
STDMETHODIMP xmlParseEntityHex(xmlsource src, xmlint* pentity)
{
	static const xmlchar g_hex_chars[] =
	{
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
		'a', 'A', 'b', 'B', 'c', 'C', 'd', 'D', 'e', 'E', 'f', 'F',
	};
	int i;
	xmlint ch, hex = 0;
	
lzLoop:
	ch = xmlGetChar(src);
	for (i = 0; i < countof(g_hex_chars); ++i)
	{
		if (g_hex_chars[i] == ch)
		{
			hex = hex * 0x10 + (i < 10 ? i : ((i - 10) >> 1) + 10);
			goto lzLoop;
		}
	}
	ASSERT_ONCE(ch == ';');

	*pentity = hex;
	return (ch == ';' ? S_OK : E_XML_INVALID_ENTITY);
}

// &xxx;
__xmlparser_template	// &
STDMETHODIMP xmlParseEntity(xmlsource src, xmlint* pch_entity)
{
	int i;
	HRESULT hr;
	xmlchar entity[__xmlsym_max];
	const xml_entity_t* pentities;

	if (xmlPeekChar(src) == '#')
	{
		xmlGetChar(src);
		switch (xmlPeekChar(src))
		{
		case 'x':	case 'X':	// hex
			xmlGetChar(src);
			return xmlParseEntityHex(src, pch_entity);
			
		default:				// dec
			return xmlParseEntityDec(src, pch_entity);
		}
	}

	hr = xmlParseSymbol(entity, src);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(xmlGetChar(src) == ';', hr = E_XML_INVALID_ENTITY);

	pentities = src->pentities;
	for (i = src->nentities; i--;)
	{
		if (xmlStrCmp(pentities[i].entity, entity) == 0)
		{
			*pch_entity = pentities[i].ch_entity;
			return S_OK;
		}
	}
	return E_XML_UNKNOWN_ENTITY;

lzExit:
	return hr;
}

__xmlparser_template
STDMETHODIMP xmlParseValue(xmlstring* pval, xmlsource src, int fContent)
{
	HRESULT hr = S_OK;
	xmlint ch, val_end_chars[] = { '\"', '>', '<', __xmleof, };
	int i;
	
	xmlStringInit(pval);
	xmlSkipWhites(src);
	
	switch (xmlPeekChar(src))
	{
	case '\'':
		val_end_chars[0] = '\'';
	case '\"':
		xmlGetChar(src);
		break;
	case __xmleof:
		return E_XML_EOF;
	default:
		if (!fContent)
			val_end_chars[0] = ' ';
	}
	for (;;)
	{
		ch = xmlPeekChar(src);
		if (ch == '&')		// ʵ������(Entity)
		{
			xmlGetChar(src);
			hr = xmlParseEntity(src, &ch); ASSERT_ONCE(hr == S_OK);
			if (hr != S_OK)	// ����ʶ��Entity!
				ch = ' ';
		}
		else
		{
			for (i = 0; i < countof(val_end_chars); ++i)
			{
				if (val_end_chars[i] == ch)
				{
					if (i == 0) xmlGetChar(src);
					return S_OK;
				}
			}
			xmlGetChar(src);
			if (val_end_chars[0] == ' ' && xmlIsWhite(ch))
				return S_OK;
		}
		xmlStringAdd(pval, (xmlchar)ch);
	}
}

// -------------------------------------------------------------------------

// <?xml prop1=val1 prop2=val2 ...?>
__xmlparser_template	// <?
STDMETHODIMP xmlParseDeclare(xmlsource src, xmlhandler handler)
{
	xmlLookupChar(src, '>');
	return S_OK;
}

// <!DOCTYPE root-tag [
// <!ELEMENT tag tagdesc>
// ...
// ]>
__xmlparser_template	// <!
STDMETHODIMP xmlParseDTD(xmlsource src, xmlhandler handler)
{
	xmlint ch;
	int count = 1;
	for (;;)
	{
		ch = xmlGetChar(src);
		switch (ch)
		{
		case '>':
			if (--count <= 0)
				return S_OK;
			break;

		case '<':
			++count;
			break;

		case __xmleof:
			return E_XML_EOF;
		}
	}
}

// <!--comment-->
__xmlparser_template	// <!--
STDMETHODIMP xmlParseComment(xmlsource src, xmlhandler handler)
{
	xmlint ch;
	while ((ch = xmlGetChar(src)) != __xmleof)
	{
		if (ch == '-')
		{
			if (xmlGetChar(src) == '-')
			{
				xmlLookupChar(src, '>');
				break;
			}
		}
	}
	return S_OK;
}

// -------------------------------------------------------------------------

__xmlparser_template
STDMETHODIMP xmlParse(xmlsource src, xmlhandler handler)
{
	HRESULT hr;
	xmlchar sym[__xmlsym_max];
	xmlchar sym_prop[__xmlsym_max];
	xmlstring val;
	xmlint ch;

	xmlSkipWhites(src);
	switch (xmlPeekChar(src))
	{
	case '<':		break;
	case __xmleof:	return S_OK;
	default:
		REPORT_ONCE("No Start Tag\n");
		return E_XML_NO_STARTTAG;
	}
	
lzLoop:
	xmlSkipWhites(src);
	switch (xmlPeekChar(src))
	{
	case '<':
		xmlGetChar(src);
		switch (xmlPeekChar(src))
		{
		case '?':
			xmlGetChar(src);
			hr = xmlParseDeclare(src, handler);
			KS_CHECK(hr);
			break;

		case '!':
			xmlGetChar(src);
			switch (xmlPeekChar(src))
			{
			case '-':
				xmlGetChar(src);
				xmlGetChar(src);
				hr = xmlParseComment(src, handler);
				KS_CHECK(hr);
				break;

			default:
				hr = xmlParseDTD(src, handler);
				KS_CHECK(hr);
			}
			break;

		case '/':
			xmlGetChar(src);
			hr = xmlParseSymbol(sym, src);
			KS_CHECK(hr);
			KS_CHECK_BOOLEX(xmlGetChar(src) == '>', hr = E_XML_NEEDSYM_GT);
			_xmlEndTag(sym, handler);
			break;
			
		default:
			hr = xmlParseSymbol(sym, src);
			KS_CHECK(hr);
			hr = _xmlStartTag(sym, handler);
			KS_CHECK_BOOL(hr == S_OK);
			// -------> ע: ����ֻҪ����S_OK�����쳣, ��xmlparser_bugfix.txt, ��6)����
			for (;;) // -----------------> Parse 'prop = val'
			{
				// 1) Parse 'prop'
				hr = xmlParseSymbol(sym_prop, src);
				if (hr != S_OK)
				{
					xmlSkipWhites(src);
					switch (xmlGetChar(src))
					{
					case '>':
						goto lzLoop;
					case '/':
						KS_CHECK_BOOLEX(xmlGetChar(src) == '>', hr = E_XML_NEEDSYM_GT);
						_xmlEndTag(sym, handler);
						goto lzLoop;
					default:
						REPORT("invalid prop symbol!");
						return hr;
					}
				}
				
				// 2) Parse '=', �˴��Ķ��μ� xmlparser_bugfix.txt, ��5)����
				switch (ch = xmlPeekChar(src))
				{
				case ' ':	case '\t':	case '\r':	case '\n':
					xmlSkipWhites(src);
					ch = xmlPeekChar(src);
					if (ch == '=') break;

				case '>':
					xmlStringInit(&val);
					goto lzParsedPropWithoutVal;

				default:
					KS_CHECK_BOOLEX(ch == '=', hr = E_XML_NEEDSYM_EQUAL);
				}
				xmlGetChar(src);	// must be '='

				// 3) Parse 'val'
				hr = xmlParseValue(&val, src, FALSE);
				KS_CHECK(hr);
				
lzParsedPropWithoutVal:
				_xmlAddProp(sym_prop, xmlStringPtr(&val), handler);
			}
		}
		break;

	case __xmleof:
		return S_OK;

	default:	{
		hr = xmlParseValue(&val, src, TRUE);
		KS_CHECK(hr);

		xmlchar content[] = { 0, 0 };
		_xmlAddProp(content, xmlStringPtr(&val), handler);
	}			}
	goto lzLoop;

lzExit:
	return hr;
}

// -------------------------------------------------------------------------
// $Log: xmlparser.h,v $
// Revision 1.2  2005/02/06 02:51:17  xushiwei
// ���ļ��Ѿ���ʱ! ��ʹ��<kso/io/xml/parser.h>
//

#endif // __IO_XMLPARSER_H__
