/* -------------------------------------------------------------------------
//	�ļ���		��	io/helpers.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-8 9:59:31
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __IO_HELPERS_H__
#define __IO_HELPERS_H__

#include "io/error.h"
#include "io/ks_xmlstd.h"
#include "atom.h"

#if !defined(_MSC_VER)
#define __Linked_IOHelper
#endif

#if !defined(__Linked_IOHelper)
#define __Linked_IOHelper

#ifdef UNICODE

#else // !defined(UNICODE)
#	ifdef _MT
#		ifdef _DLL			// MT DLL
#			ifdef _DEBUG
#				define _LIBNAME	"IOHelperDLLMTD"
#			else
#				define _LIBNAME	"IOHelperDLLMT"
#			endif
#		else				// MT
#			ifdef _DEBUG
#				define _LIBNAME	"IOHelperMTD"
#			else
#				define _LIBNAME	"IOHelperMT"
#			endif
#		endif
#	else // !defined(_MT)	// ST
#		ifdef _DEBUG
#			define _LIBNAME		"IOHelperSTD"
#		else
#			define _LIBNAME		"IOHelperST"
#		endif
#	endif
#endif

//#pragma message("\t�����Զ�����ģ�� - " _LIBNAME)
#pragma comment(lib, _LIBNAME)
#undef	_LIBNAME

#endif // __Linked_IOHelper

#endif /* __IO_HELPERS_H__ */
