/* -------------------------------------------------------------------------
//	�ļ���		��	xmlwriter.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-16 10:14:46
//	��������	��	
//
//-----------------------------------------------------------------------*/

#ifndef __IO_XMLWRITER_H__
#include "../xmlwriter.h"
#endif

// -------------------------------------------------------------------------

#if defined(___uses_xmldest_t)

__xmldest_template
STDMETHODIMP xmlWriteString(xmldest_t* dst, const xmlchar* str, int cnt = -1)
{
	if (cnt < 0)
	{
		cnt = strlen(str);
	}
	fwrite(str, cnt, 1, dst->fp);
	return S_OK;
}

__xmldest_template_inline
STDMETHODIMP xmlWriteChar(xmldest_t* dst, xmlint ch)
{
	fputc(ch, dst->fp);
	return S_OK;
}

#endif // ___uses_xmldest_t

// -------------------------------------------------------------------------

__xmlwriter_template
STDMETHODIMP xmlStartTag(xmldest dst, const xmlchar* tag)
{
	if (!dst->fHasSubtag)
	{
		xmlWriteChar(dst, '>');
	}
	
	xmlWriteChar(dst, '<');
	xmlWriteString(dst, tag);
	
	dst->fHasSubtag = FALSE;
	return S_OK;
}

__xmlwriter_template
STDMETHODIMP xmlEndTag(xmldest dst, const xmlchar* tag)
{
	if (dst->fHasSubtag)
	{
		xmlWriteChar(dst, '<');
		xmlWriteChar(dst, '/');
		xmlWriteString(dst, tag);
		xmlWriteChar(dst, '>');
	}
	else
	{
		xmlWriteChar(dst, '/');
		xmlWriteChar(dst, '>');
		dst->fHasSubtag = TRUE;
	}
	return S_OK;
}

__xmlwriter_template
STDMETHODIMP xmlAddProp(xmldest dst, const xmlchar* prop, const xmlchar* val)
{
	int ient;
	const xmlchar* pch = val;
	unsigned nentities = dst->nentities;
	const xml_entity_t* pentities = dst->pentities;
	
	xmlWriteChar(dst, ' ');
	xmlWriteString(dst, prop);
	xmlWriteChar(dst, '=');
	xmlWriteChar(dst, '\"');
	
	// -----> write prop value...
lzLoop:
	if (*pch)
	{
		for (ient = nentities; ient--; )
		{
			if (pentities[ient].ch_entity == *pch)
			{
				if (pch > val)
				{
					xmlWriteString(dst, val, pch - val);
				}
				xmlWriteChar(dst, '&');
				xmlWriteString(dst, pentities[ient].entity);
				xmlWriteChar(dst, ';');
				val = ++pch;
				goto lzLoop;
			}
		}
		++pch;
		goto lzLoop;
	}
	if (pch > val)
	{
		xmlWriteString(dst, val, pch - val);
	}
	
	xmlWriteChar(dst, '\"');
	return S_OK;
}

// -------------------------------------------------------------------------
