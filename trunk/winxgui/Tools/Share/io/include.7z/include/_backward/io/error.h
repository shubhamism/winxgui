/* -------------------------------------------------------------------------
//	�ļ���		��	error.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-15 20:26:34
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __IO_ERROR_H__
#define __IO_ERROR_H__

// ----> io/atom.h

#define E_ATOM_INVALIDPROP			E_FAIL
#define E_ATOM_INVALIDVT			E_FAIL
#define E_ATOM_NULLPROP				E_FAIL
#define E_ATOM_ACCESS_NULLATOM		E_FAIL

#define E_ATOM_AR_OUTOFRANGE		E_FAIL

// ----> io/xmlaccepter.h

#define E_WML_INVALIDSUBTAG						E_FAIL
#define E_WML_UNKNOWNTAG						E_FAIL
#define E_WML_NOSTARTTAG						E_FAIL
#define E_WML_ENDTAG_UNMATCHED					E_FAIL
#define E_WML_START_OBJECTTAG_WITHOUT_PARENT	E_FAIL

// ----> io/xmlparser.h

#define E_XML_NO_STARTTAG		E_FAIL
#define E_XML_EOF				E_FAIL
#define E_XML_INVALID_SYMBOL	E_FAIL
#define E_XML_INVALID_ENTITY	E_FAIL
#define E_XML_UNKNOWN_ENTITY	E_FAIL
#define E_XML_NEEDSYM_EQUAL		E_FAIL
#define E_XML_NEEDSYM_GT		E_FAIL

// ----> io/.h

#define E_IO_OPENFILE			E_FAIL
#define E_IO_INVALIDHANDLE		E_FAIL

#endif /* __ERROR_H__ */
