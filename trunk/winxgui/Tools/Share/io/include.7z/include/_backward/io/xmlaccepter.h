/* -------------------------------------------------------------------------
//	�ļ���		��	io_xmlaccepter.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-3 22:00:33
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __IO_XMLACCEPTER_H__
#define __IO_XMLACCEPTER_H__

#define Uses_KLinearStack
#include "ks_stack.h"

#ifndef __IO_ATOM_H__
#include "atom.h"
#endif

#include <list>
using namespace std;

struct tagKIOWMLTag
{
	WMLTAGID	tagid;
	KIOAtom*	pTag;
};
typedef struct tagKIOWMLTag		KIOWMLTag;
typedef KLinearStack<KIOWMLTag>	KIOTagStack;
typedef list<void*>				KIOStyAtomList;

typedef HRESULT (__stdcall* FHandleStyAtom)(KIOAtom* pAtom, LPVOID pParam);

class KWMLAccepter : public IKWMLAccepter
{
public:
	KWMLAccepter(LPDTD pRoot);
	~KWMLAccepter() { Clear(); }
	
	STDMETHODIMP StartTag(WMLTAGID tagid);
	STDMETHODIMP AddProp (WMLPROPID prop, LPCVOID pv, WMLBUFINFO bf);
	STDMETHODIMP EndTag  (WMLTAGID tagid, WMLATOMID* patomid);

	STDMETHODIMP EnumStyAtoms(FHandleStyAtom fnHandle, LPVOID pParam);

	virtual STDMETHODIMP LoadDoc(KIOAtom* pDoc) = 0;

private:
	STDMETHODIMP_(void)  Clear();
	STDMETHODIMP_(void*) GetMapTagidToDtd();
	
protected:
	KIOWMLTag		 m_tag;
	KIOTagStack		 m_stkTag;

	KIOStyAtomList	 m_styTags;
	
	LPDTD			 m_pRoot;
	void*			 m_map;
};

// -------------------------------------------------------------------------

#endif /* __IO_XMLACCEPTER_H__ */
