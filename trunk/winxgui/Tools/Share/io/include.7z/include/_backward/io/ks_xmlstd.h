/* -------------------------------------------------------------------------
//	�ļ���		��	ks_xmlstd.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-3 21:28:14
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __KS_XMLSTD_H__
#define __KS_XMLSTD_H__

// -------------------------------------------------------------------------

typedef unsigned WMLTAGID;
typedef unsigned WMLPROPID;
typedef unsigned WMLBUFINFO;
typedef unsigned WMLATOMID;

#define WML_STYLETAG_BASE			0x0000
#define WML_OBJECTTAG_BASE			0x8000
#define IS_STYLETAG(tagid)			((WMLTAGID)(tagid) < 0x8000)
#define IS_OBJECTTAG(tagid)			((WMLTAGID)(tagid) >= 0x8000)

#define WML_NULLTAG					((WMLTAGID)-1)
#define WML_NULLATOM				((WMLATOMID)-1)

// prop=(dim, iprp)=(vt, idim, iprp):
//	vt=4bits, idim=12bits, iprp=16bits
#define WML_PROPVT(prop)			((prop) & 0xF0000000)
#define WML_PROPDIM(prop)			((prop) & 0xFFFF0000)
#define WML_MAKEDIM(vt, idim)		((vt) | ((idim) << 16))
#define WML_MAKEPROP(dim, iprp)		((dim) | (iprp))

#define WML_BUFLEN(bf)				((bf) & 0x0FFFFFFF)
#define WML_BUFLEN_MAX				0x07FFFFFF

#define _WML_VT(ivt)				((ivt) << 28)
#define _WML_IVT(vt)				((vt) >> 28)

enum WMLPROPVT
{
	vtWMLVoid		= _WML_VT(0),
	vtWMLDate		= _WML_VT(6),
	vtWMLR8			= _WML_VT(7),
	vtWMLSubtag		= _WML_VT(10),	// IKWMLAtomArray* �ӱ�ǩ����ı���vt, �ڲ�ʹ��!!!
	vtWMLUnknown	= _WML_VT(11),	// IUnknown*
	vtWMLErr		= _WML_VT(12),
	vtWMLBool		= _WML_VT(13),
	vtWMLI4			= _WML_VT(14),
	vtWMLBStr		= _WML_VT(15),	// ������15�������޸� IKWMLAccepter::AddPropBStr
};

#define vtWMLAtomid			vtWMLI4

enum WMLPROPDIM
{
	dimWMLInvalid		= 0,
	dimWMLColor			= WML_MAKEDIM(vtWMLI4, 0x01),         // ��ɫ				COLORREF
	dimWMLLength		= WML_MAKEDIM(vtWMLI4, 0x02),         // ����				0.1mm
	dimWMLHiLength		= WML_MAKEDIM(vtWMLI4, 0x03),         // ����				0.01mm
	dimWMLDegree		= WML_MAKEDIM(vtWMLI4, 0x04),         // �Ƕ�				0.1��
	dimWMLScale			= WML_MAKEDIM(vtWMLI4, 0x05),         // ����ϵ��			1%
	dimWMLHiScale		= WML_MAKEDIM(vtWMLI4, 0x06),         // ����ϵ��			0.1%
	dimWMLEnum			= WML_MAKEDIM(vtWMLI4, 0x07),         // ö��				-
	dimWMLInt			= WML_MAKEDIM(vtWMLI4, 0x08),         // ������				-
	dimWMLFixFloat		= WML_MAKEDIM(vtWMLI4, 0x09),		  // ����С�� 
	dimWMLTicks			= WML_MAKEDIM(vtWMLI4, 0x0a),		  // ʱ��tick��(��λ:ms)
	dimWMLDate			= WML_MAKEDIM(vtWMLDate, 0x20),		  // ����(��λ: DATE)
	
	dimWMLString		= WML_MAKEDIM(vtWMLBStr, 0x100),      // �ַ���				WCHAR*

	dimWMLStorage		= WML_MAKEDIM(vtWMLUnknown, 0x150),	  // OLE Storage

	dimWMLAtomid		= WML_MAKEDIM(vtWMLAtomid,  0x200),	  // StyAtom��Class(��AtomId)
	dimWMLSubtag		= WML_MAKEDIM(vtWMLSubtag,  0x201),   // �ڲ�ʹ��!!!

	dimWMLAtomidArray	= WML_MAKEDIM(vtWMLVoid, 0x300),
	dimWMLBuffer		= WML_MAKEDIM(vtWMLVoid, 0x301),
	dimWMLIUnknown		= WML_MAKEDIM(vtWMLUnknown, 0x302),
};

#define propWMLClass		WML_MAKEPROP(dimWMLAtomid, 0xffff)
#define propWMLContent		WML_MAKEPROP(dimWMLString, 0xffff)
#define propWMLInvalid		WML_MAKEPROP(dimWMLInvalid, 0xffff)

// -------------------------------------------------------------------------

DECLARE_IID(IKMediaInit)
DECLARE_IID(IKFileMediaInit)

interface IKMediaInit : IUnknown
{
	STDMETHOD (Init)(IUnknown* pParam) = 0;
};

interface IKFileMediaInit : IUnknown
{
	STDMETHOD (Init)(LPCWSTR szFile, DWORD grfMode) = 0;
};

// -------------------------------------------------------------------------

DECLARE_IID(IKWMLAccepter)
DECLARE_IID(IKWMLStorer)

#define IMPLEMENT_ADDPROP_FRIENDLY()										\
inline STDMETHODIMP StartTag(WMLTAGID tagid, WMLATOMID id)					\
	{																		\
		HRESULT hr = StartTag(tagid);										\
		if (hr == S_OK && id != WML_NULLATOM)								\
			AddProp(propWMLClass, (LPCVOID)id, vtWMLAtomid);				\
		return hr;															\
	}																		\
inline STDMETHODIMP AddPropAtomid(WMLPROPID prop, WMLATOMID id)				\
	{ return AddProp(prop, (LPCVOID)id, vtWMLAtomid); }						\
inline STDMETHODIMP AddPropI4(WMLPROPID prop, LONG lVal)					\
	{ return AddProp(prop, (LPCVOID)lVal, vtWMLI4); }						\
inline STDMETHODIMP AddPropUnk(WMLPROPID prop, IUnknown* pUnk)				\
	{ return AddProp(prop, (LPCVOID)pUnk, vtWMLUnknown); }					\
inline STDMETHODIMP AddPropBStr(WMLPROPID prop, LPCWSTR bstr)				\
	{ ASSERT(vtWMLBStr == _WML_VT(15)); 									\
	  return AddProp(prop, (LPCVOID)bstr, (WMLBUFINFO)-1); }				\
inline STDMETHODIMP AddPropBStr(WMLPROPID prop, LPCWSTR bstr, UINT cch)		\
	{ ASSERT(vtWMLBStr == _WML_VT(15)); 									\
	  return AddProp(prop, (LPCVOID)bstr, cch|vtWMLBStr); }

interface IKWMLAccepter : IUnknown
{
	STDMETHOD (StartTag)(WMLTAGID tagid)							= 0;
	STDMETHOD (AddProp) (WMLPROPID prop, LPCVOID pv, WMLBUFINFO bf) = 0;
	STDMETHOD (EndTag)	(WMLTAGID tagid, WMLATOMID* patomid = NULL)	= 0;
	STDMETHOD (Close)   ()											= 0;
	IMPLEMENT_ADDPROP_FRIENDLY()
};

interface IKWMLStorer : IUnknown
{
	STDMETHOD (Store)(IKWMLAccepter* pAcc) = 0;
};
/* -----------------------------------------------------------------------*\
 * ���䷽��֪:
	StartTag�ڽ��ܷ���֧��ĳtagid��������������ԭ��ʧ��ʱ������Ӧ����һ��
	�����롣���Ӧ�� EndTagҲ����Ҫ�ٵ��á�
\* -----------------------------------------------------------------------*/

#endif /* __KS_XMLSTD_H__ */
