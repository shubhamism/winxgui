/* -------------------------------------------------------------------------
//	�ļ���		��	ks_xmlstd_i.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-8 11:08:24
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __KS_XMLSTD_I_H__
#define __KS_XMLSTD_I_H__

IMPLEMENT_IID(IKWMLAccepter, "160AC35E-375D-4ffa-99D9-3D5E21B08D0D", 
		0x160ac35e, 0x375d, 0x4ffa, 0x99, 0xd9, 0x3d, 0x5e, 0x21, 0xb0, 0x8d, 0xd)

IMPLEMENT_IID(IKWMLStorer, "F72CCB83-BB1E-472f-B149-F78BA1712A1A", 
		0xf72ccb83, 0xbb1e, 0x472f, 0xb1, 0x49, 0xf7, 0x8b, 0xa1, 0x71, 0x2a, 0x1a)

IMPLEMENT_IID(IKMediaInit, "A24C7DA8-FDFB-4d40-9476-4FF9E1CF5F8F", 
		0xa24c7da8, 0xfdfb, 0x4d40, 0x94, 0x76, 0x4f, 0xf9, 0xe1, 0xcf, 0x5f, 0x8f)

IMPLEMENT_IID(IKFileMediaInit, "3349E5F3-B688-4939-8450-A9A07990E2DD", 
		0x3349e5f3, 0xb688, 0x4939, 0x84, 0x50, 0xa9, 0xa0, 0x79, 0x90, 0xe2, 0xdd)

#endif /* __KS_XMLSTD_I_H__ */
