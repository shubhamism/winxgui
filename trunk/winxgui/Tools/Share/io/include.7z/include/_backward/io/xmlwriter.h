/* -------------------------------------------------------------------------
//	�ļ���		��	xmlwriter.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-4-15 15:09:30
//	��������	��	
//
//	$Id: xmlwriter.h,v 1.2 2005/02/05 04:22:10 xushiwei Exp $
//-----------------------------------------------------------------------*/
#ifndef __IO_XMLWRITER_H__
#define __IO_XMLWRITER_H__

#error "���ļ���׼�����ˡ������<kfc/xml/writer.h>"

#ifndef __IO_XMLTYPES_H__
#include "xmltypes.h"
#endif

// -------------------------------------------------------------------------

#ifndef	__xmldest_template
#define __xmldest_template		// template <class xmlchar, class xmlint>
#endif

#ifndef __xmldest_template_inline
#define __xmldest_template_inline __xmldest_template inline
#endif

// {{ -------> interface xmldest:

#if !defined(xmldest_t)
#define xmldest_t				__xmldest_t // <xmlchar, xmlint>
#define ___uses_xmldest_t

__xmldest_template
struct __xmldest_t
{
	FILE* fp;
	int fHasSubtag;	// ��ǰ��ǩ�Ѿ������ӱ�ǩ
	const xml_entity_t* pentities;
	unsigned nentities;
};

__xmldest_template_inline
STDMETHODIMP_(void) xmlDestInit(
	xmldest_t* dst,
	FILE* fp,
	const xml_entity_t* pentities,
	unsigned nentities
	)
{
	dst->fp	= fp;
	dst->fHasSubtag = TRUE;
	dst->pentities  = pentities;
	dst->nentities  = nentities;
}

#endif	// xmldest_t

typedef	xmldest_t*	xmldest;

// -------------------------------------------------------------------------

#ifndef __xmlwriter_template
#define __xmlwriter_template	// template<class xmlchar, class xmlint, class xmldest>
#endif

#ifndef __xmlwriter_template_inline
#define __xmlwriter_template_inline	__xmlwriter_template inline
#endif

__xmlwriter_template
STDMETHODIMP xmlStartTag(xmldest dst, const xmlchar* tag);

__xmlwriter_template
STDMETHODIMP xmlEndTag(xmldest dst, const xmlchar* tag);

__xmlwriter_template
STDMETHODIMP xmlAddProp(xmldest dst, const xmlchar* prop, const xmlchar* val);

// -------------------------------------------------------------------------
// $Log: xmlwriter.h,v $
// Revision 1.2  2005/02/05 04:22:10  xushiwei
// �ϳ����ļ���
//

#endif /* __XMLWRITER_H__ */
