// -------------------------------------------------------------------------
//	�ļ���		��	ioacceptor/propbag.h
//	������		��	nature(����)
//	����ʱ��	��	2003-9-30 16:31:58
//	��������	��	
//	$Id: propbag.h,v 1.6 2005/06/30 08:24:44 liucong Exp $
// -------------------------------------------------------------------------

#ifndef __IOACCEPTOR_PROPBAG_H__
#define __IOACCEPTOR_PROPBAG_H__

#ifndef __IOACCEPTOR_PROPBAGBASE_H__
#include "propbagbase.h"
#endif

// -------------------------------------------------------------------------
#define __PB propbag_helper::

// -------------------------------------------------------------------------
namespace propbag_helper
{
	inline static KPropBag* CastItfToCls(IN IIOPropBag* pPB)
	{
		return (KPropBag*)pPB;
#if 0
		if (pPB == NULL)
			return NULL;
#ifdef _DEBUG
		KPropBag* pClsPB = NULL;
		if (SUCCEEDED(pPB->QueryInterface(IID_KPropBag, (void**)&pClsPB)))
			pClsPB->Release();
#endif //_DEBUG
		return (KPropBag*)((size_t)pPB - (size_t)(IIOPropBag*)(KPropBag*)NULL);
#endif
	}


	inline LONG DeleteProp(IN KPropBag* pPB, IN IOPROPID PropID)
	{
		ASSERT(pPB);
		LONG index = pPB->FindProp(PropID, NULL);
		if (index >= 0)
			pPB->RemoveProp(index);
		return index;
	}

	//by xushiwei
	//inline LONG ReplaceProp(IN KPropBag* pPB, IN IOPROPID PropID, IN OUT VARIANT* pVar)
	inline void ReplaceProp(IN KPropBag* pPB, IN IOPROPID PropID, IN OUT VARIANT* pVar)
	{
		ASSERT(pPB != NULL && pVar != NULL);
		LONG index = pPB->FindProp(PropID, NULL);
		if (index < 0)
			//index = pPB->AddProp(PropID, pVar);
			pPB->AddProp(PropID, pVar);
		else
		{
			if (FAILED(pPB->SetProp(index, PropID, pVar)))
				index = -1;
		}
		//return index;
	}

#if !defined(X_ATTRLIST_NOADDREF)
	inline KPropBag* SafeGetSubPB(IN KPropBag* pPB, IN IOPROPID PropID)
	{
		ASSERT(pPB);
		const VARIANT* pVar = NULL;
		LONG index = pPB->FindProp(PropID, &pVar);

		if (index < 0 || pVar->vt == VT_EMPTY)
		{
			KComObjectPtr<KPropBag> ptrSubPB(create_instance);
			VARIANT var;
			var.vt = VT_PROPBAG;
			var.punkVal = ptrSubPB;
			if (index < 0)
				//VERIFY ((pPB->AddProp(PropID, &var) >= 0));
				pPB->AddProp(PropID, &var);
			else
				VERIFY(SUCCEEDED (pPB->SetProp(index, NULL, &var)));
			return ptrSubPB.detach();
		}
		else
		{
			ASSERT(pVar->vt == VT_PROPBAG);
			if (pVar->vt != VT_PROPBAG)
				return NULL;
			return CastItfToCls((IIOPropBag*)pVar->punkVal);
		}
	}
#endif

	inline LONG DetachProp(IN KPropBag* pPB, IN IOPROPID PropID, OUT VARIANT* pVar)
	{
		ASSERT(pPB && pVar);
		LONG index = pPB->FindProp(PropID, NULL);
		if (index >= 0)
		{
			if (FAILED(pPB->DetachProp(index, &PropID, pVar)))
				index = -1;
		}
		else
			VariantInit(pVar);
		return index;
	}

#if !defined(X_ATTRLIST_NOADDREF)
	inline BOOL CopyPropBag(IN IIOPropBag* pSrcPB, OUT KPropBag* pDesPB)
	{
		ASSERT(pSrcPB && pDesPB);

		pDesPB->Clear();

		LONG nCount = pSrcPB->GetPropCount();
		for(LONG i = 0; i < nCount; ++i)
        {
			IOPROPID nId = 0;
			const VARIANT* pVar = NULL;
            VERIFY(SUCCEEDED(pSrcPB->GetProp(i, &nId, &pVar)));

			VARIANT VarCopy;
            VariantInit(&VarCopy);
			if (VT_PROPBAG == pVar->vt)
			{
				KComObjectPtr<KPropBag> ptrSubPB(create_instance);
				VERIFY(CopyPropBag(CastItfToCls((IIOPropBag*)pVar->punkVal), ptrSubPB));
				VarCopy.vt = VT_PROPBAG;
				VarCopy.punkVal = ptrSubPB.detach();
			}
			else
			{
				VERIFY(SUCCEEDED(VariantCopy(&VarCopy, (VARIANT*)pVar)));
			}

			//VERIFY((pDesPB->AddProp(nId, &VarCopy) >= 0));
			pDesPB->AddProp(nId, &VarCopy);
			VariantClear(&VarCopy);
		}

        return TRUE;
	}

	inline STDMETHODIMP_(void) Dump(
							KPropBagWrapper* pTarget,
							KPropBagWrapper* pSource)
	{
		LONG Count = pSource->GetPropCount();
		IOPROPID Id = NULL;
		const VARIANT* pValue = NULL;
		for (LONG i = 0; i < Count; ++i)
		{
			pSource->GetProp(i, &Id, &pValue);

			LONG idxExist = pTarget->FindProp(Id, NULL);

			if (pValue->vt == VT_ATTRLIST)
			{
				KPropBagWrapper* pSub = (KPropBagWrapper*)pValue->lVal;
				KPropBagWrapper* pSubTarget = SafeGetSubPB(pTarget, Id); // todo: �Ż�
				Dump(pSubTarget, pSub);
			}
			else if (pValue->vt == VT_BSTR)
			{
				if (idxExist >= 0)
					pTarget->RemoveProp(idxExist);
				pTarget->AddProp(Id, pValue->bstrVal);
			}
			else
			{
				ASSERT(pValue->vt == VT_EMPTY || pValue->vt == VT_I4);

				VARIANT Value;
				memcpy(&Value, pValue, sizeof(VARIANT));
				ReplaceProp(pTarget, Id, &Value);
			}
		}
	}
#endif

	inline BOOL IsSimilarPB(IIOPropBag* pPB1, IIOPropBag* pPB2)
	{
		if (pPB1 == NULL && pPB2 == NULL)
			return TRUE;
		if (pPB1 == NULL || pPB2 == NULL)
			return FALSE;

		LONG cnt = pPB1->GetPropCount();
		if (cnt != pPB2->GetPropCount())
			return FALSE;

		for (LONG i = 0; i < cnt; ++i)
		{
			IOPROPID pid1 = 0;
			IOPROPID pid2 = 0;
			const VARIANT* pVar1 = NULL;
			const VARIANT* pVar2 = NULL;
			VERIFY(SUCCEEDED(pPB1->GetProp(i, &pid1, &pVar1)));
			VERIFY(SUCCEEDED(pPB2->GetProp(i, &pid2, &pVar2)));
			ASSERT(pVar1 && pVar2);

			if (pid1 != pid2)
				return FALSE;
			if (pVar1->vt != pVar2->vt)
				return FALSE;

			if (pVar1->vt == VT_PROPBAG)
			{
				IIOPropBag* pSubPB1 = (IIOPropBag*)pVar1->ppbVal;
				IIOPropBag* pSubPB2 = (IIOPropBag*)pVar2->ppbVal;
				if (!IsSimilarPB(pSubPB1, pSubPB2))
					return FALSE;
			}
			else
			{
				if (memcmp(pVar1, pVar2, sizeof(VARIANT)) != 0)
					return FALSE;
			}
		}

		return TRUE;
	}
} //namespace propbag_helper

// ------------------------------------------------------------------------
namespace propbag_helper
{
	/*
	@fn DiffPB
	@brief
		��������src��Ҷ���Դ�dest��ɾ������ĳ�����Ƿ�Ҷ���ԣ���������ڹ���á�
		�ڹ鷵�غ����÷�Ҷ�����ѿգ�����ɾ����
	@arg [in] dest
		�����԰��е�������Ҳ������src�У�����ܱ�ɾ����
	@arg [in] src
		src���԰��е�������Ҳ������dest�У�������Կ��ܻᱻ��dest��ɾ����\
		ע��: src�����Ǳ�����ֻ���ġ�
	@return
	@remark
		���
			1. Ҷ����, ���Ͳ������԰������ԡ�
			2. ��Ҷ����, ����Ҷ���Ե����ԡ�
			3. ����, Ҷ���� + ��Ҷ���ԡ�

		Ŀǰ�����������: 
			1. ��һ���Զ���Ŷ�����Ӧ����һ�������ԡ�
	@*/

#define __CAST_SP2PB(sp) ((KPropBag*)(IIOPropBag*)(sp))

	inline
	STDMETHODIMP_(VOID) DiffPB(
		IN KPropBag* dest, IN /*const*/ IIOPropBag* src)
	{
		typedef std::vector<ELEMENTID> ElemArray;
		ElemArray Elem2Del;

		const LONG cSrc = src->GetPropCount();
		for (LONG i = 0; i < cSrc; ++i)
		{
			PROPID idSrc;
			const VARIANT* varSrc;
			if (SUCCEEDED(src->GetProp(i, &idSrc, &varSrc)))
			{
				const VARIANT* varDest;
				if (SUCCEEDED(dest->FindProp(idSrc, &varDest)))
				{
					if (varSrc->vt == VT_UNKNOWN)
					{
						ks_stdptr<IIOPropBag> spPbSrc(varSrc->punkVal);
						ks_stdptr<IIOPropBag> spPbDest(varDest->punkVal);
						if (spPbSrc && spPbDest)
						{
							DiffPB(__CAST_SP2PB(spPbDest), spPbSrc);
							if (spPbDest->GetPropCount() == 0)
								Elem2Del.push_back(idSrc);
						}
						else
						{
							ASSERT(spPbDest == NULL && spPbSrc == NULL);
							Elem2Del.push_back(idSrc);
						}
					}
					else
					{
						Elem2Del.push_back(idSrc);
					}
				}
			}
		} // end for
		
		ElemArray::const_iterator i = Elem2Del.begin();
		for (; i != Elem2Del.end(); ++i)
			__PB DeleteProp(dest, *i);
	}
}

// -------------------------------------------------------------------------
// $Log: propbag.h,v $
// Revision 1.6  2005/06/30 08:24:44  liucong
// no message
//
// Revision 1.5  2004/12/25 13:33:26  sunhongqiao
// *** empty log message ***
//
// Revision 1.4  2004/12/25 13:28:29  sunhongqiao
// ������DiffPB��ɾ��©����
//

#endif /* __IOACCEPTOR_PROPBAG_H__ */
