// -------------------------------------------------------------------------
//	�ļ���		��	acc2xsl.h
//	������		��	Hsie
//	����ʱ��	��	2004-03-22 12:07:04
//	��������	��	�ϰ�IO�ӿ�AdaptΪ�°�IO�ӿ�
//	IO���Ͷ˽ӿڣ�	ʹ�� KAdaptIOSrc2ContSrc �� IIOSource ��װΪ IKContentSource��KAdaptContSrc2IOSrc ��֮
//	IO���ն˽ӿڣ�	ʹ�� KAdaptIOAcc2ContHdl �� IIOAcceptor ��װΪ IKContentHandler��KAdaptContHdl2IOAcc ��֮
//	���԰��ӿ�	��	ʹ�� KAdaptPb2Attr �� IIOPropBag ��װΪ IKAttributes��KAdaptAttr2Pb ��֮��ע��һ�㲻��ֱ��ʹ�ã�
//	˵��		��	ÿ���඼�Լ̳з�ʽʵ����AdaptĿ��ӿڣ�����Ҫһ��AdaptԴ�ӿ�ָ����г�ʼ����SetXXXX��
// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
//	REVISION LOG ENTRY
//	Revised by	��	����
//	Revised on	��	2004-10-29 9:09:36
//	Comments	��	���������������������
//					1. KImpElem2Acc
//						��IKElementHandler�ӿ����䵽IIOAcceptor�ӿڡ�
//					2. KImpAcc2Elem
//						��IIOAcceptor�ӿ����䵽IKElementHandler�ӿڡ�
// -------------------------------------------------------------------------

/*
@category Kingsoft SDK - KSO IO V1
@group [ksoiov1_adapt] Adaptors
@brief
	������
@*/

#ifndef __ACC2SAX_H__
#define __ACC2SAX_H__

#ifndef __KSO_IO_FILTER_H__
#include <kso/io/filter.h>
#endif

#ifndef __IOACCEPTOR_H__
#include "ioacceptor.h"
#endif

///////////////////////////////////////////////////////////////////////////
//propbag & attributes

//propbag 2 attributes
class KAdaptPb2Attr : public IKAttributes
{
private:
	#define ATTRITEMREF_RAW		((ATTRVALUE* const) 0)
	#define ATTRITEMREF_PASS	((ATTRVALUE* const)-1)

public:
	KAdaptPb2Attr() : m_pPB(NULL) {}
	~KAdaptPb2Attr() {Clear();}

public:
	HRESULT SetPB(IIOPropBag* pPB)
	{
		Clear();
		KS_ASSIGN(m_pPB, pPB);

		if (m_pPB != NULL)
		{
			LONG cnt = m_pPB->GetPropCount();
			m_vecAttrItemRef.resize(cnt, ATTRITEMREF_RAW);
		}

		return S_OK;
	}
	HRESULT Clear()
	{
		for (ATTRITEMREFVECTOR::iterator it = m_vecAttrItemRef.begin(); it != m_vecAttrItemRef.end(); ++it)
		{
			ATTRVALUE* pAttrVar = *it;
			if (pAttrVar != ATTRITEMREF_RAW
				&& pAttrVar != ATTRITEMREF_PASS)
			{
				ASSERT(pAttrVar->vt == ATTRVALUE::vtAttrList);
				IKAttributes* pAttrSub = (IKAttributes*)pAttrVar->lVal;
				if (pAttrSub != NULL)
				{
					KAdaptPb2Attr* pAttrSubInst = (KAdaptPb2Attr*)pAttrSub;
					delete pAttrSubInst;
					pAttrVar->lVal = 0;
				}
				delete pAttrVar;
			}
		}
		m_vecAttrItemRef.clear();

		KS_RELEASE(m_pPB);

		return S_OK;
	}

private:
	HRESULT _GetItemAttr(UINT idx, ATTRID* pAttrId, const ATTRVALUE** ppAttrVar)
	{
		ASSERT(m_pPB != NULL);
		ASSERT(idx < m_vecAttrItemRef.size());
		if (pAttrId == NULL && ppAttrVar == NULL)
			return S_FALSE;
		IOPROPID PbId = 0;
		const ATTRVALUE* pAttrVar = NULL;
		if (m_vecAttrItemRef[idx] == ATTRITEMREF_RAW)
		{
			const VARIANT* pPbVar = NULL;
			HRESULT hr = m_pPB->GetProp((LONG)idx, &PbId, &pPbVar);
			if (FAILED(hr))
				return hr;
			if (ppAttrVar != NULL)
			{
				if (pPbVar->vt == VT_PROPBAG)
				{
					ks_stdptr<IIOPropBag> spPbSub = pPbVar->ppbVal;
					if (spPbSub)
					{
						std::auto_ptr<ATTRVALUE> ptrAttrVarT(new ATTRVALUE);

						std::auto_ptr<KAdaptPb2Attr> ptrAttrSubInst(new KAdaptPb2Attr);
						if (FAILED(ptrAttrSubInst->SetPB(spPbSub)))
							return E_UNEXPECTED;

						ptrAttrVarT->vt = ATTRVALUE::vtAttrList;
						ptrAttrVarT->lVal = (INT)(IKAttributes*)ptrAttrSubInst.release();

						pAttrVar = m_vecAttrItemRef[idx] = ptrAttrVarT.release();
					}
				}

				if (pAttrVar == NULL)
				{
					m_vecAttrItemRef[idx] = ATTRITEMREF_PASS;
					pAttrVar = (const ATTRVALUE*)pPbVar;
				}
			}
		}
		else if (m_vecAttrItemRef[idx] == ATTRITEMREF_PASS)
		{
			const VARIANT* pPbVar = NULL;
			HRESULT hr = m_pPB->GetProp((LONG)idx, &PbId, &pPbVar);
			if (FAILED(hr))
				return hr;
			pAttrVar = (const ATTRVALUE*)pPbVar;
		}
		else
		{
			if (pAttrId != NULL)
			{
				HRESULT hr = m_pPB->GetProp((LONG)idx, &PbId, NULL);
				if (FAILED(hr))
					return hr;
			}
			pAttrVar = m_vecAttrItemRef[idx];
		}

		if (pAttrId != NULL)
			*pAttrId = (ATTRID)PbId;
		if (ppAttrVar != NULL)
			*ppAttrVar = pAttrVar;
		return S_OK;
	}

public:
    STDPROC_(UINT) Count()
	{
		if (m_pPB == NULL)
			return E_UNEXPECTED;
		return (UINT)m_vecAttrItemRef.size();
	}

	STDPROC GetAt(IN UINT index, OUT ATTRID* pAttrID, OUT ATTRVALUE_PTR* ppAttrValue)
	{
		if (m_pPB == NULL)
			return E_UNEXPECTED;
		if (index >= m_vecAttrItemRef.size())
			return E_INVALIDARG;
		return _GetItemAttr(index, pAttrID, ppAttrValue);
	}
	STDPROC_(INT) GetIndex(
		IN ATTRID uAttrID,
		OUT ATTRVALUE_PTR* ppAttrValue)
	{
		if (m_pPB == NULL)
			return E_UNEXPECTED;
		LONG idx = m_pPB->FindProp((IOPROPID)uAttrID, NULL);
		if (idx < 0)
			return -1;
		ASSERT(idx < m_vecAttrItemRef.size());
		if (ppAttrValue != NULL)
		{
			if (idx >= m_vecAttrItemRef.size())
				return E_UNEXPECTED;
			if (FAILED(_GetItemAttr(idx, NULL, ppAttrValue)))
				return -1;
		}
		return (INT)idx;
	}

private:
	typedef std::vector<ATTRVALUE*>	ATTRITEMREFVECTOR;
	ATTRITEMREFVECTOR m_vecAttrItemRef;

	IIOPropBag* m_pPB;

private:
	#undef ATTRITEMREF_RAW		//((ATTRVALUE* const) 0)
	#undef ATTRITEMREF_PASS		//((ATTRVALUE* const)-1)

public:
	DECLARE_COUNT(KAdaptPb2Attr)
};


//attributes 2 propbag
class KAdaptAttr2Pb : public IIOPropBag
{
#ifdef _DEBUG
public:
	struct __LIFE_CHECKOR
	{
		IIOPropBag* m_pPB;
		ULONG m_c;
		__LIFE_CHECKOR(IIOPropBag* pPB, ULONG c = 1) : m_pPB(NULL), m_c(c) {KS_ASSIGN(m_pPB, pPB);}
		~__LIFE_CHECKOR() {_Check(); KS_RELEASE(m_pPB);}
		void _Check()
		{
			if (m_pPB == NULL)
				return;
			//check self, Checkor hold 1 ref
			ASSERT(m_pPB->AddRef() == m_c + 2);
			ASSERT(m_pPB->Release() == m_c + 1);
			//check subs, pbs that are lower than son are checked at their destructor
			LONG cnt = m_pPB->GetPropCount();
			for (LONG i = 0; i < cnt; ++i)
			{
				const VARIANT* pVar = NULL;
				if (FAILED(m_pPB->GetProp(i, NULL, &pVar)))
					continue;
				if (pVar->vt != VT_PROPBAG)
					continue;
				if (!ks_stdptr<IIOPropBag>(pVar->ppbVal))
					continue;
				ASSERT(pVar->ppbVal->AddRef() == 2);
				ASSERT(pVar->ppbVal->Release() == 1);
			}
		}
	};
	#define _CHECK_PROPBAGLIFE(pPB)		KAdaptAttr2Pb::__LIFE_CHECKOR ____x_life_checkor((pPB))
#else
	#define _CHECK_PROPBAGLIFE(pPB)		(0)
#endif //def(_DEBUG)

public:
	KAdaptAttr2Pb() {}
	~KAdaptAttr2Pb() {Clear();}

public:
	HRESULT SetAttr(IKAttributes* pAttr)
	{
		Clear();

		if (pAttr != NULL)
		{
			UINT cnt = pAttr->Count();
			m_vecPbPropItemRef.resize(cnt, NULL);
			for (UINT i = 0; i < cnt; ++i)
			{
				ATTRID attrID = 0;
				const ATTRVALUE* pAttrVar = NULL;
				if (FAILED(pAttr->GetAt(i, &attrID, &pAttrVar)))
					continue;

				std::auto_ptr<PROPITEM> ptrItemT(new PROPITEM);
				ptrItemT->id = (IOPROPID)attrID;
				::VariantInit(&ptrItemT->var);

				if (pAttrVar->vt == ATTRVALUE::vtAttrList)
				{
					ptrItemT->var.vt = VT_PROPBAG;
					ptrItemT->var.ppbVal = NULL;

					IKAttributes* pAttrSub = (IKAttributes*)pAttrVar->lVal;
					if (pAttrSub != NULL)
					{
						KComObjectPtr<KAdaptAttr2Pb> ptrPbSubInst(create_instance);
						if (FAILED(ptrPbSubInst->SetAttr(pAttrSub)))
							continue;
						ptrItemT->var.ppbVal = ptrPbSubInst.detach();
					}
				}
				else
				{
					ASSERT(sizeof(VARIANT) == sizeof(ATTRVALUE));
					ASSERT(&((VARIANT*)NULL)->vt == &((ATTRVALUE*)NULL)->vt);
					ASSERT(&((VARIANT*)NULL)->lVal == &((ATTRVALUE*)NULL)->lVal);

					::VariantCopy(&ptrItemT->var, (VARIANT*)pAttrVar);
				}

				m_vecPbPropItemRef[i] = ptrItemT.release();
			}
		}

		return S_OK;
	}
	HRESULT Clear()
	{
		for (PBPROPITEMREFVECTOR::iterator it = m_vecPbPropItemRef.begin(); it != m_vecPbPropItemRef.end(); ++it)
		{
			PROPITEM* pItem = (*it);
			if (pItem != NULL)
			{
				::VariantClear(&pItem->var);	//the subpb is auto release
				delete pItem;
			}
		}
		m_vecPbPropItemRef.clear();

		return S_OK;
	}

public:
	STDMETHOD_(LONG, GetPropCount)()
	{
		return (LONG)m_vecPbPropItemRef.size();
	}

	STDMETHOD(GetProp)(LONG idx, IOPROPID* pPropID, const VARIANT** pVar)
	{
		if (idx < 0 || idx >= m_vecPbPropItemRef.size())
			return E_INVALIDARG;
		PROPITEM* pItem = m_vecPbPropItemRef[idx];
		if (pItem == NULL)
			return E_UNEXPECTED;
		if (pPropID != NULL)
			*pPropID = pItem->id;
		if (pVar != NULL)
			*pVar = &pItem->var;
		return S_OK;
	}

	STDMETHOD_(LONG, FindProp)(IOPROPID propID, const VARIANT** pVar)
	{
		for (PBPROPITEMREFVECTOR::iterator it = m_vecPbPropItemRef.begin(); it != m_vecPbPropItemRef.end(); ++it)
		{
			PROPITEM* pItem = (*it);
			if (pItem == NULL)
				continue;
			if (pItem->id == propID)
			{
				if (pVar != NULL)
					*pVar = &pItem->var;
				return (LONG)(it - m_vecPbPropItemRef.begin());
			}
		}
		return -1;
	}

private:
	struct PROPITEM {
		IOPROPID id;
		VARIANT var;
	};
	typedef std::vector<PROPITEM*>	PBPROPITEMREFVECTOR;
	PBPROPITEMREFVECTOR m_vecPbPropItemRef;

public:	//com
	DECLARE_COMCLASS(KAdaptAttr2Pb, IIOPropBag)
};


///////////////////////////////////////////////////////////////////////////
//acceptor & handler

//acceptor 2 handler
class KAdaptIOAcc2ContHdl : public IKContentHandler
{
public:
	KAdaptIOAcc2ContHdl() : m_pIOAcc(NULL), m_contID(0) {}
	~KAdaptIOAcc2ContHdl() {Clear();}

public:
	HRESULT SetIOAcc(IIOAcceptor* pAcc, IOTAGID contID) {Clear(); KS_ASSIGN(m_pIOAcc, pAcc); m_contID = contID; return S_OK;}
	HRESULT Clear() {KS_RELEASE(m_pIOAcc); m_contID = 0; return S_OK;}

public:
    STDPROC StartElement(
		IN ELEMENTID uElementID)
	{
		IOTAGID tagid = (IOTAGID)uElementID;
		return m_pIOAcc->BeginTag(tagid);
	}
	STDPROC AddAttributes(
		IN IKAttributes* pAttributes)
	{
		KComObjectPtr<KAdaptAttr2Pb> spPB(create_instance);
		spPB->SetAttr(pAttributes);
		_CHECK_PROPBAGLIFE(spPB);
		return m_pIOAcc->AddPropBag(spPB);
	}
    STDPROC AddContent(
		IN CONTENTVALUE_PTR pContent)
	{
		VARIANT* pVar = (VARIANT*)pContent;
		return m_pIOAcc->AddContent(m_contID, pVar);
	}
	STDPROC EndElement(
		IN ELEMENTID uElementID)
	{
		IOTAGID tagid = (IOTAGID)uElementID;
		return m_pIOAcc->EndTag(tagid);
	}
	STDPROC StartDocument(
		IN UINT nReservedParam)
	{
		return S_OK;
	}
    STDPROC EndDocument(
		IN BOOL fAbort)
	{
		return S_OK;
	}

private:
	IIOAcceptor* m_pIOAcc;
	IOTAGID m_contID;

public:
	DECLARE_COMCLASS(KAdaptAcc2ContHdl, IKContentHandler)
};


//handler 2 acceptor
class KAdaptContHdl2Acc : public IIOAcceptor
{
public:
	KAdaptContHdl2Acc() : m_pContHdl(NULL), m_deep(0) {}
	~KAdaptContHdl2Acc() {Clear();}

public:
	HRESULT SetContHdl(IKContentHandler* pContHdl) {Clear(); KS_ASSIGN(m_pContHdl, pContHdl); return S_OK;}
	HRESULT Clear() {m_deep = 0; KS_RELEASE(m_pContHdl); return S_OK;}

public:
	STDMETHOD(BeginTag)(IOTAGID tagID)
	{
		if (m_deep == 0)
		{
			if (FAILED(m_pContHdl->StartDocument(0)))
				return E_ABORT;
		}

		ELEMENTID elid = (ELEMENTID)tagID;
		HRESULT hr = m_pContHdl->StartElement(elid);
		if (FAILED(hr))
		{
			if (m_deep == 0)
				m_pContHdl->EndDocument(TRUE);
			return hr;
		}

		++ m_deep;
		return hr;
	}
	STDMETHOD(AddPropBag)(IIOPropBag* pPropBag)
	{
		KAdaptPb2Attr attr;
		attr.SetPB(pPropBag);
		HRESULT hr = m_pContHdl->AddAttributes(&attr);
		if (hr == E_ABORT || hr == E_ACCESSDENIED)
		{
			m_pContHdl->EndDocument(TRUE);
			m_deep = 0;
		}
		return hr;
	}
	STDMETHOD(AddContent)(IOTAGID contID, VARIANT* pVar)
	{
		//unuse contID ...
		ATTRVALUE* pCont = (ATTRVALUE*)pVar;
		HRESULT hr = m_pContHdl->AddContent(pCont);
		if (hr == E_ABORT || hr == E_ACCESSDENIED)
		{
			m_pContHdl->EndDocument(TRUE);
			m_deep = 0;
		}
		return hr;
	}
	STDMETHOD(EndTag)(IOTAGID tagID)
	{
		ELEMENTID elid = (ELEMENTID)tagID;
		HRESULT hr = m_pContHdl->EndElement(elid);
		if (FAILED(hr))
		{
			if (hr == E_ABORT || hr == E_ACCESSDENIED)
			{
				m_pContHdl->EndDocument(TRUE);
				m_deep = 0;
			}
		}
		else
		{
			-- m_deep;
			if (m_deep == 0)
				hr = m_pContHdl->EndDocument(FALSE);
		}
		return hr;
	}

private:
	IKContentHandler* m_pContHdl;
	ULONG m_deep;

public:
	DECLARE_COMCLASS(KAdaptContHdl2Acc, IIOAcceptor)
};


///////////////////////////////////////////////////////////////////////////
//iosource & contsource

//for iosource 2 contsource
class KAdaptIOSrc2ContSrc : public IKContentSource
{
public:
	KAdaptIOSrc2ContSrc() : m_pIOSrc(NULL) {}
	~KAdaptIOSrc2ContSrc() {Clear();}

public:
	HRESULT SetIOSrc(IIOSource* pIOSrc) {Clear(); KS_ASSIGN(m_pIOSrc, pIOSrc); return S_OK;}
	HRESULT Clear() {KS_RELEASE(m_pIOSrc); return S_OK;}

public:
	STDPROC Transfer(
		IN IKContentHandler* pHandler)
	{
		KComObjectPtr<KAdaptContHdl2Acc> spAcc(create_instance);
		spAcc->SetContHdl(pHandler);
		HRESULT hr = m_pIOSrc->Translate(spAcc);
		if (hr == E_ABORT)
			hr = E_ACCESSDENIED;
		return hr;
	}
	STDPROC Close()
	{
		return S_OK;
	}

private:
	IIOSource* m_pIOSrc;

public:
	DECLARE_COMCLASS(KAdaptIOSrc2ContSrc, IKContentSource)
};

//contsource 2 iosource
class KAdaptContSrc2IOSrc : public IIOSource
{
public:
	KAdaptContSrc2IOSrc() : m_pContSrc(NULL), m_contID(0) {}
	~KAdaptContSrc2IOSrc() {Clear();}

public:
	HRESULT SetContSrc(IKContentSource* pContSrc, IOTAGID contID) {Clear(); KS_ASSIGN(m_pContSrc, pContSrc); m_contID = contID; return S_OK;}
	HRESULT Clear() {KS_RELEASE(m_pContSrc); m_contID = 0; return S_OK;}

public:
	STDMETHOD(Translate)(IIOAcceptor* pAcceptor)
	{
		KComObjectPtr<KAdaptIOAcc2ContHdl> spHdl(create_instance);
		spHdl->SetIOAcc(pAcceptor, m_contID);
		HRESULT hr1 = m_pContSrc->Transfer(spHdl);
		if (hr1 == E_ACCESSDENIED)
			return hr1;
		HRESULT hr2 = m_pContSrc->Close();
		if (FAILED(hr1))
			return hr1;
		return hr2;
	}

private:
	IKContentSource* m_pContSrc;
	IOTAGID m_contID;

public:
	DECLARE_COMCLASS(KAdaptContSrc2IOSrc, IIOSource)
};




///////////////////////////////////////////////////////////////////////////
// -------------------------------------------------------------------------


// -------------------------------------------------------------------------
/*
@class KImpAcc2Elem
@brief
	������: IIOAcceptor �� IKElementHandler��
@remark
@*/
class KImpAcc2Elem : public IKElementHandler
{
private:
	IIOAcceptor* m_pAccExtern;
public:
	KImpAcc2Elem()
	{
		m_pAccExtern = NULL;
	}
	~KImpAcc2Elem()
	{
		KS_RELEASE(m_pAccExtern);
	}
public:
	/*
	@fn Attach
	@brief
		�������������һ��IIOAcceptor��
		����������Clear�������ú��ڴ˱����á�
	@arg [in] pAccExtern
		Ҫ��������IIOAcceptor�ӿڡ�
	@return
	@remark
	@*/
	STDMETHODIMP_(VOID) Attach(IN IIOAcceptor* pAccExtern)
	{
		KS_ASSIGN(m_pAccExtern, pAccExtern);
	}
	/*
	@fn Clear
	@brief
		ȡ�����κνӿڵĹ�����
	@return
	@remark
	@*/
	STDMETHODIMP_(VOID) Clear()
	{
		KS_RELEASE(m_pAccExtern);
	}

public:
    STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs)
	{
		HRESULT hr = m_pAccExtern->BeginTag(uElementID);
		if (FAILED(hr)) return hr;

		KComObjectPtr<KAdaptAttr2Pb> spPB(create_instance);
		spPB->SetAttr(pAttrs);
		_CHECK_PROPBAGLIFE(spPB);
		return m_pAccExtern->AddPropBag(spPB);
	}
    STDMETHODIMP AddContent(
		IN CONTENTVALUE_PTR pContent)
	{
		return m_pAccExtern->AddContent(0, (VARIANT*)pContent);
	}
	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID)
	{
		return m_pAccExtern->EndTag(uElementID);
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		*ppHandler = this;
		this->AddRef();
		return S_OK;
	}
	
	DECLARE_COMCLASS(KImpAcc2Elem, IKElementHandler)
};

// -------------------------------------------------------------------------
/*
@class KImpElem2Acc
@brief
	������: IKElementHandler �� IIOAcceptor��
@remark
@*/
class KImpElem2Acc : public IIOAcceptor
{
private:
	class _ElemDisp : public KFakeUnknown<KElementDispatcher>
	{
	public:
		STDMETHODIMP StartDocument(IN UINT nReservedParam)
		{
			return S_OK;
		}
		STDMETHODIMP EndDocument(IN BOOL fAbort)
		{
			return S_OK;
		}
	};
	_ElemDisp m_ElemDisp;

public:
	/*
	@fn Attach
	@brief
		�������������һ��IKElementHandler�ӿڣ��Ҹýӿ��Ǵ���tagIDָ����ǩ�Ľӿڡ�
		�ɶ�ε������������
	@arg [in] tagID
		��IIOAcceptor�ӿڵĿɽ��ܵĸ���ǩ��
	@arg [in] pHostHandler
		һ��ElementHandler�ӿڣ��ýӿ��Ǵ���tagIDָ����ǩ�Ľӿڡ�
	@return
		@val S_OK
			�ɹ���
		@val E_FAIL
			һ���Դ���
	@remark
	@*/
	STDMETHODIMP Attach(IN ELEMENTID tagID, IN IKElementHandler* pHostHandler)
	{
		return m_ElemDisp.Init(tagID, pHostHandler);
	}

public:
	STDMETHODIMP BeginTag(IN IOTAGID tagID)
	{
		return m_ElemDisp.StartElement(tagID);
	}
	STDMETHODIMP AddPropBag(IN IIOPropBag* pPropBag)
	{
		if (pPropBag)
		{
			KAdaptPb2Attr Attr;
			Attr.SetPB(pPropBag);
			return m_ElemDisp.AddAttributes(&Attr);
		}
		else
			return m_ElemDisp.AddAttributes(NULL);
	}
	STDMETHODIMP AddContent(IN IOTAGID contID, IN VARIANT* pVar)
	{
		return m_ElemDisp.AddContent((CONTENTVALUE_PTR)pVar);
	}
	STDMETHODIMP EndTag(IN IOTAGID tagID)
	{
		return m_ElemDisp.EndElement(tagID);
	}

	DECLARE_COMCLASS(KImpElem2Acc, IIOAcceptor)
};

// --------------------------------------------------------------------------

#endif // __ACC2SAX_H__
