//--------------------------------------------------------------------------
//	�ļ���		��	ioacceptor/ioacceptor.h
//	������		��	
//	����ʱ��	��	2003-9-16 10:55:31
//	��������	��	
//--------------------------------------------------------------------------
#ifndef __IOACCEPTOR_H__
#define __IOACCEPTOR_H__

#ifndef __KSO_IO_FILTER_H__
#include <kso/io/filter.h>
#endif

//#define X_USE_KSOFILTER

//--------------------------------------------------------------------------

typedef unsigned long _IOTHEID;
typedef _IOTHEID IOTAGID;
typedef _IOTHEID IOPROPID;

//--------------------------------------------------------------------------

//for VARIANT
#define VT_PROPBAG	VT_UNKNOWN		//����VT
#define ppbVal		punkVal			//����val

//--------------------------------------------------------------------------
#if defined(X_USE_KSOFILTER)
#include "iowrapper.h"
#define IIOPropBag		IIOPropBagWrapper
#define IIOAcceptor		IIOAcceptorWrapper
#define IIOSource		IIOSourceWrapper

#else
//--------------------------------------------------------------------------

#if defined(X_ATTRLIST_NOADDREF)
#define ATTRLIST_BASE
#else
#define ATTRLIST_BASE	: IUnknown
#endif

interface IIOPropBag ATTRLIST_BASE
{
	STDMETHOD_(LONG, GetPropCount)() PURE;
	STDMETHOD(GetProp)(LONG idx, IOPROPID* pPropID, const VARIANT** pVar) PURE;

	STDMETHOD_(LONG, FindProp)(IOPROPID propID, const VARIANT** pVar) PURE;
};

interface IIOAcceptor : public IUnknown
{//����E_ABORT��ʾ����ֹ��
	STDMETHOD(BeginTag)(IOTAGID tagID) PURE;	//��E_ABORT������E_XXX��ʾ�����ԡ�
	STDMETHOD(AddPropBag)(IIOPropBag* pPropBag) PURE;
	STDMETHOD(AddContent)(IOTAGID contID, VARIANT* pVar) PURE;
	STDMETHOD(EndTag)(IOTAGID tagID) PURE;
};

interface IIOSource : public IUnknown
{//����ʱ����IIOAcceptor�Ĵ���ֵ������E_ACCESSDENIED��ʧ��
	STDMETHOD(Translate)(IIOAcceptor* pAcceptor) PURE;
};

//--------------------------------------------------------------------------

DEFINE_IID(IIOPropBag, "2165A50D-A3F6-4b0e-A981-1A7852BB588A", 
		   0x2165a50d, 0xa3f6, 0x4b0e, 0xa9, 0x81, 0x1a, 0x78, 0x52, 0xbb, 0x58, 0x8a);

#define IID_IIOPropBag	__uuid(IIOPropBag)
#define IID_IIOAcceptor	__uuid(IKContentHandler)
#define IID_IIOSource	__uuid(IKContentSource)

//--------------------------------------------------------------------------

#endif

#endif //__IOACCEPTOR_H__

//--------------------------------------------------------------------------
