// -------------------------------------------------------------------------
//	�ļ���		��	ioacceptor/propbagbase.h
//	������		��	nature(����)
//	����ʱ��	��	2003-10-24 11:22:09
//	��������	��	
// -------------------------------------------------------------------------
#ifndef __IOACCEPTOR_PROPBAGBASE_H__
#define __IOACCEPTOR_PROPBAGBASE_H__

#include "stdarg.h"
#include <vector>

#include "kfc/comobj.h"
#include "ioacceptor.h"
#include "stl/algorithm.h"

#ifdef _DEBUG
	class KPropBag;
	#define IID_KPropBag	__uuid(KPropBag)
	DEFINE_IID(KPropBag,"BDCDB71B-1B4B-4d4b-B7D2-989B5C3BACED",
		0xbdcdb71b, 0x1b4b, 0x4d4b,0xb7, 0xd2, 0x98, 0x9b, 0x5c, 0x3b, 0xac, 0xed);
#endif //_DEBUG

// -------------------------------------------------------------------------

class KPropBag : public IIOPropBag
{
public: //construct/destruct
	KPropBag()
	{}
	virtual ~KPropBag()
	{
		for (PropList_Type::iterator it = m_PropList.begin(); it != m_PropList.end(); ++it)
			VariantClear(&(*it).Var);
	}

private:
	struct Prop_Type
	{
		IOPROPID Id;
		VARIANT  Var;
		Prop_Type(IOPROPID id, const VARIANT& var) : Id(id), Var(var)
		{}
		Prop_Type(IOPROPID id, LONG lVar) : Id(id)
		{
			Var.vt = VT_I4;
			Var.lVal = lVar;
		}
		Prop_Type(IOPROPID id, IIOPropBag* pPBAttach) : Id(id)
		{
			Var.vt = VT_PROPBAG;
			Var.punkVal = pPBAttach;
		}
	};
	typedef std::vector<Prop_Type> PropList_Type;
	PropList_Type m_PropList;

	struct Find
	{
		Find(IOPROPID id) : m_id(id)
		{
		}

		bool operator () (const Prop_Type& p)
		{
			return (p.Id == m_id);
		}

		IOPROPID m_id;
	};

public: //IIOPropBag
	STDMETHODIMP_(LONG) GetPropCount()
	{
		return m_PropList.size();
	}
	STDMETHODIMP GetProp(IN LONG nIndex, OUT IOPROPID* pPropID, OUT const VARIANT** ppVar)
	{
		if (nIndex < 0 || nIndex >= (LONG)m_PropList.size())
			return E_FAIL;
		Prop_Type& Prop = *(m_PropList.begin() + nIndex);
		if (pPropID != NULL)
			*pPropID = Prop.Id;
		if (ppVar != NULL)
			*ppVar = &(Prop.Var);
		return S_OK;
	}
	STDMETHODIMP_(LONG) FindProp(IN IOPROPID PropID, OUT const VARIANT** ppVar)
	{
		LONG cnt = m_PropList.size();
		for (LONG i = cnt - 1; i >= 0; --i)
		{
			const Prop_Type& Prop = m_PropList.at(i);
			if (Prop.Id == PropID)
			{
				if (ppVar)
					*ppVar = &(Prop.Var);
				return i;
			}
		}
		return -1;
	}

public: //operation
	STDMETHODIMP_(LONG) AddProp(IN IOPROPID PropID, IN OUT VARIANT* pVar)
	{
		if (pVar == NULL)
			return -1;
		m_PropList.push_back(Prop_Type(PropID, *pVar));
		VariantInit(pVar);
		return m_PropList.size() - 1;
	}

	STDMETHODIMP_(void) AddProp(IN IOPROPID PropID, IN LONG nPropVal)
	{
		Prop_Type rhs(PropID, nPropVal);
		m_PropList.push_back(rhs);
	}

	STDMETHODIMP_(LONG) AddUniqueProp(IN IOPROPID PropID, IN OUT VARIANT* pVar)
	{
		if (pVar == NULL)
			return -1;

		PropList_Type::iterator it = std::find_if(m_PropList.begin(), 
													m_PropList.end(), 
													Find(PropID));
		if (it == m_PropList.end()) //not find
			m_PropList.push_back(Prop_Type(PropID, *pVar));
		else //find
		{
			VariantClear(&it->Var);
			it->Var = *pVar;
		}
		VariantInit(pVar);
		return m_PropList.size() - 1;
	}

	STDMETHODIMP InsertProp(IN LONG nIndex, IN IOPROPID PropID, IN OUT VARIANT* pVar)
	{
		if (pVar == NULL || nIndex < 0)
			return E_FAIL;
		m_PropList.insert(m_PropList.begin() + nIndex, Prop_Type(PropID, *pVar));
		VariantInit(pVar);
		return S_OK;
	}
	STDMETHODIMP SetProp(IN LONG nIndex, IN const IOPROPID* pPropID, IN OUT VARIANT* pVar)
	{
		if (nIndex < 0 || nIndex >= (LONG)m_PropList.size())
			return E_FAIL;
		Prop_Type& PropRef = *(m_PropList.begin() + nIndex);
		if (pPropID != NULL)
			PropRef.Id = *pPropID;
		if (pVar != NULL)
		{
			VariantClear(&PropRef.Var);
			PropRef.Var = *pVar;
			VariantInit(pVar);
		}
		return S_OK;
	}
	STDMETHODIMP RemoveProp(IN LONG nIndex)
	{
		if (nIndex < 0 || nIndex >= (LONG)m_PropList.size())
			return E_FAIL;
		PropList_Type::iterator it = m_PropList.begin() + nIndex;
		VariantClear(&((*it).Var));
		m_PropList.erase(it);
		return S_OK;		
	}
	STDMETHODIMP DetachProp(IN LONG nIndex, OUT IOPROPID* pPropID, OUT VARIANT* pVar)
	{
		if (nIndex < 0 || nIndex >= (LONG)m_PropList.size())
			return E_FAIL;
		Prop_Type& Prop = m_PropList[nIndex];
		if (pPropID != NULL)
			*pPropID = Prop.Id;
		if (pVar != NULL)
			*pVar = Prop.Var;
		else
			VariantClear(&Prop.Var);
		m_PropList.erase(m_PropList.begin() + nIndex);
		return S_OK;
	}
	STDMETHODIMP Clear()
	{
		for (PropList_Type::iterator it = m_PropList.begin(); it != m_PropList.end(); ++it)
			VariantClear(&(*it).Var);
		m_PropList.clear();
		return S_OK;
	}

public:
#if !defined(X_ATTRLIST_NOADDREF)
	BEGIN_QUERYINTERFACE(IIOPropBag)
#ifdef _DEBUG
		ADD_INTERFACE(KPropBag)
#endif //_DEBUG
	END_QUERYINTERFACE()

	DECLARE_CLASS(KPropBag)
#endif
};

// -------------------------------------------------------------------------

#include "propbagwrapper.h"

#define KPropBag KPropBagWrapper

// -------------------------------------------------------------------------

class KAttributesPtr
{
private:
	KPropBag* _ptr;

private:
	KAttributesPtr(const KAttributesPtr& src)
	{
		_ptr = src._ptr;
		_ptr->AddRef();
	}
	void operator=(const KAttributesPtr& src);

public:
	KAttributesPtr(enum_create_instance _create_instance)
	{
#if defined(X_ATTRLIST_NOADDREF)
		_ptr = new KPropBag;
#else
		_ptr = KS_NEW(KPropBag);
#endif
	}
	~KAttributesPtr()
	{
#if defined(X_ATTRLIST_NOADDREF)
		delete _ptr;
#else
		if (_ptr)
			_ptr->Release();
#endif
	}
	KPropBag* operator->() const
	{
		return _ptr;
	}
	operator KPropBag*() const
	{
		return _ptr;
	}
#if !defined(X_ATTRLIST_NOADDREF)
	KPropBag* detach()
	{
		KPropBag* p = _ptr;
		_ptr = NULL;
		return p;
	}
#endif
};

typedef KAttributesPtr KPropBagPtr;

// -------------------------------------------------------------------------

#endif /* __IOACCEPTOR_PROPBAGBASE_H__ */
