// -------------------------------------------------------------------------
//	�ļ���		��	ioacceptor/iowrapper2.h
//	������		��	nature(����)
//	����ʱ��	��	2004-3-22 11:14:21
//	��������	��	
// -------------------------------------------------------------------------
#ifndef __IOACCEPTOR_IOWRAPPER2_H__
#define __IOACCEPTOR_IOWRAPPER2_H__

// -------------------------------------------------------------------------

#include <kso/io/filter.h>
#include <kfc/comobj.h>

// -------------------------------------------------------------------------
//	ע����ΪVARIANT����ATTRVALUE��ʱ��
//	ATTRVALUE��û�ж���Դ������Ȩ�ġ�

class KPropBagAdapter : public IKAttributes
{
	ks_stdptr<IIOPropBag> m_ptrPropBag;
	struct ATTRNODE
	{
		ATTRID AttrID;
		ATTRVALUE* pAttrValue;
		ATTRNODE() : AttrID(0), pAttrValue(NULL) {}
	};
	typedef std::vector<ATTRNODE> AttrList_Type;
	AttrList_Type m_listpAttr;
public:
	~KPropBagAdapter()
	{
		AttrList_Type::iterator it = m_listpAttr.begin();
		for (; it != m_listpAttr.end(); ++it)
		{
			ATTRVALUE*& pAttr = (*it).pAttrValue;
			if (!pAttr)
				continue;
			if (pAttr->vt == KsoVariant::vtAttrList)
				delete (KPropBagAdapter*)(pAttr->lVal);
			pAttr->vt = KsoVariant::vtEmpty;
			delete pAttr;
		}
	}
public:
    STDPROC_(UINT) Count()
	{
		return m_ptrPropBag->GetPropCount();
	}
	STDPROC GetAt(
		IN UINT index,
		OUT ATTRID* pAttrID,
		OUT ATTRVALUE_PTR* ppAttrValue)
	{
		const VARIANT* pVar = NULL;
		IOPROPID idSrc;
		HRESULT hr = E_FAIL;

		if (index < m_listpAttr.size() && m_listpAttr[index].pAttrValue)
		{
			if (pAttrID)
				*pAttrID = m_listpAttr[index].AttrID;
			if (ppAttrValue)
				*ppAttrValue = m_listpAttr[index].pAttrValue;
			return S_OK;
		}

		hr =  m_ptrPropBag->GetProp(index, &idSrc, &pVar);
		if (FAILED(hr))
			return E_FAIL;

		_Mapped2AttrList(index, idSrc, pVar);

		if (pAttrID)
			*pAttrID = m_listpAttr[index].AttrID;
		if (ppAttrValue)
			*ppAttrValue = m_listpAttr[index].pAttrValue;

		return S_OK;
	}
	STDPROC_(INT) GetIndex(
		IN ATTRID uAttrID,
		OUT ATTRVALUE_PTR* ppAttrValue)
	{
		const VARIANT* pVar = NULL;
		INT index = m_ptrPropBag->FindProp(uAttrID, &pVar);
		if (index < 0)
			return index;

		if ( index < m_listpAttr.size() && m_listpAttr[index].pAttrValue)
		{
			if (ppAttrValue)
				*ppAttrValue = m_listpAttr[index].pAttrValue;
			return S_OK;
		}
		
		_Mapped2AttrList(index, uAttrID, pVar);

		if (ppAttrValue)
			*ppAttrValue = m_listpAttr[index].pAttrValue;

		return index;
	}
	STDMETHODIMP_(void) Init(IIOPropBag* pPropBag)
	{
		m_ptrPropBag = pPropBag;
	}
private:
	VOID _Mapped2AttrList(IN INT index, IN IOPROPID idProp, IN const VARIANT* pVar)
	{
		ATTRNODE AttrNode;
		AttrNode.AttrID = idProp;
		AttrNode.pAttrValue = new ATTRVALUE;
		Var2KsoVar(pVar, AttrNode.pAttrValue);		
		if (index >= m_listpAttr.size())
			m_listpAttr.resize(index + 1);
		m_listpAttr[index] = AttrNode;
	}
public:
	static VOID Var2KsoVar(const IN VARIANT* pVar, OUT KsoVariant* pKsoVar)
	{
		ASSERT(pVar && pKsoVar);
		ASSERT(sizeof(VARIANT) >= sizeof(KsoVariant));
		memcpy((VOID*)pKsoVar, pVar, sizeof(KsoVariant));

 		if (pVar->vt == VT_UNKNOWN)
		{
			pKsoVar->vt = KsoVariant::vtAttrList;
			pKsoVar->lVal = (LONG)new KPropBagAdapter;
			((KPropBagAdapter*)pKsoVar->lVal)->Init((IIOPropBag*)pVar->punkVal);
		}
	}
	static VOID Var2KsoVarNoneAttr(const IN VARIANT* pVar, OUT KsoVariant* pKsoVar)
	{
		ASSERT(pVar && pKsoVar);
		ASSERT(sizeof(VARIANT) >= sizeof(KsoVariant));
		memcpy((VOID*)pKsoVar, pVar, sizeof(KsoVariant));
		if (pVar->vt == VT_UNKNOWN)
			if (pVar->punkVal) pVar->punkVal->AddRef();
		if (pVar->vt == VT_BSTR)
		{
			if (pVar->bstrVal)
			{
				ks_bstr bstr(pVar->bstrVal, SysStringLen(pVar->bstrVal));
				pKsoVar->bstrVal = bstr.detach();
			}
		}
		if (pVar->vt == VT_ARRAY)
			ASSERT(0); // ��֧��
	}

public:
	DECLARE_CLASS(KPropBagAdapter)
};

class KAcceptorAdapter : public IIOAcceptor
{
	ks_stdptr<IKContentHandler> m_ptrAcc;
public:
	STDMETHODIMP BeginTag(IOTAGID tagID)
	{
		return m_ptrAcc->StartElement(tagID);
	}
	STDMETHODIMP AddPropBag(IIOPropBag* pPropBag)
	{
		KComObjectPtr<KPropBagAdapter> ptrPropBagAdapter(create_instance);
		ptrPropBagAdapter->Init(pPropBag);
		return m_ptrAcc->AddAttributes(ptrPropBagAdapter);
	}
	STDMETHODIMP AddContent(IOTAGID contID, VARIANT* pVar)
	{
		KsoVariant KsoVar;
		KPropBagAdapter::Var2KsoVarNoneAttr(pVar, &KsoVar);
		HRESULT hr = E_FAIL;
		hr = m_ptrAcc->AddContent(&KsoVar);
		KS_CHECK(hr);
	KS_EXIT:
		return hr;
	}
	STDMETHODIMP EndTag(IOTAGID tagID)
	{
		return m_ptrAcc->EndElement(tagID);
	}
	STDMETHODIMP StartDocument()
	{
		return m_ptrAcc->StartDocument(NULL);
	}
    STDMETHODIMP EndDocument()
	{
		return m_ptrAcc->EndDocument(FALSE);
	}
	STDMETHODIMP_(void) Init(IKContentHandler* pAcc)
	{
		m_ptrAcc = pAcc;
	}
public:
	BEGIN_QUERYINTERFACE(IIOAcceptor)
	END_QUERYINTERFACE()
	DECLARE_CLASS(KAcceptorAdapter)
};

// -------------------------------------------------------------------------

#endif /* __IOACCEPTOR_IOWRAPPER2_H__ */
