/* -------------------------------------------------------------------------
//	�ļ���		��	ioacceptor/propbagwrapper.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-3-8 18:13:18
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IOACCEPTOR_PROPBAGWRAPPER_H__
#define __IOACCEPTOR_PROPBAGWRAPPER_H__

#ifndef __STL_VECTOR_H__
#include <stl/vector.h>
#endif

#ifndef __KFC_VARIANT_H__
#include <kfc/variant.h>
#endif

#define stl_vector_adapter KfcVector

#ifndef VT_ATTRLIST
#if defined(X_ATTRLIST_NOADDREF)
#define VT_ATTRLIST		VT_UINT
#else
#define VT_ATTRLIST		VT_UNKNOWN
#endif
#endif

// -------------------------------------------------------------------------

class KPropBagWrapper : public IIOPropBag
{
private:
	typedef IOPROPID ATTRID;
	typedef KComVariant ATTRVALUE;
	typedef const VARIANT* ATTRVALUE_PTR;

	struct _AttrPair
	{
	public:
		ATTRID idAttr;
		ATTRVALUE valAttr;

	private:
		void operator=(const _AttrPair& rAttr)
		{
			ASSERT(valAttr.vt == VT_EMPTY);
			ASSERT(rAttr.valAttr.vt == VT_EMPTY);
		}
		
	public:
		_AttrPair() {}
		_AttrPair(const _AttrPair& rAttr)
		{
			ASSERT(valAttr.vt == VT_EMPTY);
			ASSERT(rAttr.valAttr.vt == VT_EMPTY);
		}
		void _Init(ATTRID id, ATTRVALUE* pAttrValue)
		{
			idAttr = id;
			memcpy(&valAttr, pAttrValue, sizeof(ATTRVALUE));
			pAttrValue->vt = VT_EMPTY;
		}
		void _Init(ATTRID id, VARIANT* pAttrValue)
		{
			idAttr = id;
			memcpy(&valAttr, pAttrValue, sizeof(ATTRVALUE));
			pAttrValue->vt = VT_EMPTY;
		}
		void _Init(ATTRID id, int nValue)
		{
			idAttr = id;
			valAttr.vt = VT_I4;
			valAttr.lVal = nValue;
		}
		void _Init(ATTRID id, UINT nValue)
		{
			idAttr = id;
			valAttr.vt = VT_I4;
			valAttr.lVal = nValue;
		}
		void _Init(ATTRID id, DWORD nValue)
		{
			idAttr = id;
			valAttr.vt = VT_I4;
			valAttr.lVal = nValue;
		}
		void _Init(ATTRID id, LONG nValue)
		{
			idAttr = id;
			valAttr.vt = VT_I4;
			valAttr.lVal = nValue;
		}
		void _Init(ATTRID id, LPCWSTR wcsValue)
		{
			idAttr = id;
			valAttr.vt = VT_BSTR;
			valAttr.bstrVal = SysAllocString(wcsValue);
		}
		void _Init(ATTRID id, IIOPropBag* pAttrList)
		{
			idAttr = id;
			valAttr.vt = VT_ATTRLIST;
			valAttr.lVal = (UINT)pAttrList;
#if !defined(X_ATTRLIST_NOADDREF)
			if (pAttrList)
				pAttrList->AddRef();
#endif
		}
		template <class ValueType>
		void _Assign(ATTRID id, ValueType value)
		{
			valAttr.Clear();
			_Init(id, value);
		}
		void _Detach(ATTRID* pid, VARIANT* pAttrValue)
		{
			*pid = idAttr;
			memcpy(pAttrValue, &valAttr, sizeof(ATTRVALUE));
			valAttr.vt = VT_EMPTY;
		}
	};

	typedef stl_vector_adapter<_AttrPair> attrlist_t;
	typedef attrlist_t::const_iterator iterator_t;

private:
	struct _FindOp
	{
		explicit _FindOp(ATTRID id) : m_id(id)
		{
		}

		bool operator () (const _AttrPair& p) const
		{
			return (p.idAttr == m_id);
		}
		ATTRID m_id;
	};

	attrlist_t m_attrs;

public:
    STDMETHODIMP_(LONG) GetPropCount()
	{
		return m_attrs.size();
	}

	STDMETHODIMP GetProp(
		IN LONG index,
		OUT ATTRID* pAttrID,
		OUT ATTRVALUE_PTR* ppAttrValue)
	{
		if (index < m_attrs.size())
		{
			if (pAttrID)
				*pAttrID = m_attrs[index].idAttr;
			if (ppAttrValue)
				*ppAttrValue = &m_attrs[index].valAttr;
			return S_OK;
		}
		return KFC_E_OUTOFRANGE;
	}

	STDMETHODIMP_(LONG) FindProp(
		IN ATTRID uAttrID,
		OUT ATTRVALUE_PTR* ppAttrValue)
	{
		const attrlist_t& attrs = m_attrs;

		for (iterator_t it = attrs.begin(); it != attrs.end(); ++it)
		{
			if (uAttrID == it->idAttr)
			{
				if (ppAttrValue)
					*ppAttrValue = &it->valAttr;
				return it - attrs.begin();
			}
		}
		return -1;
	}

public:
	template <class ValueType>
	STDMETHODIMP_(void) AddProp(
		IN ATTRID id,
		IN const ValueType& value)
	{
		m_attrs.insert(m_attrs.end())->_Init(id, value);
	}

	template <class ValueType>
	STDMETHODIMP_(void) AddUniqueProp(
		IN ATTRID id,
		IN const ValueType& value)
	{
		attrlist_t::iterator it = std::find_if(m_attrs.begin(),
												m_attrs.end(),
												_FindOp(id));

		if (it == m_attrs.end()) //not find
			m_attrs.insert(m_attrs.end())->_Init(id, value);
		else //find, and replace
			it->_Assign(id, value);
	}

	template <class ValueType>
	STDMETHODIMP SetProp(
		IN LONG index,
		IN ATTRID id,
		IN const ValueType& value)
	{
		ASSERT(index < m_attrs.size());

		m_attrs[index]._Assign(id, value);
		return S_OK;
	}

	template <class ValueType>
	STDMETHODIMP InsertProp(
		IN LONG index,
		IN ATTRID id,
		IN const ValueType& value)
	{
		ASSERT(index <= m_attrs.size());

		m_attrs.insert(m_attrs.begin()+index)->_Init(id, value);
		return S_OK;
	}

	STDMETHODIMP DetachProp(
		IN LONG index,
		OUT ATTRID* pAttrID,
		OUT VARIANT* pAttrValue)
	{
		ASSERT(index < m_attrs.size());

		m_attrs[index]._Detach(pAttrID, pAttrValue);
		m_attrs.erase(m_attrs.begin() + index);
		return S_OK;
	}

	STDMETHODIMP RemoveProp(
		IN LONG index)
	{
		ASSERT(index < m_attrs.size());

		m_attrs.erase(m_attrs.begin() + index);
		return S_OK;
	}
	
	STDMETHODIMP_(void) Clear()
	{
		m_attrs.clear();
	}

#if !defined(X_ATTRLIST_NOADDREF)
	BEGIN_QUERYINTERFACE(IIOPropBag)
	END_QUERYINTERFACE()
	DECLARE_CLASS(KPropBagWrapper)
#endif
};

// -------------------------------------------------------------------------

#endif /* __IOACCEPTOR_PROPBAGWRAPPER_H__ */
