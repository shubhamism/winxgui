/* -------------------------------------------------------------------------
//	�ļ���		��	bstoreparse.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 15:25:30
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __BSTOREPARSE_H__
#define __BSTOREPARSE_H__

// -------------------------------------------------------------------------
#include "stl/vector.h"

class KBseParse : public FBSE, public KBaseRef
{
public:
	KBseParse ();
	virtual ~KBseParse ();

	int  blipType;//MSOBLIPTYPE
	BSTR name;//
	IStream* m_pBlipData;		//for et
};

class KBStoreParse : public KBaseRef
{
public:
	KBStoreParse();
	virtual ~KBStoreParse();

public:
	STDMETHODIMP Parse (IStream* pStream);
	STDMETHODIMP QueryBse (int nIdex, KBseParse**);
	STDMETHODIMP_(int)		GetBSECnt ();
	
private:
	STDMETHODIMP CleanUp ();
protected:
	typedef std::vector<KBseParse*> KBSES;
	KBSES m_Bses;
};


// -------------------------------------------------------------------------
inline STDMETHODIMP_(int) 
KBStoreParse::GetBSECnt ()
{
	return m_Bses.size ();
}

// -------------------------------------------------------------------------

#endif /* __BSTOREPARSE_H__ */
