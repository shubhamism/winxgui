/* -------------------------------------------------------------------------
//	�ļ���		��	shapeprop.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 13:55:57
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __SHAPEPROP_H__
#define __SHAPEPROP_H__

#undef new
// -------------------------------------------------------------------------
//#include "KObjPropsTable.h"
class KObjProp;


class KShapeProp : public KBaseRef
{
public:
	KShapeProp();
	virtual ~KShapeProp ();	
	
	void* operator new (size_t size);
	void  operator delete (void*);
	
//	BEGIN_QUERYINTERFACE(IShapeProp)
//		ADD_INTERFACE(IMsoArray)
//		END_QUERYINTERFACE()
//	DECLARE_CLASS(KShapeProp)

public:
	// IShapeProp�ӿ�ʵ��
	STDMETHODIMP_(UINT) GetPropID();
	STDMETHODIMP_(int) GetLen();
	STDMETHODIMP_(void*) GetPropBuf();
	STDMETHODIMP_(int) GetFlags();
	// IMsoArray�ӿ�ʵ��
	STDMETHODIMP_(int) GetItemCnt();
	STDMETHODIMP_(int) GetItemSize();
	STDMETHODIMP_(void*) GetItemBuf();
	
	STDMETHODIMP_(void) SetShapeProp (KObjProp*);

private:
	KObjProp* m_pProp;
};

// -------------------------------------------------------------------------

#endif /* __SHAPEPROP_H__ */
