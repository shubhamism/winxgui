/* -------------------------------------------------------------------------
//	�ļ���		��	drawingcontainer.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 15:09:01
//	��������	��	
//
//	$Id: drawingcontainer.h,v 1.2 2005/06/25 02:54:23 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAWINGCONTAINER_H__
#define __DRAWINGCONTAINER_H__

// -------------------------------------------------------------------------
// struct _RGBARRAY

#pragma pack(1)

struct _RGBARRAY
{
	UINT32 nCount;
	UINT32 rgbArray[1];
};

#pragma pack()

// -------------------------------------------------------------------------
// class KColorScheme

class KColorScheme
{
private:
	_RGBARRAY* m_data;

public:
	KColorScheme() : m_data(NULL) {}

	STDMETHODIMP_(void) Destroy()
	{
		if (m_data)
		{
			free(m_data);
			m_data = NULL;
		}
	}

	STDMETHODIMP_(BOOL) Good() const
	{
		return m_data != NULL;
	}

	STDMETHODIMP_(UINT32) GetColor(UINT32 clrEncode) const
	{
		ASSERT(m_data != NULL);

		enum { msocolorFlagScheme = 0x08000000 };
		
		if (!(msocolorFlagScheme & clrEncode))
			return clrEncode;

		clrEncode &= ~msocolorFlagScheme;
		if (m_data == NULL || clrEncode >= m_data->nCount)
			return clrEncode;

		return m_data->rgbArray[clrEncode];
	}

public:
	STDMETHODIMP Parse(IStream* pStream);
};

// -------------------------------------------------------------------------
class KShape;
class KSolverContainer;
class KDrawingContainerParse;

class KDrawingContainer : public KBaseRef
{
public:
	KDrawingContainer();
	virtual ~KDrawingContainer ();

//	DECLARE_COMCLASS(KDrawingContainer, IDrawingContainer);	
	
public:
	// IDrawingContainer�ӿ�ʵ��
	STDMETHODIMP Parse(IStream* pStream);
	STDMETHODIMP GetBkShape(KShape**);
	STDMETHODIMP GetShapes(KShape**);
	STDMETHODIMP GetSolver(KSolverContainer**);
	STDMETHODIMP_(const KColorScheme&) GetColorScheme() const;

private:
	KDrawingContainerParse* m_pContainer;
};

// -------------------------------------------------------------------------
//STDAPI	CreateDrawingContainer(IDrawingContainer**);
// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
// $Log: drawingcontainer.h,v $
// Revision 1.2  2005/06/25 02:54:23  xushiwei
// ֧��ColorScheme������UpdateSchemeColor��
//

#endif /* __DRAWINGCONTAINER_H__ */
