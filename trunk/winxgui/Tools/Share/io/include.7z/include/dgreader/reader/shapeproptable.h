/* -------------------------------------------------------------------------
//	�ļ���		��	shapeproptable.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 14:10:18
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __SHAPEPROPTABLE_H__
#define __SHAPEPROPTABLE_H__

// -------------------------------------------------------------------------
class KShapeProp;
class KObjPropsTable;
class KObjProp;

class KShapePropTable : public KBaseRef 
{

public:
	KShapePropTable();
	virtual ~KShapePropTable ();
	
//	DECLARE_COMCLASS(KShapePropTable, IShapePropTable);
	
public:
	// IShapePropTable�ӿ�ʵ��
	STDMETHODIMP_(int) GetPropCnt();
	STDMETHODIMP GetProp(int nIdx, KShapeProp**);
	STDMETHODIMP QueryProp(int ID, KShapeProp**);
	STDMETHODIMP_(void) SetOPT(KObjPropsTable*);

	STDMETHODIMP QueryBoolProp(int tp, BOOL* pbv);
protected:
	STDMETHODIMP CreateShapeProp(KObjProp*, KShapeProp**);

private:
	KObjPropsTable* m_pOPT;
};

// -------------------------------------------------------------------------

#endif /* __SHAPEPROPTABLE_H__ */
