/* -------------------------------------------------------------------------
//	�ļ���		��	shape.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 9:55:11
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __SHAPE_H__
#define __SHAPE_H__

// -------------------------------------------------------------------------
#include "escherfmt/msoescher.h"

class KShapeParse;
class KShape;
class KShapePropTable;
class KShapeProp;
class KClientData;
class KClientTextBox;

class KShape : public KBaseRef
{
public:
	KShape();
	virtual ~KShape ();	
	
//	DECLARE_COMCLASS(KShape, IShape);
		
public:
	// IShape�ӿ�ʵ��
	STDMETHODIMP Parse(IStream* pStream);
	STDMETHODIMP GetChildCnt(int* pCnt);
	STDMETHODIMP GetChild(int nIdx, KShape**);
	
	STDMETHODIMP GetShapeUDefPropTable(KShapePropTable**);
	STDMETHODIMP GetShapePropTable(KShapePropTable**);
	STDMETHODIMP QueryProp(UINT ID, KShapeProp**);
	STDMETHODIMP QueryUDefProp(UINT ID, KShapeProp**);
	//��Ϊһ��Shape�п���û��OPT�����Խ�QueryDefaultPropŲ������Ա�֤�ܵ��õ�
	// LGH [1/4/2002]
//	STDMETHODIMP QueryDefaultProp(int ID, KShapeProp**);	
	STDMETHODIMP GetClientData(KClientData**);
	STDMETHODIMP GetClientTextBox(KClientTextBox**);
	
	STDMETHODIMP GetShapeType(MSOSPT* spt);
	STDMETHODIMP GetShapeID(MSOSPID* pID);
	STDMETHODIMP_(void*) GetAnchor(MSOANCHORUINT* pUint, int* pLen);
	STDMETHODIMP GetShapePropFlags(MSOSPFLAGS*);
	
	STDMETHODIMP_(void) SetShape(KShapeParse*);
	
	STDMETHODIMP_(BOOL) FindPropID(int);
	STDMETHODIMP_(BOOL) IsFilled();

	STDMETHODIMP GetGroupInitRect(OUT RECT* pRc);
public:
	KShapeParse* GetShapeParse()
	{
		return m_pShapeParse;
	}
private:	
	KShapeParse* m_pShapeParse;
};

// -------------------------------------------------------------------------

#endif /* __SHAPE_H__ */
