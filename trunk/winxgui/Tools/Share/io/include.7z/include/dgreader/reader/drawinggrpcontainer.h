/* -------------------------------------------------------------------------
//	�ļ���		��	drawinggrpcontainer.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 16:08:40
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DRAWINGGRPCONTAINER_H__
#define __DRAWINGGRPCONTAINER_H__

#include "escherfmt/msoescher.h"

// -------------------------------------------------------------------------
class KDrawingGrpContainerParse;
class KBStore;
class KShapePropTable;
class KObjPropsTable;

class KDrawingGrpContainer : public KBaseRef
{
public:
	KDrawingGrpContainer();
	virtual ~KDrawingGrpContainer ();
	
//	DECLARE_COMCLASS(KDrawingGrpContainer, IDrawingGrpContainer);
		
public:
	// IDrawingGrpContainer�ӿ�ʵ��
	STDMETHODIMP GetBStore(KBStore**);
	STDMETHODIMP Parse(IStream* pStream);
	STDMETHODIMP GetDefaultOPT(KShapePropTable**);
	STDMETHODIMP GetColorMRU(INT** ppColors, INT* pCnt);
	STDMETHODIMP GetSplitMenuColors(FSplitMenuColors** ppSplitColors);

	KObjPropsTable* GetRawOPT();
	
public:
	KDrawingGrpContainerParse* m_pContainer;
};

// -------------------------------------------------------------------------
//STDAPI CreateDrawGrpContainer(IDrawingGrpContainer**);
// -------------------------------------------------------------------------

#endif /* __DRAWINGGRPCONTAINER_H__ */
