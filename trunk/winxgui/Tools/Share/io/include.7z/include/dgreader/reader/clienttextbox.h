/* -------------------------------------------------------------------------
//	�ļ���		��	clienttextbox.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 10:45:18
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __CLIENTTEXTBOX_H__
#define __CLIENTTEXTBOX_H__

// -------------------------------------------------------------------------
class KClientTextBoxParse;
class KClientTextBox : public KBaseRef
{
public:
	KClientTextBox();
	virtual ~KClientTextBox ();
	
//	DECLARE_COMCLASS(KClientTextBox, IClientTextBox);
	
public:
	// IClientTextBox�ӿ�ʵ��
	STDMETHODIMP_(int)	GetTextBoxDataLen();
	STDMETHODIMP_(void*) GetTextBoxData();
	STDMETHODIMP_(void) SetClientTextBox (KClientTextBoxParse* pClientTextBox);

private:
	KClientTextBoxParse* m_pClientTextBoxParse;
};

// -------------------------------------------------------------------------

#endif /* __CLIENTTEXTBOX_H__ */
