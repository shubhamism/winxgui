/* -------------------------------------------------------------------------
//	�ļ���		��	bstore.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 15:25:30
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __BSTORE_H__
#define __BSTORE_H__

// -------------------------------------------------------------------------

class KBStoreParse;
class KBse;

class KBStore : public KBaseRef
{
public:
	KBStore();
	virtual ~KBStore();
	
public:
	// IBStore�ӿ�ʵ��
	STDMETHODIMP GetBSE(int nIdx, KBse**);
	STDMETHODIMP_(int) GetBSECnt();
	STDMETHODIMP_(void) SetBstore(KBStoreParse*);

private:
	KBStoreParse* m_pBstore;
};

// -------------------------------------------------------------------------

#endif /* __BSTORE_H__ */
