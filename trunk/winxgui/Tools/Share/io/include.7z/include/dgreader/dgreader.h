/* -------------------------------------------------------------------------
//	�ļ���		��	dgreader/dgreader.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-24 12:38:57
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DGREADER_DGREADER_H__
#define __DGREADER_DGREADER_H__

// -------------------------------------------------------------------------
#ifndef __IOHEADER_BASEREF_H__
#include "../ioheader/baseref.h"
#endif

#ifndef __DRAWINGCONTAINER_H__
#include "reader/drawingcontainer.h"
#endif // __DRAWINGCONTAINER_H__

#ifndef __DRAWINGGRPCONTAINER_H__
#include "reader/drawinggrpcontainer.h"
#endif // __DRAWINGGRPCONTAINER_H__

#ifndef __SHAPE_H__
#include "reader/shape.h"
#endif // __SHAPE_H__

#ifndef __CLIENTDATA_H__
#include "reader/clientdata.h"
#endif // __CLIENTDATA_H__

#ifndef __CLIENTTEXTBOX_H__
#include "reader/clienttextbox.h"
#endif // __CLIENTTEXTBOX_H__

#ifndef __SHAPEPROPTABLE_H__
#include "reader/shapeproptable.h"
#endif // __SHAPEPROPTABLE_H__

#ifndef __SHAPEPROP_H__
#include "reader/shapeprop.h"
#endif // __SHAPEPROPTABLE_H__

#ifndef __DGEXP_FILE_H__
#include "export/exp_file.h"
#endif __DGEXP_FILE_H__

#ifndef __BSE_H__
#include "reader/bse.h"
#endif //__BSE_H__

#ifndef __BSTORE_H__
#include  "reader/bstore.h"
#endif

#ifndef __BSTOREPARSE_H__
#include "reader/bstoreparse.h"
#endif //__BSTOREPARSE_H__
// -------------------------------------------------------------------------

#endif /* __DGREADER_DGREADER_H__ */
