/* -------------------------------------------------------------------------
//	�ļ���		��	clientdata.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 10:20:20
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __CLIENTDATA_H__
#define __CLIENTDATA_H__

// -------------------------------------------------------------------------
class KClientDataParse;

class KClientData : public KBaseRef
{
public:
	KClientData();
	virtual ~KClientData ();
	
public:
	// IClientData�ӿ�ʵ��
	STDMETHODIMP_(int) GetLength();
	STDMETHODIMP_(void*) GetDataBuf();
	STDMETHODIMP_(void) SetClientData (KClientDataParse* pClientData);

private:
	KClientDataParse* m_pClientDataParse;
};

// -------------------------------------------------------------------------

#endif /* __CLIENTDATA_H__ */
