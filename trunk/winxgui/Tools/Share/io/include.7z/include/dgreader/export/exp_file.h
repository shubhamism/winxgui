/* -------------------------------------------------------------------------
//	�ļ���		��	exp_file.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-26 10:33:21
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DGEXP_FILE_H__
#define __DGEXP_FILE_H__

// -------------------------------------------------------------------------

#include "../include/ioacceptor/propbagbase.h"

interface IKClientInfuser;
interface IIOAcceptor;
class KDrawingContainer;
class KShape;
class KPropBag;
class KShapeProp;
class KSolverContainer;
class __RectProportion;
struct FConnectorRule;
class KDrawingGrpContainer;

class KDgIOSourceImpl
{
public:
	KDgIOSourceImpl();
	~KDgIOSourceImpl();
	
//	STDMETHODIMP Init(KDrawingContainer*, IKClientInfuser*);
	STDMETHODIMP Init(IKClientInfuser*);
	
public:
	//IIOSource
	//<pres_canvas>
	STDMETHOD(Translate)(IIOAcceptor* pAcceptor, KDrawingContainer*);
	//<draw_shape>
	STDMETHOD(Translate)(IIOAcceptor* pAcceptor, KShape*, KPropBag* pRootBag = NULL);

	//<pres_default_shapeprops>
	STDMETHOD(Translate)(IIOAcceptor* pAcceptor, KDrawingGrpContainer*);

	//<draw_rules>
	STDMETHODIMP InfuseSolver(IIOAcceptor* pAcceptor, KSolverContainer* pSolver);

private:
	//parse DrawingContainer
	//<pres_backgroundshape>
	STDMETHODIMP InfuseBKShape(IIOAcceptor* pAcceptor, KShape* pBKShape);
	STDMETHODIMP InfuseRootShape(IIOAcceptor* pAcceptor, KShape* pRootShape);
	STDMETHODIMP InfuseSingleShape(IIOAcceptor* pAcceptor, KShape* pShape, KPropBag* pRootBag = NULL);
	//<draw_groupshape>
	STDMETHODIMP InfuseGroupShape(IIOAcceptor* pAcceptor, KShape* pShape, RECT* pRcGrp, RECT* pInitRct,
								bool bFlipH = false, KPropBag* pProp = NULL);
	//<draw_shape>
	STDMETHODIMP InfuseOneShape(IIOAcceptor* pAcceptor, KShape* pShape, RECT*, KPropBag* pProp = NULL);
	//<draw_image>
	STDMETHODIMP InfuseShapeImage(KPropBag*, KShape*);
	STDMETHODIMP InfuseEquation(KPropBag*, KShape*);
	//<draw_shape_prop>�����ǩ��ȡ��
	STDMETHODIMP InfuseShapeProp(IIOAcceptor* pAcceptor, KShape*, RECT*, KPropBag* pProp = NULL);
	STDMETHODIMP InfuseShapeFlag(KPropBag*, KShape* pShape, RECT* pRcGrp, bool);
	//<draw_shape_style>�����ǩ��ȡ��
	STDMETHODIMP InfuseShapeStyle(KPropBag* pAcceptor, KShape* pShape);

	//<draw_textbox>
	STDMETHODIMP InfuseTextBox(IIOAcceptor* pAcc, KShape* pShape);

	STDMETHODIMP InfuseClientData(KPropBag* pAcceptor, KShape* pShape);

	
	//<draw_rule>
	STDMETHODIMP InfuseConnectorRule(IIOAcceptor* pAcceptor, FConnectorRule* pRule);
	STDMETHODIMP InfuseRuleProp(KPropBag* pBag, FConnectorRule* pRule);
	
	STDMETHODIMP InfuseShapeLock(KPropBag* pBag, KShape* pShape);

	STDMETHODIMP InfuseColorMRU(KPropBag* pBag, KDrawingGrpContainer* pDrawContontainer);

private:
	STDMETHODIMP GetShapeAnchor (KShape* pShape, RECT& rc);
	STDMETHODIMP GetRect(IN void* pClientAnchor, IN LONG len, OUT RECT* pRC);

	
	STDMETHODIMP GetShapeGrpChildsMaxExtent (KShape* pGrp, RECT& rcMax);
	// void SetRectProportion(KShape* pShape, RECT* pRcGrp, __RectProportion& rcProp);
	STDMETHODIMP _SetGroupInitRect(KPropBag* pBag, KShape* pGrp,
									RECT* pRcGrp);
					   
private:
	KDrawingContainer*	m_pCanvas;
	IKClientInfuser*	m_pClientInfuser;
	//---->�����ɽ��շ����У������޷�����
//	POINT*	m_pPTs;		//vertices
//	BYTE*	m_pFlags;	//segmentinfo��Ϊ��������
//	void*	m_pColors;	//preset��ɫ����
	
	bool	m_bHasImage;

};

// -------------------------------------------------------------------------
#endif /* __DGEXP_FILE_H__ */
