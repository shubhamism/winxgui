// -------------------------------------------------------------------------
//	�ļ���		��	iox_wpssource.h
//	������		��	Hsie
//	����ʱ��	��	2003-11-06 17:11:08
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __IOX_WPSSOURCE_H__
#define __IOX_WPSSOURCE_H__

/*
@category Kingsoft SDK - KSO - IO V1
@require
	<b>Header:</b> Declared in <b><ioacceptor/acc2sax.h></b>
@group [ksoiov1] IO V1
@brief
@*/

////interface
#ifndef __IOACCEPTOR_H__
#include "ioacceptor/ioacceptor.h"
#endif

#ifndef __ACC2SAX_H__
#include "ioacceptor/acc2sax.h"
#endif

////io std
#ifndef __KSO_IO_SCHEMA_H__
#include <kso/io/schema.h>
#endif

#endif // __IOX_WPSSOURCE_H__
