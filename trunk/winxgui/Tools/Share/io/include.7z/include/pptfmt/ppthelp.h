/* -------------------------------------------------------------------------
//	�ļ���		��	pptfmt/ppthelp.h
//	������		��	Lizm
//	����ʱ��	��	2004-8-8 21:33:51
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __PPTFMT_PPTHELP_H__
#define __PPTFMT_PPTHELP_H__

#ifndef __KSO_IO_V6_STD_TYPE_PRES_H__
#include "kso/io/v6/std/type_pres.h"
#endif

namespace ppt_xml
{
// -------------------------------------------------------------------------
// PPT���м���ҳ�л����ͺͷ����ת������pptreader��pptwriter����
void XML2PPT_TransitionTypeDir(
	IN  int xmlType, 
	OUT int& pptType,
	OUT int& pptDir
	);	
void PPT2XML_TransitionTypeDir(
	IN int pptType, 
	IN int pptDir, 
	OUT int& xmlType, 
	OUT int& xmlDir
	);

int PPT2XML_Effect97TypeDir(
	IN UINT pptType, 
	IN UINT pptDir, 
	OUT UINT& xmlType, 
	OUT UINT& xmlDir
	);
bool XML2PPT_Effect97TypeDir(
	IN UINT xmlType, 
	IN UINT xmlDir, 
	OUT UINT& pptType, 
	OUT UINT& pptDir
	);

bool PPT2XML_Effect2003TypeDir(
	IN int pptType, 
	IN int pptDir, 
	IN int subClass,
	OUT int& xmlType, 
	OUT int& xmlDir);
bool XML2PPT_Effect2003TypeDir(
	IN int xmlType, 
	IN int xmlDir, 
	IN int subClass,
	OUT int& pptType, 
	OUT int& pptDir);

enumPresActionType 
	PPT2XML_ActionType(PPT_Interactive_ActionType);
PPT_Interactive_ActionType 
	XML2PPT_ActionType(enumPresActionType);

enumPresJumpType
	PPT2XML_JumpType(PPT_Interactive_JumpType);
PPT_Interactive_JumpType
	XML2PPT_JumpType(enumPresJumpType);

// -------------------------------------------------------------------------

int  PPT2XML_SlideSize(int pptType, int width, int height);
int  XML2PPT_SlideSize(int xmlType);

int XML2PPT_FontAlignType(int align);
int PPT2XML_FontAlignType(int lAligntype);
int XML2PPT_AlignType(int align);
int PPT2XML_AlignType(int lAligntype);
int XML2PPT_BulletType(int nType);

int XML2PPT_PlaceholderId(int id);
// -------------------------------------------------------------------------
enum PPTColorType
{
	pptctText,
	pptctNormal,
	pptctBullet,
};

DWORD PPT2XML_Color(DWORD clrMS, PPTColorType ct);
DWORD XML2PPT_Color(DWORD dw, PPTColorType ct);
long	MakeColor(int colorType, long r, long g, long b);

//576dpi
inline int TWIP2MASTERCOOR (int n)
{	return int (double (n) * 576 / 1440 + 0.5);}

//EMUs - English Metric Units
//	���Ծ�����EMUs����ʾ����ʱ��Ҳ���� A units
//	1 cm(����)    == 360000 EMUs
//	1 inch(Ӣ��)  == 914400 EMUs
//	1 point(��)   == 12700 EMUs
inline int TWIP2EMUS(int n)	
{	return n * 635;	}
// -------------------------------------------------------------------------
};
#endif /* __PPTFMT_PPTHELP_H__ */
