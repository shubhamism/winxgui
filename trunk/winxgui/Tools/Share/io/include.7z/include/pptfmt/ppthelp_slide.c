#ifndef ppt_xml_impl
#error use ppthelp.c instead
#endif

const int PPTSlideSizeDict[][4] =
{
	{ DA_OnScreen,		0, 0, slidesizeOnScreen		},
	{ DA_LetterSize,	0, 0, slidesizeLetterPaper	},//8.5 X 11 Inch
	{ DA_A4Paper,		0, 0, slidesizeA4Paper		},//210 X 297 mm
	{ DA_35MM,			0, 0, slidesize35MM			},
	{ DA_Overhead,		0, 0, slidesizeOverhead		},//ͶӰ���õ�Ƭ
	{ DA_Banner,		0, 0, slidesizeBanner			},//���
	{ DA_Custom,		19180, 14385, slidesizeLedgerPaper	},	// ������
	{ DA_Custom,		20160, 15120, slidesizeA3Paper		},
	{ DA_Custom,		17050, 12788, slidesizeB4ISOPaper	},
	{ DA_Custom,		11290, 8468, slidesizeB5ISOPaper	},
//		{ DA_Custom,		0, 0, slidesizeB4JISPaper		},	// �����ַ���ߴ�λ��
//		{ DA_Custom,		0, 0, slidesizeB5JISPaper		},
//		{ DA_Custom,		0, 0, slidesizeHagakiCard		},
//		{ DA_Custom,			0, 0, slidesizeCustom			},
};

int PPT2XML_SlideSize(int pptType, int width, int height)
{

	for (int i = 0; i < countof(PPTSlideSizeDict); ++i)
	{
		if (PPTSlideSizeDict[i][0] == pptType)
		{
			if (pptType == DA_Custom)
			{
				if (labs(width - PPTSlideSizeDict[i][1]) < 5 && 
					labs(height - PPTSlideSizeDict[i][2]) < 5)
					return PPTSlideSizeDict[i][3];
			}
			else
				return PPTSlideSizeDict[i][3];
		}
	}
	return slidesizeCustom;
}

int XML2PPT_SlideSize(int xmlType)
{
	switch (xmlType)
	{
	case slidesizeLedgerPaper:
	case slidesizeA3Paper:
	case slidesizeB4ISOPaper:
	case slidesizeB5ISOPaper:
		return DA_Custom;
	}

	for (int i = 0; i < countof(PPTSlideSizeDict); ++i)
	{
		if (PPTSlideSizeDict[i][3] == xmlType)
			return PPTSlideSizeDict[i][0];
	}
	return DA_Custom;
}