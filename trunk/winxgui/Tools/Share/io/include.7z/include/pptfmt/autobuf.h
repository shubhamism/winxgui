/* -------------------------------------------------------------------------
//	�ļ���		��	autobuf.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-20 9:51:16
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __AUTOBUF_H__
#define __AUTOBUF_H__

#include "stl/string.h"
//------------------------------------------------------------------------
//
template <class Type>
class KBuffer : public KBaseRef
{
public:
	typedef		Type			value;
	typedef		Type*			pointer;
	
public:
	KBuffer ()  {}
	virtual ~KBuffer ()						{	m_Buf.erase(m_Buf.begin(), m_Buf.end());}	
	KBuffer (void* buf, UINT len)			{	SetBuf (buf, len);		}
	KBuffer (KBuffer& buf)					{	Copy (buf);				}
	operator void*  ()						{	return GetBuffer ();	}
	KBuffer& operator = (KBuffer& buf)		{	return Copy (buf);		}
	KBuffer& Copy (KBuffer& buf)			{	return SetBuf (buf.GetBuffer (), buf.GetLength ());	}
	void Clear ()							{	m_Buf.erase(m_Buf.begin(), m_Buf.end());}


	const void* GetBuffer ()	{	return m_Buf.c_str ();	}
	UINT  GetLength ()	{	return m_Buf.length ();	}
	
	KBuffer& SetBuf (const void* pBuf, UINT len)
	{
		m_Buf.copy((pointer)pBuf, len);
		//m_Buf.Alloc (len);
		//memcpy (m_Buf.GetBuffer (), pBuf, len);
		return *this;
	}

	KBuffer& InsertAt (int nPos, void* pBuf, UINT len)
	{
		if (len)
		{
			ASSERT (pBuf);
			ASSERT (nPos >= -1);
			ASSERT (nPos < m_Buf.GetLength ());

			//if (nPos <= 0)
			//	return InsertHead (pBuf, len);
			//if (nPos > (int)m_Buf.GetLength () - 1)
			//	return Append (pBuf, len);

			m_Buf.insert(nPos, pBuf, len);
			//m_Buf.Realloc (m_Buf.GetLength () + len);

			//memcpy ((BYTE*)m_Buf.GetBuffer () + nPos + len,
			//		(BYTE*)m_Buf.GetBuffer () + nPos,
			//		m_Buf.GetLength () - len - nPos);
			
			//memcpy ((BYTE*)m_Buf.GetBuffer () + nPos,
			//		pBuf,
			//		len);
		}
		return *this;
	}

	KBuffer& RemoveAt (UINT nPos, UINT len)
	{
		if (len)
		{
			ASSERT (nPos >= 0 && nPos < m_Buf.GetLength ());
			ASSERT (len <= m_Buf.GetLength () - nPos);

			m_Buf.erase(nPos, len);
			//memcpy ((BYTE*)m_Buf.GetBuffer () + nPos,
			//		(BYTE*)m_Buf.GetBuffer () + nPos + len,
			//		m_Buf.GetLength () - nPos - len);
			//m_Buf.Realloc (m_Buf.GetLength () - len);
		}
		return *this;
	}

	KBuffer& InsertHead (void* pBuf, UINT nLen)
	{
		//m_Buf.Realloc (m_Buf.GetLength () + nLen);
		
		//memcpy ((BYTE*)m_Buf.GetBuffer () + nLen,
		//		(BYTE*)m_Buf.GetBuffer (),
		//		m_Buf.GetLength () - nLen);
		//memcpy (m_Buf.GetBuffer (),
		//		pBuf, 
		//		nLen);
		m_Buf.insert(0, pBuf, nLen);
		return *this;
	}

	KBuffer& Append (void* pBuf, UINT nLen)
	{
		m_Buf.append((pointer)pBuf, nLen);
		//m_Buf.Realloc (m_Buf.GetLength () + nLen);
		//memcpy ((BYTE*)m_Buf.GetBuffer () + m_Buf.GetLength () - nLen, 
		//		pBuf, 
		//		nLen);
		return *this;
	}

	UINT GetRefCount()	{ return m_nRef; }
/*
	KBuffer& SetAtGrow (UINT nPos, void* pBuf, UINT nLen)
	{
		UINT nEnd = nPos + nLen;
		if (nEnd > m_Buf.GetLength ())
			m_Buf.Realloc (nEnd);

		memcpy ((BYTE*)m_Buf.GetBuffer () + nPos, pBuf, nLen);
		return *this;
	}

	KBuffer& SetSize (UINT cbSize, BOOL bClear = TRUE)
	{	
		
		if (bClear) 
		{
			//m_Buf.Alloc (cbSize); 
			m_Buf.clear();
			m_Buf.resize(cbSize);
		}
		else 
		{	//m_Buf.Realloc (cbSize);	
			m_Buf.clear();
		return *this;
	}
*/

private:
	std::basic_string< Type > m_Buf;
};

typedef KBuffer< BYTE > KRefBufferObj;

// -------------------------------------------------------------------------
template <typename T_Buffer>
class KBufferUsage
{
public:
	typedef typename T_Buffer::value		value;

public:
	KBufferUsage () : m_pBuf (NULL)	{}
	KBufferUsage (KBufferUsage& buf) : m_pBuf (NULL)			{	this->operator = (buf);	}
	KBufferUsage (IStream* pStream, UINT nLen) : m_pBuf (NULL)	{	Read (pStream, nLen);	}
	KBufferUsage (void* buf, UINT len): m_pBuf (NULL)			{	SetBuf (buf, len);		}

	virtual ~KBufferUsage ()									{	RELEASE (m_pBuf);		}
	operator void*  ()											{	return GetBuffer ();	}
	KBufferUsage& Copy (KBufferUsage& buf)						{	return SetBuf (buf.GetBuffer (), buf.GetLength ());	}
	
	const void* GetBuffer (){	return m_pBuf ? m_pBuf->GetBuffer () : NULL;	}
	UINT  GetLength () const{	return m_pBuf ? m_pBuf->GetLength () : 0;		}
	
	HRESULT GetBuffer (T_Buffer** ppBuf)
	{
		*ppBuf = m_pBuf;
		if (m_pBuf)
		{
			m_pBuf->AddRef ();
			return S_OK;
		}
		return E_NOINTERFACE;
	}

//	operator IBuffer* ()	{	return (IBuffer*)m_pBuf;	}
	operator T_Buffer* ()	{	return (T_Buffer*)m_pBuf;	}
		
	void Clear ()												
	{	
		if (m_pBuf)
		{
			if (1 < m_pBuf->GetRefCount ())
			{
				m_pBuf->Release ();
				m_pBuf = NULL;
			}
			else
				m_pBuf->Clear ();
		}
	}

	KBufferUsage& operator = (const KBufferUsage& buf)
	{	
		if (m_pBuf)
			m_pBuf->Release ();
		m_pBuf = buf.m_pBuf;
		if (buf.m_pBuf)
			buf.m_pBuf->AddRef ();
		return *this;
	}

	KBufferUsage& SetBuf (const void* pBuf, UINT len)
	{
		CopyBeforeModify ();
		m_pBuf->SetBuf (pBuf, len);
		return *this;
	}
	
	KBufferUsage& InsertAt (UINT nPos, void* pBuf, UINT len)
	{
		CopyBeforeModify ();
		m_pBuf->InsertAt (nPos, pBuf, len);
		return *this;
	}

	KBufferUsage& RemoveAt (UINT nPos, UINT len)
	{
		CopyBeforeModify ();
		m_pBuf->RemoveAt (nPos, len);
		return *this;
	}

/*
	KBufferUsage& SetAtGrow (UINT nPos, void* pBuf, UINT nLen)
	{
		CopyBeforeModify ();
		m_pBuf->SetAtGrow (nPos, pBuf, nLen);
		return *this;
	}

	KBufferUsage& SetSize (UINT cbSize, BOOL bClear = TRUE)
	{	
		CopyBeforeModify ();
		m_pBuf->SetSize (cbSize, bClear);
		return *this;
	}
*/

	KBufferUsage& Append (void* pBuf, UINT nLen)
	{
		CopyBeforeModify ();
		m_pBuf->Append (pBuf, nLen);
		return *this;
	}

	int	Read (IStream* pStream, UINT nLen)
	{
		try
		{
			CopyBeforeModify ();
			UINT nTmp = nLen;
//			m_pBuf->SetSize (nLen);
			value* pBuf = new value[nLen]; 
			pStream->Read (pBuf, nLen, (unsigned long*)&nLen);
			if (nTmp <= nLen)
				Append(pBuf, nLen);

			delete []pBuf;
		}
		catch (...)
		{
			Clear ();
			ASSERT (FALSE);
		}
		return GetLength ();
	}
protected:
	void CopyBeforeModify (BOOL bCopy = TRUE)
	{
		if (NULL == m_pBuf ||
			1 < m_pBuf->GetRefCount ())
		{
			T_Buffer* pNew = new T_Buffer;
			if (m_pBuf)
			{
				if (bCopy)
					pNew->Copy (*m_pBuf);
				m_pBuf->Release ();
			}
			m_pBuf = pNew;
		}
	}

private:
	T_Buffer* m_pBuf;
};

typedef KBufferUsage< KRefBufferObj > KAutoBuffer;
// -------------------------------------------------------------------------

#endif /* __AUTOBUF_H__ */
