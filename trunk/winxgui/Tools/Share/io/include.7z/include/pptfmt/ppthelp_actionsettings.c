#ifndef ppt_xml_impl
#error use ppthelp.c instead
#endif

enumPresActionType 
	PPT2XML_ActionType(PPT_Interactive_ActionType tp)
{
	switch (tp)
	{
	case PI_NoAction:			return presPINoAction;	//�޶���
	case PI_MacroAction:		return presPIMacroAction;	//����һ����
	case PI_RunProgramAction:	return presPIRunProgramAction;	//����һ������
	case PI_JumpAction:			return presPIJumpAction;	//��ת
	case PI_HyperlinkAction:	return presPIHyperlinkAction;	//����
	case PI_OLEAction:			return presPIOLEAction;	//���漸������ûʲô�ã��Ȳ����ˣ�
	case PI_MediaAction:		return presPIMediaAction;
	case PI_CustomShowAction:		return presPICustomShowAction;
	}
	
	ASSERT_ONCE(0);
	return presPINoAction;
}

PPT_Interactive_ActionType 
	XML2PPT_ActionType(enumPresActionType tp)
{
	switch(tp)
	{
	case presPINoAction:			return PI_NoAction;	//�޶���
	case presPIMacroAction:			return PI_MacroAction;	//����һ����
	case presPIRunProgramAction:	return PI_RunProgramAction;	//����һ������
	case presPIJumpAction:			return PI_JumpAction;	//��ת
	case presPIHyperlinkAction:		return PI_HyperlinkAction;	//����
	case presPIOLEAction:			return PI_OLEAction;	//���漸������ûʲô�ã��Ȳ����ˣ�
	case presPIMediaAction:			return PI_MediaAction;
	case presPICustomShowAction:	return PI_CustomShowAction;
	}

	ASSERT_ONCE(0);
	return PI_NoAction;
}

enumPresJumpType
	PPT2XML_JumpType(PPT_Interactive_JumpType tp)
{
	switch(tp)
	{
	case PI_NoJump:				return presNoJump;
	case PI_NextSlide:			return presNextSlide;
	case PI_PreviousSlide:		return presPreviousSlide;
	case PI_FirstSlide:			return presFirstSlide;
	case PI_LastSlide:			return presLastSlide;
	case PI_LastSlideViewed:	return presLastSlideViewed;
	case PI_EndShow:			return presEndShow;
	}

	ASSERT_ONCE(0);
	return presNoJump;
}

PPT_Interactive_JumpType
	XML2PPT_JumpType(enumPresJumpType tp)
{
	switch(tp)
	{
	case presNoJump:			return PI_NoJump;
	case presNextSlide:			return PI_NextSlide;
	case presPreviousSlide:		return PI_PreviousSlide;
	case presFirstSlide:		return PI_FirstSlide;
	case presLastSlide:			return PI_LastSlide;
	case presLastSlideViewed:		return PI_LastSlideViewed;
	case presEndShow:			return PI_EndShow;
	}

	ASSERT_ONCE(0);
	return PI_NoJump;
}