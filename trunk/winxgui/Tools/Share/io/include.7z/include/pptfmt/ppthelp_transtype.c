#ifndef ppt_xml_impl
#error use ppthelp.c instead
#endif

const int SlideTransPPT2XMLDict[][4] = 
{
//PowerPoint 2000 start
	{ directionNone,	transitionNone,	TR_NoTrans,	TR_NoTrans_None},
	// �г�
	{ directionNone,	transitionCut,	TR_NoTrans,	TR_Cut},	//also Animation
	// ȫ���г�
	{ directionNone,	transitionCutThroughBlack,	TR_NoTrans,	TR_CutThroughBlack},
	// ���
	{ directionNone,	transitionRandom,	TR_Random,	TR_Random_Normal},	//also Animation
	// ˮƽ��Ҷ��
	{ directionNone,	transitionBlindsHorizontal,		TR_Blinds,	TR_Blinds_Down},	//also Animation
	// ��ֱ��Ҷ��
	{ directionNone,	transitionBlindsVertical,		TR_Blinds,	TR_Blinds_Right},	//also Animation
	// ��������
	{ directionRight,	transitionCheckerboardAcross,	TR_Checkerboard,	TR_Checkerboard_Right},	//also Animation
	// ��������
	{ directionDown,	transitionCheckerboardDown,		TR_Checkerboard,	TR_Checkerboard_Down},	//also Animation
//	---> ����Ч��
	{ directionLeft,		transitionCoverLeft,		TR_Cover,	TR_Cover_Left},
	{ directionUp,			transitionCoverUp,			TR_Cover,	TR_Cover_Up},
	{ directionRight,		transitionCoverRight,		TR_Cover,	TR_Cover_Right},
	{ directionDown,		transitionCoverDown,		TR_Cover,	TR_Cover_Down},
	{ directionTopLeft,		transitionCoverLeftUp,		TR_Cover,	TR_Cover_LeftUp},
	{ directionTopRight,	transitionCoverRightUp,		TR_Cover,	TR_Cover_RightUp},
	{ directionBottomLeft,	transitionCoverLeftDown,	TR_Cover,	TR_Cover_LeftDown},
	{ directionBottomRight,	transitionCoverRightDown,	TR_Cover,	TR_Cover_RightDown},
	// �ܽ�
	{ directionNone,		transitionDissolve,			TR_Dissolve, TR_Dissolve_Normal},	//also Animation
	// ȫ�ڵ���
	{ directionNone,		transitionFade,				TR_Fade,	TR_Fade_Normal},
//	---> ���Ч��
	{ directionLeft,		transitionUncoverLeft,		TR_UnCover,	TR_UnCover_Left},
	{ directionUp,			transitionUncoverUp,		TR_UnCover,	TR_UnCover_Up},
	{ directionRight,		transitionUncoverRight,		TR_UnCover,	TR_UnCover_Right},
	{ directionDown,		transitionUncoverDown,		TR_UnCover,	TR_UnCover_Down},
	{ directionTopLeft,		transitionUncoverLeftUp,	TR_UnCover,	TR_UnCover_LeftUp},
	{ directionTopRight,	transitionUncoverRightUp,	TR_UnCover,	TR_UnCover_RightUp},
	{ directionBottomLeft,	transitionUncoverLeftDown,	TR_UnCover,	TR_UnCover_LeftDown},
	{ directionBottomRight,	transitionUncoverRightDown,	TR_UnCover,	TR_UnCover_RightDown},
	// ���ˮƽ����
	{ directionHorizontal,	transitionRandomBarsHorizontal,	TR_RandomBars,	TR_RandomBars_Horizontal},	//also Animation
	// �����ֱ����
	{ directionVertical,	transitionRandomBarsVertical,	TR_RandomBars,	TR_RandomBars_Vertical},	//also Animation
//	---> ����״Ч�� 
	{ directionTopLeft,		transitionStripsLeftUp,		TR_Strips,	TR_Strips_LeftUp},		//also Animation
	{ directionTopRight,	transitionStripsRightUp,	TR_Strips,	TR_Strips_RightUp},		//also Animation
	{ directionBottomLeft,	transitionStripsLeftDown,	TR_Strips,	TR_Strips_LeftDown},	//also Animation
	{ directionBottomRight,	transitionStripsRightDown,	TR_Strips,	TR_Strips_RightDown},	//also Animation
//  ---> ����Ч��	
	{ directionLeft,	transitionWipeLeft,		TR_Wipe,	TR_Wipe_Left},		//also Animation
	{ directionUp,		transitionWipeUp,		TR_Wipe,	TR_Wipe_Up},		//also Animation
	{ directionRight,	transitionWipeRight,	TR_Wipe,	TR_Wipe_Right},		//also Animation
	{ directionDown,	transitionWipeDown,		TR_Wipe,	TR_Wipe_Down},		//also Animation
	// ��״չ��
	{ directionOut,		transitionBoxOut,		TR_Box,		TR_Box_Out},		//also Animation
	// ��״����
	{ directionIn,		transitionBoxIn,		TR_Box,		TR_Box_In},			//also Animation
//  ---> �������������� + ����������չ�� + �������������� + ����������չ��
	{ directionHorizontalOut,	transitionSplitHorizontalOut,	TR_Split,	TR_Split_HorizontalOut},	//also Animation
	{ directionHorizontalIn,	transitionSplitHorizontalIn,	TR_Split,	TR_Split_HorizontalIn},		//also Animation
	{ directionVerticalOut,		transitionSplitVerticalOut,		TR_Split,	TR_Split_VerticalOut},		//also Animation
	{ directionVerticalIn,		transitionSplitVerticalIn,		TR_Split,	TR_Split_VerticalIn},		//also Animation

	{ directionLeft,		transitionFlyFromLeft,			TR_AniEffectSet,	TR_AES_FlyInFromLeft},		//only Animation
	{ directionUp,			transitionFlyFromTop,			TR_AniEffectSet,	TR_AES_FlyInFromTop},		//only Animation
	{ directionRight,		transitionFlyFromRight,			TR_AniEffectSet,	TR_AES_FlyInFromRight},		//only Animation
	{ directionDown,		transitionFlyFromBottom,		TR_AniEffectSet,	TR_AES_FlyInFromBottom},		//only Animation
	{ directionTopLeft,		transitionFlyFromTopLeft,		TR_AniEffectSet,	TR_AES_FlyInFromTopLeft},		//only Animation
	{ directionTopRight,	transitionFlyFromTopRight,		TR_AniEffectSet,	TR_AES_FlyInFromTopRight},		//only Animation
	{ directionBottomLeft,	transitionFlyFromBottomLeft,	TR_AniEffectSet,	TR_AES_FlyInFromBottomLeft},		//only Animation
	{ directionBottomRight,	transitionFlyFromBottomRight,	TR_AniEffectSet,	TR_AES_FlyInFromBottomRight},		//only Animation

//	{ directionLeft,		transitionPeekin,		TR_AniEffectSet,	TR_AES_PeekInFromLeft},		//only Animation
//	{ directionDown,		transitionPeekin,		TR_AniEffectSet,	TR_AES_PeekInFromBottom},		//only Animation
//	{ directionRight,		transitionPeekin,		TR_AniEffectSet,	TR_AES_PeekInFromRight},		//only Animation
//	{ directionUp,			transitionPeekin,		TR_AniEffectSet,	TR_AES_PeekInFromTop},		//only Animation
//
//	{ directionLeft,		transitionCrawlin,		TR_AniEffectSet,	TR_AES_CrawlInFromLeft},		//only Animation
//	{ directionUp,			transitionCrawlin,		TR_AniEffectSet,	TR_AES_CrawlInFromTop},		//only Animation
//	{ directionRight,		transitionCrawlin,		TR_AniEffectSet,	TR_AES_CrawlInFromRight},		//only Animation
//	{ directionDown,		transitionCrawlin,		TR_AniEffectSet,	TR_AES_CrawlInFromBottom},			//only Animation
//
//	{ directionIn,			transitionZoom,				TR_AniEffectSet,	TR_AES_ZoomIn},		//�Ŵ�		//only Animation
//	{ directionIn,			transitionZoomSlightly,		TR_AniEffectSet,	TR_AES_ZoomInSlightly},		//��΢�Ŵ�	//only Animation
//	{ directionOut,			transitionZoom,				TR_AniEffectSet,	TR_AES_ZoomOut},		//��С		//only Animation
//	{ directionOut,			transitionZoomSlightly,		TR_AniEffectSet,	TR_AES_ZoomOutSlightly},		//��΢��С		//only Animation
//	{ directionIn,			transitionZoomScreenCenter,	TR_AniEffectSet,	TR_AES_ZoomInFromScreenCenter},		//����Ļ���ķŴ�		//only Animation
//	{ directionOut,			transitionZoomScreenBottom,	TR_AniEffectSet,	TR_AES_ZoomOutFromScreenBottom},		//����Ļ�ײ���С		//only Animation
//
//	{ directionVerticalOut,	transitionStretch,		TR_AniEffectSet,	TR_AES_StretchAcross},		//ˮƽ��չ		//only Animation
//	{ directionLeft,		transitionStretch,		TR_AniEffectSet,	TR_AES_StretchFromLeft},		//only Animation
//	{ directionUp,			transitionStretch,		TR_AniEffectSet,	TR_AES_StretchFromTop},		//only Animation
//	{ directionRight,		transitionStretch,		TR_AniEffectSet,	TR_AES_StretchFromRight},		//only Animation
//	{ directionDown,		transitionStretch,		TR_AniEffectSet,	TR_AES_StretchFromBottom	},		//only Animation
//
//	{ directionNone,		transitionSwivel,		TR_AniEffectSet,	TR_AES_Swivel},		//only Animation
//
//	{ directionIn,			transitionSpiral,		TR_AniEffectSet,	TR_AES_SpiralIn},		//only Animation
//
////PowerPoint 2000 end
////PowerPoint XP start
//	{ directionNone,	transitionRandom,	TR_Random,	TR_Random_Normal_XP},
	// ����
	{ directionOut,	transitionDiamondOut,	TR_Diamond_XP,	TR_Diamond_XP_Normal},
	// �Ӻ�
	{ directionOut,	transitionPlusOut,	TR_Plus_XP,	TR_Plus_XP_Normal},
	// ����Ч��
	{ directionNone,	transitionWedge,	TR_Wedge_XP,	TR_Wedge_XP_Normal},
//	---> �Ƴ�Ч��
	{ directionLeft,	transitionPushLeft,	TR_Push_XP,	TR_Push_XP_Left},
	{ directionUp,		transitionPushUp,	TR_Push_XP,	TR_Push_XP_Up},
	{ directionRight,	transitionPushRight,TR_Push_XP,	TR_Push_XP_Right},
	{ directionDown,	transitionPushDown,	TR_Push_XP,	TR_Push_XP_Down},
	// ˮƽ����	
	{ directionHorizontal,	transitionCombHorizontal,	TR_Comb_XP,	TR_Comb_XP_Horizontal},
	// ��ֱ����
	{ directionVertical,	transitionCombVertical,	TR_Comb_XP,	TR_Comb_XP_Vertical},
	// ���ſ챨
	{ directionCounterclockwise, transitionNewsflash,	TR_Newsflash_XP,	TR_Newsflash_XP_Normal},
	// ƽ������
	{ directionNone,	transitionFadeSmoothly,	TR_Fadesmooth_XP,	TR_Fadesmooth_XP_Normal},
//	---> �ַ�
	{ directionClockwise,	transitionWheel1Spoke,	TR_Wheelclockwise_XP,	TR_Wheelclockwise_XP_1},
	{ directionClockwise,	transitionWheel2Spokes,	TR_Wheelclockwise_XP,	TR_Wheelclockwise_XP_2},
	{ directionClockwise,	transitionWheel3Spokes,	TR_Wheelclockwise_XP,	TR_Wheelclockwise_XP_3},
	{ directionClockwise,	transitionWheel4Spokes,	TR_Wheelclockwise_XP,	TR_Wheelclockwise_XP_4},
	{ directionClockwise,	transitionWheel8Spokes,	TR_Wheelclockwise_XP,	TR_Wheelclockwise_XP_8},
	// Բ��
	{ directionOut,			transitionCircleOut,	TR_Circle_XP,	TR_Circle_XP_Normal},
//PowerPoint XP end
};


VOID XML2PPT_TransitionTypeDir(
	IN  int xmlType, 
	OUT int& pptType,
	OUT int& pptDir
	)
{
	
	int nSize = countof(SlideTransPPT2XMLDict);
	for (int n = 0; n < nSize; ++n)
	{
		if (SlideTransPPT2XMLDict[n][1] == xmlType)
		{			
			pptType = SlideTransPPT2XMLDict[n][2];
			pptDir	= SlideTransPPT2XMLDict[n][3];
			return;
		}
	}
	pptType = transitionNone;
	pptDir	= directionNone;
}

void PPT2XML_TransitionTypeDir(
	IN int pptType, 
	IN int pptDir, 
	OUT int& xmlType, 
	OUT int& xmlDir
	)
{
	int nSize = countof(SlideTransPPT2XMLDict);
	for (int n = 0; n < nSize; ++n)
	{
		if (SlideTransPPT2XMLDict[n][2] == pptType &&
			SlideTransPPT2XMLDict[n][3] == pptDir)
		{			
			xmlType = SlideTransPPT2XMLDict[n][1];
			xmlDir	= SlideTransPPT2XMLDict[n][0];
			return;
		}
	}
	xmlType = transitionNone;
	xmlDir	= directionNone;
}


