/* -------------------------------------------------------------------------
//	�ļ���		��	pptheader.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 10:30:14
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __PPTHEADER_H__
#define __PPTHEADER_H__

// -------------------------------------------------------------------------
#ifndef __MSO_FILEFMT_POWERPOINT_PPT_H__
#include "mso/filefmt/powerpoint/ppt.h"
using namespace ppt;
#endif //__MSO_FILEFMT_POWERPOINT_PPT_H__

#include "mso/filefmt/powerpoint/kppttxcfstyle.h"
#include "mso/filefmt/powerpoint/kppttxpfstyle.h"

#ifndef __IOHEADER_IOHEADER_H__
#include "ioheader/ioheader.h"
#endif //__IOHEADER_IOHEADER_H__

#ifndef __PPTTOOLS_H__
#include "ppttools.h"
#endif // __PPTTOOLS_H__

#ifndef __AUTOBUF_H__
#include "autobuf.h"
#endif // __AUTOBUF_H__

// -------------------------------------------------------------------------

#endif /* __PPTHEADER_H__ */
