#ifndef ppt_xml_impl
#error use ppthelp.c instead
#endif


// ------------------------------------------------------------------------------
// ����Ϊ97����Ч�����м���ת��
const UINT Effect97PPT2XMLDict[][4] = 
{
	{PA_Appear,			PA_AES_FlyInFromLeft,		presAnimEffectAppear,	directionNone	},
	{PA_AniEffectSet,	PA_AES_FlyInFromBottom,		presAnimEffectFly,		directionBottom	},
	{PA_AniEffectSet,	PA_AES_FlyInFromLeft,		presAnimEffectFly,		directionLeft	},
	{PA_AniEffectSet,	PA_AES_FlyInFromRight,		presAnimEffectFly,		directionRight	},
	{PA_AniEffectSet,	PA_AES_FlyInFromTop,		presAnimEffectFly,		directionTop	},
	{PA_AniEffectSet,	PA_AES_FlyInFromBottomLeft,	presAnimEffectFly,		directionBottomLeft	},
	{PA_AniEffectSet,	PA_AES_FlyInFromBottomRight,presAnimEffectFly,		directionBottomRight},
	{PA_AniEffectSet,	PA_AES_FlyInFromTopLeft,	presAnimEffectFly,		directionTopLeft	},
	{PA_AniEffectSet,	PA_AES_FlyInFromTopRight,	presAnimEffectFly,		directionTopRight	},
	{PA_Blinds,			1,							presAnimEffectBlinds,	directionHorizontal	},
	{PA_Blinds,			0,							presAnimEffectBlinds,	directionVertical	},
	{PA_Box,			1,							presAnimEffectBox,		directionIn	},
	{PA_Box,			0,							presAnimEffectBox,		directionOut	},
	{PA_CheckerBoard,	0,							presAnimEffectCheckerboard,	directionHorizontal	},
	{PA_CheckerBoard,	1,							presAnimEffectCheckerboard,	directionVertical	},
	{PA_AniEffectSet,	PA_AES_CrawlInFromBottom,	presAnimEffectCrawl,	directionBottom	},
	{PA_AniEffectSet,	PA_AES_CrawlInFromLeft,		presAnimEffectCrawl,	directionLeft	},
	{PA_AniEffectSet,	PA_AES_CrawlInFromRight,	presAnimEffectCrawl,	directionRight	},
	{PA_AniEffectSet,	PA_AES_CrawlInFromTop,		presAnimEffectCrawl,	directionTop	},
	{PA_DissolveIn,		0,							presAnimEffectDissolve,	directionNone	},
	{PA_FlashOnce,		0,							presAnimEffectFlashOnce,	directionNone	},
	{PA_FlashOnce,		1,							presAnimEffectFlashOnce,	directionNone	},
	{PA_FlashOnce,		2,							presAnimEffectFlashOnce,	directionNone	},
	{PA_AniEffectSet,	PA_AES_PeekInFromBottom,		presAnimEffectPeek,	directionDown},
	{PA_AniEffectSet,	PA_AES_PeekInFromLeft,		presAnimEffectPeek,	directionLeft},
	{PA_AniEffectSet,	PA_AES_PeekInFromRight,		presAnimEffectPeek,	directionRight},
	{PA_AniEffectSet,	PA_AES_PeekInFromTop,		presAnimEffectPeek,	directionUp},
	{PA_RandomBars,		0,							presAnimEffectRandomBars, directionHorizontal	},
	{PA_RandomBars,		1,							presAnimEffectRandomBars, directionVertical	},
	{PA_AniEffectSet,	PA_AES_SpiralIn,		presAnimEffectSpiral,	directionNone	},
	{PA_Split,	PA_Split_UpDownToCenter,		presAnimEffectSplit,	directionHorizontalIn},
	{PA_Split,	PA_Split_CenterToUpDown,		presAnimEffectSplit,	directionHorizontalOut},
	{PA_Split,	PA_Split_LeftRightToCenter,		presAnimEffectSplit,	directionVerticalIn},
	{PA_Split,	PA_Split_CenterToLeftRight,		presAnimEffectSplit,	directionVerticalOut},
	{PA_AniEffectSet,	PA_AES_ExpandHorizontal,		presAnimEffectStretch,	directionHorizontal	},
	{PA_AniEffectSet,	PA_AES_ExpandFromBottom,		presAnimEffectStretch,	directionBottom	},
	{PA_AniEffectSet,	PA_AES_ExpandFromLeft,		presAnimEffectStretch,	directionLeft	},
	{PA_AniEffectSet,	PA_AES_ExpandFromRight,		presAnimEffectStretch,	directionRight	},
	{PA_AniEffectSet,	PA_AES_ExpandFromTop,		presAnimEffectStretch,	directionTop	},
	{PA_Strips,	PA_AES_FlyInFromBottomLeft,		presAnimEffectStrips,	directionBottomLeft	},
	{PA_Strips,	PA_AES_FlyInFromTopLeft,		presAnimEffectStrips,	directionUpLeft	},
	{PA_Strips,	PA_AES_FlyInFromBottomRight,		presAnimEffectStrips,	directionBottomRight},
	{PA_Strips,	PA_AES_FlyInFromTopRight,		presAnimEffectStrips,	directionUpRight	},
	{PA_AniEffectSet,	PA_AES_Swivel,		presAnimEffectSwivel,	directionHorizontal	},
	{PA_Wipe,			PA_Wipe_Bottom,				presAnimEffectWipe,		directionUp},
	{PA_Wipe,			PA_Wipe_Left,				presAnimEffectWipe,		directionRight},
	{PA_Wipe,			PA_Wipe_Right,				presAnimEffectWipe,		directionLeft},
	{PA_Wipe,			PA_Wipe_Up,					presAnimEffectWipe,		directionDown},
	{PA_AniEffectSet,	PA_AES_ZoomIn,				presAnimEffectZoom,		directionIn	},
	{PA_AniEffectSet,	PA_AES_ZoomInFromScreenCenter,	presAnimEffectZoom,	directionInCenter	},
	{PA_AniEffectSet,	PA_AES_ZoomInSlightly,		presAnimEffectZoom,		directionInSlightly	},
	{PA_AniEffectSet,	PA_AES_ZoomOut,				presAnimEffectZoom,		directionOut	},
	{PA_AniEffectSet,	PA_AES_ZoomOutFromScreenBottom,	presAnimEffectZoom,	directionOutBottom	},
	{PA_AniEffectSet,	PA_AES_ZoomOutSlightly,		presAnimEffectZoom,		directionOutSlightly},
	{PA_RandomEffects,	0,		presAnimEffectRandomEffects,		directionNone},
};


int PPT2XML_Effect97TypeDir(
	IN UINT pptType, 
	IN UINT pptDir, 
	OUT UINT& xmlType, 
	OUT UINT& xmlDir
	)
{
	xmlType = presAnimeffectNone;
	xmlDir = directionNone;
	for (int i = 0; i < countof(Effect97PPT2XMLDict); ++i)
	{
		if (Effect97PPT2XMLDict[i][0] == pptType && 
			Effect97PPT2XMLDict[i][1] == pptDir)
		{
			xmlType = Effect97PPT2XMLDict[i][2];
			xmlDir	= Effect97PPT2XMLDict[i][3];
			return i;
		}
	}
	
	// ����ʶ��97������Ϊ���ִ���
	xmlType = presAnimEffectAppear;
	xmlDir = directionNone;
	return 0;
}
 
bool XML2PPT_Effect97TypeDir(
	IN UINT xmlType, 
	IN UINT xmlDir, 
	OUT UINT& pptType, 
	OUT UINT& pptDir
	)
{
	// 97������ʶ��ģ�ͳһ��Ϊ���ֶ���Ч��
	pptType = PA_Appear;
	pptDir = PA_AES_FlyInFromLeft;
	for (int i = 0; i < countof(Effect97PPT2XMLDict); ++i)
	{
		if (Effect97PPT2XMLDict[i][2] == xmlType && 
			Effect97PPT2XMLDict[i][3] == xmlDir)
		{
			pptType = Effect97PPT2XMLDict[i][0];
			pptDir	= Effect97PPT2XMLDict[i][1];
			return true;
		}
	}

	return false;
}
// -----------------------------------------------------------------------------
// ����Ϊ2003����Ч�����м���ת��
//	�������˳�
static const int Effect2003PPT2XMLDict_EnterExit[][4] =
{
	// 1 ����
	{ msoEffectAppear,	0x0,	presAnimEffectAppear,	directionNone},
	// 2 ��						
	{ msoEffectFly,	0x01,	presAnimEffectFly,	directionTop		},	// From Top
	{ msoEffectFly,	0x02,	presAnimEffectFly,	directionRight		},	
	{ msoEffectFly,	0x04,	presAnimEffectFly,	directionBottom		},	// From Bottom
	{ msoEffectFly,	0x08,	presAnimEffectFly,	directionLeft		},	
	{ msoEffectFly,	0x0C,	presAnimEffectFly,	directionBottomLeft	},		
	{ msoEffectFly,	0x06,	presAnimEffectFly,	directionBottomRight},	// directionBottom | directionRight		
	{ msoEffectFly,	0x09,	presAnimEffectFly,	directionTopLeft	},	// directionTop | directionLeft	
	{ msoEffectFly,	0x03,	presAnimEffectFly,	directionTopRight	},	// directionTop | directionRight	
	// 3 ��Ҷ��						
	{ msoEffectBlinds,	0x05,	presAnimEffectBlinds,	directionVertical	},	//	
	{ msoEffectBlinds,	0x0A,	presAnimEffectBlinds,	directionHorizontal	},	//	
	// 4 ��״						
//		{ presAnimEffectBox,	0x02,	presAnimEffectChangeFontSize, },			
	{ msoEffectBox,	0x10,	presAnimEffectBox,	directionIn			},
	{ msoEffectBox,	0x20,	presAnimEffectBox,	directionOut		},	//
	// 5 ����						
	{ msoEffectCheckerboard,	0x05,	presAnimEffectCheckerboard,	directionVertical	},	//	
	{ msoEffectCheckerboard,	0x0A,	presAnimEffectCheckerboard,	directionHorizontal	},	//	
	// 6 Բ����չ						
	//{ msoEffectCircle,		0x0,	presAnimEffectCircle,	directionIn		},
	{ msoEffectCircle,		0x10,	presAnimEffectCircle,	directionIn		},
	{ msoEffectCircle,		0x20,	presAnimEffectCircle,	directionOut	},	
	// 7 ������						
	{ msoEffectCrawl,	0x01,	presAnimEffectCrawl,	directionTop		},	// From Top
	{ msoEffectCrawl,	0x02,	presAnimEffectCrawl,	directionRight		},	
	{ msoEffectCrawl,	0x04,	presAnimEffectCrawl,	directionBottom		},	// From Bottom
	{ msoEffectCrawl,	0x08,	presAnimEffectCrawl,	directionLeft		},	
	// 8 ����						
	{ msoEffectDiamond,	0x10,	presAnimEffectDiamond,	directionIn		},	
	{ msoEffectDiamond,	0x20,	presAnimEffectDiamond,	directionOut	},		
	// 9 �����ܽ�						
	{ msoEffectDissolve,	0x0,	presAnimEffectDissolve,	directionNone	},	//	
	// 10  ����						
	{ msoEffectFade,		0x0,	presAnimEffectFade,	directionNone	},	//
	// 11 ��˸	
	{ msoEffectFlashOnce,	0x0,	presAnimEffectFlashOnce,	directionNone		},	
	// 12 �����г�						
	{ msoEffectPeek,	0x01,	presAnimEffectPeek,	directionUp			},
	{ msoEffectPeek,	0x02,	presAnimEffectPeek,	directionRight		},	
	{ msoEffectPeek,	0x04,	presAnimEffectPeek,	directionDown		},	//
	{ msoEffectPeek,	0x08,	presAnimEffectPeek,	directionLeft		},	
	// 13 ʮ����
	{ msoEffectPlus,	0x10,	presAnimEffectPlus, directionIn},				
	{ msoEffectPlus,	0x20,	presAnimEffectPlus, directionOut},				
	// 14 �������
	{ msoEffectRandomBars,	0x0A,	presAnimEffectRandomBars,		directionHorizontal	},	//
	{ msoEffectRandomBars,	0x05,	presAnimEffectRandomBars,		directionVertical	},	
	// 15 ��������
	{ msoEffectSpiral,		0x0,	presAnimEffectSpiral,	directionNone},		
	// 16 ����
	{ msoEffectSplit,		0x1a,	presAnimEffectSplit,	directionHorizontalIn},		
	{ msoEffectSplit,		0x2a,	presAnimEffectSplit,	directionHorizontalOut},		
	{ msoEffectSplit,		0x15,	presAnimEffectSplit,	directionVerticalIn	},	
	{ msoEffectSplit,		0x25,	presAnimEffectSplit,	directionVerticalOut},		
	// 17 ��չ
	{ msoEffectStretch,	0xa,	presAnimEffectStretch,	directionHorizontal},			
	{ msoEffectStretch,	0x4,	presAnimEffectStretch,	directionBottom},			
	{ msoEffectStretch,	0x8,	presAnimEffectStretch,	directionLeft},			
	{ msoEffectStretch,	0x2,	presAnimEffectStretch,	directionRight},			
	{ msoEffectStretch,	0x1,	presAnimEffectStretch,	directionTop},			
							
	// 18 ����״						
	{ msoEffectStrips,		0xC,	presAnimEffectStrips,	directionBottomLeft},		
	{ msoEffectStrips,		0x09,	presAnimEffectStrips,	directionUpLeft},		
	{ msoEffectStrips,		0x06,	presAnimEffectStrips,	directionBottomRight},		
	{ msoEffectStrips,		0x03,	presAnimEffectStrips,	directionUpRight},		
							
	// ��������ǽ��ݶ��� ��ʲô��						
	{ msoEffectStrips,		0x0,	presAnimEffectBrushOnUnderline, directionNone},			
							
	// 19 ��ת						
	{ msoEffectSwivel,		0x0A,	presAnimEffectSwivel,	directionHorizontal},		
	{ msoEffectSwivel,		0x05,	presAnimEffectSwivel,	directionVertical},		
	// 20 ����չ��						
	{ msoEffectWedge,		0x0,	presAnimEffectWedge,	directionNone},		

	// 21 ���� ����������תͼ�Σ��м��δ���������ַ���						
	{ msoEffectWheel,		0x01,	presAnimEffectWheel,	directionWheel1},		
	{ msoEffectWheel,		0x02,	presAnimEffectWheel,	directionWheel2},		
	{ msoEffectWheel,		0x03,	presAnimEffectWheel,	directionWheel3},		
	{ msoEffectWheel,		0x04,	presAnimEffectWheel,	directionWheel4},		
	{ msoEffectWheel,		0x08,	presAnimEffectWheel,	directionWheel8},		
							
	// 22 ����						
	{ msoEffectWipe,	0x01,	presAnimEffectWipe,	directionUp			},
	{ msoEffectWipe,	0x02,	presAnimEffectWipe,	directionRight		},	
	{ msoEffectWipe,	0x04,	presAnimEffectWipe,	directionDown		},	// From Bottom
	{ msoEffectWipe,	0x08,	presAnimEffectWipe,	directionLeft		},	//
	// 23 ����Ч��						
	{ msoEffectZoom,	0x10,	presAnimEffectZoom,	directionIn			},
	{ msoEffectZoom,	0x210,	presAnimEffectZoom,	directionInCenter	},	// ����Ļ���ķŴ�	
	{ msoEffectZoom,	0x220,	presAnimEffectZoom,	directionOutCenter	},	// ��С����Ļ����	
	{ msoEffectZoom,	0x24,	presAnimEffectZoom,	directionOutBottom	},	// ����Ļ�ײ���С	
	{ msoEffectZoom,	0x14,	presAnimEffectZoom,	directionInBottom	},	// �Ŵ���Ļ�ײ�	
	{ msoEffectZoom,	0x120,	presAnimEffectZoom,	directionOutSlightly},	// ��΢��С		
	{ msoEffectZoom,	0x110,	presAnimEffectZoom,	directionInSlightly	},	// ��΢�Ŵ�	
	{ msoEffectZoom,	0x20,	presAnimEffectZoom,	directionOut		},	// ��
	// 24 ���Ч��						
	{ msoEffectRandomEffects,	0x0,	presAnimEffectRandomEffects,	directionNone		},	
	// 25 ����						
	{ msoEffectBoomerang,		0x0,	presAnimEffectBoomerang,	directionNone},		
	// 26 ����						
	{ msoEffectBounce,		0x0,	presAnimEffectBounce,	directionNone},		
	// 27 ��ɫ���ֻ�						
	{ msoEffectColorReveal, 0x0,	presAnimEffectColorReveal, directionNone},					
	// 28 ��Ļ						
	{ msoEffectCredits,	0x0,	presAnimEffectCredits,	directionNone		},	// From Top
	// 29 ����						
	{ msoEffectEaseIn,		0x0,	presAnimEffectEaseIn,	directionNone		},
	// 30 ����						
	{ msoEffectFloat,		0x0,	presAnimEffectFloat,	directionNone},		
	// 31 ��תʽ��Զ����						
	{ msoEffectGrowAndTurn,	0x0,	presAnimEffectGrowAndTurn, directionNone},				
	// 34 ����						
	{ msoEffectLightSpeed,		0x0,	presAnimEffectLightSpeed,	directionNone},		
	// 35 ��߷糵						
	{ msoEffectPinwheel,		0x0,	presAnimEffectPinwheel,	directionNone	},	
	// 37 ����						
	{ msoEffectRiseUp,		0x0,	presAnimEffectRiseUp,	directionNone	},	
	// 38 ����						
	{ msoEffectSwish,		0x0,	presAnimEffectSwish,		directionNone	},
							
	// 39 ����						
	{ msoEffectThinLine,		0x0,	presAnimEffectThinLine,	directionNone},		
	// 40 �º���չ��						
	{ msoEffectUnFold, 0x0,		presAnimEffectUnfold,	directionNone	},				
	// 41 �ӱ�ʽ						
	{ msoEffectWhip, 0x0,	presAnimEffectWhip,	directionNone	},			
	// 42 ����						
	{ msoEffectAscend,	0x0,	presAnimEffectAscend,	directionNone},			
	// 43 ������ת
	{ msoEffectCenterRevolve,		0x0,	presAnimEffectCenterRevolve,	directionNone},		
	// 44 ����						
	// { msoEffectSpinner,	0x0,	presAnimEffectSpinner,	directionNone},			
	// 45 ����ʽ����						
	{ msoEffectFadedSwivel,	0x0,	presAnimEffectFadedSwivel,	directionNone},			
	// 47 �½�						
	{ msoEffectDescend,		0x0,	presAnimEffectDescend,	directionNone},		
	// 48 Ͷ��						
	{ msoEffectSling,	0x0,	presAnimEffectSling,	directionNone},			
	// 49 ����						
	{ msoEffectSpinner,		0x0,	presAnimEffectSpinner,	directionNone},		
	// 50 ѹ��						
	{ msoEffectStretchy,		0x0,	presAnimEffectStretchy,	directionNone},		
	// 51 �Ŵ�						
	{ msoEffectZip,		0x0,	presAnimEffectZip,		directionNone},	
	// 52 ��������						
	{ msoEffectArcUp,	0x0,	presAnimEffectArcUp,	directionNone},			
	// 53 ����ʽ����						
	{ msoEffectFadedZoom,		0x0,	presAnimEffectFadedZoom,		directionNone},	
	// 54 ����						
	{ msoEffectGlide,	0x0,	presAnimEffectGlide,	directionNone},			
	// 55 չ��						
	{ msoEffectExpand,		0x0, 	presAnimEffectExpand,	directionNone},		
	// 56 �շ�						
	{msoEffectFlip,		0x0,	presAnimEffectFlip,		directionNone},	

	// 58 �۵�	
	{msoEffectFold,		0x0,	presAnimEffectFold,		directionNone},	

};

// ǿ������
static const int Effect2003PPT2XMLDict_Enphasis[][4] = 
{
	// ���������ɫ
	{ msoEffectChangeFillColor, 1, presAnimEffectChangeFillColor, directionNone},
	// ��������
	{ msoEffectChangeFont, 2, presAnimEffectChangeFont, directionNone},
	// ����������ɫ
	{ msoEffectChangeFontColor, 2, presAnimEffectChangeFontColor, directionNone},
	// �����ֺ�
	{ msoEffectChangeFontSize, 0x0, presAnimEffectChangeFontSize, directionNone},
	// ��������
	{ msoEffectChangeFontStyle, 1, presAnimEffectChangeFontStyle, directionNone},
	// �Ŵ�/��С
	{ msoEffectGrowShrink, 0x0, presAnimEffectGrowShrink, directionNone},
	// ����������ɫ
	{ msoEffectChangeLineColor, 2, presAnimEffectChangeLineColor, directionNone},
	// ������
	{ msoEffectSpin, 0x0, presAnimEffectSpin, directionNone},
	// ͸��
	{ msoEffectTransparency, 0x0, presAnimEffectTransparency, directionNone},
	// �Ӵ���˸
	{ msoEffectBoldFlash, 0x0, presAnimEffectBoldFlash, directionNone},
	// ��ը
	{ msoEffectBlast, 0x0, presAnimEffectBlast, directionNone},
	// �Ӵ�չʾ
	{ msoEffectBoldReveal, 0x0, presAnimEffectBoldReveal, directionNone},
	// ��ɫ
	{ msoEffectBrushOnColor, 0x0, presAnimEffectBrushOnColor, directionNone},
	// �����»���
	{ msoEffectBrushOnUnderline, 0x0, presAnimEffectBrushOnUnderline, directionNone},
	// ��ɫ
	{ msoEffectColorBlend, 0x0, presAnimEffectColorBlend, directionNone},
	// ��ɫ����
	{ msoEffectColorWave, 0x0, presAnimEffectColorWave, directionNone},
	// ��ɫ
	{ msoEffectComplementaryColor, 0x0, presAnimEffectComplementaryColor, directionNone},
	// ��ɫ2
	{ msoEffectComplementaryColor2, 0x0, presAnimEffectComplementaryColor2, directionNone},
	// �Ա�ɫ
	{ msoEffectContrastingColor, 0x0, presAnimEffectContrastingColor, directionNone},
	// ����
	{ msoEffectDarken, 0x0, presAnimEffectDarken, directionNone},
	// ������
	{ msoEffectDesaturate, 0x0, presAnimEffectDesaturate, directionNone},
	// ��������
	{ msoEffectFlashBulb, 0x0, presAnimEffectFlashBulb, directionNone},
	// ����
	{ msoEffectFlicker, 0x0, presAnimEffectFlicker, directionNone},
	// ��ɫ����
	{ msoEffectGrowWithColor, 0x0, presAnimEffectGrowWithColor, directionNone},
	// �䵭
	{ msoEffectLighten, 0x0, presAnimEffectLighten, directionNone},
	// ��ʽǿ��
	{ msoEffectStyleEmphasis, 0x0, presAnimEffectStyleEmphasis, directionNone},
	// ���ΰ�
	{ msoEffectTeeter, 0x0, presAnimEffectTeeter, directionNone},
	// ��ֱͻ����ʾ
	{ msoEffectVerticalGrow, 0x0, presAnimEffectVerticalGrow, directionNone},
	// ������
	{ msoEffectWave, 0x0, presAnimEffectWave, directionNone},
	// ��˸
	{ msoEffectWink, 0x0, presAnimEffectWink, directionNone},
	// ����
	{ msoEffectFlash, 0x0, presAnimEffectFlash, directionNone},
};

// ·������
static const int Effect2003PPT2XMLDict_Path[][4] = 
{
	// 1 Բ����չ
	{msoEffectPathCircle, 0, presAnimEffectPathCircle, directionNone},
	// 2 ֱ��������
	{msoEffectPathRightTriangle, 0, presAnimEffectPathRightTriangle, directionNone},
	// 3 ����
	{msoEffectPathDiamond, 0, presAnimEffectPathDiamond, directionNone},
	// 4 ������
	{msoEffectPathHexagon, 0, presAnimEffectPathHexagon, directionNone},
	// 5 �����
	{msoEffectPath5PointStar, 0, presAnimEffectPath5PointStar, directionNone},
	// 6 ������
	{msoEffectPathCrescentMoon, 0, presAnimEffectPathCrescentMoon, directionNone},
	// 7 ������
	{msoEffectPathSquare, 0, presAnimEffectPathSquare, directionNone},
	// 8 ����
	{msoEffectPathTrapezoid, 0, presAnimEffectPathTrapezoid, directionNone},
	// 9 ����
	{msoEffectPathHeart, 0, presAnimEffectPathHeart, directionNone},
	// 10 �˱���
	{msoEffectPathOctagon, 0, presAnimEffectPathOctagon, directionNone},
	// 11 ������
	{msoEffectPath6PointStar, 0, presAnimEffectPath6PointStar, directionNone},
	// 12 �������
	{msoEffectPathFootball, 0, presAnimEffectPathFootball, directionNone},
	// 13 �ȱ�������
	{msoEffectPathEqualTriangle, 0, presAnimEffectPathEqualTriangle, directionNone},
	// 14 ƽ���ı���
	{msoEffectPathParallelogram, 0, presAnimEffectPathParallelogram, directionNone},
	// 15 �����
	{msoEffectPathPentagon, 0, presAnimEffectPathPentagon, directionNone},
	// 16 �Ľ���
	{msoEffectPath4PointStar, 0, presAnimEffectPath4PointStar, directionNone},
	// 17 �˽���
	{msoEffectPath8PointStar, 0, presAnimEffectPath8PointStar, directionNone},
	// 18 �����
	{msoEffectPathTeardrop, 0, presAnimEffectPathTeardrop, directionNone},
	// 19 �����
	{msoEffectPathPointyStar, 0, presAnimEffectPathPointyStar, directionNone},
	// 20 Բ��������
	{msoEffectPathCurvedSquare, 0, presAnimEffectPathCurvedSquare, directionNone},
	// 21 ������X
	{msoEffectPathCurvedX, 0, presAnimEffectPathCurvedX, directionNone},
	// 22 ��ֱ����8
	{msoEffectPathVerticalFigure8, 0, presAnimEffectPathVerticalFigure8, directionNone},
	// 23 ��������
	{msoEffectPathCurvyStar, 0, presAnimEffectPathCurvyStar, directionNone},
	// 24 ������·
	{msoEffectPathLoopdeLoop, 0, presAnimEffectPathLoopdeLoop, directionNone},
	// 25 Բ��
	{msoEffectPathBuzzsaw, 0, presAnimEffectPathBuzzsaw, directionNone},
	// 26 ˮƽ����8
	{msoEffectPathHorizontalFigure8, 0, presAnimEffectPathHorizontalFigure8, directionNone},
	// 27 ����
	{msoEffectPathPeanut, 0, presAnimEffectPathPeanut, directionNone},
	// 28 ˫8����
	{msoEffectPathFigure8Four, 0, presAnimEffectPathFigure8Four, directionNone},
	// 29 ����
	{msoEffectPathNeutron, 0, presAnimEffectPathNeutron, directionNone},
	// 30 Ʈ����
	{msoEffectPathSwoosh, 0, presAnimEffectPathSwoosh, directionNone},
	// 31 ����
	{msoEffectPathBean, 0, presAnimEffectPathBean, directionNone},
	// 32 ʮ������չ
	{msoEffectPathPlus, 0, presAnimEffectPathPlus, directionNone},
	// 33 ���ǽ�
	{msoEffectPathInvertedTriangle, 0, presAnimEffectPathInvertedTriangle, directionNone},
	// 34 �����ν�
	{msoEffectPathInvertedSquare, 0, presAnimEffectPathInvertedSquare, directionNone},
	// 35 ����
	{msoEffectPathLeft, 0, presAnimEffectPathLeft, directionNone},
	// 36 ������ת
	{msoEffectPathTurnRight, 0, presAnimEffectPathTurnRight, directionNone},
	// 37 ���»���
	{msoEffectPathArcDown, 0, presAnimEffectPathArcDown, directionNone},
	// 38 ��������
	{msoEffectPathZigzag, 0, presAnimEffectPathZigzag, directionNone},
	// 39 S������2
	{msoEffectPathSCurve2, 0, presAnimEffectPathSCurve2, directionNone},
	// 40 ���Ҳ�
	{msoEffectPathSineWave, 0, presAnimEffectPathSineWave, directionNone},
	// 41 ������
	{msoEffectPathBounceLeft, 0, presAnimEffectPathBounceLeft, directionNone},
	// 42 ����
	{msoEffectPathDown, 0, presAnimEffectPathDown, directionNone},
	// 43 ����ת
	{msoEffectPathTurnUp, 0, presAnimEffectPathTurnUp, directionNone},
	// 44 ���ϻ���
	{msoEffectPathArcUp, 0, presAnimEffectPathArcUp, directionNone},
	// 45 ����
	{msoEffectPathHeartbeat, 0, presAnimEffectPathHeartbeat, directionNone},
	// 46 ��������
	{msoEffectPathSpiralRight, 0, presAnimEffectPathSpiralRight, directionNone},
	// 47 ������
	{msoEffectPathWave, 0, presAnimEffectPathWave, directionNone},
	// 48 ��������
	{msoEffectPathCurvyLeft, 0, presAnimEffectPathCurvyLeft, directionNone},
	// 49 �Խ���������
	{msoEffectPathDiagonalDownRight, 0, presAnimEffectPathDiagonalDownRight, directionNone},
	// 50 ����ת
	{msoEffectPathTurnDown, 0, presAnimEffectPathTurnDown, directionNone},
	// 51 ������
	{msoEffectPathArcLeft, 0, presAnimEffectPathArcLeft, directionNone},
	// 52 ©��
	{msoEffectPathFunnel, 0, presAnimEffectPathFunnel, directionNone},
	// 53 ����
	{msoEffectPathSpring, 0, presAnimEffectPathSpring, directionNone},
	// 54 ���ҵ���
	{msoEffectPathBounceRight, 0, presAnimEffectPathBounceRight, directionNone},
	// 55 ��������
	{msoEffectPathSpiralLeft, 0, presAnimEffectPathSpiralLeft, directionNone},
	// 56 �Խ���������
	{msoEffectPathDiagonalUpRight, 0, presAnimEffectPathDiagonalUpRight, directionNone},
	// 57 ������ת
	{msoEffectPathTurnUpRight, 0, presAnimEffectPathTurnUpRight, directionNone},
	// 58 ���һ���
	{msoEffectPathArcRight, 0, presAnimEffectPathArcRight, directionNone},
	// 59 S������1
	{msoEffectPathSCurve1, 0, presAnimEffectPathSCurve1, directionNone},
	// 60 ˥����
	{msoEffectPathDecayingWave, 0, presAnimEffectPathDecayingWave, directionNone},
	// 61 ��������
	{msoEffectPathCurvyRight, 0, presAnimEffectPathCurvyRight, directionNone},
	// 62 ���½���
	{msoEffectPathStairsDown, 0, presAnimEffectPathStairsDown, directionNone},
	// 64 ����
	{msoEffectPathUp, 0, presAnimEffectPathUp, directionNone},
	// 63 ����
	{msoEffectPathRight, 0, presAnimEffectPathRight, directionNone},
	// 0 �Զ���·��
	{msoEffectCustom, 0, presAnimEffectCustom, directionNone},
};

// ý�嶯��
static const int Effect2003PPT2XMLDict_Media[][4] = 
{
	{msoEffectMediaPlay, 0, presAnimEffectMediaPlay, directionNone},
	{msoEffectMediaPause, 0, presAnimEffectMediaPause, directionNone},
	{msoEffectMediaStop, 0, presAnimEffectMediaStop, directionNone},
};

bool PPT2XML_Effect2003TypeDir(
	IN int pptType, IN int pptDir, IN int Class, OUT int& xmlType, OUT int& xmlDir)
{
	if ( (Class == PresetClassEntrance) ||
		 (Class == PresetClassExit))
	{
		for (int i = 0; i < countof(Effect2003PPT2XMLDict_EnterExit); ++i)
		{
			if (pptType == Effect2003PPT2XMLDict_EnterExit[i][0] && 
				pptDir == Effect2003PPT2XMLDict_EnterExit[i][1])
			{
				xmlType = Effect2003PPT2XMLDict_EnterExit[i][2];
				xmlDir = Effect2003PPT2XMLDict_EnterExit[i][3];
				return true;
			}
		}
	}
	
	if (Class == PresetClassEmphasis)
	{
		for(int i = 0; i < countof(Effect2003PPT2XMLDict_Enphasis); ++i)
		{
			if (pptType == Effect2003PPT2XMLDict_Enphasis[i][0])
			{
				xmlType = Effect2003PPT2XMLDict_Enphasis[i][2];
				xmlDir = pptDir;
				return true;
			}
		}
	}
	
	if (Class == PresetClassPath)
	{
		for(int i = 0; i < countof(Effect2003PPT2XMLDict_Path); ++i)
		{
			if (pptType == Effect2003PPT2XMLDict_Path[i][0])
			{
				xmlType = Effect2003PPT2XMLDict_Path[i][2];
				xmlDir = Effect2003PPT2XMLDict_Path[i][3];
				return true;
			}
		}
	}

	if (Class == PresetClassMediaCall)
	{
		for(int i = 0; i < countof(Effect2003PPT2XMLDict_Media); ++i)
		{
			if (pptType == Effect2003PPT2XMLDict_Media[i][0])
			{
				xmlType = Effect2003PPT2XMLDict_Media[i][2];
				xmlDir = Effect2003PPT2XMLDict_Media[i][3];
				return true;
			}
		}
	}
	ASSERT_ONCE(0);
	// Ŀǰ��֧�ֵĶ���Ч��ͳһ��Ϊ������Ч��
	xmlType = presAnimEffectFade;
	xmlDir = directionNone;
	return false;
}

bool XML2PPT_Effect2003TypeDir(
	IN int xmlType, IN int xmlDir,IN int subClass, OUT int& pptType, OUT int& pptDir)
{
	if ( (subClass == PresetClassEntrance) ||
		 (subClass == PresetClassExit))
	{
		for (int i = 0; i < countof(Effect2003PPT2XMLDict_EnterExit); ++i)
		{
			if (xmlType == Effect2003PPT2XMLDict_EnterExit[i][2] && 
				xmlDir == Effect2003PPT2XMLDict_EnterExit[i][3])
			{
				pptType = Effect2003PPT2XMLDict_EnterExit[i][0];
				pptDir = Effect2003PPT2XMLDict_EnterExit[i][1];
				return true;
			}
		}
	}

	if (subClass == PresetClassEmphasis)
	{
		for (int i = 0; i < countof(Effect2003PPT2XMLDict_Enphasis); ++i)
		{
			if (xmlType == Effect2003PPT2XMLDict_Enphasis[i][2])
			{
				pptType = Effect2003PPT2XMLDict_Enphasis[i][0];
				pptDir = xmlDir;
				return true;
			}
		}
	}

	if (subClass == PresetClassPath)
	{
		for (int i = 0; i < countof(Effect2003PPT2XMLDict_Path); ++i)
		{
			if (xmlType == Effect2003PPT2XMLDict_Path[i][2] && 
				xmlDir == Effect2003PPT2XMLDict_Path[i][3])
			{
				pptType = Effect2003PPT2XMLDict_Path[i][0];
				pptDir = Effect2003PPT2XMLDict_Path[i][1];
				return true;
			}
		}
	}
					
	if (subClass == PresetClassMediaCall)
	{
		for (int i = 0; i < countof(Effect2003PPT2XMLDict_Media); ++i)
		{
			if (xmlType == Effect2003PPT2XMLDict_Media[i][2] && 
				xmlDir == Effect2003PPT2XMLDict_Media[i][3])
			{
				pptType = Effect2003PPT2XMLDict_Media[i][0];
				pptDir = Effect2003PPT2XMLDict_Media[i][1];
				return true;
			}
		}
	}
	ASSERT_ONCE(0);
	// Ŀǰ��֧�ֵĶ���Ч��ͳһ��Ϊ����Ч��
	pptType = msoEffectFade;
	pptDir = 0x00; //directionBottom;
	return false;
}
// ----------------------------------------------------------------------------

long	MakeColor(int colorType, long r, long g, long b)
{
	long res = 0;
#define __MAKEARGB(r, g, b) (DWORD)((0xFF << 24) | RGB(b, g, r))
	switch (colorType) 
	{
	case ColorType_RGB:
		// rgb
		res = __MAKEARGB(r, g, b);
		break;
	case ColorType_HLS:
		// hls ÿ��λ��10λ�����ŵ�����ʾ, 
		res = (r & 0x000003ff) << 20 |
			(g & 0x000003ff) << 10 |
			(b & 0x000003ff);
		break;
	case ColorType_Schema:
		// color schema ������
		res = 0x00080000 | r;
		break;
	default:
		ASSERT(0);
		break;
	}
	return res;
}
