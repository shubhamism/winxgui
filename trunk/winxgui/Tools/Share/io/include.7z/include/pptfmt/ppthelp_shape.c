int XML2PPT_PlaceholderId(int id)
{
	switch(id)
	{
	case presPHNONE:					return PH_NONE;
	case presPHMASTERTITLE:				return PH_MASTERTITLE;
	case presPHMASTERBODY:				return PH_MASTERBODY;
	case presPHMASTERCENTEREDTITLE:		return PH_MASTERCENTEREDTITLE;
	case presPHMASTERSUBTITLE:			return PH_MASTERSUBTITLE;
	case presPHMASTERNOTESSLIDEIMAGE:	return PH_MASTERNOTESSLIDEIMAGE;
	case presPHMASTERNOTESBODYIMAGE:	return PH_MASTERNOTESBODYIMAGE;
	case presPHMASTERDATE:				return PH_MASTERDATE;
	case presPHMASTERSLIDENUMBER:		return PH_MASTERSLIDENUMBER;
	case presPHMASTERFOOTER:			return PH_MASTERFOOTER;
	case presPHMASTERHEADER:			return PH_MASTERHEADER;
	case presPHNOTESSLIDEIMAGE:			return PH_NOTESSLIDEIMAGE;
	case presPHNOTESBODY:				return PH_NOTESBODY;
	case presPHTITLE:					return PH_TITLE;
	case presPHBODY:					return PH_BODY;
	case presPHCENTEREDTITLE:			return PH_CENTEREDTITLE;
	case presPHSUBTITLE:				return PH_SUBTITLE;
	case presPHVERTICALTEXTTITLE:		return PH_VERTICALTEXTTITLE;
	case presPHVERTICALTEXTBODY:		return PH_VERTICALTEXTBODY;
	case presPHOBJECT:					return PH_OBJECT;
	case presPHGRAPH:					return PH_GRAPH;
	case presPHTABLE:					return PH_TABLE;
	case presPHCLIPART:					return PH_CLIPART;
	case presPHORGANISZATIONCHART:		return PH_ORGANISZATIONCHART;
	case presPHMEDIACLIP:				return PH_MEDIACLIP;
	}

	ASSERT(FALSE);

	return PH_NONE;
}