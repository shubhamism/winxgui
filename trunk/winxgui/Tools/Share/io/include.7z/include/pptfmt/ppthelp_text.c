#ifndef ppt_xml_impl
#error use ppthelp.c instead
#endif

int PPT2XML_FontAlignType(int lAligntype)
{
	switch (lAligntype)
	{
	case PF_Roman:			return kso_text::ptaRoman;
	case PF_Hanging:		return kso_text::ptaHanging;
	case PF_Centered:		return kso_text::ptaCentered;
	case PF_UpHoldingFixed:	return kso_text::ptaVariable;
	}

	ASSERT(0);
	return kso_text::ptaRoman;
}


int XML2PPT_FontAlignType(int align)
{
	switch (align)
	{
	case kso_text::ptaRoman:	return PF_Roman;
	case kso_text::ptaHanging:	return PF_Hanging;
	case kso_text::ptaCentered:	return PF_Centered;
	case kso_text::ptaVariable:	return PF_UpHoldingFixed;
	};

	ASSERT(0);
	return PF_Roman;
}


int PPT2XML_AlignType(int lAligntype)
{
	switch (lAligntype)
	{
	case PF_Left:			return kso_text::paLeft;
	case PF_Center:			return kso_text::paCenter;
	case PF_Right:			return kso_text::paRight;
	case PF_Justify:		return kso_text::paLeftRight;
	case PF_Distributed:	return kso_text::paDistribute;
	}

	ASSERT(0);
	return kso_text::paLeft;
}

int XML2PPT_AlignType(int align)
{
	switch (align)
	{
	case kso_text::paLeft:		return PF_Left;
	case kso_text::paCenter:	return PF_Center;
	case kso_text::paRight:		return PF_Right;
	case kso_text::paLeftRight:	return PF_Justify;
	case kso_text::paDistribute:return PF_Distributed;
	};

	ASSERT(0);
	return PF_Left;
}

int XML2PPT_BulletType(int nType)
{
	switch (nType)
	{
	case -1:				return Bullet_None;
	case presListDefault:	return Bullet_None;
	case presListImage:		return Bullet_Picture;
	case presListAutoNum:	return Bullet_Numbered;
	case presListBullet:	return Bullet_Char;
	};

	ASSERT(FALSE);
	return Bullet_None;
}
