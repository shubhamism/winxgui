// -------------------------------------------------------------------------
//	�ļ���		��	iox_kfc.h
//	������		��	wanghui
//	����ʱ��	��	2003-4-8 17:26:03
//	��������	��	ʹ��KFCʱ���������ͷ�ļ�
//
// -------------------------------------------------------------------------
#ifndef __IOX_KFC_H__
#define __IOX_KFC_H__

#define USE_ST_MODEL	//ǿ��ʹ��KSingleThreadModel

#include "kfc.h"
using namespace kfc;
#include "iox_stl.h"	// һ��Ҫ����kfc.h֮��
#include "kfc/comobj.h"
#include "kfc/classfactory.h"
#include "kfc/strapi.h"
#include "kfc/guid.h"
#include "kfc/variant.h"
#include "kfc/datetime.h"


// -------------------------------------------------------------------------
#define KCOMPTR(itf)	ks_stdptr<itf>
#define KCOMQIPTR(itf)	ks_comptr<itf, &IID_##itf>

#ifndef RGB
#define RGB(r,g,b)          ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
#endif

#ifndef min
#define min(a,b)    (((a) < (b)) ? (a) : (b))
#endif

#ifndef max
#define max(a,b)    (((a) > (b)) ? (a) : (b))
#endif


#ifndef STDIMP
#define STDIMP HRESULT __stdcall
#endif

#ifndef STDIMP_
#define STDIMP_(type)	type __stdcall
#endif

#ifndef VS
#define VS(x) VERIFY(SUCCEEDED(x))
#endif

#ifndef VERIFY_SUCCEEDED
#define VERIFY_SUCCEEDED(x)		VERIFY(SUCCEEDED(x))
#endif

#ifndef AS
#define AS(x) ASSERT(SUCCEEDED(x))
#endif

#define RP2(a, b)\
{\
	kfc::ks_wstring msg;\
	Format(msg, __L(a), b);\
	REPORT(msg.c_str());\
}\

#define RP3(a, b, c)\
{\
	kfc::ks_wstring msg;\
	Format(msg, __L(a), b, c);\
	REPORT(msg.c_str());\
}\

#define RP4(a, b, c, d)\
{\
	kfc::ks_wstring msg;\
	Format(msg, __L(a), b, c, d);\
	REPORT(msg.c_str());\
}\

// -------------------------------------------------------------------------
#endif // __IOX_KFC_H__
