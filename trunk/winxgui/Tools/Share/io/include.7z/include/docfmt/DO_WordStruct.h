// -------------------------------------------------------------------------
//	�ļ���		��	DO_WordStruct.h
//	������		��	whui
//	����ʱ��	��	2001-8-6 16:31:37
//	��������	��	����Word�ļ���ʽ���ض��������������
//
//	$Id: DO_WordStruct.h,v 1.13 2006/08/23 02:19:04 chenghui Exp $
// -------------------------------------------------------------------------
#ifndef __DO_WORDSTRUCT_H__
#define __DO_WORDSTRUCT_H__

#define __MSO_FILEFMT_WORD_SPRM_OPRAND_PARAGRAPH_H__
#define __MSO_FILEFMT_WORD_DRAW_GDI_H__

#if defined(__LINUX__)
#include "linux/types.h"
#endif

#include <limits>


#pragma pack(push) 		// ��һ��Ӧ�ñ�֤���ڣ�
#pragma pack(1)

// -------------------------------------------------------------------------

typedef DWORD	FC;
typedef DWORD	LCB;
typedef USHORT	CB;
typedef DWORD	PN;
typedef DWORD	CP;			// Character Position
typedef	DWORD	CCH;		// Characters Count
typedef WORD	BF;			// Bit Field
typedef WORD	FTC;		// Font Code
typedef WORD	ISTD;		// Indexes to STyle Descriptors
#define FKP_BYTES 0x200

// modify by LL @ 02/10/8
typedef struct tagDTTM         // DaTe and TiMe 
{
	unsigned mint	: 6;  // minutes (0-59)
	unsigned hr		: 5;  // hours (0-23)
	unsigned dom	: 5;  // days of month (1-31)
	unsigned mon	: 4;  // months (1-12)
	unsigned yr		: 9;  // years (1900-2411)-1900
	unsigned wdy	: 3;  // weekday (Sun=0 .. Sat=6)
}DTTM;
// modify end
 
typedef short	PRM;		// Property Modifier

typedef WORD	STI;		//STyle Identifier 
typedef WORD	OPCODE;		//sprm opcode 
typedef short	LID;		//language identification code
typedef WORD	XCHAR;		//sprm opcode 
typedef short	FRD;		//Footnote Reference Descriptor 
typedef DWORD	SPID;		//Shape id

// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
// { ---> Table Stream�е�һЩ�ṹ

//------------------------------------------------
//�ṹ��:	SED ---> Plcf SED
//������:	Word97�����ļ���ָ��SEPX����λ�õĽṹ
//------------------------------------------------
typedef struct tagSED
{
	SHORT	fn					;//used internally by Word
	
	FC		fcSepx				;//SEPX���ݿ�ʼ��main stream �е��ļ�ƫ��
	SHORT	fnMpr				;//used internally by Word
	FC		fcMpr				;//points to offset in FC space of main stream where 
								 //the Macintosh Print Record for a document created on 
								 //a Mac will be stored
}SED;

//------------------------------------------------
//�ṹ��:	PCD(Piece Descriptor) ---> Clx ֮ Plcf PCD
//������:	����piece��Ϣ
//------------------------------------------------
typedef struct tagPCD
{
	SHORT	fNoParaLast	:1;	//when 1, means that piece contains no end of paragraph marks.
	SHORT	fPaphNil	:1;	//used internally by Word
	SHORT	fCopied		:1;	//used internally by Word
	SHORT	nUnsed		:5;	//
	SHORT	fn			:8;	//used internally by Word
	ULONG	fc;				//file offset of beginning of piece. 
	WORD	prm;			//Property Modifier
}PCD;

struct KPlcfpcdHdr
{
	BYTE clxt;
	ULONG lcbPlcfpcd;
};

#define	GRBIT_PCD_ANSI			0x40000000L

// { ---> PCD.fc ֮����: �����ı����ļ�ƫ�ƣ��Լ����õı��롣
//	if (PCD.fc & GRBIT_PCD_ANSI)	// ��UNICODE:
//		fcText = (PCD.fc & ~GRBIT_PCD_ANSI) >> 1
//  else // UNICODE
//		cbText = (cp[i+1] - cp[i]) * sizeof(WCHAR)
// }
//------------------------------------------------
//�ṹ��:	FFN(Font Family Name) ---> Sttbfffn
//������:	
//------------------------------------------------
typedef struct tagFFN
{
	UCHAR	cbFfnM1;	// total length of FFN - 1.
	struct tagHead
	{
		UCHAR	prq			:2;		//pitch request
		UCHAR	fTrueType	:1;		//when 1, font is a TrueType font
		UCHAR	reserved1	:1;		//reserved
		UCHAR	ff			:3;		//font family id
		UCHAR	reserved2	:1;		//reserved
		SHORT	wWeight;	//base weight of font
		UCHAR	chs;		//character set identifier
		UCHAR	ixchSzAlt;	//�������忪ʼλ��
		PANOSE	panose;
		FONTSIGNATURE	fs;
	} head;
	PBYTE	xszFfn;
	PBYTE	xszFfnAlt;
}FFN;

//------------------------------------------------
//�ṹ��:	STSHI(STyle SHeet Information) ---> Stshf
//������:	Word�ļ��е���ʽ���ĸ�Ҫ��Ϣ
//------------------------------------------------
typedef struct tagSTSHI
{
	USHORT  cstd;                          // Count of styles in stylesheet
	USHORT  cbSTDBaseInFile;               // Length of STD Base as stored in a file
	BF      fStdStylenamesWritten : 1;     // Are built-in stylenames stored?
	BF		:  15;                         // Spare flags
	USHORT  stiMaxWhenSaved;               // Max sti known when this file was written
	USHORT  istdMaxFixedWhenSaved;         // How many fixed-index istds are there?
	USHORT  nVerBuiltInNamesWhenSaved;     // Current version of built-in stylenames
	FTC     rgftcStandardChpStsh[3];       // ftc used by StandardChpStsh for this document
}STSHI;

//------------------------------------------------
//�ṹ��:	BASE_STD(STyle Descriptor Base part) ---> Stshf
//������:	������ʽ�ľ�������
//------------------------------------------------
enum  STYLETYPE		// tagBASE_STD::sgc
{
	ST_NONE/*û������*/, 
	ST_PARA/*paragraph style*/,
	ST_CHP /*character style*/,
	ST_TAP /*table style*/,
};

typedef struct tagBASE_STD
{
	// Base part of STD:
	USHORT    sti		: 12;	// invariant style identifier 
	USHORT    fScratch	: 1;	// spare field for any temporary use,always reset back to zero!
	USHORT    fInvalHeight : 1;	// PHEs of all text with this style are wrong
	USHORT    fHasUpe	: 1;    // UPEs have been generated
	USHORT    fMassCopy : 1;    // std has been mass-copied; if unused atsave time, style should be deleted

	USHORT    sgc		: 4;    // **style type code
	USHORT    istdBase	: 12;   // **base style

	USHORT    cupx		: 4;    // # of UPXs (and UPEs)
	USHORT    istdNext	: 12;   // **next style

	USHORT    bchUpe;           // offset to end of upx's, start of upe's

	USHORT    fAutoRedef : 1;   // auto redefine style when appropriate
	USHORT    fHidden	: 1;    // hidden from UI?
	USHORT				: 14;   // unused bits
}BASE_STD;

typedef struct tagBASE_STDEX : public BASE_STD
{
	UINT16	istdLink	: 12;	// ������ʽ��0������������ʽ��
								// ��API�û��ǶȽ���������ʽ����ָ������ʽ���ӵ�����ʽ��
	UINT16	fPropRMark	: 1;	// �Ƿ���ڸ�ʽ�޶�
	UINT16	grbitUnk2	: 3;

	UINT32	styrsid;
	//
	//	��������Ǵ�rtfָ��\styrsid���ù����ġ�����Rtf Specification 1.6��δ�������塣
	//
	//	��Ӧ����һ��id����Ϊrsid����ϸ����δ֪����WordML�İ��������������
	//	rsid element
	//	 - Represents the Revision Save ID for this style, which is 
	//	   a unique identifier used to track when the style was last changed.
	//
	//	�ɴ˿ɼ�����Ӧ����һ�����ڸ�ʽ�޸ĸ��٣�FormatChange Track����ʱ�����
	//
	UINT16	unknown2;
}BASE_STDEX;

//------------------------------------------------
//�ṹ��:	FLD(Field Descriptor)
//������:	������ָ���
//------------------------------------------------
typedef struct	tagFlag				//������β����
{
	UCHAR	fDiffer:1;
	UCHAR	fZombieEmbed:1;
	UCHAR	fResultDirty:1;
	UCHAR	fResultEdited:1;
	UCHAR	fLocked:1;
	UCHAR	fPrivateResult:1;
	UCHAR	fNested:1;			//��ʾ��ǰ���Ƿ�Ƕ������һ������
	UCHAR	fHasSep:1;			//��ʾ��ǰ���Ƿ�����ָ���(0x14)
} FLD_FLAG;

typedef struct tagFLD
{
	UCHAR	ch : 5;					//�ṹ��ʾ����?��β?��ָ���?
	UCHAR	reserved: 3;
	union	Mark
	{
		UCHAR	flt;				//�������׷���,��ʾ������(field type)
		FLD_FLAG flag;
	} mark;
}FLD;

//------------------------------------------------
//�ṹ��:	FSPA(File Shape Address)
//������:	
//˵  ��:	
//------------------------------------------------
typedef struct tagFSPA
{
	LONG	spid;
	ULONG	xaLeft;		//������ߵ�ˮƽλ��
	ULONG	yaTop;		//�����ϱߵĴ�ֱλ��
	ULONG	xaRight;	//�����ұߵ�ˮƽλ��
	ULONG	yaBottom;	//�����±ߵĴ�ֱλ��
	USHORT	fHdr	:1;
	USHORT	bx		:2;	//x position of shape relative to anchor CP
	USHORT	by		:2; //y position of shape relative to anchor CP
	USHORT	wr		:4; //text wrapping mode 
	USHORT	wrk		:4; //text wrapping mode type (valid only for wrapping modes 2 and 4
	USHORT	fScaSimple	:1; //when set, temporarily overrides bx, by, forcing the xaLeft, xaRight, yaTop, and yaBottom fields to all be page relative
	USHORT	fBolowText	:1;
	USHORT	fAnchorLock	:1;
	LONG	cTxbx;
}FSPA;

//------------------------------------------------
//�ṹ��:	BKD(BreaK Descriptor)
//������:	
//------------------------------------------------
typedef struct tagBKD
{
	SHORT	ipt;				//
	SHORT	dcpDepend;			//
	USHORT	icol :8;			//
	USHORT	fTableBreak	:1;		//table break	
	USHORT	fColumnBreak:1;		//column break
	USHORT	fMarked:1;			//
	USHORT	fUnk:1;
	USHORT	fTextOverflow:1;
}BKD;

typedef struct tagFTXBXS
{
	LONG	ci;
	LONG	cReusable;
	SHORT	fReusable;
	LONG	reserved;
	LONG	lid;
	LONG	txidUndo;
}FTXBXS;

//------------------------------------------------
//�ṹ��:	ASUMYI(AutoSummary Info)
//������:	
//˵����:	2003-11-19 �� nature ����
//------------------------------------------------
//typedef struct tagASUMYI
//{
//	SHORT	fValid		:1;	//true iff the ASUMYI is valid
//	SHORT	fView		:1;	//true iff AutoSummary View is active
//	SHORT	iViewBy		:2;	// Display method for AutoSummary View:
//								//0 = Emphasize in current doc
//								//1 = Reduce doc to summary
//								//2 = Insert into doc
//								//3 = Show in new document
//	SHORT	fUpdateProps:1;	//true if we should update File Properties summary information after the next summarization
//	SHORT	reserved	:11;//reserved
//	SHORT	wDlgLevel;		//Dialog summary level
//	LONG	lHighestLevel;	//upper bound for lLevel for sentences in this document
//	LONG	lCurrentLevel;	// show document sentences at or below this level
//}ASUMYI;

//------------------------------------------------
//�ṹ��:	Drawing Object Grid(DOGRID)
//������:	
//˵����:	2003-11-19 �� nature ����
//------------------------------------------------
//typedef struct tagDOGRID
//{
//	SHORT	xaGrid;				//x-coordinate of the upper left-hand corner of the grid
//	SHORT	yaGrid;				//y-coordinate of the upper left-hand corner of the grid
//	SHORT	dxaGrid;			//width of each grid square
//	SHORT	dyaGrid;			//height of each grid square
//	SHORT	dyGridDisplay	:7;	//the number of grid squares (in the y direction) between each gridline drawn on the screen. 0 means don't display any gridlines in the y direction.
//	SHORT	fTurnItOff		:1;	//suppress display of gridlines
//	SHORT	dxGridDisplay	:7;	//the number of grid squares (in the x direction) between each gridline drawn on the screen. 0 means don't display any gridlines in the y direction.
//	SHORT	fFollowMargins	:1;	//if true, the grid will start at the left and top margins and ignore xaGrid and yaGrid.
//}DOGRID;

//------------------------------------------------
//�ṹ��:	Document Typography Info(DOPTYPOGRAPHY)
//������:
//˵����:	2003-11-19 �� nature ����
//------------------------------------------------
//typedef struct tagDOPTYPOGRAPHY
//{
//	USHORT	fKerningPunct	:1; //true if we're kerning punctuation 
//	USHORT	iJustification	:2; //Kinsoku method of justification: 
//									//0 = always expand 
//									//1 = compress punctuation 
//									//2 = compress punctuation and kana. 
//	USHORT	iLevelOfKinsoku	:2;	//Level of Kinsoku: 
//									//0 = Level 1 
//									//1 = Level 2 
//									//2 = Custom 
//	USHORT	f2on1			:1;	//merge page, 2-page-on-1
//	USHORT	reserved		:10;//reserved
//	SHORT	cchFollowingPunct;	//length of rgxchFPunct 
//	SHORT	cchLeadingPunct;	//length of rgxchLPunct 
//	XCHAR	rgxchFPunct[101];	//array of characters that should never appear at the start of a line 
//	XCHAR	rgxchLPunct [51];	//array of characters that should never appear at the end of a line
//}DOPTYPOGRAPHY;
//------------------------------------------------
//�ṹ��:	DOP(DOcument Properties)
//������:	�����ĵ�����
//------------------------------------------------
//typedef struct tagDOP
//{
//	USHORT	fFacingPages			:1;	//1 when facing pages should be printed
//	USHORT	fWidowControl			:1;	//1 when widow control is in effect.
//										//0 when widow control disabled.
//	USHORT	fPMHMainDoc				:1;	//1 when doc is a main doc for Print Merge Helper,
//										//0 when not;
//										//default=0
//	USHORT	grfSuppression			:2;	//Default line suppression storage; 
//										//0= form letter line suppression; 
//										//1= no line suppression;
//										//default=0. No longer used.
//	//-{{modify by nature @ 2003/11/19	
//	//SHORT	fpc						:2;	//footnote position code
//	//SHORT	unused					:1;	//unused;
//	//SHORT	grpfIhdt				:8;	//No longer used.
//	//SHORT	rncFtn					:2;	//restart index for footnotes
//	//SHORT	nFtn					:14;//initial footnote number for document
//	USHORT	fpc						:2;	//footnote position code
//										//0 print as endnotes
//										//1 print at bottom of page
//										//2 print immediately beneath text
//	USHORT	unused					:1;	//unused;
//	USHORT	grpfIhdt				:8;	//No longer used.
//	USHORT	rncFtn					:2;	//restart index for footnotes
//										//0 don't restart note numbering
//										//1 restart for each section
//										//2 restart for each page
//	USHORT	nFtn					:14;//initial footnote number for document
//	//-}}modify end
//	USHORT	fOutlineDirtySave		:1;	//when 1, indicates that information in the hplcpad should be refreshed
//										//since outline has been dirtied
//	USHORT	reserved1				:7;	//reserved
//	USHORT	fOnlyMacPics			:1;	//when 1, Word believes all pictures recorded in the document 
//										//were created on a Macintosh
//	USHORT	fOnlyWinPics			:1;	//when 1, Word believes all pictures recorded in the document w
//										//ere created in Windows
//	USHORT	fLabelDoc				:1;	//when 1, document was created as a print merge labels document
//	USHORT	fHyphCapitals			:1;	//when 1, Word is allowed to hyphenate words that are capitalized. 
//										//When 0, capitalized may not be hyphenated
//	USHORT	fAutoHyphen				:1;	//when 1, Word will hyphenate newly typed text as a background task
//	USHORT	fFormNoFields			:1;
//	USHORT	fLinkStyles				:1;	//when 1, Word will merge styles from its template
//	//-{{modify by nature @ 2003/11/24
//	//SHORT	fRevMarking				:1;	//when 1, Word will mark revisions as the document is edited
//	USHORT	fRevMarking				:1;	//when 1, Word will mark revisions as the document is edited
//	//-}}modify end
//	USHORT	fBackup					:1;	//always make backup when document saved when 1.
//	USHORT	fExactCWords			:1;	//when 1, the results of the last Word Count execution 
//										//(as recorded in several DOP fields) are still exactly correct.
//	USHORT	fPagHidden				:1;	//when 1, hidden document contents are displayed
//	USHORT	fPagResults				:1;	//when 1, field results are displayed, when 0 field codes are displayed.
//	USHORT	fLockAtn				:1;	//when 1, annotations are locked for editing
//	//-{{modify by nature @ 2003/11/21
//	//SHORT	fMirrorMargins			:1;	//swap margins on left/right pages when 1.
//	USHORT	fMirrorMargins			:1;	//swap margins on left/right pages when 1.
//	//-}}modify end
//	USHORT	reserved2				:1;	//reserved
//	USHORT	fDfltTrueType			:1;	//when 1, use TrueType fonts by default
//										//(flag obeyed only when doc was created by WinWord 2.x)
//	USHORT	fPagSuppressTopSpacing	:1;	//when 1, file created with SUPPRESSTOPSPACING=YES in win.ini. 
//										//(flag obeyed only when doc was created by WinWord 2.x).
//	USHORT	fProtEnabled			:1;	//when 1, document is protected from edit operations
//	USHORT	fDispFormFldSel			:1;	//when 1, restrict selections to occur only within form fields
//	USHORT	fRMView					:1;	//when 1, show revision markings on screen
//	USHORT	fRMPrint				:1;	//when 1, print revision marks when document is printed
//	//-{{modify by nature @ 2003/11/19
//	//SHORT	reserved3				:7;	//reserved
//	USHORT	reserved3				:1;	//reserved
//	//-}}modify end
//	USHORT	fLockRev				:1;	//when 1, the current revision marking state is locked
//	USHORT	fEmbedFonts				:1;	//when 1, document contains embedded TrueType fonts
//	struct
//	{
//		USHORT	fNoTabForInd		:1;	//compatibility option: when 1, don't add automatic tab stops for hanging indent
//		USHORT	fNoSpaceRaiseLower	:1;	//compatibility option: when 1, suppress the paragraph Space Before 
//										//and Space After options after a page break
//		USHORT	fSuppressSpbfAfterPageBreak	:1;	//compatibility option: when 1, suppress the paragraph Space Before 
//												//and Space After options after a page break
//		USHORT	fWrapTrailSpaces	:1;	//compatibility option: when 1, wrap trailing spaces at the end of a line 
//										//to the next line
//		USHORT	fMapPrintTextColor	:1;	//compatibility option: when 1, print colors as black on non-color printers
//		USHORT	fNoColumnBalance	:1;	//compatibility option: when 1, don't balance columns for 
//										//Continuous Section starts
//		USHORT	fConvMailMergeEsc	:1;	//
//		USHORT	fSupressTopSpacing	:1;	//compatibility option: when 1, suppress extra line spacing at top of page
//		USHORT	fOrigWordTableRules	:1;	//compatibility option: when 1, combine table borders like Word 5.x 
//										//for the Macintosh
//		USHORT	fTransparentMetafiles	:1;//compatibility option: when 1, don't blank area between metafile pictures
//		USHORT	fShowBreaksInFrames	:1;	//compatibility option: when 1, show hard page or column breaks in frames
//		USHORT	fSwapBordersFacingPgs	:1;//compatibility option: when 1, swap left and right pages on odd facing pages
//		USHORT	reserved			:1;	//reserved
//	} copts;
//	USHORT	dxaTab;						//default tab width  720 twips
//	USHORT	wSpare;
//	USHORT	dxaHotZ;				//width of hyphenation hot zone measured in twips
//	USHORT	cConsecHypLim;			//number of lines allowed to have consecutive hyphens
//	USHORT	wSpare2;				//reserved
//	DTTM	dttmCreated;			//date and time document was created
//	DTTM	dttmRevised;			//date and time document was last revised
//	DTTM	dttmLastPrint;			//date and time document was last printed
//	//-{{modify by nature @ 2003/11/19	
//	//INT	nRevision;				//number of times document has been revised since its creation
//	//LONG	cWords;					//count of words tallied by last Word Count execution
//	//LONG	cCh;					//count of characters tallied by last Word Count execution
//	//INT	cPg;					//count of pages tallied by last Word Count execution
//	//SHORT	cPg;					//count of pages tallied by last Word Count execution
//	//LONG	cParas;					//count of paragraphs tallied by last Word Count execution	
//	//SHORT	mcEdn				:2;	//restart endnote number code
//	//SHORT	nEdn				:14;//beginning endnote number
//	//SHORT	epc					:2;	//endnote position code
//	//SHORT	nfcFtnRef			:4;	//number format code for auto footnotes
//	USHORT	nRevision;				//number of times document has been revised since its creation
//	ULONG	tmEdited;				//time document was last edited
//	ULONG	cWords;					//count of words tallied by last Word Count execution
//	ULONG	cCh;					//count of characters tallied by last Word Count execution
//	USHORT	cPg;					//count of pages tallied by last Word Count execution
//	ULONG	cParas;					//count of paragraphs tallied by last Word Count execution
//	USHORT	mcEdn				:2;	//restart endnote number code
//	USHORT	nEdn				:14;//beginning endnote number
//	USHORT	epc					:2;	//endnote position code
//	USHORT	nfcFtnRef			:4;	//number format code for auto footnotes
//									//0 Arabic
//									//1 Upper case Roman
//									//2 Lower case Roman
//									//3 Upper case Letter
//									//4 Lower case Letter
//	USHORT	nfcEdnRef			:4; //number format code for auto endnotes
//	//-}}modify end
//	USHORT	fPrintFormData		:1;	//only print data inside of form fields
//	USHORT	fSaveFormData		:1;	//only save document data that is inside of a form field.
//	USHORT	fShadeFormData		:1;	//shade form fields
//	USHORT	reserved4			:2;	//reserved
//	USHORT	fWCFtnEdn			:1;	//when 1, include footnotes and endnotes in word count
//	ULONG	cLines;					//count of lines tallied by last Word Count operation
//	ULONG	cWordsFtnEnd;			//count of words in footnotes and endnotes tallied by last Word Count operation
//	ULONG	cChFtnEdn;				//count of characters in footnotes and endnotes tallied by last Word Count operation
//	USHORT	cPgFtnEdn;				//count of pages in footnotes and endnotes tallied by last Word Count operation
//	ULONG	cParasFtnEdn;			//count of paragraphs in footnotes and endnotes tallied by last Word Count operation
//	ULONG	cLinesFtnEdn;			//count of paragraphs in footnotes and endnotes tallied by last Word Count operation
//	ULONG	lKeyProtDoc;			//document protection password key, only valid if dop.fProtEnabled, dop.
//									//fLockAtn or dop.fLockRev are 1.
//	//-{{modify by nature @ 2003/11/24
//	//SHORT	wvkSaved			:3;	//document view kind
//	USHORT	wvkSaved			:3;	//document view kind
//									//0 Normal view
//									//1 Outline view
//									//2 Page View
//	//-}}modify end
//	USHORT	wScaleSaved			:9;	//zoom percentage
//	USHORT	zkSaved				:2;	//zoom type
//									//0 None
//									//1 Full page
//									//2 Page width
//	USHORT	fRotateFontW6		:1;	//This is a vertical document (Word 6/95 only)
//	USHORT	iGutterPos			:1;	//Gutter position for this doc: 0 => side; 1 => top
//}DOP;
//------------------------------------------------
//�ṹ��:	DOPEP1(DOcument Properties Expand Part 1)
//������:	�����ĵ�����
//˵����:	2003-11-19 �� nature ����
//------------------------------------------------
//typedef struct tagDOPEP1
//{
//	USHORT	fNoTabForInd		:1;	//(see above)
//	USHORT	fNoSpaceRaiseLower	:1;	//(see above)
//	USHORT	fSupressSpbfAfterPageBreak	:1;	//(see above)
//	USHORT	fWrapTrailSpaces	:1;	//(see above)
//	USHORT	fMapPrintTextColor	:1;	//(see above)
//	USHORT	fNoColumnBalance	:1;	//(see above)
//	USHORT	fConvMailMergeEsc	:1;	//(see above)
//	USHORT	fSupressTopSpacing	:1;	//(see above)
//	USHORT	fOrigWordTableRules	:1;	//(see above)
//	USHORT	fTransparentMetafiles		:1;	//(see above)
//	USHORT	fShowBreaksInFrames	:1;	//(see above)
//	USHORT	fSwapBordersFacingPgs		:1;	//(see above)
//	USHORT	reserved1			:4;	//(reserved)
//	USHORT	fSuppressTopSpacingMac5		:1;	//Suppress extra line spacing at top of page like MacWord 5.x
//	USHORT	fTruncDxaExpand		:1;	//Expand/Condense by whole number of points.
//	USHORT	fPrintBodyBeforeHdr	:1;	//Print body text before header/footer
//	USHORT	fNoLeading			:1;	//Don't add leading (extra space) between rows of text
//	USHORT	reserved2			:1;	//(reserved)
//	USHORT	fMWSmallCaps		:1;	//Use larger small caps like MacWord 5.x
//	USHORT	reserved3			:10;//(reserved)
//}DOPEP1;
//------------------------------------------------
//�ṹ��:	DOPEP2(DOcument Properties Expand Part 2)
//������:	�����ĵ�����
//˵����:	2003-11-19 �� nature ����
//------------------------------------------------
//typedef struct tagDOPEP2
//{
//	USHORT	adt;					//Autoformat Document Type: 0 for normal. 1 for letter, and 2 for email.
//	DOPTYPOGRAPHY	doptypography;	//see DOPTYPOGRAPHY
//	DOGRID	dogrid;					//see DOGRID	 
//	USHORT	reserved1			:1;	//Always set to zero when writing files
//	USHORT	lvl					:4;	//Which outline levels are showing in outline view (0 => heading 1 only, 4 => headings 1 through 5, 9 => all levels showing)
//	USHORT	fGramAllDone		:1;	//Doc has been completely grammar checked
//	USHORT	fGramAllClean		:1;	//No grammer errors exist in doc
//	USHORT	fSubsetFonts		:1;	//if you are doing font embedding, you should only embed the characters in the font that are used in the document
//	USHORT	fHideLastVersion	:1;	//Hide the version created for autoversion
//	USHORT	fHtmlDoc			:1;	//This file is based upon an HTML file
//	USHORT	reserved2			:1;	//Always set to zero when writing files
//	USHORT	fSnapBorder			:1;	//Snap table and page borders to page border
//	USHORT	fIncludeHeader		:1;	//Place header inside page border
//	USHORT	fIncludeFooter		:1;	//Place footer inside page border 
//	USHORT	fForcePageSizePag	:1;	//Are we in online view
//	USHORT	fMinFontSizePag		:1;	//Are we auto-promoting fonts to >= hpsZoonFontPag?
//	USHORT	fHaveVersions		:1;	//versioning is turned on
//	USHORT	fAutoVersion		:1;	//autoversioning is enabled
//	USHORT	reserved			:14;//Always set to zero when writing files
//	ASUMYI	asumyi;					//Autosummary info
//	ULONG	cChWS;					//Count of characters with spaces
//	ULONG	cChWSFtnEdn;			//Count of characters with spaces in footnotes and endnotes
//	ULONG	grfDocEvents;
//	ULONG	fVirusPrompted		:1;	//Have we prompted for virus protection on this doc?
//	ULONG	fVirusLoadSafe		:1;	//If prompted, load safely for this doc?
//	ULONG	KeyVirusSession30	:30;//Random session key to sign above bits for a Word session.
//	BYTE	Spare[30];				//Spare
//	ULONG	reserved3;				//Always set to zero when writing files
//	ULONG	reserved4;				//Always set to zero when writing files
//	ULONG	cDBC;					//Count of double byte characters
//	ULONG	cDBCFtnEdn;				//Count od double byte characters in footnotes and endnotes
//	ULONG	reserved5;				//Always set to zero when writing files
//	USHORT	nfcFtnRef;				//number format code for auto footnote references
//									//0 Arabic
//										//1 Upper case Roman
//										//2 Lower case Roman
//										//3 Upper case Letter
//										//4 Lower case Letter
//	USHORT	nfcEdnRef;				//number format code for auto endnote references
//										//0 Arabic
//										//1 Upper case Roman
//										//2 Lower case Roman
//										//3 Upper case Letter
//										//4 Lower case Letter
//	USHORT	hpsZoonFontPag;			//minimum font size if fMinFontSizePag is true
//	USHORT	dywDispPag;				//height of the window in online view during last repag
//}DOPEP2;
//------------------------------------------------
//�ṹ��:	DOPEP3(DOcument Properties Expand Part 3)
//������:	�����ĵ�����
//˵����:	2003-11-27 �� nature ����
//------------------------------------------------
//typedef struct tagDOPEP3
//{
//	BYTE	unknown[44];			//Unknown Block
//}DOPEP3;

typedef struct tagBTE
{
	PN		pn		: 22;
	LONG	unused	: 10;
}BTE;
// } ---> TableStream�е�һЩ�ṹ
// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
// { ---> WordDocument Stream �е�һЩ�ṹ

//------------------------------------------------
//�ṹ��:	PHE(Paragraph HEight) ---> Plcfbte PAPX������
//������:	�����θ���Ϣ
//------------------------------------------------
typedef struct tagPHE
{
	SHORT	fSpare		:1;
	SHORT	fUnk		:1;
	SHORT	fDiffLines	:1;	//when 1, total height of paragraph is known 
							//but lines in paragraph have different heights.
	SHORT	reserved1	:5;
	SHORT	clMac		:8;	//when fDiffLines is 0 is number of lines in paragraph
	SHORT	reserved2;
	LONG	dxaCol;
	union
	{
		LONG	dymLine;	//when fDiffLines is 0, 
							//is height of every line in paragraph in pixels
		LONG	dymHeight;	//when fDiffLines is 1, 
							//is the total height in pixels of the paragraph
	};
}PHE;

//------------------------------------------------
//�ṹ��:	FKP_BX
//������:	������PAPX FKP�е�BX�ṹ
//------------------------------------------------
typedef struct tagFKP_BX
{
	BYTE	bxOffset;	//word offset
	PHE		bxPhe;
}FKP_BX;

//------------------------------------------------
//�ṹ��:	BRC(BoRder Code)
//��  ��:	
//------------------------------------------------
typedef struct tagBRC
{
	USHORT	dptLineWidth	:8;	//�����߿���(in 1/8 pt, max of 32 pt)
	USHORT	brcType			:8;	//��������
								//0 none		��	
								//1 single		������	
								//2 thick		����
								//3 double		˫��
								//5 hairline	ϸ��
								//6 dot
								//7 dash large gap
								//8 dot dash
								//9 dot dot dash
								//10 triple
								//11 thin-thick small gap
								//12 thick-thin small gap
								//13 thin-thick-thin small gap
								//14 thin-thick medium gap
								//15 thick-thin medium gap
								//16 thin-thick-thin medium gap
								//17 thin-thick large gap
								//18 thick-thin large gap
								//19 thin-thick-thin large gap
								//20 wave
								//21 double wave
								//22 dash small gap
								//23 dash dot stroked
								//24 emboss 3D
								//25 engrave 3D
								//codes 64 �C 230 represent border art types and are used only for page borders
	USHORT	ico				:8;	//������ɫ(see chp.ico)
	USHORT	dptSpace		:5;	//width of space to maintain between border and text within border. 
	USHORT	fShadow			:1;	//�����Ƿ���Ӱ
	USHORT	fFrame			:1;	
	USHORT	rservered		:1;	//����������
} BRC;

//------------------------------------------------
//�ṹ��:	BRC(BoRder Code)��չ�ṹ
//��  ��:	��word2000֮�����ڱ�ʾ���ɫ
//    by: 	
//------------------------------------------------
typedef struct tagBRC_EX
{
	COLORREF	crColor			;	//��ɫ
	USHORT		dptLineWidth	:8;	//�����߿���(in 1/8 pt, max of 32 pt)
	USHORT		brcType			:8;	//��������
									//0 none		��	
									//1 single		������	
									//2 thick		����
									//3 double		˫��
									//5 hairline	ϸ��
									//6 dot
									//7 dash large gap
									//8 dot dash
									//9 dot dot dash
									//10 triple
									//11 thin-thick small gap
									//12 thick-thin small gap
									//13 thin-thick-thin small gap
									//14 thin-thick medium gap
									//15 thick-thin medium gap
									//16 thin-thick-thin medium gap
									//17 thin-thick large gap
									//18 thick-thin large gap
									//19 thin-thick-thin large gap
									//20 wave
									//21 double wave
									//22 dash small gap
									//23 dash dot stroked
									//24 emboss 3D
									//25 engrave 3D
									//codes 64 �C 230 represent border art types and are used only for page borders
	USHORT		dptSpace		:5;	//width of space to maintain between border and text within border. 
	USHORT		fShadow			:1;	//�����Ƿ���Ӱ
	USHORT		fFrame			:1;	
	USHORT		rservered		:1;	//����������
	USHORT		rservered2		:8; //δ������������
} BRC_EX;

typedef struct tagBKF
{
	short	ibkl		;
	USHORT	itcFirst	:7;
	USHORT	fPub		:1;
	USHORT	itcLim		:7;
	USHORT	fCol		:1;
} BKF;

typedef ULONG _BRC;

typedef struct tagBRCEX
{
	COLORREF crFore;			//��ɫ
	union
	{
		BRC	brc;
		_BRC brcValue;
	};
}BRCEX;

typedef struct tagSHD
{
	USHORT	icoFore		:5;			//ǰ����ɫ (see chp.ico)
	USHORT	icoBack		:5;			//������ɫ (see chp.ico)
	USHORT	ipat		:6;			//����ͼ�� (see ipat table below)
}SHD;

typedef struct tagSHDEX
{
	COLORREF crFore;			//ǰ����ɫ
	COLORREF crBack;			//������ɫ
	USHORT ipat;				//����ͼ��
}SHDEX;

//------------------------------------------------
//�ṹ��:	PICF
//������:	Data Stream�е�ͼƬ����
//------------------------------------------------
struct PICF
{
	ULONG	lcb				;	//�����ṹ���������ݵ��ܵĳ���
	USHORT	cbHeader		;	//�ṹ�ĳ��ȣ�����������rgbָ���ֽ���
	SHORT	mfp_mm			;	//���һ��WindowsͼԪ�ļ�������PICF֮��
								//mfp ��һ�� METAFILEPICT�ṹ��
								//��� PICF֮���������TIFF filename, mfp.mm == 98 
								//�����λͼ mfp.mm == 99
	SHORT	mfp_xExt		;
	SHORT	mfp_yExt		;
	SHORT	mfp_hMF			;	
	
	//�����7����Ա��
	//���PICF��������λͼ��������һ��BITMAP�ṹ
	//���PICF��������ͼԪ�ļ���������һ��8�ֽ�����6���ֽڲ��õľ�������
	//���ȫ����0�����������
	SHORT	bmType			;
	SHORT	bmWidth			;	
	SHORT	bmHeight		;	
	SHORT	bmWidthBytes	;	
	SHORT	bmPlanes		;	
	SHORT	bmBitsPixel		;	
	SHORT	bmBits			;	

	USHORT	dxaGoal			;	//ͼƬ������ߴ絥λ twip
	USHORT	dyaGoal			;	//ͼƬ�������ߴ絥λ twip
	USHORT	mx				;	//ˮƽ���� ��λ��.001% .
	USHORT	my				;	//��ֱ���� ��λ��.001% .
//�����4��Crop ֵ, ������ʾָ���ı߽类�����ƶ���������ʾָ���ı߽类�����ƶ�����λ��twip
	SHORT	dxaCropLeft		;	//������
	SHORT	dxaCropTop		;	//������
	SHORT	dxaCropRight	;	//������
	SHORT	dxaCropBottom	;	//������
//�����6����Ա�Ǳ��ϳ��ĸ�ʽ

	SHORT	brcl		:4	;	//�Ǳ��ϳ��ĸ�ʽ
	SHORT	fFrameEmpty	:1	;	//�Ǳ��ϳ��ĸ�ʽ
	SHORT	fBitmap		:1	;	//�Ǳ��ϳ��ĸ�ʽ
	SHORT	fDrawHatch	:1	;	//�Ǳ��ϳ��ĸ�ʽ
	SHORT	fError		:1	;	//�Ǳ��ϳ��ĸ�ʽ
	SHORT	bpp			:8	;	//�Ǳ��ϳ��ĸ�ʽ
//�����6���Ǳ��ϳ���
//�����4����Ա��������ͼƬ�ı߽�
	BRC		brc[4]			;	//������

	SHORT	dxaOrigin		;	//hand annotation origin��ˮƽƫ��
	SHORT	dyaOrigin		;	//hand annotation origin�Ĵ�ֱƫ��
	SHORT	cProps			;	//����
//	PBYTE	rgb				;	//ָ��ͼƬ����
};

//------------------------------------------------
//�ṹ��:	LFOLVL
//������:   one LFOLVL per level of the LST to be overridden 
//    by:   rongjianxing	
//------------------------------------------------
typedef struct tagLFOLVL
{
	long iStartAt	;
	BYTE ilvl		: 4;
	BYTE fStartAt	: 1;
	BYTE fFormatting: 1;
	BYTE reserved1	: 2;
	BYTE reserved2[3];
} LFOLVL;

//------------------------------------------------
//�ṹ��:	LFO
//������:	WORD97�е���ϵLSTF��FKP PAPX ���Զ������ṹ��List Format Override��
//------------------------------------------------
typedef struct tagLFO
{
	LONG	lsid			;	//ȫ��Ψһ��ID��
	LONG	reserved1		;	//reserved 
	LONG	reserved2		;	//reserved 
	BYTE	clfolvl			;	//count of levels whose format is overridden
								//(see LFOLVL) ()��ʱû�з�������
	BYTE	reserved3[3]	;	//reserved
 
}LFO;

typedef struct tagLSTF
{
	LONG	lsid			;	//ȫ��Ψһ��ID��
	LONG	tplc			;	//ȫ��Ψһ��ģ��ţ����ã� 
	USHORT	rgistd[9]		;	//��¼��ÿһ��Ķ���ʽ������
								//4095(0x0FFF)��ʾû������Ķ���ʽ
	BYTE	fSimpleList		:1;	//Ϊ�棬��ʾ��ֻ��һ������ı����
								//�����ʾ����һ�����ı���飨9�㣩
    BYTE	fRestartHdn		:1;	//Word 6 compatibility option: ��WORD6�������ã�
								//true if the list should start numbering over at
								//the beginning of each section 
    BYTE	reserved1		:6;	//reserved 
	BYTE	reserved2		;	//reserved 
}LSTF;


//------------------------------------------------
//�ṹ��:	LVLF
//������:	WORD97�������Զ������ÿһ������ԵĽṹ��List LeVeL��
//------------------------------------------------
typedef struct tagLVLF
{
	LONG	iStartAt		;	//ÿһ���ŵĿ�ʼֵ
	BYTE	nfc				;	//����ַ���ʽ
	BYTE	jc				:2;	//��Ŷ��뷽ʽ
	BYTE	fLegal			:1;	//true (==1) if the level turns all inherited 
								//numbers to arabic, false if it preserves 
								//their number format code (nfc)
	BYTE	fNoRestart		:1;	//true if the level's number sequence is 
								//not restarted by higher (more significant) 
								//levels in the list 
	BYTE	fPrev			:1;	//Word 6 compatibility option:
								//equivalent to anld.fPrev (see ANLD) 
	BYTE	fPrevSpace		:1;	//Word 6 compatibility option:
								//equivalent to anld.fPrevSpace (see ANLD) 
	BYTE	fWord6			:1;	//true if this level was from a converted 
								//Word 6 document. If it is true, 
								//all of the Word 6 compability options become
								//valid; otherwise they are ignored. 
	BYTE	reserved		:1;	//reserved
	BYTE	rgbxchNums[9]	;	//contains the character offsets into 
								//the LVL's XST of the inherited numbers 
								//of previous levels. This array should 
								//be zero terminated unless it is full 
								//(all 9 levels full). The XST contains place 
								//holders for any paragraph numbers contained 
								//in the text of the number, and the place holder
								//contains the ilvl of the inherited number, 
								//so lvl.xst[lvl.rgbxchNums[0]] == the level of 
								//the first inherited number in this level. 
	BYTE	ixchFollow		;	//the type of character following the number text
								//for the paragraph: 
								//0 == tab, 1 == space, 2 == nothing. 
	LONG	dxaSpace		;	//Word 6 compatibility option: 
								//equivalent to anld.dxaSpace (see ANLD) 
	LONG	dxaIndent		;	//Word 6 compatibility optino:
								//equivalent to anld.dxaIndent (see ANLD) 
	BYTE	cbGrpprlChpx	;	//length, in bytes, of the LVL's grpprlChpx 
	BYTE	cbGrpprlPapx	;	//length, in bytes, of the LVL's grpprlPapx 
	SHORT	iRestartAfterLevel;	//reserved 
}LVLF;

// -------------------------------------------------------------------------

#ifndef DOC_ITC_MAX
#define DOC_ITC_MAX				64
#endif

enum KDO_TC_HORIMERGE
{
	DO_TC_HoriFirstMerge	= 3,
	DO_TC_HoriMerged		= 2,
};

enum KDO_TC_VERTMERGE
{
	DO_TC_VertFirstMerge	= 3,
	DO_TC_VertMerged		= 1,
};

enum KDO_TC_BRC
{
	DO_TC_BrcTop,
	DO_TC_BrcLeft,
	DO_TC_BrcBottom,
	DO_TC_BrcRight,
	DO_TC_BrcHoriGrid,		// ˮƽ������
	DO_TC_BrcVertGrid,		// ��ֱ������
};

typedef struct tagTC
{
	USHORT	horiMerge : 2;		// ˮƽ�ϲ���־	(KDO_TC_HORIMERGE)
	USHORT	fVertical : 1;		// ��ֱ����
	USHORT	fBackward : 1;		// ���ڴ�ֱ����������ִ��µ��ϣ�����λ��
	USHORT	fRotateFont : 1;	// �������@font(��ӡ����), ����λ��
	USHORT	vertMerge	: 2;	// ��ֱ�ϲ���־ (KDO_TC_VERTMERGE)
	USHORT	vertAlign	: 2;	// ��ֱ����: 0 top	1 center	2 bottom
	UINT16	fUnused1	: 3;
	UINT16	fFitText	: 1;	// �Ƿ���Ӧ���֡�
	UINT16	fNoWrap		: 1;	// �Ƿ��Զ����С�
	UINT16	fUnused2	: 2;
	UINT16	wUnused;
	union
	{
		BRC	 brc[4];			// �ı߿�, �ο�: KDO_TC_BRC
		_BRC brcValue[4];
	};
}TC;
#define brcTop		brc[0]
#define brcLeft		brc[1]
#define brcBottom	brc[2]
#define brcRight	brc[3]

typedef struct _tagTC
{
	ULONG	grbit;
	ULONG	brcValue[4];
}_TC;

typedef struct tagTCEX
{
	USHORT	horiMerge	: 2;	// ˮƽ�ϲ���־
	USHORT	fVertical	: 1;	// ��ֱ����
	USHORT	fBackward	: 1;	// ���ڴ�ֱ����������ִ��µ��ϣ�����λ��
	USHORT	fRotateFont : 1;	// �������@font(��ӡ����), ����λ��
	USHORT	vertMerge	: 2;	// ��ֱ�ϲ���־
	USHORT	vertAlign	: 2;	// ��ֱ����: 0 top	1 center	2 bottom
	USHORT	fUnused		: 7;
	USHORT	wUnused;
	BRCEX	brc[4];				// �ı߿�, �ο�: KDO_TC_BRC
}TCEX;

typedef struct tagTROW
{
	UINT  jc;				// �������ֵ�ˮƽ����(sprmTJc)
	LONG  dxaGapHalf;		// (sprmTDxaGapHalf)
	LONG  dyaRowHeight;		// �и�(sprmTDyaRowHeight)
	ULONG tlp;				// (sprmTTlp)
	ULONG lwHTMLProps;		// (sprmTHTMLProps)
	BRCEX rgbrcTable[6];	// ����߿�(sprmTTableBorders), �ο�: KDO_TC_BRC
	UCHAR fCantSplit;		// (sprmTFCantSplit)
	UCHAR fTableHeader;		// (sprmTTableHeader)
	SHORT wReserved;
}TROW;

typedef struct tagTAPEX : public TROW
{
	UINT	 itc;			// �����б�Ԫ�ĸ���. ���� >= 0 ����<=64.
	union
	{
		TC	 rgtc[DOC_ITC_MAX];
		_TC	 _rgtc[DOC_ITC_MAX];
	};
	COLORREF crBrcFore[4][DOC_ITC_MAX];
	SHDEX	 rgshdex[DOC_ITC_MAX];
	SHORT	 rgdxaCenter[DOC_ITC_MAX+2];
}TAPEX;

typedef struct tagTLP	// Table Autoformat Look sPecifier (��ʽ����), 4bytes
{
	SHORT itl;				// index to Word's table of table looks (see itl table below) 
	SHORT fBorders	:1;	 	// when ==1, use the border properties from the selected table look 
	SHORT fShading	:1; 	// when ==1, use the shading properties from the selected table look 
	SHORT fFont		:1; 	// when ==1, use the font from the selected table look 
	SHORT fColor 	:1; 	// when ==1, use the color from the selected table look 
	SHORT fBestFit 	:1; 	// when ==1, do best fit from the selected table look 
	SHORT fHdrRows 	:1; 	// when ==1, apply properties from the selected table look to the header rows in the table
	SHORT fLastRow 	:1; 	// when ==1, apply properties from the selected table look to the last row in the table 
	SHORT fHdrCols 	:1; 	// when ==1, apply properties from the selected table look to the header columns of the table 
	SHORT fLastCol 	:1; 	// when ==1, apply properties from the selected table look to the last column of the table 
}TLP;

// -------------------------------------------------------------------------

/*@@delete { // ����������Ҫ�õ���һЩ�ṹ by Yang Gang
struct LSPD		// �����и�
{
	short	dyaLine;
	short	fMultLinespace;
};

struct TBD		// �����Ʊ�λ����
{
	byte jc:3;	// justification code: 0 left, 1 centered, 2 right, 3 decimal, 4 bar
	byte tlc:3;	// tab leader code: 0 no leader, 1 dotted leader, 2 hyphenated leader,
				// 3 single line leader, 4 heavy line leader
	byte rcv:2;	// reserved 
};*/
// }

//����Atn
struct ATRD
{
	BYTE	xstUser[20];
	short	ibst;
	short	ak;
	USHORT	grfbmc;
	LONG	lTagBkmk;
};

//����sprmTPC
struct HVSTRUCT
{
	USHORT Black : 4;
	USHORT iV	 : 2;
	USHORT iH	 : 2;
};

// -------------------------------------------------------------------------

typedef struct tagMOSCLIENTANCHOREX
{
	USHORT id;
	ULONG  value;
} MOSCLIENTANCHOREX;

enum  EnumAnchorExPropID {
	EAID_Unknown		=   0xBF01,
	EAID_Hr_AlignMode	=	0x038F,
	EAID_Hr_RelativeTo	=	0x0390,
	EAID_Vt_AlignMode   =	0x0391,
	EAID_Vt_RelativeTo  =   0x0392
};

#define	istdNil		4095


//style sti (buildin)
#define stiPNormal	0x0000
#define stiRNormal	0x0041
#define stiTNormal	0x0069


//sprmPPc�е�PC�ṹ
typedef struct tagPC
{
	USHORT reserved	:4;
	USHORT pcVert	:2;
	USHORT pcHorz	:2;
}PPC;


//��Ԫ��ϲ�����
enum CELLVMERGETYPE
{
	vmtNone		 = 0,
	vmtFollow	 = 1,
	vmtLead 	 = 3,
};

/*@@delete
typedef struct tagDCS
{
	INT16 t_drop		:3;
	INT16 lines			:5;
	INT16 reserved		:8;
}DCS;*/

#pragma pack(pop)


// -------------------------------------------------------------------------
#ifndef __MSO_FILEFMT_WORD_FIB_H__
#include <mso/filefmt/word/fib.h>
#endif

#ifndef __MSO_FILEFMT_WORD_CORE_DOP_H__
#include <mso/filefmt/word/core/dop.h>
#endif

#define DOP _unused

// -------------------------------------------------------------------------
// $Log: DO_WordStruct.h,v $
// Revision 1.13  2006/08/23 02:19:04  chenghui
// ������ʽ��д
//
// Revision 1.12  2005/08/03 06:56:42  wangdong
// FSPAzhogn��dxaGoal, dyaGoalӦ�����޷��ŵġ�
//
// Revision 1.10  2005/01/07 03:58:40  xushiwei
// word filefmt�����ϲ���<mso/filefmt/word.h>�С�
//

#endif // __DO_WORDSTRUCT_H__
