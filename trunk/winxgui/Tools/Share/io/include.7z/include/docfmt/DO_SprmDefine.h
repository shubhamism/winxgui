// -------------------------------------------------------------------------
//	�ļ���		��	DO_SprmDefine.h
//	������		��	WangHui(����)
//	����ʱ��	��	2001-9-18 15:40:10
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __DO_SPRMDEFINE_H__
#define __DO_SPRMDEFINE_H__

#ifndef __MSO_FILEFMT_WORD_ENUM_H__
#include <mso/filefmt/word/enum.h>
#endif

#ifndef __MSO_FILEFMT_WORD_SPRM_H__
#include <mso/filefmt/word/sprm.h>
#endif

#pragma pack(1)
// -------------------------------------------------------------------------

struct sprmPPcOprand
{
	BYTE	fBrLnAbove	: 1;
	BYTE	fBrLnBelow	: 1;
	BYTE	fUnused		: 2;
	BYTE	pcVert		: 2;
	BYTE	pcHorz		: 2;
	// if pcVert ==3, pap.pcVert should not be changed. Otherwise, contains
	// new value of pap.pcVert.	
};

enum SprmTSetBrc_GribtChg
{
	sprm_setbrc_chgtop   	= 0x01,
	sprm_setbrc_chgleft   	= 0x02,
	sprm_setbrc_chgbottom  	= 0x04,
	sprm_setbrc_chgright   	= 0x08,
	sprm_setbrc_chgdiag1  	= 0x10,	// ��Ԫб��: ����-����
	sprm_setbrc_chgdiag2	= 0x20,	// ��Ԫб��: ����-����
};

struct sprmTSetBrcOprand
{
	BYTE	itcFirst;
	BYTE	itcLim;
	BYTE	gribtChg;	// see SprmTSetBrc_GribtChg
	BRC		brc;
};

struct sprmTSetBrcExOprand
{
	BYTE	itcFirst;
	BYTE	itcLim;
	BYTE	gribtChg;	// see SprmTSetBrc_GribtChg
	BRCEX	brcex;
};

// -------------------------------------------------------------------------
#pragma pack()

#endif // __DO_SPRMDEFINE_H__
