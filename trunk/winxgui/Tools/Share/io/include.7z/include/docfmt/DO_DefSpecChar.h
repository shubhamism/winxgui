// -------------------------------------------------------------------------
//	�ļ���		��	DO_SpecChar.h
//	������		��	Hsie
//	����ʱ��	��	2003-11-04 21:21:27
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __DO_SPECCHAR_H__
#define __DO_SPECCHAR_H__

//normal characters 
#define spchParaEnd				13	//Paragraph ends
#define spchHardLineBrk			11	//Hard line breaks
#define spchBrkHyphen			45	//Breaking hyphens
#define spchNonReqHyphen		31	//Non-required hyphens
#define spchNonBrkHyphen		30	//Non-breaking hyphens
#define spchNonBrkSpc			160	//Non-breaking spaces
#define spchNormalSpc			32	//Normal spaces
#define spchSectMark			12	//Section marks, an entry in the section table
#define spchPageBrk				12	//Page breaks, otherwise
#define spchColumnBrk			14	//Column breaks
#define spchTab					9	//Tab
#define spchFldBegin			19	//field begin mark
#define spchFldSepa				20	//field separator
#define spchFldEnd				21	//field end mark
#define spchFldEsc				92	//field escape character ('\\')
#define spchFormulaMark			92	//formula mark ('\\')
#define spchCellMark			7	//cell mark (pap.fInTable == 1)
#define spchRowMark				7	//row mark (pap.fInTable == 1 && pap.fTtp == 1)

//special characters 
#define spchCurPageNum			0	//Current page number
#define spchPicture				1	//Picture
#define spchAutoFootnote		2 	//Autonumbered footnote reference
#define spchFootnoteSepa		3	//Footnote separator character
#define spchFootnoteContinue	4	//Footnote continuation character
#define spchAnnotation			5	//Annotation reference
#define spchLineNum				6	//Line number
#define spchHandAntPic			7	//Hand Annotation picture (Generated in Pen Windows)
#define spchDrawnObject			8	//Drawn object
#define spchAbbrDate			10	//Abbreviated date (e.g. "Wed, Dec 1, 1993")
#define spchTime				11	//Time in hours:minutes:seconds
#define spchCurSectNum			12	//Current section number
#define spchAbbrDayOfWeek		14	//Abbreviated day of week (e.g. "Thu" for "Thursday")
#define spchDayOfWeek			15	//Day of week (e.g. "Thursday")
#define spchDayShort			16	//Day short (e.g. "9" for the ninth day of the month)
#define spchCTNonLeadHour		22	//Hour of current time with no leading zero
#define spchCTHasLeadHour		23	//Hour of current time (two digit with leading zero when necessary)
#define spchCTNonLeadMin		24	//Minute of current time with no leading zero
#define spchCTHasLeadMin		25	//Minute of current time(two digit with leading zero when necessary)
#define spchCTSecond			26	//Seconds of current time
#define spchCTNoon				27	//AM/PM for current time
#define spchCTOldFmt			28	//Current time in hours:minutes:seconds in old format
#define spchDateM				29	//Date M (e.g. "December 2, 1993")
#define spchShortDate			30	//Short Date (e.g. "12/2/93")
#define spchShortMonth			33	//Short Month (e.g. "12" to represent "December")
#define	spchLongYear			34	//Long Year (e.g. "1993")
#define spchShortYear			35	//Short Year (e.g. "93")
#define spchAbbrMonth			36	//Abbreviated month (e.g. "Dec" to represent "December")
#define spchLongMonth			37	//Long month (e.g. "December")
#define spchCTHourMin			38	//Current time in hours:minutes (e.g. "2:01")
#define spchLongDate			39	//Long date (e.g. "Thursday, December 2, 1993")
#define spchSymbol				40	//Symbol
#define spchPrtMergeHlpFld		41	//Print Merge Helper field


#endif // __DO_SPECCHAR_H__
