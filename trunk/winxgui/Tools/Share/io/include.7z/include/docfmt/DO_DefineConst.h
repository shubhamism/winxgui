//*********************************************************************************
//	�ļ���		:	DO_DefineConst.h
//	������		:	WangHui(����)
//	��������	:	2001-8-29 17:46:13
//	�ļ�����	:	�����Ķ���
//	$Id: DO_DefineConst.h,v 1.4 2006/09/04 08:28:19 xulingjiao Exp $
//*********************************************************************************
#ifndef __DO_DEFINECONST_H__
#define __DO_DEFINECONST_H__

#define FACILITY_DOCWRITER			0x100

#define	ERROR_CODE_OUTOF_PAGESIZE			1
#define ERROR_CODE_OUTOF_FREESPACE			2
#define E_DW_OUTOF_PAGESIZE		MAKE_HRESULT(1, FACILITY_DOCWRITER, ERROR_CODE_OUTOF_PAGESIZE)
#define E_DW_OUTOF_FREESPACE	MAKE_HRESULT(1, FACILITY_DOCWRITER, ERROR_CODE_OUTOF_FREESPACE)

#define DOC_ULONG_PAGEBITS			9
#define DOC_ULONG_PAGESIZE			(1 << DOC_ULONG_PAGEBITS) //doc�ļ���һҳ�Ĵ�С

//�����������������Ͷ���
#define DOC_MAINTEXT				0x0001	//����������������������
#define DOC_FTN						0x0002	//��ע
#define DOC_HDD						0x0003	//ҳü��ҳ��
#define DOC_MCR						0x0004	//��
#define DOC_ATN						0x0005	//��ע
#define DOC_EDN						0x0006	//βע
#define DOC_TXBX					0x0007	//�ı���
#define DOC_HDRTXBX					0x0008	//header textbox ��ҳü��ҳ�ŵ����ֿ򣿣�
//�����������������Ͷ���
#define	DOC_USHORT_MagicNumber		0xA5EC	//magic number
#define	DOC_USHORT_Version			0x00BF	//FIB version 
#define	DOC_USHORT_Product			0x2039	//product version written by
#define	DOC_USHORT_Lid				0x0409	//language stamp 0x0409 ��USA
											// ��MSDN ��Language Identifiers and Locales
#define	DOC_USHORT_FibBack			0x00BF	//������fib�汾����

#define DOC_USHORT_csw				0x000E	//Count of fields in the array of "shorts"
#define DOC_SHORT_MagicCreated		0x6A62	//0x6A62 is the creator ID for Word
#define DOC_SHORT_MagicRevised		0x6A62	//0x6A62 is the creator ID for Word
#define DOC_SHORT_MagicCreatedPrivate	0xCFFD
#define DOC_SHORT_MagicRevisedPrivate	0xCFFD
#define DOC_SHORT_lidFE				0x0804	//language stamp 0x0804 ��CHS
											// ��MSDN ��Language Identifiers and Locales

#define DOC_USHORT_clw				0x0016	//Count of fields in the array of "shorts"
#define DOC_USHORT_ProductCreated	0x0000A59F//contains the build date of the creator. 
												// 10695 indicates the creator program 
												// was compiled on Jan 6, 1995
#define DOC_USHORT_ProductRevised	0x0000A59F
#define DOC_ULONG_FbpChpFirst		0x000FFFFF
#define DOC_ULONG_FbpPapFirst		0x000FFFFF
#define DOC_ULONG_FbpLvcFirst		0x000FFFFF
#define DOC_USHORT_cfclcb			0x006c	//Number of fields in the array of FC/LCB pairs
#define DOC_NO_CLX_PREFACE			0X02	//�ǿ��ٴ��̵�DOC�ļ�CLX���ݿ�Ŀ�ʼ���
#define DOC_EMPTY_PRM				0x0000
#define DOC_USHORT_Product_Kingsoft	0x8888

//----------------------------------------------------------
// ���¶������Word�ļ���ʽ���õ���һЩ����

//----------------------------------------------------------
//// ������Word8.0�ж���style��ID��
//----------------------------------------------------------
enum MsoStiList
{
	stiNormal = 0,
	stiLev1 = 1,
	stiLev2 = 2,
	stiLev3 = 3,
	stiLev4 = 4,
	stiLev5 = 5,
	stiLev6 = 6,
	stiLev7 = 7,
	stiLev8 = 8,
	stiLev9 = 9,
	stiLevFirst = stiLev1,
	stiLevLast = stiLev9,
	stiIndex1 = 10,			// 0x000A
	stiIndex2 = 11,			// 0x000B
	stiIndex3 = 12,			// 0x000C
	stiIndex4 = 13,			// 0x000D
	stiIndex5 = 14,			// 0x000E
	stiIndex6 = 15,			// 0x000F
	stiIndex7 = 16,			// 0x0010
	stiIndex8 = 17,			// 0x0011
	stiIndex9 = 18,			// 0x0012
	stiIndexFirst = stiIndex1,
	stiIndexLast = stiIndex9,
	stiToc1 = 19,			// 0x0013
	stiToc2 = 20,			// 0x0014
	stiToc3 = 21,			// 0x0015
	stiToc4 = 22,			// 0x0016
	stiToc5 = 23,			// 0x0017
	stiToc6 = 24,			// 0x0018
	stiToc7 = 25,			// 0x0019
	stiToc8 = 26,			// 0x001A
	stiToc9 = 27,			// 0x001B
	stiTocFirst = stiToc1,
	stiTocLast = stiToc9,
	stiNormIndent = 28,		// 0x001C
	stiFtnText = 29,		// 0x001D
	stiAtnText = 30,		// 0x001E
	stiHeader = 31,			// 0x001F
	stiFooter = 32,			// 0x0020
	stiIndexHeading = 33,	// 0x0021
	stiCaption = 34,		// 0x0022
	stiToCaption = 35,		// 0x0023
	stiEnvAddr = 36,		// 0x0024
	stiEnvRet = 37,			// 0x0025
	stiFtnRef = 38,			// 0x0026  char style
	stiAtnRef = 39,			// 0x0027  char style
	stiLnn = 40,			// 0x0028  char style
	stiPgn = 41,			// 0x0029  char style
	stiEdnRef = 42,			// 0x002A  char style
	stiEdnText = 43,		// 0x002B
	stiToa = 44,			// 0x002C
	stiMacro = 45,			// 0x002D
	stiToaHeading = 46,		// 0x002E
	stiList = 47,			// 0x002F
	stiListBullet = 48,		// 0x0030
	stiListNumber = 49,		// 0x0031
	stiList2 = 50,			// 0x0032
	stiList3 = 51,			// 0x0033
	stiList4 = 52,			// 0x0034
	stiList5 = 53,			// 0x0035
	stiListBullet2 = 54,	// 0x0036
	stiListBullet3 = 55,	// 0x0037
	stiListBullet4 = 56,    // 0x0038
	stiListBullet5 = 57,    // 0x0039
	stiListNumber2 = 58,    // 0x003A
	stiListNumber3 = 59,    // 0x003B
	stiListNumber4 = 60,    // 0x003C
	stiListNumber5 = 61,    // 0x003D
	stiTitle = 62,			// 0x003E
	stiClosing = 63,		// 0x003F
	stiSignature = 64,		// 0x0040
	stiNormalChar = 65,		// 0x0041  char style
	stiBodyText = 66,		// 0x0042
	stiBodyText2 = 67,		// 0x0043
	stiListCont = 68,		// 0x0044
	stiListCont2 = 69,		// 0x0045
	stiListCont3 = 70,		// 0x0046
	stiListCont4 = 71,		// 0x0047
	stiListCont5 = 72,		// 0x0048
	stiMsgHeader = 73,		// 0x0049
	stiSubtitle = 74,		// 0x004A
	stiSalutation = 75,		// 0x004B
	stiDate = 76,			// 0X004C
	stiBodyText1I = 77,		// 0x004D
	stiBodyText1I2 = 78,    // 0x004E
	stiNoteHeading = 79,    // 0x004F
	//stiBodyText2 = 80,	// 0x0050 ?
	stiBodyText3 = 81,		// 0x0051
	stiBodyTextInd2 = 82,   // 0x0052
	stiBodyTextInd3 = 83,   // 0x0053
	stiBlockQuote = 84,		// 0x0054
	stiHyperlink = 85,		// 0x0055  char style
	stiHyperlinkFollowed = 86, // 0x0056   char style
	stiStrong = 87,			// 0x0057  char style
	stiEmphasis = 88,		// 0x0058  char style
	stiNavPane = 89,		// 0x0059  char style
	stiPlainText = 90,		// 0x005A
	stiHeadingBase = 91,
	stiFootnoteBase = 92,
	stiHeaderBase = 93,
	stiIndexBase = 94,
	stiTocBase = 95,
	stiMax,
};
#define stiUser      0x0ffe  // user styles are distinguished by name
#define stiNil       0x0fff  // max for 12 bits

//----------------------------------------------------------
//// ������Word8.0�ж���LID(���Ա�ʶ)��ID��
//----------------------------------------------------------
#define LID_NoProofing					0x0400
#define LID_Arabic						0x0401
#define LID_Bulgarian					0x0402
#define LID_Catalan						0x0403
#define LID_Traditional_Chinese			0x0404
#define LID_Simplified_Chinese			0x0804
#define LID_Czech						0x0405
#define LID_Danish						0x0406
#define LID_German						0x0407
#define LID_Swiss_German				0x0807
#define LID_Greek						0x0408
#define LID_US_English				0x0409
#define LID_UK_English				0x0809
#define LID_Australian_English			0x0c09
#define LID_Castilian_Spanish			0x040a
#define LID_Mexican_Spanish				0x080a
#define LID_Finnish						0x040b
#define LID_French						0x040c
#define LID_Belgian_French				0x080c
#define LID_Canadian_French				0x0c0c
#define LID_Swiss_French				0x100c
#define LID_Hebrew						0x040d
#define LID_Hungarian					0x040e
#define LID_Icelandic					0x040f
#define LID_Italian						0x0410
#define LID_Swiss Italian				0x0810
#define LID_Japan_se					0x0411
#define LID_Korean						0x0412
#define LID_Dutch						0x0413
#define LID_Belgian_Dutch				0x0813
#define LID_Norwegian_Bokmal			0x0414
#define LID_Norwegian_Nynorsk			0x0814
#define LID_Polish						0x0415
#define LID_Brazilian_Portuguese		0x0416
#define LID_Portuguese					0x0816
#define LID_Rhaeto_Romanic				0x0417
#define LID_Romanian					0x0418
#define LID_Russian						0x0419
#define LID_Croato_Serbian				0x041a	// (Latin)	
#define LID_Serbo_Croatian				0x081a	//(Cyrillic)
#define LID_Slovak						0x041b
#define LID_Albanian					0x041c
#define LID_Swedish						0x041d
#define LID_Thai						0x041e
#define LID_Turkish						0x041f
#define LID_Urdu						0x0420
#define LID_Bahasa						0x0421
#define LID_Ukrainian					0x0422
#define LID_Byelorussian				0x0423
#define LID_Slovenian					0x0424
#define LID_Estonian					0x0425
#define LID_Latvian						0x0426
#define LID_Lithuanian					0x0427
#define LID_Farsi						0x0429
#define LID_Basque						0x042D
#define LID_Macedonian					0x042F
#define LID_Afrikaans					0x0436
#define LID_Malaysian					0x043E

#define PAGESIZE	 0x0200  //һҳ�Ĵ�С

//----------------------------------------------------------
// ���¶������ͨ�õ�һЩ����
#define MAX_LOADSTRING 100
#define MAX_PROMPT_STRING 100


#endif // __DO_DEFINECONST_H__
//----------------------------------------------------------

// $Log: DO_DefineConst.h,v $
// Revision 1.4  2006/09/04 08:28:19  xulingjiao
// �޸�28778
//
// Revision 1.3  2005/07/06 09:22:02  wangdong
// no message
//
