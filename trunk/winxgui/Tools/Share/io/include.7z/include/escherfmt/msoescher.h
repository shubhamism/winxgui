// -------------------------------------------------------------------------
//	�ļ���		��	msoescher.h
//	������		��	���� (ת����WangHui��LuGuiHua��ZQY  2001-10-18 17:11)
//	����ʱ��	��	2003-10-11 10:07:59
//	��������	��	
//	
// -------------------------------------------------------------------------
#ifndef __MSOESCHER_H__
#define __MSOESCHER_H__

#pragma pack(1)

// ------------------------------------------------------------------------
// ��������

typedef enum
{
	msosptMin								= 0,
	msosptNotPrimitive						= msosptMin,
	msosptRectangle							= 1,
	msosptRoundRectangle					= 2,
	msosptEllipse							= 3,
	msosptDiamond							= 4,
	msosptIsocelesTriangle					= 5,
	msosptRightTriangle						= 6,
	msosptParallelogram						= 7,
	msosptTrapezoid							= 8,
	msosptHexagon							= 9,
	msosptOctagon							= 10,
	msosptPlus								= 11,
	msosptStar								= 12,
	msosptArrow								= 13,
	msosptThickArrow						= 14,
	msosptHomePlate							= 15,
	msosptCube								= 16,
	msosptBalloon							= 17,
	msosptSeal								= 18,
	msosptArc								= 19,
	msosptLine								= 20,
	msosptPlaque							= 21,
	msosptCan								= 22,
	msosptDonut								= 23,
	msosptTextSimple						= 24,
	msosptTextOctagon						= 25,
	msosptTextHexagon						= 26,
	msosptTextCurve							= 27,
	msosptTextWave							= 28,
	msosptTextRing							= 29,
	msosptTextOnCurve						= 30,
	msosptTextOnRing						= 31,
	msosptStraightConnector1				= 32,
	msosptBentConnector2					= 33,
	msosptBentConnector3					= 34,
	msosptBentConnector4					= 35,
	msosptBentConnector5					= 36,
	msosptCurvedConnector2					= 37,
	msosptCurvedConnector3					= 38,
	msosptCurvedConnector4					= 39,
	msosptCurvedConnector5					= 40,
	msosptCallout1							= 41,
	msosptCallout2							= 42,
	msosptCallout3							= 43,
	msosptAccentCallout1					= 44,
	msosptAccentCallout2					= 45,
	msosptAccentCallout3					= 46,
	msosptBorderCallout1					= 47,
	msosptBorderCallout2					= 48,
	msosptBorderCallout3					= 49,
	msosptAccentBorderCallout1				= 50,
	msosptAccentBorderCallout2				= 51,
	msosptAccentBorderCallout3				= 52,
	msosptRibbon							= 53,
	msosptRibbon2							= 54,
	msosptChevron							= 55,
	msosptPentagon							= 56,
	msosptNoSmoking							= 57,
	msosptSeal8								= 58,
	msosptSeal16							= 59,
	msosptSeal32							= 60,
	msosptWedgeRectCallout					= 61,
	msosptWedgeRRectCallout					= 62,
	msosptWedgeEllipseCallout				= 63,
	msosptWave								= 64,
	msosptFoldedCorner						= 65,
	msosptLeftArrow							= 66,
	msosptDownArrow							= 67,
	msosptUpArrow							= 68,
	msosptLeftRightArrow					= 69,
	msosptUpDownArrow						= 70,
	msosptIrregularSeal1					= 71,
	msosptIrregularSeal2					= 72,
	msosptLightningBolt						= 73,
	msosptHeart								= 74,
	msosptPictureFrame						= 75,
	msosptQuadArrow							= 76,
	msosptLeftArrowCallout					= 77,
	msosptRightArrowCallout					= 78,
	msosptUpArrowCallout					= 79,
	msosptDownArrowCallout					= 80,
	msosptLeftRightArrowCallout				= 81,
	msosptUpDownArrowCallout				= 82,
	msosptQuadArrowCallout					= 83,
	msosptBevel								= 84,
	msosptLeftBracket						= 85,
	msosptRightBracket						= 86,
	msosptLeftBrace							= 87,
	msosptRightBrace						= 88,
	msosptLeftUpArrow						= 89,
	msosptBentUpArrow						= 90,
	msosptBentArrow							= 91,
	msosptSeal24							= 92,
	msosptStripedRightArrow					= 93,
	msosptNotchedRightArrow					= 94,
	msosptBlockArc							= 95,
	msosptSmileyFace						= 96,
	msosptVerticalScroll					= 97,
	msosptHorizontalScroll					= 98,
	msosptCircularArrow						= 99,
	msosptNotchedCircularArrow				= 100,
	msosptUturnArrow						= 101,
	msosptCurvedRightArrow					= 102,
	msosptCurvedLeftArrow					= 103,
	msosptCurvedUpArrow						= 104,
	msosptCurvedDownArrow					= 105,
	msosptCloudCallout						= 106,
	msosptEllipseRibbon						= 107,
	msosptEllipseRibbon2					= 108,
	msosptFlowChartProcess					= 109,
	msosptFlowChartDecision					= 110,
	msosptFlowChartInputOutput				= 111,
	msosptFlowChartPredefinedProcess		= 112,
	msosptFlowChartInternalStorage			= 113,
	msosptFlowChartDocument					= 114,
	msosptFlowChartMultidocument			= 115,
	msosptFlowChartTerminator				= 116,
	msosptFlowChartPreparation				= 117,
	msosptFlowChartManualInput				= 118,
	msosptFlowChartManualOperation			= 119,
	msosptFlowChartConnector				= 120,
	msosptFlowChartPunchedCard				= 121,
	msosptFlowChartPunchedTape				= 122,
	msosptFlowChartSummingJunction			= 123,
	msosptFlowChartOr						= 124,
	msosptFlowChartCollate					= 125,
	msosptFlowChartSort						= 126,
	msosptFlowChartExtract					= 127,
	msosptFlowChartMerge					= 128,
	msosptFlowChartOfflineStorage			= 129,
	msosptFlowChartOnlineStorage			= 130,
	msosptFlowChartMagneticTape				= 131,
	msosptFlowChartMagneticDisk				= 132,
	msosptFlowChartMagneticDrum				= 133,
	msosptFlowChartDisplay					= 134,
	msosptFlowChartDelay					= 135,
	msosptTextPlainText						= 136,
	msosptTextStop							= 137,
	msosptTextTriangle						= 138,
	msosptTextTriangleInverted				= 139,
	msosptTextChevron						= 140,
	msosptTextChevronInverted				= 141,
	msosptTextRingInside					= 142,
	msosptTextRingOutside					= 143,
	msosptTextArchUpCurve					= 144,
	msosptTextArchDownCurve					= 145,
	msosptTextCircleCurve					= 146,
	msosptTextButtonCurve					= 147,
	msosptTextArchUpPour					= 148,
	msosptTextArchDownPour					= 149,
	msosptTextCirclePour					= 150,
	msosptTextButtonPour					= 151,
	msosptTextCurveUp						= 152,
	msosptTextCurveDown						= 153,
	msosptTextCanUp							= 154,	//MS bt��97�ĵ���can��Cascadeλ���෴
	msosptTextCanDown						= 155,
	msosptTextWave1							= 156,
	msosptTextWave2							= 157,
	msosptTextWave3							= 158,
	msosptTextWave4							= 159,
	msosptTextInflate						= 160,
	msosptTextDeflate						= 161,
	msosptTextInflateBottom					= 162,
	msosptTextDeflateBottom					= 163,
	msosptTextInflateTop					= 164,
	msosptTextDeflateTop					= 165,
	msosptTextDeflateInflate				= 166,
	msosptTextDeflateInflateDeflate			= 167,
	msosptTextFadeRight						= 168,
	msosptTextFadeLeft						= 169,
	msosptTextFadeUp						= 170,
	msosptTextFadeDown						= 171,
	msosptTextSlantUp						= 172,
	msosptTextSlantDown						= 173,
	msosptTextCascadeUp						= 174,
	msosptTextCascadeDown					= 175,
	msosptFlowChartAlternateProcess			= 176,
	msosptFlowChartOffpageConnector			= 177,
	msosptCallout90							= 178,
	msosptAccentCallout90					= 179,
	msosptBorderCallout90					= 180,
	msosptAccentBorderCallout90				= 181,
	msosptLeftRightUpArrow					= 182,
	msosptSun								= 183,
	msosptMoon								= 184,
	msosptBracketPair						= 185,
	msosptBracePair							= 186,
	msosptSeal4								= 187,
	msosptDoubleWave						= 188,
	msosptActionButtonBlank					= 189,
	msosptActionButtonHome					= 190,
	msosptActionButtonHelp					= 191,
	msosptActionButtonInformation			= 192,
	msosptActionButtonForwardNext			= 193,
	msosptActionButtonBackPrevious			= 194,
	msosptActionButtonEnd					= 195,
	msosptActionButtonBeginning				= 196,
	msosptActionButtonReturn				= 197,
	msosptActionButtonDocument				= 198,
	msosptActionButtonSound					= 199,
	msosptActionButtonMovie					= 200,
	msosptHostControl						= 201,
	msosptTextBox							= 202,
	msosptGroupShape						= 203,
	msosptMax									 ,
	msosptNil								= 0x0FFF,
}MSOSPT;

//------------------------------------------------------------------------
//����ID
typedef enum
{
//	Property			PID		Type		Default		Description 
//Transform
	msopt_Rotation							= 4,  //LONG	0	fixed point: 16.16 degrees

//Protection
	msopt_fLockRotation						= 119,//BOOL	FALSE	 No rotation
	msopt_fLockAspectRatio					= 120,//BOOL	FALSE	Don't allow changes in aspect ratio
	msopt_fLockPosition						= 121,//BOOL	FALSE	Don't allow the shape to be moved
	msopt_fLockAgainstSelect				= 122,//BOOL	FALSE	Shape may not be selected
	msopt_fLockCropping						= 123,//BOOL	FALSE	No cropping this shape
	msopt_fLockVertices						= 124,//BOOL	FALSE	Edit Points not allowed
	msopt_fLockText							= 125,//BOOL	FALSE	Do not edit text
	msopt_fLockAdjustHandles				= 126,//BOOL	FALSE	Do not adjust
	msopt_fLockAgainstGrouping				= 127,//BOOL	FALSE	Do not group this shape

// Text
	msopt_lTxid								= 128,//LONG	0		id for the text, value determined by the host
	msopt_dxTextLeft						= 129,//LONG	1/10inch margins relative to shape's inscribed text rectangle (in EMUs) 
	msopt_dyTextTop							= 130,//LONG	1/20 inch	
	msopt_dxTextRight						= 131,//LONG	1/10 inch	
	msopt_dyTextBottom						= 132,//LONG	1/20 inch	
	msopt_WrapText							= 133,//MSOWRAPMODE	FALSE	Wrap text at shape margins
	msopt_scaleText							= 134,//LONG	0	Text zoom/scale (used if fFitTextToShape)
	msopt_anchorText						= 135,//MSOANCHOR	Top	How to anchor the text
	msopt_txflTextFlow						= 136,//MSOTXFL	HorzN	Text flow
	msopt_cdirFont							= 137,//MSOCDIR	msocdir0	Font rotation
	msopt_hspNext							= 138,//MSOHSP	NULL	ID of the next shape (used by Word for linked textboxes)
	msopt_txdir								= 139,//MSOTXDIR	LTR	Bi-Di Text direction
	msopt_fSelectText						= 187,//BOOL	TRUE	TRUE if single click selects text, FALSE if two clicks
	msopt_fAutoTextMargin					= 188,//BOOL	FALSE	use host's margin calculations
	msopt_fRotateText						= 189,//BOOL	FALSE	Rotate text with shape
	msopt_fFitShapeToText					= 190,//BOOL	FALSE	Size shape to fit text size
	msopt_fFitTextToShape					= 191,//BOOL	FALSE	Size text to fit shape size

//GeoText
	msopt_gtextUNICODE						= 192,//WCHAR*	NULL	UNICODE text string
	msopt_gtextRTF							= 193,//char*	NULL	RTF text string
	msopt_gtextAlign						= 194,//MSOGEOTEXTALIGN	Center	alignment on curve
	msopt_gtextSize							= 195,//LONG	36<<16	default point size
	msopt_gtextSpacing						= 196,//LONG	1<<16	fixed point 16.16
	msopt_gtextFont							= 197,//WCHAR*	NULL	font family name
	msopt_gtextFReverseRows					= 240,//BOOL	FALSE	Reverse row order
	msopt_fGtext							= 241,//BOOL	FALSE	Has text effect
	msopt_gtextFVertical					= 242,//BOOL	FALSE	Rotate characters
	msopt_gtextFKern						= 243,//BOOL	FALSE	Kern characters
	msopt_gtextFTight						= 244,//BOOL	FALSE	Tightening or tracking
	msopt_gtextFStretch						= 245,//BOOL	FALSE	Stretch to fit shape
	msopt_gtextFShrinkFit					= 246,//BOOL	FALSE	Char bounding box
	msopt_gtextFBestFit						= 247,//BOOL	FALSE	Scale text-on-path
	msopt_gtextFNormalize					= 248,//BOOL	FALSE	Stretch char height
	msopt_gtextFDxMeasure					= 249,//BOOL	FALSE	Do not measure along path
	msopt_gtextFBold						= 250,//BOOL	FALSE	Bold font
	msopt_gtextFItalic						= 251,//BOOL	FALSE	Italic font
	msopt_gtextFUnderline					= 252,//BOOL	FALSE	Underline font
	msopt_gtextFShadow						= 253,//BOOL	FALSE	Shadow font
	msopt_gtextFSmallcaps					= 254,//BOOL	FALSE	Small caps font
	msopt_gtextFStrikethrough				= 255,//BOOL	FALSE	Strike through font
	msopt_fPseudoInline						= 1343,

//Blip
	msopt_cropFromTop						= 256,//LONG	0	16.16 fraction times total image width or height, as appropriate.
	msopt_cropFromBottom					= 257,//LONG	0	
	msopt_cropFromLeft						= 258,//LONG	0	
	msopt_cropFromRight						= 259,//LONG	0	
	msopt_pib								= 260,//IMsoBlip*	NULL	Blip to display
	msopt_pibName							= 261,//WCHAR*	NULL	Blip file name
	msopt_pibFlags							= 262,//MSOBLIPFLAGS	Comment	Blip flags
	msopt_pictureTransparent				= 263,//LONG	~0	transparent color (none if ~0UL) 
	msopt_pictureContrast					= 264,//LONG	1<<16	contrast setting
	msopt_pictureBrightness					= 265,//LONG	0	brightness setting
	msopt_pictureGamma						= 266,//LONG	0	16.16 gamma
	msopt_pictureId							= 267,//LONG	0	Host-defined ID for OLE objects (usually a pointer)
	msopt_pictureDblCrMod					= 268,//MSOCLR	This	Modification used if shape has double shadow
	msopt_pictureFillCrMod					= 269,//MSOCLR	undefined	
	msopt_pictureLineCrMod					= 270,//MSOCLR	undefined	
	msopt_pibPrint							= 271,//IMsoBlip*	NULL	Blip to display when printing
	msopt_pibPrintName						= 272,//WCHAR*	NULL	Blip file name
	msopt_pibPrintFlags						= 273,//MSOBLIPFLAGS	Comment	Blip flags
	msopt_fNoHitTestPicture					= 316,//BOOL	FALSE	Do not hit test the picture
	msopt_pictureGray						= 317,//BOOL	FALSE	grayscale display
	msopt_pictureBiLevel					= 318,//BOOL	FALSE	bi-level display
	msopt_pictureActive						= 319,//BOOL	FALSE	Server is active (OLE objects only)

//Geometry
	msopt_geoLeft							= 320,//LONG 0 Defines the G (geometry) coordinate space. 
	msopt_geoTop							= 321,//LONG 0   
	msopt_geoRight							= 322,//LONG 21600   
	msopt_geoBottom							= 323,//LONG 21600   
	msopt_shapePath							= 324,//MSOSHAPEPATH msoshapeLinesClosed   
	msopt_pVertices							= 325,//IMsoArray NULL An array of points, in G units. 
	msopt_pSegmentInfo						= 326,//IMsoArray NULL   
	msopt_adjustValue						= 327,//LONG 0 Adjustment values corresponding to the positions of the adjust handles of the shape. The number of values used and their allowable ranges vary from shape type to shape type. 
	msopt_adjust2Value						= 328,//LONG 0   
	msopt_adjust3Value						= 329,//LONG 0   
	msopt_adjust4Value						= 330,//LONG 0   
	msopt_adjust5Value						= 331,//LONG 0   
	msopt_adjust6Value						= 332,//LONG 0   
	msopt_adjust7Value						= 333,//LONG 0   
	msopt_adjust8Value						= 334,//LONG 0   
	msopt_adjust9Value						= 335,//LONG 0   
	msopt_adjust10Value						= 336,//LONG 0 
	msopt_connectlocs						= 337,//IMsoArray NULL An array of points 
	msopt_connectangles						= 338,//IMsoArray
	msopt_handles							= 341, // struct
	msopt_forumulas							= 342, // IMsoArray
	//0x155	341
	/*
	<v:handles>
		<v:h position="#0,topLeft" xrange="0,21600" yrange="@0,2147483647"/>
		<v:h position="bottomRight,#1" xrange="@0,2147483647" yrange="0,21600"/>
	</v:handles>
	*/
	//0x156 342
	/*
	<v:formulas>
		<v:f eqn="val 0"/>
		<v:f eqn="prod #0 1 2"/>
		<v:f eqn="prod @1 #1 21600"/>
		<v:f eqn="sum #0 0 @2"/>
		<v:f eqn="val #0"/>
		<v:f eqn="sum @1 10800 0"/>
		<v:f eqn="prod #1 1 2"/>
		<v:f eqn="val #1"/>
		<v:f eqn="sum @2 @6 @1"/>
		<v:f eqn="sum @8 10800 0"/>
		<v:f eqn="sum @6 10800 0"/>
	</v:formulas>
	 */
	msopt_textboxrect						= 343,//IMsoArray
	msopt_fShadowOK							= 378,//BOOL TRUE Shadow may be set 
	msopt_f3DOK								= 379,//BOOL TRUE 3D may be set 
	msopt_fLineOK							= 380,//BOOL TRUE Line style may be set 
	msopt_fGtextOK							= 381,//BOOL FALSE Text effect (WordArt) supported 
	msopt_fFillShadeShapeOK					= 382,//BOOL FALSE   
	msopt_fFillOK							= 383,//BOOL TRUE OK to fill the shape through the UI or VBA? 

//Fill Style
	msopt_fillType							= 384,//MSOFILLTYPE	Solid	Type of fill
	msopt_fillColor							= 385,//MSOCLR	white	Foreground color
	msopt_fillOpacity						= 386,//LONG	1<<16	Fixed 16.16
	msopt_fillBackColor						= 387,//MSOCLR	white	Background color
	msopt_fillBackOpacity					= 388,//LONG	1<<16	Shades only
	msopt_fillCrMod							= 389,//MSOCLR	undefined	Modification for BW views
	msopt_fillBlip							= 390,//IMsoBlip*	NULL	Pattern/texture
	msopt_fillBlipName						= 391,//WCHAR*	NULL	Blip file name
	msopt_fillBlipFlags						= 392,//MSOBLIPFLAGS	Comment	Blip flags
	msopt_fillWidth							= 393,//LONG	0	How big (A units) to make a metafile texture.
	msopt_fillHeight						= 394,//LONG	0	
	msopt_fillAngle							= 395,//LONG	0	Fade angle - degrees in 16.16
	msopt_fillFocus							= 396,//LONG	0	Linear shaded fill focus percent
	msopt_fillToLeft						= 397,//LONG	0	Fraction 16.16
	msopt_fillToTop							= 398,//LONG	0	Fraction 16.16
	msopt_fillToRight						= 399,//LONG	0	Fraction 16.16
	msopt_fillToBottom						= 400,//LONG	0	Fraction 16.16
	msopt_fillRectLeft						= 401,//LONG	0	For shaded fills, use the specified rectangle instead of the shape's bounding rect to define how large the fade is going to be.
	msopt_fillRectTop						= 402,//LONG	0	
	msopt_fillRectRight						= 403,//LONG	0	
	msopt_fillRectBottom					= 404,//LONG	0	
	msopt_fillDztype						= 405,//MSODZTYPE	Default	
	msopt_fillShadePreset					= 406,//LONG	0	Special shades
	msopt_fillShadeColors					= 407,//IMsoArray	NULL	a preset array of colors
	msopt_fillOriginX						= 408,//LONG	0	
	msopt_fillOriginY						= 409,//LONG	0	
	msopt_fillShapeOriginX					= 410,//LONG	0	
	msopt_fillShapeOriginY					= 411,//LONG	0	
	msopt_fillShadeType						= 412,//MSOSHADETYPE	Default	Type of shading, if a shaded (gradient) fill.
	msopt_fFillRotateWithShape				= 442,//BOOL	TRUE	
	msopt_fFilled							= 443,//BOOL	TRUE	Is shape filled?
	msopt_fHitTestFill						= 444,//BOOL	TRUE	Should we hit test fill? 
	msopt_fillShape							= 445,//BOOL	TRUE	Register pattern on shape
	msopt_fillUseRect						= 446,//BOOL	FALSE	Use the large rect?
	msopt_fNoFillHitTest					= 447,//BOOL	FALSE	Hit test a shape as though filled

//Line Style
	msopt_lineColor							= 448,//MSOCLR	black	Color of line
	msopt_lineOpacity						= 449,//LONG	1<<16	Not implemented
	msopt_lineBackColor						= 450,//MSOCLR	white	Background color
	msopt_lineCrMod							= 451,//MSOCLR	undefined	Modification for BW views
	msopt_lineType							= 452,//MSOLINETYPE	Solid	Type of line
	msopt_lineFillBlip						= 453,//IMsoBlip*	NULL	Pattern/texture
	msopt_lineFillBlipName					= 454,//WCHAR*	NULL	Blip file name
	msopt_lineFillBlipFlags					= 455,//MSOBLIPFLAGS	Comment	Blip flags
	msopt_lineFillWidth						= 456,//LONG	0	How big (A units) to make a metafile texture.
	msopt_lineFillHeight					= 457,//LONG	0	
	msopt_lineFillDztype					= 458,//MSODZTYPE	Default	How to interpret fillWidth/Height numbers.
	msopt_lineWidth							= 459,//LONG	9525	A units; 1pt				=				= 12700 EMUs
	msopt_lineMiterLimit					= 460,//LONG	8<<16	ratio (16.16) of width
	msopt_lineStyle							= 461,//MSOLINESTYLE	Simple	Draw parallel lines?
	msopt_lineDashing						= 462,//MSOLINEDASHING	Solid	Can be overridden by:
	msopt_lineDashStyle						= 463,//IMsoArray	NULL	As Win32 ExtCreatePen
	msopt_lineStartArrowhead				= 464,//MSOLINEEND	NoEnd	Arrow at start
	msopt_lineEndArrowhead					= 465,//MSOLINEEND	NoEnd	Arrow at end
	msopt_lineStartArrowWidth				= 466,//MSOLINEENDWIDTH	MediumWidthArrow	Arrow at start
	msopt_lineStartArrowLength				= 467,//MSOLINEENDLENGTH	MediumLenArrow	Arrow at end
	msopt_lineEndArrowWidth					= 468,//MSOLINEENDWIDTH	MediumWidthArrow	Arrow at start
	msopt_lineEndArrowLength				= 469,//MSOLINEENDLENGTH	MediumLenArrow	Arrow at end
	msopt_lineJoinStyle						= 470,//MSOLINEJOIN	JoinRound	How to join lines
	msopt_lineEndCapStyle					= 471,//MSOLINECAP	EndCapFlat	How to end lines
	msopt_fArrowheadsOK						= 507,//BOOL	FALSE	Allow arrowheads if prop. is set
	msopt_fLine								= 508,//BOOL	TRUE	Any line?
	msopt_fHitTestLine						= 509,//BOOL	TRUE	Should we hit test lines? 
	msopt_lineFillShape						= 510,//BOOL	TRUE	Register pattern on shape
	msopt_fNoLineDrawDash					= 511,//BOOL	FALSE	

//Shadow Style
	msopt_shadowType						= 512,//MSOSHADOWTYPE	Offset	Type of effect
	msopt_shadowColor						= 513,//MSOCLR	0x808080	Foreground color
	msopt_shadowHighlight					= 514,//MSOCLR	0xCBCBCB	Embossed color
	msopt_shadowCrMod						= 515,//MSOCLR	undefined	Modification for BW views
	msopt_shadowOpacity						= 516,//LONG	1<<16	Fixed 16.16
	msopt_shadowOffsetX						= 517,//LONG	25400	Offset shadow
	msopt_shadowOffsetY						= 518,//LONG	25400	Offset shadow
	msopt_shadowSecondOffsetX				= 519,//LONG	0	Double offset shadow
	msopt_shadowSecondOffsetY				= 520,//LONG	0	Double offset shadow
	msopt_shadowScaleXToX					= 521,//LONG	1<<16	16.16
	msopt_shadowScaleYToX					= 522,//LONG	0	16.16
	msopt_shadowScaleXToY					= 523,//LONG	0	16.16
	msopt_shadowScaleYToY					= 524,//LONG	1<<16	16.16
	msopt_shadowPerspectiveX				= 525,//LONG	0	16.16 / weight
	msopt_shadowPerspectiveY				= 526,//LONG	0	16.16 / weight
	msopt_shadowWeight						= 527,//LONG	1<<8	scaling factor
	msopt_shadowOriginX						= 528,//LONG	0	
	msopt_shadowOriginY						= 529,//LONG	0	
	msopt_fShadow							= 574,//BOOL	FALSE	Any shadow?
	msopt_fshadowObscured					= 575,//BOOL	FALSE	Excel5-style shadow
	
//Perspective Style
	msopt_perspectiveType					= 576,//MSOXFORMTYPE	Shape	Where transform applies
	msopt_perspectiveOffsetX				= 577,//LONG	0	The LONG values define a transformation matrix, effectively, each value is scaled by the perspectiveWeight parameter.
	msopt_perspectiveOffsetY				= 578,//LONG	0	
	msopt_perspectiveScaleXToX				= 579,//LONG	1<<16	
	msopt_perspectiveScaleYToX				= 580,//LONG	0	
	msopt_perspectiveScaleXToY				= 581,//LONG	0	
	msopt_perspectiveScaleYToY				= 582,//LONG	1<<16	
	msopt_perspectivePerspectiveX			= 583,//LONG	0	
	msopt_perspectivePerspectiveY			= 584,//LONG	0	
	msopt_perspectiveWeight					= 585,//LONG	1<<8	Scaling factor
	msopt_perspectiveOriginX				= 586,//LONG	1<<15	
	msopt_perspectiveOriginY				= 587,//LONG	1<<15	
	msopt_fPerspective						= 639,//BOOL	FALSE	On/off

//3D Object
	msopt_c3DSpecularAmt					= 640,//LONG	0	Fixed-point 16.16
	msopt_c3DDiffuseAmt						= 641,//LONG	65536	Fixed-point 16.16
	msopt_c3DShininess						= 642,//LONG	5	Default gives OK results
	msopt_c3DEdgeThickness					= 643,//LONG	12700	Specular edge thickness
	msopt_c3DExtrudeForward					= 644,//LONG	0	Distance of extrusion in EMUs
	msopt_c3DExtrudeBackward				= 645,//LONG	457200	
	msopt_c3DExtrudePlane					= 646,//LONG	0	Extrusion direction
	msopt_c3DExtrusionColor					= 647,//MSOCLR	FillThenLine	Basic color of extruded part of shape; the lighting model used will determine the exact shades used when rendering. 
	msopt_c3DCrMod							= 648,//MSOCLR	undefined	Modification for BW views
	msopt_f3D								= 700,//BOOL	FALSE	Does this shape have a 3D effect?
	msopt_fc3DMetallic						= 701,//BOOL	0	Use metallic specularity?
	msopt_fc3DUseExtrusionColor				= 702,//BOOL	FALSE	
	msopt_fc3DLightFace						= 703,//BOOL	TRUE	

//3D Style
	msopt_c3DYRotationAngle					= 704,//LONG	0	degrees (16.16) about y axis
	msopt_c3DXRotationAngle					= 705,//LONG	0	degrees (16.16) about x axis
	msopt_c3DRotationAxisX					= 706,//LONG	100	These specify the rotation axis; only their relative magnitudes matter.
	msopt_c3DRotationAxisY					= 707,//LONG	0	
	msopt_c3DRotationAxisZ					= 708,//LONG	0	
	msopt_c3DRotationAngle					= 709,//LONG	0	degrees (16.16) about axis
	msopt_c3DRotationCenterX				= 710,//LONG	0	rotation center x (16.16 or g-units)
	msopt_c3DRotationCenterY				= 711,//LONG	0	rotation center y (16.16 or g-units)
	msopt_c3DRotationCenterZ				= 712,//LONG	0	rotation center z (absolute (emus))
	msopt_c3DRenderMode						= 713,//MSO3DRENDERMODE	FullRender	Full,wireframe, or bcube
	msopt_c3DTolerance						= 714,//LONG	30000	pixels (16.16)
	msopt_c3DXViewpoint						= 715,//LONG	1250000	X view point (emus)
	msopt_c3DYViewpoint						= 716,//LONG	-1250000	Y view point (emus)
	msopt_c3DZViewpoint						= 717,//LONG	9000000	Z view distance (emus)
	msopt_c3DOriginX						= 718,//LONG	32768	
	msopt_c3DOriginY						= 719,//LONG	-32768	
	msopt_c3DSkewAngle						= 720,//LONG	-8847360	degree (16.16) skew angle
	msopt_c3DSkewAmount						= 721,//LONG	50	Percentage skew amount
	msopt_c3DAmbientIntensity				= 722,//LONG	20000	Fixed point intensity
	msopt_c3DKeyX							= 723,//LONG	50000	Key light source direc-
	msopt_c3DKeyY							= 724,//LONG	0	tion; only their relative
	msopt_c3DKeyZ							= 725,//LONG	10000	magnitudes matter
	msopt_c3DKeyIntensity					= 726,//LONG	38000	Fixed point intensity
	msopt_c3DFillX							= 727,//LONG	-50000	Fill light source direc-
	msopt_c3DFillY							= 728,//LONG	0	tion; only their relative
	msopt_c3DFillZ							= 729,//LONG	10000	magnitudes matter
	msopt_c3DFillIntensity					= 730,//LONG	38000	Fixed point intensity
	msopt_fc3DConstrainRotation				= 763,//BOOL	TRUE	
	msopt_fc3DRotationCenterAuto			= 764,//BOOL	FALSE	
	msopt_fc3DParallel						= 765,//BOOL	1	Parallel projection?
	msopt_fc3DKeyHarsh						= 766,//BOOL	1	Is key lighting harsh?
	msopt_fc3DFillHarsh						= 767,//BOOL	0	Is fill lighting harsh?

//Shape
	msopt_hspMaster							= 769,//MSOHSP	NULL	master shape
	msopt_cxstyle							= 771,//MSOCXSTYLE	None	Type of connector
	msopt_bWMode							= 772,//MSOBWMODE	Automatic	Settings for modifications to be made when in different forms of black-and-white mode.
	msopt_bWModePureBW						= 773,//MSOBWMODE	Automatic	
	msopt_bWModeBW							= 774,//MSOBWMODE	Automatic	
	msopt_fOleIcon							= 826,//BOOL	FALSE	For OLE objects, whether the object is in icon form
	msopt_fPreferRelativeResize				= 827,//BOOL	FALSE	For UI only. Prefer relative resizing. 
	msopt_fLockShapeType					= 828,//BOOL	FALSE	Lock the shape type (don't allow Change Shape)
	msopt_fDeleteAttachedObject				= 830,//BOOL	FALSE	
	msopt_fBackground						= 831,//BOOL	FALSE	If TRUE, this is the background shape.

//Callout
	msopt_spcot								= 832,//MSOSPCOT	TwoSegment	Callout type
	msopt_dxyCalloutGap						= 833,//LONG	1/12 inch	Distance from box to first point.(EMUs)
	msopt_spcoa								= 834,//MSOSPCOA	Any	Callout angle
	msopt_spcod								= 835,//MSOSPCOD	Specified	Callout drop type
	msopt_dxyCalloutDropSpecified			= 836,//LONG	9 points	if msospcodSpecified, the actual drop distance
	msopt_dxyCalloutLengthSpecified			= 837,//LONG	0	if fCalloutLengthSpecified, the actual distance
	msopt_fCallout							= 889,//BOOL	FALSE	Is the shape a callout?
	msopt_fCalloutAccentBar					= 890,//BOOL	FALSE	does callout have accent bar
	msopt_fCalloutTextBorder				= 891,//BOOL	TRUE	does callout have a text border
	msopt_fCalloutMinusX					= 892,//BOOL	FALSE	
	msopt_fCalloutMinusY					= 893,//BOOL	FALSE	
	msopt_fCalloutDropAuto					= 894,//BOOL	FALSE	If true, then we occasionally invert the drop distance
	msopt_fCalloutLengthSpecified			= 895,//BOOL	FALSE	if true, we look at dxyCalloutLengthSpecified

//Group Shape
	msopt_wzName							= 896,//WCHAR*	NULL	Shape Name (present only if explicitly set)
	msopt_wzDescription						= 897,//WCHAR*	NULL	alternate text
	msopt_pihlShape							= 898,//IHlink*	NULL	The hyperlink in the shape.
	msopt_pWrapPolygonVertices				= 899,//IMsoArray	NULL	The polygon that text will be wrapped around (Word)
	msopt_dxWrapDistLeft					= 900,//LONG	1/8 inch	Left wrapping distance from text (Word)
	msopt_dyWrapDistTop						= 901,//LONG	0	Top wrapping distance from text (Word)
	msopt_dxWrapDistRight					= 902,//LONG	1/8 inch	Right wrapping distance from text (Word)
	msopt_dyWrapDistBottom					= 903,//LONG	0	Bottom wrapping distance from text (Word)
	msopt_lidRegroup						= 904,//LONG	0	Regroup ID 
	msopt_fUserDraw							= 0x3b5, // BOOL FALSE, user draw
	msopt_fEditedWrap						= 953,//BOOL	FALSE	Has the wrap polygon been edited?
	msopt_fBehindDocument					= 954,//BOOL	FALSE	Word-only (shape is behind text)
	msopt_fOnDblClickNotify					= 955,//BOOL	FALSE	Notify client on a double click
	msopt_fIsButton							= 956,//BOOL	FALSE	A button shape (i.e., clicking performs an action). Set for shapes with attached hyperlinks or macros.
	msopt_fOneD								= 957,//BOOL	FALSE	1D adjustment
	msopt_fHidden							= 958,//BOOL	FALSE	Do not display
	msopt_fPrint							= 959,//BOOL	TRUE	Print this shape
	
// Userdefined Properties(In PPT) -- add by liupeng
	msopt_borderTopColor					= 925,// LONG	
// Userdefined Properties(In PPT) -- add by liubin
	msopt_objTableSignature					= 927, //0x39F	1 means the shape is a obj table
	msopt_objTableInfo						= 928, //0x3A0	complex data, see PPT_TableInfo in Coding\include\mso\filefmt\powerpoint\ppt.h

// Userdefined Properties(In PPT) -- add by liupeng
	msopt_inkData							= 0x700,	// IMsoArray
	msopt_fInkFlags1						= 0x73f,
	msopt_fInkFlags2						= 0x73c,

	//��mso/filefmt/escher/ShapeProperties.h�����ƹ���
	msopt_ksextBase							= 0x2000, // 8192 ����������չ����
	msopt_fillPattern						= msopt_ksextBase + 5,	//enum MSOHATCHSTYLE,   �ڶ��̺���ʶ�����ͼ��
	msopt_fillTexture						= msopt_ksextBase + 6,	//enum MSOTEXTURESTYLE, �ڶ��̺���ʶ���������
	msopt_linePattern						= msopt_ksextBase + 7,	//enum MSOHATCHSTYLE,   �ڶ��̺���ʶ�����ͼ��

	msopt_objTableLineStyle					= msopt_ksextBase + 100,// wpp�������չ�ı߿�����
	msopt_objTableWpp						= msopt_ksextBase + 101,


}MSOBJPROPTYPE;
//------------------------------------------------------------------------
//
// MSOSHAPEPATH
typedef enum
{
	msoshapeLines,        // A line of straight segments
	msoshapeLinesClosed,  // A closed polygonal object
	msoshapeCurves,       // A line of Bezier curve segments
	msoshapeCurvesClosed, // A closed shape with curved edges
	msoshapeComplex,      // pSegmentInfo must be non-empty
} MSOSHAPEPATH;

// MSOWRAPMODE
typedef enum
{
	msowrapSquare,
	msowrapByPoints,
	msowrapNone,
	msowrapTopBottom,
	msowrapThrough,
} MSOWRAPMODE;

// MSOBWMODE
typedef enum
{
	msobwColor,          // only used for predefined shades
	msobwAutomatic,      // depends on object type
	msobwGrayScale,      // shades of gray only
	msobwLightGrayScale, // shades of light gray only
	msobwInverseGray,    // dark gray mapped to light gray, etc.
	msobwGrayOutline,    // pure gray and white
	msobwBlackTextLine,  // black text and lines, all else grayscale
	msobwHighContrast,   // pure black and white mode (no grays)
	msobwBlack,          // solid black
	msobwWhite,          // solid white
	msobwDontShow,       // object not drawn
	msobwNumModes        // number of Black and white modes
} MSOBWMODE;

// MSOANCHOR
typedef enum
{
	msoanchorTop, 
	msoanchorMiddle, 
	msoanchorBottom, 
	msoanchorTopCentered, 
	msoanchorMiddleCentered, 
	msoanchorBottomCentered,
	msoanchorTopBaseline,
	msoanchorBottomBaseline,
	msoanchorTopCenteredBaseline,
	msoanchorBottomCenteredBaseline
} MSOANCHOR;

// MSOCDIR
typedef enum
{
	msocdir0,       // Right
	msocdir90,      // Down
	msocdir180,     // Left
	msocdir270      // Up
} MSOCDIR;

// MSOCXSTYLE �C connector style
typedef enum
{
	msocxstyleStraight = 0,
	msocxstyleBent,
	msocxstyleCurved,
	msocxstyleNone
} MSOCXSTYLE;

// MSOTXFL -- text flow
typedef enum 
{
	msotxflHorzN,           // Horizontal non-@
	msotxflTtoBA,           // Top to Bottom @-font
	msotxflBtoT,            // Bottom to Top non-@
	msotxflTtoBN,           // Top to Bottom non-@
	msotxflHorzA,           // Horizontal @-font
	msotxflVertN,           // Vertical, non-@
} MSOTXFL;

// MSOTXDIR - text direction (needed for Bi-Di support)
typedef enum
{
	msotxdirLTR,           // left-to-right text direction
	msotxdirRTL,           // right-to-left text direction
	msotxdirContext,      // context text direction
} MSOTXDIR;

// MSOSPCOT -- Callout Type 
typedef enum
{
	msospcotRightAngle = 1,
	msospcotOneSegment = 2,
	msospcotTwoSegment = 3,
	msospcotThreeSegment = 4,
} MSOSPCOT;

// MSOSPCOA -- Callout Angle
typedef enum
{
	msospcoaAny,
	msospcoa30,
	msospcoa45,
	msospcoa60,
	msospcoa90,
	msospcoa0,
} MSOSPCOA;

// MSOSPCOD -- Callout Drop
typedef enum
{
	msospcodTop,
	msospcodCenter,
	msospcodBottom,
	msospcodSpecified,
} MSOSPCOD;

// MSOGEOTEXTALIGN �C WordArt alignment
typedef enum
{
	msoalignTextStretch,      /* Stretch each line of text to fit width. */
	msoalignTextCenter,       /* Center text on width. */
	msoalignTextLeft,         /* Left justify. */
	msoalignTextRight,        /* Right justify. */
	msoalignTextLetterJust,   /* Spread letters out to fit width. */
	msoalignTextWordJust,     /* Spread words out to fit width. */
	msoalignTextInvalid       /* Invalid */
} MSOGEOTEXTALIGN;

// MSOBLIPFLAGS �C flags for pictures
typedef enum
{
	msoblipflagDefault = 0,
	msoblipflagComment = 0,   // Blip name is a comment
	msoblipflagFile,          // Blip name is a file name
	msoblipflagURL,           // Blip name is a full URL
	msoblipflagType = 3,      // Mask to extract type
	/* Or the following flags with any of the above. */
	msoblipflagDontSave = 4,  // A "dont" is the depression in the metal
							 // body work of an automobile caused when a
							 // cyclist violently thrusts his or her nose
							 // at it, thus a DontSave is another name for
							 // a cycle lane.
	msoblipflagDoNotSave = 4, // For those who prefer English
	msoblipflagLinkToFile = 8,
} MSOBLIPFLAGS;

// MSO3DRENDERMODE
typedef enum
{
	msoFullRender,      // Generate a full rendering
	msoWireframe,       // Generate a wireframe
	msoBoundingCube,    // Generate a bounding cube
} MSO3DRENDERMODE;

// MSOXFORMTYPE
typedef enum
{
	msoxformAbsolute,   // Apply transform in absolute space centered on shape
	msoxformShape,      // Apply transform to shape geometry
	msoxformDrawing     // Apply transform in drawing space
} MSOXFORMTYPE;

// MSOSHADOWTYPE
typedef enum
{
	msoshadowOffset,    // N pixel offset shadow
	msoshadowDouble,    // Use second offset too
	msoshadowRich,      // Rich perspective shadow (cast relative to shape)
	msoshadowShape,     // Rich perspective shadow (cast in shape space)
	msoshadowDrawing,   // Perspective shadow cast in drawing space
	msoshadowEmbossOrEngrave,
} MSOSHADOWTYPE;

// MSODZTYPE - the type of a (length) measurement
typedef enum
{
	msodztypeMin          = 0,
	msodztypeDefault      = 0,  // Default size, ignore the values
	msodztypeA            = 1,  // Values are in EMUs
	msodztypeV            = 2,  // Values are in pixels
	msodztypeShape        = 3,  // Values are 16.16 fractions of shape size
	msodztypeFixedAspect  = 4,  // Aspect ratio is fixed
	msodztypeAFixed       = 5,  // EMUs, fixed aspect ratio
	msodztypeVFixed       = 6,  // Pixels, fixed aspect ratio
	msodztypeShapeFixed   = 7,  // Proportion of shape, fixed aspect ratio
	msodztypeFixedAspectEnlarge
						 = 8,  // Aspect ratio is fixed, favor larger size
	msodztypeAFixedBig    = 9,  // EMUs, fixed aspect ratio
	msodztypeVFixedBig    = 10, // Pixels, fixed aspect ratio
	msodztypeShapeFixedBig= 11, // Proportion of shape, fixed aspect ratio
	msodztypeMax         = 11
} MSODZTYPE;

// MSOFILLTYPE
typedef enum
{
	msofillNone = -1,
	msofillSolid = 0,         // Fill with a solid color
	msofillPattern,           // Fill with a pattern (bitmap)
	msofillTexture,           // A texture (pattern with its own color map)
	msofillPicture,           // Center a picture in the shape
	msofillShade,             // Shade from start to end points
	msofillShadeCenter,       // Shade from bounding rectangle to end point
	msofillShadeShape,        // Shade from shape outline to end point
	msofillShadeScale,        // Similar to msofillShade, but the fillAngle
							 // is additionally scaled by the aspect ratio of
							 // the shape. If shape is square, it is the
							 // same as msofillShade.
	msofillShadeTitle,        // special type - shade to title ---  for PP 
	msofillBackground         // Use the background fill color/pattern
} MSOFILLTYPE;

// MSOSHADETYPE �C how to interpret the colors in a shaded fill.
typedef enum
{
	msoshadeNone  = 0,        // Interpolate without correction between RGBs
	msoshadeGamma = 1,        // Apply gamma correction to colors
	msoshadeSigma = 2,        // Apply a sigma transfer function to position
	msoshadeBand  = 4,        // Add a flat band at the start of the shade
	msoshadeOneColor = 8,     // This is a one color shade

/* A parameter for the band or sigma function can be stored in the top
  16 bits of the value - this is a proportion of *each* band of the
  shade to make flat (or the approximate equal value for a sigma
  function).  NOTE: the parameter is not used for the sigma function,
  instead a built in value is used.  This value should not be changed
  from the default! */
	msoshadeParameterShift = 16,
	msoshadeParameterMask  = 0xffff0000,

	msoshadeDefault = (msoshadeGamma | msoshadeSigma | (16384<<msoshadeParameterShift))
} MSOSHADETYPE;

//   MSOLINESTYLE - compound line style
typedef enum
{
	msolineSimple,            // Single line (of width lineWidth)
	msolineDouble,            // Double lines of equal width
	msolineThickThin,         // Double lines, one thick, one thin
	msolineThinThick,         // Double lines, reverse order
	msolineTriple             // Three lines, thin, thick, thin
} MSOLINESTYLE;

// MSOLINETYPE - how to "fill" the line contour
typedef enum
{
	msolineSolidType,         // Fill with a solid color
	msolinePattern,           // Fill with a pattern (bitmap)
	msolineTexture,           // A texture (pattern with its own color map)
	msolinePicture            // Center a picture in the shape
} MSOLINETYPE;

// MSOLINEDASHING - dashed line style
typedef enum
{
	msolineSolid,              // Solid (continuous) pen
	msolineDashSys,            // PS_DASH system   dash style
	msolineDotSys,             // PS_DOT system   dash style
	msolineDashDotSys,         // PS_DASHDOT system dash style
	msolineDashDotDotSys,      // PS_DASHDOTDOT system dash style
	msolineDotGEL,             // square dot style
	msolineDashGEL,            // dash style
	msolineLongDashGEL,        // long dash style
	msolineDashDotGEL,         // dash short dash
	msolineLongDashDotGEL,     // long dash short dash
	msolineLongDashDotDotGEL   // long dash short dash short dash
} MSOLINEDASHING;

// MSOLINEEND - line end effect
typedef enum
{
	msolineNoEnd,
	msolineArrowEnd,
	msolineArrowStealthEnd,
	msolineArrowDiamondEnd,
	msolineArrowOvalEnd,
	msolineArrowOpenEnd,
} MSOLINEEND;

// MSOLINEENDWIDTH - size of arrowhead
typedef enum
{
	msolineNarrowArrow,
	msolineMediumWidthArrow,
	msolineWideArrow
} MSOLINEENDWIDTH;

//   MSOLINEENDLENGTH - size of arrowhead
typedef enum
{
	msolineShortArrow,
	msolineMediumLenArrow,
	msolineLongArrow
} MSOLINEENDLENGTH;

//   MSOLINEJOIN - line join style.
typedef enum
{
	msolineJoinBevel,     // Join edges by a straight line
	msolineJoinMiter,     // Extend edges until they join
	msolineJoinRound      // Draw an arc between the two edges
} MSOLINEJOIN;

//   MSOLINECAP - line cap style (applies to ends of dash segments too).
typedef enum
{
	msolineEndCapRound,   // Rounded ends - the default
	msolineEndCapSquare,  // Square protrudes by half line width
	msolineEndCapFlat     // Line ends at end point
} MSOLINECAP;


//------------------------------------------------------------------------
//
typedef struct tagMSOFBH
{
	ULONG ver :  4;
	ULONG inst: 12;
	ULONG fbt : 16;
	ULONG cbLength;
}MSOFBH;

enum enumMSOPointers
{
	msofbtDggContainer					= 0xF000,
	msofbtBstoreContainer				= 0xF001,
	msofbtDgContainer					= 0xF002,
	msofbtSpgrContainer					= 0xF003,
	msofbtSpContainer					= 0xF004,
	msofbtSolverContainer				= 0xF005,
	msofbtDgg							= 0xF006,
	msofbtBSE							= 0xF007,
	msofbtDg							= 0xF008,
	msofbtSpgr							= 0xF009,
	msofbtSp							= 0xF00A,
	msofbtOPT							= 0xF00B,
	msofbtTextbox						= 0xF00C,
	msofbtClientTextbox					= 0xF00D,
	msofbtAnchor						= 0xF00E,
	msofbtChildAnchor					= 0xF00F,
	msofbtClientAnchor					= 0xF010,
	msofbtClientData					= 0xF011,
	msofbtConnectorRule					= 0xF012,
	msofbtAlignRule						= 0xF013,
	msofbtArcRule						= 0xF014,
	msofbtClientRule					= 0xF015,
	msofbtCLSID							= 0xF016,
	msofbtCalloutRule					= 0xF017,
	msofbtBlip							= 0xF018,
	msofbtRegroupItems					= 0xF118,
	msofbtSelection						= 0xF119,
	msofbtColorMRU						= 0xF11A,
	msofbtDeletedPspl					= 0xF11D,
	msofbtSplitMenuColors				= 0xF11E,
	msofbtOleObject						= 0xF11F,
	msofbtColorScheme					= 0xF120,
	msofbtUDefProp						= 0xF122,//range of fbts reserved for various kinds of BLIPs                  X   X   X

};

//------------------------------------------------------------------------
// ͼƬ��ʽ����
typedef enum
{
	msoblipUsageDefault,  // All non-texture fill blips get this.
	msoblipUsageTexture,
	msoblipUsageMax = 255 // Since this is stored in a byte
}MSOBLIPUSAGE;

typedef enum
{							   // GEL provided types...
	msoblipERROR = 0,          // An error occured during loading
	msoblipUNKNOWN,            // An unknown blip type
	msoblipEMF,                // Windows Enhanced Metafile
	msoblipWMF,                // Windows Metafile
	msoblipPICT,               // Macintosh PICT
	msoblipJPEG,               // JFIF
	msoblipPNG,                // PNG
	msoblipDIB,                // Windows DIB
	msoblipFirstClient = 32,   // First client defined blip type
	msoblipLastClient  = 255   // Last client defined blip type
}MSOBLIPTYPE;

typedef enum
{
	msobiUNKNOWN = 0,
	msobiWMF  = 0x216,      // Metafile header then compressed WMF
	msobiEMF  = 0x3D4,      // Metafile header then compressed EMF
	msobiPICT = 0x542,      // Metafile header then compressed PICT
	msobiPNG  = 0x6E0,      // One byte tag then PNG data
	msobiJFIF = 0x46A,      // One byte tag then JFIF data
	msobiJPEG = msobiJFIF,
	msobiDIB  = 0x7A8,      // One byte tag then DIB data
	msobiClient=0x800,      // Clients should set this bit
}MSOBI;                     // Blip signature as encoded in the (MSOFBH.inst & 0xFFFE)

typedef enum
{
	msocompressionDeflate = 0,
	msocompressionNone = 254,    // Used only if compression fails
	msocompressionTest = 255,    // For testing only
}MSOBLIPCOMPRESSION;

typedef enum
{
	msofilterAdaptive = 0,       // PNG type - not used/supported for metafile
	msofilterNone = 254,
	msofilterTest = 255,         // For testing only
}MSOBLIPFILTER;

//����MS ppt��presetֵ
typedef enum
{
	msoPresetNone   =   0,
	msoEarlysunset	=	msoPresetNone+136,		//136
	msoLatesunset,								//137
	msoNightfall,								//138
	msoDaybreak,								//139
	msoHorizon,									//140
	msoDesert,									//141
	msoOcean,									//142
	msoCalmwater,								//143
	msoFire,									//144
	msoFog,										//145
	msoMoss,									//146
	msoPeacock,									//147
	msoWheat,									//148
	msoParchmenttrue,							//149
	msoMahogany,								//150
	msoRainbow,									//151
	msoRainbow2,								//152
	msoGold,									//153
	msoGold2,									//154
	msoBrass,									//155
	msoChrome,									//156
	msoChrome2,									//157
	msoSilver,									//158
	msoSapphire,								//159
		
} MSOSHADEPRESET;

#define msdg_CURVE_END	 0x8000
#define msdg_CURVE_START  0x4000
#define msdg_CURVE_LINETO 0x0000
#define msdg_CURVE_BEZIER 0x2000
#define msdg_CURVE_CLOSED 0x6000
//------------------------------------------------------------------------
// FBSE - File Blip Store Entry
typedef struct tagFBSE
{
	BYTE      btWin32;    // Required type on Win32
	BYTE      btMacOS;    // Required type on Mac
	BYTE      rgbUid[16]; // Identifier of blip
	WORD      tag;        // currently unused
	ULONG     size;       // Blip�Ĵ�С
	ULONG     cRef;       // blip�����ü���
	ULONG     offset;    // �ڴ��ͼƬ���ݵ����е�λ��ƫ�ơ�
	BYTE      usage;      // blip��ʹ�÷�ʽ������ͼƬ����������ơ�����MSOBLIPUSAGE
	BYTE      cbName;     // blip���Ƶĳ��ȡ�
	BYTE      unused2;    // for the future
	BYTE      unused3;    // for the future
}FBSE;

//------------------------------------------------------------------------
//The first part of an OPT record is an array of FOPTEs
typedef struct
{
	USHORT pid		: 14;    // Property ID
	USHORT fBid		: 1;     // value is a blip ID �C only valid if fComplex is FALSE
	USHORT fComplex : 1;	 // complex property, value is length
	
	union
	{
		ULONG  op;				 // Value
		ULONG  len;
	};
} FOPTE;

//------------------------------------------------------------------------
// DrawingContainer
typedef struct
{
	ULONG	csp;          // The number of shapes in this drawing
	ULONG	spidCur;      // The last MSOSPID given to an SP in this DG
}FDG;

//------------------------------------------------------------------------
//Shape ID = DrawingIndexInDoc * 0x400 + ShapeIndexInDrawing
//DrawingIndexInDoc��ֻ��������
typedef struct tagFDGG
{
	ULONG spidMax; // The current maximum shape ID
	ULONG cidcl;     // The number of ID clusters (FIDCLs) + 1������˵����һ�����õ�Drawing������
	ULONG cspSaved;  // The total number of shapes saved
					 // (including deleted shapes, if undo
					 // information was saved)
	ULONG cdgSaved;  // The total number of drawings saved
} FDGG;

typedef struct//ShapeID����������
{
	ULONG dgid;    // DG owning the SPIDs in this cluster��Drawing��������
	ULONG cspidCur;  // number of SPIDs used so far����Drawing����һ�������õ�Shape��
} FIDCL;

//------------------------------------------------------------------------
//Shape
typedef ULONG MSOSPID;

typedef struct
{
//
   ULONG fGroup : 1;        //0x001 This shape is a group shape
   ULONG fChild : 1;        //0x002 Not a top-level shape
   ULONG fPatriarch : 1;    //0x004 This is the topmost group shape.
                            // Exactly one of these per drawing. 
   ULONG fDeleted : 1;      //0x008 The shape has been deleted
//
   ULONG fOleShape : 1;     //0x010 The shape is an OLE object
   ULONG fHaveMaster : 1;   //0x020 Shape has a hspMaster property
   ULONG fFlipH : 1;        //0x040 Shape is flipped horizontally
   ULONG fFlipV : 1;        //0x080 Shape is flipped vertically
//
   ULONG fConnector : 1;    //0x100 Connector type of shape
   ULONG fHaveAnchor : 1;   //0x200 Shape has an anchor of some kind
   ULONG fBackground : 1;   //0x400 Background shape
   ULONG fHaveSpt : 1;      //0x800 Shape has a shape type property
//
   ULONG reserved : 20;     // Not yet used
}MSOSPFLAGS;

typedef struct tagFSP
{
	MSOSPID		spid;           // The shape id 
	MSOSPFLAGS  grfPersistent;
}FSP;
//------------------------------------------------------------------------
//Shape Group
typedef struct tagFSPGR
{
	RECT   rcgBounds;
}FSPGR;
//------------------------------------------------------------------------
//
typedef struct
{
	SHORT top;
	SHORT left;
	SHORT right;
	SHORT bottom;
}SRECT;

typedef enum
{
	msoAnchor_Unknown	= -1,
	msoAnchor			= 0,//An anchor record is used for top-level shapes 
							//when the shape streamed to the clipboard. 
							//The content of the record is simply a RECT with
							//a coordinate system of 100,000 units per 
							//inch and origin in the top-left of the drawing.
	msoAnchor_Child		= 1,//����ShapeGroup�ĵ�λ
	msoAnchor_Client	= 2,//��Host����
}MSOANCHORUINT;//���ε�λ
//------------------------------------------------------------------------
//IMsoArray.txt
typedef struct
{
	short count;		//����
	short cntInMem;		//���ڴ��еĸ���������û�ã� >= count
	short size;			//Ԫ�صĴ�С
}FMsoArrayHeader;
//------------------------------------------------------------------------
//
typedef enum
{
	OP_BlipID	= 0x2,
	OP_Complex	= 0x4,
}MsoPropFlags;
//------------------------------------------------------------------------
//
#pragma pack()

#pragma pack(1)
typedef struct tagMSOCLIENTANCHOREX
{
	ULONG bx;	//XRelTo;
	ULONG by;	//YRelTo;
//	ULONG XAlign;	//Star Office �л���ȡ�����������ݣ�������֪���Ǹ����õ�
//	ULONG YAlign;
} MSOCLIENTANCHOREX;

struct FConnectorRule
{
   ULONG ruid;       // rule ID
   MSOSPID spidA;    // SPID of shape A
   MSOSPID spidB;    // SPID of shape B
   MSOSPID spidC;    // SPID of connector shape
   ULONG cptiA;      // Connection site Index of shape A
   ULONG cptiB;      // Connection site Index of shape B
};

struct FSplitMenuColors
{
	ULONG fillColor;
	ULONG lineColor;
	ULONG shadowColor;
	ULONG threedColor;
};

#pragma pack()

#include "msescher_errcode.h"

#endif // __MSOESCHER_H__
