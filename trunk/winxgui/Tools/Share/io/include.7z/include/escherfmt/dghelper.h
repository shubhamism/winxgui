/* -------------------------------------------------------------------------
//	�ļ���		��	dghelper.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-26 9:44:32
//	��������	��	ժ��dyl
//
// -----------------------------------------------------------------------*/
#ifndef __PPTFMT_DGHELPER_H__
#define __PPTFMT_DGHELPER_H__

//#include "mediaconstobj.h"
//#include "mediaconstbasic.h"
#include "msoescher.h"
//#include <cmath>

class KShape;
class KObjPropsTable;

namespace dgreader
{

	//#define EMU2XML(emu)	(emu / 3600)
	#define EMU2XML(emu)	(emu)		//there are 360000 EMUs per centimeter
	//�м��ͳһ��EMU��λ

	LONG XMLFillType(LONG lfilltype);
	LONG XMLStrokeStyle(LONG);
	LONG XMLStrokeDashStyle(LONG);
	LONG XMLStrokeFillStyle(LONG llineStyle);
	LONG XMLArrowType(LONG);
	LONG XMLArrowWidth(LONG);
	LONG XMLArrowLength(LONG);
	LONG XMLShadowType(LONG);
	LONG XMLGeoTextAlignType(LONG lAligntype);
	int	GetHatchStyle(WCHAR* pBlipName);
	int	GetDefaultTextureStyle(WCHAR* pBlipName);
	int GetCustomType(WCHAR* pShapeName);
	
	RECT GetShapeBoundRect(long nRotation, RECT& rc);

	BOOL QueryBoolProp(KShape* pObj, LONG propid, BOOL* pprop);
	BOOL QueryI4Prop(KShape* pObj, LONG propid, LONG* pprop);
	BOOL QueryI4UDefProp(KShape* pObj, LONG propid, LONG* pprop);
	BOOL QueryBoolUDefProp(KShape* pObj, LONG propid, BOOL* pprop);
	BOOL QueryBstrProp(KShape* pShape, LONG propid, const WCHAR** ppName);

	BOOL QueryBoolProp(KObjPropsTable* pOPT, LONG propid, BOOL* pprop);
	BOOL QueryI4Prop(KObjPropsTable* pOPT, LONG propid, LONG* pprop);
	BOOL QueryI4UDefProp(KObjPropsTable* pOPT, LONG propid, LONG* pprop);
	BOOL QueryBoolUDefProp(KObjPropsTable* pOPT, LONG propid, BOOL* pprop);
	BOOL QueryBstrProp(KObjPropsTable* pOPT, LONG propid, const WCHAR** ppName);

	
	int ToLOMETRIC (int x, MSOANCHORUINT u, HRESULT* pResult = NULL);
	
	inline float FIX2FLOAT(LONG fix)
	{
		return (float)fix / 0x10000 + 0.005;
	}
	inline LONG FLOAT2FIX(float num)
	{
		num *= 0x10000;;
		return (LONG)num;
	}

	inline LONG EMUS2PT(LONG emus)
	{
		return emus / 12700.0 + 0.5;
	}

	inline double EMUS2INCH(LONG emus)
	{
		static const double EmusPerInch = 12700.0 * 72.0;
		return emus / EmusPerInch;
	}
	
	LONG XMLRenderMode(LONG lRenderMode);
	LONG XMLShadePresetType(LONG lPresettype);
	LONG XMLBlipType(LONG lBlipType);
	LONG XMLAnchorTextType(LONG lAnchorType);
	LONG XMLTextFlowType(LONG lFlowType);	//���ַ���
	LONG XMLTextWrapType(LONG lWrapType);	//��������
	LONG XMLTextDirFont(LONG lFontType);	//������ת
	LONG XMLTxDir(LONG txDir);				//���ַ���
	LONG XMLLineJoinType(LONG lType);
	LONG XMLLineCapType(LONG lType);
	LONG XMLCxStyle(LONG lType);
	LONG XMLCalloutType(LONG lType);
	LONG XMLCalloutAngleType(LONG lType);
	LONG XMLCalloutDropType(LONG lType);
}
// -------------------------------------------------------------------------

#endif /* __PPTFMT_DGHELPER_H__ */
