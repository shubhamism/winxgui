/* -------------------------------------------------------------------------
//	�ļ���		��	msescher_errcode.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-21 9:35:09
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __MSESCHER_ERRCODE_H__
#define __MSESCHER_ERRCODE_H__

// -------------------------------------------------------------------------
#ifndef _HRESULT_DEFINED
#define _HRESULT_DEFINED
typedef LONG HRESULT;
#endif

#ifndef MAKE_HRESULT
#define MAKE_HRESULT(sev,fac,code)	((HRESULT) (((unsigned long)(sev)<<31) | ((unsigned long)(fac)<<16)	| ((unsigned long)(code))) )
#endif

#define FACILITY_MSESCHER	0xFF

#define MAKE_ESCHER_ERRCODE(code) MAKE_HRESULT (1, FACILITY_MSESCHER, (code))

enum MSESCHERREADERERRCODE
{
		E_ESCHER_STREAM_LEN		= MAKE_ESCHER_ERRCODE (1),	//the len of stream is wrong
		E_ESCHER_STREAM_INVALID = MAKE_ESCHER_ERRCODE (2),
		E_ESCHER_STREAM_READ	= MAKE_ESCHER_ERRCODE (3),
		
		E_ESCHER_INVALID_FBT	= MAKE_ESCHER_ERRCODE (20),
		E_ESCHER_INVALID_FBH	= MAKE_ESCHER_ERRCODE (21),
		E_ESCHER_INVALID_INST	= MAKE_ESCHER_ERRCODE (22),
};


// -------------------------------------------------------------------------

#endif /* __MSESCHER_ERRCODE_H__ */
