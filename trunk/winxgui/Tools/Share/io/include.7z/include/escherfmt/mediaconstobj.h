/* -------------------------------------------------------------------------
//	�ļ���		��	pptfmt/mediaconstobj.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-26 9:48:59
//	��������	��	ժ��xsw
//
// -----------------------------------------------------------------------*/
#ifndef __PPTFMT_MEDIACONSTOBJ_H__
#define __PPTFMT_MEDIACONSTOBJ_H__


// -------------------------------------------------------------------------
// KSOFRAME

enum KSOBGMODE		// ����ģʽ
{
	bgmodeInvert		= 0,
	bgmodeTransparent	= 1,
	bgmodeOpaque		= 2,
	bgmodeGradient		= 10,	// ����ɫ����
};

enum KSOANCHOR		// �Ű�λ������
{
	anchorFollowPage,	// ҳ�����
	anchorFollowText,	// ���Ķ���
	anchorEachPage,		// ȫ�ֶ���
	anchorOddPage,		// ȫ�ֶ���
	anchorEvenPage,		// ȫ�ֶ���
};

enum KSOWRAPMODE	// ������������:(��Ҫ��ָ���������)
{
	wrapAround			= 0x00,
	wrapByPointAround	= 0x01,
	wrapNoWrap			= 0x04,

	wrapBoth			= 0x0100,
	wrapLeft			= 0x0200,
	wrapRight			= 0x0300,
	wrapOnLargerSide	= 0x0400,
};

// -------------------------------------------------------------------------
// KSOTEXTFLOW

enum KSOTEXTFLOW		// ���������Ű�(textflow)��ʽ	MSOTXFL
{
	txtflowHorzN = 0,           // Horizontal non-@
	txtflowTtoBA = 1,           // Top to Bottom @-font
	txtflowBtoTN = 2,            // Bottom to Top non-@
	txtflowTtoBN = 3,           // Top to Bottom non-@
	txtflowHorzA = 4,           // Horizontal @-font
	txtflowVertN = 5,           // Vertical, non-@
	//add
	txtflowBtoTA = 10,           // Bottom to Top @-font
	txtflowVertA = 11,           // Vertical, @-font
};

// -------------------------------------------------------------------------
// KSOTEXTDIR

enum KSOTEXTDIR		// ���������Ű�(textdir)����	MSOTXDIR - text direction (needed for Bi-Di support)
{
	txtdirLTR,           // left-to-right text direction
	txtdirRTL,           // right-to-left text direction
	txtdirContext,      // context text direction
};

// -------------------------------------------------------------------------
// KSOTEXTANCHOR

enum KSOTEXTANCHOR		// �������ֶ�������
{
	textanchorTop					= 0,
	textanchorMiddle				= 1,
	textanchorBottom				= 2, 
	textanchorTopCentered			= 3, 
	textanchorMiddleCentered		= 4, 
	textanchorBottomCentered		= 5,
	textanchorTopBaseline			= 6,
	textanchorBottomBaseline		= 7,
	textanchorTopCenteredBaseline	= 8,
	textanchorBottomCenteredBaseline= 9,

	textanchorTopRight			= 107, 
	textanchorMiddleRight		= 108, 
	textanchorBottomRight		= 109,
};

// -------------------------------------------------------------------------
// KSOXYTYPE

enum KSOXYTYPE		// ���������ê���λ������
{
	xytypeNone				 = -1,
	xytypePageMargin		 = 0,	//relative to page margin
	xytypePageTopLeft		 = 1,	//relative to top of page
	xytypeColumnParagraph	 = 2,	//relative to text (column for horizontal text; paragraph for vertical text)
	xytypeCharLine			 = 3,	//relative to char (char for horizontal text; line for vertical text)
	xytypeReserved			 = 4	// reserved
};

// -------------------------------------------------------------------------
// KSOOLE

// -------------------------------------------------------------------------
// KSOIMAGE

enum KSOCLRMODE		// ��ɫģʽ
{
	clrmodeNormal		= 0,	// ����
	clrmodeGrayScale	= 1,	// �Ҷ�
	clrmodeMono			= 2,	// ��ɫ
};

// -------------------------------------------------------------------------

enum KSODIAGONALTYPE
{
	diagtypeAvg,	// ƽ���ֲ���б��
	diagtypeBelow,	// ƫ���²��б��
	diagtypeAbove,	// ƫ���ϲ��б��
	diagtypeCross,	// ����б�ߣ�tblcellDiagHeadX/Y��Ч��
};

enum KSOGRAPHTYPE
{
	graphMin				               	= 0,		
	graphNotPrimitive						= graphMin,	// �Ǽ�ͼ�ζ���
	graphRectangle							= 1,        // ����
	graphRoundRectangle						= 2,        // Բ�Ǿ���
	graphEllipse							= 3,        // ��Բ
	graphDiamond							= 4,        // ����
	graphIsocelesTriangle					= 5,        // ����������(����Ϊ������)
	graphRightTriangle						= 6,        // ֱ��������
	graphParallelogram						= 7,        // ƽ���ı���
	graphTrapezoid							= 8,        // ����
	graphHexagon							= 9,        // ������
	graphOctagon							= 10,       // �˱���
	graphPlus								= 11,       // ʮ����
	graphStar								= 12,       // �����
	graphArrow								= 13,       // ��ͷ
	graphThickArrow							= 14,       // �ּ�ͷ
	graphHomePlate							= 15,       // 
	graphCube								= 16,       // ������
	graphBalloon							= 17,       //����
	graphSeal								= 18,       //ͼ��
	graphArc								= 19,       // ����
	graphLine								= 20,       // ֱ��
	graphPlaque								= 21,       //
	graphCan								= 22,       // Բ����
	graphDonut								= 23,       // Բ��
	graphTextSimple							= 24,       //����
	graphTextOctagon						= 25,       
	graphTextHexagon						= 26,
	graphTextCurve							= 27,
	graphTextWave							= 28,
	graphTextRing							= 29,
	graphTextOnCurve						= 30,
	graphTextOnRing							= 31,
	graphStraightConnector1					= 32,
	graphBentConnector2						= 33,
	graphBentConnector3						= 34,
	graphBentConnector4						= 35,
	graphBentConnector5						= 36,
	graphCurvedConnector2					= 37,
	graphCurvedConnector3					= 38,
	graphCurvedConnector4					= 39,
	graphCurvedConnector5					= 40,
	graphCallout1							= 41,
	graphCallout2							= 42,
	graphCallout3							= 43,
	graphAccentCallout1						= 44,
	graphAccentCallout2						= 45,
	graphAccentCallout3						= 46,
	graphBorderCallout1						= 47,
	graphBorderCallout2						= 48,
	graphBorderCallout3						= 49,
	graphAccentBorderCallout1				= 50,
	graphAccentBorderCallout2				= 51,
	graphAccentBorderCallout3				= 52,
	graphRibbon								= 53,
	graphRibbon2							= 54,
	graphChevron							= 55,
	graphPentagon							= 56,       // �����
	graphNoSmoking							= 57,		// ���̱�־(Բ����һб��)
	graphSeal8								= 58,		// �˽���
	graphSeal16								= 59,		// 16����
	graphSeal32								= 60,		// 32����
	graphWedgeRectCallout					= 61,
	graphWedgeRRectCallout					= 62,
	graphWedgeEllipseCallout				= 63,
	graphWave								= 64,
	graphFoldedCorner						= 65,
	graphLeftArrow							= 66,
	graphDownArrow							= 67,
	graphUpArrow							= 68,
	graphLeftRightArrow						= 69,
	graphUpDownArrow						= 70,
	graphIrregularSeal1						= 71,
	graphIrregularSeal2						= 72,
	graphLightningBolt						= 73,
	graphHeart								= 74,
	graphPictureFrame						= 75,
	graphQuadArrow							= 76,
	graphLeftArrowCallout					= 77,
	graphRightArrowCallout					= 78,
	graphUpArrowCallout						= 79,
	graphDownArrowCallout					= 80,
	graphLeftRightArrowCallout				= 81,
	graphUpDownArrowCallout					= 82,
	graphQuadArrowCallout					= 83,
	graphBevel								= 84,
	graphLeftBracket						= 85,
	graphRightBracket						= 86,
	graphLeftBrace							= 87,
	graphRightBrace							= 88,
	graphLeftUpArrow						= 89,
	graphBentUpArrow						= 90,
	graphBentArrow							= 91,
	graphSeal24								= 92,
	graphStripedRightArrow					= 93,
	graphNotchedRightArrow					= 94,
	graphBlockArc							= 95,
	graphSmileyFace							= 96,
	graphVerticalScroll						= 97,
	graphHorizontalScroll					= 98,
	graphCircularArrow						= 99,
	graphNotchedCircularArrow				= 100,
	graphUturnArrow							= 101,
	graphCurvedRightArrow					= 102,
	graphCurvedLeftArrow					= 103,
	graphCurvedUpArrow						= 104,
	graphCurvedDownArrow					= 105,
	graphCloudCallout						= 106,
	graphEllipseRibbon						= 107,
	graphEllipseRibbon2						= 108,
	graphFlowChartProcess					= 109,
	graphFlowChartDecision					= 110,
	graphFlowChartInputOutput				= 111,
	graphFlowChartPredefinedProcess			= 112,
	graphFlowChartInternalStorage			= 113,
	graphFlowChartDocument					= 114,
	graphFlowChartMultidocument				= 115,
	graphFlowChartTerminator				= 116,
	graphFlowChartPreparation				= 117,
	graphFlowChartManualInput				= 118,
	graphFlowChartManualOperation			= 119,
	graphFlowChartConnector					= 120,
	graphFlowChartPunchedCard				= 121,
	graphFlowChartPunchedTape				= 122,
	graphFlowChartSummingJunction			= 123,
	graphFlowChartOr						= 124,
	graphFlowChartCollate					= 125,
	graphFlowChartSort						= 126,
	graphFlowChartExtract					= 127,
	graphFlowChartMerge						= 128,
	graphFlowChartOfflineStorage			= 129,
	graphFlowChartOnlineStorage				= 130,
	graphFlowChartMagneticTape				= 131,
	graphFlowChartMagneticDisk				= 132,
	graphFlowChartMagneticDrum				= 133,
	graphFlowChartDisplay					= 134,
	graphFlowChartDelay						= 135,
	graphTextPlainText						= 136,
	graphTextStop							= 137,
	graphTextTriangle						= 138,
	graphTextTriangleInverted				= 139,
	graphTextChevron						= 140,
	graphTextChevronInverted				= 141,
	graphTextRingInside						= 142,
	graphTextRingOutside					= 143,
	graphTextArchUpCurve					= 144,
	graphTextArchDownCurve					= 145,
	graphTextCircleCurve					= 146,
	graphTextButtonCurve					= 147,
	graphTextArchUpPour						= 148,
	graphTextArchDownPour					= 149,
	graphTextCirclePour						= 150,
	graphTextButtonPour						= 151,
	graphTextCurveUp						= 152,
	graphTextCurveDown						= 153,
	graphTextCascadeUp						= 154,
	graphTextCascadeDown					= 155,
	graphTextWave1							= 156,
	graphTextWave2							= 157,
	graphTextWave3							= 158,
	graphTextWave4							= 159,
	graphTextInflate						= 160,
	graphTextDeflate						= 161,
	graphTextInflateBottom					= 162,
	graphTextDeflateBottom					= 163,
	graphTextInflateTop						= 164,
	graphTextDeflateTop						= 165,
	graphTextDeflateInflate					= 166,
	graphTextDeflateInflateDeflate			= 167,
	graphTextFadeRight						= 168,
	graphTextFadeLeft						= 169,
	graphTextFadeUp							= 170,
	graphTextFadeDown						= 171,
	graphTextSlantUp						= 172,
	graphTextSlantDown						= 173,
	graphTextCanUp							= 174,
	graphTextCanDown						= 175,
	graphFlowChartAlternateProcess			= 176,
	graphFlowChartOffpageConnector			= 177,
	graphCallout90							= 178,
	graphAccentCallout90					= 179,
	graphBorderCallout90					= 180,
	graphAccentBorderCallout90				= 181,
	graphLeftRightUpArrow					= 182,
	graphSun								= 183,
	graphMoon								= 184,
	graphBracketPair						= 185,
	graphBracePair							= 186,
	graphSeal4								= 187,
	graphDoubleWave							= 188,
	graphActionButtonBlank					= 189,
	graphActionButtonHome					= 190,
	graphActionButtonHelp					= 191,
	graphActionButtonInformation			= 192,
	graphActionButtonForwardNext			= 193,
	graphActionButtonBackPrevious			= 194,
	graphActionButtonEnd					= 195,
	graphActionButtonBeginning				= 196,
	graphActionButtonReturn					= 197,
	graphActionButtonDocument				= 198,
	graphActionButtonSound					= 199,
	graphActionButtonMovie					= 200,
	graphHostControl						= 201,
	graphTextBox							= 202,
	//����Ϊ�������ӵĶ���
	graphOLE								= 300,
	graphGroup								= 301,
	graphPieColumn                          = 302, //Բ��ͼ
	graphTable								= 304, //���񡣼������ͱ�Ԫ�Ա�ͳһ������
	graphMax									 ,
	graphNil								= 0x0FFF,
};

// -------------------------------------------------------------------------

#endif /* __PPTFMT_MEDIACONSTOBJ_H__ */
