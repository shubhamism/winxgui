/* -------------------------------------------------------------------------
//	�ļ���		��	ioheader/baseref.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-12-31 14:22:29
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IOHEADER_BASEREF_H__
#define __IOHEADER_BASEREF_H__

// -------------------------------------------------------------------------
class KBaseRef
{
public:
	KBaseRef() : m_nRef( 1 )
	{}
	virtual ~KBaseRef()
	{}
	
public:
	unsigned long AddRef()
	{
		return  m_nRef++;
	}
	
	unsigned long Release()
	{
		if ( 0 == ( --m_nRef ) )
		{
			delete this;
			return 0;
		}
		return m_nRef;
	}
	
	unsigned long GetRefCount()
	{
		return m_nRef;
	}
protected:
	unsigned long m_nRef;
};

// -------------------------------------------------------------------------

#endif /* __IOHEADER_BASEREF_H__ */
