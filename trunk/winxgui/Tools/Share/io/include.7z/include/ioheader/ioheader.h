/* -------------------------------------------------------------------------
//	�ļ���		��	ioheader/ioheader.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-12-31 14:24:33
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IOHEADER_IOHEADER_H__
#define __IOHEADER_IOHEADER_H__

// -------------------------------------------------------------------------
#ifndef __IOHEADER_BASEREF_H__
#include "baseref.h"
#endif //__IOHEADER_BASEREF_H__

#ifndef __IOTOOLS_H__
#include "iotools.h"
#endif //__IOTOOLS_H__

// -------------------------------------------------------------------------

#endif /* __IOHEADER_IOHEADER_H__ */
