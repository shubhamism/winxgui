/* -------------------------------------------------------------------------
//	�ļ���		��	streamreader.h
//	������		��	ׯӿ
//	����ʱ��	��	2003-11-19 12:29:25
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __STREAMREADER_H__
#define __STREAMREADER_H__

// -------------------------------------------------------------------------
#include "stl/stack.h"
//template <class T> 
//HRESULT Read (IStream* pStream, T* t, ULONG nSize = sizeof (T));
namespace ioreader
{
HRESULT Seek (IStream* pStream, DWORD dwOrign, int nOffset, ULONG* pNewPos = NULL);
HRESULT SeekNext (IStream* pStream, int nOffset, ULONG* pNewPos = NULL);
int		GetStreamSize (IStream* pStream);
int		GetCurPos (IStream* pStream);
//------------------------------------------------------------------------
//

enum KStreamReader_Except
{
	SR_INVALID_ISTREAM	= 0x1,
	SR_ISTREAM_SEEK		= 0x2,
	SR_ISTREAM_READ		= 0x3,
	SR_OVERFLOW			= 0x4,//������ָ���ķ�Χ
};

class KStreamReader
{
public:
	KStreamReader ();
	virtual ~KStreamReader ();
public:
	HRESULT Attach (IStream* pStream, int nLen = INT_MAX);
	HRESULT Attach2(IStream* pStream);//����һ��ԭ��
	HRESULT Detach ();
	
	int GetInstance ();
	int GetVer		();
	int GetType		();
	int GetLength	();
	
	BOOL NextRecord	(BOOL bSkipContainer = TRUE);
	void Read		(void* pBuf, int nSize, BOOL bForce = FALSE);
	void Seek		(int offset, BOOL bForce = FALSE);
	
	void GoToRecHead();
	
	void GoEnd		();
	void GoHead		();
	
	BOOL IsEnd ();
	
	void PushPos ();
	void PopPos ();
protected:
#pragma pack (1)
	struct RecHeader
	{
		unsigned ver  :  4;
		unsigned inst : 12;
		unsigned type : 16;
		unsigned len  : 32;
	};
#pragma pack ()
	
	typedef std::stack<int> KStreamPosStack;
	KStreamPosStack m_SavedPos;
	
	void ThrowE (int nCode);
	
	enum OPTIONS
	{
		opNULL			= 0x0,
			opRHValid		= 0x1,
			opAttach2		= 0x2,		
	};
	
	UINT	  m_nOptions;
	UINT	  m_nRoadEnd;
	UINT	  m_nRoadHead;
	UINT	  m_nRecHead;
	
	IStream*  m_pStream;
	RecHeader m_rh;
};
//------------------------------------------------------------------------
//
class KStreamPosSaver
{
public:
	KStreamPosSaver  (IStream* pStream);
	~KStreamPosSaver ();
protected:
	IStream* m_pStream;
	int		 m_nPos;
};

//------------------------------------------------------------------------
//
#include "streamreader.inl"
}

// -------------------------------------------------------------------------

#endif /* __STREAMREADER_H__ */
