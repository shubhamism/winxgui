/* -------------------------------------------------------------------------
//	�ļ���		��	iox_docfmt.h
//	������		��	pengfang
//	����ʱ��	��	2003-9-19 13:17:52
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IOX_DOCFMT_H__
#define __IOX_DOCFMT_H__

// -------------------------------------------------------------------------

#if !defined(__iotype)
#define __iotype
#endif

#include "docfmt/DO_WordStruct.h"
#include "docfmt/DO_DefineConst.h"
#include "docfmt/DO_SprmDefine.h"
#include "docfmt/DO_DefFibId.h"
#include "docfmt/DO_DefSpecChar.h"

// -------------------------------------------------------------------------

#endif /* __IOX_DOCFMT_H__ */
