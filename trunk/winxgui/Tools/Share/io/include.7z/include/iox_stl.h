/***************************************************************************
*                                                                          *
*                                iox_stl.h                                 *
*                                                                          *
*                                                   Zqy 2003-6-11 14:55:52 *
*													modified: wanghui      *
***************************************************************************/
#ifndef __IOX_STL_H_INC__
#define __IOX_STL_H_INC__

//ΪETʹ��STL�ṩһ��Adapter

#include "stl/vector.h"
#include "stl/deque.h"
#include "stl/list.h"
#include "stl/map.h"
#include "stl/hash_map.h"
#include "stl/set.h"
#include "stl/hash_set.h"
#include "stl/string.h"
#include "stl/stack.h"
#include "stl/queue.h"
#include "stl/algorithm.h"


#endif // __IOX_STL_H_INC__
