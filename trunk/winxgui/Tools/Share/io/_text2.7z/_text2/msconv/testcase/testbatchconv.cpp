/* -------------------------------------------------------------------------
//	�ļ���		��	testbatchconv.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 10:09:40
//	��������	��	
//
//	$Id: testbatchconv.cpp,v 1.7 2005/10/27 02:06:13 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <wordhelp.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// SD_DoConvertToRtf

inline
STDMETHODIMP SD_DoConvertToRtf(
						  IN LPCWSTR szFile,
						  IN SD_FILEINFO_ARG fiArg,
						  IN LPVOID pParam)
{
	KWordHelper& word = *(KWordHelper*)pParam;
	
	WCHAR szDestFile[_MAX_PATH];
	
	LPCWSTR szDot = wcsrchr(szFile, '.');
	if (szDot == NULL || wcsicmp(szDot, __X(".doc")) != 0)
		return S_OK;

	USES_CONVERSION;
	LPCWSTR szFileName = wcsrchr(szFile, '/') + 1;
	printf("\nprocessing %s ...", W2A(szFileName));

	memcpy(
		szDestFile,
		szFile,
		(szDot - szFile)*sizeof(WCHAR));

	wcscpy(
		szDestFile + (szDot - szFile),
		__X(".rtf"));
	
	HRESULT hr = word.ConvertFile(
		szFile,
		szDestFile,
		wdFormatRTF);
	
	ASSERT_OK(hr);

	return S_OK;
}

// -------------------------------------------------------------------------
// SD_DoConvertToTxt

inline
STDMETHODIMP SD_DoConvertToTxt(
							   IN LPCWSTR szFile,
							   IN SD_FILEINFO_ARG fiArg,
							   IN LPVOID pParam)
{
	KWordHelper& word = *(KWordHelper*)pParam;
	
	WCHAR szDestFile[_MAX_PATH];
	
	LPCWSTR szDot = wcsrchr(szFile, '.');
	if (szDot == NULL || wcsicmp(szDot, __X(".doc")) != 0)
		return S_OK;
	
	USES_CONVERSION;
	LPCWSTR szFileName = wcsrchr(szFile, '/') + 1;
	printf("\nprocessing %s ...", W2A(szFileName));
	
	memcpy(
		szDestFile,
		szFile,
		(szDot - szFile)*sizeof(WCHAR));
	
	wcscpy(
		szDestFile + (szDot - szFile),
		__X(".txt"));
	
	HRESULT hr = word.ConvertFile(
		szFile,
		szDestFile,
		wdFormatText);
	
	ASSERT_OK(hr);
	
	return S_OK;
}

// -------------------------------------------------------------------------
// SD_HtmlToText

STDMETHODIMP SD_HtmlToText(
						   IN LPCWSTR szFile,
						   IN SD_FILEINFO_ARG fiArg,
						   IN LPVOID pParam)
{
	KWordHelper& word = *(KWordHelper*)pParam;
	
	WCHAR szDestFile[_MAX_PATH];
	
	LPCWSTR szDot = wcsrchr(szFile, '.');
	if (szDot == NULL || wcsicmp(szDot, __X(".htm")) != 0)
		return S_OK;
	
	USES_CONVERSION;
	LPCWSTR szFileName = wcsrchr(szFile, '/') + 1;
	printf("\nprocessing %s ...", W2A(szFileName));
	
	memcpy(
		szDestFile,
		szFile,
		(szDot - szFile)*sizeof(WCHAR));
	
	wcscpy(
		szDestFile + (szDot - szFile),
		__X(".txt"));
	
	HRESULT hr = word.ConvertFile(
		szFile,
		szDestFile,
		wdFormatText
		);
	
	ASSERT_OK(hr);
	
	return S_OK;
}

// -------------------------------------------------------------------------

typedef std::basic_string<WCHAR> string_type;

struct SD_WebsiteToText_Param
{
	KWordHelper word;
	string_type strDestDirBase;
	UINT iSrcUrlBase;
};

STDMETHODIMP SD_WebsiteToText(
						   IN LPCWSTR szFile,
						   IN SD_FILEINFO_ARG fiArg,
						   IN LPVOID pParam)
{
	SD_WebsiteToText_Param& para = *(SD_WebsiteToText_Param*)pParam;
	KWordHelper& word = para.word;	
		
	LPCWSTR szDot = wcsrchr(szFile, '.');
	if (szDot == NULL || wcsicmp(szDot, __X(".htm")) != 0)
		return S_OK;
	
	USES_CONVERSION;
	printf("\nprocessing %s ...", W2A(szFile + para.iSrcUrlBase));
	
	string_type strDestFileName = szFile + para.iSrcUrlBase;
	for (string_type::iterator it = strDestFileName.begin(); it != strDestFileName.end(); ++it)
	{
		if (*it == '/' || *it == '\\')
			*it = '!';
	}
	LPWSTR szExt = &*strDestFileName.end() - 3;
	szExt[0] = 't';
	szExt[1] = 'x';
	szExt[2] = 't';

	string_type strDestFile = para.strDestDirBase + strDestFileName;
	
	HRESULT hr = word.ConvertFile(
		szFile,
		strDestFile.c_str(),
		wdFormatText
		);
	
	ASSERT_OK(hr);
	
	return S_OK;
}

// -------------------------------------------------------------------------

class TestBatchConv : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestBatchConv);
//		CPPUNIT_TEST(convToRtf);
//		CPPUNIT_TEST(convToText);
//		CPPUNIT_TEST(convHtmlToText);
//		CPPUNIT_TEST(convWebsiteToText);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void convToText()
	{
		const WCHAR szDir[] = __X("J:/v6/sample/doc");
		
		KWordHelper word;
		ASSERT(word.IsWordInstalled());
		
		_XScanDirectory(
			szDir,
			SD_DoConvertToTxt,
			SD_SCAN_SUBDIR,
			&word);
	}

	void convToRtf()
	{
		const WCHAR szDir[] = __X("J:/v6/sample");

		KWordHelper word;
		ASSERT(word.IsWordInstalled());
		
		_XScanDirectory(
			szDir,
			SD_DoConvertToRtf,
			0,
			&word);
	}

	void convHtmlToText()
	{
		const WCHAR szDir[] = __X("J:/v6/Coding/product/win32d/testcase/chmrw/gb2312");
		
		KWordHelper word;
		ASSERT(word.IsWordInstalled());
		
		word.SetDefaultTextEncoding(msoEncodingSimplifiedChineseGBK);

		_XScanDirectory(
			szDir,
			SD_HtmlToText,
			SD_SCAN_SUBDIR,
			&word);
	}

	void convWebsiteToText()
	{
		const WCHAR szDir[] = L"F:/web/www.china.org.cn/download/latest/www.china.org.cn/";
		
		SD_WebsiteToText_Param para;
		ASSERT(para.word.IsWordInstalled());
		
		para.strDestDirBase = __X("F:/web/text/www.china.org.cn/");
		para.iSrcUrlBase = countof(szDir) - 1;

		para.word.SetDefaultTextEncoding(msoEncodingUTF8);
		
		_XScanDirectory(
			szDir,
			SD_WebsiteToText,
			SD_SCAN_SUBDIR,
			&para);
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestBatchConv);

// -------------------------------------------------------------------------
//	$Log: testbatchconv.cpp,v $
//	Revision 1.7  2005/10/27 02:06:13  xushiwei
//	vc8 support
//	
//	Revision 1.6  2005/02/04 08:18:43  xushiwei
//	ʹ��wordת��htm��txt�ļ������Ƿ���Ч��ԶԶ����IE���ʴ�׼���������������
//	
//	Revision 1.5  2005/01/27 05:15:58  xushiwei
//	֧��html2text�����ҿ������ñ����text�ı��롣
//	
//	Revision 1.4  2005/01/27 03:35:15  xushiwei
//	����ת��html => text�ļ���
//	
//	Revision 1.3  2005/01/24 10:18:04  xushiwei
//	������docת��Ϊtxt��
//	
//	Revision 1.1  2004/12/24 05:37:53  xushiwei
//	�޸�����bug��������batch word2rtf������
//	
