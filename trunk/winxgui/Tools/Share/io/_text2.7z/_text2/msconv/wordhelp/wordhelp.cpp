/* -------------------------------------------------------------------------
//	�ļ���		��	wordreader.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-13 12:06:01
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <kso/io/fmtcheck.h>
#include "wordhelp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// link docreader

#pragma linklib("docreader")

STDAPI _dr_Initialize();
STDAPI _dr_Terminate();
STDAPI _dr_CreateSourceEx(IStorage* pDocStg, IKContentSource** ppContentSource);

// -------------------------------------------------------------------------

inline 
STDMETHODIMP GetTempFileW(LPWSTR szTempFile)
{
	WCHAR szTempPath[MAX_PATH];
	GetTempPathW(countof(szTempPath), szTempPath);
	GetTempFileNameW(szTempPath, __X("kso"), 0, szTempFile);
	return S_OK;
}

// -------------------------------------------------------------------------

static WCHAR _g_szSrcPath[MAX_PATH];
static WCHAR _g_szTempPath[MAX_PATH];
static WdSaveFormat _g_lSaveFormat;

// -------------------------------------------------------------------------

class KWordHelpReader : 
	public IKContentSource,
	public IKFilterMediaInit
{
private:
	IKContentSource* m_pSrc;
	WCHAR m_szTempPath[MAX_PATH];
	
public:
	KWordHelpReader() : m_pSrc(NULL)
	{
		m_szTempPath[0] = '\0';
	}
	~KWordHelpReader()
	{
		Close();
	}

public:
	// IKFilterMediaInit
	
	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		if (m_pSrc != NULL)
			return E_ACCESSDENIED;

		HRESULT hr = E_INVALIDARG;
		if (pMedium->tymed == FILTER_TYMED_FILE)
		{
			if (wcscmp(_g_szSrcPath, pMedium->lpszFileName) != 0)
			{
				REPORT("��Ԥ�ڵ��ļ���");
				hr = E_UNEXPECTED;
				goto KS_EXIT;
			}
			wcscpy(m_szTempPath, _g_szTempPath);

			ks_stdptr<IStorage> spStg;
			hr = StgOpenStorage(_g_szTempPath, NULL, STGM_T_READ, 0, 0, &spStg);
			KS_CHECK(hr);
			
			hr = _dr_CreateSourceEx(spStg, &m_pSrc);
			KS_CHECK(hr);
		}
KS_EXIT:
		*_g_szSrcPath = '\0';
		if (FAILED(hr) && *_g_szTempPath)
		{
			DeleteFileW(_g_szTempPath);
			*_g_szTempPath = '\0';
			*m_szTempPath = '\0';
		}
		return hr;
	}
	
public:
	// IKContentSource
	
	/*
	@fn Transfer
	@brief
		��������Դ���������ݣ���һ�����ݽ�����(IKContentHandler)�С�
	@arg [in] pHandler
		�ṩ�����ݽ�������ָ�롣���ڽ��ܴ�������ݡ�
	@return
		���ܵķ���ֵ�У�
		@val S_OK
			����ɹ���
		@val E_ACCESSDENIED
			����û��׼���á�
		@val �κ���������ֵ
			�κ���IKContentHandler���صĴ���ֵ��
	*/
	STDMETHODIMP Transfer(
		IN IKContentHandler* pAcc)
	{
		if (m_pSrc == NULL)
			return E_ACCESSDENIED;

		return m_pSrc->Transfer(pAcc);
	}

	/*
	@fn Close
	@brief
		�رո�����Դ���˺��������Transfer������E_ACCESSDENIED��
	*/
	STDMETHODIMP Close()
	{
		KS_RELEASE(m_pSrc);
		if (*m_szTempPath)
		{
			DeleteFileW(m_szTempPath);
			*m_szTempPath = '\0';
		}
		return S_OK;
	}

	BEGIN_QUERYINTERFACE(IKContentSource)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_CLASS(KWordHelpReader)
	DECLARE_COUNT(KWordHelpReader)
};

// -------------------------------------------------------------------------

#define lFormat_First					(filterKSOXMLText | wdFormatRTF)

EXPORTAPI filterpluginInitialize(IN void* pReserved)
{
	return _dr_Initialize();
}

EXPORTAPI filterpluginTerminate()
{
	return _dr_Terminate();
}

EXPORTAPI filterpluginRegister(IN IKFilterPluginRegister* pReg)
{
	typedef KWordImportFilters::const_iterator iterator;

#pragma prompt("GetImportFilters�����б��ػ�����")
	KWordImportFilters filters;
	_g_WordHelper.GetImportFilters(filters);
	_g_WordHelper.CloseWord();
	for (iterator it = filters.begin(); it != filters.end(); ++it)
	{
		const WordImportFilterInfo& info = (*it).second;
		pReg->Register(
			filterKSOXMLText | (*it).first,
			info.strFormatName,
			FILTER_IMPORT,
			FILTER_TYMED_FILE,
			info.strExt,
			info.strDescription);
	}
	return S_OK;
}

EXPORTAPI filterpluginFormatCorrect(
									IN LPCFILTERMEDIUM pMedium,
									IN long lFormat)
{
	if (pMedium->tymed != FILTER_TYMED_FILE)
		return E_UNEXPECTED;

	if (lFormat_First == lFormat)
	{
		GetTempFileW(_g_szTempPath);
		_g_lSaveFormat = wdFormatInvalid;
		_g_WordHelper.ConvertFile(
			pMedium->lpszFileName,
			_g_szTempPath,
			wdFormatDocument,
			&_g_lSaveFormat
			);
		_g_WordHelper.CloseWord();

		if (_g_lSaveFormat == wdFormatInvalid)
		{
			DeleteFileW(_g_szTempPath);
			*_g_szTempPath = '\0';
			//_g_lSaveFormat = wdFormatInvalid;
		}
		else
		{
			wcscpy(_g_szSrcPath, pMedium->lpszFileName);
		}
	}

	if (
		lFormat == (_g_lSaveFormat | filterKSOXMLText) || 
		(lFormat > wdSaveFormatMax)
		)
		return S_OK;
	else
		return E_UNEXPECTED;
}

EXPORTAPI filterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv)
{
	*ppv = new KCountObject<KWordHelpReader>;
	return S_OK;
}

// -------------------------------------------------------------------------
