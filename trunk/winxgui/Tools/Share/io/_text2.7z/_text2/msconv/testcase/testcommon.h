/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-7 0:08:17
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#include <cppunit/cppunit.h>

// -------------------------------------------------------------------------
// testFilePath

extern UINT g_iTempFileName;
extern WCHAR g_szTempFileName[2][_MAX_PATH];

#define testFilePath(file)	\
	GetSystemIniPath(		\
		g_szTempFileName[++g_iTempFileName&1], L"../testcase/msconv/" L ## file)

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(LPCWSTR) _XGetModuleNameMsConv()
{
	return __X("msconv.dll");
}

#undef _XGetModuleName
#define _XGetModuleName	_XGetModuleNameMsConv

// -------------------------------------------------------------------------

#endif /* __TESTCOMMON_H__ */
