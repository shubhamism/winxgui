/* -------------------------------------------------------------------------
//	�ļ���		��	wordhelp.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-6 22:34:23
//	��������	��	
//
//	$Id: wordhelp.h,v 1.7 2005/01/27 05:15:58 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __WORDHELP_H__
#define __WORDHELP_H__

#ifndef __MSO_API_MSO_ENUM_H__
#include <mso/api/mso_enum.h>
#endif

#ifndef __MSO_API_MSWORD_ENUM_H__
#include <mso/api/msword_enum.h>
#endif

#ifndef __STL_MAP_H__
#include <stl/map.h>
#endif

#ifndef __MSWORD8_H__
#define __MSWORD8_H__
#include "msword8.h"
#endif

#ifndef __MSWORD_H__
#define __MSWORD_H__
#include "msword.h"
#endif

#define	msoEncodingDefault		((MsoEncoding)0)
#define wdFormatInvalid			((WdSaveFormat)-1)
#define wdSaveFormatMax			0x800

// -------------------------------------------------------------------------
// class KWordImportFilters

typedef long WordSaveFormat;

struct WordImportFilterInfo
{
	ks_wstring strFormatName;
	ks_wstring strExt;
	ks_wstring strDescription;
};

class KWordImportFilters : public std::map<WordSaveFormat, WordImportFilterInfo>
{
};

// -------------------------------------------------------------------------
// class KWordHelper

class KWordHelper
{
private:
	BOOL m_fHasWord; // �Ƿ�װOFFICE
	CLSID m_clsid; // ����װ��OFFICE������Word.Application��CLSID��
	_Application m_app;

	KWordHelper(const KWordHelper& rhs);
	void operator=(const KWordHelper& rhs);

public:
	KWordHelper()
	{
		// ͨ��ProgIDȡ��CLSID���Դ��ж�Word�Ƿ�װ��
		HRESULT hr = ::CLSIDFromProgID(L"Word.Application", &m_clsid);
		m_fHasWord = SUCCEEDED(hr);
	}
	~KWordHelper()
	{
		if (m_app)
			CloseWord();
	}

	STDMETHODIMP_(BOOL) IsWordInstalled() const
	{
		return m_fHasWord;
	}

	STDMETHODIMP_(void) RunWord()
	{
		ASSERT( IsWordInstalled() );
		if (m_app == NULL)
		{
			if (!m_app.CreateDispatch(m_clsid)) //����ˣ���װ��wordΪ�β���������
				throw (E_UNEXPECTED);

			m_app.SetVisible(FALSE);
		}
		ASSERT(m_app);
	}

	STDMETHODIMP_(void) CloseWord()
	{
		if (m_app)
		{
			//׼������_Application::Quit�����ˣ���Ҫ����3��������
			//���ǣ��������ʹ��CComVariant������һ��ģ���ࡣ
			//�ڶ����ʱ��ֱ�ӵ��ô������Ĺ��캯������VARIANTʹ�ü򵥶��˰�
			CComVariant SaveChanges(false),OriginalFormat,RouteDocument;
			//ʹ�� CComVariant �Ĳ��������Ĺ��캯����Ĭ�Ͼ���ʹ��VT_EMPTY������Ϊ������
			//���⣬����CComVariant,�㻹����ʹ��COleVariant��_variant_t�����Ҹ�����ϲ��ǰ��
			m_app.Quit(&SaveChanges,&OriginalFormat,&RouteDocument);
			m_app.ReleaseDispatch();
		}
	}

	STDMETHODIMP_(int) GetVersion()
	{
		if (!m_fHasWord)
			return 0;
		
		RunWord();
		return atoi( m_app.GetVersion() );
	}

	STDMETHODIMP GetImportFilters(KWordImportFilters& filters)
	{
		if (!m_fHasWord)
			return E_ACCESSDENIED;

		try
		{
			RunWord();
			
			int nVer = atoi( m_app.GetVersion() );

			WordImportFilterInfo info;
			
			info.strFormatName = __X("RTF");
			info.strExt = __X("*.rtf");
			info.strDescription = __X("RTF �ļ�");
			filters[wdFormatRTF] = info;

			if (nVer >= 9) // office 2000
			{
				info.strFormatName = __X("HTML");
				info.strExt = __X("*.htm; *.html");
				info.strDescription = __X("HTML �ļ�");
				filters[wdFormatHTML] = info;
				
				if (nVer >= 10) // office XP
				{
					info.strFormatName = __X("");
					info.strExt = __X("*.mht; *.mhtml");
					info.strDescription = __X("�����ļ���ҳ");
					filters[wdFormatWebArchive] = info;

					if (nVer >= 11) // office 2003
					{
						info.strFormatName = __X("WordML");
						info.strExt = __X("*.xml");
						info.strDescription = __X("WordML �ļ�");
						filters[wdFormatXML] = info;
					}
				}
			}

			FileConverters converters = m_app.GetFileConverters();
			long nCount = converters.GetCount();
			for (long i = 1; i <= nCount; ++i)
			{
				CComVariant index(i);
				FileConverter conv = converters.Item(&index);
				if (conv.GetCanOpen())
				{
					CString strExt = conv.GetExtensions();
					if (strExt == "*") // ����Ҫ
						continue;
					long lSaveFormat = conv.GetCanSave() ? 
						conv.GetSaveFormat() : (wdSaveFormatMax+i);
					info.strFormatName = conv.GetClassName();
					info.strExt = "*." + strExt;
					for (;;)
					{
						ks_wstring::size_type pos = info.strExt.find_first_of(' ');
						if (pos == ks_wstring::npos)
							break;
						info.strExt.replace(pos, 1, __X(";*."));
					}
					info.strDescription = conv.GetFormatName();
					filters[lSaveFormat] = info;
				}
				conv.ReleaseDispatch();
			}
			converters.ReleaseDispatch();
		}
		catch (...)
		{
		}		
		return S_OK;
	}

	STDMETHODIMP SetDefaultTextEncoding(
		IN MsoEncoding encoding)
	{
		if (!m_fHasWord)
			return E_ACCESSDENIED;
		
		try
		{
			RunWord();
			
			Options options = m_app.GetOptions();
			options.SetDefaultTextEncoding(encoding);
			options.ReleaseDispatch();
		}
		catch (...)
		{
			return E_FAIL;
		}
		return S_OK;
	}
	
	STDMETHODIMP ConvertFile(
		IN LPCWSTR SrcFile,
		IN LPCWSTR DestFile,
		IN WdSaveFormat DestSaveFormat = wdFormatDocument, // ����ΪWord�ĵ�
		OUT WdSaveFormat* SrcSaveFormat = NULL // ����Դ�ļ����ļ���ʽ
		)
	{
		ASSERT(SrcFile && DestFile);

		HRESULT hr = S_OK;
		if (!m_fHasWord)
			return E_ACCESSDENIED;

		try
		{
			RunWord();
			
			const WCHAR szNull[] = { 0 };
			CComVariant Null(szNull);
			CComVariant Zero(0);
			CComVariant True(true);
			CComVariant False(false);
			
			//ͨ��WORD�����֪��������Ҫʹ��Documents,�������Ƕ���һ������app��ȡ��
			Documents docs = m_app.GetDocuments();

			_Document doc;
			try
			{
				//���ļ�
				CComVariant FilePath(SrcFile);

				int nVer = atoi( m_app.GetVersion() );
				if (nVer >= 9) // office 2000
				{
					//CComVariant theEncoding(encoding);
					//CComVariant* Encoding = (encoding ? &theEncoding : &False);
					doc = docs.Open2000(
						&FilePath,
						&False,		// ConfirmConversions
						&False,		// ReadOnly
						&False,		// AddToRecentFiles
						&Null,		// PasswordDocument
						&Null,		// PasswordTemplate
						&False,		// Revert
						&Null,		// WritePasswordDocument
						&Null,		// WritePasswordTemplate
						&Zero,		// Format, see enum WdOpenFormat
						&Zero,		// Encoding
						&False		// Visible
						);
				}
				else
				{
					doc = docs.Open(
						&FilePath,
						&False,		// ConfirmConversions
						&False,		// ReadOnly
						&False,		// AddToRecentFiles
						&Null,		// PasswordDocument
						&Null,		// PasswordTemplate
						&False,		// Revert
						&Null,		// WritePasswordDocument
						&Null,		// WritePasswordTemplate
						&Zero		// Format, see enum WdOpenFormat
						);
				}
			}
			catch (COleDispatchException* e)
			{
				TRACEA("---> Open Exception: %s\n", (LPCSTR)e->m_strDescription);

				if (e->m_scError != 0x800a1436) //�ļ�������
					doc = m_app.GetActiveDocument();

				e->Delete();
			}

			if (SrcSaveFormat)
				*SrcSaveFormat = (WdSaveFormat)(doc ? doc.GetSaveFormat() : wdFormatInvalid);

			try
			{
				CComVariant FilePath(DestFile);
				CComVariant FileFormat(DestSaveFormat);
				doc.SaveAs(
					&FilePath,
					&FileFormat,
					&False,		// LockComments
					&Null,		// Password
					&False,		// AddToRecentFiles
					&Null,		// WritePassword,
					&False,		// ReadOnlyRecommended,
					&False,		// EmbedTrueTypeFonts,
					&False,		// SaveNativePictureFormat,
					&False,		// SaveFormsData,
					&False		// SaveAsAOCELetter
					);
			}
			catch (COleDispatchException* e)
			{
				TRACEA("---> SaveAs Exception: %s\n", (LPCSTR)e->m_strDescription);
				hr = e->m_scError; // ���ܳ���Ŀ���ļ��Ѿ����򿪵����
				e->Delete();
			}

			try
			{
				CComVariant SaveChanges(false),OriginalFormat,RouteDocument;
				doc.Close(&SaveChanges, &OriginalFormat, &RouteDocument);
			}
			catch (COleDispatchException* e)
			{
				TRACEA("---> Close Exception: %s\n", (LPCSTR)e->m_strDescription);
			}

			doc.ReleaseDispatch();
			docs.ReleaseDispatch();
		}
		catch (...)
		{
			return E_ABORT;
		}
		ASSERT_OK(hr);
		return hr;
	}
};

extern KWordHelper _g_WordHelper;

// -------------------------------------------------------------------------
// $Log: wordhelp.h,v $
// Revision 1.7  2005/01/27 05:15:58  xushiwei
// ֧��html2text�����ҿ������ñ����text�ı��롣
//
// Revision 1.6  2004/12/24 05:37:53  xushiwei
// �޸�����bug��������batch word2rtf������
//

#endif /* __WORDHELP_H__ */
