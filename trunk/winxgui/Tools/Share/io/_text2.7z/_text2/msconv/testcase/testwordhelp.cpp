/* -------------------------------------------------------------------------
//	�ļ���		��	testwordhelp.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-7 0:08:07
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <wordhelp.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestWordHelp : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestWordHelp);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
		KWordHelper word;
		
		ASSERT(word.IsWordInstalled());

		word.ConvertFile(
			testFilePath("basic.rtf"),
			testFilePath("_basic_.doc")
			);
	}
};

//CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestWordHelp);

// -------------------------------------------------------------------------
