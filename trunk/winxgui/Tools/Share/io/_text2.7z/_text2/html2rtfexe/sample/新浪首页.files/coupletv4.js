var MSIE=navigator.userAgent.indexOf("MSIE");
var OPER=navigator.userAgent.indexOf("Opera");

function adshowCouplet(){
	if((document.body.offsetWidth>800) && MSIE!=-1 && OPER==-1 && ifCouplet){	
		document.getElementById('couplet_left').style.visibility='visible';
		document.getElementById('couplet_right').style.visibility='visible';	  
		document.getElementById('couplet_left').style.top=100;
		document.getElementById('couplet_left').style.left=5;
		document.getElementById('couplet_right').style.top=100;
		document.getElementById('couplet_right').style.right=5;
	}else{
		document.getElementById('couplet_left').style.visibility='hidden';
		document.getElementById('couplet_right').style.visibility='hidden';
	}
	setTimeout("adshowCouplet();",50)
}