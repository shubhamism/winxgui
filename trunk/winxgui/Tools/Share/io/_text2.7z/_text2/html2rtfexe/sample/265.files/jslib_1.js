var w3c=(document.getElementById)? true:false;
var agt=navigator.userAgent.toLowerCase();
var ie = ((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1) && (agt.indexOf("omniweb") == -1));
var ie5=(w3c && ie)? true : false;
var ns6=(w3c && (navigator.appName=="Netscape"))? true: false;
var op8=(navigator.userAgent.toLowerCase().indexOf("opera")==-1)? false:true;

/* General function*/
function Ob(o){
 var o=document.getElementById(o)?document.getElementById(o):o;
 return o;
}
function Hd(o){
 Ob(o).className="hidden";
}
function Sw(o){
 Ob(o).className="show";
}
function ExCls(o,a,b){
 Ob(o).className=Ob(o).className==a?b:a;
}


function SetCookie(name,value){
     var argv=SetCookie.arguments;
     var argc=SetCookie.arguments.length;
     var expires=(2<argc)?argv[2]:null;
     var path=(3<argc)?argv[3]:null;
     var domain=(4<argc)?argv[4]:null;
     var secure=(5<argc)?argv[5]:false;
     document.cookie=name+"="+escape(value)+((expires==null)?"":("; expires="+expires.toGMTString()))+((path==null)?"":("; path="+path))+((domain==null)?"":("; domain="+domain))+((secure==true)?"; secure":"");
} 

function GetCookie(Name) {
 var search = Name + "=";
 var returnvalue = "";
 if (document.cookie.length > 0) {
  offset = document.cookie.indexOf(search);
  if (offset != -1) {      
   offset += search.length;
   end = document.cookie.indexOf(";", offset);                        
   if (end == -1)
   end = document.cookie.length;
   returnvalue=unescape(document.cookie.substring(offset,end));
  }
 }
 return returnvalue;
}

function GetSubCookie(Name, CookieValue) {
 var search = Name + "=";
 var returnvalue = "";
 if (CookieValue.length > 0) {
  offset = CookieValue.indexOf(search);
  if (offset != -1) {      
   offset += search.length;
   end = CookieValue.indexOf("&", offset);                        
   if (end == -1)
   end = CookieValue.length;
   returnvalue=unescape(CookieValue.substring(offset,end));
  }
 }
 return returnvalue;
}

/*Chose Skin*/
function SavSkin(s,n){
 Hd("SkinCtrl");
 n==1?Ob("ActSkin").href="/css/skin_"+s+"_1.css":Ob("Cn").className="Cn"+s;
 //alert("aa");
 var expdate=new Date();
 expdate.setTime(expdate.getTime()+(24*60*60*1000*30));
 SetCookie("Skin265_"+n,s,expdate,"/",null,false);
}

function GetSkin(){
 /*if (document.body.className=="SubPage") {
  var sName=GetCookie("Skin265_2")?GetCookie("Skin265_2"):"Cn1";
  Ob("Cn").className=sName;
  if (Ob("Cn").className=="Cn2") {
   Ob("BtnCloseDir")
  }
 }*/
}

function GetCSS(){
 var sSkin=GetCookie("Skin265_1")?GetCookie("Skin265_1"):"2";
  document.write ("<link id=\"ActSkin\" type=\"text/css\" rel=\"stylesheet\" href=\"/css/skin_"+sSkin+"_1.css\" />");
}
function ExChgDir(){
 ExCls('Cn','Cn3','Cn1');
 Ob("BtnCloseDir").innerHTML=Ob("Cn").className=="Cn3"?"��Ŀ¼":"�ر�Ŀ¼";
 //alert(Ob("Cn").className)
 //SavSkin(Ob("Cn").className,2);
 //alert(GetCookie("Skin265_2"));
}

function MySkin(n){
 var sHtml="";
 if (n!=1) {
  //alert(GetCookie("Skin265_2"));
  sHtml="<a id=\"BtnCloseDir\" href=\"javascript:void(0)\" onclick=\"ExChgDir();\">�ر�Ŀ¼</a>&nbsp;|&nbsp;"
 sHtml+="<a href=\"javascript:ShowSkin();\">���Ʒ��</a>&nbsp;|&nbsp;";
 sHtml+="<a href=\"http://my.265.com/hd/topic_121_11925_1.htm\" target=\"_blank\">������·</a>";
 } else {
 sHtml="<a href=\"http://my.265.com/hd/topic_121_11925_1.htm\" target=\"_blank\">������·</a>&nbsp;|&nbsp;";
 sHtml+="<a href=\"javascript:ShowSkin();\">���Ʒ��</a>";
 }
 sHtml="<p id=\"OrdSkin\">"+sHtml+"</p>";
 document.write (sHtml);
}

function ShowSkin(){
 if (Ob("SkinCtrl").className=="hidden") {
 var sHtml="<div class=\"OpH\">����ҳ����</div><div class=\"OpB\"><ul id=\"SkinTyp1\"><li id=\"MySkin1_2\"><img class=\"s2\" src=\"/css/s.gif\" alt=\"skin\" />&nbsp;<a href=\"javascript:SavSkin('2',1);\">��ɫ����</a></li><li id=\"MySkin1_3\"><img class=\"s3\" src=\"/css/s.gif\" alt=\"skin\" />&nbsp;<a href=\"javascript:SavSkin('3',1);\">��ɫ����</a></li></ul><ul id=\"SkinTyp2\"><li><a href=\"javascript:void(0)\" id=\"MySkin2_1\" title=\"��������\" onclick=\"SavSkin('1',2);\"><img src=\"/css/img0/p_lt.gif\" alt=\"��������\" /></a><a href=\"javascript:void(0)\" id=\"MySkin2_3\" title=\"���ز���\" onclick=\"SavSkin('3',2);\"><img src=\"/css/img0/p_no.gif\" alt=\"���ز���\" /></a><a href=\"javascript:void(0)\" id=\"MySkin2_2\" title=\"��������\" onclick=\"SavSkin('2',2);\"><img src=\"/css/img0/p_rt.gif\" alt=\"��������\" /></a></li></ul></div><div class=\"OpF\"><a href=\"javascript:void(0)\" onclick=\"Hd('SkinCtrl');\" title=\"����ر�\">���رա�</a></div>";
 Ob("SkinCtrl").innerHTML=sHtml;
 Sw("SkinCtrl");
 var nLt=Ob("Wp2").offsetLeft;
 if(document.body.className=="SubPage") {
 nLt=Ob("Wp2").offsetLeft;
 } else {
 nLt=Ob("MCol").offsetLeft+Ob("MCol").offsetWidth-Ob("SkinCtrl").offsetWidth-2;
 nLt=ie?nLt:nLt+4;
 }
Ob("SkinCtrl").style.left=nLt+"px";
Ob("MySkin1_"+GetCookie("Skin265_1")).className="chosed";
Ob("MySkin2_"+GetCookie("Skin265_2")).className="chosed";
 } else {
  Hd("SkinCtrl");
 }
}

function ExRtCol(){
 ExCls("Wp","Big","");
 ExCls("RtCol","hidden","");
 ExCls("BtnShow1","hidden","");
}

var CurrOpObj=null;
function ExChgFam(o, curo){
 Ob("Famous_area").style.display="none";
 Ob("FrmUrl1").style.display="none";
 Ob(curo).style.display="";
 o.className="cur"; 
 if (CurrOpObj && CurrOpObj != o)
  CurrOpObj.className="";
  CurrOpObj =o;
}

function HitTree(e){
 var tag = ie ? e.srcElement : e.target; ExCls(tag.parentNode,"open","close");
}

function SetEvt(o,a,b){
 ie?o.attachEvent("on"+a,b):o.addEventListener(a,b, false);
}

function CNLTree(id,ClsOpen,ClsClose,ClsChild){
 this.id=id;
 this.ClassOpen=ClsOpen || "open";
 this.ClassClose=ClsClose || "close";
 this.ClassChild=ClsChild || "child";
 this.AddEvt = function () {
  var arrObj=Ob(this.id).getElementsByTagName("img");
  for (var i=0;i<arrObj.length; i++) {
   arrObj[i].className=="s"?SetEvt(arrObj[i],"click",HitTree):"";
  }
 }
}

var Keys=new Array();
Keys[0]=new Array();
Keys[0][0]="��Ϸ";
Keys[0][1]="����";
Keys[0][2]="��������";
Keys[0][3]="����";
Keys[0][4]="��Ʊ";
Keys[0][5]="�ʻ�";
Keys[1]=new Array();
Keys[1][0]="����ʻ�";
Keys[1][1]="����ɽˮ";
Keys[1][2]="��ֽ";
Keys[1][3]="����";
Keys[1][4]="��ģ";
Keys[1][5]="��ɴ";
Keys[2]=new Array();
Keys[2][0]="����";
Keys[2][1]="����";
Keys[2][2]="��������";
Keys[2][3]="���˽�";
Keys[2][4]="�ͼ�";
Keys[2][5]="������";
Keys[3]=new Array();
Keys[3][0]="ҹ��";
Keys[3][1]="����";
Keys[3][2]="��įɳ����";
Keys[3][3]="�ʼ�";
Keys[3][4]="���볤��";
Keys[3][5]="���ò���";
Keys[4]=new Array();
Keys[4][0]="��ˮ";
Keys[4][1]="�������";
Keys[4][2]="�ֻ�";
Keys[4][3]="����";
Keys[4][4]="����ͷ";
Keys[4][5]="����";

var KNo=Math.floor(6*Math.random());
function s4(){
 var v=Ob("Kaa").value
 if(Ob("a0").checked)
 window.open("http://www.yok.com/go.php?NO=9&Key="+v,"0");
 if(Ob("a1").checked)
 window.open("http://www.yok.com/go.php?NO=8&Key="+v,"1");
 if(Ob("a2").checked)
 window.open("http://www.baidu.com/baidu?tn=265com&word="+v,"2");
 if(Ob("a3").checked)
 window.open("http://www.yahoo.com.cn/search?source=yisou_union_265&pid=200523_1006&p="+v,"3");
 if(Ob("a4").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=10","4");
 if(Ob("a5").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=11","5");
 if(Ob("a6").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=14","6");
 if(Ob("a7").checked)
 window.open("http://cb.kingsoft.com/search?t=word&lang=gb2312&s="+v,"7");
 if(Ob("a8").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=35","8");
 if(Ob("a9").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=26","9");
 if(Ob("a10").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=158","10");
 if(Ob("a11").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=174","11");
 if(Ob("a12").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=39","12");
 if(Ob("a13").checked) 
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=49","13");
 if(Ob("a14").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=24","14");
 if(Ob("a15").checked)
 window.open("http://www.yok.com/go.php?Key="+v+"&NO=152","15");
 return false;
}
function gt(f){
 var t;
 var u;
 if(f.a0 != undefined){
  u = 'Y:';
  t = f.k.value;
  if(f.a0.checked==true){u+='0;';}
  if(f.a1.checked==true){u+='1;';}
  if(f.a2.checked==true){u+='2;';}
  if(f.a3.checked==true){u+='3;';}
  if(f.a4.checked==true){u+='4;';}
  if(f.a5.checked==true){u+='5;';}
  if(f.a6.checked==true){u+='6;';}
  if(f.a7.checked==true){u+='7;';}
  if(f.a8.checked==true){u+='8;';}
  if(f.a9.checked==true){u+='9;';}
  if(f.a10.checked==true){u+='10;';}
  if(f.a11.checked==true){u+='11;';}
  if(f.a12.checked==true){u+='12;';}
  if(f.a13.checked==true){u+='13;';}
  if(f.a14.checked==true){u+='14;';}
  if(f.a15.checked==true){u+='15;';}
 }
 else{
  t = f.Ka.value;
  u = 'G';
 }
 try{
  new Image().src = "http://statis.265.com/url?a=S&u="+u+"&t="+t;
 }catch(ex){}
 if(Ob("Ka").value == ""){
  Ob("ch").value = "noprefill";
 } else {
  Ob("ch").value = "prefill";
 }
}
function tracking(e){
 e = e ? e : window.event;
 var s = e.srcElement ? e.srcElement : e.target;
 var a = s.tagName;
 var u = s.href;
 var t = s.innerText ? s.innerText : s.textContent;
 if(a == "A" || a == "IMG"){
  if(a == "IMG"){
   t = s.href || s.src;
   u = s.parentElement || s.parentNode;
  }
  try{
   new Image().src = "http://statis.265.com/url?a="+a+"&u="+escape(u)+"&t="+t;
  }catch(ex){}
 }
 return true;
}

function LTrim(str){
var whitespace = new String(" \t\n\r");
var s = new String(str);
if (whitespace.indexOf(s.charAt(0)) != -1){
var j=0, i = s.length;
while (j < i && whitespace.indexOf(s.charAt(j)) != -1){
	j++;
}
s = s.substring(j, i);
}
return s;
}

function RTrim(str){
var whitespace = new String(" \t\n\r");
var s = new String(str);
if (whitespace.indexOf(s.charAt(s.length-1)) != -1){
var i = s.length - 1;
while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1){
i--;
}
s = s.substring(0, i+1);
}
return s;
}

//E78���JS
var c= '500x30_265';
var f = 'nounion';
var newWindow = null;
var querystr = location.href;
function ADsend(id,type,placeid){
var pid = RTrim(LTrim(id));
var newpid = parseInt(pid)-parseInt(10000);
var path = parseInt(newpid/1000);
open_url1 = "http://channel.e78.com/_unpage2.php?c="+c+"&f="+f;
window.open(open_url1,'home','width=820 height=620,top=50,left=50,toolbar=yes,menubar=yes, scrollbars=yes, resizable=yes,location=yes, status=yes');
open_url = "http://count.e78.com/page/WD_9588/"+path+"/sendring"+pid+".htm?p="+id+"&t="+type+"&c="+c+"&f="+f+"&u="+querystr;
window.open(open_url,'open','width=460 height=490');
}
function ADsend2(id,type,placeid){
var pid = RTrim(LTrim(id));
var newpid = parseInt(pid)-parseInt(10000);
var path = parseInt(newpid/1000);
open_url1 = "http://channel.e78.com/_unpage2.php?c="+c+"&f="+f;
window.open(open_url1,'home','width=820 height=620,top=50,left=50,toolbar=yes,menubar=yes, scrollbars=yes, resizable=yes,location=yes, status=yes');
open_url = "http://send.e78.com:8080/send/param.php?pid="+pid+"&ptype="+type+"&c="+c+"&f="+f+"&u="+querystr;
window.open(open_url,'','width=460 height=490');
}