var popDivs='<DIV id=fifa2006pop style="Z-INDEX: 99999; FILTER: alpha(opacity=100); LEFT: 0px; VISIBILITY: hidden; WIDTH: 220px;POSITION: absolute; HEIGHT: 120px;top:0px;">';
popDivs += '<style>';
popDivs += '<!--';
popDivs += '.f12_ffff {font-size:12px;line-height:20px;color:#fff;}';
popDivs += '.f12_ffff a:link,.f12_ffff a:visited{color:#fff;text-decoration:none;}';
popDivs += '.f12_ffff a:hover {color:#fff;text-decoration:underline;}';
popDivs += ' -->';
popDivs += '</style>';
popDivs += '<table width=220 height=120 border=0 cellpadding=0 cellspacing=0 background=http://2006.sohu.com/2006/images/bg.gif>';
popDivs += '<tr>';
popDivs += '<td width=60>';
popDivs += '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="60" height="120">';
popDivs += '<param name="movie" value="http://2006.sohu.com/2006/images/60120.swf">';
popDivs += '<param name=quality value=high>';
popDivs += '<param name="Wmode" value="Transparent">';
popDivs += '<embed src="http://2006.sohu.com/2006/images/60120.swf" width="60" height="120" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" wmode="Transparent"></embed>';
popDivs += '</object></td>';
popDivs += '<td width=160>';
popDivs += '<table width=160 height=30 border=0 cellpadding=0 cellspacing=0>';
popDivs += '<tr><td><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="62" height="30">';
popDivs += '<param name="movie" value="http://2006.sohu.com/2006/images/font.swf">';
popDivs += '<param name=quality value=high>';
popDivs += '<param name="Wmode" value="Transparent">';
popDivs += '<embed src="http://2006.sohu.com/2006/images/font.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="62" height="30"></embed>';
popDivs += '</object></td><td><a href=http://61.135.131.68/1e3e229abd0d68a32abf28b4cedb21ed.php target=_blank><img src=http://images.sohu.com/ccc.gif width=74 height=20 border=0></a><br></td><td width=16 align=center valign=top><a style="cursor:hand;" onclick="window.fifa2006pop.style.display=\'none\';"><img src="http://2006.sohu.com/2006/images/close.gif" width="11" height="10" border=0 vspace="5"></a></td></tr>';
popDivs += '</table>';
popDivs += '<table width=150 height=90 border=0 cellpadding=0 cellspacing=0>';
popDivs += '<tr><td valign=top align=left>';
popDivs += '<iframe marginwidth=0 marginheight=0  frameborder=0 scrolling=no  width=140 height=70 src="http://2006.sohu.com//fifa2006/pop.shtml" allowtransparency="true"></iframe>';
popDivs += '</td></tr></table></td></tr></table></DIV>';
function getCookieVal (offset)
{
    var endstr = document.cookie.indexOf (";", offset);
    if (endstr == -1)
      endstr = document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}

function GetCookie (name)   {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    while (i < clen) {
      var j = i + alen;
      if (document.cookie.substring(i, j) == arg)
        return getCookieVal (j);
      i = document.cookie.indexOf(" ", i) + 1;
      if (i == 0) break;
    }
    return null;
}

function SetCookie (name, value)
{
    var argv = SetCookie.arguments;
    var argc = SetCookie.arguments.length;
    var expires = (argc > 2) ? argv[2] : null;
    var path = (argc > 3) ? argv[3] : "/";
    var domain = (argc > 4) ? argv[4] : ".sohu.com";
    var secure = (argc > 5) ? argv[5] : false;
    document.cookie = name + "=" + escape (value) +((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +((path == null) ? "" : ("; path=" + path)) +((domain == null) ? "" : ("; domain=" + domain)) +((secure == true) ? "; secure" : "");
}

function setLastlastVisitCookie (count)
{
    var rightNow = new Date();
    var expdate = new Date();
    expdate.setHours(23);
    expdate.setMinutes(59);
    expdate.setSeconds(59);
    SetCookie ("fifaLastVisitOneDay",count, expdate , "/");
}
function ResetCookie()
{
    SetCookie("fifaLastVisitOneDay", 0, null, "/");
}


function getMsg()
{
	try{
	divTop = parseInt(fifa2006pop.style.top,10)
	divLeft = parseInt(fifa2006pop.style.left,10)
	divHeight = parseInt(fifa2006pop.offsetHeight,10)
	divWidth = parseInt(fifa2006pop.offsetWidth,10)
	docWidth = document.body.clientWidth;
	docHeight = document.body.clientHeight;
	fifa2006pop.style.top = parseInt(document.body.scrollTop,10) + docHeight + 10;//  divHeight
	fifa2006pop.style.left = parseInt(document.body.scrollLeft,10) + docWidth - divWidth
	fifa2006pop.style.visibility="visible"
	objTimer = window.setInterval("moveDiv()",1)
	}
	catch(e){
	}
}

function resizeDiv()
	{
	timecounter+=1;
	if((timecounter) >= showtimeout)
	{
		if(objTimer) window.clearInterval(objTimer)
		objTimer = window.setInterval("hiddenDiv()",1);
	}
	try{
	divHeight = parseInt(fifa2006pop.offsetHeight,10)
	divWidth = parseInt(fifa2006pop.offsetWidth,10)
	docWidth = document.body.clientWidth;
	docHeight = document.body.clientHeight;
	fifa2006pop.style.top = docHeight - divHeight + parseInt(document.body.scrollTop,10)
	fifa2006pop.style.left = docWidth - divWidth + parseInt(document.body.scrollLeft,10)
	}
	catch(e){}
}

function moveDiv()
{
	try
	{
	if(parseInt(fifa2006pop.style.top,10) <= (docHeight - divHeight + parseInt(document.body.scrollTop,10)))
	{
			if(objTimer) window.clearInterval(objTimer)
			timecounter=0;
			resizeDiv();
			objTimer = window.setInterval("resizeDiv()",1000)
		}else{
			divTop = parseInt(fifa2006pop.style.top,10)
			fifa2006pop.style.top = divTop - 5;
		}
	}
	catch(e){
	}
}

function hiddenDiv()
{
	
	if(fifa2006pop.filters){
		if(fifa2006pop.filters.alpha.Opacity > 0)
		{
			fifa2006pop.filters.alpha.Opacity -= 1;
		}
		else
		{
			closeDiv();
		}
	}else{
		fifa2006pop_Opactiy_f--;
		if(fifa2006pop_Opactiy_f<=0){
			closeDiv();	
		}
	}
}

function closeDiv()
{
	fifa2006pop.style.visibility="hidden";
	if(objTimer) window.clearInterval(objTimer)
	if(fifa2006pop.filters){
		fifa2006pop.filters.alpha.Opacity = fifa2006pop_Opactiy ;
	}else{
		fifa2006pop_Opacity_f = fifa2006pop_Opactiy;
	}
}

var docUrl = document.location.href;
var isSohu = docUrl.indexOf("www.sohu.com")>=0;
var divTop,divLeft,divWidth,divHeight,docHeight,docWidth,objTimer,xmsTimer,timecounter = 0;
var showtimeout = 30;
var req = null;
var fifa2006pop = null;
var fifa2006pop_Opactiy = 90;
var fifa2006pop_Opactiy_f = 90;
var localTime =0;
document.write(popDivs);
fifa2006pop = document.getElementById("fifa2006pop");
var bVisitedToday = false;  
var lastVisit = GetCookie("fifaLastVisitOneDay");   
if (lastVisit != null) 
{
	lastVisit = parseInt(lastVisit);
	if(lastVisit<2){
		bVisitedToday = false;
	}else{
		bVisitedToday = true;
	}
}else{
	lastVisit = 0;	
}
if(fifa2006pop.filters){
fifa2006pop_Opacity = fifa2006pop.filters.alpha.Opacity;
}
if(bVisitedToday == false)
{
	lastVisit++;
   	setLastlastVisitCookie(lastVisit);
	window.onresize = resizeDiv;
	window.onerror = function(e){}
        window.onload =getMsg;
}
