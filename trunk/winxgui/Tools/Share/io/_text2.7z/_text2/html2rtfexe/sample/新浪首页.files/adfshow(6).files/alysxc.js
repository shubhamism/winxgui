function alysxc(u,w,h,p,d,c,b)
{
	if (arguments.length==6)
	{//flash
		var o=document.getElementById(c);
		o.innerHTML="<div style='POSITION:relative;Z-INDEX:1;width:"+w+"px; height: "+h+"px'><DIV style='POSITION:absolute;Z-INDEX:2;width:"+w+"px; height: "+h+"px'><OBJECT classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://active.macromedia.com/flash2/cabs/swflash.cab#version=4,0,0,0' WIDTH="+ w+" HEIGHT="+h+"> <PARAM NAME=movie VALUE='"+u+"'><param name='wmode' value='transparent'><PARAM NAME=quality VALUE=high><EMBED src='"+u+"' WIDTH="+ w+" HEIGHT="+h+" TYPE='application/x-shockwave-flash'></EMBED></OBJECT></div><div style='POSITION:absolute;left:0;top:0;Z-INDEX:3;width:"+w+"px; height: "+h+"px'><OBJECT classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://active.macromedia.com/flash2/cabs/swflash.cab#version=4,0,0,0' ID=button"+d+" WIDTH="+w+" HEIGHT="+h+"><PARAM NAME=movie VALUE='"+p+"/main/adfshow?local=blank.swf'><param name='wmode' value='transparent'><PARAM NAME=quality VALUE=high><EMBED src='"+p+"/main/adfshow?local=blank.swf' quality=high WIDTH="+w+" HEIGHT="+h+" TYPE='application/x-shockwave-flash' name=button"+d+"></EMBED></OBJECT></div></div>";
		return c;
	}else
	{
		var o=document.getElementById(d);
		p=(!p)?'Transparent':'Opaque';
		o.innerHTML='<div style="POSITION:relative;Z-INDEX:1;width:'+w+'px;height:'+h+'px"><DIV style="POSITION:absolute;Z-INDEX:2;width:'+w+'px;height:'+h+'px"><OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://active.macromedia.com/flash2/cabs/swflash.cab#version=4,0,0,0" WIDTH="'+w+'" HEIGHT="'+h+'"><PARAM NAME="movie" VALUE="'+u+'"><PARAM NAME="wmode" VALUE="'+p+'"><EMBED src="'+u+'" WIDTH="'+w+'" HEIGHT="'+h+'" WMODE="'+p+'" TYPE="application/x-shockwave-flash"></EMBED></OBJECT></div><div style="POSITION:absolute;left:0;top:0;Z-INDEX:3;width:'+w+'px;height:'+h+'px"><OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://active.macromedia.com/flash2/cabs/swflash.cab#version=4,0,0,0" ID="button'+b+'" WIDTH="'+w+'" HEIGHT="'+h+'"><PARAM NAME="movie" VALUE="'+c+'/main/adfshow?local=blank.swf"><PARAM NAME="Wmode" VALUE="Transparent"><EMBED src="'+c+'/main/adfshow?local=blank.swf" WMODE="Transparent" WIDTH="'+w+'" HEIGHT="'+h+'" TYPE="application/x-shockwave-flash" name="button'+b+'"></EMBED></OBJECT></div></div>';
		return d;
	}
}
