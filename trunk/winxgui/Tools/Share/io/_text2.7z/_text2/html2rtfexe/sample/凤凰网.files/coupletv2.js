document.ns = navigator.appName == "Microsoft Internet Explorer"
function doCouplet(){
	if((document.body.offsetWidth>800) && document.ns){	
	couplet_left.style.visibility='visible';
	couplet_right.style.visibility='visible';	  
	  couplet_left.style.top=450;
	  couplet_left.style.left=10;
	  couplet_right.style.top=450;
	  couplet_right.style.right=10;
	}else{
	couplet_left.style.visibility='hidden';
	couplet_right.style.visibility='hidden';}
}