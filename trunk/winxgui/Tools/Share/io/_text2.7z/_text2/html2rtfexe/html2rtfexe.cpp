// html2rtfexe.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <mso/io/html/reader/serve.h>
#include "htm/htm2utf8encode.h"
#include "htmtidy.h"

#ifdef main
#undef main
#endif

int testHtml2Doc(int argc, char* argv[])
{
	if(argc < 2)
		return -1;	
	HMODULE hmod = LoadLibrary("html2rtf.dll");
	if(!hmod)
		return -2;
	Html2DocTypePr proc = (Html2DocTypePr)GetProcAddress(hmod, "Html2Doc");
	if(!proc)
		return -3;
	proc(argc, argv);
	return 0;
}

int testTidyFile(LPCSTR szSrcFile, LPCSTR szOutFile)
{	
	ks_stdptr<IStream> src;
	USES_CONVERSION;
	HRESULT hr = CreateStreamOnFile(A2W(szSrcFile), STGM_READ|STGM_SHARE_DENY_NONE, &src);
	if(FAILED(hr))
		return -1;
	TIDY_FILE arg;
	arg.DeleErrFile = yes;
	return TidyFile(src, szOutFile, -1, &arg, szSrcFile, NULL);
}

int testHtm2Utf8(LPCSTR szSrcFile, LPCSTR szOutFile)
{
	USES_CONVERSION;	
	ULONG cbWrite;
	Htm2Utf8Encode(A2W(szSrcFile), A2W(szOutFile), &cbWrite, NULL);
	return 0;
}

int main(int argc, char* argv[])
{	
	if(argc < 3)
		return -1;
	ks_stdptr<IStream> src;
	USES_CONVERSION;
	HGLOBAL hgbl;
	ULONG cbWritten;
	Htm2Utf8Encode(A2W(argv[1]), &hgbl, &cbWritten, NULL);
	ks_stdptr<IStream> target;
	CreateStreamOnFile(A2W(argv[2]), STGM_CREATE|STGM_READWRITE|STGM_SHARE_EXCLUSIVE, &target);
	target->Write(GlobalLock(hgbl), cbWritten, NULL);
	CREATE_LEXER arg;
	SeekPos(target, SEEK_SET, 0);
	Lexer* lex = CreateLexer(target, UTF8, &arg);
	GlobalUnlock(hgbl);
	GlobalFree(hgbl);
	target->Commit(0);	
	return 0;
}