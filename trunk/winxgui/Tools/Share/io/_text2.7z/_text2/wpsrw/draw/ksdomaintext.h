//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainText.h
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-6-5 11:03:40
//	FileDescription	:	Domain Text 
//
//////////////////////////////////////////////////////////////////////////////////////
// KSDomainText.h: interface for the KSDomainText class.
//////////////////////////////////////////////////////////////////////

#ifndef __KSDOMAINTEXT_H
#define __KSDOMAINTEXT_H

#include "Ptobj.h"
#include "Objtext.h"

class KSDomainText : public CLtxtObj  
{
protected:
	DECLARE_SERIAL(KSDomainText);
	KSDomainText();
	
public:
	KSDomainText(const CWpsDoc* pDoc, const CRect& position, int nShape);
	
public:	
	virtual ~KSDomainText();
	CString m_sTitle;	 //	Ĭ������
	int m_nMaxLen;		 // �����Ա���
	//	BOOL m_bEnableField; // û�б��棬������ֻ����ReadOnly ״̬�´β���Ч
	
private:
	BOOL m_bBackGround;
	
public:
	virtual void Serialize_01( KSArchive& ar );
};

// �������ֱ���������
class KSDomainMLText : public CRotateText
{
protected:
	DECLARE_SERIAL(KSDomainMLText);
	KSDomainMLText();
	
public:
	KSDomainMLText(const CWpsDoc* pDoc, const CRect& position, int nShape);
	
public:	
	virtual ~KSDomainMLText();
	CString m_sTitle;	//	Ĭ������
	
private:
	BOOL m_bBackGround;
	//	BOOL m_bEnableField; // û�б��棬������ֻ����ReadOnly ״̬�´β���Ч
	
public:
	virtual void Serialize_01( KSArchive& ar );
};
#endif // !defined(AFX_KSDOMAINTEXT_H__428604A1_3AC3_11D4_A00C_5254AB1993A3__INCLUDED_)
