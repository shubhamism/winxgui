/* -------------------------------------------------------------------------
//	�ļ���		��	wpsdoc.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 10:55:46
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "wpsdoc.h"
#include "wpspage.h"
#include "wpsdocman.h"
#include "anchorobj.h"
#include "stylesheet_text.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CWpsDoc::CWpsDoc()
{
	c_pTextPool = NULL;
	c_pFootnoteTextPool = NULL;
	m_bIsRevise = FALSE;
	m_dwObjIDCount = 1;
	
	::memset(&m_FileHeader, 0, sizeof(m_FileHeader));
	
	/*@@todo
	//���̱�ǳ�ʼ��...
	m_ModifiedFlag = 0;
	m_Modified_Afs = 0;

	m_nFilterIndex = unknownfile;	// {{ io-newfile ȱʡ�ļ�����
	m_bPromptSaveWPT = FALSE;
	m_szPathName[0] = 0;
	m_lpSummary = NULL;		// ȱʡ��ժҪ��Ϣ
	m_wSumSize = 0;

	m_bAddToRecentFileList = TRUE;
	m_pOpenFileData = NULL;

	m_TOCParas.nHowToGetTOC = GETTOC_VIASTYLE;
	m_TOCParas.nTOCPos = TOCPOS_CURPOS;
	m_TOCParas.nTOCLevels = 3;
	m_TOCParas.nTOCStyle = 0;
	m_TOCParas.bPageSeparator = TRUE;
	m_TOCParas.bPageRef = TRUE;
*/

	m_StySht_Text = new CStyleSheet_Text;
/*
	InitStyleSheet();
	m_hLocked = NULL_LOCKFILE;
	m_fOpenCopy = FALSE;

	m_wCurUserID = 0;

	m_EditMode = edit_page;

	m_dwAFSCounter = ::GetTickCount();
	m_szAFSName[0] = 0;
	SetModifiedFlag_Afs (FALSE);

	//��ɫ����صı�����ʼ��...start
	m_nCurIndexOfUD = 0;//��ǰ�Զ�����ɫλ�����
	//��ʼ���Զ�����ɫ...
	int n;
	CString strUserDefine = LoadWPSString(IDS_USERDEFINE);
	for (n = 0; n < defMAX_COLOR_USERDEF; n ++)
	{
		m_UserDefTable[n].crColour = -1;
		strcpy(m_UserDefTable[n].szName, strUserDefine);
	}
	//��ɫ����صı�����ʼ��...end
	
	m_bReadOnly = FALSE;
	m_bBackGround = TRUE;

	//��ʼ�������Ű����, by wxb
	SetNewFileRenderRule();

	// Init Doc ID
	m_uID = AfxGetWPSDocID();
	g_docMan.AddDocument(m_uID, this);

	CWinwpsApp* pApp = (CWinwpsApp*)AfxGetApp();
	m_nCrptyCookie = pApp->m_AddInCrypt.CreateDocument(m_uID);


	m_pSummary = NULL;
	CoCreateInstance(CLSID_Summary, NULL, CLSCTX_ALL, IID_ISummary, (void**)&m_pSummary);

	// ��ʼ��WORDת����Ϣ,SHQ	2001	21/MAR
	InitOpeningWordDoc();

	ApcEnableAutoCreate(FALSE);
	ApcEnableAutoLoad(TRUE);

	m_eMacroRecordingState = macrecStopped;
	m_iApcRecorderPtr = NULL;
	
	m_pBlockNamer = NULL;
	m_bNeedProcessPOToTO	= FALSE;
	InitPageBackGround();

	m_bObjIDReseted = FALSE;

	// added by duyuesheng
	m_pLastFindResult = new FINDRESULT;
	m_pFindScene = new FINDSCENE;
	m_pFindListType = new FINDLISTTYPEPRO;

	ResetFindState();
	// m_bUseOld = FALSE;
	
	m_bPrompt = TRUE;

	InitShapeNameMap();		//��ʼ��Shape��������ӳ��
	InitDocNameMap();		//Initialize doc name map
	*/


	m_pNotify = NULL;

	m_pVBAStg = NULL;
}

CWpsDoc::~CWpsDoc()
{
	DeleteContents();

	/*@@
	//����дΪ��;������������������ݡ�
	delete m_pLastFindResult; // added by duyuesheng
	delete m_pFindScene; // added by duyuesheng
	delete m_pFindListType; // added by duyuesheng
		
	CWinwpsApp* pApp = (CWinwpsApp*)AfxGetApp();
	pApp->m_AddInCrypt.DeCreateDocument(m_nCrptyCookie);
	m_nCrptyCookie = -1;
	
	g_docMan.RemoveDocument(m_uID);
*/
	if (m_StySht_Text != NULL)
		delete m_StySht_Text;

/*	
	if (m_hLocked!=NULL_LOCKFILE)
	{
		ksUnlockFile(m_hLocked);
		m_hLocked = NULL;
	}
*/	
	while (m_OleDataArray.GetSize() > 0)
	{	
		delete (COLEData*)m_OleDataArray.GetAt(0);
		m_OleDataArray.RemoveAt(0);
	}
/*	
	if (m_pSummary)
	{
		m_pSummary->Release();
		m_pSummary = NULL;
	}
	if (m_pBlockNamer)
		m_pBlockNamer->Release();
	
	if (m_pOpenFileData)
		delete m_pOpenFileData; */

	if (m_pVBAStg)
		m_pVBAStg->Release();
	m_pVBAStg = NULL;
}

/***************************************************************************
����:	���ȫ��ҳ��
***************************************************************************/
void CWpsDoc::DeleteWPSPages()
{
	ASSERT_VALID(this);
	CWPSPage*	pWPSPage;
	int nSize = m_WPSPages.GetUpperBound();
	for (int i = nSize; i >= 1; i--)		// ע��: i��1Ϊֹ
	{
		pWPSPage = (CWPSPage*) m_WPSPages.GetAt(i);
		if (pWPSPage)
		{
			ASSERT_VALID(pWPSPage);
			delete pWPSPage;
		}
		m_WPSPages.RemoveAt(i);	// 6-25,'98�����ռǣ��ر��ļ�ʱASSERT
	}
	m_WPSPages.RemoveAll();
}

/**************************************************************************
����:	ɾ��ȫ����ҳ�ڶ���
**************************************************************************/
void CWpsDoc::DeleteMasterObjects()
{
	ASSERT_VALID(this);
	while (!m_lstMasterObjs.IsEmpty())
#ifdef _DEBUG
	{
		CWPSObj* pObj;
		pObj = (CWPSObj*) m_lstMasterObjs.RemoveHead();
		ASSERT_VALID(pObj);
		delete pObj;
	}
#else
	delete m_lstMasterObjs.RemoveHead();
#endif
}

/***************************************************************************
���ܣ�  ɾ��ȫ�����Ķ���
***************************************************************************/
void CWpsDoc::DeleteAnchoredObjects()
{
	CWPSObj* pDelObj = NULL;
	
	CPtrList DelList;
	
	ASSERT_VALID(this);
	
	int nSize = NumOfAnchoredObjs();
	
	CAnchorObj* pObj;
	
	for (int i = 0; i < nSize; i++)
	{
		pObj = (CAnchorObj*)m_newAryAnchoredObjs.GetAt(i);
		
		if (pObj)
		{
			pDelObj = pObj->Detach();
			if (pDelObj && DelList.Find(pDelObj) == NULL)
				DelList.AddTail(pDelObj);
			else
			{
				TRACEA("Obj is already delete !!!\n");
			}
			
			ASSERT_VALID(pObj);
			delete pObj;
		}
	}
	
	POSITION pos = DelList.GetHeadPosition();
	while (pos)
	{
		pDelObj = (CWPSObj*)DelList.GetNext(pos);
		if (pDelObj)
			delete pDelObj;
	}
	
	m_newAryAnchoredObjs.RemoveAll();
}

inline void CWpsDoc::DeleteUserObjs()
{
	int n = m_UserArray.GetSize();
	while (n--)
		delete m_UserArray.GetAt(n);
	m_UserArray.RemoveAll();
}

/***************************************************************************
���ܣ�	����ļ�����
***************************************************************************/
void CWpsDoc::DeleteContents()
{
	// ɾ��ȫ��ҳ��
	DeleteWPSPages();

	if (c_pTextPool)
	{
		delete c_pTextPool;
		c_pTextPool = NULL;
	}
	if (c_pFootnoteTextPool)
	{
		ASSERT_VALID(c_pFootnoteTextPool);
		delete c_pFootnoteTextPool;
		c_pFootnoteTextPool = NULL;
	}

	// ɾ��ҳüҳ��
	m_SectionInfoManager.ClearHeaderFooter();
	
	// ���ȫ�ļ����Ķ���
	DeleteMasterObjects();
	DeleteAnchoredObjects();
	
	// ɾ���й��û���Ϣ
	DeleteUserObjs();
	
	/*@@todo
	
	DeleteBackupPages();
		
	// ɾ��AFS�ļ�
	DeleteAFSFile();
	
	// �����ļ�ժҪ��Ϣ
	FreeSummaryInfo();
	
	VERIFY(UnInitMacroManager());
	
	// vba
	if (m_iApcRecorderPtr != NULL)
		StopMacroRecording();
	
	// stop VBA execution
	CWinwpsApp* pApp = (CWinwpsApp*)AfxGetApp();
    if (pApp->ApcHost)
    {
		//		pApp->ApcHost->APC_RAW(End)(NULL);
		if (ApcProjectItem)
			ApcProjectItem.Detach();
    }
	
	POSITION pos = GetStartPosition();
	COleClientItem* pItem;
	while (pos && (pItem = GetNextClientItem(pos)) != NULL)
	{
		pItem->Release(OLECLOSE_NOSAVE);    // release OLE object
		RemoveItem(pItem);  // disconnect from document
		pItem->InternalRelease();   // may 'delete pItem'
	}
	
	KWpsDocBase::DeleteContents();	*/
}

CUser* CWpsDoc::GetUser(WORD wUserID)
{
//	if (!GetUserNum())
//#ifndef _WPSREADER
//		CreateNewUser();	// ��ԭ�����ĵ�û���û������ڴ����ɵ�һ���û�
//#else
//		return NULL;
//#endif	// #ifndef _WPSREADER
	ASSERT(wUserID < GetUserNum());
	CUser* pUser = (CUser*)m_UserArray.GetAt(wUserID);
	return pUser;
}

// -------------------------------------------------------------------------
