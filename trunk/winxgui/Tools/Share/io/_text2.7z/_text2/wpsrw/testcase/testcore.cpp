/* -------------------------------------------------------------------------
//	�ļ���		��	testcore.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 20:45:59
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifdef _DEBUG

#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestWpsCore : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestWpsCore);
//		CPPUNIT_TEST(testStyle);
//		CPPUNIT_TEST(testAnnotation);
//		CPPUNIT_TEST(testEscPage);
		CPPUNIT_TEST(testBasic);
		CPPUNIT_TEST(testChpx);
		CPPUNIT_TEST(testPapx);
		CPPUNIT_TEST(testMultiSection);
		CPPUNIT_TEST(testEscTime);
		CPPUNIT_TEST(testEscDate);
		CPPUNIT_TEST(testEscDay);
		CPPUNIT_TEST(testEscFootnote);
		CPPUNIT_TEST(testBookmark);
		CPPUNIT_TEST(testHyperlink);
		CPPUNIT_TEST(testAutoNum);
		CPPUNIT_TEST(testSection);
		CPPUNIT_TEST(testSectionScriptSheet);
		CPPUNIT_TEST(testPageObjs);
		CPPUNIT_TEST(testToc);
		CPPUNIT_TEST(testTabStops);
		CPPUNIT_TEST(testVBA);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testEscPage()
	{
		testWps2DocFile("core/esc_pagenum_WPS2003.wps", "_core_esc_pagenum_WPS2003_.doc");
		testWps2DocFile("core/esc_pagenum_WPS2000.wps", "_core_esc_pagenum_WPS2000_.doc");
		testWps2DocFile("core/esc_totalpage_WPS2000.wps", "_core_esc_totalpage_WPS2000_.doc");
		testWps2DocFile("core/esc_totalpage_WPS2003.wps", "_core_esc_totalpage_WPS2003_.doc");
	}
	void testEscTime()
	{
		testWps2DocFile("core/esc_time_WPS2000.wps", "_core_esc_time_WPS2000_.doc");
		testWps2DocFile("core/esc_time_WPS2003.wps", "_core_esc_time_WPS2003_.doc");
	}
	void testEscDate()
	{
		testWps2DocFile("core/esc_date_WPS2000.wps", "_core_esc_date_WPS2000_.doc");
		testWps2DocFile("core/esc_date_WPS2003.wps", "_core_esc_date_WPS2003_.doc");
	}
	void testEscDay()
	{
		testWps2DocFile("core/esc_day_WPS2000.wps", "_core_esc_day_WPS2000_.doc");
		testWps2DocFile("core/esc_day_WPS2003.wps", "_core_esc_day_WPS2003_.doc");
	}
	void testEscFootnote()
	{
		testWps2DocFile("core/esc_footnote_WPS2003.wps", "_core_esc_footnote_WPS2003_.doc");
	}
	void testBookmark()
	{
		testWps2DocFile("core/bookmark_WPS2003.wps", "_core_bookmark_WPS2003_.doc");
	}
	void testHyperlink()
	{
		testWps2DocFile("core/hyperlink_WPS2003.wps", "_core_hyperlink_WPS2003_.doc");
	}
	void testStyle()
	{
		testWps2DocFile("core/style_WPS2000.wps", "_core_style_WPS2000_.doc");
		testWps2DocFile("core/style_WPS2003.wps", "_core_style_WPS2003_.doc");
	}
	void testAutoNum()
	{
		testWps2DocFile("core/autonum_WPS2001.wps", "_core_autonum_WPS2001_.doc");
		testWps2DocFile("core/autonum_WPS2002.wps", "_core_autonum_WPS2002_.doc");
		testWps2DocFile("core/autonum_WPS2003.wps", "_core_autonum_WPS2003_.doc");
	}
	void testBasic()
	{
		testWps2DocFile("core/a.wps", "_core_a_.doc");
		testWps2DocFile("core/2000/a.wps", "_2000_core_a_.doc");
	}
	void testChpx()
	{
		//testWps2DocFile("core/chpx.wps", "_core_chpx_.doc");
		testWps2DocFile("core/2000/chpx.wps", "_2000_core_chpx_.doc");
	}
	void testPapx()
	{
		testWps2DocFile("core/papx.wps", "_core_papx_.doc");
	//	testWps2DocFile("core/papx2.wps", "_core_papx2_.doc");
	}
	void testMultiSection()
	{
		testWps2DocFile("core/multi_sect.wps", "_core_multi_sect_.doc");
	}
	void testSection()
	{
		testWps2DocFile("core/section.wps", "_core_section_.doc");
	}
	void testSectionScriptSheet()
	{
		testWps2DocFile("core/SectionScriptSheet.wps", "_core_sectionScriptSheet_.doc");
	}
	void testAnnotation()
	{
		testWps2DocFile("core/Annotation.wps", "_core_annotation_.doc");
	}
	void testPageObjs()
	{
		testWps2DocFile("core/PageObjs.wps", "_core_PageObjs_.doc");
	}
	void testToc()
	{
		testWps2DocFile("core/toc.wps", "_core_toc_.doc");
	}
	void testTabStops()
	{
		testWps2DocFile("core/tabStops.wps", "_core_tabStops_.doc");
	}
	void testVBA()
	{
		testWps2DocFile("core/vba.wps", "_2_core_vba_.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestWpsCore);

static HRESULT g_hr = WpsInitialize();

#endif

// -------------------------------------------------------------------------
