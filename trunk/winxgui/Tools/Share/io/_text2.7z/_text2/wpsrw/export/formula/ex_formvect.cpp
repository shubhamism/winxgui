/* -------------------------------------------------------------------------
//	�ļ���		��	ex_formvect.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-31 10:43:06
//	��������	��	
//
//	$Id: ex_formvect.cpp,v 1.10 2005/08/31 04:20:19 lizhongbo Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "math.h"

#include "ex_formula.h"
#include "../ks_colormodel.h"
#include "../export_tools.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int FS[4] = { 637, 425, 247, 185 };
int nTempFS[4];
int nFormulaCharMrg = 12;//	��ʽ���ֵļ��(12%)
int nTempFormulaCharMrg;
//int CM_DEFAULT = 12;	//	��ʽ���ֵļ��(12%)
int LM_DEFAULT = 50;	//	��ʽ�м�ļ��(50%)

int GetFS( int ndx )
{
	ASSERT( ndx >= 0 );
	ndx = MIN(3, ndx);
	return FS[ndx];
}

void SaveFS()
{
	for(int i=0; i<4; i++)
		nTempFS[i] = FS[i];
	nTempFormulaCharMrg = nFormulaCharMrg;
}

void RefreshFS()
{
	for(int i=0; i<4; i++)
		FS[i] = nTempFS[i];
	nFormulaCharMrg = nTempFormulaCharMrg;
}

void ChangeFS(int nFS[4], int nCharMrg)
{
	for(int i=0; i<4; i++)
		FS[i]=nFS[i];
	nFormulaCharMrg = nCharMrg;
}

// -------------------------------------------------------------------------

void CFormula::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	if (IsObjListEmpty())
		return;
	//	��������
	CRect rect = m_rect;
	DrawPosition( pDC, rect );
	pDC->LPtoDP(&rect);	
	rect.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formula ���Ͻ�
	pDC->OffsetViewportOrg(rect.left, rect.top);
	CWPSObj* pObj;
	for (POSITION pos = GetFirstObjPos(); pos;)
	{
		pObj = GetNextObj(pos);
		pObj->DrawShape(pDC, pICS);
	}            
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rect.left, -rect.top);
}

EX_SHAPE_API CFormula_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormula::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}
// ��ʽ
#define TAILWIDTH	8		//��ʽ��β�͵Ŀ�
#define TAILHEIGHT	6		//��ʽ��β�͵ĸ�

void CFormRadical::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formFrac ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	int m_fontsize = (GetFS(m_nFSIndex)+5)/10; 
	COLORREF clr = RGB(0, 0, 0);

	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);
	//���´������ڻ���ʽ����
	////////////////////////////////////////
	pDC->MoveTo(m_formRadCell.m_rect.right+4,m_formRadCell.m_rect.top-8);
	pDC->LineTo(m_formRadCell.m_rect.left,m_formRadCell.m_rect.top-8);
	pDC->LineTo(m_formExpon.m_rect.right,m_formRadCell.m_rect.bottom);
	pDC->LineTo(m_formExpon.m_rect.right-m_fontsize/4,m_formRadCell.m_rect.bottom-m_formRadCell.m_rect.Height()/3);
   	pDC->LineTo(m_formExpon.m_rect.right-m_fontsize/4-TAILWIDTH,m_formRadCell.m_rect.bottom-m_formRadCell.m_rect.Height()/3+TAILHEIGHT);
	////////////////////////////////////////
 	pDC->SelectObject(pOldPen);
	m_formExpon.DrawShape(pDC, pICS);
	m_formRadCell.DrawShape(pDC, pICS);
//	p = (CFormula_Export*)&m_formRadCell;
//	p->Draw(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormRadical_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormRadical::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

int c_nInte;
int c_tmAscent;
CFont* GetFontObj(CDC* pDC, int nH, char* szFName, BYTE Italic, int nWeight)
{
	static LOGFONT	s_scrlf;
	static char		s_szFName[LF_FACESIZE];
	static int		s_nH = -1;
	static CFont	s_scrfont;
	static BYTE		s_bIsI;
	static int      s_nWeight;
	if (s_nH == -1)
	{
		s_scrlf.lfEscapement 	= 0;
		s_scrlf.lfOrientation	= 0;
		s_scrlf.lfItalic		= (Italic==CC_DISABLED?(BYTE)0: (BYTE)1);
		s_scrlf.lfUnderline		= 0;
		s_scrlf.lfStrikeOut		= 0;
		s_scrlf.lfCharSet 		= ANSI_CHARSET;
		s_scrlf.lfOutPrecision 	= OUT_DEFAULT_PRECIS;//OUT_STROKE_PRECIS;
		s_scrlf.lfClipPrecision	= CLIP_DEFAULT_PRECIS;//CLIP_STROKE_PRECIS;
		s_scrlf.lfQuality		= DEFAULT_QUALITY;
		s_scrlf.lfPitchAndFamily= DEFAULT_PITCH;
		lstrcpy(s_scrlf.lfFaceName, szFName);
		s_scrlf.lfHeight = -nH;
		s_scrlf.lfWidth  = 0;
		s_scrlf.lfWeight = nWeight;
		s_nH = nH;
		s_nWeight=nWeight;
		s_bIsI = Italic;
		if (!s_scrfont.CreateFontIndirect(&s_scrlf))
			return NULL;
	}
	else if (s_nH != nH || s_bIsI != Italic ||s_nWeight!=nWeight||
			  lstrcmp(s_szFName, szFName) != 0)
	{	s_scrlf.lfItalic = (Italic==CC_DISABLED?(BYTE)0: (BYTE)1);
		s_scrlf.lfWeight = nWeight;
		lstrcpy(s_scrlf.lfFaceName, szFName);
		s_scrlf.lfHeight = -nH;
		s_nH = nH;
		lstrcpy(s_szFName, szFName);
		s_bIsI = Italic;
		s_nWeight=nWeight;
		s_scrfont.DeleteObject();				// !!!
		if (!s_scrfont.CreateFontIndirect(&s_scrlf))
			return NULL;
	}
	CFont* pFont = pDC->SelectObject(&s_scrfont);
	ASSERT(pFont);
	TEXTMETRIC tm;
	pDC->GetTextMetrics(&tm);
	c_nInte = tm.tmInternalLeading/2;
	c_tmAscent = tm.tmAscent;
	return pFont;
}

extern TCHAR		szDefEFontName[];

void CFormABC::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formABC ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	int nFontH = (GetFS(m_nFSIndex)+5)/10;
	CFont* pOldFont = GetFontObj(pDC, nFontH, szDefEFontName, m_Italic,m_nWeight);
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	COLORREF Oldcolor= pDC->SetTextColor(KColorModel::IndexToRef(m_FormCharColor, pICS));
	CString curStr;
	TextStringToString(curStr, m_string);
#ifdef LINUX_BUILD
	LOGFONT logFont;
	pDC->GetCurrentFont()->GetLogFont(&logFont);
	CFont newFont;
	logFont.lfCharSet=GB2312_CHARSET;
	newFont.CreateFontIndirect(&logFont);
	pDC->SelectObject(&newFont);
#endif 
	pDC->SetTextAlign(TA_LEFT|TA_BASELINE);
	pDC->TextOut(0, 0-c_nInte+c_tmAscent, curStr);
//	int nLen = curStr.GetLength();
//	pDC->ExtTextOut(0,-c_nInte,0,rct,curStr,nLen,0);
	pDC->SelectObject(pOldFont);
	pDC->SetTextColor(Oldcolor);
	pDC->SetBkMode(nBkMode);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();

}

void CFormFrac::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if(!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect( -pDC->GetViewportOrg() );
	//	ԭ�������� formFrac ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	//	���ö���
	m_formulaTop.DrawShape(pDC, pICS);
	
	COLORREF clr = RGB(0, 0, 0);
	
	//	������
	CPen* pOldPen;
	CPen pen( PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject( &pen );	
	CRect rc = m_rectFLine;
	pDC->MoveTo( 0,			rc.CenterPoint().y );
	pDC->LineTo( rc.right,	rc.CenterPoint().y );
	pDC->SelectObject(pOldPen);	
	//	���ö���
	m_formulaBot.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormFrac_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormFrac::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormDivide::GetLR(int& Lw,int& Rw)
{
	int maxHeight = MAX(m_formulaTop.m_rect.Height(),m_formulaBot.m_rect.Height());
	int FW = (int)(maxHeight*tan(3.1415926*15/180));
	if (m_formulaTop.m_rect.Width()+(int)(tan(3.1415926*15/180)*m_formulaTop.m_rect.Height())/2>=FW/2)
		Lw = m_formulaTop.m_rect.Width()+(int)(tan(3.1415926*15/180)*m_formulaTop.m_rect.Height())/2;
	else
		Lw = FW/2;
	if (m_formulaBot.m_rect.Width()+(int)(tan(3.1415926*15/180)*m_formulaBot.m_rect.Height()/2)>=FW/2)
		Rw = m_formulaBot.m_rect.Width()+(int)(tan(3.1415926*15/180)*m_formulaBot.m_rect.Height())/2;
	else
		Rw = FW/2;
}

void CFormDivide::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CFormLabel ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	int maxHeight=MAX(m_formulaTop.m_rect.Height(),m_formulaBot.m_rect.Height());
	int FW=(int)(maxHeight*tan(3.1415926*15/180));
	int Lw,Rw;
	GetLR(Lw,Rw);

	COLORREF clr = RGB(0, 0, 0);

	//	set pen
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
		//��б��
	CPoint temP1(Lw+FW/2,0);
    CPoint temP2(Lw-FW/2,m_rect.Height());
	pDC->MoveTo(temP1);
	pDC->LineTo(temP2);
	pDC->SelectObject(pOldPen);
	//	��ʽ����
	m_formulaTop.DrawShape(pDC, pICS);
	m_formulaBot.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormDivide_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormDivide::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormObj::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if(!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	CFormulae::DrawShape(pDC, pICS);
	RefreshFS();
}

EX_SHAPE_API CFormObj_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormObj::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormulae::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	if (IsObjListEmpty())
		return;
	//	��������
	//	ԭ�������� formulae ���Ͻ�
	CRect rect = m_rect;
	DrawPosition( pDC, rect );
	pDC->LPtoDP(&rect);	rect.OffsetRect(-pDC->GetViewportOrg());	//	������������ԭ��(ʹ��Ԫ����)
	pDC->OffsetViewportOrg(rect.left, rect.top);
	CWPSObj* pObj;
	for (POSITION pos = GetFirstObjPos(); pos;)
	{
		pObj = GetNextObj(pos);
		pObj->DrawShape(pDC, pICS);
	}            
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rect.left, -rect.top);
}
EX_SHAPE_API CFormulae_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormulae::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}


#define INTERVAL	4		//�����С��0.4mm
void CFormRemain::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CFormRemain ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	
	COLORREF clr = RGB(0, 0, 0);

	//	set pen
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
		//��б��
	CPoint temP1(m_formulaLeft.m_rect.Width()+INTERVAL/2,0);
    CPoint temP2(m_formulaLeft.m_rect.Width()+INTERVAL/2,INTERVAL+m_formulaIn.m_rect.Height()+INTERVAL/2);
	CPoint temP3(m_formulaLeft.m_rect.Width()+INTERVAL+m_formulaIn.m_rect.Width()+INTERVAL,INTERVAL+m_formulaIn.m_rect.Height()+INTERVAL/2);
	pDC->MoveTo(temP1);
	pDC->LineTo(temP2);
	pDC->LineTo(temP3);

	CGdiObject* OldBrush;
	OldBrush=pDC->SelectStockObject(BLACK_BRUSH);
	CPoint temP4(m_formulaIn.m_rect.right+1*INTERVAL,INTERVAL+m_formulaIn.m_rect.Height()/2);
	CPoint temP5(m_formulaIn.m_rect.right+4*INTERVAL,INTERVAL+m_formulaIn.m_rect.Height()/2);
	CPoint temP6(m_formulaIn.m_rect.right+7*INTERVAL,INTERVAL+m_formulaIn.m_rect.Height()/2);
	pDC->Ellipse(temP4.x-INTERVAL,temP4.y-INTERVAL,temP4.x+INTERVAL,temP4.y+INTERVAL);
	pDC->Ellipse(temP5.x-INTERVAL,temP5.y-INTERVAL,temP5.x+INTERVAL,temP5.y+INTERVAL);
	pDC->Ellipse(temP6.x-INTERVAL,temP6.y-INTERVAL,temP6.x+INTERVAL,temP6.y+INTERVAL);
	pDC->SelectObject(OldBrush);
	pDC->SelectObject(pOldPen);
	//	��ʽ����
	m_formulaLeft.DrawShape(pDC, pICS);
	m_formulaIn.DrawShape(pDC, pICS);
	m_formulaRight.DrawShape(pDC, pICS);
	m_formulaBot.DrawShape(pDC,pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormRemain_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormRemain::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

CWPSObj* GetPrevObj(CWPSObj* pObj, CObList* pList, BOOL bCycle)
{
	ASSERT_VALID(pObj);
	if (!pList || pList->GetCount() <= 1)
		return NULL;
	POSITION pos = pList->Find(pObj);
	if (pos)
	{
		pList->GetPrev(pos);
		if (pos)
			return (CWPSObj*)pList->GetPrev(pos);
		if (bCycle)
			return (CWPSObj*)pList->GetTail();
		return NULL;
	}
	return NULL;
}

void CFormTBscript::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	
	rct.OffsetRect(-pDC->GetViewportOrg());
    CFormula* pMstObj = (CFormula*)this->GetMstObj();
	if (pMstObj)
	{
		CWPSObj* pPrv = (CFormula*)::GetPrevObj(this, pMstObj->GetObjList(),FALSE);
		if (pPrv!=NULL)
		{	//	ԭ��������CFormTBscript���Ͻ�
			pDC->OffsetViewportOrg(rct.left, rct.top);
			//	���ö���
			m_formulaeTop.DrawShape(pDC, pICS);
			//	���ö���
			m_formulaeBot.DrawShape(pDC, pICS);
			pDC->OffsetViewportOrg(-rct.left, -rct.top);
		}
	}
	else
	{
		// liupeng ���ʲô���ݶ�û�еĻ��Ͳ�Ҫ���˰�,bugid 15679 
		{
			RefreshFS();
			return;
		}
		int h = (GetFS(m_nFSIndex+1)+5)/10;
		int H = (GetFS(m_nFSIndex)+5)/10;
		if (m_formulaeTop.m_rect.Height()<=h&&m_formulaeTop.m_rect.Width()<=h/2&&m_formulaeBot.m_rect.Height()<=h&&m_formulaeBot.m_rect.Width()<=h/2)
		{
			COLORREF clr = RGB(0,0,0);

			CPen* pOldPen;
			CPen pen(PS_SOLID, 1, clr);
			pOldPen = pDC->SelectObject(&pen);	
			//	set brush
			CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
			int nBkMode = pDC->SetBkMode(TRANSPARENT);
			//	��������
			int nFontH =(GetFS(1)+5)/10;
			COLORREF OldColor = pDC->SetTextColor(clr);
			CFont* pOldFont = GetFontObj(pDC, nFontH, "����", CC_DISABLED,FW_NORMAL);
			CPoint point(-10,0);
			pDC->SetTextAlign(TA_LEFT|TA_BASELINE);
			pDC->TextOut(point.x,point.y+c_tmAscent,"R");
			pDC->SetTextColor(OldColor);
			//GetFontObj(pDC, nFontH/2, "����", CC_DISABLED,FW_NORMAL);
			//CPoint pointT(20,0);
			//CPoint pointB(20,25);
			//pDC->TextOut(pointT.x,pointT.y,"2");
			//pDC->TextOut(pointB.x,pointB.y,"n");
			pDC->Rectangle(20,8,20+nFontH/4,10+nFontH/4);
			pDC->Rectangle(20,38,20+nFontH/4,40+nFontH/4);
			pDC->SelectObject(pOldFont);
			pDC->SelectObject(pOldBrush);
			pDC->SelectObject(pOldPen);	
			pDC->SetBkMode(nBkMode);
		}
		else
		{
			//	ԭ��������CFormTBscript���Ͻ�
			pDC->OffsetViewportOrg(rct.left, rct.top);
			//	���ö���
			m_formulaeTop.DrawShape(pDC, pICS);
			//	���ö���
			m_formulaeBot.DrawShape(pDC, pICS);
			pDC->OffsetViewportOrg(-rct.left, -rct.top);
		}
	}
	RefreshFS();
}

EX_SHAPE_API CFormTBscript_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormTBscript::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}


void CFormMatr::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if(!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect( -pDC->GetViewportOrg() );
	//	ԭ�������� formMatr ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	
	COLORREF clr = RGB(0, 0, 0);

	//	����Χ��
	CPoint wh(2,20);
	int b = wh.y;
	int h = m_rect.Height();
	int w = m_rect.Width();
	switch ( m_nBracket ) {
	case BK_ver:
	{	//	set pen
		CPen* pOldPen;
		CPen pen( PS_SOLID, wh.x, clr);
		pOldPen = pDC->SelectObject( &pen );	
		pDC->MoveTo( 1,		1 );
		pDC->LineTo( 1,		h-1 );
		pDC->MoveTo( w-1,	1 );
		pDC->LineTo( w-1,	h-1 );
		pDC->SelectObject(pOldPen);	
	}
	break;
	case BK_ver2:
	{	//	set pen
		CPen* pOldPen;
		CPen pen( PS_SOLID, wh.x, clr);
		pOldPen = pDC->SelectObject( &pen );	
		int dd = wh.x*4;
		pDC->MoveTo( dd,	1   );
		pDC->LineTo( dd,	h-1 );
		pDC->MoveTo( 1,	1   );
		pDC->LineTo( 1,	h-1 );
		pDC->MoveTo( w-dd,	1   );
		pDC->LineTo( w-dd,	h-1 );
		pDC->MoveTo( w-1,	1   );
		pDC->LineTo( w-1,	h-1 );
		pDC->SelectObject(pOldPen);	
	}
	break;
	case BK_arc:
	{	//	set pen
		CPen* pOldPen;
		CPen pen( PS_SOLID, 1, clr);
		pOldPen = pDC->SelectObject( &pen );	
		//	set brush
		CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(BLACK_BRUSH);
		double ddy4ddx = h*h + 4*b*b;
		int r = (int)(ddy4ddx/(8.0*b));
		CRect rcArc(0, h/2-r, 2*r, h/2+r);
		CPoint sp(b,0);
		CPoint ep(b,h);
		CPoint sp2(w-b,0);
		CPoint ep2(w-b,h);
		pDC->Chord( rcArc, sp, ep );
		rcArc.SetRect(w-2*r, h/2-r, w, h/2+r);
		pDC->Chord( rcArc, ep2, sp2 );
		pDC->SelectObject(pOldPen);	
		pDC->SelectObject(pOldBrush);	
		pOldPen = (CPen*)pDC->SelectStockObject(WHITE_PEN);
		pOldBrush = (CBrush*)pDC->SelectStockObject(WHITE_BRUSH);
		int dd = b/4;
		ddy4ddx = h*h + 4*(b-dd)*(b-dd);
		r = (int)(ddy4ddx/(8.0*(b-dd)));
		CRect rcArc2(dd+1, h/2-r, 2*r, h/2+r);
		pDC->Chord( rcArc2, sp, ep );
		rcArc2.SetRect(w-dd-1-2*r, h/2-r, w-dd-1, h/2+r);
		pDC->Chord( rcArc2, ep2, sp2 );
		pDC->SelectObject(pOldPen);	
		pDC->SelectObject(pOldBrush);	
	}
	break;
	case BK_squ:
	{	//	set pen
		CPen* pOldPen;
		CPen pen( PS_SOLID, wh.x, clr);
		pOldPen = pDC->SelectObject( &pen );	
		pDC->MoveTo( b,	1 );
		pDC->LineTo( 1,	1 );
		pDC->LineTo( 1,	h-1 );
		pDC->LineTo( b,	h-1 );
		pDC->MoveTo( w-b,	1 );
		pDC->LineTo( w-1,	1 );
		pDC->LineTo( w-1,	h-1 );
		pDC->LineTo( w-b,	h-1 );
		pDC->SelectObject(pOldPen);	
	}
	break;
	case BK_bra:
	{	//	set pen
		CPen* pOldPen;
		CPen pen( PS_SOLID, wh.x, clr);
		pOldPen = pDC->SelectObject( &pen );	
		CPoint pnt(0,0);
		CPoint p[4];
		p[0].x = pnt.x+b;	p[0].y = pnt.y;
		p[1].x = pnt.x;		p[1].y = pnt.y;
		p[2].x = pnt.x+b;	p[2].y = pnt.y+h/2;
		p[3].x = pnt.x;		p[3].y = pnt.y+h/2;
		pDC->PolyBezier(p, 4);
		p[0].x = pnt.x;		p[0].y = pnt.y+h/2;
		p[1].x = pnt.x+b;	p[1].y = pnt.y+h/2;
		p[2].x = pnt.x;		p[2].y = pnt.y+h;
		p[3].x = pnt.x+b;	p[3].y = pnt.y+h;
		pDC->PolyBezier(p, 4);
		pnt.x = w;
		p[0].x = pnt.x-b;	p[0].y = pnt.y;
		p[1].x = pnt.x;		p[1].y = pnt.y;
		p[2].x = pnt.x-b;	p[2].y = pnt.y+h/2;
		p[3].x = pnt.x;		p[3].y = pnt.y+h/2;
		pDC->PolyBezier(p, 4);
		p[0].x = pnt.x;		p[0].y = pnt.y+h/2;
		p[1].x = pnt.x-b;	p[1].y = pnt.y+h/2;
		p[2].x = pnt.x;		p[2].y = pnt.y+h;
		p[3].x = pnt.x-b;	p[3].y = pnt.y+h;
		pDC->PolyBezier(p, 4);
		pDC->SelectObject(pOldPen);	
	}
	break;
	case BK_null:
		break;
	}
//���´��뻭�����----------------------------
	CPen* pOldPen;
	CPen pen( PS_DOT, wh.x, clr);
	pOldPen = pDC->SelectObject( &pen );	
	int nFontW = (GetFS(m_nFSIndex)+5)/10;
	int nLExt = nFontW/2;
	CWPSObj* pObj;
	CPoint Spoint,Epoint;
	if(m_nRow[0])
	{	Spoint=CPoint(0,0);
		Epoint=CPoint(m_rect.Width(),0);
		pDC->MoveTo(Spoint);
		pDC->LineTo(Epoint);
	}
	for (int r=0; r<m_nR; r++)
	{	int mm = r*m_nC;
		int nObjMaxBottom=nFontW+nLExt;
		for (int c=0; c<m_nC; c++)
		{	pObj = (CWPSObj*)m_objArray[mm+c];
			if(pObj->m_rect.bottom>nObjMaxBottom)
				nObjMaxBottom=pObj->m_rect.bottom;
		}
		if( m_nRow[r+1])
		{	Spoint=CPoint(0,nObjMaxBottom+nLExt);
			Epoint=CPoint(m_rect.Width(),nObjMaxBottom+nLExt);
			pDC->MoveTo(Spoint);
			pDC->LineTo(Epoint);
		}
	}
	if(m_nColumn[0])
	{	Spoint=CPoint(0,0);
		Epoint=CPoint(0,m_rect.Height());
		pDC->MoveTo(Spoint);
		pDC->LineTo(Epoint);
	}
	
	for ( int c=0; c<m_nC; c++)
	{	int nObjMaxRight=nFontW+nLExt;
		for (int r=0; r<m_nR; r++)
		{	pObj = (CWPSObj*)m_objArray[r*m_nC+c];
			if(pObj->m_rect.right>nObjMaxRight)
				nObjMaxRight=pObj->m_rect.right;
		}
		if( m_nColumn[c+1])
		{	Spoint=CPoint(nObjMaxRight+nLExt,0);
			Epoint=CPoint(nObjMaxRight+nLExt,m_rect.Height());
			pDC->MoveTo(Spoint);
			pDC->LineTo(Epoint);
		}
	}
	pDC->SelectObject( pOldPen );	
//------------------------------------------------------
	for (int n=0; n<m_nR*m_nC; n++)
	{	pObj = (CWPSObj*)m_objArray[n];
		pObj->DrawShape(pDC, pICS);
	}
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormMatr_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormMatr::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

TCHAR g_szSymbolFontName[] = _T("Symbol");

void CFormTB::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if(!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
  	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect( -pDC->GetViewportOrg() );
	//	ԭ�������� formTB ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	
	COLORREF clr(RGB(0, 0, 0));

	//	set pen
	CPen* pOldPen;
	CPen pen( PS_DOT, 1, clr);
	pOldPen = pDC->SelectObject( &pen );	
	//	set brush
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	int nBkMode = pDC->SetBkMode( TRANSPARENT );
	//	���ö���
	m_formulaeTop.DrawShape( pDC, pICS);
	//	��������
	int nFontH = ( GetFS(m_nFSIndex-1)+5 )/10;
///	CFont* pOldFont = GetFontObj( pDC, nFontH, szDefCFontName, CC_DISABLED, FW_NORMAL );
	CFont* pOldFont = GetFontObj( pDC, nFontH, g_szSymbolFontName, CC_DISABLED, FW_NORMAL );
	CRect rc = m_rectChar;
//	pDC->TextOut( rc.left, rc.top, m_str );
	pDC->SetTextAlign(TA_LEFT|TA_BASELINE);
	pDC->TextOut( rc.left, rc.top-c_nInte+c_tmAscent, m_str );
	pDC->SelectObject(pOldFont);
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);	
	pDC->SetBkMode( nBkMode );
	//	���ö���
	m_formulaeBot.DrawShape( pDC, pICS);
	//	��������
	m_formula.DrawShape( pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormTB_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormTB::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

#define ARROWL		12		//��ͷ��:1.2mm 
#define ARROWH		6		//��ͷ��0.6mm
#define FRAC_EXT	4		//��Ƿ��������ߵ����¿��ߵĳߴ磺0.4mm
#define FRAC_W		2		//�����߿���0.2mm

void CFormLabel::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CFormLabel ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	
	COLORREF clr(RGB(0, 0, 0));

	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
	CRect rc = m_rectLabel;
	CPoint wh(ARROWL,ARROWH);
	CRect TempRect(rc.right,rc.top-rc.Height(),rc.left,rc.bottom+rc.Height());//��CURVEʱ,Ҫ���ӱ�Ƿ���߶� 
	CGdiObject* OldBrush;
	switch(m_LabelType)
	{
	case ONEPOINT://һ��
		OldBrush = pDC->SelectStockObject(BLACK_BRUSH);
		pDC->Ellipse(rc.CenterPoint().x-3,rc.CenterPoint().y-3,rc.CenterPoint().x+3,rc.CenterPoint().y+3);
		pDC->SelectObject(OldBrush);
		break;
	case TWOPOINT://����
		OldBrush = pDC->SelectStockObject(BLACK_BRUSH);
		pDC->Ellipse(rc.CenterPoint().x-FRAC_EXT-3,rc.CenterPoint().y-3,rc.CenterPoint().x-FRAC_EXT+3,rc.CenterPoint().y+3);
		pDC->Ellipse(rc.CenterPoint().x+FRAC_EXT-3,rc.CenterPoint().y-3,rc.CenterPoint().x+FRAC_EXT+3,rc.CenterPoint().y+3);
		pDC->SelectObject(OldBrush);
		break;
	case THREEPOINT://����
		OldBrush = pDC->SelectStockObject(BLACK_BRUSH);
		pDC->Ellipse(rc.CenterPoint().x-FRAC_EXT*2-3,rc.CenterPoint().y-3,rc.CenterPoint().x-FRAC_EXT*2+3,rc.CenterPoint().y+3);
		pDC->Ellipse(rc.CenterPoint().x-3,rc.CenterPoint().y-3,rc.CenterPoint().x+3,rc.CenterPoint().y+3);
		pDC->Ellipse(rc.CenterPoint().x+FRAC_EXT*2-3,rc.CenterPoint().y-3,rc.CenterPoint().x+FRAC_EXT*2+3,rc.CenterPoint().y+3);
		pDC->SelectObject(OldBrush);
		break;
	case LEFTARROW://���ͷ
		pDC->MoveTo(wh.x,rc.CenterPoint().y-wh.y);	
		pDC->LineTo(0,rc.CenterPoint().y);
		pDC->LineTo(rc.right,rc.CenterPoint().y);
		break;
	case RIGHTARROW://�Ҽ�ͷ
		 pDC->MoveTo(0,rc.CenterPoint().y);
	     pDC->LineTo(rc.right,	rc.CenterPoint().y);
         pDC->LineTo(rc.right-wh.x,rc.CenterPoint().y-wh.y);
	     break;
    case DOUBLEARROW://˫��ͷ
		 pDC->MoveTo(wh.x,rc.CenterPoint().y-wh.y);	
	     pDC->LineTo(0,rc.CenterPoint().y);
	     pDC->LineTo(rc.right,	rc.CenterPoint().y);
         pDC->LineTo(rc.right-wh.x,rc.CenterPoint().y-wh.y);
	     break;
    case SINGELLINE://����
	     pDC->MoveTo(0,rc.CenterPoint().y);
	     pDC->LineTo(rc.right,	rc.CenterPoint().y);
	     break;
   case DOUBLELINE://˫��
	     pDC->MoveTo(0,rc.CenterPoint().y-FRAC_W);
	     pDC->LineTo(rc.right,	rc.CenterPoint().y-FRAC_W);
		 pDC->MoveTo(0,rc.CenterPoint().y+FRAC_W);
	     pDC->LineTo(rc.right,	rc.CenterPoint().y+FRAC_W);
	     break;
  	case ARC://Բ��
		 if (m_LabelLocation == TOPLABEL)
			pDC->Arc(CRect(rc.left,rc.top,rc.right,rc.bottom*2),CPoint(rc.right,rc.bottom),CPoint(rc.left,rc.bottom));
    	 if (m_LabelLocation == BOTTOMLABEL)
     	    pDC->Arc(CRect(rc.left,rc.top-rc.Height(),rc.right,rc.bottom),CPoint(rc.left,rc.top),CPoint(rc.right,rc.top));
		 break;	 
   case CURVE://������
	     POINT Points[4];
		 Points[0].x = 0;
		 Points[0].y = TempRect.CenterPoint().y;
         Points[1].x = TempRect.CenterPoint().x/2;
		 Points[1].y = TempRect.top;
		 Points[2].x = TempRect.CenterPoint().x/2*3;
		 Points[2].y = TempRect.bottom;
		 Points[3].x = TempRect.left;
		 Points[3].y = TempRect.CenterPoint().y;		 
	     pDC->PolyBezier(Points,4);
		 break;	 
   case SQUARE://������
	   if (m_LabelLocation == TOPLABEL)
	   {
			pDC->MoveTo(0,rc.bottom);
			pDC->LineTo(0,rc.CenterPoint().y);
			pDC->LineTo(rc.right,rc.CenterPoint().y);
			pDC->LineTo(rc.right,rc.bottom);
	   }
	   if (m_LabelLocation == BOTTOMLABEL)
	   {
			pDC->MoveTo(0,rc.top);
			pDC->LineTo(0,rc.CenterPoint().y);
			pDC->LineTo(rc.right,rc.CenterPoint().y);
			pDC->LineTo(rc.right,rc.top);
	   }
     break;	 
  case BRACKET://������
	    if (m_LabelLocation == TOPLABEL)
	   {
			POINT Points[4];
			Points[1].x = 0;
			Points[1].y = rc.top;
			Points[0].x = 0;
			Points[0].y = rc.bottom;
			Points[3].x = rc.CenterPoint().x;
			Points[3].y = rc.top;
			Points[2].x = rc.CenterPoint().x;
			Points[2].y = rc.bottom;		 
			pDC->PolyBezier(Points,4);
			Points[0].x = rc.CenterPoint().x;
			Points[0].y = rc.top;
			Points[1].x = rc.CenterPoint().x;
			Points[1].y = rc.bottom;
			Points[2].x = rc.right;
			Points[2].y = rc.top;
			Points[3].x = rc.right;
			Points[3].y = rc.bottom;		 
			pDC->PolyBezier(Points,4);
	   }
	   if (m_LabelLocation == BOTTOMLABEL)
	   {
			POINT Points[4];
			Points[0].x = 0;
			Points[0].y = rc.top;
			Points[1].x = 0;
			Points[1].y = rc.bottom;
			Points[2].x = rc.CenterPoint().x;
			Points[2].y = rc.top;
			Points[3].x = rc.CenterPoint().x;
			Points[3].y = rc.bottom;		 
			pDC->PolyBezier(Points,4);
			Points[1].x = rc.CenterPoint().x;
			Points[1].y = rc.top;
			Points[0].x = rc.CenterPoint().x;
			Points[0].y = rc.bottom;
			Points[3].x = rc.right;
			Points[3].y = rc.top;
			Points[2].x = rc.right;
			Points[2].y = rc.bottom;		 
			pDC->PolyBezier(Points,4);
	   }
	   break;
   case SHARPANGLE://�����
		pDC->MoveTo(rc.left,rc.bottom);
		pDC->LineTo(rc.CenterPoint().x,rc.top);
		pDC->LineTo(rc.right,rc.bottom);
		break;
	}
 	pDC->SelectObject(pOldPen);	
	//	��ʽ����
	m_formulaObj.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormLabel_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormLabel::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormLabArrow::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ��������CFormLabArrow���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

	int m_ArrowHeight = ARROWH*2;
    int dx = 2*m_ArrowHeight;
	COLORREF clr = RGB(0, 0, 0);
	//	set pen
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	////////////////////////////////////////
	int m_maxW = MAX(m_formulaeTop.m_rect.Width(),m_formulaeBot.m_rect.Width());
	CPoint Temp1(0,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
	CPoint Temp2(dx*2+m_maxW,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
	CPoint Temp3(Temp1.x+2*m_ArrowHeight,Temp1.y-m_ArrowHeight/2);
	CPoint Temp4(Temp1.x+2*m_ArrowHeight,Temp1.y+m_ArrowHeight/2);
	CPoint Temp5(Temp2.x-2*m_ArrowHeight,Temp2.y-m_ArrowHeight/2);
	CPoint Temp6(Temp2.x-2*m_ArrowHeight,Temp2.y+m_ArrowHeight/2);
	CPoint Temp7(Temp1.x+2*m_ArrowHeight,Temp1.y-m_ArrowHeight/4-m_ArrowHeight/2);
	CPoint Temp8(Temp2.x-2*m_ArrowHeight,Temp2.y+m_ArrowHeight/4+m_ArrowHeight/2);
	CRgn Rgn1,Rgn2;
	CBrush Brush;
	POINT TempSA1[4],TempSA2[4];
	switch (m_ArrowType)
	{
	case SOLIDARROW://����ʵ�ļ�ͷ˫ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp3);
		pDC->MoveTo(Temp4);
		pDC->LineTo(Temp1);
		pDC->LineTo(Temp2);
		pDC->LineTo(Temp5);
		pDC->MoveTo(Temp6);
		pDC->LineTo(Temp2);
		TempSA1[0].x = Temp1.x;
		TempSA1[0].y = Temp1.y;
		TempSA1[1].x = Temp3.x;
		TempSA1[1].y = Temp3.y;
		TempSA1[2].x = Temp4.x;
		TempSA1[2].y = Temp4.y;

		TempSA2[0].x = Temp2.x;
		TempSA2[0].y = Temp2.y;
		TempSA2[1].x = Temp5.x;
		TempSA2[1].y = Temp5.y;
		TempSA2[2].x = Temp6.x;
		TempSA2[2].y = Temp6.y;
		Brush.CreateSolidBrush(clr);
		Rgn1.CreatePolygonRgn(TempSA1,3,ALTERNATE); 
		Rgn2.CreatePolygonRgn(TempSA2,3,ALTERNATE); 
        pDC->FillRgn(&Rgn1,&Brush);
        pDC->FillRgn(&Rgn2, &Brush);
		Brush.DeleteObject();
 		break;
   	case LEFTSOLIDARROW://����ʵ�ļ�ͷ��ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp3);
		pDC->MoveTo(Temp4);
		pDC->LineTo(Temp1);
		pDC->LineTo(Temp2);
		TempSA1[0].x = Temp1.x;
		TempSA1[0].y = Temp1.y;
		TempSA1[1].x = Temp3.x;
		TempSA1[1].y = Temp3.y;
		TempSA1[2].x = Temp4.x;
		TempSA1[2].y = Temp4.y;
		Brush.CreateSolidBrush(clr);
		Rgn1.CreatePolygonRgn(TempSA1,3,ALTERNATE); 
        pDC->FillRgn(&Rgn1,&Brush);
		Brush.DeleteObject();
 		break;
	case RIGHTSOLIDARROW://����ʵ�ļ�ͷ��ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp2);
		pDC->LineTo(Temp5);
		pDC->MoveTo(Temp6);
		pDC->LineTo(Temp2);
		TempSA2[0].x = Temp2.x;
		TempSA2[0].y = Temp2.y;
		TempSA2[1].x = Temp5.x;
		TempSA2[1].y = Temp5.y;
		TempSA2[2].x = Temp6.x;
		TempSA2[2].y = Temp6.y;
		Brush.CreateSolidBrush(clr);
		Rgn2.CreatePolygonRgn(TempSA2,3,ALTERNATE); 
        pDC->FillRgn(&Rgn2, &Brush);
		Brush.DeleteObject();
 		break;
	case DOUBLEARROW://����ʵ�ļ�ͷ˫ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp3);
		pDC->MoveTo(Temp4);
		pDC->LineTo(Temp1);
		pDC->LineTo(Temp2);
		pDC->LineTo(Temp5);
		pDC->MoveTo(Temp6);
		pDC->LineTo(Temp2);
		break;
	case LEFTARROW://���߿��ļ�ͷ��ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp3);
		pDC->MoveTo(Temp4);
		pDC->LineTo(Temp1);
		pDC->LineTo(Temp2);
		break;
	case RIGHTARROW://���߿��ļ�ͷ��ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp2);
		pDC->LineTo(Temp5);
		pDC->MoveTo(Temp6);
		pDC->LineTo(Temp2);
		break;
	case SINGLELINE://����
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp2);
		break;
	case DOUBLELINE://˫��
		pDC->MoveTo(Temp1.x,Temp1.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/4);
		pDC->MoveTo(Temp1.x,Temp1.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/4);
		break;
	case HALFARROW://˫������ָ��
		pDC->MoveTo(Temp7);
		pDC->LineTo(Temp1.x,Temp1.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/4);
		pDC->MoveTo(Temp1.x,Temp1.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/4);
		pDC->LineTo(Temp8);
		break;	
	case HALFARROW2://˫������ָ��
		pDC->MoveTo(Temp1.x,Temp1.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-2*m_ArrowHeight,Temp2.y-m_ArrowHeight/4-m_ArrowHeight/2);
		pDC->MoveTo(Temp1.x+2*m_ArrowHeight,Temp1.y+m_ArrowHeight/4+m_ArrowHeight/2); 
		pDC->LineTo(Temp1.x,Temp1.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/4);
		break;
	case HOLLOW://˫��˫ָ��
	  	pDC->MoveTo(Temp1);
		pDC->LineTo(Temp3.x,Temp3.y-m_ArrowHeight/3);
		pDC->MoveTo(Temp4.x,Temp4.y+m_ArrowHeight/3);
		pDC->LineTo(Temp1);
		pDC->MoveTo(Temp2);
		pDC->LineTo(Temp5.x,Temp5.y-m_ArrowHeight/3);
		pDC->MoveTo(Temp6.x,Temp6.y+m_ArrowHeight/3);
		pDC->LineTo(Temp2);		 

		pDC->MoveTo(Temp1.x+FRAC_W*4,Temp1.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-FRAC_W*4,Temp2.y-m_ArrowHeight/4);
		pDC->MoveTo(Temp1.x+FRAC_W*4,Temp1.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-FRAC_W*4,Temp2.y+m_ArrowHeight/4);	  
	    break;
	case LEFTHOLLOW://˫����ָ��
		pDC->MoveTo(Temp1);
		pDC->LineTo(Temp3.x,Temp3.y-m_ArrowHeight/3);
		pDC->MoveTo(Temp4.x,Temp4.y+m_ArrowHeight/3);
		pDC->LineTo(Temp1);
		pDC->MoveTo(Temp1.x+FRAC_W*4,Temp1.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-FRAC_W*4,Temp2.y-m_ArrowHeight/4);
		pDC->MoveTo(Temp1.x+FRAC_W*4,Temp1.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-FRAC_W*4,Temp2.y+m_ArrowHeight/4);
		break; 
	case RIGHTHOLLOW://˫����ָ��
        pDC->MoveTo(Temp2);
		pDC->LineTo(Temp5.x,Temp5.y-m_ArrowHeight/3);
		pDC->MoveTo(Temp6.x,Temp6.y+m_ArrowHeight/3);
		pDC->LineTo(Temp2);		 

		pDC->MoveTo(Temp1.x+FRAC_W*4,Temp1.y-m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-FRAC_W*4,Temp2.y-m_ArrowHeight/4);
		pDC->MoveTo(Temp1.x+FRAC_W*4,Temp1.y+m_ArrowHeight/4);
		pDC->LineTo(Temp2.x-FRAC_W*4,Temp2.y+m_ArrowHeight/4);
	    break;
	case REVERSE://�������
		pDC->MoveTo(Temp1.x,Temp1.y-m_ArrowHeight/3);
		pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/3);
		pDC->LineTo(Temp2.x-m_ArrowHeight*3/2,Temp2.y-m_ArrowHeight/3-m_ArrowHeight/3);
		pDC->MoveTo(Temp2.x,Temp2.y-m_ArrowHeight/3);
		pDC->LineTo(Temp2.x-m_ArrowHeight*3/2,Temp2.y-m_ArrowHeight/3+m_ArrowHeight/3);
	
		pDC->MoveTo(Temp1.x+m_ArrowHeight*3/2,Temp2.y+m_ArrowHeight/3+m_ArrowHeight/3);
		pDC->LineTo(Temp1.x,Temp1.y+m_ArrowHeight/3);
		pDC->LineTo(Temp1.x+m_ArrowHeight*3/2,Temp2.y+m_ArrowHeight/3-m_ArrowHeight/3);	
		pDC->MoveTo(Temp1.x,Temp1.y+m_ArrowHeight/3);
		pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/3);
		break;
	}
	////////////////////////////////////////
	pDC->SelectObject(pOldPen);
	pDC->SetBkMode(nBkMode);
	//	���ö���
	m_formulaeTop.DrawShape(pDC, pICS);
	//	���ö���
	m_formulaeBot.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}

EX_SHAPE_API CFormLabArrow_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormLabArrow::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormPower::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CFormLabel ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

	COLORREF clr = RGB(0, 0, 0);
	//	set pen
	CPen* pOldPen;
	CPen pen(PS_SOLID, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
	//	set brush
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	//	��������
	int nFontH = (GetFS(m_nFSIndex-1)+5)/10;
	CFont* pOldFont = GetFontObj(pDC, nFontH, "����", CC_DISABLED,FW_NORMAL);
	CRect rc =CRect(CPoint(-nFontH/4, m_nHor-nFontH/2), CSize(nFontH,nFontH));
	int H = (GetFS(m_nFSIndex-1)+5)/10;
	if (nRingType == HAS_RING)
	{
		CRect rcTemp(H/4-H/7, m_nHor-H/7, H/4+H/7, m_nHor+H/7);
		pDC->Ellipse(rcTemp);
	}
	pDC->SetTextAlign(TA_LEFT|TA_BASELINE);
	pDC->TextOut(rc.left, rc.top+c_tmAscent, m_str);
	pDC->SelectObject(pOldFont);
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);	
	pDC->SetBkMode(nBkMode);
	//	��ʽ����
	m_formulaTop.DrawShape(pDC, pICS);
	m_formulaBot.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormPower_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormPower::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormIntegral::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formTB ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	COLORREF clr = RGB(0, 0, 0);
	//	set pen
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 3, clr);
	pOldPen = pDC->SelectObject(&pen);	
	//	set brush
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	//	���ö���
	m_formulaeTop.DrawShape(pDC, pICS);
	//	��������
	int nFontH = (GetFS(m_nFSIndex-1)+5)/10;
	CFont* pOldFont = GetFontObj(pDC, nFontH, "����", CC_DISABLED,FW_NORMAL);
	CRect rc = m_rectChar;
	int h= (GetFS(m_nFSIndex)+5)/10;
	CPoint temInterval(h/6,h/6);
	CPoint CenterP = rc.CenterPoint();
	pDC->SetTextAlign(TA_LEFT|TA_BASELINE);
	if (m_HowMany == 1)
	{	
		CPoint CenterP = rc.CenterPoint();
		CenterP.x += FRAC_W/2;
		CenterP.y += FRAC_W/2;
		if (m_ringed == 1)
		{
			CRect e_rect(CenterP.x-temInterval.x*3/2,CenterP.y-temInterval.x*3/2,CenterP.x+temInterval.x*3/2,CenterP.y+temInterval.x*3/2);
			pDC->Ellipse(&e_rect);
		}
		pDC->TextOut(rc.left, rc.top+c_tmAscent, m_str);
	}
	if (m_HowMany == 2)
	{	
		if (m_ringed == 1)
		{
			CRect e_rect(CenterP.x-temInterval.x*5/3,CenterP.y-temInterval.x*5/3,CenterP.x+temInterval.x*5/3,CenterP.y+temInterval.x*5/3);
			pDC->Ellipse(&e_rect);
		}
		pDC->TextOut(rc.left-temInterval.x*3/4, rc.top+c_tmAscent, m_str);
		pDC->TextOut(rc.left+temInterval.x*3/4, rc.top+c_tmAscent, m_str);
	}
	if (m_HowMany == 3)
	{	if (m_ringed == 1)
		{
			CRect e_rect(CenterP.x-temInterval.x*5/2,CenterP.y-temInterval.x*3/2,CenterP.x+temInterval.x*5/2,CenterP.y+temInterval.x*3/2);
			pDC->Ellipse(&e_rect);
		}
		pDC->TextOut(rc.left-temInterval.x*3/2, rc.top+c_tmAscent, m_str);
		pDC->TextOut(rc.left, rc.top+c_tmAscent, m_str);
		pDC->TextOut(rc.left+temInterval.x*3/2, rc.top+c_tmAscent, m_str);
	}

	pDC->SelectObject(pOldFont);
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);	
	pDC->SetBkMode(nBkMode);
	//	���ö���
	m_formulaeBot.DrawShape(pDC, pICS);
	//	��������
	m_formula.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormIntegral_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormIntegral::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormTMB::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formTB ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	//	���ö���
	m_formulaeTop.DrawShape(pDC, pICS);
	//	���ö���
	m_formulaeBot.DrawShape(pDC, pICS);
	//	�м�������
	m_formulaMid.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormTMB_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormTMB::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormTM::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formTB ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	//	���ö���
	m_formulaeTop.DrawShape(pDC, pICS);
	//	�м�������
	m_formulaMid.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormTM_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormTM::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormMB::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formTB ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	//	���ö���
	m_formulaeBot.DrawShape(pDC, pICS);
	//	�м�������
	m_formulaMid.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormMB_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormMB::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormFuntion::DrawBracket(CDC * pDC , IColorScheme* pICS, CPoint wh, CRect rct)
{
	int b = wh.y;
	int h = rct.Height();
	int w = rct.Width();

	switch (m_nLineKind) {
	case BK_ver://������
	{
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(wh.x,0);
			pDC->LineTo(wh.x,h);
		}
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
		{
    		pDC->MoveTo(w-wh.x,0);
			pDC->LineTo(w-wh.x,h);
		}
	}
	break;
	case BK_ver2://˫����
	{	//	set pen
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(wh.x,0);
			pDC->LineTo(wh.x,h);
			pDC->MoveTo(3*wh.x,0);
			pDC->LineTo(3*wh.x,h);
		}
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
		{
    		pDC->MoveTo(w-wh.x,0);
			pDC->LineTo(w-wh.x,h);
    		pDC->MoveTo(w-3*wh.x,0);
			pDC->LineTo(w-3*wh.x,h);
		}
	}
	break;
	case BK_jian://����߻�����
	{
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(wh.x*5,0);
			pDC->LineTo(0,h/2);
			pDC->LineTo(wh.x*5,h);
		}
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(w-wh.x*5,0);
			pDC->LineTo(w,h/2);
			pDC->LineTo(w-wh.x*5,h);
		}
	}
	break;
	case BK_bra://������
	{  	
		CPoint p[4];
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
		{
			p[0].x = wh.x*5;	p[0].y =0;
			p[1].x = 0;			p[1].y = 0;
			p[2].x = wh.x*5;	p[2].y = h/2;
			p[3].x = 0;			p[3].y = h/2;
			pDC->PolyBezier(p, 4);
			p[0].x = 0;			p[0].y = h/2;
			p[1].x = wh.x*5;	p[1].y = h/2;
			p[2].x = 0;			p[2].y = h;
			p[3].x = wh.x*5;	p[3].y =h;
			pDC->PolyBezier(p, 4);
		}
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
		{
			p[0].x = w-wh.x*5;	p[0].y =0;
			p[1].x = w;			p[1].y = 0;
			p[2].x = w-wh.x*5;	p[2].y = h/2;
			p[3].x = w;			p[3].y = h/2;
			pDC->PolyBezier(p, 4);
			p[0].x =w;			p[0].y = h/2;
			p[1].x = w-wh.x*5;	p[1].y = h/2;
			p[2].x = w;			p[2].y = h;
			p[3].x = w-wh.x*5;	p[3].y =h;
			pDC->PolyBezier(p, 4);
		}
	}
	break;
	case BK_arc://����
	{
		CRect rcArc(0,0, wh.x*12, h);	
		CPoint sp(wh.x*5,0);
		CPoint ep(wh.x*5,h);
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
			pDC->Arc(rcArc, sp, ep);
		rcArc.SetRect(w-wh.x*12, 0, w, h);
		CPoint sp2(w-wh.x*5,0);
		CPoint ep2(w-wh.x*5,h);
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
			pDC->Arc(rcArc, ep2, sp2);
	}
	break;
	case BK_squ://������
	{
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(wh.x*5,	0);
			pDC->LineTo(wh.x,	0);
			pDC->LineTo(wh.x,	h);
			pDC->LineTo(wh.x*5,	h);
		}
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(w-wh.x*5,0);
			pDC->LineTo(w-wh.x,0);
			pDC->LineTo(w-wh.x,h);
			pDC->LineTo(w-wh.x*5,	h);
		}
	}
	break;
	case BK_oblique://б������
	{
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
		{
			pDC->MoveTo(wh.x*5,0);
			pDC->LineTo(wh.x,wh.x*2);
			pDC->LineTo(wh.x,h-wh.x*2);
			pDC->LineTo(wh.x*5,h);
		}
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
		{
        	pDC->MoveTo(w-wh.x*5,0);
			pDC->LineTo(w-wh.x,wh.x*2);
			pDC->LineTo(w-wh.x,h-wh.x*2);
			pDC->LineTo(w-wh.x*5,h);		
		}
	}
	break;
/*	case BK_arc:
	{	//	set pen
		COLORREF color=pDC->GetPixel(CPoint (2,2));
		CPen* pOldPen;
		CPen pen(PS_SOLID, 0, RGB(0,0,0));
		pOldPen = pDC->SelectObject(&pen);	
		//	set brush
		CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(BLACK_BRUSH);
		double ddy4ddx = h*h + 4*b*b;
		int r = (int)(ddy4ddx/(8.0*b));
		CRect rcArc(0, h/2-r, 2*r, h/2+r);

		CPoint sp(b,0);
		CPoint ep(b,h);
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
			pDC->Chord(rcArc, sp, ep);
		rcArc.SetRect(w-2*r, h/2-r, w, h/2+r);
		CPoint sp2(w-b,0);
		CPoint ep2(w-b,h);
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
			pDC->Chord(rcArc, ep2, sp2);
		pDC->SelectObject(pOldPen);	
		pDC->SelectObject(pOldBrush);	

		CPen pn(PS_SOLID, 0, color);
		CBrush br(color);
		pOldPen = (CPen*)pDC->SelectObject(&pn);
		pOldBrush = (CBrush*)pDC->SelectObject(&br);
		int dd = b/4;
		ddy4ddx = h*h + 4*(b-dd)*(b-dd);
		r = (int)(ddy4ddx/(8.0*(b-dd)));
		CRect rcArc2(dd+1, h/2-r, 2*r, h/2+r);
		if (m_nOutputKind == BK_LEFT || m_nOutputKind == BK_ALL)
			pDC->Chord(rcArc2, sp, ep);
		rcArc2.SetRect(w-dd-1-2*r, h/2-r, w-dd-1, h/2+r);
		if (m_nOutputKind == BK_RIGHT || m_nOutputKind == BK_ALL)
			pDC->Chord(rcArc2, ep2, sp2);
		pDC->SelectObject(pOldPen);	
		pDC->SelectObject(pOldBrush);	
	}
	break;
*/
	case BK_null://����
		break;
	}
}

void CFormFuntion::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);
	CPoint pt=pDC->GetViewportOrg();
	rct.OffsetRect(-pt);
	//	ԭ�������� formMatr ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	//	����Χ��
	int w = (GetFS(m_nFSIndex)+5)/10;
	CPoint wh(1,w/2);
	COLORREF clr = RGB(0, 0, 0);
	//	set pen
	CPen* pOldPen;
	CPen pen(PS_SOLID, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
	CFormFuntion::DrawBracket(pDC, pICS, wh, m_rect);
	pDC->SelectObject(pOldPen);	
	m_form.DrawShape(pDC, pICS);
	pDC->SetViewportOrg(pt);
	RefreshFS();
}
EX_SHAPE_API CFormFuntion_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormFuntion::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CChemLink::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CChemLink ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	COLORREF clr = RGB(0, 0, 0);
	//	set pen
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
	for(int i=0;i<8;i++)
	{
		switch(i)
		{
		case EAST:
			 if (m_nBondData[0] == SINGLE)
			 { 
				 CPoint temP1(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.CenterPoint().y);
				 CPoint temP2(m_rect.Width(),m_ChemBondObj.m_rect.CenterPoint().y);
				 pDC->MoveTo(temP1);
				 pDC->LineTo(temP2);
			 }
			 if (m_nBondData[0] == DOUBLE)
			 {
				 CPoint temP1(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W);
				 CPoint temP2(m_rect.Width(),m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W);
				 CPoint temP3(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W);
				 CPoint temP4(m_rect.Width(),m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W);
				 pDC->MoveTo(temP1);
				 pDC->LineTo(temP2);
				 pDC->MoveTo(temP3);
				 pDC->LineTo(temP4);
			 }
			 if (m_nBondData[0] == THREE)
			 {
				 CPoint temP1(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W*5/2);
				 CPoint temP2(m_rect.Width(),m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W*5/2);
				 CPoint temP3(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.CenterPoint().y);
				 CPoint temP4(m_rect.Width(),m_ChemBondObj.m_rect.CenterPoint().y);
				 CPoint temP5(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W*2);
				 CPoint temP6(m_rect.Width(),m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W*2);
				 pDC->MoveTo(temP1);
				 pDC->LineTo(temP2);
				 pDC->MoveTo(temP3);
				 pDC->LineTo(temP4);
				 pDC->MoveTo(temP5);
				 pDC->LineTo(temP6);
			 }		 
			 break;
		case EAST_SOUTH:
			if (m_nBondData[1] == SINGLE)
			 {   
				CPoint temP1(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.bottom);
				CPoint temP2(m_rect.Width(),m_rect.Height());
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[1] == DOUBLE)
			 {
				 CPoint temP1(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.bottom+INTERVAL);
				 CPoint temP2(m_rect.Width()-INTERVAL,m_rect.Height());
				 CPoint temP3(m_ChemBondObj.m_rect.right+INTERVAL,m_ChemBondObj.m_rect.bottom);
				 CPoint temP4(m_rect.Width(),m_rect.Height()-INTERVAL);
				 pDC->MoveTo(temP1);
				 pDC->LineTo(temP2);
				 pDC->MoveTo(temP3);
				 pDC->LineTo(temP4);
			 }
			 if (m_nBondData[1] == THREE)
			 {
				 CPoint temP1(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.bottom+INTERVAL*3/2);
				 CPoint temP2(m_rect.Width()-INTERVAL*3/2,m_rect.Height());
				 CPoint temP3(m_ChemBondObj.m_rect.right+FRAC_W*3/2,m_ChemBondObj.m_rect.bottom+FRAC_W*3/2);
				 CPoint temP4(m_rect.Width()-FRAC_W*3/2,m_rect.Height()-FRAC_W*3/2);
				 CPoint temP5(m_ChemBondObj.m_rect.right+INTERVAL*3/2,m_ChemBondObj.m_rect.bottom);
				 CPoint temP6(m_rect.Width(),m_rect.Height()-INTERVAL*3/2);
				 pDC->MoveTo(temP1);
				 pDC->LineTo(temP2);
				 pDC->MoveTo(temP3);
				 pDC->LineTo(temP4);
				 pDC->MoveTo(temP5);
				 pDC->LineTo(temP6);
			 }
	   		 break;
		case SOUTH:
			if (m_nBondData[2] == SINGLE)
			 {
				CPoint temP1(m_ChemBondObj.m_rect.CenterPoint().x,m_ChemBondObj.m_rect.bottom);
				CPoint temP2(m_ChemBondObj.m_rect.CenterPoint().x,m_rect.Height());
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[2] == DOUBLE)
			 {
				CPoint temP1(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W,m_ChemBondObj.m_rect.bottom);
				CPoint temP2(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W,m_rect.Height());
				CPoint temP3(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3/2,m_ChemBondObj.m_rect.bottom);
				CPoint temP4(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3/2,m_rect.Height());
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
			 }
			 if (m_nBondData[2] == THREE)
			 {
				CPoint temP1(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W*5/2,m_ChemBondObj.m_rect.bottom);
				CPoint temP2(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W*5/2,m_rect.Height());
				CPoint temP3(m_ChemBondObj.m_rect.CenterPoint().x,m_ChemBondObj.m_rect.bottom);
				CPoint temP4(m_ChemBondObj.m_rect.CenterPoint().x,m_rect.Height());
				CPoint temP5(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3,m_ChemBondObj.m_rect.bottom);
				CPoint temP6(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3,m_rect.Height());
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
				pDC->MoveTo(temP5);
				pDC->LineTo(temP6);
			 }
			break;
		case SOUTH_WEST:
			if (m_nBondData[3] == SINGLE)
			 {  
				CPoint temP1(0,m_rect.Height());
				CPoint temP2(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.bottom);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[3] == DOUBLE)
			 {
				CPoint temP1(0,m_rect.Height()-INTERVAL);
				CPoint temP2(m_ChemBondObj.m_rect.left-INTERVAL,m_ChemBondObj.m_rect.bottom);
				CPoint temP3(INTERVAL,m_rect.Height());
				CPoint temP4(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.bottom+INTERVAL);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
			 }
			 if (m_nBondData[3] == THREE)
			 {
				CPoint temP1(0,m_rect.Height()-INTERVAL*3/2);
				CPoint temP2(m_ChemBondObj.m_rect.left-INTERVAL*3/2,m_ChemBondObj.m_rect.bottom);
				CPoint temP3(FRAC_W*3/2,m_rect.Height()-FRAC_W*3/2);
				CPoint temP4(m_ChemBondObj.m_rect.left-FRAC_W*3/2,m_ChemBondObj.m_rect.bottom+FRAC_W*3/2);
				CPoint temP5(INTERVAL*3/2,m_rect.Height());
				CPoint temP6(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.bottom+INTERVAL*3/2);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
				pDC->MoveTo(temP5);
				pDC->LineTo(temP6);
			 }
			break;
		case WEST:
			if (m_nBondData[4] == SINGLE)
			 {
				CPoint temP1(0,m_ChemBondObj.m_rect.CenterPoint().y);
				CPoint temP2(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.CenterPoint().y);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[4] == DOUBLE)
			 {
				CPoint temP1(0,m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W);
				CPoint temP2(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W);
				CPoint temP3(0,m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W);
				CPoint temP4(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
			 }
			 if (m_nBondData[4] == THREE)
			 {
				CPoint temP1(0,m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W*5/2);
				CPoint temP2(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.CenterPoint().y-FRAC_W*5/2);
				CPoint temP3(0,m_ChemBondObj.m_rect.CenterPoint().y);
				CPoint temP4(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.CenterPoint().y);
				CPoint temP5(0,m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W*2);
				CPoint temP6(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.CenterPoint().y+FRAC_W*2);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
				pDC->MoveTo(temP5);
				pDC->LineTo(temP6);
			 }
			break;
		case WEST_NORTH:
			if (m_nBondData[5] == SINGLE)
			 {   
				CPoint temP1(0,0);
				CPoint temP2(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[5] == DOUBLE)
			 {
				CPoint temP1(0,INTERVAL);
				CPoint temP2(m_ChemBondObj.m_rect.left-INTERVAL,m_ChemBondObj.m_rect.top);
				CPoint temP3(INTERVAL,0);
				CPoint temP4(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.top-INTERVAL);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
			 }
			 if (m_nBondData[5] == THREE)
			 {
				CPoint temP1(0,INTERVAL*3/2);
				CPoint temP2(m_ChemBondObj.m_rect.left-INTERVAL*3/2,m_ChemBondObj.m_rect.top);
				CPoint temP3(FRAC_W*3/2,FRAC_W*3/2);
				CPoint temP4(m_ChemBondObj.m_rect.left-FRAC_W*3/2,m_ChemBondObj.m_rect.top-FRAC_W*3/2);
				CPoint temP5(INTERVAL*3/2,0);
				CPoint temP6(m_ChemBondObj.m_rect.left,m_ChemBondObj.m_rect.top-INTERVAL*3/2);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
				pDC->MoveTo(temP5);
				pDC->LineTo(temP6);
			 }
			break;
		case NORTH:
			if (m_nBondData[6] == SINGLE)
			 {   
				CPoint temP1(m_ChemBondObj.m_rect.CenterPoint().x,0);
				CPoint temP2(m_ChemBondObj.m_rect.CenterPoint().x,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[6] == DOUBLE)
			 {
				CPoint temP1(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W,0);
				CPoint temP2(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W,m_ChemBondObj.m_rect.top);
				CPoint temP3(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3/2,0);
				CPoint temP4(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3/2,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
			 }
			 if (m_nBondData[6] == THREE)
			 {
				CPoint temP1(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W*5/2,0);
				CPoint temP2(m_ChemBondObj.m_rect.CenterPoint().x-FRAC_W*5/2,m_ChemBondObj.m_rect.top);
				CPoint temP3(m_ChemBondObj.m_rect.CenterPoint().x,0);
				CPoint temP4(m_ChemBondObj.m_rect.CenterPoint().x,m_ChemBondObj.m_rect.top);
				CPoint temP5(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3,0);
				CPoint temP6(m_ChemBondObj.m_rect.CenterPoint().x+FRAC_W*3,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
				pDC->MoveTo(temP5);
				pDC->LineTo(temP6);
			 }
			break;
		case NORTH_EAST:
			if (m_nBondData[7] == SINGLE)
			 {
				CPoint temP1(m_rect.Width(),0);
				CPoint temP2(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
			 }
			 if (m_nBondData[7] == DOUBLE)
			 {
				CPoint temP1(m_rect.Width()-INTERVAL,0);
				CPoint temP2(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.top-INTERVAL);
				CPoint temP3(m_rect.Width(),INTERVAL);
				CPoint temP4(m_ChemBondObj.m_rect.right+INTERVAL,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
			 }
			 if (m_nBondData[7] == THREE)
			 {
				CPoint temP1(m_rect.Width()-INTERVAL*3/2,0);
				CPoint temP2(m_ChemBondObj.m_rect.right,m_ChemBondObj.m_rect.top-INTERVAL*3/2);
				CPoint temP3(m_rect.Width()-FRAC_W*3/2,FRAC_W*3/2);
				CPoint temP4(m_ChemBondObj.m_rect.right+FRAC_W*3/2,m_ChemBondObj.m_rect.top-FRAC_W*3/2);
				CPoint temP5(m_rect.Width(),INTERVAL*3/2);
				CPoint temP6(m_ChemBondObj.m_rect.right+INTERVAL*3/2,m_ChemBondObj.m_rect.top);
				pDC->MoveTo(temP1);
				pDC->LineTo(temP2);
				pDC->MoveTo(temP3);
				pDC->LineTo(temP4);
				pDC->MoveTo(temP5);
				pDC->LineTo(temP6);
			 }
			break;
		default:
			ASSERT(FALSE);
		}
	}
 	pDC->SelectObject(pOldPen);	
	//	��ʽ����
	m_ChemBondObj.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CChemLink_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CChemLink::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

int CChemRing::GetPositionNum(int nPosition)
{
	int temPosition=0;
	for(int i=0;i<nPosition;i++)
		if (m_nElem[i] == 1)
			temPosition++;

	return temPosition;
}

void CChemRing::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formMatr ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	int nW =FRAC_W;
	int FontW = (GetFS(m_nFSIndex)+5)/10;

	COLORREF clr = RGB(0, 0, 0);

	//	set pen
	CPen* pOldPen;
	CPen pen(PS_SOLID, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	

	CPoint  point0,point1,point2,point3,point4,point5;
	CPoint  point6,point7,point8,point9,point10,point11;

	int nTopBotMaxW=0,nTopWidth,nBotWidth;
	if (m_nElem[0] == 1&&m_nElem[3] == 1)
	{	
		nTopBotMaxW=MAX(((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.Width(),((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.Width());
		nTopWidth=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.Width();
		nBotWidth=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.Width();
	}
	else
	{	 if (m_nElem[0] == 1)
		{
			nTopBotMaxW=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.Width();
			nTopWidth=nTopBotMaxW;
		}
		if (m_nElem[3] == 1)
		{	
			nTopBotMaxW=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.Width();
			nBotWidth=nTopBotMaxW;
		}
	}
	int  nLeftMaxW=0;
	if (m_nElem[1] == 1&&m_nElem[2] == 1)
		nLeftMaxW=MAX(((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.Width(),((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.Width());
	else
	{	
		if (m_nElem[1] == 1)
			nLeftMaxW=((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.Width();
		if (m_nElem[2] == 1)
			nLeftMaxW=((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.Width();
	}
	int  nRightMaxW=0;
	if (m_nElem[4] == 1&&m_nElem[5] == 1)
		nRightMaxW=MAX(((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.Width(),((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.Width());
	else
	{	
		if (m_nElem[4] == 1)
 			nRightMaxW=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.Width();
		if (m_nElem[5] == 1)
			nRightMaxW=((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.Width();
	}

	int nLMaxH=0,nRMaxH=0,nMaxH=0;
	if (m_nElem[4] == 1&&m_nElem[5] == 1)
		nRMaxH=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.Height()+((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.Height();
	else
	{	
		if (m_nElem[4] == 1)
			nRMaxH=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.Height();
		if (m_nElem[5] == 1)
			nRMaxH=((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.Height();
	}	

	if (m_nElem[1] == 1&&m_nElem[2] == 1)
		nLMaxH=((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.Height()+((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.Height();
	else
	{	
		if (m_nElem[1] == 1)
			nLMaxH=((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.Height();
		if (m_nElem[2] == 1)
			nLMaxH=((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.Height();
	}
	nMaxH=MAX(nLMaxH,nRMaxH);

	if (m_nElem[0] == 1)
	{	
		point0.x=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.left;
		point0.y=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.top+FontW/3;
		point11.x=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.right;
		point11.y=point0.y;
	}
	else
	{	
		if (m_nElem[3] == 1)
			point0.x=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.CenterPoint().x;
		else 
		{	
			point0.x=nLeftMaxW+FontW/3;
			if (nLeftMaxW == 0)
				point0.x=FontW*7/12;
		}
		point0.y=m_rect.Height();
		point11.x=point0.x;
		point11.y=point0.y;
	}
	if (m_nElem[1] == 1)
	{	
		point1.y=((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.bottom;
		point1.x=nLeftMaxW-FontW/3;
       	point2.x=point1.x;
		point2.y=((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.top;
	}
	else
	{ 	
		if (m_nElem[2] == 1)
			point1.x=((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.right-FontW/3;
		else
		    point1.x=0;
		if (m_nElem[0] == 1)
			point1.y=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.top-FontW/6;
      	else
		 	point1.y=m_rect.Height()-FontW/2;
     	point2=point1;
		 
	}

	if (m_nElem[2] == 1)
	{	
		point3.y=((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.bottom;
		point3.x=((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.right-FontW/3;
		point4.x=point3.x;
		point4.y=((CWPSObj*)m_objArray[GetPositionNum(2)])->m_rect.top;
	}
	else
	{ 	
		if (m_nElem[1] == 1)
			point3.x=((CWPSObj*)m_objArray[GetPositionNum(1)])->m_rect.right-FontW/3;
		else
		  	 point3.x=0;
		if (m_nElem[3] == 1)
			point3.y=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.bottom+FontW/6;
	   	 else
			point3.y=FontW/2;
		point4.x=point3.x;
		point4.y=point3.y;
	}

	if (m_nElem[3] == 1)
	{	
		point5.x=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.left;
		point5.y=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.bottom-FontW/2;
		point6.x=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.right;
		point6.y=point5.y;
	}
	else
	{    
		if (m_nElem[0] == 1)
			point5.x=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.CenterPoint().x;
		else 
		{
			point5.x=nLeftMaxW+FontW/3;
	    	if (nLeftMaxW == 0)
			  point5.x=FontW*7/12;
		}
		point5.y=0;
		point6.x=point5.x;
	   	point6.y=point5.y;
	}

	if (m_nElem[4] == 1)
	{	
		point7.x=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.left+FontW/3;
		point7.y=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.top;
		point8.x=point7.x;
		point8.y=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.bottom;
	}
	else
	{	
		if (m_nElem[5] == 1)
			point7.x=((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.left+FontW/3;
		else
			point7.x=m_rect.Width();
		if (m_nElem[3] == 1)
			point7.y=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.bottom+FontW/6;
       else
			point7.y=FontW/2;
		point8.x=point7.x;
		point8.y=point7.y;
 	}

	if (m_nElem[5] == 1)
	{	
		point9.x=((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.left+FontW/3;
		point9.y=((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.top;
		point10.x=point9.x;
		point10.y=((CWPSObj*)m_objArray[GetPositionNum(5)])->m_rect.bottom;
	}
	else
	{	
		if (m_nElem[4] == 1)
			point9.x=((CWPSObj*)m_objArray[GetPositionNum(4)])->m_rect.left+FontW/3;
		else
			point9.x=m_rect.Width();
		if (m_nElem[0] == 1)
			point9.y=((CWPSObj*)m_objArray[GetPositionNum(0)])->m_rect.top-FontW/6;
       else
			point9.y=m_rect.Height()-FontW/2;
		point10.x=point9.x;
		point10.y=point9.y;	
	}
	CPoint CenterP;
	if (nLeftMaxW!=0)
		CenterP.x=nLeftMaxW+FontW/3+nTopBotMaxW/2;
	else
		CenterP.x=FontW*2/3+nTopBotMaxW/2;
	if (m_nElem[3] == 1)
	{
		int nTopHeight=((CWPSObj*)m_objArray[GetPositionNum(3)])->m_rect.Height();
		CenterP.y=nTopHeight-FontW/3+nMaxH/2+FontW;
	}
	else
		CenterP.y=nMaxH/2+FontW;

	int h=FRAC_W*4,dx,dy,nHor,nVer;
	dx=point0.x-point1.x;
	dy=point0.y-point1.y;
	nHor=(int)(h*sqrt(dx*dx+dy*dy)/dy);
	nVer=(int)(h*sqrt(dx*dx+dy*dy)/dx);
	CPoint dpoint0(point0.x,point0.y-nVer),dpoint1(point1.x+nHor,point1.y);
	CPoint dpoint2(point2.x+h,point2.y-FRAC_W*2),dpoint3(point3.x+h,point3.y+FRAC_W*2);
	dx=point5.x-point4.x;
	dy=point4.y-point5.y;
	nVer=(int)(h*sqrt(dx*dx+dy*dy)/dx);
	nHor=(int)(h*sqrt(dx*dx+dy*dy)/dy);
	CPoint dpoint5(point5.x,point5.y+nVer),dpoint4(point4.x+nHor,point4.y);

	dx=point7.x-point6.x;
	dy=point7.y-point6.y;
	nHor=(int)(h*sqrt(dx*dx+dy*dy)/dy);
	nVer=(int)(h*sqrt(dx*dx+dy*dy)/dx);
	CPoint dpoint6(point6.x,point6.y+nVer),dpoint7(point7.x-nHor,point7.y);
	CPoint dpoint8(point8.x-h,point8.y+FRAC_W*2),dpoint9(point9.x-h,point9.y-FRAC_W*2);

	dx=point10.x-point11.x;
	dy=point11.y-point10.y;
	nVer=(int)(h*sqrt(dx*dx+dy*dy)/dx);
	nHor=(int)(h*sqrt(dx*dx+dy*dy)/dy);
	CPoint dpoint10(point10.x-nHor,point10.y),dpoint11(point11.x,point11.y-nVer);
	if (m_nBondData[0] == 2)
	{
		pDC->MoveTo(dpoint0);
		pDC->LineTo(dpoint1);
	}	
	if (m_nBondData[1] == 2)
	{
		pDC->MoveTo(dpoint2);
		pDC->LineTo(dpoint3);
	}
	if (m_nBondData[2] == 2)
	{
		pDC->MoveTo(dpoint4);
		pDC->LineTo(dpoint5);
	}
	if (m_nBondData[3] == 2)
	{
		pDC->MoveTo(dpoint6);
		pDC->LineTo(dpoint7);
	}
	if (m_nBondData[4] == 2)
	{
		pDC->MoveTo(dpoint8);
		pDC->LineTo(dpoint9);	
	}
	if (m_nBondData[5] == 2)
	{
		pDC->MoveTo(dpoint10);
		pDC->LineTo(dpoint11);	
	}
	if (m_nBondData[0] == 1||m_nBondData[0] == 2)
	{
		pDC->MoveTo(point0);
		pDC->LineTo(point1);
	}
	if (m_nBondData[1] == 1||m_nBondData[1] == 2)
	{
		pDC->MoveTo(point2);
		pDC->LineTo(point3);
	}
	if (m_nBondData[2] == 1||m_nBondData[2] == 2)
	{
		pDC->MoveTo(point4);
		pDC->LineTo(point5);
	}
	if (m_nBondData[3] == 1||m_nBondData[3] == 2)
	{
		pDC->MoveTo(point6);
		pDC->LineTo(point7);
	}
	if (m_nBondData[4] == 1||m_nBondData[4] == 2)
	{	
		pDC->MoveTo(point8);
		pDC->LineTo(point9);
	}
	if (m_nBondData[5] == 1||m_nBondData[5] == 2)
	{	
		pDC->MoveTo(point10);
		pDC->LineTo(point11);
	}
	
	if (m_nCenterCirKind == 2)
	{	
		COLORREF clr = RGB(0, 0, 0);

		CPen temPen(PS_DOT,1, clr);
		CPen* ptemOldPen = pDC->SelectObject(&temPen);
		pDC->Ellipse(CRect(CenterP.x-6,CenterP.y-6,CenterP.x+6,CenterP.y+6));
		pDC->SelectObject(ptemOldPen);
	}
	if (m_nCenterCirKind == 1)
		pDC->Ellipse(CRect(CenterP.x-6,CenterP.y-6,CenterP.x+6,CenterP.y+6));
	pDC->SelectObject(pOldPen);	

	CWPSObj* pObj;
	for (int n=0; n<m_nRingNum; n++)
	{	
		pObj = (CWPSObj*)m_objArray[n];
		pObj->DrawShape(pDC, pICS);
	}
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CChemRing_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CChemRing::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CChemLogogram::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CChemLogogram ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

	COLORREF clr = RGB(0, 0, 0);

	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	CPoint point1,point2,point3,point4,point5,point6,point7,point8,point9,point10,point11,point12;
	switch(m_nWhatKind)
	{
		case THREE_EDGE://������
		{	
			point1=CPoint(0,m_rect.Height()-FRAC_W*2);
			point2=CPoint(m_rect.Width(),m_rect.Height()-FRAC_W*2);
			point3=CPoint(m_rect.Width()/2,0);
			point4=CPoint(0,m_rect.Height()-FRAC_W*2);
			pDC->MoveTo(point1);
			pDC->LineTo(point2);
			pDC->LineTo(point3);
			pDC->LineTo(point4);
			break;
		}
		case FOUR_EDGE://�ı���
		{	CRect temRect(FRAC_W*2,FRAC_W*2,m_rect.Width()-FRAC_W*2,m_rect.Height()-FRAC_W*2);
			pDC->Rectangle(temRect);
			break;
		}
		case FIVE_EDGE_B://���������
		{
			point1=CPoint(m_rect.Width()/2,m_rect.Height());
			point2=CPoint(m_rect.Width()-FRAC_W*3,m_rect.Height()/2);
			point3=CPoint(m_rect.Width()-FRAC_W*3,FRAC_W*2);
			point4=CPoint(FRAC_W*3,FRAC_W*2);
			point5=CPoint(FRAC_W*3,m_rect.Height()/2);
			if (m_nBondData[0]!=0)
			{
				pDC->MoveTo(point1);
				pDC->LineTo(point2);
			}
			if (m_nBondData[1]!=0)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[2]!=0)
			{	
				pDC->MoveTo(point3);
				pDC->LineTo(point4);
			}
			if (m_nBondData[3]!=0)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[4]!=0)
			{	
				pDC->MoveTo(point5);
				pDC->LineTo(point1);
			}

			point1=CPoint(m_rect.Width()/2,m_rect.Height()-FRAC_W*4);
			point2=CPoint(m_rect.Width()-FRAC_W*5,m_rect.Height()/2-FRAC_W);
			point3=CPoint(m_rect.Width()-FRAC_W*5,FRAC_W*4);
			point4=CPoint(FRAC_W*5,FRAC_W*4);
			point5=CPoint(FRAC_W*5,m_rect.Height()/2-FRAC_W);
			if (m_nBondData[0] == 2)
			{
				pDC->MoveTo(point1);
				pDC->LineTo(point2);
			}
			if (m_nBondData[1] == 2)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[2] == 2)
			{	
				pDC->MoveTo(point3);
				pDC->LineTo(point4);
			}
			if (m_nBondData[3] == 2)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[4] == 2)
			{	
				pDC->MoveTo(point5);
				pDC->LineTo(point1);
			}
			
			break;
		}
		case FIVE_EDGE_T://���������
		{
			point1=CPoint(FRAC_W*3,m_rect.Height()-FRAC_W*2);
			point2=CPoint(m_rect.Width()-FRAC_W*3,m_rect.Height()-FRAC_W*2);
			point3=CPoint(m_rect.Width()-FRAC_W*3,m_rect.Height()/2);
			point4=CPoint(m_rect.Width()/2,0);
			point5=CPoint(FRAC_W*3,m_rect.Height()/2);
			if (m_nBondData[0]!=0)
			{	
				pDC->MoveTo(point1);
				pDC->LineTo(point2);
			}
			if (m_nBondData[1]!=0)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[2]!=0)
			{	
				pDC->MoveTo(point3);
				pDC->LineTo(point4);
			}
			if (m_nBondData[3]!=0)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[4]!=0)
			{	
				pDC->MoveTo(point5);
				pDC->LineTo(point1);
			}

			point1=CPoint(FRAC_W*5,m_rect.Height()-FRAC_W*4);
			point2=CPoint(m_rect.Width()-FRAC_W*5,m_rect.Height()-FRAC_W*4);
			point3=CPoint(m_rect.Width()-FRAC_W*5,m_rect.Height()/2+FRAC_W);
			point4=CPoint(m_rect.Width()/2,FRAC_W*4);
			point5=CPoint(FRAC_W*5,m_rect.Height()/2+FRAC_W);
			if (m_nBondData[0] == 2)
			{	
				pDC->MoveTo(point1);
				pDC->LineTo(point2);
			}
			if (m_nBondData[1] == 2)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[2] == 2)
			{	
				pDC->MoveTo(point3);
				pDC->LineTo(point4);
			}
			if (m_nBondData[3] == 2)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[4] == 2)
			{
				pDC->MoveTo(point5);
				pDC->LineTo(point1);
			}
			
			break;
		}
		case D_SIX_EDGE_VER:
		case D_LONG_SIX_EDGE_VER:
		{
			point5=CPoint(FRAC_W*2,m_rect.Height()/4);
			point6=CPoint(FRAC_W*2,m_rect.Height()*3/4);
			point1=CPoint(m_rect.Width()/2,m_rect.Height());
			point2=CPoint(m_rect.Width()-FRAC_W*2,m_rect.Height()*3/4);
			point3=CPoint(m_rect.Width()-FRAC_W*2,m_rect.Height()/4);
			point4=CPoint(m_rect.Width()/2,0);

			if (m_nBondData[0]!=0)
			{
				pDC->MoveTo(point1);
				pDC->LineTo(point2);
			}
			if (m_nBondData[1]!=0)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[2]!=0)
			{	
				pDC->MoveTo(point3);
				pDC->LineTo(point4);
			}
			if (m_nBondData[3]!=0)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[4]!=0)
			{	
				pDC->MoveTo(point5);
				pDC->LineTo(point6);
			}
			if (m_nBondData[5]!=0)
			{	
				pDC->MoveTo(point6);
				pDC->LineTo(point1);
			}
			//������Щ�����/��1��Ϊ�˼�С���
			point1=CPoint(m_rect.Width()/2,m_rect.Height()-FRAC_W*3-1);
			point2=CPoint(m_rect.Width()/2,m_rect.Height()-FRAC_W*3-1);
			point3=CPoint(m_rect.Width()-FRAC_W*4-1,m_rect.Height()*3/4-FRAC_W*2);
			point4=CPoint(m_rect.Width()-FRAC_W*4-1,m_rect.Height()*3/4-FRAC_W*2);
			point5=CPoint(m_rect.Width()-FRAC_W*4-1,m_rect.Height()/4+FRAC_W*2);
			point6=CPoint(m_rect.Width()-FRAC_W*4-1,m_rect.Height()/4+FRAC_W*2-1);
			point7=CPoint(m_rect.Width()/2,FRAC_W*3);
			point8=CPoint(m_rect.Width()/2,FRAC_W*3);
			point9=CPoint(FRAC_W*4+1,m_rect.Height()/4+FRAC_W*2);
			point10=CPoint(FRAC_W*4+1,m_rect.Height()/4+FRAC_W*2);
			point11=CPoint(FRAC_W*4+1,m_rect.Height()*3/4-FRAC_W*2);
			point12=CPoint(FRAC_W*4+1,m_rect.Height()*3/4-FRAC_W*2+1);

			if (m_nBondData[0] == 2)
			{
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[1] == 2)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[2] == 2)
			{	
				pDC->MoveTo(point6);
				pDC->LineTo(point7);
			}
			if (m_nBondData[3] == 2)
			{	
				pDC->MoveTo(point8);
				pDC->LineTo(point9);
			}
			if (m_nBondData[4] == 2)
			{	
				pDC->MoveTo(point10);
				pDC->LineTo(point11);
			}
			if (m_nBondData[5] == 2)
			{	
				pDC->MoveTo(point12);
				pDC->LineTo(point1);
			}
			break;
		}
		case D_SIX_EDGE_HORI:
		case D_LONG_SIX_EDGE_HORI:
		{
			point5=CPoint(m_rect.Width()/4,FRAC_W*2);
			point6=CPoint(0,m_rect.Height()/2);
			point1=CPoint(m_rect.Width()/4,m_rect.Height()-FRAC_W*2);
			point2=CPoint(m_rect.Width()*3/4,m_rect.Height()-FRAC_W*2);
			point3=CPoint(m_rect.Width(),m_rect.Height()/2);
			point4=CPoint(m_rect.Width()*3/4,FRAC_W*2);

			if (m_nBondData[0]!=0)
			{
				pDC->MoveTo(point1);
				pDC->LineTo(point2);
			}
			if (m_nBondData[1]!=0)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[2]!=0)
			{	
				pDC->MoveTo(point3);
				pDC->LineTo(point4);
			}
			if (m_nBondData[3]!=0)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[4]!=0)
			{	
				pDC->MoveTo(point5);
				pDC->LineTo(point6);
			}
			if (m_nBondData[5]!=0)
			{	
				pDC->MoveTo(point6);
				pDC->LineTo(point1);
			}
			point1=CPoint(m_rect.Width()/4+FRAC_W*2,m_rect.Height()-FRAC_W*4);
			point2=CPoint(m_rect.Width()/4+FRAC_W*2,m_rect.Height()-FRAC_W*5+1);
			point3=CPoint(m_rect.Width()*3/4-FRAC_W*2,m_rect.Height()-FRAC_W*5+1);
			point4=CPoint(m_rect.Width()*3/4-FRAC_W*2,m_rect.Height()-FRAC_W*4);
			point5=CPoint(m_rect.Width()-FRAC_W*3*m_rect.Width()/m_rect.Height()-1,m_rect.Height()/2-FRAC_W/2);
			point6=CPoint(m_rect.Width()-FRAC_W*3*m_rect.Width()/m_rect.Height()-1,m_rect.Height()/2-FRAC_W/2);
			point7=CPoint(m_rect.Width()*3/4-FRAC_W*2,FRAC_W*4);
			point8=CPoint(m_rect.Width()*3/4-FRAC_W*2,FRAC_W*5-1);
			point9=CPoint(m_rect.Width()/4+FRAC_W*2,FRAC_W*5-1);
			point10=CPoint(m_rect.Width()/4+FRAC_W*2,FRAC_W*4);
			point11=CPoint(FRAC_W*3*m_rect.Width()/m_rect.Height()+1 ,m_rect.Height()/2-FRAC_W/2);
			point12=CPoint(FRAC_W*3*m_rect.Width()/m_rect.Height()+1 ,m_rect.Height()/2-FRAC_W/2);

			if (m_nBondData[0] == 2)
			{	
				pDC->MoveTo(point2);
				pDC->LineTo(point3);
			}
			if (m_nBondData[1] == 2)
			{	
				pDC->MoveTo(point4);
				pDC->LineTo(point5);
			}
			if (m_nBondData[2] == 2)
			{	
				pDC->MoveTo(point6);
				pDC->LineTo(point7);
			}
			if (m_nBondData[3] == 2)
			{	
				pDC->MoveTo(point8);
				pDC->LineTo(point9);
			}
			if (m_nBondData[4] == 2)
			{	pDC->MoveTo(point10);
				pDC->LineTo(point11);
			}
			if (m_nBondData[5] == 2)
			{	
				pDC->MoveTo(point12);
				pDC->LineTo(point1);
			}
			break;
		}
		default:
			break;
	}
	if (m_nCirKind == 1&&m_nWhatKind>FIVE_EDGE_T)
 	{
		COLORREF clr = RGB(0, 0, 0);

		CPen temPen(PS_DOT,1,clr);
		CPen* ptemOldPen=pDC->SelectObject(&temPen);
		CRect temRect=CRect(CPoint(m_rect.Width()/2-FRAC_W*7,m_rect.Height()/2-FRAC_W*7),CSize(14*FRAC_W,FRAC_W*14));
		pDC->Ellipse(temRect);
		pDC->SelectObject(ptemOldPen);
	}
	if (m_nCirKind == 2&&m_nWhatKind>FIVE_EDGE_T)
 	{
		CRect temRect=CRect(CPoint(m_rect.Width()/2-FRAC_W*7,m_rect.Height()/2-FRAC_W*7),CSize(14*FRAC_W,FRAC_W*14));
		pDC->Ellipse(temRect);
	}
	if (m_bHasCross&&m_nWhatKind>FIVE_EDGE_T)
 	{
		CRect temRect=CRect(CPoint(m_rect.Width()/2-FRAC_W*7,m_rect.Height()/2-FRAC_W*7),CSize(14*FRAC_W,FRAC_W*14));
		pDC->MoveTo(temRect.left, temRect.CenterPoint().y-1);
		pDC->LineTo(temRect.right,temRect.CenterPoint().y-1);
		pDC->MoveTo(temRect.CenterPoint().x-1,temRect.top);
		pDC->LineTo(temRect.CenterPoint().x-1,temRect.bottom);
	}
	pDC->SelectObject(pOldBrush);
	pDC->SetBkMode(nBkMode);
	pDC->SelectObject(pOldPen);	
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CChemLogogram_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CChemLogogram::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CChemResponse::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CFormLabel ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	int maxHeight=MAX(m_formulaTop.m_rect.Height(),m_formulaBot.m_rect.Height());
	//	��ʽ����
	m_formulaTop.DrawShape(pDC, pICS);
	m_formulaMid.DrawShape(pDC, pICS);
	m_formulaBot.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CChemResponse_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CChemResponse::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void DrawPointLine(CDC* pDC,CPoint pointS, CPoint pointE, int nCount )
{
	int ndx,ndy;
	ndx=(pointE.x-pointS.x)/nCount;
	ndy=(pointE.y-pointS.y)/nCount;
	for(int i=0;i<=nCount-1;i++)
		pDC->Ellipse(CRect(CPoint(pointS.x+ndx/2+ndx*i-1,pointS.y+ndy/2+ndy*i-1),CSize(3,3)));
}
//  ����ͷ
void DrawArrowEnd(CDC* pDC, CPoint& end, double alpha, CPoint ArrowLH,COLORREF clr=RGB(0,0,0));
void DrawArrowEnd(CDC* pDC, CPoint& end, double alpha, CPoint ArrowLH,COLORREF clr/*=RGB(0,0,0)*/)
{
	CPoint wlPnt;
	double dW =1;// sqrt(1);
	wlPnt.x = (int)(ArrowLH.y * dW);
	wlPnt.y = (int)(ArrowLH.x * dW);
	
	double cosa = cos(alpha);
	double sina = sin(alpha);
	CPoint start;
	start.x = end.x + (int)(wlPnt.y*cosa);
	start.y = end.y + (int)(wlPnt.y*sina);

	CPoint pp[3];
	pp[1] = end;
	pp[0].x = start.x + (int)(-wlPnt.x*sina);
	pp[0].y = start.y + (int)(wlPnt.x*cosa);
	pp[2].x = start.x - (int)(-wlPnt.x*sina);
	pp[2].y = start.y - (int)(wlPnt.x*cosa);

	//	set brush
	LOGBRUSH logbrush;
	logbrush.lbStyle = BS_SOLID;
	logbrush.lbColor = clr;
	CBrush brush;
	if (!brush.CreateBrushIndirect(&logbrush))
		return;
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	pDC->Polygon(pp, 3);
	pDC->SelectObject(pOldBrush);
}

void CChemBond::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� CChemBond ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	
	COLORREF clr = RGB(0, 0, 0);
	
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(BLACK_BRUSH);
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	int nInterval=4;
	switch(m_nBondKind)
	{
		case SINGLELINE:
		{
			if (m_nDirection == 0)
			{	
				pDC->MoveTo(0,m_rect.Height()/2);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2);
			}
			if (m_nDirection == 2)
			{   
				pDC->MoveTo(m_rect.Width()/2,0);
				 pDC->LineTo(m_rect.Width()/2,m_rect.Height());
			}
			if (m_nDirection == 1)
			{
				pDC->MoveTo(0,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height());
			}
			if (m_nDirection == 3)
			{   
				pDC->MoveTo(0,m_rect.Height());
				pDC->LineTo(m_rect.Width(),0);
			}
			break;
		}
		case DOUBLELINE:
		{
			if (m_nDirection == 0)
			{
				pDC->MoveTo(0,m_rect.Height()/2-INTERVAL);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2-INTERVAL);
				pDC->MoveTo(0,m_rect.Height()/2+INTERVAL);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2+INTERVAL);
			}
			if (m_nDirection == 2)
			{   
				pDC->MoveTo(m_rect.Width()/2-INTERVAL,0);
				 pDC->LineTo(m_rect.Width()/2-INTERVAL,m_rect.Height());
				 pDC->MoveTo(m_rect.Width()/2+INTERVAL,0);
				 pDC->LineTo(m_rect.Width()/2+INTERVAL,m_rect.Height());
			}
			if (m_nDirection == 1)
			{
				pDC->MoveTo(0,INTERVAL);
				pDC->LineTo(m_rect.Width()-INTERVAL,m_rect.Height());
				pDC->MoveTo(INTERVAL,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height()-INTERVAL);
			}
			if (m_nDirection == 3)
			{  
				pDC->MoveTo(INTERVAL,m_rect.Height());
				pDC->LineTo(m_rect.Width(),INTERVAL);
				pDC->MoveTo(0,m_rect.Height()-INTERVAL);
				pDC->LineTo(m_rect.Width()-INTERVAL,0);
			}
			break;
		}
		case THREELINE:
		{
			if (m_nDirection == 0)
			{	
				pDC->MoveTo(0,m_rect.Height()/2-INTERVAL);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2-INTERVAL);
				pDC->MoveTo(0,m_rect.Height()/2);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2);
				pDC->MoveTo(0,m_rect.Height()/2+INTERVAL);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2+INTERVAL);
			}
			if (m_nDirection == 2)
			{   
				pDC->MoveTo(m_rect.Width()/2-INTERVAL,0);
				pDC->LineTo(m_rect.Width()/2-INTERVAL,m_rect.Height());
				pDC->MoveTo(m_rect.Width()/2,0);
				pDC->LineTo(m_rect.Width()/2,m_rect.Height());
				pDC->MoveTo(m_rect.Width()/2+INTERVAL,0);
				pDC->LineTo(m_rect.Width()/2+INTERVAL,m_rect.Height());
			}
			if (m_nDirection == 1)
			{
				pDC->MoveTo(0,INTERVAL*3/2);
				pDC->LineTo(m_rect.Width()-INTERVAL*3/2,m_rect.Height());
				pDC->MoveTo(INTERVAL,INTERVAL);
				pDC->LineTo(m_rect.Width()-INTERVAL,m_rect.Height()-INTERVAL);
				pDC->MoveTo(INTERVAL*3/2,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height()-INTERVAL*3/2);
			}
			if (m_nDirection == 3)
			{  
				pDC->MoveTo(INTERVAL*3/2,m_rect.Height());
				pDC->LineTo(m_rect.Width(),INTERVAL*3/2);
				pDC->MoveTo(INTERVAL,m_rect.Height()-INTERVAL);
				pDC->LineTo(m_rect.Width()-INTERVAL,INTERVAL);
				pDC->MoveTo(0,m_rect.Height()-INTERVAL*3/2);
				pDC->LineTo(m_rect.Width()-INTERVAL*3/2,0);
			}
			break;
		}
		case DOTLINE:
		{
			CPen tempen(PS_DOT,1, clr);
			CPen* pOldPen=pDC->SelectObject(&tempen);
			if (m_nDirection == 0)
			{	
				pDC->MoveTo(0,m_rect.Height()/2);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2);
			}
			if (m_nDirection == 2)
			{   
				pDC->MoveTo(m_rect.Width()/2,0);
				pDC->LineTo(m_rect.Width()/2,m_rect.Height());
			}
			if (m_nDirection == 1)
			{
				pDC->MoveTo(0,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height());
			}
			if (m_nDirection == 3)
			{   
				pDC->MoveTo(0,m_rect.Height());
				pDC->LineTo(m_rect.Width(),0);
			}
			pDC->SelectObject(pOldPen);
			break;
		}	
		case DOT_SOLID:
		{
			if (m_nDirection == 0)
			{ 
				CPen tempen(PS_DOT,1,clr);
			    CPen* pOldPen=pDC->SelectObject(&tempen);
				pDC->MoveTo(0,m_rect.Height()/2-INTERVAL);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2-INTERVAL);
				pDC->SelectObject(pOldPen);
				pDC->MoveTo(0,m_rect.Height()/2+INTERVAL);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2+INTERVAL);
			}
			if (m_nDirection == 2)
			{   
				CPen tempen(PS_DOT,1,clr);
			    CPen* pOldPen=pDC->SelectObject(&tempen);
				pDC->MoveTo(m_rect.Width()/2-INTERVAL,0);
				pDC->LineTo(m_rect.Width()/2-INTERVAL,m_rect.Height());
				pDC->SelectObject(pOldPen);
				pDC->MoveTo(m_rect.Width()/2+INTERVAL,0);
				pDC->LineTo(m_rect.Width()/2+INTERVAL,m_rect.Height());
			}
			if (m_nDirection == 1)
			{   
				CPen tempen(PS_DOT,1,clr);
			    CPen* pOldPen=pDC->SelectObject(&tempen);
				pDC->MoveTo(0,INTERVAL);
				pDC->LineTo(m_rect.Width()-INTERVAL,m_rect.Height());
				pDC->SelectObject(pOldPen);
				pDC->MoveTo(INTERVAL,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height()-INTERVAL);
			}
			if (m_nDirection == 3)
			{   
				CPen tempen(PS_DOT,1,clr);
			    CPen* pOldPen=pDC->SelectObject(&tempen);
				pDC->MoveTo(INTERVAL,m_rect.Height());
				pDC->LineTo(m_rect.Width(),INTERVAL);
				pDC->SelectObject(pOldPen);
				pDC->MoveTo(0,m_rect.Height()-INTERVAL);
				pDC->LineTo(m_rect.Width()-INTERVAL,0);
			}
			break;
		}
		case POINTLINE:
		{	
			CPen pen(PS_SOLID,2, clr);
			CPen* pOldPen1=pDC->SelectObject(&pen);
			if (m_nDirection == 0)
				DrawPointLine(pDC,CPoint(0,m_rect.Height()/2), CPoint(m_rect.Width(),m_rect.Height()/2),3*m_nBondLength);
			if (m_nDirection == 2)
				DrawPointLine(pDC,CPoint(m_rect.Width()/2,0), CPoint(m_rect.Width()/2,m_rect.Height()),3*m_nBondLength);
			if (m_nDirection == 1)
				DrawPointLine(pDC,CPoint(0,0), CPoint(m_rect.Width(),m_rect.Height()),3*m_nBondLength);
			if (m_nDirection == 3)
				DrawPointLine(pDC,CPoint(0,m_rect.Height()), CPoint(m_rect.Width()),3*m_nBondLength);
			pDC->SelectObject(pOldPen1);
			break;
		}
		case ARROW1:
		{
			if (m_nDirection == 0)
			{
				pDC->MoveTo(0,m_rect.Height()/2);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2);
				DrawArrowEnd(pDC, CPoint(m_rect.Width(),m_rect.Height()/2),3.1415,CPoint(10,4));
			}
			if (m_nDirection == 2)
			{   
				pDC->MoveTo(m_rect.Width()/2,0);
				pDC->LineTo(m_rect.Width()/2,m_rect.Height());
				DrawArrowEnd(pDC, CPoint(m_rect.Width()/2,m_rect.Height()),3.1415*270/180,CPoint(10,4));
			}
			if (m_nDirection == 1)
			{
				pDC->MoveTo(0,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height());
				DrawArrowEnd(pDC, CPoint(m_rect.Width(),m_rect.Height()),3.1415*225/180,CPoint(10,4));
			}
			if (m_nDirection == 3)
			{   
				pDC->MoveTo(0,m_rect.Height());
				pDC->LineTo(m_rect.Width(),0);
				DrawArrowEnd(pDC, CPoint(0,m_rect.Height()),3.1415*315/180,CPoint(10,4));
			}
			break;
		}
		case ARROW2:
		{
			if (m_nDirection == 0)
			{
				pDC->MoveTo(0,m_rect.Height()/2);
				pDC->LineTo(m_rect.Width(),m_rect.Height()/2);
				DrawArrowEnd(pDC, CPoint(0,m_rect.Height()/2),0,CPoint(10,4));
			}
			if (m_nDirection == 2)
			{   
				pDC->MoveTo(m_rect.Width()/2,0);
				 pDC->LineTo(m_rect.Width()/2,m_rect.Height());
				DrawArrowEnd(pDC, CPoint(m_rect.Width()/2,0),3.1415*90/180,CPoint(10,4));
			}
			if (m_nDirection == 1)
			{
				pDC->MoveTo(0,0);
				pDC->LineTo(m_rect.Width(),m_rect.Height());
				DrawArrowEnd(pDC, CPoint(0,0),3.1415*45/180,CPoint(10,4));
			}
			if (m_nDirection == 3)
			{   
				pDC->MoveTo(0,m_rect.Height());
				pDC->LineTo(m_rect.Width(),0);
				DrawArrowEnd(pDC, CPoint(m_rect.Width(),0),3.1415*135/180,CPoint(10,4));
			}
			break;
		}			
		default:
			break;
	}

	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);	
	pDC->SetBkMode(nBkMode);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CChemBond_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CChemBond::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CChemRespSym::DrawRightArrow(CDC * pDC, IColorScheme* pICS,
		CPoint OrgPoint, int nLength, int nArrowH, int nArrowL,COLORREF clr/*=RGB(0,0,0)*/)
{
	CPoint point1(OrgPoint);
	CPoint point2(point1.x+nLength,point1.y);
	CPoint point3(point2.x-nArrowL,point2.y-nArrowH);
	CPoint point4(point2.x-nArrowL*2/3,point2.y);
	CPoint point5(point2.x-nArrowL,point2.y+nArrowH);
  	POINT PArray[4];
	PArray[0].x=point2.x;
	PArray[0].y=point2.y;
	PArray[1].x=point3.x;
    PArray[1].y=point3.y;
 	PArray[2].x=point4.x;
	PArray[2].y=point4.y;
    PArray[3].x=point5.x;
 	PArray[3].y=point5.y;
	CBrush Brush;
	CRgn Rgn1;
	Brush.CreateSolidBrush(clr);
	Rgn1.CreatePolygonRgn(PArray,4,ALTERNATE); 
	pDC->FillRgn(&Rgn1,&Brush);
    pDC->MoveTo(point1);
	pDC->LineTo(point4);	
}

void CChemRespSym::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ��������CChemRespSym���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

	int m_ArrowHeight=ARROWH*2;
    int dx=2*m_ArrowHeight;
	
	COLORREF clr = RGB(0, 0, 0);

	//	set pen
	CPen* pOldPen;
	CPen pen(PS_INSIDEFRAME, 1, clr);
	pOldPen = pDC->SelectObject(&pen);	
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	////////////////////////////////////////
	int m_maxW=MAX(m_formulaeTop.m_rect.Width(),m_formulaeBot.m_rect.Width());
	CPoint Temp1(0,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
	CPoint Temp2(dx*2+m_maxW,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
	CPoint Temp3(Temp1.x+2*m_ArrowHeight,Temp1.y-m_ArrowHeight/2);
	CPoint Temp4(Temp1.x+2*m_ArrowHeight,Temp1.y+m_ArrowHeight/2);
	CPoint Temp5(Temp2.x-2*m_ArrowHeight,Temp2.y-m_ArrowHeight/2);
	CPoint Temp6(Temp2.x-2*m_ArrowHeight,Temp2.y+m_ArrowHeight/2);
	CPoint Temp7(Temp1.x+2*m_ArrowHeight,Temp1.y-m_ArrowHeight/4-m_ArrowHeight/2);
	CPoint Temp8(Temp2.x-2*m_ArrowHeight,Temp2.y+m_ArrowHeight/4+m_ArrowHeight/2);
	CRgn Rgn1,Rgn2;
	CBrush Brush;
	POINT TempSA2[4],TempSA3[4];
	switch (m_ArrowType)
	{
		case RIGHTSOLIDARROW://��Ӧ
			pDC->MoveTo(Temp1);
			pDC->LineTo(Temp2);
/*			pDC->LineTo(Temp5);
			pDC->MoveTo(Temp6);
			pDC->LineTo(Temp2);
*/			TempSA2[0].x=Temp2.x;
			TempSA2[0].y=Temp2.y;
			TempSA2[1].x=Temp5.x+m_ArrowHeight/2;
			TempSA2[1].y=Temp5.y+m_ArrowHeight/4;
			TempSA2[2].x=Temp6.x+m_ArrowHeight/2;
			TempSA2[2].y=Temp6.y;
			Brush.CreateSolidBrush(clr);
			Rgn2.CreatePolygonRgn(TempSA2,3,ALTERNATE); 
			pDC->FillRgn(&Rgn2, &Brush);
 			break;
		case DOUBLELINE://������
			pDC->MoveTo(Temp1.x,Temp1.y-m_ArrowHeight/4);
			pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/4);
			pDC->MoveTo(Temp1.x,Temp1.y+m_ArrowHeight/4);
			pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/4);
			break;
		case REVERSE1://����(˫������ָ��)
			pDC->MoveTo(Temp1.x,Temp1.y-m_ArrowHeight/4);
			pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/4);
			pDC->LineTo(Temp2.x-2*m_ArrowHeight,Temp2.y-m_ArrowHeight/4-m_ArrowHeight/2);
			pDC->MoveTo(Temp1.x+2*m_ArrowHeight,Temp1.y+m_ArrowHeight/4+m_ArrowHeight/2); 
			pDC->LineTo(Temp1.x,Temp1.y+m_ArrowHeight/4);
			pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/4);
			break;
		case REVERSE2://�������
			pDC->MoveTo(Temp1.x,Temp1.y-m_ArrowHeight/3);
			pDC->LineTo(Temp2.x,Temp2.y-m_ArrowHeight/3);
			pDC->LineTo(Temp2.x-m_ArrowHeight*3/2,Temp2.y-m_ArrowHeight/3-m_ArrowHeight/3);
			pDC->MoveTo(Temp2.x,Temp2.y-m_ArrowHeight/3);
			pDC->LineTo(Temp2.x-m_ArrowHeight*3/2,Temp2.y-m_ArrowHeight/3+m_ArrowHeight/3);
		
			pDC->MoveTo(Temp1.x+m_ArrowHeight*3/2,Temp2.y+m_ArrowHeight/3+m_ArrowHeight/3);
			pDC->LineTo(Temp1.x,Temp1.y+m_ArrowHeight/3);
			pDC->LineTo(Temp1.x+m_ArrowHeight*3/2,Temp2.y+m_ArrowHeight/3-m_ArrowHeight/3);	
			pDC->MoveTo(Temp1.x,Temp1.y+m_ArrowHeight/3);
			pDC->LineTo(Temp2.x,Temp2.y+m_ArrowHeight/3);
			break;
		case  POLYMERIZE1://�ۺϷ���1
			{
				 int FontW=(GetFS(m_nFSIndex)+5)/10;
				 int maxW=MAX(m_formulaeTop.m_rect.Width(),m_formulaeBot.m_rect.Width());
				 int count=m_rect.Width()/FontW;
				 int interval=(m_rect.Width()-count*FontW)/2;
				 for(int i=0;i<count;i++)
				{
					CPoint temOrgP(interval+i*FontW,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
					CPoint temp1(FontW,FontW);
					CPoint temp2(m_ArrowHeight*2/3,m_ArrowHeight*3/2);
					DrawRightArrow(pDC, pICS, temOrgP,temp1.x,temp2.x,temp2.y,RGB(0,0,0));
				}
				break;
			}
		case  POLYMERIZE2://�ۺϷ���2
			{  
				int FontW=(GetFS(m_nFSIndex)+5)/10;
				int maxW=MAX(m_formulaeTop.m_rect.Width(),m_formulaeBot.m_rect.Width());
				int count=m_rect.Width()/FontW;
				int nInterval=(m_rect.Width()-count*FontW)/2;
				for(int i=0;i<count;i++)
				{
					CPoint temP(nInterval+i*FontW,nInterval);
					if (i == 0||i == count-1)
					{
						CPoint temOrgP(nInterval+i*FontW,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
						CPoint temp1(FontW,FontW);
						CPoint temp2(m_ArrowHeight*2/3,m_ArrowHeight*3/2);
						DrawRightArrow(pDC, pICS, temOrgP,temp1.x,temp2.x,temp2.y, RGB(0,0,0));
					}
					else
					{	
						int temIterval=FontW/3;
						CPoint tempoint;
						for(int j=1;j<=3;j++)
						{
							tempoint.x=nInterval+i*FontW+temIterval*j-temIterval/2;
							tempoint.y=m_formulaeTop.m_rect.Height()+m_ArrowHeight/2;
							pDC->SetPixel(tempoint,clr);
						}	
					}
				}

				break;
			}
		case RIGHTBOTTOMLINKLINE:
		case DOT_RIGHTBOTTOMLINKLINE:
			{	
				Temp1=CPoint(m_ArrowHeight*2/3,m_rect.Height());
				Temp2=CPoint(m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp3=CPoint(m_rect.Width()-m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp4=CPoint(m_rect.Width()-m_ArrowHeight*2/3,m_rect.Height());
				TempSA3[0].x=Temp4.x;
				TempSA3[0].y=Temp4.y+m_ArrowHeight/4;
				TempSA3[1].x=Temp4.x-m_ArrowHeight*2/3;
				TempSA3[1].y=Temp4.y-m_ArrowHeight*3/2;
				TempSA3[2].x=Temp4.x;
				TempSA3[2].y=Temp4.y-m_ArrowHeight;
				TempSA3[3].x=Temp4.x+m_ArrowHeight*2/3;
				TempSA3[3].y=Temp4.y-m_ArrowHeight*3/2;
				Brush.CreateSolidBrush(clr);
				Rgn1.CreatePolygonRgn(TempSA3,4,ALTERNATE);
				pDC->FillRgn(&Rgn1,&Brush);
				if (m_ArrowType == DOT_RIGHTBOTTOMLINKLINE)
				{
					pDC->SelectObject(pOldPen);
					CPen pen(PS_DOT,1,clr);
					pOldPen=pDC->SelectObject(&pen);
				}

				pDC->MoveTo(Temp1);
				pDC->LineTo(Temp2);
				pDC->LineTo(Temp3);
				pDC->LineTo(Temp4);
				if (m_ArrowType == DOT_RIGHTBOTTOMLINKLINE)
					pDC->SelectObject(pOldPen);
				break;
			}
		case RIGHTTOPLINKLINE:
		case DOT_RIGHTTOPLINKLINE:
			{
				Temp1=CPoint(m_ArrowHeight*2/3,0);
				Temp2=CPoint(m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp3=CPoint(m_rect.Width()-m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp4=CPoint(m_rect.Width()-m_ArrowHeight*2/3,0);
				TempSA3[0].x=Temp4.x;
				TempSA3[0].y=Temp4.y-m_ArrowHeight/4;
				TempSA3[1].x=Temp4.x-m_ArrowHeight*2/3;
				TempSA3[1].y=Temp4.y+m_ArrowHeight*3/2;
				TempSA3[2].x=Temp4.x;
				TempSA3[2].y=Temp4.y+m_ArrowHeight;
				TempSA3[3].x=Temp4.x+m_ArrowHeight*2/3;
				TempSA3[3].y=Temp4.y+m_ArrowHeight*3/2;
				Brush.CreateSolidBrush(clr);
				Rgn1.CreatePolygonRgn(TempSA3,4,ALTERNATE);
				pDC->FillRgn(&Rgn1,&Brush);
				if (m_ArrowType == DOT_RIGHTTOPLINKLINE)
				{	
					pDC->SelectObject(pOldPen);
					CPen pen(PS_DOT,1,clr);
					pOldPen=pDC->SelectObject(&pen);
				}

				pDC->MoveTo(Temp1);
				pDC->LineTo(Temp2);
				pDC->LineTo(Temp3);
				pDC->LineTo(Temp4);
				if (m_ArrowType == DOT_RIGHTTOPLINKLINE)
					pDC->SelectObject(pOldPen);
				break;
			}
		case LEFTBOTTOMLINKLINE:
		case DOT_LEFTBOTTOMLINKLINE:
			{
				Temp1=CPoint(m_ArrowHeight*2/3,m_rect.Height());
				Temp2=CPoint(m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp3=CPoint(m_rect.Width()-m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp4=CPoint(m_rect.Width()-m_ArrowHeight*2/3,m_rect.Height());
				TempSA3[0].x=Temp1.x;
				TempSA3[0].y=Temp1.y+m_ArrowHeight/4;
				TempSA3[1].x=Temp1.x-m_ArrowHeight*2/3;
				TempSA3[1].y=Temp1.y-m_ArrowHeight*3/2;
				TempSA3[2].x=Temp1.x;
				TempSA3[2].y=Temp1.y-m_ArrowHeight;
				TempSA3[3].x=Temp1.x+m_ArrowHeight*2/3;
				TempSA3[3].y=Temp1.y-m_ArrowHeight*3/2;
				Brush.CreateSolidBrush(clr);
				Rgn1.CreatePolygonRgn(TempSA3,4,ALTERNATE);
				pDC->FillRgn(&Rgn1,&Brush);
				if (m_ArrowType == DOT_LEFTBOTTOMLINKLINE)
				{	
					pDC->SelectObject(pOldPen);
					CPen pen(PS_DOT,1,clr);
					pOldPen=pDC->SelectObject(&pen);
				}

				pDC->MoveTo(Temp1);
				pDC->LineTo(Temp2);
				pDC->LineTo(Temp3);
				pDC->LineTo(Temp4);
				if (m_ArrowType == DOT_LEFTBOTTOMLINKLINE)
					pDC->SelectObject(pOldPen);
				break;
			}
		case LEFTTOPLINKLINE:
		case DOT_LEFTTOPLINKLINE:
			{	
				Temp1=CPoint(m_ArrowHeight*2/3,0);
				Temp2=CPoint(m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp3=CPoint(m_rect.Width()-m_ArrowHeight*2/3,m_formulaeTop.m_rect.Height()+m_ArrowHeight/2);
				Temp4=CPoint(m_rect.Width()-m_ArrowHeight*2/3,0);
				TempSA3[0].x=Temp1.x;
				TempSA3[0].y=Temp1.y-m_ArrowHeight/4;
				TempSA3[1].x=Temp1.x-m_ArrowHeight*2/3;
				TempSA3[1].y=Temp1.y+m_ArrowHeight*3/2;
				TempSA3[2].x=Temp1.x;
				TempSA3[2].y=Temp1.y+m_ArrowHeight;
				TempSA3[3].x=Temp1.x+m_ArrowHeight*2/3;
				TempSA3[3].y=Temp1.y+m_ArrowHeight*3/2;
				Brush.CreateSolidBrush(clr);
				Rgn1.CreatePolygonRgn(TempSA3,4,ALTERNATE);
				pDC->FillRgn(&Rgn1,&Brush);
				if (m_ArrowType == DOT_LEFTTOPLINKLINE)
				{
					pDC->SelectObject(pOldPen);
					CPen pen(PS_DOT,1,clr);
					pOldPen=pDC->SelectObject(&pen);
				}

				pDC->MoveTo(Temp1);
				pDC->LineTo(Temp2);
				pDC->LineTo(Temp3);
				pDC->LineTo(Temp4);
				if (m_ArrowType == DOT_LEFTTOPLINKLINE)
					pDC->SelectObject(pOldPen);
				break;
			}
		default:
			break;
	}
	////////////////////////////////////////
	pDC->SelectObject(pOldPen);
	pDC->SetBkMode(nBkMode);
	//	���ö���
	m_formulaeTop.DrawShape(pDC, pICS);
	//	���ö���
	m_formulaeBot.DrawShape(pDC, pICS);
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CChemRespSym_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CChemRespSym::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

int CFormSymbol::GetFontHeight( CWpsView* pView )
{	
	ASSERT( m_nFSIndex >= 0&&m_nFSIndex < 4 );
	m_nFSIndex = MIN(3, m_nFSIndex);
	if ( m_pMstObj && m_pMstObj->IsKindOf(RUNTIME_CLASS(CFormula)))
	{
		ASSERT(m_nFSIndex >= 0 && m_nFSIndex < 4);
		m_nFSIndex = MIN(3, m_nFSIndex);
		return FS[m_nFSIndex];
		//	return m_pMstObj->GetFontHeight( pView );
	}
	return m_nFontSize[m_nFSIndex];

}
extern TCHAR g_szSymbolFontName[];
BOOL CreateSymbolFont(CFont& font, int nH, BYTE Italic, int nWeight)
{
	LOGFONT	s_scrlf;
	s_scrlf.lfEscapement 	= 0;
	s_scrlf.lfOrientation	= 0;
	s_scrlf.lfItalic		= (Italic==CC_DISABLED?(BYTE)0: (BYTE)1);
	s_scrlf.lfUnderline		= 0;
	s_scrlf.lfStrikeOut		= 0;
	s_scrlf.lfCharSet 		= ANSI_CHARSET;
	s_scrlf.lfOutPrecision 	= OUT_DEFAULT_PRECIS;//OUT_STROKE_PRECIS;
	s_scrlf.lfClipPrecision	= CLIP_DEFAULT_PRECIS;//CLIP_STROKE_PRECIS;
	s_scrlf.lfQuality		= DEFAULT_QUALITY;
	s_scrlf.lfPitchAndFamily= DEFAULT_PITCH;
	s_scrlf.lfHeight		= -nH;
	s_scrlf.lfWidth			= 0;
	s_scrlf.lfWeight		= nWeight;
	lstrcpy(s_scrlf.lfFaceName, g_szSymbolFontName);
	if (!font.CreateFontIndirect(&s_scrlf))
		return FALSE;
	ASSERT (font.GetSafeHandle());
	return TRUE;
}
void CFormSymbol::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formSymbol ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	int nFontH = GetFontHeight(NULL)/10;
	//	Symbol����
	CFont font;
	if (!CreateSymbolFont(font, nFontH, m_Italic, m_nWeight))
		return;
	CFont* pOldFont = pDC->SelectObject(&font);
	ASSERT(pOldFont);
	TEXTMETRIC tm;
	pDC->GetTextMetrics(&tm);
	c_nInte = tm.tmInternalLeading/2;
	int nBkMode = pDC->SetBkMode(TRANSPARENT);
	COLORREF Oldcolor= pDC->SetTextColor(KColorModel::IndexToRef(m_FormCharColor, pICS));
	CString str;
	str += (char)m_wSymbol;
	// we should convert multibyte text to singlebyte text because all text is english or number
	pDC->SetTextAlign(TA_LEFT|TA_BASELINE);
	pDC->TextOut(0, -c_nInte+c_tmAscent, str);
//	pDC->ExtTextOut(0, -c_nInte+c_tmAscent, 0, rct, str, 1, 0);
	pDC->SetTextColor(Oldcolor);
	pDC->SetBkMode(nBkMode);
	pDC->SelectObject(pOldFont);
	font.DeleteObject();

	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormSymbol_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormSymbol::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

void CFormEquation::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formMatr ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	//	����Χ��
	int	nBracketWidth = (GetFS(m_nFSIndex)+5)/20;
	CPoint wh(2,nBracketWidth);
	int b = wh.y;
	int h = rct.Height();
	int w = rct.Width();

	CPen* pOldPen;
	CPen pen(PS_SOLID, wh.x, RGB(0,0,0));
	pOldPen = pDC->SelectObject(&pen);	
	int nFirstObjHor = ((CFormula*)GetMatrCell(1,1))->GetObjHor();//ȡ��һ�����̵�ˮƽ����.��
	int nLastObjHor = ((CFormula*)GetMatrCell(m_nR,1))->GetObjHor();//ȡ���һ�����̵�ˮƽ�����
	int nCenterP = (m_rect.Height()-nFirstObjHor-(GetMatrCell(m_nR,1)->m_rect.Height()-nLastObjHor))/2+nFirstObjHor;//�������е��y
	CPoint p0(b,nFirstObjHor);
	CPoint p1(0, nFirstObjHor);
	CPoint p2(b,nCenterP);
	CPoint p3(0,nCenterP);

	CPoint p[4];
	p[0].x = p0.x;		p[0].y = p0.y;
	p[1].x = p1.x;		p[1].y = p1.y;
	p[2].x = p2.x;		p[2].y = p2.y;
	p[3].x = p3.x;		p[3].y = p3.y;
	pDC->PolyBezier(p, 4);
	p0 = CPoint(0,nCenterP);
	p1 = CPoint(b,nCenterP);
	p2 = CPoint(0,m_rect.Height()-(GetMatrCell(m_nR,1)->m_rect.Height()-nLastObjHor));
	p3 = CPoint(b,m_rect.Height()-(GetMatrCell(m_nR,1)->m_rect.Height()-nLastObjHor));
	p[0].x = p0.x;		p[0].y = p0.y;
	p[1].x = p1.x;		p[1].y = p1.y;
	p[2].x = p2.x;		p[2].y = p2.y;
	p[3].x = p3.x;		p[3].y = p3.y;
	pDC->PolyBezier(p, 4);
	pDC->SelectObject(pOldPen);	
	CWPSObj* pObj;
	for (int n = 0; n < m_nR*m_nC; n++)
	{	
		pObj = (CWPSObj*)m_objArray[n];
		pObj->DrawShape(pDC, pICS);
	}
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CFormEquation_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CFormEquation::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}
void CAtomConstruMap::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	SaveFS();
	if (!GetMstObj())
		ChangeFS(m_nFontSize, m_nFormulaCharMrg);
	//	��������
	CRect rct = m_rect;
	DrawPosition( pDC, rct );
	pDC->LPtoDP(&rct);	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formMatr ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
    //Set Pen;
	CPen* pOldPen;
	CPen pen(PS_SOLID,1, RGB(0,0,0));
	pOldPen = pDC->SelectObject(&pen);	
	//	set brush
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	int nBkMode = pDC->SetBkMode(TRANSPARENT);

	int W = ((CWPSObj*)m_objArray[0])->m_rect.Width();
	int H = ((CWPSObj*)m_objArray[0])->m_rect.Height();
	CRect temR(CPoint(m_rect.Width()/2-(W+20)/2,m_rect.Height()/2-(W+20)/2),CSize(W+20,W+20));
	pDC->Ellipse(temR);
	int wh = (GetFS(m_nFSIndex)+5)/10;
	int rad = wh/8;
	CPoint StartP1,EndP1,StartP2,EndP2;
	CRect temObjR;
	for(int i = 1;i<m_nLayerNum;i++)
	{    
		rad+=((CWPSObj*)m_objArray[i-1])->m_rect.Width()/2;
		rad+=((CWPSObj*)m_objArray[i])->m_rect.Width()/2;	
		rad+=wh/4;
		temR = CRect(CPoint(m_rect.Width()/2-rad,m_rect.Height()/2-rad),CSize(rad*2,rad*2));
		temObjR = ((CWPSObj*)m_objArray[i])->m_rect;
		StartP1 = CPoint(temObjR.CenterPoint().x,temObjR.top);
		EndP1 = CPoint(m_rect.Width()/2+(int)(rad*cos(m_nWrapAngle/2*3.14/180)),m_rect.Height()/2-(int)(rad*sin(m_nWrapAngle/2*3.14/180)));
		StartP2 = CPoint(m_rect.Width()/2+(int)(rad*cos(m_nWrapAngle/2*3.14/180)),m_rect.Height()/2+(int)(rad*sin(m_nWrapAngle/2*3.14/180)));
		EndP2 = CPoint(temObjR.CenterPoint().x,temObjR.bottom);
		pDC->Arc(temR,StartP1,EndP1);
		pDC->Arc(temR,StartP2,EndP2);
	}
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);	
	pDC->SetBkMode(nBkMode);

	CWPSObj* pObj;
	for (int n = 0; n<m_nLayerNum; n++)
	{	
		pObj = (CWPSObj*)m_objArray[n];
		pObj->DrawShape(pDC, pICS);
	}
	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
	RefreshFS();
}
EX_SHAPE_API CAtomConstruMap_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CAtomConstruMap::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

/*
void CForm::DrawShape(CDC* pDC, IColorScheme* pICS)
{
}
EX_SHAPE_API CForm_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	CForm::DrawShape(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}
*/

// -------------------------------------------------------------------------
//	$Log: ex_formvect.cpp,v $
//	Revision 1.10  2005/08/31 04:20:19  lizhongbo
//	*** empty log message ***
//	
//	Revision 1.9  2005/06/30 08:57:47  liupeng
//	*** empty log message ***
//	
//	Revision 1.8  2005/06/17 03:14:39  shenjiazheng
//	�޶���ѧ���ųɡ���ڿ顱���⡣Ӧ����Ҫ���ַ������Ϊ���߶������
//	
//	Revision 1.7  2005/01/17 09:00:49  shenjiazheng
//	*** empty log message ***
//	
//	Revision 1.6  2005/01/11 09:55:52  shenjiazheng
//	*** empty log message ***
//	
//	Revision 1.5  2005/01/08 06:27:15  shenjiazheng
//	*** empty log message ***
//	
//	Revision 1.4  2005/01/08 01:42:54  shenjiazheng
//	*** empty log message ***
//	
//	Revision 1.3  2005/01/07 03:51:08  wanli
//	*** empty log message ***
//	
//	Revision 1.2  2005/01/07 03:20:46  shenjiazheng
//	*** empty log message ***
//	
//	Revision 1.1  2004/12/31 02:50:27  xushiwei
//	formula�������̳���������
//	
