/* -------------------------------------------------------------------------
//	�ļ���		��	wppframe.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-28 14:38:39
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "wppframe.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(CWPPFrame, CFrameText, 0xA0 | VERSIONABLE_SCHEMA)

void CWPPFrame::Serialize_01(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);

		ar << m_bIsTitleFrame;
	}
	else
	{
		ar >> m_bIsTitleFrame;

		if (!g_fCompoundFile && m_bIsTitleFrame)	//��2002֮ǰ���ļ�, �����Ǳ����ʱ
		{
			m_wVAlign = TAL_VCENTER;
		}
	}
	CFrameText::Serialize_01(ar);
}

void CWPPFrame::Serialize_97(CArchive& ar)
{
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);

		ar << m_bIsTitleFrame;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_bIsTitleFrame;
	}
	CFrameText::Serialize_98(ar);
}

void CWPPFrame::Serialize_98(CArchive& ar)
{
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);

		ar << m_bIsTitleFrame;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_bIsTitleFrame;
	}
	CFrameText::Serialize_98(ar);
}

/*
*
*/

//CMapStringToPtr g_mapStyleNameToLevel;	//��ʽ������Ŀ���Ų�εĿ���ӳ���
//BOOL CreateMapStyleNameToLevel()
//{
//	if (!g_mapStyleNameToLevel.IsEmpty())
//		return FALSE;
//	//������ʽ������Ŀ���Ų�εĿ���ӳ���
//	CString strTmp;
//	int nTmp;
//
//	strTmp = (IDS_SYS_WPPSTYLE_SLIDEMASTER_TITLE);
//	nTmp = 0;
//	g_mapStyleNameToLevel.SetAt(strTmp, (void*)(nTmp + 1));
//	strTmp = (IDS_SYS_WPPSTYLE_TITLEMASTER_TITLE);
//	nTmp = 0;
//	g_mapStyleNameToLevel.SetAt(strTmp, (void*)(nTmp + 1));
//
//	for (nTmp = 0; nTmp < 5; nTmp++)
//	{
//		strTmp = (IDS_SYS_WPPSTYLE_SLIDEMASTER_HEADING1);
//		strTmp += nTmp;
//		g_mapStyleNameToLevel.SetAt(strTmp, (void*)(nTmp + 1));
//		strTmp = (IDS_SYS_WPPSTYLE_TITLEMASTER_HEADING1);
//		strTmp += nTmp;
//		g_mapStyleNameToLevel.SetAt(strTmp, (void*)(nTmp + 1));
//	}
//	return TRUE;
//}
//
CTextPool* GetMasterPool(int nFrameType, CWPPDoc* pDoc)
{
	if (NULL == pDoc )//|| !pDoc->IsKindOf(RUNTIME_CLASS(CWPPDoc)))
		return NULL;
	ASSERT_VALID(pDoc);
	ASSERT(nFrameType >= 1 && nFrameType <= 4);
	CTextPool*	pPool = NULL;
	//CWPPView*	pView = (CWPPView*)GetCurView();		ASSERT_VALID(pView);
	//CWPPDoc*	pDoc = pView->GetDocument();			ASSERT_VALID(pDoc);
	CWPPMaster*	pMasterSlide = pDoc->GetSlideMaster();
	CWPPMaster*	pMasterTitle = pDoc->GetTitleMaster();
	if (NULL == pMasterSlide || NULL == pMasterTitle)
		return NULL;
	ASSERT_VALID(pMasterSlide);
	ASSERT_VALID(pMasterTitle);

	switch (nFrameType)
	{
	case 1:
		pPool = pMasterTitle->GetSysTitleObj()->GetAccessToTextPool();
		break;
	case 2:
		pPool = pMasterTitle->GetSysTextObj()->GetAccessToTextPool();
		break;
	case 3:
		pPool = pMasterSlide->GetSysTitleObj()->GetAccessToTextPool();
		break;
	case 4:
		pPool = pMasterSlide->GetSysTextObj()->GetAccessToTextPool();
		break;
	default:
		ASSERT(0);
		break;
	}
	ASSERT_VALID(pPool);
	return pPool;
}
////�����ϵ���⣺
////	WPP��Level��ָ��ʽ�ļ���һ�����ֿ����弶(�Ժ���ܻ����)�������Ե�
////	��Ŀ���ŵ�Level����ļ���һ�����ֿ��ǿ����ж�����Ŀ���ţ�ÿ����ʮ������
////	��Ŀǰ������
//const AUTONUMGROUP* GetABInfoFromStyle(LPCTSTR lpszStyleName, CTextPool* pPool,
//										BOOL bIsMaster,   int& nANLevel)
//{
//	ASSERT_VALID(pPool);
//
//	nANLevel = 0;
//	CreateMapStyleNameToLevel();
//	int nLevel = 0;
//	g_mapStyleNameToLevel.Lookup(lpszStyleName, (void*&)nLevel);
//	if (0 == nLevel)
//		return NULL;
//	else
//		nLevel--;
//	ASSERT(nLevel >= 0 && nLevel < 5);
//
//	KABGroupInfoMan* pABInfoMan = pPool->GetABGroupInfoMan();	ASSERT_VALID(pABInfoMan);
//	const AUTONUMPARAREF* pABInfoRef = NULL;
//	AUTONUMGROUP* pABInfoOK = NULL;
//	CParagraph* pPara = NULL;
//	for (int i = 0, nSize = pPool->NumOfParagraphs(); i < nSize; i++)
//	{
//		pPara = pPool->GetParagraph(i);	ASSERT_VALID(pPara);
//		pABInfoRef = pPara->GetAutoNumRefData();
//		if (pABInfoRef && pPara->GetStyleName() == lpszStyleName)
//		{	
//			pABInfoOK = GetGroup_FromGroupSPtr(pABInfoRef->m_AuoNumGroupSPtr);
//			nANLevel = nLevel;
//			return pABInfoOK;
//		}
//	}
//
//	return NULL;
//}
//
BOOL CWPPFrame::InitStyle(int nSlideBaseType, BOOL bMultLevel)
{
	CTextPool* pPool = GetAccessToTextPool(); ASSERT_VALID(pPool);
	int nStyleStrID;
	CParagraph* pPara;
	
	CWPPDoc* pWPPDoc = (CWPPDoc*)m_pDocument;
	if (NULL == pWPPDoc)
		return FALSE;

	switch (nSlideBaseType)
	{	
	case enSLIDEBASE_TITLE:												// ����ҳ
		if (bMultLevel)													// ������
			nStyleStrID = (int)IDS_SYS_WPPSTYLE_TITLEMASTER_HEADING1;
		else															// ������
			nStyleStrID = (int)IDS_SYS_WPPSTYLE_TITLEMASTER_TITLE;

		pPara = pPool->GetParagraph(0); ASSERT_VALID(pPara);
		pPara->SetStyle(TSID_USERDEFINEDPS, (LPCTSTR)nStyleStrID);//LoadWPSString(nStyleStrID));
		break;
	case enSLIDEBASE_SLIDE:												// ��ʾҳ
		if (bMultLevel)													// ��ʾҳ���ֿ�
		{
			for (int i = 0; i < 5; i++)
			{
				pPara = pPool->GetParagraph(i); 
				//ASSERT_VALID(pPara);
				if (!pPara)
					continue;
				//nStyleStrID = IDS_SYS_WPPSTYLE_SLIDEMASTER_HEADING1 + i;
				char szStyle[] = "WPPS_SLIDE_H1";
				szStyle[sizeof(szStyle) - 2] = '1' + i;
				pPara->SetStyle(TSID_USERDEFINEDPS, szStyle);//LoadWPSString(nStyleStrID));
			}
		}
		else															// ��ʾҳ����
		{
			nStyleStrID = (int)IDS_SYS_WPPSTYLE_SLIDEMASTER_TITLE;
			pPara = pPool->GetParagraph(0); ASSERT_VALID(pPara);
			pPara->SetStyle(TSID_USERDEFINEDPS, LPCTSTR(nStyleStrID));
		}
		break;
	}

	//Begin BlackBay�� ��ʼ�����ֿ�ÿһ�ε���Ŀ����
/*
	CreateMapStyleNameToLevel();
	CTextPool *pMasterPool = ::GetMasterPool(1 +
		(nSlideBaseType == enSLIDEBASE_TITLE ? 0 : 2) +
		(bMultLevel ? 1 : 0), (CWPPDoc*)m_pDocument);
	const AUTONUMGROUP* pABInfo;
	int n1, n2;
	int nLevel;
	int nANLevel;
	AUTONUMATOM anTmpAtom;
	AUTONUMATOM* anTmpGroup[_MAX_AUTONUMATOMS_EACHGROUP];
	
	for (int i = 0, len = pPool->NumOfParagraphs(); i < len; i++)
	{
		n1 = n2 = i;
		pPara = pPool->GetParagraph(i);	ASSERT_VALID(pPara);
		pABInfo = NULL;
		if (pMasterPool)
		{
			ASSERT_VALID(pMasterPool);
			pABInfo = ::GetABInfoFromStyle(pPara->GetStyleName(), pMasterPool, pPool == pMasterPool, nANLevel);
		}
		if (pABInfo)
		{
			anTmpAtom = *GETATOM_FROMATOMSPTR(pABInfo->GroupData[nANLevel]);

			//������Ŀ������ռλ�ÿ���...
				if (nANLevel >= 0 && nANLevel < 5)
			{
				anTmpAtom.lAutoNumNormalTextToFirstIndent = 
							pWPPDoc->GetAutoNumIndentByStyleLevel(nANLevel);
			}

			for (int nTmp = 0; nTmp < _MAX_AUTONUMATOMS_EACHGROUP; nTmp++)
				anTmpGroup[nTmp] = &anTmpAtom;
			pPool->SetAutoNumAttrib(n1, n2, _MAX_AUTONUMATOMS_EACHGROUP,
								anTmpGroup, &anTmpAtom, nANLevel, TRUE, FALSE, FALSE);
		}
		else
		{
			if ((pPool == pMasterPool || NULL == pMasterPool)
				&& nSlideBaseType == enSLIDEBASE_SLIDE && bMultLevel)
			{
				nLevel = 0;
				g_mapStyleNameToLevel.Lookup(pPara->GetStyleName(), (void*&)nLevel);
				if (nLevel > 0)
					nLevel--;
				else
					nLevel = 0;
				nANLevel = nLevel;

				//WPP����Ŀ�����ַ����ԣ�Ĭ�ϸ��汾���׾�֮������
				if (g_MakeupAutoNumAtomFromOldInfo(&anTmpAtom, defTYPE_BULLET, g_nANTypeLevel[nLevel], 1, nANLevel, TRUE))
				{
					//������Ŀ������ռλ�ÿ���...
					if (nANLevel >= 0 && nANLevel < 5)
					{
						anTmpAtom.lAutoNumNormalTextToFirstIndent = 
								pWPPDoc->GetAutoNumIndentByStyleLevel(nANLevel);
					}					

					for (int nTmp = 0; nTmp < _MAX_AUTONUMATOMS_EACHGROUP; nTmp++)
						anTmpGroup[nTmp] = &anTmpAtom;
					pPool->SetAutoNumAttrib(n1, n2, _MAX_AUTONUMATOMS_EACHGROUP,
											anTmpGroup, &anTmpAtom, nANLevel, TRUE, FALSE, FALSE);
				}
			}
		}
	}
	//End	BlackBay
*/
	return TRUE;
}
BOOL g_DelUnwanterCCAboutWPPMaster(CParagraph* pParagraph)
{
	ASSERT_VALID(pParagraph);
	if (pParagraph)
	{
		CObList* pList = NULL;
		pList = pParagraph->GetAttribList(TRUE); //ASSERT_VALID(pList);
		if (pList)
		{
			CCtrlCode* pObj;
			POSITION pos1, pos2;
			for (pos1 = pList->GetHeadPosition(); (pos2 = pos1) != NULL;)
			{
				pObj = (CCtrlCode*)pList->GetNext(pos1);
				ASSERT_VALID(pObj);
				if (pObj->GetCodeID() != SETAUTONUMBER)
				{
					pList->RemoveAt(pos2);
					delete pObj;
				}
			}
		}
	}

	return TRUE;
}

BOOL CWPPFrame::ProcessStyleForHoliness(int nSlideBaseType, BOOL bMultLevel)
{
	CParagraph* pPara;

	CWPPDoc* pWPPDoc = (CWPPDoc*)m_pDocument;
	if (NULL == pWPPDoc)
		return FALSE;

	CTextPool *pMasterPool = ::GetMasterPool(1 + (nSlideBaseType == enSLIDEBASE_TITLE ? 0 : 2) +
											(bMultLevel ? 1 : 0), (CWPPDoc*)m_pDocument);
	ASSERT_VALID(pMasterPool);

	for (int i = 0, nParaCount = pMasterPool->NumOfParagraphs(); i < nParaCount; i++)
	{
		pPara = pMasterPool->GetParagraph(i); ASSERT_VALID(pPara);
		if (!pPara)
			continue;
		g_DelUnwanterCCAboutWPPMaster(pPara);
	}
	
	return TRUE;
}


// -------------------------------------------------------------------------
