/* -------------------------------------------------------------------------
//	�ļ���		��	ksoledata.cpp
//	������		��	Tank
//	����ʱ��	��	2004-11-23 11:13:48
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ksoledata.h"
#include "wpsdoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////////
// Function Name: COLEData::Write
// Function		: Write block data to COLEData block
// Entry		: pszName: name, pData: data, nSize: data size
// Return		: success if BOOL
// Remark		:
///////////////////////////////////////////////////////////////////////////
BOOL COLEData::Write(LPCTSTR pszName, LPVOID pData, int nSize)
{
	if (nSize == 0 || !pData)
		return FALSE;

	char* pTemp;
	char* pPoint = m_pData;
	int nBlockSize;
	while (pPoint < m_pData + m_nBufSize)
	{
		nBlockSize = *(int*)pPoint;
		pTemp = pPoint + sizeof(int);
		if (lstrcmp((LPCTSTR)pTemp, pszName) == 0)
		{
			pTemp += lstrlen((LPTSTR)pTemp) + 1;
			if ((m_pData - pPoint) + nBlockSize < m_nBufSize)
				memmove(pPoint, pPoint + nBlockSize, m_nBufSize - (pPoint - m_pData) - nBlockSize);
			m_nBufSize -= nBlockSize;
			break;
		}
		pPoint += nBlockSize;
	}

	int nNameSize = lstrlen(pszName) + 1;
	nBlockSize = nNameSize + sizeof(int) + nSize;
	char* pnewdata = (char*)malloc(m_nBufSize + nBlockSize);
	if (!pnewdata)
		return FALSE;

	if (m_nBufSize && m_pData)
		memcpy(pnewdata, m_pData, m_nBufSize);
	if (m_pData)	// LvGh 2002-6-12 15:17 VBA����ʱ����ԭ��������ڴ�й©
		free(m_pData);
	
	m_pData = pnewdata; pnewdata += m_nBufSize;
	*(int*)pnewdata = nBlockSize; pnewdata += sizeof(int);
	memcpy(pnewdata, pszName, nNameSize); pnewdata += nNameSize;
	memcpy(pnewdata, pData, nSize);
	m_nBufSize += nBlockSize;
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////
// Function Name: COLEData::Read
// Function		: read data from colddata block
// Entry		: pszName: name of data, pInBuf: input storing buffer, nSize: buffer size
// Return		: data size in buffer, no fount data if 0
// Remark		: return the data size if pInBuf = 0
///////////////////////////////////////////////////////////////////////////
int	COLEData::Read(LPCTSTR pszName, LPVOID pInBuf, int nSize)
{
	if (pInBuf)
		*(char*)pInBuf = 0;

	ASSERT(pszName);
	char* pTemp;
	char* pPoint = m_pData;
	int nBlockSize;
	while (pPoint < m_pData + m_nBufSize)
	{
		nBlockSize = *(int*)pPoint;
		pTemp = pPoint + sizeof(int);
		if (lstrcmp((LPCTSTR)pTemp, pszName) == 0)
		{
			pTemp += lstrlen((LPTSTR)pTemp) + 1;
			if (pInBuf)
				memcpy(pInBuf, pTemp, MIN(nSize, nBlockSize - (pTemp - pPoint)));
			return pTemp - pPoint;
		}
		pPoint += nBlockSize;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////
// Function Name: CWpsDoc::CreateStorage
// Function		: create a new storage, you can write and read data to ppData after you create.
// Entry		: pszName: storage name, ppData: return COLEData, dwflag: flag
// Return		: HRESULT, S_OK if success, STG_E_INSUFFICIENTMEMORY if insufficient memory,
//				  STG_E_FILEALREADYEXISTS if fail
// Remark		: you can get the pointer of COLEData after call the function, don't care about
//				  it after you use.
///////////////////////////////////////////////////////////////////////////
HRESULT CWpsDoc::CreateStorage(LPCTSTR pszName, COLEData** ppData, DWORD dwflag/*=STGM_READWRITE*/)
{
	ASSERT(pszName);
	if (*pszName == 0)
		return STG_E_INVALIDPOINTER;
	int nSize = m_OleDataArray.GetSize();
	for (int i = 0; i < nSize; i++)
	{
		if (((COLEData*)m_OleDataArray.GetAt(i))->m_strName == pszName)
			return STG_E_FILEALREADYEXISTS;
	}

	switch (dwflag)
	{
	case STGM_READWRITE:
		COLEData* pdata = new COLEData;
		if (!pdata)
			return STG_E_INSUFFICIENTMEMORY;
		pdata->dwflag = dwflag;
		pdata->m_strName = pszName;
		m_OleDataArray.Add(pdata);
		*ppData = pdata;
	}
	return S_OK;
}

///////////////////////////////////////////////////////////////////////////
// Function Name: CWpsDoc::GetStorage
// Function		: you can open a storage after you open an document
// Entry		: pszName: storage name, dwflag: open flag
// Return		: COLEData* which you can operating.
// Remark		: you have no right to delete the COLEData block after you use.
///////////////////////////////////////////////////////////////////////////
COLEData* CWpsDoc::OpenStorage(LPCTSTR pszName, DWORD dwflag)
{
	COLEData* pData;
	int nSize = m_OleDataArray.GetSize();
	for (int i = 0; i < nSize; i++)
	{
		pData = (COLEData*)m_OleDataArray.GetAt(i);
		if (pData->m_strName == pszName)
			return pData;
	}
	return NULL;
}

//#ifndef _WPSREADER
////////////////////////////////////////////////////////////////////////////
////	����:	��oledata�����ļ�
////	����:	�ɹ�ʱ����TRUE, ʧ��ʱ����FALSE
////////////////////////////////////////////////////////////////////////////
//BOOL CWpsDoc::SaveOLEBlockData(CFile* pFile)
//{
//	ASSERT_VALID(pFile);
//	COLEData* pData;
//
//	DWORD dwBlockSize = 0;
//	TRY
//	{
//#ifdef _GWS
//		if (g_pWPSFHeader != NULL)				//�������ļ�����ΪWPS�ļ�
//			g_pWPSFHeader->wfhOLEBlock = pFile->GetPosition();
//		else
//#endif
//			m_FileHeader.wfhOLEBlock = pFile->GetPosition();
//
//		int nSize = 0x10101010;									// ��ʼ��
//		pFile->Write(&nSize, sizeof(int)); dwBlockSize += sizeof(int);
//		int nStrLen;
//		nSize = m_OleDataArray.GetSize();
//		pFile->Write(&nSize, sizeof(int)); dwBlockSize += sizeof(int);
//		for (int i = 0; i < nSize; i++)
//		{
//			pData = (COLEData*)m_OleDataArray.GetAt(i);
//			pFile->Write(&pData->dwflag, sizeof(DWORD)); dwBlockSize += sizeof(DWORD);
//			nStrLen = pData->m_strName.GetLength();
//			pFile->Write(&nStrLen, sizeof(int)); dwBlockSize += sizeof(int);
//			pFile->Write((LPCTSTR)pData->m_strName, nStrLen); dwBlockSize += nStrLen;
//			pFile->Write(&pData->m_nBufSize, sizeof(int)); dwBlockSize += sizeof(int);
//			pFile->Write(pData->m_pData, pData->m_nBufSize); dwBlockSize += pData->m_nBufSize;
//		}
//
//#ifdef _GWS
//		if (g_pWPSFHeader != NULL)				//�������ļ�����ΪWPS�ļ�
//			g_pWPSFHeader->wfhOLEBlockSize = dwBlockSize;
//		else
//#endif
//			m_FileHeader.wfhOLEBlockSize = dwBlockSize;
//	}
//	CATCH_ALL(e)
//	{
//		pFile->Abort(); // will not throw an exception
//		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
//		TRY
//			if (e && e->IsKindOf(RUNTIME_CLASS(CFileException)) && ((CFileException*)e)->m_cause)
//				ReportSaveLoadException("", e, TRUE, AFX_IDP_FAILED_TO_SAVE_DOC);
//		END_TRY
//		return FALSE;
//	}
//	END_CATCH_ALL
//
//	return TRUE;
//}
//#endif	// #ifndef _WPSREADER
//
////////////////////////////////////////////////////////////////////////////
////	����:	���ļ��ж���oledata
////	����:	�ɹ�ʱ����TRUE, ʧ��ʱ����FALSE
////	ע�⣺	�ļ�ָ�뱻�ı�
////////////////////////////////////////////////////////////////////////////
//BOOL CWpsDoc::LoadOLEBlockData(CFile* pFile)
//{
//	ASSERT_VALID(pFile);
//
//	// �ж��ļ����Ƿ���oledata
//#ifdef _GWS
//	return TRUE;									// û��oledata�������˳�
//#else
//	if (m_FileHeader.wfhVersion < VER_WINWPS01 ||
//		m_FileHeader.wfhOLEBlock == 0 || m_FileHeader.wfhOLEBlockSize == 0)
//		return TRUE;								// û��oledata�������˳�
//#endif // #ifdef _GWS
//
//	pFile->Seek(m_FileHeader.wfhOLEBlock, CFile::begin);
//
//	DWORD dwBufSize = m_FileHeader.wfhOLEBlockSize;
////	BYTE* pBuf = (BYTE*)malloc(dwBufSize);
////	if (!pBuf)
////	{
////		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
////		return TRUE;	// ���ܴ˴�, ������FALSE
////	}
//	// ������ǩ��Ϣ������Ļ�������
////	VERIFY(dwBufSize == pFile->Read(pBuf, dwBufSize));
//
//	// 
//	int nSize;
//	pFile->Read(&nSize, sizeof(int));
//	if (nSize != 0x10101010)								// ��ʼ��
//	{	ASSERT(FALSE);
//		return FALSE;
//	}
//	int nStrLen;
//	pFile->Read(&nSize, sizeof(int));
//
//	COLEData* pData;
//	LPTSTR pBuf;
//	for (int i = 0; i < nSize; i++)
//	{
//		pData = new COLEData;
//		if (!pData)
//			return FALSE;
//		m_OleDataArray.Add(pData);
//
//		pFile->Read(&pData->dwflag, sizeof(DWORD));
//		pFile->Read(&nStrLen, sizeof(int));
//		pBuf = pData->m_strName.GetBuffer(nStrLen + 10);
//		pFile->Read(pBuf, nStrLen); *(pBuf + nStrLen) = 0;
//		pData->m_strName.ReleaseBuffer();
//		pFile->Read(&pData->m_nBufSize, sizeof(int));
//		pData->m_pData = (char*)malloc(pData->m_nBufSize);
//		if (!pData->m_pData)
//			return FALSE;
//		pFile->Read(pData->m_pData, pData->m_nBufSize);
//	}
//	ASSERT(pFile->GetPosition() == m_FileHeader.wfhOLEBlock + m_FileHeader.wfhOLEBlockSize);
//
//	return TRUE;
//}
//
