/* -------------------------------------------------------------------------
//	�ļ���		��	io/record_in.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-16 2:23:16
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IO_RECORD_IN_H__
#define __IO_RECORD_IN_H__

#ifndef __IO_RECORD_SHARE_H__
#include "record_share.h"
#endif

#ifndef __IO_FILEADPT_H__
#include "fileadpt.h"
#endif

// =========================================================================

template <class File>
class KRecordReaderBasic
{
public:
	KRecordReaderBasic()
	{
		m_wBlkSize = m_wRestSize = 0;
	}
	STDMETHODIMP_(void) Attach(File pFile)
	{
		m_pFile = pFile;
	}
	STDMETHODIMP PeekNextRec(UINT* pwTag)
	{
		UINT cb;
		WORD wTag;
		if (m_wRestSize)
		{
			HRESULT hr = _ioSeekFile(m_pFile, m_wRestSize, SEEK_CUR);
			if (hr != S_OK)
				return hr;
		}
		cb = _ioReadFile(m_pFile, &wTag, sizeof(wTag));
		_ioSeekFile(m_pFile, -(cb + m_wRestSize), SEEK_CUR);
		if (cb == sizeof(wTag))
		{
			*pwTag = wTag;
			return S_OK;
		}
		return S_FALSE;
	}
	STDMETHODIMP ResetRec()
	{
		if (m_wRestSize < m_wBlkSize)
		{
			_ioSeekFile(m_pFile, (FILEOFF)(m_wRestSize - m_wBlkSize), SEEK_CUR);
			m_wRestSize = m_wBlkSize;
		}
		return S_OK;
	}
	STDMETHODIMP_(UINT) Read(LPVOID lpBuf, UINT nCount)
	{
		if (nCount > m_wRestSize)
		{
			nCount = m_wRestSize;
		}
		nCount = m_pFile->Read(lpBuf, nCount);
		m_wRestSize -= nCount;
		return nCount;
	}
	STDMETHODIMP_(UINT) Skip(UINT nCount)
	{
		if (nCount > m_wRestSize)
		{
			nCount = m_wRestSize;
		}
		_ioSeekFile(m_pFile, nCount, SEEK_CUR);
		m_wRestSize -= nCount;
		return nCount;
	}
	STDMETHODIMP_(UINT) GetBlkSize()
	{
		return m_wBlkSize;
	}
	STDMETHODIMP_(UINT) GetRestSize()
	{
		return m_wRestSize;
	}
	
protected:
	File m_pFile;
	UINT m_wBlkSize;	// ��ǰ����Ϣ��
	UINT m_wRestSize;
};

// =========================================================================

struct KRecordHeader
{
	UINT	wTag;
	UINT	wSize;
	DWORD	dwReserved;
};

template <class File>
class KWPSRecordReader : public KRecordReaderBasic<File>
{
public:
	STDMETHODIMP NextRec(KRecordHeader* pRecHdr)
	{
		if (m_wRestSize)
		{
			HRESULT hr = _ioSeekFile(m_pFile, m_wRestSize, SEEK_CUR);
			if (hr != S_OK)
				return hr;
		}
		
		KWPSRecordHeader hdr;
		UINT cb = _ioReadFile(m_pFile, &hdr, sizeof(hdr));
		if (cb != sizeof(hdr))
		{
			m_wRestSize = m_wBlkSize = 0;
			return S_FALSE;
		}
		pRecHdr->wTag  = hdr.wTag;
		pRecHdr->wSize = m_wRestSize = m_wBlkSize = hdr.wSize;
		pRecHdr->dwReserved = hdr.dwReserved;
		return S_OK;
	}
};

template <class File>
class KExcelRecordReader : public KRecordReaderBasic<File>
{
public:
	STDMETHODIMP NextRec(KRecordHeader* pRecHdr)
	{
		if (m_wRestSize)
		{
			HRESULT hr = _ioSeekFile(m_pFile, m_wRestSize, SEEK_CUR);
			if (hr != S_OK)
				return hr;
		}
		
		KExcelRecordHeader hdr;
		UINT cb = _ioReadFile(m_pFile, &hdr, sizeof(hdr));
		if (cb != sizeof(hdr))
		{
			m_wRestSize = m_wBlkSize = 0;
			return S_FALSE;
		}
		pRecHdr->wTag  = hdr.wTag;
		pRecHdr->wSize = m_wRestSize = m_wBlkSize = hdr.wSize;
		pRecHdr->dwReserved = 0;
		return S_OK;
	}
};

// =========================================================================
// ����ET�ļ�¼ͷ�����̶�������Ҫ��������

template <class File>
class KETRecordReader : public KRecordReaderBasic<File>
{
public:
	STDMETHODIMP NextRec(KRecordHeader* pRecHdr)
	{
		if (m_wRestSize)
		{
			HRESULT hr = _ioSeekFile(m_pFile, m_wRestSize, SEEK_CUR);
			if (hr != S_OK)
				return hr;
		}
		
		_KETRecordHeader hdr;
		UINT cb = _ioReadFile(m_pFile, &hdr, sizeof(hdr));
		if (cb != sizeof(hdr))
		{
			m_wRestSize = m_wBlkSize = 0;
			return S_FALSE;
		}
		else
		{
			DWORD dwRecSize;
			if (hdr.wTag & 0x8000)
			{
				hdr.wTag &= 0x7fff;
				_ioReadFile(m_pFile, &dwRecSize, sizeof(DWORD));
			}
			else
			{
				dwRecSize = hdr.wSize;
			}
			m_wRestSize = m_wBlkSize = dwRecSize;
			pRecHdr->wTag  = hdr.wTag;
			pRecHdr->wSize = dwRecSize;
			pRecHdr->dwReserved = 0;
			return S_OK;
		}
	}
};

// =========================================================================

#endif /* __IO_RECORD_IN_H__ */
