
/*************************************************************************
	�ļ���:	WndCtrl.CPP  --  Implementation for CWPSWndCtrl

	˵��:	��������Ϊ WINWPS ���̵�һ����, ʵ��CWPSWndCtrl�࣬�Ա���WPS
			�ļ��в����׼��Windows����(EditCtrl��CheckBox��)

	���:	����

	����:	1998�� 7�� 9��
*************************************************************************/

#include "stdafx.h"

//#include "Resource.h"
//#include "winwps32.h"
//#include "MainFrm.h"
class CWPSDoc;
class CWPSView;
class CWPSObj;
//#include "FrameObj.h"
//#include "PageOP.h"
#include "WndCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//======================================================================

//void CalcWndPos (CWpsView* pView, const CRect& rcRef, CRect* prc)
//{
//	ASSERT (prc);
//	CRect rc = rcRef;
//	pView->DocToClient (rc);
//	pView->PageToPageBoard (rc);
//	pView->PageBoardToClient (rc);
//	*prc = rc;
//}

//LRESULT APIENTRY WPSWndCtrlProc (HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
//{
//	if (!hWnd)
//		return 0;
//
//	if (msg==WM_LBUTTONDOWN ||
//		msg==WM_RBUTTONDOWN ||
//		msg==WM_LBUTTONUP ||
//		msg==WM_RBUTTONUP ||
//		msg==WM_LBUTTONDBLCLK ||
//		msg==WM_MOUSEMOVE)
//	{
//		CWpsView* pView = GetCurView ();
//		if (pView)
//		{
//			POINT pt; VERIFY (GetCursorPos(&pt));
//			pView->ScreenToClient (&pt);
//			return pView->SendMessage (msg, wParam, MAKELPARAM(pt.x,pt.y));
//		}
//		return 0;
//	}
//
//	CWPSWndCtrl* pObj = (CWPSWndCtrl*)GetWindowLong (hWnd, GWL_USERDATA);
//	ASSERT_KINDOF (CWPSWndCtrl, pObj);
//	ASSERT_VALID (pObj);
////	TRACE1 ("msg: %d\n", msg);
//	if (msg==WM_DESTROY)
//	{
//#ifdef _DEBUG					// ����detach, ������˳�ʱ
//		pObj->DetachWnd();	// CWPSWndCtrl::AssertValid()�����
//#endif
////		IsWindow (hWnd);
////		MCIWndStop (hWnd);
////		MCIWndClose (hWnd);
//	}
//
//	WNDPROC pProc = pObj->GetPrevWndProc();
//	ASSERT (pProc);
//	return CallWindowProc (pProc, hWnd, msg, wParam, lParam);
//}


//======================================================================

/////////////////////////////////////////////////////////////////////////////
// CWPSWndCtrl

//IMPLEMENT_SERIAL(CWPSWndCtrl, CFPBase, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CWPSWndCtrl, CFPBase, 0xA0 | VERSIONABLE_SCHEMA)

CWPSWndCtrl::CWPSWndCtrl()
{
	m_hWnd = NULL;
	m_pPrevWndProc = NULL;
}

CWPSWndCtrl::~CWPSWndCtrl()
{
// ��Ϊview���Ӵ��ڣ�m_hWnd�ᱻ�Զ�ɾ���������ͼ��ڴ˶���
//	DeleteContent();
}

//DEL void CWPSWndCtrl::DeleteContent()
//DEL {
//DEL 	if (m_hWnd)
//DEL 	{	VERIFY (::DestroyWindow(m_hWnd)!=NULL);
//DEL 		m_hWnd = NULL;
//DEL 	}
//DEL }

#ifdef _DEBUG
void CWPSWndCtrl::Dump(CDumpContext& dc) const
{
	CFPBase::Dump(dc);
	dc << "\nI'm a CWPSWndCtrl object.\n";
}
void CWPSWndCtrl::AssertValid() const
{
//	CFPBase::AssertValid();

	if (m_hWnd)
		ASSERT (::IsWindow(m_hWnd));
}
//DEL void CWPSWndCtrl::DetachWnd()
//DEL {	ASSERT_VALID (this);
//DEL //	ASSERT (m_hWnd);	// Ϊʲô���յ�����WM_DESTROY, �����˴�����?
//DEL 	TRACE2 ("%s %u: MCIWnd detached.\n", __FILE__, __LINE__);
//DEL 	m_hWnd = NULL;
//DEL }
#endif //_DEBUG

CWPSWndCtrl::CWPSWndCtrl (const CWpsDoc* pDoc, const CRect& rc)
			:CFPBase(pDoc, rc)
{
	m_hWnd = NULL;
	m_pPrevWndProc = NULL;

	SetWPSObjType (WndCtrl);
	SetLPenStyle (PS_NULL);		// �ޱ߿�
	SetMasterPage (0);
}

/*
BOOL CWPSWndCtrl::InitClass (CWpsView* pView, LPCTSTR lpszFile)
{
	CRect rc; ::CalcWndPos (pView, m_rect, &rc);
	m_hWnd = CreateWindowEx (
		WS_EX_LEFT,
		"EDIT",
		"Hello",
		WS_CHILD | WS_VISIBLE | WS_BORDER | WS_THICKFRAME | WS_CLIPCHILDREN |
				   WS_CLIPSIBLINGS | ES_LEFT | ES_AUTOHSCROLL |
					ES_AUTOVSCROLL | ES_WANTRETURN | ES_MULTILINE,
		rc.left, rc.top, rc.Width(), rc.Height(),
		pView->m_hWnd,
		NULL,
		AfxGetInstanceHandle(),
		NULL);
}
*/

/***********************************************************************
	���ܣ�	������Subclass��ʵ��������ƶ����ڵȹ���
***********************************************************************/
//DEL BOOL CWPSWndCtrl::DoSubClass()
//DEL {	ASSERT_VALID (this);
//DEL 	m_pPrevWndProc = (WNDPROC)GetWindowLong (m_hWnd, GWL_WNDPROC);
//DEL 	ASSERT (m_pPrevWndProc);
//DEL 	SetWindowLong (m_hWnd, GWL_USERDATA, (LONG)this);
//DEL 	SetWindowLong (m_hWnd, GWL_WNDPROC, (LONG)WPSWndCtrlProc);
//DEL 	return TRUE;
//DEL }

/***********************************************************************
	���ܣ�	��������λ��/��С���������ʾ�����ı仯
***********************************************************************/
//DEL BOOL CWPSWndCtrl::AdjustWnd (CWpsView* pView)
//DEL {
//DEL 	if (!m_hWnd)
//DEL 		return TRUE;
//DEL 	CRect rc = m_rect;
//DEL 	if (IsFollowText())	// �������ĵ����
//DEL 	{	CWPSPage* pPage = pView->GetCurPage();
//DEL 		if (pPage)
//DEL 		{	ASSERT_VALID (pPage);
//DEL 			CFrameObj* pFrame = (CFrameObj*)pPage->GetFrameText();
//DEL 			if (pFrame)
//DEL 			{	ASSERT_VALID (pFrame);
//DEL 				CRect rcFrame = pFrame->m_rect;
//DEL 				rc.OffsetRect (rcFrame.left, rcFrame.top);
//DEL 			}
//DEL 		#ifdef _DEBUG
//DEL 			else ASSERT(FALSE);
//DEL 		#endif
//DEL 		}
//DEL 	#ifdef _DEBUG
//DEL 		else ASSERT(FALSE);
//DEL 	#endif
//DEL 	}
//DEL 	pView->DocToClient (rc);
//DEL 	pView->PageToPageBoard (rc);
//DEL 	pView->PageBoardToClient (rc);
//DEL 	CRect rcWnd; ::GetWindowRect (m_hWnd, &rcWnd);
//DEL 	BOOL bEC = FALSE;
//DEL 	if (rcWnd!=rc)
//DEL 	{	::MoveWindow (m_hWnd, rc.left, rc.top, rc.Width(), rc.Height(), TRUE);
//DEL 		bEC = TRUE;
//DEL 	}
//DEL 	return bEC;
//DEL }

//	�������캯��
//royho 20041213 ����������б�Ҫ��
#ifndef _WPSREADER
CWPSWndCtrl::CWPSWndCtrl (const CWPSWndCtrl* pObj)
{
	ASSERT_VALID (this);
	ASSERT_VALID (pObj);
	//royho 20041213 ������
	//	CopyObj (pObj);
}
#endif	// #ifndef _WPSREADER

//royho 20041213 ���ƶ����ʱ��Ż���õ��ˣ�Ӧ������Զ���������������
//#ifndef _WPSREADER
//void CWPSWndCtrl::CopyObj (const CWPSObj* pObj, BOOL b/*= TRUE*/)
//{
//	ASSERT_VALID (pObj);
//	//	���ƻ�������
//	CFPBase::CopyObj (pObj, b);
//
//	//	���Ʊ�������
//	ASSERT_KINDOF (CWPSWndCtrl, pObj);
//	CWPSWndCtrl* pWCObj = (CWPSWndCtrl*)pObj;
//	m_pPrevWndProc = NULL;
//	m_hWnd = NULL;
////	m_pPrevWndProc = pWCObj->m_pPrevWndProc;
////	m_hWnd = pWCObj->m_hWnd;
//// ����Ӧ��գ����Ǹ�������?
//}
//#endif	// #ifndef _WPSREADER

void CWPSWndCtrl::Serialize_98 (KSArchive& ar)
{
	CFPBase::Serialize_98 (ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << (DWORD)0;		// 8�ֽڻ���
		ar << (DWORD)0;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		DWORD dw1, dw2;
		ar >> dw1;		// 8�ֽڻ���
		ar >> dw2;

		// �ж϶���������Ƿ���Ч
		if (dw1 || dw2)
		{	ASSERT (FALSE);
			AfxThrowArchiveException (CArchiveException::badIndex);
		}
	}
}

void CWPSWndCtrl::Serialize_01(KSArchive& ar)
{
	CFPBase::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << (DWORD)0;		// 8�ֽڻ���
		ar << (DWORD)0;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		DWORD dw1, dw2;
		ar >> dw1;		// 8�ֽڻ���
		ar >> dw2;

		// �ж϶���������Ƿ���Ч
		if (dw1 || dw2)
		{	ASSERT (FALSE);
			AfxThrowArchiveException (CArchiveException::badIndex);
		}
	}
}

/*
BEGIN_MESSAGE_MAP(CWPSWndCtrl, CWnd)
	//{{AFX_MSG_MAP(CWPSWndCtrl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
*/

/////////////////////////////////////////////////////////////////////////////
// CWPSWndCtrl message handlers
