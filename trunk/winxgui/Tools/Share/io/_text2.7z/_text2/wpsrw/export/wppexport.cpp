/* -------------------------------------------------------------------------
//	�ļ���		��	wppexport.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 15:41:49
//	��������	��
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if defined(WPP_ONLY)
#include <pres/wppdoc.h>
#include "wppexport.h"
//#include <mso/io/powerpoint/writer.c>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
HRESULT gWriteCurrentUserStream (KWriteParam& param)
{
	HRESULT hr = S_OK;

	PSR_CurrentUserAtom cu;
	LPSTR lpAnsiName = NULL;
	UINT uReleaseVersion = 0x8;//For ppt97 file
	KBSTR bstrUserName;

	IWriteProxy* pProxy = NULL;
	KSRecWriter rw;

	bstrUserName = param.GetUserName ();
	if (!bstrUserName.GetLength ())
		bstrUserName = L"Unknown User";

	cu.size = sizeof (PSR_CurrentUserAtom);
	cu.magic = PPT_MAGICNUM;
	cu.majorVersion = 0xCF;//PPT2000
	cu.minorVersion = 0;
	cu.docFileVersion = 0x303f4;
	cu.offsetToCurrentEdit = param.GetDocument()->GetUserEditOffset();
	cu.lenUserName = ::BSTR2AnsiChar (bstrUserName, NULL, NULL) - 1;
	lpAnsiName = new char [cu.lenUserName + 1];
	::BSTR2AnsiChar (bstrUserName, lpAnsiName, cu.lenUserName + 1);

	hr = param.GetCurrentUserWriteProxy (&pProxy);
	if (SUCCEEDED (hr))
	{
		try
		{
			rw.SetTarget (pProxy)
				.StartRec (PST_CurrentUserAtom)
				.Write (&cu, sizeof (PSR_CurrentUserAtom))
				.Write (lpAnsiName, cu.lenUserName)
				.Write (&uReleaseVersion, 4)
				.EndRec ();

			hr = WriteEx (pProxy,
						  (BSTR)bstrUserName,
						  sizeof (WCHAR) * bstrUserName.GetLength ());
		}
		catch (KSRecWriterException e)
		{
			e.m_nExceptionCode;
			ASSERT (FALSE);
			hr = E_FAIL;
		}
		catch (...)
		{
			hr = E_FAIL;
		}
	}

	delete []lpAnsiName;
	RELEASE (pProxy);
	return hr;
}

STDMETHODIMP WppExportDoc(IN const CWPPDoc* pDoc, IN IStorage* pPPTRootStg)
{
	HRESULT hr = S_OK;
	MsoAutoFreeAlloc autoAlloc;
	KPPTDocument pptDocument;
	pptDocument.Initialize(&autoAlloc, FALSE);
	//
	CWPPDocContext docuCtx(pptDocument, autoAlloc, *((CWPPDoc*)pDoc));
	hr = ((CWPPDocExport*)pDoc)->Export(docuCtx);
	ASSERT(SUCCEEDED(hr));
	if(FAILED(hr))
		return hr;
	//
	KWriteParam param;
	param.SetStorage(pPPTRootStg);
	param.SetDocument(&pptDocument);
	hr = pptDocument.WriteDocData(param);

	hr = pptDocument.FinishDocStream(param, FALSE);
	hr = ::gWriteCurrentUserStream (param);

	return hr;
}

// -------------------------------------------------------------------------

EXPORTAPI WppExport(IN LPCWSTR szWppFile, IN IStorage* pPPTRootStg)
{
	USES_CONVERSION;

	CWPPDoc doc;
	BOOL fRet = doc.OnWPPFileLoad(W2A(szWppFile));
	ASSERT(fRet);

	if (!fRet)
		return E_FAIL;

	return WppExportDoc(&doc, pPPTRootStg);
}

STDMETHODIMP WppExportDoc(LPCWSTR szWppFile, IKFilterEventNotify* pNotify, IStorage* pPPTRootStg)
{
	USES_CONVERSION;

	CWPPDoc doc;
	doc.m_pNotify = pNotify;
	try
	{
		if (doc.OnWPPFileLoad(W2A(szWppFile)))
			return WppExportDoc(&doc, pPPTRootStg);
	}
	catch (...)
	{
		return E_FAIL;
	}
	ASSERT(FALSE);
	return E_FAIL;
}
// -------------------------------------------------------------------------

EXPORTAPI WppConvert(IN LPCWSTR szWppFile, IN LPCWSTR szPPTFile)
{
	USES_CONVERSION;

	CWPPDoc doc;
	BOOL fRet = doc.OnWPPFileLoad(W2A(szWppFile));
	ASSERT(fRet);

	if (!fRet)
		return E_FAIL;

	ks_stdptr<IStorage> spPPTRootStg;
	HRESULT hr = StgCreateDocfile(szPPTFile, STGM_G_CREATE, 0, &spPPTRootStg);
	ASSERT_OK(hr);
	if (FAILED(hr))
		return hr;

	return WppExportDoc(&doc, spPPTRootStg);
}

// -------------------------------------------------------------------------
#endif
