/* -------------------------------------------------------------------------
//	�ļ���		��	zlib/compress.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-29 17:37:06
//	��������	��	
//
// -----------------------------------------------------------------------*/
#include "stdafx.h"

#ifndef __IO_ZIP_H__
#include <wpsrw/io/zip.h>
#endif

#ifndef _ZLIB_H
#include "zlib/zlib.h"
#endif

// -------------------------------------------------------------------------

STDMETHODIMP zlibCompress(LPCVOID pSrc, UINT cbSize, HGBL* phGbl)
{
	HRESULT hr;
	HGBL hGbl = NULL;
	Bytef* pDest = NULL;
	UINT cbAfterCompress;
	
	ASSERT(Z_OK == S_OK && sizeof(UINT) >= sizeof(uLongf));
	
	cbAfterCompress = cbSize + cbSize/1000 + (12 + 4); //4 �Ƕ���ӵ�
	hGbl = XGlobalAlloc(GHND, cbAfterCompress);
	if (hGbl == NULL)
		return E_OUTOFMEMORY;
	
	try
	{
		pDest = (Bytef*)XGlobalLock(hGbl);
		hr = compress2(pDest, (uLongf*)&cbAfterCompress, (const Bytef*)pSrc, cbSize, Z_DEFAULT_COMPRESSION);
		XGlobalUnlock(hGbl);
	}
	catch (...)
	{
		hr = E_UNEXPECTED;
	}
	
	if (hr == Z_OK)
	{
		if (cbAfterCompress >= cbSize)
		{
			hr = S_ZIP_NONEED_COMPRESSION;
			goto lzExit;
		}
		*phGbl = XGlobalReAlloc(hGbl, cbAfterCompress, GHND);
		return S_OK;
	}
	
lzExit:
	XGlobalFree(hGbl);
	return hr;
}

// -------------------------------------------------------------------------
