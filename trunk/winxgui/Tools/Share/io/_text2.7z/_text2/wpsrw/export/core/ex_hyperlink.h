/* -------------------------------------------------------------------------
//	�ļ���		��	ex_hyperlink.h
//	������		��	����
//	����ʱ��	��	2004-10-25 3:02:31 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_HYPERLINK_H__
#define __EX_HYPERLINK_H__

// -------------------------------------------------------------------------
class CCtrlCode_HotRef;
class KWpsExport;
class KHyperLinkExport
{
public:
	KHyperLinkExport()
	{
		ClearHotRef();
	}
	~KHyperLinkExport() {}

protected:
	CCtrlCode_HotRef* m_pHotRef;
	KWpsExport* m_pExport;

protected:
	void SetHotRef(CCtrlCode_HotRef* pHotRef)
	{
		ASSERT(pHotRef != NULL);
		m_pHotRef = pHotRef;
	}
	void ClearHotRef()
	{
		m_pHotRef = NULL;
	}
	STDMETHODIMP HLProc_1(CCtrlCode_HotRef* pHotRef);
	STDMETHODIMP HLProc_2(CCtrlCode_HotRef* pHotRef);
	STDMETHODIMP HLProc_3(CCtrlCode_HotRef* pHotRef);
	STDMETHODIMP HLProc_Convert();
	STDMETHODIMP HLProc_Convert_CmdMakeup(LPWSTR lpszBuf, int cbSize);
	STDMETHODIMP HLProc_Convert_CorePara(LPWSTR lpszBuf, int cbSize);
	
public:
	STDMETHODIMP Convert(KWpsExport& export, CCtrlCode_HotRef* pHotRef);
	
};

// -------------------------------------------------------------------------

#endif /* __EX_HYPERLINK_H__ */
