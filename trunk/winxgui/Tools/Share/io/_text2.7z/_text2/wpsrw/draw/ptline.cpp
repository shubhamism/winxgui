/* -------------------------------------------------------------------------
//	�ļ���		��	ptline.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-21 14:52:26
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CLineObj, CPTObj, 0xA0 | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

void CLineObj::Serialize_97(CArchive& ar)
{
	CPTObj::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		INT16 wTemp;
		for (int i=0; i < 2; i++)
		{
			ar >>  wTemp; m_linepnt[i].x = wTemp;
			ar >>  wTemp; m_linepnt[i].y = wTemp;
		}
		ar >> wTemp;
		m_nlineobjShape = (LineObjShape)wTemp;
	}
	CWPSObj::SerializeObjType(ar);
}

void CLineObj::Serialize_98(CArchive& ar)
{
	CPTObj::Serialize_98(ar);
	if (ar.IsStoring())
	{	
		ar << m_linepnt[0];
		ar << m_linepnt[1];
		ar << m_nlineobjShape;
		if (m_nlineobjShape == linkLine || m_nlineobjShape == linkBezier)
		{	
			ar << (int) m_bVert;
			ar << m_handle3;
		}
	}
	else
	{	
		ar >> m_linepnt[0];
		ar >> m_linepnt[1];
		int nTemp;
		ar >> nTemp;
		m_nlineobjShape = (LineObjShape)nTemp;
		if (m_nlineobjShape == linkLine || m_nlineobjShape == linkBezier)
		{
			int iTemp;
			ar >> iTemp;
			m_bVert = (BOOL)iTemp;
			ar >> m_handle3;
		}

	}
	CWPSObj::SerializeObjType(ar);
}

void CLineObj::Serialize_01(CArchive& ar)
{
	CPTObj::Serialize_01(ar);
	if (ar.IsStoring())
	{	
		ar << m_linepnt[0];
		ar << m_linepnt[1];
		ar << m_nlineobjShape;
		if (m_nlineobjShape == linkLine || m_nlineobjShape == linkBezier)
		{	
			ar << (int) m_bVert;
			ar << m_handle3;
		}
	}
	else
	{	
		ar >> m_linepnt[0];
		ar >> m_linepnt[1];
		int nTemp;
		ar >> nTemp;
		m_nlineobjShape = (LineObjShape)nTemp;
		if (m_nlineobjShape == linkLine || m_nlineobjShape == linkBezier)
		{
			int iTemp;
			ar >> iTemp;
			m_bVert = (BOOL)iTemp;
			ar >> m_handle3;
		}
	}
	CWPSObj::SerializeObjType(ar);
}

