/* -------------------------------------------------------------------------
//	�ļ���		��	ex_textpapx.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 11:12:39
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_wpsdoc.h"

#ifndef __EX_SHAPE_H__
#include "../draw/ex_shape.h"
#endif

//lijun
#ifndef __STYLE_TEXT_H__
#include "../../core/style_text.h"
#endif

#ifndef __STYLESHEET_TEXT_H__
#include "../../core/stylesheet_text.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

CtrlCodeClassDecl(SETHALIGNMENT, CCtrlCode_Alignment);
CtrlCodeClassDecl(SETVALIGNMENT, CCtrlCode_Alignment);
CtrlCodeClassDecl(SETLINEMARGIN,  CCtrlCode_LineMargin);
CtrlCodeClassDecl(SETPARAMARGIN,  CCtrlCode_ParaMargin);
CtrlCodeClassDecl(SETAFPAMARGIN,  CCtrlCode_ParaMargin);
CtrlCodeClassDecl(SETFIRSTINDENT, CCtrlCode_ParaIndent);
CtrlCodeClassDecl(SETLEFTINDENT,  CCtrlCode_ParaIndent);
CtrlCodeClassDecl(SETRIGHTINDENT, CCtrlCode_ParaIndent);
CtrlCodeClassDecl(SETTABS, CCtrlCode_Tabs);
CtrlCodeClassDecl(SETAUTONUMBER,  CCtrlCode_AutoNumber);
CtrlCodeClassDecl(SETPARAFRAME,   CCtrlCode_ParaFrame);

//����id�����ִ���ʽ���еõ��ֺſ�����	
CCtrlCode_Size *GetFSFormStyleSheet(KWpsExport& export, DWORD dwID, CString styleName)
{
	DWORD dwStyleID = dwID;
	CString strStyleName = styleName;
	CStyle_Text *styleText = NULL;
	CCtrlCode_Size *pCodesize = NULL;
	CStyleSheet_Text* pSheet_WPS = export.m_pDoc->GetStyleSheet_Text();
	
	while (dwID != 0)
	{
		styleText = (CStyle_Text *)pSheet_WPS->GetStyle(dwID, strStyleName);
		if (styleText == NULL)
		{
			break;
		}
		pCodesize = (CCtrlCode_Size *)styleText->GetCtrlCode(SETFONTSIZE);
		if ( pCodesize != NULL)
		{
			return pCodesize;
			break;
		}
		else
		{
			dwID = styleText->GetBaseStyleID();
			strStyleName = styleText->GetBaseStyleName();
		}
	}
	return NULL;
}

//lijun �Ӷ����еõ���ߵ�����ĸ߶�, 
//nFromSenNum, nToSenNum �ֱ��ʾ�Ӵ˶����Ǿ俪ʼ���Ǿ����
LONG GetFSFormPara(KWpsExport& export, CParagraph *pPara, int nFromSenNum, int nToSenNum)
{
	tagFONTSIZE fontSize;
	CSentence *sen = NULL;	
	CCtrlCode_Size *pCodesize = NULL;
	CCtrlCode_Size *pCodesize1 = NULL;
	LONG nFontWidth = 0;
	
	memset((void *)&fontSize, 0, sizeof(fontSize));
	if (pPara == NULL)
		return 0;
	pCodesize = GetFSFormStyleSheet(export, pPara->m_dwStyleID, pPara->m_strStyleName);		
	for (int i = nFromSenNum; i < nToSenNum; i++)
	{
		sen = pPara->GetSentence(i);
		pCodesize1 = (CCtrlCode_Size*)sen->GetCtrlCode(SETFONTSIZE);
		if (pCodesize1 != NULL)
		{
			fontSize.nfsSize = pCodesize1->GetSize();
			fontSize.nfsUnit = pCodesize1->GetUnit();
			if (GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND) > nFontWidth)
				nFontWidth = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);
		}
		else
		{
			pCodesize1 = GetFSFormStyleSheet(export, sen->GetStyleID(), sen->GetStyleName());
			if (pCodesize1 != NULL)
			{
				fontSize.nfsSize = pCodesize1->GetSize();
				fontSize.nfsUnit = pCodesize1->GetUnit();
				if (GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND) > nFontWidth)
					nFontWidth = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);
			}
		}
	}
	if (nFontWidth == 0)
	{
		if(pCodesize != NULL)			
			nFontWidth = GetFontSizeHM(pCodesize->GetSize(), pCodesize->GetUnit());	
		else					
			nFontWidth = GetFontSizeHM(9, 1);	
	}
	return nFontWidth;
}

EX_CONV_API PapxCtrlCode_Context::GenHAlignmentCode(CCtrlCode_Alignment* pCode, KDWPropBuffer& papx)
{		
	INT32 jc=mso_jcLeftAndRightJustify;
	WORD wGetalgn=pCode->GetAlignment();
	switch (wGetalgn)
	{
	case TAL_LEFT:
		jc = mso_jcLeftJustify;
		break;
	case TAL_HCENTER:
		jc = mso_jcCenter;
		break;
	case TAL_RIGHT:
		jc = mso_jcRightJustify;
		break;
	case TAL_JUSTIFIED:
		jc = mso_jcLeftAndRightJustify;
		break;
	case TAL_FULLJUSTIFIED:
		jc = mso_jcMediumJustify;
		break;
	default:
		ASSERT(pCode->GetAlignment() == TAL_LEFT);
		jc = mso_jcLeftJustify;
	}
	papx.AddPropFix(sprmPJc,jc);
	papx.AddPropFix(sprmPJcEx,jc);
}

// �ı����뷽ʽ
EX_CONV_API PapxCtrlCode_Context::GenVAlignmentCode(CCtrlCode_Alignment* pCode, KDWPropBuffer& papx)
{
	WORD wGetAlign=pCode->GetAlignment();
	WORD vAlign = 2;
	switch(wGetAlign)
	{
	case TAL_TOP:
		vAlign = 0;		
		break;
	case TAL_VCENTER:
		vAlign = 1;		
		break;		
	case TAL_BOTTOM:
		vAlign = 3;		
		break;
	default:
		papx.AddPropFix(sprmPWAlignFont,2);
	}
	papx.AddPropFix(sprmPWAlignFont,vAlign);
}

EX_CONV_API PapxCtrlCode_Context::GenLineMarginCode(CCtrlCode_LineMargin* pCode, KDWPropBuffer& papx)
{	
	const UNIT_VALUE* pUVal=pCode->GetLineMargin();
	union
	{
		LSPD lspd;
		INT32 val;
	};
	//lijun �м��ת��
	CCtrlCode_Size *pCodesize = NULL;
	CCtrlCode *pCtrlCode = NULL;
	CParagraph *pPara = NULL;
	INT16 nFontWidth = 0;
	tagFONTSIZE fontSize;
	//�����е����ԱȽ�����Ҫ�ȿ����������
	if (m_export.m_pTblEleAttri != NULL)
	{
		POSITION pos = 0;
		for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
		{
			pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
			if (pCtrlCode->GetCodeID() == SETFONTSIZE)
			{
				pCodesize = (CCtrlCode_Size *)pCtrlCode;
				fontSize.nfsSize = pCodesize->GetSize();
				fontSize.nfsUnit = pCodesize->GetUnit();
				nFontWidth = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);
				break;
			}
		}
	}
	else
	{
		if (GetParaContent() == NULL || GetParaContent()->GetParagraph() == NULL)
			nFontWidth = GetFontSizeHM(9, FALSE);
		else		
		{
			pPara = GetParaContent()->GetParagraph();
			nFontWidth = GetFSFormPara(m_export, pPara, 0, pPara->NumOfSentences());
		}
	}

	switch(pUVal->wUnit)
	{
	case UNIT_PERCENT:
		lspd.fMultLinespace=1;
		//�ٷֱ�ֵ������Ҫ��word�е�ֵҪ��,���ﲻ���ѳ���һ��ϵ��,�������ϵ�����Ǻ�׼ȷ
		//�м�����ֵ��0��ʱ�����⴦��һ��,������ɾ����и�.
		if (pUVal->nValue == 0)
		{
			lspd.fMultLinespace = 0;
			lspd.dyaLine = 0;
		}
		else
			lspd.dyaLine=12*(pUVal->nValue+100)/5 * 0.85;
		papx.AddPropFix(sprmPDyaLine,val);
		break;
	//lijun
	//���Ե�λ
	case UNIT_METRIC:
		{		
			lspd.fMultLinespace = 0;
			lspd.dyaLine = (pUVal->nValue * 10 + nFontWidth) * 0.56736 * 1.04;
			papx.AddPropFix(sprmPDyaLine,val);
			break;
		}	
	//�̶�ֵ
	case UNIT_EXACT:
		{		
			lspd.fMultLinespace = 0;
			lspd.dyaLine = -(pUVal->nValue * 10 + nFontWidth) * 0.56736;
			papx.AddPropFix(sprmPDyaLine,val);
			break;
		}
	//��Сֵ
	case  UNIT_MIN:
		{		
			lspd.fMultLinespace = 0;
			lspd.dyaLine = (pUVal->nValue * 10 + nFontWidth) * 0.56736 * 1.04;
			papx.AddPropFix(sprmPDyaLine,val);
			break;
		}	
	default://@@todo
		;//ASSERT_ONCE(0);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenParaMarginCode(CCtrlCode_ParaMargin* pCode, KDWPropBuffer& papx)
{	
	const UNIT_VALUE* pUVal=pCode->GetParaMargin();
	switch(pUVal->wUnit)
	{
	case UNIT_METRIC:
		papx.AddPropFix(sprmPDyaBefore,lm2twip(pUVal->nValue));
		break;
	case UNIT_PERCENT://to do
//		papx.AddPropFix(sprmPDyaBeforeRel,pUVal->nValue);
//		break;
		{
			//lijun ����word��wps���еĸ��ͬ,����Ķμ����Ĳ�׼,���»���
			tagFONTSIZE fontSize;
			CCtrlCode_Size *pCodesize = NULL;
			CCtrlCode *pCtrlCode = NULL;
			CParagraph *pPara = NULL;
			LONG nFontHeight;
			//�����е����ԱȽ�����Ҫ�ȿ����������
			if (m_export.m_pTblEleAttri != NULL)
			{
				POSITION pos = 0;
				for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
				{
					pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
					if (pCtrlCode->GetCodeID() == SETFONTSIZE)
					{
						pCodesize = (CCtrlCode_Size *)pCtrlCode;
						fontSize.nfsSize = pCodesize->GetSize();
						fontSize.nfsUnit = pCodesize->GetUnit();
						nFontHeight = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);
						break;
					}
				}
			}
			else
			{			
				if (GetParaContent() == NULL || GetParaContent()->GetParagraph() == NULL)
					nFontHeight = GetFontSizeHM(9, FALSE);
				else
				{
					pPara = GetParaContent()->GetParagraph();
					nFontHeight = GetFSFormPara(m_export, pPara, 0, 1);				
				}
				papx.AddPropFix(sprmPDyaBeforeRel, 0);
				papx.AddPropFix(sprmPDyaBefore, nFontHeight * 0.56736 * pUVal->nValue * 0.01);
			}	
			break;			
		}
	default:
		ASSERT_ONCE(0);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenAfterParaMarginCode(CCtrlCode_ParaMargin* pCode, KDWPropBuffer& papx)
{
	const UNIT_VALUE* pUVal=pCode->GetParaMargin();
	switch(pUVal->wUnit)
	{
	case UNIT_METRIC:
		papx.AddPropFix(sprmPDyaAfter,lm2twip(pUVal->nValue));
		break;
	case UNIT_PERCENT://to do
		//papx.AddPropFix(sprmPDyaAfterRel,pUVal->nValue);
		//lijun ����word��wps���еĸ��ͬ,����Ķμ����Ĳ�׼,���»���
		{
			//lijun
			tagFONTSIZE fontSize;
			CSentence* sen = NULL;	
			CCtrlCode_Size *pCodesize = NULL;
			CCtrlCode *pCtrlCode = NULL;
			CParagraph *pPara = NULL;
			LONG nFontHeight = 0;
			//�����е����ԱȽ�����Ҫ�ȿ����������
			if (m_export.m_pTblEleAttri != NULL)
			{
				POSITION pos = 0;
				for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
				{
					pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
					if (pCtrlCode->GetCodeID() == SETFONTSIZE)
					{
						pCodesize = (CCtrlCode_Size *)pCtrlCode;
						fontSize.nfsSize = pCodesize->GetSize();
						fontSize.nfsUnit = pCodesize->GetUnit();
						nFontHeight = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);
						break;
					}
				}
			}
			else
			{			
				if (GetParaContent() == NULL || GetParaContent()->GetParagraph() == NULL)
					nFontHeight = GetFontSizeHM(9, FALSE);
				else
				{
					pPara = GetParaContent()->GetParagraph();
					nFontHeight = GetFSFormPara(m_export, pPara, 0, 1);	
				}
			}			
			papx.AddPropFix(sprmPDyaAfterRel, 0);
			papx.AddPropFix(sprmPDyaAfter, nFontHeight * 0.56736 * pUVal->nValue * 0.01);
			break;			
		}
	default:
		ASSERT_ONCE(0);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenFirstIndentCode(CCtrlCode_ParaIndent* pCode, KDWPropBuffer& papx)
{
	const UNIT_VALUE* pUVal=pCode->GetIndent();	
	switch(pUVal->wUnit)
	{
	case UNIT_METRIC:
		papx.AddPropFix(sprmPDxaLeft1,lm2twip(pUVal->nValue));
		papx.AddPropFix(sprmPDxaLeft1Ex,lm2twip(pUVal->nValue));		
		break;
	case UNIT_GRID://to do
		{
			//lijun
			tagFONTSIZE fontSize;
			WORD wAspectX = 100;
			CSentence* sen = NULL;	
			CCtrlCode_Size *pCodesize = NULL;
			CCtrlCode_AspectX *pAspectX = NULL;
			CCtrlCode *pCtrlCode = NULL;
			CParagraph *pPara = NULL;
			LONG nFontWidth = 0;
			//�����е����ԱȽ�����Ҫ�ȿ����������
			if (m_export.m_pTblEleAttri != NULL)
			{
				POSITION pos = 0;
				for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
				{
					pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
					if (pCtrlCode->GetCodeID() == SETFONTSIZE)
					{
						pCodesize = (CCtrlCode_Size *)pCtrlCode;
						fontSize.nfsSize = pCodesize->GetSize();
						fontSize.nfsUnit = pCodesize->GetUnit();
						nFontWidth = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);						
					}
					if (pCtrlCode->GetCodeID() == SETASPECTX);
						wAspectX = pAspectX->GetAspectX();
				}
			}
			else
			{							
				if (GetParaContent() == NULL || GetParaContent()->GetParagraph() == NULL)
					nFontWidth = GetFontSizeHM(9, FALSE);
				else
				{
					pPara = GetParaContent()->GetParagraph();
					nFontWidth = GetFSFormPara(m_export, pPara, 0, 1);
					sen = pPara->GetSentence(0);
					pAspectX = (CCtrlCode_AspectX*)sen->GetCtrlCode(SETASPECTX);
					if (pAspectX != NULL)			
						wAspectX = pAspectX->GetAspectX();	
				}
			}
			papx.AddPropFix(sprmPDxaLeft1Rel, 0);
			papx.AddPropFix(sprmPDxaLeft1, nFontWidth * 
				0.56736 * wAspectX * 0.01 * pUVal->nValue);
			
			papx.AddPropFix(sprmPDxaLeft1Ex, nFontWidth * 
				0.56736 * wAspectX * 0.01 * pUVal->nValue);
			//����ʵ�ʹ۲�������wps�¶����������ּ��û�й�ϵ,����û�а���sprmPDxaLeftRel
			//�����������������,���ڵļ��㹫ʽΪ"�������� = �ֺ�*���峤����"
			break;			
		}
	default:
		ASSERT_ONCE(0);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenLeftIndentCode(CCtrlCode_ParaIndent* pCode, KDWPropBuffer& papx)
{	
	const UNIT_VALUE* pUVal=pCode->GetIndent();
	switch(pUVal->wUnit)
	{
	case UNIT_METRIC:
		{
			// ����Word����ԵĴ�����ʽ�����⣬�������0��word����Ϊ����Եģ�
			// ���Դ˴�ǿ��ת��һ����Сֵ��ǿ��word���վ���ֵ����
			int nLeftIndent = 1;
			if (pUVal->nValue == 0)
				nLeftIndent = 1;//lm2twip(0x5a);
			else
				nLeftIndent = lm2twip(pUVal->nValue);

			papx.AddPropFix(sprmPDxaLeft, nLeftIndent);
			papx.AddPropFix(sprmPDxaLeftEx, nLeftIndent);
		}
		break;
	case UNIT_GRID://to do	
		{
			//lijun 
			tagFONTSIZE fontSize;
			WORD wAspectX = 100;
			CSentence* sen = NULL;	
			CCtrlCode_Size *pCodesize = NULL;
			CCtrlCode_AspectX *pAspectX = NULL;
			CCtrlCode *pCtrlCode = NULL;
			CParagraph *pPara = NULL;
			LONG nFontWidth = 0;
			//�����е����ԱȽ�����Ҫ�ȿ����������
			if (m_export.m_pTblEleAttri != NULL)
			{
				POSITION pos = 0;
				for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
				{
					pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
					if (pCtrlCode->GetCodeID() == SETFONTSIZE)
					{
						pCodesize = (CCtrlCode_Size *)pCtrlCode;
						fontSize.nfsSize = pCodesize->GetSize();
						fontSize.nfsUnit = pCodesize->GetUnit();
						nFontWidth = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);					
					}
					if (pCtrlCode->GetCodeID() == SETASPECTX);
						wAspectX = pAspectX->GetAspectX();	
				}
			}
			else
			{			
				if (GetParaContent() == NULL || GetParaContent()->GetParagraph() == NULL)			
					nFontWidth = GetFontSizeHM(9, FALSE);
				else
				{
					pPara = GetParaContent()->GetParagraph();
					nFontWidth = GetFSFormPara(m_export, pPara, 0, 1);
					sen = pPara->GetSentence(0);
					pAspectX = (CCtrlCode_AspectX*)sen->GetCtrlCode(SETASPECTX);
					if (pAspectX != NULL)			
						wAspectX = pAspectX->GetAspectX();	
				}
			}
			papx.AddPropFix(sprmPDxaLeftRel, 0);
			papx.AddPropFix(sprmPDxaLeft, nFontWidth * 
				0.56736 * wAspectX * 0.01 * pUVal->nValue);
			papx.AddPropFix(sprmPDxaLeftEx, nFontWidth * 
							0.56736 * wAspectX * 0.01 * pUVal->nValue);
			//����ʵ�ʹ۲�������wps�¶����������ּ��û�й�ϵ,����û�а���sprmPDxaLeftRel
			//�����������������,���ڵļ��㹫ʽΪ"�������� = �ֺ�*���峤����"
			break;			
		}
	default:
		ASSERT_ONCE(0);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenRightIndentCode(CCtrlCode_ParaIndent* pCode, KDWPropBuffer& papx)
{	
	const UNIT_VALUE* pUVal=pCode->GetIndent();
	switch(pUVal->wUnit)
	{
	case UNIT_METRIC:
		papx.AddPropFix(sprmPDxaRight,lm2twip(pUVal->nValue));
		papx.AddPropFix(sprmPDxaRightEx,lm2twip(pUVal->nValue));
		break;		
	case UNIT_GRID://to do	
		{
			//lijun
			tagFONTSIZE fontSize;
			WORD wAspectX = 100;
			CCtrlCode_Size *pCodesize = NULL;
			CCtrlCode_AspectX *pAspectX = NULL;
			CCtrlCode *pCtrlCode = NULL;
			CParagraph *pPara = NULL;
			CSentence *sen = NULL;
			LONG nFontWidth = 0;
			//�����е����ԱȽ�����Ҫ�ȿ����������
			if (m_export.m_pTblEleAttri != NULL)
			{
				POSITION pos = 0;
				for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
				{
					pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
					if (pCtrlCode->GetCodeID() == SETFONTSIZE)
					{
						pCodesize = (CCtrlCode_Size *)pCtrlCode;
						fontSize.nfsSize = pCodesize->GetSize();
						fontSize.nfsUnit = pCodesize->GetUnit();
						nFontWidth = GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND);						
					}
					if (pCtrlCode->GetCodeID() == SETASPECTX);
						wAspectX = pAspectX->GetAspectX();					
				}
			}
			else
			{			
				if (GetParaContent() == NULL || GetParaContent()->GetParagraph() == NULL)
					nFontWidth = GetFontSizeHM(9, FALSE);
				else
				{
					pPara = GetParaContent()->GetParagraph();
					nFontWidth = GetFSFormPara(m_export, pPara, 0, 1);
					sen = pPara->GetSentence(0);
					pAspectX = (CCtrlCode_AspectX*)sen->GetCtrlCode(SETASPECTX);
					if (pAspectX != NULL)			
						wAspectX = pAspectX->GetAspectX();
				}
			}
			papx.AddPropFix(sprmPDxaRightRel, 0);
			papx.AddPropFix(sprmPDxaRight, nFontWidth * 0.56736 * wAspectX * 0.01 * pUVal->nValue);			
			papx.AddPropFix(sprmPDxaRightEx, nFontWidth * 0.56736 * wAspectX * 0.01 * pUVal->nValue);
			//����ʵ�ʹ۲�������wps�¶����������ּ��û�й�ϵ,����û�а���sprmPDxaLeftRel
			//�����������������,���ڵļ��㹫ʽΪ"�������� = �ֺ�*���峤����"
			break;			
		}
	default:
		ASSERT_ONCE(0);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenTabsCode(CCtrlCode_Tabs* pCode, KDWPropBuffer& papx)
{
	PTABITEM pti = pCode->GetTabs();
	for(int i = 0; i < MAXTABSTOPS + 1; i++)
	{
		TABITEM& ti = pti[i];
		if(ti.nTabPosition == 0)
			break;
		INT16 dxa = WpsShapeToTwip(ti.nTabPosition);
		//����Ĭ���Ʊ�λ
		if(i == 0 && !m_export.m_bSetDopDefaultTabStops && GetParaContent() && GetParaContent()->GetParagraph())
		{
			m_export.m_bSetDopDefaultTabStops = TRUE;
			KDWDocProperties& dop = m_export.GetDop();
			dop.dop.dxaTab = dxa;
		}
		TBD tbd;
		tbd.jc = mso_tbdLeftTab;
		switch(ti.wFrontChar)
		{
		default:
		case FC_SYSTEM://			1		// ϵͳĬ����ǰ��
			tbd.tlc = mso_tbdNoLeader;
			break;
		case FC_POINT://			2		// �Ե�Ϊǰ��
			tbd.tlc = mso_tbdDottedLeader;
			break;
		case FC_MINUS://			3		// ��"-"Ϊǰ��
			tbd.tlc = mso_tbdHyphenatedLeader;
			break;
		case FC_HYPHEN://			4		// ��"_"Ϊǰ��
			tbd.tlc = mso_tbdSingleLineLeader;
			break;
		}
		tbd.reserved = 0;
		if(i != 0)
		{
			//����Ŀ¼��Ŀ������tab,��ΪĿ¼��Ŀʹ�����Ʊ�λ����תĿ¼ʱ����
			if(GetParaContent() && GetParaContent()->GetParagraph() && GetParaContent()->GetParagraph()->m_lSerialID >= 0)
			{
				papx.AddTabStops(1, &dxa, &tbd);
			}
		}
		else
		{
			//@@todo wpsÿ���ζ�������Ĭ���Ʊ�λ����word�е�Ĭ���Ʊ�λ�����DOP�У�����һ����չָ���¼ÿ���ε�Ĭ���Ʊ�λ
		}
	}
	
}

EX_CONV_API PapxCtrlCode_Context::GenAutoNumberCode(CCtrlCode_AutoNumber* pCode, KDWPropBuffer& papx)
{
	const AUTONUMPARAREF* pParaRef	= pCode->GetRefData();
	if (pParaRef)
	{
		KAutoNumGroupSPtr spGroup= pParaRef->m_AuoNumGroupSPtr;
		UINT uIndex = m_export.AddAutonumGroup(spGroup);
		papx.AddPropFix(sprmPIlfo, uIndex);
		papx.AddPropFix(sprmPIlvl, pParaRef->m_nLevel);
	}
}

EX_CONV_API PapxCtrlCode_Context::GenParaFrameCode(CCtrlCode_ParaFrame* pCode, KDWPropBuffer& papx)
{	
	/*
	//WPS�в������ö���߿�ֻ���ַ��߿�
	PARAFRAME frame = pCode->GetParaFrame();
	union
	{
		BRC topBrc;
		UINT32 ValtopBrc;
	}TOPBRC;
	TOPBRC.ValtopBrc = 0;
	TOPBRC.topBrc.brcType = frame.nPenStyleTop;
	TOPBRC.topBrc.dptLineWidth = frame.nWidthTop;
	TOPBRC.topBrc.dptSpace = frame.lDistanceT;
	TOPBRC.topBrc.ico = frame.dwColorTop;
	papx.AddPropFix(sprmPBrcTop,TOPBRC.ValtopBrc);
	papx.AddPropVar(sprmPBrcTopEx,TOPBRC.ValtopBrc);
	union
	{
		BRC leftBrc;
		UINT32 ValleftBrc;
	}LEFTBRC;
	LEFTBRC.ValleftBrc = 0;
	LEFTBRC.leftBrc.brcType = frame.nPenStyleLeft;
	LEFTBRC.leftBrc.dptLineWidth = frame.nWidthLeft;
	LEFTBRC.leftBrc.dptSpace = frame.lDistanceL;
	LEFTBRC.leftBrc.ico = frame.dwColorLeft;
	papx.AddPropFix(sprmPBrcLeft,LEFTBRC.ValleftBrc);
	papx.AddPropVar(sprmPBrcLeftEx,LEFTBRC.ValleftBrc);
	union
	{
		BRC rightBrc;
		UINT32 ValrightBrc;
	}RIGHTBRC;
	RIGHTBRC.ValrightBrc = 0;
	RIGHTBRC.rightBrc.brcType = frame.nPenStyleRight;
	RIGHTBRC.rightBrc.dptLineWidth = frame.nWidthRight;
	RIGHTBRC.rightBrc.dptSpace = frame.lDistanceR;
	RIGHTBRC.rightBrc.ico = frame.dwColorRight;
	papx.AddPropFix(sprmPBrcRight,RIGHTBRC.ValrightBrc);
	papx.AddPropVar(sprmPBrcRightEx,RIGHTBRC.ValrightBrc);
	union
	{
		BRC bottomBrc;
		UINT32 ValbottomBrc;
	}BOTTOMBRC;
	BOTTOMBRC.ValbottomBrc = 0;
	BOTTOMBRC.bottomBrc.brcType = frame.nPenStyleBottom;
	BOTTOMBRC.bottomBrc.dptLineWidth = frame.nWidthBottom;
	BOTTOMBRC.bottomBrc.dptSpace = frame.lDistanceB;
	BOTTOMBRC.bottomBrc.ico = frame.dwColorBottom;
	papx.AddPropFix(sprmPBrcBottom,BOTTOMBRC.ValbottomBrc);
	papx.AddPropVar(sprmPBrcBottomEx,BOTTOMBRC.ValbottomBrc); */
}

// -------------------------------------------------------------------------

EX_BEGIN_CONV(PapxCtrlCode_Context)
	EX_ADD_CONV(SETHALIGNMENT,  GenHAlignmentCode)
	EX_ADD_CONV(SETVALIGNMENT,  GenVAlignmentCode)
	EX_ADD_CONV(SETLINEMARGIN,  GenLineMarginCode)
	EX_ADD_CONV(SETPARAMARGIN,  GenParaMarginCode)
	EX_ADD_CONV(SETAFPAMARGIN,  GenAfterParaMarginCode)
	EX_ADD_CONV(SETFIRSTINDENT, GenFirstIndentCode)
	EX_ADD_CONV(SETLEFTINDENT,  GenLeftIndentCode)
	EX_ADD_CONV(SETRIGHTINDENT, GenRightIndentCode)
	EX_ADD_CONV(SETTABS, 	    GenTabsCode)
	EX_ADD_CONV(SETAUTONUMBER,  GenAutoNumberCode)
	EX_ADD_CONV(SETPARAFRAME,   GenParaFrameCode)
EX_END_CONV()

// -------------------------------------------------------------------------
