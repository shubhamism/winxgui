//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainCalendar.cpp
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-5-31 16:12:38
//	FileDescription	:	
//
//////////////////////////////////////////////////////////////////////////////////////

// KSDomainCalendar.cpp: implementation of the KSDomainCalendar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "KSDomainCalendar.h"

#ifndef __WPSOBJ_H
	#include "Wpsobj.h"
#endif

#ifndef __PTOBJ_H
	#include "Ptobj.h"
#endif

extern DWORD g_dwLanguageVersion;
extern DWORD g_dwResourceLanguage;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define LB_NOSELECT 0x10

IMPLEMENT_SERIAL(KSDomainCalendar,CLtxtObj,0xA0 | VERSIONABLE_SCHEMA)

KSDomainCalendar::KSDomainCalendar()
{
	m_pMonthView = NULL;
}

KSDomainCalendar::~KSDomainCalendar()
{
	ASSERT_VALID(this);
	if (m_pMonthView)
	{
		delete m_pMonthView;
		m_pMonthView = NULL;
	}
	
}

KSDomainCalendar::KSDomainCalendar(const CWpsDoc* pDoc, 
							      const CRect& position, 
					           int nShape/*=rectangle*/)
					 : CLtxtObj(pDoc,position,rectangle) 
{
	m_pMonthView = NULL;
	m_bSelect = FALSE;
	m_sSelectDate = "";
	m_bBackGround = FALSE;
	m_uLPenStyle = PS_NULL;
/*
	SetBkMode(OPAQUE);					// �����:���
	SetBkColor(RGB(192, 192, 192));		// ��ɫ
	SetFillLogBrush(0, RGB(192, 192, 192), 0);
*/
}

KSDomainCalendar::KSDomainCalendar(const KSDomainCalendar* pObj)
{
	ASSERT_VALID(pObj);
//	CopyObj(pObj,TRUE);
	m_bSelect = FALSE;
	m_sSelectDate = "";
}

void KSDomainCalendar::Serialize_01(KSArchive& ar)
{
	CLtxtObj::Serialize_01(ar);
	if (ar.IsStoring())
	{
		ar << m_bSelect;
		ar << m_sSelectDate;
		ar << m_nStyleIndex;
		ar << m_nTimeIndex;
		ar << m_bBackGround;
	}
	else
	{
		ar >> m_bSelect;
		ar >> m_sSelectDate;
		ar >> m_nStyleIndex;
		ar >> m_nTimeIndex;
		ar >> m_bBackGround;
	}
	CWPSObj::SerializeObjType(ar);
}
