/* -------------------------------------------------------------------------
//	�ļ���		��	doswps.h
//	������		��	������
//	����ʱ��	��	2005-4-1 13:38:00
//	��������	��	
//
//	$Id: doswps.h,v 1.1 2005/04/05 06:41:20 duanyuluo Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOSWPS_H__
#define __DOSWPS_H__

#include "../export/export.h"
#include "kfc/base.h"

// -------------------------------------------------------------------------

interface IKFilterEventNotify;

class KDosWpsFileExport
{
protected:
	char* m_lpBuffer;
	int m_nBufLen;

public:
	KDosWpsFileExport() : m_lpBuffer(0), m_nBufLen(0)
	{
	}
	~KDosWpsFileExport()
	{
		if (m_lpBuffer)
		{
			delete m_lpBuffer;
			m_lpBuffer = 0;
		}
	}
	HRESULT Load(IN LPCTSTR szWpsFile, IN IKFilterEventNotify* pNotify)
	{
		CFile theFile;
		CFileException fe;
		if (!theFile.Open(szWpsFile, CFile::modeRead | CFile::shareDenyNone, &fe))
		{
			REPORT("���ļ�ʧ�ܣ�");
			return IO_E_NOTEXIST;
		}
		return Load(&theFile, pNotify);
	}
	HRESULT Load(IN CFile* pFile, IN IKFilterEventNotify* pNotify)
	{
		return GetText(pFile, pNotify);
	}
	HRESULT Export(IN LPCWSTR szDocFile)
	{
		ks_stdptr<IStorage> spWordRootStg;
		HRESULT hr = StgCreateDocfile(szDocFile, STGM_G_CREATE, 0, &spWordRootStg);
		ASSERT_OK(hr);

		return Export(spWordRootStg);
	}
	HRESULT Export(IN IStorage* pWordRootStg);

protected:
	HRESULT GetText(CFile* pFile, IKFilterEventNotify* pNotify);
};

// -------------------------------------------------------------------------
//	$Log: doswps.h,v $
//	Revision 1.1  2005/04/05 06:41:20  duanyuluo
//	*** empty log message ***
//	

#endif /* __DOSWPS_H__ */
