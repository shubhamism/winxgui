// CP_GBK.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "KXGlobalVI.h"
#include "KXCodePageVI.h"
#include "KSCodePageVI_GBK.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void InitWordTbl();
BOOL g_bWin9xOrWinNT = TRUE;

BOOL EnvironmentTesting()
{
	InitWordTbl();
	OSVERSIONINFO vi;
	vi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	g_bWin9xOrWinNT = ::GetVersion() >= 0x80000000;
	if (!GetVersionEx(&vi) || vi.dwPlatformId < VER_PLATFORM_WIN32_WINDOWS)
		return FALSE;

	return TRUE;
}

KXGlobalVI*	g_lpKXGlobalVirtualInterface;
KSCodePageVI_GBK CodePageVI;

///////////////////////////////////////////////////////////////////////////
// Function Name: KXCodePageVI* PASCAL EXPORT InitDll
// Function		: Initialize DLL
// Entry		: global virtual interface
// Return		: Codepage virtual interface
// Remark		: return -1 if init environment failed
//				  return -2 if init map failed
//				  return -3 if extra error
//				  return 1  if init succeed
///////////////////////////////////////////////////////////////////////////
STDAPI_(int) InitDll_CPGBK(
					 KXGlobalVI* pKXGlobalVI,
					 KXCodePageVI** ppCodePageVI, 
					 DWORD dwLanguageVersion)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	/*@@todo --> KXGlobalVI�ӿ��ƺ��Ѿ�û�����ˡ�
	ASSERT(pKXGlobalVI);
	if (!pKXGlobalVI)
		return -3; */

	if (g_lpKXGlobalVirtualInterface)
		return -3;

	if (!EnvironmentTesting())
		return -1;

	g_lpKXGlobalVirtualInterface = pKXGlobalVI;
	*ppCodePageVI = &CodePageVI;
	CodePageVI.SetLanguageVersion(dwLanguageVersion);

	// ����Ĭ����ʾ����
	g_lpKXGlobalVirtualInterface->m_Default_Outword = 0xF5A1;

	return 1;
}
