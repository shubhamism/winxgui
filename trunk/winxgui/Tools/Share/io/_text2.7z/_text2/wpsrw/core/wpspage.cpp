/* -------------------------------------------------------------------------
//	�ļ���		��	wpspage.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 19:16:17
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "wpspage.h"
#include <draw/frametext.h>
#include <draw/ptobj.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL CreateAlikeObjsForPage(
							CObList* pDestList,
							const CObList* pSrcList,
							CObArray* pNewObArray,
							CWpsDoc* pDoc)
{
	ASSERT(0);
	return TRUE;
}

// ���²���Ϊ�� class ���л�����
IMPLEMENT_WPSSERIAL(CWPSPage, CWPSObj, 0xDB)

CWPSPage::CWPSPage() //: m_pTempObjPacksAry(NULL)
{
	ChangeRuntimeClassName();
}

/*************************************************************************
���ܣ�	���캯��
��ڣ�	pDoc: �ĵ�ָ��
pRect: δ��
nPageIndex: ����ҳ��
wPageNumber: �߼�ҳ��
*************************************************************************/
CWPSPage::CWPSPage(CWpsDoc* pDoc, const CRect& pRect, int nPageIndex, WORD wPageNumber)
   : CWPSObj(pDoc, pRect)
{
	ASSERT_VALID(pDoc);
	ASSERT(wPageNumber >= 0);

	m_wPageNumber = wPageNumber;
	m_pDocument = pDoc;

	SetWPSObjType(WPSPage);
	ChangeRuntimeClassName();

	//ҳ��߿�Added by shq	23/6	2000
	m_bHasPageRect = FALSE;		//ȱʡ�ޱ�ҳ�ı߿�����
	
/*@@todo
	m_nPageIndex = nPageIndex;
	
	// ��ҳ���ϴ��������ı���
	//CRect rcCore(500, 500, 1000, 1000);
	CRect rcCore = pDoc->GetPaperCore(wPageNumber, FALSE);
	CFrameText* pFrameText = new CFrameText(pDoc,m_nPageIndex,rcCore,FALSE);
	ASSERT(pFrameText);
	c_pFrameText = pFrameText;
	
	// ��Doc�ڵ�TextPool��������ɵ�FrameText
	CTextPool* pTextPool = ((CWpsDoc*)pDoc)->GetAccessToTextPool();
	ASSERT_VALID(pTextPool);
	pFrameText->AttachTextPool(pTextPool);
	c_pFootnoteFrameText = NULL;
	bFNFramebeDel = FALSE;
	
	// ����ҳ���ı����ȱʡ����
	CRect rcMargine(0,0,0,0);
	pFrameText->SetLPenStyle(PS_NULL);			// �ޱ߿�
	pFrameText->SetBkMode(TRANSPARENT);		// OPAQUE
	//pFrameText->SetMarginInside (CRect(0,0,0,0));
	//pFrameText->SetMarginOutside(CRect(0,0,0,0));
	pFrameText->SetMarginInside (rcMargine);	// �ڱ߾�Ϊ0
	pFrameText->SetMarginOutside(rcMargine);	// ��߾�Ϊ0
	pFrameText->SetScriptSheetFlag(pDoc->IsScriptSheet());
	//pFrameText->RefreshSitePos();
	
	// �ڱ����ı���֮�佨������
	if (wPageNumber>0)
		pFrameText->MarkPrevFrameNode(FN_PREVPAGE, FN_MAINTEXTFRAME);
	pFrameText->MarkNextFrameNode(FN_NEXTPAGE, FN_MAINTEXTFRAME);
	
	//pTextPool->SetTextColumns(3);
	m_pTempObjPacksAry	= NULL;
	*/
}

//=======================================================
// ����	: CWPSPage::FilterCommentFrame
// ����	: �ǵ���ע����, ��Ҫ����ע����ҳ�����
// ���� : void 
// ��ע	:
//=======================================================
void CWPSPage::FilterCommentFrame()
{
	POSITION posTemp;
	POSITION pos = m_WPSObjectList.GetHeadPosition();
	while((posTemp = pos) != NULL)
	{		
		CWPSObj* pObj = (CWPSObj*)m_WPSObjectList.GetNext(pos);
		if (pObj->IsKindOf(RUNTIME_CLASS(CFrameText)))
		{
			CFrameText* pFrame = (CFrameText*)pObj;		ASSERT_VALID(pFrame);
			if (pFrame->IsCommentFrame())
				m_WPSObjectList.RemoveAt(posTemp);
		}
		if (pObj->IsKindOf(RUNTIME_CLASS(CLineObj)))
		{
			CLineObj* pLine = (CLineObj*)pObj;		ASSERT_VALID(pLine);
			if (pLine->m_bCM)
				m_WPSObjectList.RemoveAt(posTemp);
		}
	}
}

/**************************************************************************
	����:	ɾ����ҳ�ڵ�ȫ������
**************************************************************************/
// amend by wdb	2001-6-12 ��ע���ڱ༭��ѡ��״̬�ر��ļ�ʱ����,���note
void CWPSPage::DeleteObjects()
{
	ASSERT_VALID(this);
	FilterCommentFrame();
	CWPSObj* pDelObj = NULL;
	CPtrList DelList;
	while (!m_WPSObjectList.IsEmpty())
	{
		pDelObj = (CWPSObj*) m_WPSObjectList.RemoveHead();
		if (pDelObj && DelList.Find(pDelObj) == NULL)
		{
			DelList.AddTail(pDelObj);
		}
		else
		{
			ASSERT(FALSE);
		}
	}
	POSITION pos = DelList.GetHeadPosition();
	while (pos)
	{
		pDelObj = (CWPSObj*)DelList.GetNext(pos);
		if (pDelObj)
			delete pDelObj;
	}
}

/**************************************************************************
����:	ɾ����ҳ�ڵ�ȫ������
**************************************************************************/
void CWPSPage::DeleteContents()
{
	ASSERT_VALID(this);
	DeleteObjects();
/*@@todo
	ClearTempObjPacks(FALSE);							// ��һ������,�������ʲô������
	if (c_pFrameText)
	{
		ASSERT_VALID(c_pFrameText);
		c_pFrameText->DetachTextPool();
		delete c_pFrameText;
	}
	if (c_pFootnoteFrameText)
	{
		ASSERT_VALID(c_pFootnoteFrameText);
		c_pFootnoteFrameText->DetachTextPool();			// ��ǰ��Ҫ�� Pool �Ͼ�һ�й�ϵ
		delete c_pFootnoteFrameText;
	}
	if (m_pTempObjPacksAry)
	{
		m_pTempObjPacksAry->RemoveAll();				// ������Ƕ���ָ�����
		delete m_pTempObjPacksAry;
		m_pTempObjPacksAry	= NULL;
	}*/
}

// -------------------------------------------------------------------------

#define WPS_OBJCNT_MAX		(WPSRecordSizeMax / 4)

STDMETHODIMP CWPSPage::Serialize_Read_02(KSArchive& ar)
{
	HRESULT hr;
	KWPSMainReader wr;
	_KWPSRecordHeader hdr;
	ULONG* lp = NULL;
	UINT i, nObjCnt;
	
	wr.Attach(&ar);
	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSPageData, hr = E_UNEXPECTED);
	
	// 1) load page info
	WPSPageData rec;
	ZeroMemory(&rec, sizeof(rec));
	rec.fcPresPara = (ULONG)-1;
	wr.Read(&rec, sizeof(rec));
	
#if defined(WPP_ONLY)
	if (rec.fcPresPara != (ULONG)-1)
	{
		Object_Serialize_Read_02(ar, rec.fcPresPara, &m_bmPresPara);
	}
#endif //defined(WPP_ONLY)
	
	ASSERT(sizeof(WPSPageBrc) == sizeof(tagKPAGERECT));
	m_wPageNumber	= rec.iPageNumber;
	m_PageRect		= (tagKPAGERECT&)rec.brcPage;
	m_bHasPageRect	= rec.fHasPageBrc;
	m_rect			= rec.rcPage;
	
	nObjCnt = rec.nObjCnt;
	ASSERT(nObjCnt <= WPS_OBJCNT_MAX);
	if (nObjCnt == 0)
		goto lzNormalExit;
	
	// 2) load object list offset
	lp = new ULONG[nObjCnt];
	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSObjsData, hr = E_UNEXPECTED);
	nObjCnt = wr.Read(lp, sizeof(ULONG)*nObjCnt) / sizeof(ULONG);
	
	ASSERT(nObjCnt == rec.nObjCnt);
	
	// 3) save object list from pStream
	CObject* pObj;
	for (i = 0; i < nObjCnt; ++i)
	{
		WPSObj_Serialize_Read_02(ar, lp[i], &pObj);
		ASSERT(pObj);
		if (pObj)
			m_WPSObjectList.AddTail(pObj);
	}
	
lzNormalExit:
	if (lp)
		delete[] lp;
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());
	return S_OK;
	
KS_EXIT:
	return WPSIOThrowError(hr);
}

STDMETHODIMP CWPSPage::Serialize_Write_02(KSArchive& ar)
{
	//@@todo
	ASSERT(0);
	return S_OK;
}

void CWPSPage::Serialize_01(KSArchive& ar)
{
	ASSERT_VALID(this);

	if (!g_fCompoundFile)	// wps2002-io-page, old version serialize
	{
		char szPageID[] = FILEID_PAGE;
		if (ar.IsStoring())
		{
			ar.Write(&szPageID, sizeof(szPageID) - 1);	// minus 1: exclude NULL
			ar << m_wPageNumber;
			
			//ҳ��߿�Added by shq	23/6	2000
			ar.Write(&m_PageRect, sizeof(m_PageRect));
			ar << m_bHasPageRect;
		}
		else
		{
			ar.Read(&szPageID, sizeof(szPageID) - 1);	// minus 1: exclude NULL
			ar >> m_wPageNumber;
			
			//ҳ��߿�Added by shq	23/6	2000
			ar.Read(&m_PageRect, sizeof(m_PageRect));
			ar >> m_bHasPageRect;
		}
		CWPSObj::Serialize_01(ar);
	}

// 4-3'00 ������ ���� �ļ�����Ϊ WPS2000 �ļ�ʱ�������Ķ���תΪ�������ֶ���

#if defined _WPSGW
	if (g_bExport2Wps2000)
	{	// ���̲������������ļ���Ϊ WPS2000 �ļ�
		CObArray array;
		CObList* pOrgList, list;
		pOrgList = &m_WPSObjectList;
		list.AddTail(pOrgList);
		pOrgList->RemoveAll();
		BOOL b = CopyAlikeObjsForPage(pOrgList, &list, &array);
		pOrgList->Serialize(ar);
		if (b)
		{
			while (array.GetSize())		// ɾ���´����ĵ������ֶ���
			{
				delete array.GetAt(0);
				array.RemoveAt(0);
			}

			g_uExportflag |= LOSS_GWOBJ;
		}
		pOrgList->RemoveAll();
		pOrgList->AddTail(&list);
		list.RemoveAll();
	}
	else
#endif	// #if defined _WPSGW
	{
		// ����ҳ���ϵ���ע�����,�����Դ洢!!!	add by wdb
		POSITION posNew, posOld;
		CObList CMList;
		if (ar.IsStoring())
		{
			for (posNew = m_WPSObjectList.GetHeadPosition(); (posOld = posNew) != NULL;)
			{
				CWPSObj* pObj = (CWPSObj*)m_WPSObjectList.GetNext(posNew);
				ASSERT_VALID(pObj);
				if (pObj->IsKindOf(RUNTIME_CLASS(CFrameText)))
				{
					CFrameText* pFrame = (CFrameText*)pObj;
					if (pFrame->IsCommentFrame() && pFrame->GetFrameID() == 2)		//��ע��
					{
						m_WPSObjectList.RemoveAt(posOld);
						CMList.AddTail((CObject*)pFrame);
					}
				}
				if (pObj->IsKindOf(RUNTIME_CLASS(CLineObj)))
				{
					CLineObj* pLine = (CLineObj*)pObj;
					ASSERT_VALID(pLine);
					if (pLine->m_bCM)					//��ע��
					{
						m_WPSObjectList.RemoveAt(posOld);
					}
				}
			}
		}

		if (!g_fCompoundFile) // wps2002-io-page, old version serialize
			m_WPSObjectList.Serialize(ar);
		else	// wps2002-io-page, new version serialize
		{
			if (ar.IsStoring())
				Serialize_Write_02(ar);
			else
				Serialize_Read_02(ar);
		}

		// �ֵ�Ҫ�����ӽ�ȥ, ���ܲ���!
		for (POSITION pos = CMList.GetHeadPosition(); pos != NULL;)
		{
			CFrameText* pFrame = (CFrameText*)CMList.GetNext(pos);
			ASSERT_VALID(pFrame);
			ASSERT(pFrame->IsCommentFrame() && pFrame->GetFrameID() == 2);
			CLineObj* pLine = pFrame->GetLineObj();
			ASSERT_VALID(pLine);
			m_WPSObjectList.AddTail(pLine);	
			m_WPSObjectList.AddTail(pFrame);		
		}		
	}

	/*@@todo - ���ӵ�
	//	�ؽ�ҳ������ƴ�ӹ�ϵ
	void ResumeObjConnect(const CObList*, DWORD&);
	if (!ar.IsStoring() && m_pDocument)
	{
		DWORD dwCnt = m_pDocument->GetObjIDCount();
		ResumeObjConnect(&m_WPSObjectList, dwCnt);
		m_pDocument->SetObjIDCount(dwCnt);
	}*/

	DoValidate();
}

void CWPSPage::Serialize_98(KSArchive& ar)
{
	ASSERT_VALID(this);

	char szPageID[] = FILEID_PAGE;

	if (ar.IsStoring())
	{
		ar.Write(&szPageID, sizeof(szPageID) - 1);	// minus 1: exclude NULL
		ar << m_wPageNumber;
	}
	else
	{
		ar.Read(&szPageID, sizeof(szPageID) - 1);	// minus 1: exclude NULL
		ar >> m_wPageNumber;
	}
	CWPSObj::Serialize_98(ar);

// 4-3'00 ������ ���� �ļ�����Ϊ WPS2000 �ļ�ʱ�������Ķ���תΪ�������ֶ���

#if defined _WPSGW
	if (g_bExport2Wps2000)
	{	// ���̲������������ļ���Ϊ WPS2000 �ļ�
		CObArray array;
		CObList* pOrgList, list;
		pOrgList = &m_WPSObjectList;
		list.AddTail(pOrgList);
		pOrgList->RemoveAll();
		BOOL b = CopyAlikeObjsForPage(pOrgList, &list, &array);
		pOrgList->Serialize(ar);
		if (b)
		{
			while (array.GetSize())		// ɾ���´����ĵ������ֶ���
			{
				delete array.GetAt(0);
				array.RemoveAt(0);
			}

			g_uExportflag |= LOSS_GWOBJ;
		}
		pOrgList->RemoveAll();
		pOrgList->AddTail(&list);
		list.RemoveAll();
	}
	else
#else
	if (g_bExport2Wps2000)
	{	// ���̲������������ļ���Ϊ WPS2000 �ļ�
		CObArray array;
		CObList* pOrgList, list;
		pOrgList = &m_WPSObjectList;
		list.AddTail(pOrgList);
		pOrgList->RemoveAll();
		BOOL b = CreateAlikeObjsForPage(pOrgList, &list, &array, m_pDocument);
		pOrgList->Serialize(ar);
		if (b)
		{
			while (array.GetSize())		// ɾ���´����ĵ������ֶ���
			{
				delete array.GetAt(0);
				array.RemoveAt(0);
			}
		}
		pOrgList->RemoveAll();
		pOrgList->AddTail(&list);
		list.RemoveAll();
	}
	else
#endif	// #if defined _WPSGW && !defined _WPSREADER
	{
		m_WPSObjectList.Serialize(ar);
	}
	
	//���´������ڹ��İ�---------------------
	{
		for(POSITION pos = m_WPSObjectList.GetHeadPosition(); pos != NULL; )
		{
			CObject *pObj;
			POSITION oldPos = pos;
			pObj = m_WPSObjectList.GetNext( pos );
			pObj = ConvertGWToRotateText(pObj);

			if(pObj) 
				m_WPSObjectList.SetAt(oldPos, pObj);
		}
	}
	//---------------------------------------
	
	/*@@todo - ���ӵ�
	//	�ؽ�ҳ������ƴ�ӹ�ϵ
	void ResumeObjConnect(const CObList*, DWORD&);
	if (!ar.IsStoring() && m_pDocument)
	{
		DWORD dwCnt = m_pDocument->GetObjIDCount();
		ResumeObjConnect(&m_WPSObjectList, dwCnt);
		m_pDocument->SetObjIDCount(dwCnt);
	}*/

	DoValidate();
}

void CWPSPage::Serialize_97(KSArchive& ar)
{
	ASSERT_VALID(this);

	char szPageID[] = FILEID_PAGE;

	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		ar.Read(&szPageID, sizeof(szPageID) - 1);	// minus 1: exclude NULL
		ar >> m_wPageNumber;
	}
	CWPSObj::Serialize_97(ar);
	m_WPSObjectList.Serialize(ar);
	if (!ar.IsStoring())
	{
		DiaToRectPoly(m_WPSObjectList, m_pDocument); // ������תΪ�������
	}

#if defined(WPP_ONLY) // wps2002-io-wpswpp, by tsingbo
	m_bmPresPara.InitClass();
#endif

	DoValidate();
}

// -------------------------------------------------------------------------
