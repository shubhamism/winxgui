//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainMailButton.h
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-6-6 14:16:32
//	FileDescription	:	Domain Mail Button 
//
//////////////////////////////////////////////////////////////////////////////////////

// KSDomainMailButton.h: interface for the KSDomainMailButton class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __KSDMOMAINMAILBUTTON_H
#define __KSDMOMAINMAILBUTTON_H

#include "Ptobj.h"

class KSDomainMailButton : public CLtxtObj  
{
	
protected:
	DECLARE_SERIAL(KSDomainMailButton);
	KSDomainMailButton();
	
public:
//	KSDomainMailButton(const CWpsDoc* pDoc, const CRect& position, int nShape);
	virtual ~KSDomainMailButton();
	
	KSDomainMailButton( const KSDomainMailButton* obj );
	
public:
	CString m_sSendCc, m_sSendTo, m_sSubject;
    BOOL m_bSelect;
	
	//private:
	//	BOOL m_bEnableField;		// û�б��棬������ֻ����ReadOnly ״̬�´β���Ч
	
public:
	virtual void Serialize_01(KSArchive& ar);
};

#endif // !defined(AFX_KSDOMAINMAILBUTTON_H__428604A2_3AC3_11D4_A00C_5254AB1993A3__INCLUDED_)
