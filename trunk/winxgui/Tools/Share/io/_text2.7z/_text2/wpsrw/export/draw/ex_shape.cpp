   /* -------------------------------------------------------------------------
//	�ļ���		��	ex_shape.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 21:25:53
//	��������	��	
//
//	$Id: ex_shape.cpp,v 1.81 2005/10/08 08:39:58 liupeng Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
//#include <core/anchorobj.h>
#include <draw/wpsobj.h>
#include <export/chart/ex_chart.h>

#ifdef WPP_ONLY
#include <export/pres/ex_wppframetbl.h>
#else
#include <export/table/ex_frametbl.h>
#endif

#include <export/formula/ex_formula.h>
#include "ex_ptobj.h"
#include "ex_frametext.h"
#include "ex_frameimg.h"
#include "ex_frameole.h"
#include "ex_wpsgroup.h"
#include "ex_objtext.h"
#include "ex_frameole.h"
#include "ex_framept.h"
#ifdef WPP_ONLY
#include <export/pres/ex_wppframe.h>
#endif

#include "wpsrw/wpsobjtool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
void swap_long(LONG& a, LONG& b)
{
	LONG nMid = a;
	a = b;
	b = nMid;
}
// -------------------------------------------------------------------------
#define EX_BEGIN_SHAPE_DISP(nObjType)										\
	switch (nObjType)														\
	{
	
#define EX_ADD_SHAPE(type)													\
	case type:																\
		ShapeExportBaseTypeCast(type, pObj)->ConvertShape(*this);			\
		ShapeExportTypeCast(type, pObj)->ConvertShape(*this);				\
		break;

#define EX_END_SHAPE_DISP()													\
	default:																\
		REPORT_ONCE("Unknown shape!!!\n");									\
	}

void CalcAngleEff(CPTObj* pPtObj, RECT& rc, CShape_Context& shapeCtx)
{
	if (pPtObj == NULL)
		return;	
	RECT rct;
	
	if (pPtObj->CheckObjType() == LTXTObj)
	{
		CLtxtObj_Export* pExpClass = reinterpret_cast<CLtxtObj_Export*>(pPtObj);
		ASSERT(pExpClass);
		CRect rcTmp = pPtObj->GetMrect();
		pExpClass->GetShapeRect(shapeCtx, rcTmp);
		rc = rcTmp;
		return;
	}

//	rct = pPtObj->GetMrect();
	rct = GetShapeNonRotateRect(pPtObj);

	int nObjType = ((CWPSObj *)pPtObj)->CheckObjType();
	if(nObjType == FRAMETable)
	{
		rct.right += _TABLEINBOXADD;
		rct.bottom += _TABLEINBOXADD;
	}
	
	LONG nWidth = rct.right - rct.left, 
		nHeight = rct.bottom - rct.top;
	POINT ptCenter;
	ptCenter.x = nWidth / 2 + rct.left;
	ptCenter.y = nHeight / 2 + rct.top;
	LONG nAngle = 0;
	switch (nObjType)
	{
		case LTXTObj:
		case LTXTSizeComment:
		case MultitextRect:
		case LINEObj:
		case RECTObj:
		case RECTRound:
		case RECTEllipse:
		case RECTDiamond:
		case RECTCube:
		case RECTCylinder:
		case RECTPieColumn:
		case POLYObj:
		case CURVEObj:
		{
			nAngle = pPtObj->GetObjTheta() / 10;
			break;
		}
	}
	if (nAngle < 0)
		nAngle = 360 + nAngle;
	if ((nAngle != 90 || nAngle != 270) && (nAngle > 45 && nAngle < 135) ||
		(nAngle > 225 && nAngle < 315))
	{
		rc.left = ptCenter.x - nHeight / 2;
		rc.right = ptCenter.x + nHeight / 2;
		rc.top = ptCenter.y - nWidth / 2;
		rc.bottom = ptCenter.y + nWidth / 2;
	}
	else
	{
		rc.left = ptCenter.x - nWidth / 2;
		rc.right = ptCenter.x + nWidth / 2;
		rc.top = ptCenter.y - nHeight / 2;
		rc.bottom = ptCenter.y + nHeight / 2;
	}
	return;
}

void CalcOutRect (CWPSGroup *pGroupShap, RECT& rc, CShape_Context& shapeCtx)
{
	if (pGroupShap == NULL) 
		return;
	CWPSObj *pWpsObj;
	rc.left = 65535; 
	rc.top = 65535;
	rc.right = 0;
	rc.bottom = 0;
	CRect rct(0, 0, 0, 0); 
	for (POSITION pos = pGroupShap->GetGrpList()->GetHeadPosition(); pos; )		
	{	
		pWpsObj = (CWPSObj *)pGroupShap->GetGrpList()->GetNext(pos);
		if (pWpsObj != NULL && pWpsObj->IsKindOf(RUNTIME_CLASS(CPTObj)))
		{
			CPTObj* pPtObj = (CPTObj *)pWpsObj;		
			CalcAngleEff(pPtObj, rct, shapeCtx); // 
		}
		else
			rct = pWpsObj->GetMrect();
		rc.left = MIN(rc.left, rct.left);
		rc.right = MAX(rc.right, rct.right);
		rc.top = MIN(rc.top, rct.top); 
		rc.bottom = MAX(rc.bottom, rct.bottom);
	}
	return;
}
/*
Tank, 20041029
EX_ADD_SHAPE�Ĳ����֮��:������˵,CFrameObj�е�m_pImgΪͼƬ,��CFrameImage��
����ͼƬ���е�ͼƬ,�������ͼƬ���,��m_pImg��ת����CFrameObj_Export������,����
��Ҫ����CFrameObj_Export��ôת��,����CShape_Context����m_dwFlag��־.
��������EX_ADD_SHAPE2:

STDMETHODIMP_(void) CShape_Context::ConvertShape(CWPSObj* pObj)
{
	EX_BEGIN_SHAPE_DISP()
		...
		EX_ADD_SHAPE2(FRAMEImg)
		...
	EX_END_SHAPE_DISP()
	...
}

EX_SHAPE_API CFrameImage_Export::ConvertShape(CShape_Context& context)
{
	context.m_dwFlag |= WPSRW_FRAMEIMAGE;
	((CFrameObj_Export*)this)->ConvertShape(context);
	...
}


��:������
�����ε���,�������úܼ�:(��Ȼ��ȫ�ֺ������ڼ���)
void gConvertCTFPBase(CShape_Context& context, CTFPBase* pObj)
{
	if(context.m_dwFlag == ZZZ)
	{
		//��ôת��
	}
	else
	{
		//��ôת��
	}
}
void gConvertCFPBase(CShape_Context& context, CTFPBase* pObj)
{
	if(context.m_dwFlag == XXX)
		context.m_dwFlag = YYY;
	gConvertCTFPBase(context, pObj);
	//���Լ���ת��
}
...
...
...
void gConvertCFrameImage(CShape_Context& context, CFrameImage* pObj)
{
	context.m_dwFlag = WWW;
	gConvertCFameObj(context, pObj);
	//���Լ���ת��
}

STDMETHODIMP_(void) CShape_Context::ConvertShape(CWPSObj* pObj)
{
	switch (pObj->CheckObjType())
	{
	case FRAMEImg:
		gConvertCFrameImage(*this, (CFrameImage*)pObj);
		break;
	case LINEObj:
		gConvertCLineObj(*this, (CLineObj*)pObj);
		break;
		...
		...
	}
}
Ҳ�������úܸ���,����ģ���ػ�.......
������,�ҵĹ۵�
*/
#define EX_ADD_SHAPE2(type)													\
	case type:																\
		ShapeExportTypeCast(type, pObj)->ConvertShape(*this);				\
		break;

// -------------------------------------------------------------------------
//
// ��ʽ���ֵ�nObjType = WPSObj����Ҫ������취������ʹ��RuntimeClass
//
// note (by xushiwei):
//	1��������ϲ���ú꣬���Ƕ���Ӧ��һЩ����Ԥ��ı仯��˵������Ȼ�ǲ�������ġ�
//	2������ķ���(RCEX_ADD_SHAPE)�Ҳ�������̫����(���EX_ADD_SHAPE)����Ϊ�ϡ�
//	   ��Ϊ�����������Ϊ����������Ϊ��Щ�������Ϊ����

#define RCEX_BEGIN_SHAPE_DISP()												\
	CRuntimeClass* __pRC = pObj->GetRuntimeClass();							\
	if (0);

#define RCEX_ADD_SHAPE(TheClass)											\
	else if (__pRC == RUNTIME_CLASS(TheClass))								\
	{																		\
		((TheClass##_Export*)pObj)->ConvertShape(*this);					\
	}

#define RCEX_END_SHAPE_DISP()												\
	else																	\
	{																		\
		REPORT_ONCE("Unknown shape!!!\n");									\
	}

// -------------------------------------------------------------------------

STDMETHODIMP_(void) CShape_Context::ConvertShape(CWPSObj* pObj)
{
	int nObjType = pObj->CheckObjType();
	
	if (nObjType == WPSObj)
	{
		RCEX_BEGIN_SHAPE_DISP()
			RCEX_ADD_SHAPE(CFormObj)		// һ�鹫ʽ����
			RCEX_ADD_SHAPE(CFormula)		// ��ʽ����
			RCEX_ADD_SHAPE(CFormulae)		// ��ʽ����s
			RCEX_ADD_SHAPE(CFormFrac)		// ��ʽ����
			RCEX_ADD_SHAPE(CFormDivide)		// б��ʽ����
			RCEX_ADD_SHAPE(CFormRemain)		// �³�ʽ����
			RCEX_ADD_SHAPE(CFormRadical)	// ��ʽ����
			RCEX_ADD_SHAPE(CFormTBscript)	// ���±����
			RCEX_ADD_SHAPE(CFormMatr)		// �������
			RCEX_ADD_SHAPE(CFormTB)			// ��͡�������
			RCEX_ADD_SHAPE(CFormLabel)		// ���±�Ƕ���
			RCEX_ADD_SHAPE(CFormLabArrow)	// ��ע��ͷ����
			RCEX_ADD_SHAPE(CFormPower)		// ��ָ����
			RCEX_ADD_SHAPE(CFormIntegral)		// ����
			RCEX_ADD_SHAPE(CFormTMB)		// ����
			RCEX_ADD_SHAPE(CFormTM)		// ����
			RCEX_ADD_SHAPE(CFormMB)		// ����
			RCEX_ADD_SHAPE(CFormFuntion)		// ����
			RCEX_ADD_SHAPE(CChemLink)		// ����
			RCEX_ADD_SHAPE(CChemRing)		// ����
			RCEX_ADD_SHAPE(CChemLogogram)		// ����
			RCEX_ADD_SHAPE(CChemResponse)		// ����
			RCEX_ADD_SHAPE(CChemBond)		// ����
			RCEX_ADD_SHAPE(CChemRespSym)		// ����
			RCEX_ADD_SHAPE(CFormSymbol)		// ����
			RCEX_ADD_SHAPE(CFormEquation)		// ����
			RCEX_ADD_SHAPE(CAtomConstruMap)		// ����
/*
			RCEX_ADD_SHAPE(CForm)		// ����
*/
		RCEX_END_SHAPE_DISP()
		return;
	}

	EX_BEGIN_SHAPE_DISP(nObjType)
		EX_ADD_SHAPE(LINEObj)
		EX_ADD_SHAPE(LINECycle)
		EX_ADD_SHAPE(FRAMEText)
		EX_ADD_SHAPE(FRAMEPT)
		EX_ADD_SHAPE2(FRAMEImg)
		EX_ADD_SHAPE(RECTObj)
		EX_ADD_SHAPE(RECTRound)
		EX_ADD_SHAPE(RECTEllipse)
		EX_ADD_SHAPE(RECTDiamond)
		EX_ADD_SHAPE(RECTCube)
		EX_ADD_SHAPE(RECTCylinder)
		EX_ADD_SHAPE(RECTPieColumn)
		EX_ADD_SHAPE(POLYObj)
		EX_ADD_SHAPE(CURVEObj)
		EX_ADD_SHAPE(LTXTObj)
		EX_ADD_SHAPE(LTXTSizeComment)
		EX_ADD_SHAPE(WPSGroup)
		EX_ADD_SHAPE(RECTPoly)
		EX_ADD_SHAPE(FRAMEOLE)
		EX_ADD_SHAPE(MultitextRect)
		EX_ADD_SHAPE(FRAMEChart)
		EX_ADD_SHAPE2(FRAMETable)
		EX_ADD_SHAPE2(FRMTableBody)
		EX_ADD_SHAPE(BarCodeObj)
#ifdef WPP_ONLY
		EX_ADD_SHAPE(WPPFRAME)
#endif
	EX_END_SHAPE_DISP()
}

// -------------------------------------------------------------------------

STDMETHODIMP_(void) CShape_Context::GetAnchorInfo(
		CWPSObj* pWpsObj,
		RECT rc,
		OUT KDWShapeAnchor& anchor)
{
	FSPA_TEXTWRAP wrapMode =  mso_spaWrNone;
	FSPA_TEXTWRAPTYPE wrapType = mso_spaWrtBoth;
	if(pWpsObj->IsKindOf(RUNTIME_CLASS(CFrameObj)) ||
		pWpsObj->IsKindOf(RUNTIME_CLASS(CWPSGroup)))
	{
		CWPSObj::WrapMode wrapModeWps;
		if(pWpsObj->IsKindOf(RUNTIME_CLASS(CFrameObj)))
		{
			wrapModeWps = ((CFrameObj*)pWpsObj)->m_wrapMode;
		}
		else
		{
			wrapModeWps = ((CWPSGroup*)pWpsObj)->GetWrapModeEx();
		}
		switch(wrapModeWps)
		{
		case CWPSObj::wm_around:
			wrapMode = mso_wrapSquare;//������
			wrapType = mso_spaWrtBoth;//����
			break;
		case CWPSObj::wm_onlargerside:
			wrapMode = mso_wrapSquare;//������
			wrapType = mso_spaWrtLarget;//���һ��
			break;
		case CWPSObj::wm_left:
			wrapMode = mso_wrapSquare;//������
			wrapType = mso_spaWrtLeft;//���
			break;
		case CWPSObj::wm_right:
			wrapMode = mso_wrapSquare;//������
			wrapType = mso_spaWrtRight;//�Ҳ�
			break;
		case CWPSObj::wm_notonside:
			wrapMode = mso_wrapTopBottom;//������
			break;
		default:
			break;
		}
	}
	memset(&anchor, 0 , sizeof(anchor));
	anchor.xaLeft = WpsShapeToTwip(rc.left);
	anchor.yaTop = WpsShapeToTwip(rc.top);
	anchor.xaRight = WpsShapeToTwip(rc.right);
	anchor.yaBottom = WpsShapeToTwip(rc.bottom);
	anchor.xRel = mso_spaXRelTopOfPage;
	anchor.yRel = mso_spaYRelTopOfPage;
	anchor.wrapMode = wrapMode;
	anchor.wrapType = wrapType;
	anchor.fAnchorLock = FALSE;
	//��������
	//
	int nDispStyle = CWPSObj::DS_ONTEXT;
	if(pWpsObj->IsKindOf(RUNTIME_CLASS(CFPBase)))
	{
		nDispStyle = ((CFPBase*)pWpsObj)->m_nDispStyle;
	}
	else if(pWpsObj->IsKindOf(RUNTIME_CLASS(CWPSGroup)))
	{
		nDispStyle = ((CWPSGroup*)pWpsObj)->GetObjDispStyleEx();
	}

	if (nDispStyle == CWPSObj::DS_UNDERTEXT)
	{
		anchor.wrapMode = mso_wrapNone;
		m_opt.AddPropBool(msopt_fBehindDocument, 1);
	}


	m_optUDef.AddPropFix(msopt_spXRelTo, mso_spaXRelTopOfPage);
	m_optUDef.AddPropFix(msopt_spYRelTo, mso_spaYRelTopOfPage);

}

STDMETHODIMP_(void) CShape_Context::Export(CAnchorObj* pObj)
{
	CWPSObj* pWpsObj;
	if(IsInlineShape())
	{
		pWpsObj = pObj->GetWPSObj();
		m_optUDef.AddPropBool(msopt_fInlineShape, TRUE);
	}
	else
	{
		ASSERT(FALSE);
	}
	Export(pWpsObj);
}

STDMETHODIMP_(void) CShape_Context::Export(CWPSObj* pObj)
{
	CWPSObj* pWpsObj;

	pWpsObj = (CWPSObj*)pObj;


	if(!IsInlineShape())
	{
		if(((int)m_nPageLocation) > 0)
		{
			m_optUDef.AddPropFix(ksextopt_spPageLocation, m_nPageLocation);
		}
	}

	ASSERT_VALID(pWpsObj);
	//
	CRect rc = pWpsObj->GetMrect();
	int nObjType = pWpsObj->CheckObjType();
	switch (nObjType)
	{
	case LTXTObj:
	case LTXTSizeComment:
		{
			CLtxtObj_Export* pExpClass = reinterpret_cast<CLtxtObj_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc);
		}
		break;
	case MultitextRect:
		{
			CRotateText_Export* pExpClass = reinterpret_cast<CRotateText_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc);
		}
		break;
	case FRAMEOLE:
		{
			//wps��ole��KDWOleShape��ʾ,��KDWShape CShape_Context::m_shape��һ��,ֻ���Լ���ת��,����
			//���һ����϶�������ole����,��������
			//wppû�������,��Ϊ����KDWShape
#ifndef WPP_ONLY
			// liupeng: �������: ole��������ͼƬ��ʾ������
			// wps��ole����������ͱ�ת��ΪͼƬ��, sptPictureFrame, ����
			// �ڵ�ͼƬ����ʱ, ͼƬӦ����ΪͼƬ������ͼƬ, ��������Ϊ����
			// ͼƬ
			m_dwFlag |= WPSRW_FRAMEIMAGE;
			ConvertShape(pWpsObj);//ole�����Լ���ת��
			return;
#endif
		}
		break;
	case LINEObj:
	//case LINECycle:
		{
			CLineObj_Export* pExpClass = reinterpret_cast<CLineObj_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc);

			// liupeng: �������ζ�����2003��û�бպϣ����ԾͲ������������
			if(pExpClass->m_nlineobjShape == CLineObj::linkLine || 
				pExpClass->m_nlineobjShape == CLineObj::linkBezier)
			{
				m_opt.ForceAddPropBool(msopt_fFilled, FALSE);
				m_dwFlag |= WPSRW_NOCONVERTFILL;
			}
		}
		break;
	case RECTObj:
	case RECTRound:
	case RECTEllipse:
	case RECTDiamond:
	case RECTCube:
	case RECTCylinder:
	case RECTPieColumn:
		{

			CRectObj_Export* pExpClass = reinterpret_cast<CRectObj_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc);	
		}
		break;
	case POLYObj:
		{
			CPolyObj_Export* pExpClass = reinterpret_cast<CPolyObj_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc, TRUE);
		}
		break;
	case CURVEObj:
		{
			CCurveObj_Export* pExpClass = reinterpret_cast<CCurveObj_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc);
		}
		break;
	case RECTPoly:
		{
			CRectPoly_Export *pExpClass = reinterpret_cast<CRectPoly_Export*>(pWpsObj);
			ASSERT(pExpClass);
			pExpClass->GetShapeRect(*this, rc);			
		}
		break;
	case BarCodeObj:
		{
			// �����������ʱ���������ת�Ƕȣ�����Ҫ�Ե�
			CBarCodeObj* pBarObj = reinterpret_cast<CBarCodeObj*>(pWpsObj);
			int theta = pBarObj->GetObjTheta();
			// ��ת�ǶȲ���ˮƽʱ���߶Ե�
			if (theta != 0 && theta != 1800)
			{
				int centerx = (rc.left + rc.right) / 2;
				int centery = (rc.top + rc.bottom ) / 2;
				CRect newrc;
				newrc.left = centerx - (centery - rc.top);
				newrc.right = centerx + (rc.bottom - centery);
				newrc.top = centery - (centerx - rc.left);
				newrc.bottom = centery + (rc.right - centerx);
				rc = newrc;
			}
		}
		break;
	}
	
	if(IsInlineShape())
	{
		if(nObjType != FRAMETable)//������shape
		{
			m_shape = m_export.AddInlineShape(
				WpsShapeToTwip(rc.Width()),
				WpsShapeToTwip(rc.Height()),
				IsGroupType(nObjType));
		}
	}
	else
	{
		//�������϶���Ļ�Ҫ�������϶�����ÿһ������δ��ת֮ǰ����Ͽ�
		if (WPSGroup == nObjType)//ͼ�ο�֧����ת�����ؿ���
		{
			CRect temp;
			CWPSGroup *pGroupShap = (CWPSGroup *)pObj;			
			CalcOutRect(pGroupShap, temp, *this);
			rc = temp;
		}
		//���Ƿ����ı��������һ���ı���,������v6�¿��Զ�λ�������ҳ��
#ifndef	 WPP_ONLY
		if(nObjType == FRAMETable)
		{
			rc.right += _TABLEINBOXADD;//�ı���ӿ�һ��
			rc.bottom += _TABLEINBOXADD;//�ı���Ӹ�һ��
		}		
#endif
		if (nObjType == LTXTObj || nObjType == MultitextRect)
		{
			rc.right += 5;	//�������ֺͶ������ּӿ�һ��
			rc.bottom += 5; //�������ֺͶ������ּӸ�һ��
		}
#ifndef WPP_ONLY
		KDWShapeAnchor anchor;
		GetAnchorInfo(pWpsObj, rc, anchor);
		m_shape = m_export.AddShape(anchor, IsGroupType(nObjType));
#else
		// ������ppt�д�Ϊ��϶���
		if(nObjType == FRAMETable)
			m_shape = m_wppSlideCtx->AddShape(rc, TRUE);
		else
			m_shape = m_wppSlideCtx->AddShape(rc, IsGroupType(nObjType));
#endif
	}

	ConvertShape(pWpsObj);

#ifndef WPP_ONLY
	if(nObjType == FRAMETable && IsInlineShape())
	{
		return;
	}
#endif

	m_shape.SetProperties(m_opt);
	m_shape.SetUDefProperties(m_optUDef);
}

// -------------------------------------------------------------------------
// $Log: ex_shape.cpp,v $
// Revision 1.81  2005/10/08 08:39:58  liupeng
// *** empty log message ***
//
// Revision 1.80  2005/09/23 07:32:15  liupeng
// *** empty log message ***
//
// Revision 1.79  2005/07/27 10:48:21  liupeng
// *** empty log message ***
//
// Revision 1.78  2005/06/29 02:55:59  liupeng
// *** empty log message ***
//
// Revision 1.77  2005/06/23 02:49:02  liupeng
// *** empty log message ***
//
// Revision 1.76  2005/04/22 09:38:46  liupeng
// *** empty log message ***
//
// Revision 1.75  2005/04/22 09:34:07  tanke
// *** empty log message ***
//
// Revision 1.74  2005/03/31 10:34:31  liupeng
// *** empty log message ***
//
// Revision 1.73  2005/03/30 04:07:18  tanke
// *** empty log message ***
//
// Revision 1.72  2005/03/11 09:27:21  duanyuluo
// *** empty log message ***
//
// Revision 1.71  2005/02/23 10:06:13  duanyuluo
// *** empty log message ***
//
// Revision 1.70  2005/01/26 07:20:16  lijun
// *** empty log message ***
//
// Revision 1.69  2005/01/24 01:34:08  lijun
// *** empty log message ***
//
// Revision 1.68  2005/01/24 01:33:04  lijun
// *** empty log message ***
//
// Revision 1.67  2005/01/23 12:50:31  lijun
// *** empty log message ***
//
// Revision 1.66  2005/01/22 14:03:44  lijun
// *** empty log message ***
//
// Revision 1.65  2005/01/21 08:18:15  tanke
// *** empty log message ***
//
// Revision 1.64  2005/01/21 02:55:33  tanke
// *** empty log message ***
//
// Revision 1.63  2005/01/20 09:51:12  lijun
// *** empty log message ***
//
// Revision 1.62  2005/01/20 09:50:20  lijun
// *** empty log message ***
//
// Revision 1.61  2005/01/18 06:24:47  wangdong
// *** empty log message ***
//
// Revision 1.60  2005/01/17 12:08:33  lijun
// *** empty log message ***
//
// Revision 1.59  2005/01/17 12:06:36  wangdong
// *** empty log message ***
//
// Revision 1.58  2005/01/15 09:35:44  duanyuluo
// *** empty log message ***
//
// Revision 1.57  2005/01/15 08:44:33  wangdong
// *** empty log message ***
//
// Revision 1.56  2005/01/14 07:44:43  wangdong
// *** empty log message ***
//
// Revision 1.55  2005/01/14 03:30:22  wanli
// *** empty log message ***
//
// Revision 1.54  2005/01/13 07:21:03  wangdong
// *** empty log message ***
//
// Revision 1.53  2005/01/13 02:46:57  lijun
// *** empty log message ***
//
// Revision 1.52  2005/01/12 08:00:34  yangchao
// *** empty log message ***
//
// Revision 1.51  2005/01/11 12:32:50  wangdong
// *** empty log message ***
//
// Revision 1.50  2005/01/11 09:40:55  lijun
// *** empty log message ***
//
// Revision 1.49  2005/01/11 09:38:31  lijun
// *** empty log message ***
//
// Revision 1.48  2005/01/11 08:51:40  lijun
// *** empty log message ***
//
// Revision 1.47  2005/01/11 06:44:37  lijun
// *** empty log message ***
//
// Revision 1.46  2005/01/11 06:30:32  lijun
// *** empty log message ***
//
// Revision 1.45  2005/01/10 09:21:20  yangchao
// *** empty log message ***
//
// Revision 1.44  2005/01/08 13:58:58  dengzhihui
// *** empty log message ***
//
// Revision 1.43  2005/01/08 11:07:26  lijun
// *** empty log message ***
//
// Revision 1.42  2005/01/08 09:55:36  wangdong
// *** empty log message ***
//
// Revision 1.41  2005/01/08 06:56:32  dengzhihui
// �޸�ֱ�ߵĽǶ����⣬�о�û���޸ĵúܳ��ף���Ҫ��һ��������Ԫ��ͨһ�¡�
//
// Revision 1.40  2005/01/08 06:27:15  shenjiazheng
// *** empty log message ***
//
// Revision 1.39  2005/01/08 01:47:23  shenjiazheng
// *** empty log message ***
//
// Revision 1.38  2005/01/07 09:57:44  wangdong
// *** empty log message ***
//
// Revision 1.37  2005/01/07 07:40:49  wangdong
// *** empty log message ***
//
// Revision 1.36  2005/01/07 04:38:43  lijun
// *** empty log message ***
//
// Revision 1.35  2005/01/07 04:33:12  lijun
// *** empty log message ***
//
// Revision 1.34  2005/01/06 09:53:37  lijun
// *** empty log message ***
//
// Revision 1.33  2005/01/06 08:37:21  wangdong
// *** empty log message ***
//
// Revision 1.32  2005/01/06 02:49:58  lijun
// *** empty log message ***
//
// Revision 1.31  2005/01/04 12:47:24  wanli
// *** empty log message ***
//
// Revision 1.30  2004/12/31 02:50:27  xushiwei
// formula�������̳���������
//
// Revision 1.29  2004/12/29 01:27:47  lijun
// *** empty log message ***
//
// Revision 1.28  2004/12/27 08:36:08  wangdong
// *** empty log message ***
//
// Revision 1.27  2004/12/23 09:20:06  wangdong
// *** empty log message ***
//
// Revision 1.26  2004/12/17 08:58:34  xushiwei
// Ϊ֧�־ɰ汾wps��ҳ���������msopt_spPageLocation��չ����(optUDef)��
// �м������anchor����: text_anchor_page_location��
//
// Revision 1.25  2004/12/17 08:07:25  xushiwei
// ������ksextension�Ķ�������ǰ׺msopt_��Ϊksextopt_��
//
// Revision 1.24  2004/12/17 07:51:02  xushiwei
// ����ҳ��������չ����: msopt_spPageLocation��
//
