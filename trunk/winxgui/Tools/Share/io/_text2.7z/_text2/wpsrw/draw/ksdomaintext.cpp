//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainText.cpp
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-6-5 11:03:40
//	FileDescription	:	Domain Text 
//
//////////////////////////////////////////////////////////////////////////////////////
// KSDomainText.cpp: implementation of the KSDomainText class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifndef __WPSOBJ_H
	#include "Wpsobj.h"
#endif

#ifndef __FRAMEOBJ_H
	#include "frameobj.h"
#endif

#ifndef __PTOBJ_H
	#include "Ptobj.h"
#endif

#ifndef __OBJTEXT_H
	#include "ObjText.h"
#endif

#include "KSDomainText.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL(KSDomainText,CLtxtObj,98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(KSDomainText,CLtxtObj,0xA0 | VERSIONABLE_SCHEMA)

KSDomainText::KSDomainText()
{
	m_nMaxLen = 256;
}

KSDomainText::~KSDomainText()
{

}

KSDomainText::KSDomainText(const CWpsDoc* pDoc, 
						   const CRect& position, 
						   int nShape/*=rectangle*/)
			:CLtxtObj(pDoc,position,rectangle)     
{
	m_sTitle = _T("");
	m_bBackGround = FALSE;
	m_uLPenStyle = PS_NULL;
//	KCOLORINDEX indexColor;
//	KColorModel::RGBToColor(indexColor, 192,192, 192);
//
//	SetBkMode(OPAQUE);					// �����:���
//	SetBkColor(indexColor);		// ��ɫ
////	SetFillLogBrush(BS_HATCHED, RGB(192, 192, 192), NULL);
//	SetFillLogBrush(0, indexColor, 0);
	m_nMaxLen = 256;
}


/*
void CLtxtObj::AppentMaxLenToString(int nMaxLen)
{
	BOOL bIsProtect = IsProtectDomain();
	if (!bIsProtect)
		return;

	TEXTWORD twWord =  0x39FE3900;
	twWord = twWord | nMaxLen;
	m_string += twWord;
}

void CLtxtObj::SeparateMaxLenFromString(int& nMaxLen)
{
	BOOL bIsProtect = IsProtectDomain();
	if (!bIsProtect)
		return;

	int nLen = m_string.GetTextSize();
	TEXTWORD twWord = m_string[nLen - 1]);
	nMaxLen = twWord & 0x000000FF;

}
*/

void KSDomainText::Serialize_01(KSArchive& ar)
{
	CLtxtObj::Serialize_01(ar);

	if (ar.IsStoring())
	{
		ar << m_sTitle;
		ar << m_bBackGround;

	}
	else
	{
		ar >> m_sTitle;
		ar >> m_bBackGround;
	}

	CWPSObj::SerializeObjType(ar);
}

///////////////////////////////////////////////////////////////////////////////////

// �������ֱ���������

IMPLEMENT_SERIAL(KSDomainMLText, CRotateText,0xA0 | VERSIONABLE_SCHEMA)

KSDomainMLText::KSDomainMLText()
{
}

KSDomainMLText::~KSDomainMLText()
{

}

CWpsView* GetCurView();
KSDomainMLText::KSDomainMLText(const CWpsDoc* pDoc, 
						   const CRect& position, 
						   int nShape/*=rectangle*/)
			:CRotateText(pDoc,position,rectangle)     
{
	m_sTitle = _T("");
	m_bBackGround = FALSE;
//	CWpsView* pView = ::GetCurView();
//	ASSERT_VALID(pView);
//	SetHAlignment((WORD)TAL_LEFT, pView);
//	SetVAlignment((WORD)TAL_TOP, pView);
//
	m_uLPenStyle = PS_NULL;
//	KCOLORINDEX indexColor;
//	KColorModel::RGBToColor(indexColor, 192,192, 192);
//
//	SetBkMode(OPAQUE);					// �����:���
//	SetBkColor(indexColor);		// ��ɫ
////	SetFillLogBrush(BS_HATCHED, RGB(192, 192, 192), NULL);
//	SetFillLogBrush(0, indexColor, 0);
}

void KSDomainMLText::Serialize_01(KSArchive& ar)
{
	CRotateText::Serialize_01(ar);

	if (ar.IsStoring())
	{
		ar << m_sTitle;
		ar << m_bBackGround;

	}
	else
	{
		ar >> m_sTitle;
		ar >> m_bBackGround;
	}
	CWPSObj::SerializeObjType(ar);
}
