/* -------------------------------------------------------------------------
//	�ļ���		��	ptcurve.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-25 12:05:53
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CCurveObj, CPTObj, 0xA0 | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

void CCurveObj::Serialize_97( CArchive& ar)
{
	CPTObj::Serialize_97( ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{	__int16 wTemp;
		for ( int i=0; i<4; i++)
		{
			ar >>  wTemp; m_curvepnt[i].x = wTemp;
			ar >>  wTemp; m_curvepnt[i].y = wTemp;
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CCurveObj::Serialize_98( CArchive& ar)
{
	CPTObj::Serialize_98( ar);
	if (ar.IsStoring())
	{
		ar << m_curvepnt[0];
		ar << m_curvepnt[1];
		ar << m_curvepnt[2];
		ar << m_curvepnt[3];
	}
	else
	{
		ar >> m_curvepnt[0];
		ar >> m_curvepnt[1];
		ar >> m_curvepnt[2];
		ar >> m_curvepnt[3];
	}
	CWPSObj::SerializeObjType(ar);
}

void CCurveObj::Serialize_01( CArchive& ar)
{
	CPTObj::Serialize_01( ar);
	if (ar.IsStoring())
	{
		ar << m_curvepnt[0];
		ar << m_curvepnt[1];
		ar << m_curvepnt[2];
		ar << m_curvepnt[3];
	}
	else
	{
		ar >> m_curvepnt[0];
		ar >> m_curvepnt[1];
		ar >> m_curvepnt[2];
		ar >> m_curvepnt[3];
	}
	CWPSObj::SerializeObjType(ar);
}

// -------------------------------------------------------------------------
