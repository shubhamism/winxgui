/* -------------------------------------------------------------------------
//	�ļ���		��	ctrlcodeio.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 14:45:54
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ctrlcode.h"
#include "ctrlcode_sprm.h"
#include "cclist.h"
//#include "cclist.cpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// ============ temporary

class KDelegatedBufferOp: public IAppendBuffer
{
private:
	std::vector<char> m_data;

public:
	UINT GetSize() const
	{
		return m_data.size();
	}
	LPCVOID GetData() const
	{
		return m_data.begin();
	}
	HRESULT Add(LPCVOID pData, UINT cb)
	{
		const char* first = (const char*)pData;
		m_data.insert(m_data.end(), first, first + cb);
		return S_OK;
	}
	void DumpBuffer();
};

#ifdef _DEBUG
void KDelegatedBufferOp::DumpBuffer()
{
	//	return;		// Disable dump

	FILE* fp = fopen("d:\\ctrlcode_dump.txt", "a");
	if (fp == NULL)
	{
		TRACEA("Could not open tested file\n");
		return;
	}

	int nSize = m_data.size();
	const WORD* p = (const WORD*)m_data.begin();

	if (nSize & 1)
		fprintf(fp, "A segment is not word aligned\r\n");
	nSize >>= 1;	// convert to count of word

	fprintf(fp, "[%lX]: ", nSize);
	for (int i= 0; i < nSize; i++)
	{
		fprintf(fp, "%X ", p[i]);
	}
	fprintf(fp, "\r\n\r\n");

	fclose(fp);
}
#endif

void ReadProp(CObList* pList, KSArchive& ar)
{
	LPBYTE pData;
	DWORD cb;

	sprmCtrlAid::KNestedSprmList	nest;
	WORD	sprm;
	WORD*	pw;
	CCtrlCode*	pcc;
	WORD*	pEND;

	ASSERT(pList != NULL);

	ar >> cb;
	if (cb == 0)
		return;

	pData = new BYTE[cb];
	if (pData == NULL)
	{
		ASSERT(pData);
		// throw exception may be better
		return;
	}
	ar.Read(pData, cb);

	pEND = (WORD*)pData + (cb >> 1);
	nest.Start((WORD*)pData, cb >> 1);
	while (!nest.EndOfList())
	{
		nest.Next(sprm, pw);
		pcc = CoCreate_CtrlCode(sprm, pw, pEND - pw, nest);
		ASSERT(49680 == sprm || pcc != NULL);
		if (pcc != NULL)
			pList->AddTail(pcc);
	}

	delete[] pData;
}

void ReadProp(CObArray* pArray, KSArchive& ar)
{
	LPBYTE pData;
	DWORD cb;

	sprmCtrlAid::KNestedSprmList	nest;
	WORD	sprm;
	WORD*	pw;
	CCtrlCode*	pcc;
	WORD*	pEND;

	ASSERT(pArray != NULL);

	ar >> cb;
	if (cb == 0)
		return;

	pData = new BYTE[cb];
	if (pData == NULL)
	{
		ASSERT(pData);
		// throw exception may be better
		return;
	}
	ar.Read(pData, cb);

	pEND = (WORD*)pData + (cb >> 1);
	nest.Start((WORD*)pData, cb >> 1);
	while (!nest.EndOfList())
	{
		nest.Next(sprm, pw);
		pcc = CoCreate_CtrlCode(sprm, pw, pEND - pw, nest);
		ASSERT(pcc != NULL);
		if (pcc != NULL)
			pArray->Add(pcc);
	}

	delete[] pData;
}

void WriteProp(CObList* pList, KSArchive& ar)
{
	KDelegatedBufferOp	pDBuf;
	CCtrlCode*	p;
	POSITION	pi;
	_CoSaveArg	csarg;

	csarg.pAr = &ar;

	if (pList == NULL)
	{
		ar << (DWORD)0;
		return;
	}

	for(pi = pList->GetHeadPosition(); pi != NULL; )
	{
		p = (CCtrlCode*)pList->GetNext(pi);
		CoSave_CtrlCode(p, &pDBuf, &csarg);
	}

	DWORD dwSize = pDBuf.GetSize();
	ar << dwSize;
	ar.Write(pDBuf.GetData(), dwSize);
#ifdef _DEBUG
	pDBuf.DumpBuffer();
#endif
}

void WriteProp(CObArray* pArray, KSArchive& ar)
{
	KDelegatedBufferOp	pDBuf;
	CCtrlCode*	p;
	int			i, c;
	_CoSaveArg	csarg;

	csarg.pAr = &ar;

	if (pArray == NULL)
	{
		ar << (DWORD)0;
		return;
	}

	c = pArray->GetSize();
	for (i = 0; i < c; i++)
	{
		p = (CCtrlCode*)((*pArray)[i]);
		CoSave_CtrlCode(p, &pDBuf, &csarg);
	}

	DWORD dwSize = pDBuf.GetSize();
	ar << dwSize;
	ar.Write(pDBuf.GetData(), dwSize);
#ifdef _DEBUG
	pDBuf.DumpBuffer();
#endif
}

// ===========================

// used by CTableElement
STDMETHODIMP TableElementProp_Serialize_Write(CObList& AttribList, KSArchive& ar)
{
//	AttribList.Serialize(ar);
	WriteProp(&AttribList, ar);
	return S_OK;
}

STDMETHODIMP TableElementProp_Serialize_Read(CObList& AttribList, KSArchive& ar)
{
//	AttribList.Serialize(ar);
	ReadProp(&AttribList, ar);
	return S_OK;
}

// used by CFrameTable
STDMETHODIMP TableElementProp_Serialize_Write(CObArray& AttribList, KSArchive& ar)
{
//	AttribList.Serialize(ar);
	WriteProp(&AttribList, ar);
	return S_OK;
}

STDMETHODIMP TableElementProp_Serialize_Read(CObArray& AttribList, KSArchive& ar)
{
//	AttribList.Serialize(ar);
	ReadProp(&AttribList, ar);
	return S_OK;
}

// used by CStyle_Text
STDMETHODIMP StylePara_Serialize_Write(CObList& PAList, KSArchive& ar)
{
//	PAList.Serialize(ar);
	WriteProp(&PAList, ar);
	return S_OK;
}

STDMETHODIMP StylePara_Serialize_Read(CObList& PAList, KSArchive& ar)
{
//	PAList.Serialize(ar);
	ReadProp(&PAList, ar);
	return S_OK;
}

STDMETHODIMP StyleSent_Serialize_Write(CObList& SAList, KSArchive& ar)
{
//	SAList.Serialize(ar);
	WriteProp(&SAList, ar);
	return S_OK;
}

STDMETHODIMP StyleSent_Serialize_Read(CObList& SAList, KSArchive& ar)
{
//	SAList.Serialize(ar);
	ReadProp(&SAList, ar);
	return S_OK;
}

// used by CSentence
STDMETHODIMP SentenceProp_Serialize_Write(KSArchive& ar, CObList* pAttribList)
{
//	ar << pAttribList;
	WriteProp(pAttribList, ar);
	return S_OK;
}

STDMETHODIMP SentenceProp_Serialize_Read(KSArchive& ar, CObList** ppAttribList)
{
//	ar >> *ppAttribList;
	*ppAttribList = new CObList;
	ReadProp(*ppAttribList, ar);
	return S_OK;
}

// used by CParagraph
STDMETHODIMP ParagraphProp_Serialize_Write(KSArchive& ar, CObList* pAttribList)
{
//	ar << pAttribList;
	WriteProp(pAttribList, ar);
	return S_OK;
}

STDMETHODIMP ParagraphProp_Serialize_Read(KSArchive& ar, CObList** ppAttribList)
{
//	ar >> *ppAttribList;
	*ppAttribList = new CObList;
	ReadProp(*ppAttribList, ar);
	return S_OK;
}

STDMETHODIMP TextObj_Serialize_Write_02(CObList& AttrList, CArchive& ar)
{
	WriteProp(&AttrList, ar);
	return S_OK;
}

STDMETHODIMP TextObj_Serialize_Read_02(CObList& AttrList, CArchive& ar)
{
	ReadProp(&AttrList, ar);
	return S_OK;
}

// -------------------------------------------------------------------------
