/* -------------------------------------------------------------------------
//	�ļ���		��	ex_autonum.h
//	������		��	����
//	����ʱ��	��	2004-11-3 11:21:57 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_AUTONUM_H__
#define __EX_AUTONUM_H__

#include <stl/map.h>

// -------------------------------------------------------------------------

class CAutonum_Export
{
public:
	CAutonum_Export() {}
	~CAutonum_Export() {}

public:
	typedef std::map<KAutoNumGroupPtr*, UINT> AutonumGroupMapType;
	AutonumGroupMapType m_AutonumGroupMap;

public:
	STDMETHODIMP_(UINT) Convert(KWpsExport& export, KAutoNumGroupPtr* pGroup);
};

// -------------------------------------------------------------------------

#endif /* __EX_AUTONUM_H__ */
