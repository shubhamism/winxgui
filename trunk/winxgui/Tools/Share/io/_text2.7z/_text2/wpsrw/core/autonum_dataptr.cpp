/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_dataptr.cpp
//	������		��	����
//	����ʱ��	��	2004-10-29 11:28:51 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "autonum_atom.h"
#include "autonum_group.h"
#include "autonum_dataptr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////
// ����		��	��KAutoNumAtomSPtrȡ��Ӧ��tagAUTONUMATOM*
/////////////////////////////////////////////////////////////////
tagAUTONUMATOM*
GetAtom_FromAtomSPtr(const KAutoNumAtomSPtr& spAtom)
{
	tagAUTONUMATOM* _pRet	= NULL;
	KAutoNumAtomSPtr _spAtom	= spAtom;
	KAutoNumAtomPtr* _pAtomPtr	= _spAtom;
	if (_pAtomPtr)
		_pRet	= (tagAUTONUMATOM*)(*_pAtomPtr);
	return _pRet;
}

/////////////////////////////////////////////////////////////////
// ����		��	��KAutoNumGroupSPtrȡ��Ӧ��tagAUTONUMGROUP*
/////////////////////////////////////////////////////////////////
tagAUTONUMGROUP*
GetGroup_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup)
{
	tagAUTONUMGROUP* _pRet	= NULL;
	KAutoNumGroupSPtr _spGroup		= spGroup;
	KAutoNumGroupPtr* _pGroupPtr	= _spGroup;
	if (_pGroupPtr)
		_pRet	= (tagAUTONUMGROUP*)(*_pGroupPtr);
	return _pRet;
}

/////////////////////////////////////////////////////////////////
// ����		��	��KAutoNumGroupSPtrȡ��Ӧ��KAutoNumAtomSPtr
/////////////////////////////////////////////////////////////////
KAutoNumAtomSPtr
GetAtomSPtr_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup, int nLevel)
{
	KAutoNumAtomSPtr _Ret;
	tagAUTONUMGROUP* _pGroupData	= GetGroup_FromGroupSPtr(spGroup);
	if (_pGroupData && ISVALIDAUTONUMLEVEL(nLevel))
		_Ret	= _pGroupData->GroupData[nLevel];
	return _Ret;
}

/////////////////////////////////////////////////////////////////
// ����		��	��KAutoNumGroupSPtrȡĳ��level��KAutoNumAtomPtr*,���Ƽ�ʹ��
/////////////////////////////////////////////////////////////////
KAutoNumAtomPtr*
GetAtomPtr_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup, int nLevel)
{	// ���Ƽ�ʹ�ô˺���
	KAutoNumAtomPtr* _pRet				= NULL;
	tagAUTONUMGROUP* _pGroupData	= GetGroup_FromGroupSPtr(spGroup);
	if (_pGroupData && ISVALIDAUTONUMLEVEL(nLevel))
	{
		KAutoNumAtomSPtr _spAtom	= _pGroupData->GroupData[nLevel];
		_pRet	= (KAutoNumAtomPtr*)(_spAtom);
	}
	return _pRet;
}

/////////////////////////////////////////////////////////////////
// ����		��	��KAutoNumGroupSPtrȡĳ��level��tagAUTONUMATOM*
/////////////////////////////////////////////////////////////////
tagAUTONUMATOM*
GetAtom_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup, int nLevel)
{
	tagAUTONUMATOM* _pRet	= NULL;
	KAutoNumAtomPtr* _pAtomPtr	= GetAtomPtr_FromGroupSPtr(spGroup, nLevel);
	if (_pAtomPtr)
		_pRet	= (tagAUTONUMATOM*)(*_pAtomPtr);
	return _pRet;
}

// -------------------------------------------------------------------------
