/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_abgroupinfoman.h
//	������		��	����
//	����ʱ��	��	2004-10-27 11:12:01 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __AUTONUM_ABGROUPINFOMAN_H__
#define __AUTONUM_ABGROUPINFOMAN_H__

// autonumber and bullet group info manager
#define		defTYPE_UNKNOWN				0
#define		defTYPE_BULLET				1
#define		defTYPE_AUTONUMBER			2

#define		defMINLEVEL					0		//��С��
#define		defMAXLEVEL					8		//����

#define		BMPBUTTONNUMBER				8
#define		defKSTARTNUMBERMIN			1
#define		defKSTARTNUMBERMAX			2000

	BOOL g_MakeupAutoNumAtomFromOldInfo(tagAUTONUMATOM*, int, int, int, int, BOOL=TRUE);

// -------------------------------------------------------------------------

class KAutoNumIOAdapter;
class KABGroupInfoMan : public CObject
{
	DECLARE_SERIAL(KABGroupInfoMan);
protected:
	_KGroupContainer		m_listGroup;
	_KAtomContainer			m_listAtom;
public:
	KABGroupInfoMan();
/*	//@@ appendix
	KABGroupInfoMan(const KABGroupInfoMan&);
*/	//@@ appendix
	virtual ~KABGroupInfoMan();
public:
	void ReleaseAll();
/*	//@@ appendix
	const KABGroupInfoMan& operator=(const KABGroupInfoMan&);
*/	//@@ appendix
protected:
	int m_nLengthPerLevel;
/*	//@@ appendix
public:
	void SetLengthPerLevel(int n);
	int GetLengthPerLevel() const;		// ��ʷԭ��
*/	//@@ appendix
public:
	KAutoNumAtomSPtr AddAtom(tagAUTONUMATOM*, BOOL bAllocMem = FALSE);
	KAutoNumGroupSPtr AddGroup(tagAUTONUMGROUP*, BOOL bAllocMem = FALSE);

/*	//@@ appendix
	ATOMPOS GetFirstAtomPos();
	KAutoNumAtomSPtr GetNextAtom(ATOMPOS&);
	ATOMPOS		GetEndAtomPos();
	GROUPPOS GetFirstGroupPos();
	KAutoNumGroupSPtr GetNextGroup(GROUPPOS&);
	GROUPPOS	GetEndGroupPos();

	int GetAtomSize() const;
	int GetGroupSize() const;
*/	//@@ appendix
public:
	virtual void Serialize(KSArchive& ar);
public:
	static KAutoNumIOAdapter* SelectIOAdapter(KAutoNumIOAdapter*);
protected:
	static KAutoNumIOAdapter* s_pIOAdapter;
};

// -------------------------------------------------------------------------

#endif /* __AUTONUM_ABGROUPINFOMAN_H__ */
