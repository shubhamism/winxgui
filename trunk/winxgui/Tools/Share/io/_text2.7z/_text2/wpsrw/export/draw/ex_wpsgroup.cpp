/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wpsgroup.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-9 18:21:10
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_wpsgroup.h"

#include "ex_ptobj.h"
#include "ex_frametext.h"
#include "ex_frameimg.h"
#include "ex_frameole.h"
#include "ex_wpsgroup.h"
#include "ex_objtext.h"
#include "ex_frameole.h"
#include "ex_framept.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

EX_SHAPE_API CWPSGroup_Export::ConvertShape(CShape_Context& context)
{
	for (POSITION pos = m_grpobjList.GetHeadPosition(); pos; )
	{
		CWPSObj* pWpsObj = (CWPSObj*)m_grpobjList.GetNext(pos);
		ASSERT(
			pWpsObj->IsKindOf(RUNTIME_CLASS(CWPSObj)));

		int nObjType = pWpsObj->CheckObjType();
		BOOL fGroup = IsGroupObject(pWpsObj);
		CRect rc = pWpsObj->GetMrect();
#ifndef WPP_ONLY
		CShape_Context subshape(context.GetWpsExport());
#else
		CShape_Context subshape(context.GetSlideBaseCtx());
#endif

		switch (nObjType)
		{
		case LTXTObj:
		case LTXTSizeComment:
			{
				CLtxtObj_Export* pExpClass = reinterpret_cast<CLtxtObj_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case MultitextRect:
			{
				CRotateText_Export* pExpClass = reinterpret_cast<CRotateText_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case FRAMEOLE:
			{
//				subshape.ConvertShape(pWpsObj);//ole�����Լ���ת��
//				continue;
			}
		
			break;
		case LINEObj:
			//case LINECycle:
			{
				CLineObj_Export* pExpClass = reinterpret_cast<CLineObj_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case RECTObj:
		case RECTRound:
		case RECTEllipse:
		case RECTDiamond:
		case RECTCube:
		case RECTCylinder:
		case RECTPieColumn:
			{
				CRectObj_Export* pExpClass = reinterpret_cast<CRectObj_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case POLYObj:
//			{
//				CPolyObj_Export* pExpClass = reinterpret_cast<CPolyObj_Export*>(pWpsObj);
//				ASSERT(pExpClass);
//				pExpClass->GetShapeRect(subshape, rc);
//			}
			break;
		case CURVEObj:
//			{
//				CCurveObj_Export* pExpClass = reinterpret_cast<CCurveObj_Export*>(pWpsObj);
//				ASSERT(pExpClass);
//				pExpClass->GetShapeRect(subshape, rc);
//			}
			break;
		case RECTPoly:
			{
				CRectPoly_Export *pExpClass = reinterpret_cast<CRectPoly_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);			
			}
			break;
		}

		if (nObjType == LTXTObj || nObjType == MultitextRect)
		{
			rc.right += 5;	//��/�������ּӼӿ�һ��
			rc.bottom += 5; //��/�������ּӸ�һ��
		}
#ifndef WPP_ONLY
		if (nObjType == FRAMETable)
		{
			rc.right += _TABLEINBOXADD;	
			rc.bottom += _TABLEINBOXADD; 
			subshape.m_nPageLocation = 1;
		}
#endif
#ifndef WPP_ONLY
		subshape.m_shape = context.m_shape.NewShape(fGroup)
			.SetChildAnchor(
				WpsShapeToTwip(rc.left),
				WpsShapeToTwip(rc.top),
				WpsShapeToTwip(rc.right),
				WpsShapeToTwip(rc.bottom));
#else
		subshape.m_shape = context.m_shape.NewShape(nObjType == FRAMETable ? TRUE : fGroup)
			.SetChildAnchor(
				WpsShapeToPptUnit(rc.left),
				WpsShapeToPptUnit(rc.top),
				WpsShapeToPptUnit(rc.right),
				WpsShapeToPptUnit(rc.bottom));
#endif

		subshape.ConvertShape(pWpsObj);
		subshape.m_shape.SetProperties(subshape.m_opt);
		subshape.m_shape.SetUDefProperties(subshape.m_optUDef);

	}
}

// -------------------------------------------------------------------------





















