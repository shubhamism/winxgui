/* -------------------------------------------------------------------------
//	�ļ���		��	wpsfile.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 19:34:05
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <atlconv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

BOOL g_fCopyPasteProc;// ������̺Ϳ���ճ��

const WCHAR g_wcsPicStream[]  = { 'P', 'i', 'c', 0 };
const WCHAR g_wcsObjStream[]  = { 'O', 'b', 'j', 0 };
const WCHAR g_wcsTextStream[] = { 'T', 'e', 'x', 't', 0 };

// -------------------------------------------------------------------------

class KWPS2002File2 : public KWPS2002File
{
public:
	using KWPS2002File::m_pRootStg;
	using KWPS2002File::m_pPicStream;
	using KWPS2002File::m_pMainStream;
	using KWPS2002File::m_pObjStream;
};

KWPS2002File::~KWPS2002File()
{
	if (m_pRootStg || m_hFile != CFile::hFileNull)
	{
		KWPS2002File::Close();
	}
}

BOOL KWPS2002File::Open(LPCTSTR lpszFileName, UINT nOpenFlags, CFileException* pError)
{
	SetFilePath(lpszFileName);
	
	if (m_pRootStg || m_hFile != CFile::hFileNull)
	{
		KWPS2002File::Close();
	}
	if (nOpenFlags & CFile::modeCreate)	// create mode
	{
		WCHAR name[_MAX_PATH];
		mbstowcs(name, lpszFileName, _MAX_PATH);
		StgCreateDocfile(name, STGM_G_WRITE, 0, &m_pRootStg);
		if (m_pRootStg == NULL)
		{
			return FALSE;
		}
		return Base::CreateStream(m_pRootStg, m_pszStreamName);
	}
	else if (nOpenFlags & CFile::modeWrite)	// lock-file mode
	{
		ASSERT(FALSE);
		return CFile::Open(lpszFileName, nOpenFlags, pError);
	}
	else	// open mode
	{
		WCHAR name[_MAX_PATH];
		mbstowcs(name, lpszFileName, _MAX_PATH);
		StgOpenStorage(name, NULL, STGM_T_READ, 0, 0, &m_pRootStg);
		if (m_pRootStg == NULL)
		{
			return FALSE;
		}
		return Base::OpenStream(m_pRootStg, m_pszStreamName);
	}
}

BOOL KWPS2002File::Open(IStorage* pStg)
{
	if (m_pRootStg || m_hFile != CFile::hFileNull)
	{
		KWPS2002File::Close();
	}

	m_pRootStg = pStg;

	if (m_pRootStg == NULL)
	{
		return FALSE;
	}

	m_pRootStg->AddRef();

	//modify by zyf ԭ�������Ĭ�ϱ�־λ�� ReadWrite
	//��Ϊstg�����ı�־λΪread����������־λ��ͳһ����linux������ʱ�ʹ򲻿�stream
	return Base::OpenStream(m_pRootStg, m_pszStreamName, modeRead | shareExclusive);
}

void KWPS2002File::Close()
{
	if (m_hFile != CFile::hFileNull)	// lock-file mode
	{
		ASSERT(FALSE);
		CFile::Close();
	}
	else	// create/open mode
	{
		if (m_pMainStream)
		{
			m_pMainStream->Release();
			m_pMainStream = NULL;
		}
		if (m_pPicStream)
		{
			m_pPicStream->Release();
			m_pPicStream = NULL;
		}
		if (m_pObjStream)
		{
			m_pObjStream->Release();
			m_pObjStream = NULL;
		}
		if (m_lpStream)
			Base::Close();
		if (m_pRootStg)
		{
			m_pRootStg->Release();
			m_pRootStg = NULL;
		}
	}
}

// -------------------------------------------------------------------------

STDMETHODIMP_(IStorage*) _QueryStorage(CFile* pFile)
{
	if (pFile->IsKindOf(RUNTIME_CLASS_WPS2002File))
	{
		return ((KWPS2002File2*)pFile)->m_pRootStg;
	}
	return NULL;
}

STDMETHODIMP_(IStream*) SwitchSubdoc(KSArchive& ar, IStream* pNewdoc)
{
	if (pNewdoc == NULL)
		return NULL;

	KWPS2002File2* pFile = (KWPS2002File2*)ar.GetFile();
	if (
		pFile &&
		pFile->IsKindOf(RUNTIME_CLASS_WPS2002File)
		)
	{
		if (pFile->m_pMainStream == NULL)
			(pFile->m_pMainStream = pFile->m_lpStream)->AddRef();

		ar.Flush(); // Ҫ�л������Ƚ���������д��!!!
		
		IStream* pOlddoc = pFile->m_lpStream;
		(pFile->m_lpStream = pNewdoc)->AddRef();
		VERIFY(pOlddoc->Release());
		return pOlddoc;
	}
	return NULL;
}

STDMETHODIMP_(IStream*) _NeedPicStream(KSArchive& ar)
{
	KWPS2002File2* pFile = (KWPS2002File2*)ar.GetFile();
	if (
		pFile &&
		pFile->IsKindOf(RUNTIME_CLASS_WPS2002File)
		)
	{
		if (pFile->m_pPicStream == NULL && pFile->m_pRootStg)
		{
			pFile->m_pRootStg->CreateStream(
				g_wcsPicStream, 
				STGM_CREATE|STGM_SHARE_EXCLUSIVE|STGM_WRITE,
				0, 0,
				&pFile->m_pPicStream
				);
		}
		return pFile->m_pPicStream;
	}
	return NULL;
}

STDMETHODIMP_(IStream*) _QueryPicStream(KSArchive& ar)
{
	KWPS2002File2* pFile = (KWPS2002File2*)ar.GetFile();
	if (
		pFile &&
		pFile->IsKindOf(RUNTIME_CLASS_WPS2002File)
		)
	{
		if (pFile->m_pPicStream == NULL && pFile->m_pRootStg)
		{
			pFile->m_pRootStg->OpenStream(
				g_wcsPicStream,
				NULL,
				STGM_SHARE_EXCLUSIVE|STGM_READ,
				0,
				&pFile->m_pPicStream
				);
		}
		return pFile->m_pPicStream;
	}
	return NULL;
}

STDMETHODIMP_(IStream*) _NeedObjStream(CFile* pFile0)
{
	KWPS2002File2* pFile = (KWPS2002File2*)pFile0;
	if (
		pFile &&
		pFile->IsKindOf(RUNTIME_CLASS_WPS2002File)
		)
	{
		if (pFile->m_pObjStream == NULL && pFile->m_pRootStg)
		{
			pFile->m_pRootStg->CreateStream(
				g_wcsObjStream, 
				STGM_CREATE|STGM_SHARE_EXCLUSIVE|STGM_WRITE,
				0, 0,
				&pFile->m_pObjStream
				);
		}
		return pFile->m_pObjStream;
	}
	return NULL;
}

STDMETHODIMP_(IStream*) _NeedObjStream(KSArchive& ar)
{
	return _NeedObjStream(ar.GetFile());
}

STDMETHODIMP_(IStream*) _QueryObjStream(CFile* pFile0)
{
	KWPS2002File2* pFile = (KWPS2002File2*)pFile0;
	if (
		pFile &&
		pFile->IsKindOf(RUNTIME_CLASS_WPS2002File)
		)
	{
		if (pFile->m_pObjStream == NULL && pFile->m_pRootStg)
		{
			pFile->m_pRootStg->OpenStream(
				g_wcsObjStream,
				NULL,
				STGM_SHARE_EXCLUSIVE|STGM_READ,
				0,
				&pFile->m_pObjStream
				);
		}
		return pFile->m_pObjStream;
	}
	return NULL;
}

STDMETHODIMP_(IStream*) _QueryObjStream(KSArchive& ar)
{
	return _QueryObjStream(ar.GetFile());
}

// -------------------------------------------------------------------------

STDMETHODIMP_(BOOL) _IsWPSFile(LPCTSTR lpszFileName, LPCTSTR pszStreamName)
{
	USES_CONVERSION;

	WCHAR name[_MAX_PATH];
	mbstowcs(name, lpszFileName, _MAX_PATH);
	
	if (StgIsStorageFile(name) != S_OK)
		return FALSE;
	
	IStorage* pStg = NULL;
	if (StgOpenStorage(name, NULL, STGM_T_READ, 0, 0, &pStg) != S_OK)
		return FALSE;
	
	IStream* pStrm = NULL;
	HRESULT hr = pStg->OpenStream(A2W(pszStreamName), 0, STGM_G_READ, 0, &pStrm);
	
	if (pStrm)
		pStrm->Release();
	if (pStg)
		pStg->Release();
	
	return hr == S_OK;
}

// -------------------------------------------------------------------------
