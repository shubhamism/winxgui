/////////////////////////////////////////////////////////////////////////////
//
// Formulae.cpp - implementation for CFormulae objects
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h" 
#include <imm.h>
//#include "wpsserial.h"
//#include "ctrlcode.h"
#include "wpsobj.h"
#if !defined(AFX_KSTEXTSTRING_H_INCLUDED_)
#include "./../core/TextString.h"
#endif
//#include "ResID_BMP.h"
#ifndef _WPSREADER
//#include "ResID_String.h"

#ifndef __OBJSET_H
//#include "objset.h"
#endif
#endif	// _WPSREADER

#ifndef __FORMULAE_H
#include "formulae.h"
#endif

#ifndef __FORMCELL_H
#include "formcell.h"
#endif

#ifndef __FORMABC_H
#include "formabc.h"
#endif

#ifndef __FORMVECT_H
#include "formvect.h"
#endif

#ifndef __WPSVIEW_H
//#include "wpsview.h"
#endif

#ifndef __FRAMEOBJ_H
#include "frameobj.h"
#endif

#ifndef __WPSDOC_H
//#include "wpsdoc.h"
#endif

#ifndef __PAGEOP_H
//#include "pageop.h"
#endif

#ifndef __OBJTOOL_H
//#include "objtool.h"
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//int FS[4] = { 637, 425, 247, 185 };
//int nTempFS[4];
//int nFormulaCharMrg = 12;//	��ʽ���ֵļ��(12%)
//int nTempFormulaCharMrg;
////int CM_DEFAULT = 12;	//	��ʽ���ֵļ��(12%)
//int LM_DEFAULT = 50;	//	��ʽ�м�ļ��(50%)
//int GetFS(int ndx);
//
//void SaveFS()
//{
//	for(int i=0; i<4; i++)
//		nTempFS[i] = FS[i];
//	nTempFormulaCharMrg = nFormulaCharMrg;
//}
//
//void RefreshFS()
//{
//	for(int i=0; i<4; i++)
//		FS[i] = nTempFS[i];
//	nFormulaCharMrg = nTempFormulaCharMrg;
//}
//
//void ChangeFS(int nFS[4], int nCharMrg)
//{
//	for(int i=0; i<4; i++)
//		FS[i]=nFS[i];
//	nFormulaCharMrg = nCharMrg;
//}

/////////////////////////////////////////////////////////////////////////////
//	CFormulae

//IMPLEMENT_SERIAL(CFormulae, CWPSObj, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CFormulae, CWPSObj, 0xA0 | VERSIONABLE_SCHEMA)

CFormulae::CFormulae()
{
}

CFormulae::~CFormulae()
{
	ASSERT(this);
	DeleteContent();
}

void CFormulae::DeleteContent()
{
	while (!m_objList.IsEmpty()) 	    
		delete m_objList.RemoveHead();
}      

void CFormulae::Serialize_97(KSArchive&)
{
	ASSERT(FALSE);
}     

void CFormulae::Serialize_98(KSArchive& ar)
{
	CWPSObj::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		m_objList.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_objList.Serialize(ar);
		CWPSObj* pObj;
		//	�衰����
		for (POSITION pos = GetFirstObjPos(); pos;)
		{	pObj = GetNextObj(pos);
			pObj->SetMstObj(this);
		}            
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormulae::Serialize_01(KSArchive& ar)
{
	CWPSObj::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		m_objList.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_objList.Serialize(ar);
		CWPSObj* pObj;
		//	�衰����
		for (POSITION pos = GetFirstObjPos(); pos;)
		{	pObj = GetNextObj(pos);
			pObj->SetMstObj(this);
		}            
	}
	CWPSObj::SerializeObjType(ar);
}

//void CWPSObj::GetInFocusObjRect(CWpsView* pView, CRect* rc)
//{
//	if (pView->c_pCurCell)
//	{
//		if (pView->IsObjActivated() && 
//			pView->c_pCurCell->IsKindOf(RUNTIME_CLASS(CFormABC)))
//			pView->c_pCurCell->GetInFocusObjRect(pView, rc);
//		else
//		{
//			CRect rct = pView->c_pCurCell->m_rect;
//			CellToForm(pView->GetCurObj(), pView->c_pCurCell, rct);
//			if (CELL_POS_HEAD == pView->GetCurSZPos())
//				*rc = CRect(rct.TopLeft(), CSize(2,2));
//			else
//				*rc = CRect(rct.BottomRight(), CSize(2,2));
//		}
//	}
//	else
//		*rc = m_rect;
//}


/////////////////////////////////////////////////////////////////////////////
//	CFormObj

//IMPLEMENT_SERIAL(CFormObj, CFormulae, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormObj, CFormulae, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)



CFormObj::~CFormObj()
{
	ASSERT(this);
	DeleteContent();
}

void CFormObj::DeleteContent()
{
}      



void CFormObj::Serialize_97(KSArchive&)
{
	ASSERT(FALSE);
}     

void CFormObj::Serialize_98(KSArchive& ar)
{
	CFormulae::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nCompLoca, sizeof(int));
		ar.Write(&m_nType,		sizeof(int));
		ar << m_bHasFather;
		if(!m_bHasFather)//�ޡ�����������ֺ�
		{	for(int i=0;i<4; i++)
				ar << m_nFontSize[i];
			ar.Write(&m_nFormulaCharMrg, sizeof(int));
		}
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nCompLoca,	sizeof(int));
		ar.Read(&m_nType,		sizeof(int));
		SetMstObj(NULL);
		int nVersion = ar.GetObjectSchema();
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
			{	int nOldFS[4] = { 637, 425, 247, 185 };
				for(int i=0;i<4; i++)
					m_nFontSize[i] = nOldFS[i];
				m_nFormulaCharMrg = 12;//��ֵΪ12
			}
			break;
			case 1:
			{	ar >> m_bHasFather;
				if(!m_bHasFather)//�ޡ�����������ֺ�
				{	for(int i=0;i<4; i++)
						ar >> m_nFontSize[i];
					ar.Read(&m_nFormulaCharMrg, sizeof(int));
				}
			}
			break;
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormObj::Serialize_01(KSArchive& ar)
{
	CFormulae::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nCompLoca, sizeof(int));
		ar.Write(&m_nType,		sizeof(int));
		ar << m_bHasFather;
		if(!m_bHasFather)//�ޡ�����������ֺ�
		{	for(int i=0;i<4; i++)
				ar << m_nFontSize[i];
			ar.Write(&m_nFormulaCharMrg, sizeof(int));
		}
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nCompLoca,	sizeof(int));
		ar.Read(&m_nType,		sizeof(int));
		SetMstObj(NULL);
		int nVersion = ar.GetObjectSchema();
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
			{
				int nOldFS[4] = { 637, 425, 247, 185 };
				for(int i=0;i<4; i++)
					m_nFontSize[i] = nOldFS[i];
				m_nFormulaCharMrg = 12;//��ֵΪ12
			}
			break;
			case 1:
			{
				ar >> m_bHasFather;
				if(!m_bHasFather)//�ޡ�����������ֺ�
				{	for(int i=0;i<4; i++)
						ar >> m_nFontSize[i];
					ar.Read(&m_nFormulaCharMrg, sizeof(int));
				}
			}
			break;
		}
	}
	CWPSObj::SerializeObjType(ar);
}







void CFormObj::SetMstObj(CWPSObj* pObj)
{
	CFormulae::SetMstObj(pObj);
	if(pObj)
		m_bHasFather=TRUE;
	else 
		m_bHasFather=FALSE;
}

#ifndef _GWSREADER

#endif	// #ifndef _GWSREADER

/////////////////////////////////////////////////////////////////////////////
//	CFormula

//IMPLEMENT_SERIAL(CFormula, CWPSObj, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CFormula, CWPSObj, 0xA0 | VERSIONABLE_SCHEMA)

CFormula::CFormula()
{                      
}

CFormula::~CFormula()
{
	ASSERT(this);
	DeleteContent();
}

void CFormula::DeleteContent()
{
	while (!m_objList.IsEmpty()) 	    
		delete m_objList.RemoveHead();
}      

void CFormula::Serialize_97(KSArchive&)
{
	ASSERT(FALSE);
}     

void CFormula::Serialize_98(KSArchive& ar)
{
	CWPSObj::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nFSIndex, sizeof(int));
		ar.Write(&m_nHor, sizeof(int));
		ar.Write(&m_nVer, sizeof(int));
		m_objList.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nFSIndex, sizeof(int));
		ar.Read(&m_nHor, sizeof(int));
		ar.Read(&m_nVer, sizeof(int));
		m_objList.Serialize(ar);
		//	�衰����
		CWPSObj* pObj;
		for (POSITION pos = GetFirstObjPos(); pos;)
		{
			pObj = GetNextObj(pos);
			pObj->SetMstObj(this);
		}            
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormula::Serialize_01(KSArchive& ar)
{
	CWPSObj::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nFSIndex, sizeof(int));
		ar.Write(&m_nHor, sizeof(int));
		ar.Write(&m_nVer, sizeof(int));
		m_objList.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nFSIndex, sizeof(int));
		ar.Read(&m_nHor, sizeof(int));
		ar.Read(&m_nVer, sizeof(int));
		m_objList.Serialize(ar);
		//	�衰����
		CWPSObj* pObj;
		for (POSITION pos = GetFirstObjPos(); pos;)
		{	pObj = GetNextObj(pos);
			pObj->SetMstObj(this);
		}            
	}
	CWPSObj::SerializeObjType(ar);
}
