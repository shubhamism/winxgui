   // KSCodePageVI.h: interface for the KSCodePageVI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KSCODEPAGEVI_H_INCLUDED_)
#define AFX_KSCODEPAGEVI_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef AFX_KXCODEPAGEVI_H_INCLUDED_
#include "KXCodePageVI.h"
#endif // #ifndef AFX_KXCODEPAGEVI_H_INCLUDED_

class KSCodePageVI_GBK : public KXCodePageVI  
{
public:
	KSCodePageVI_GBK();
	virtual ~KSCodePageVI_GBK();

private:
	DWORD m_dwLanguageVersion;
public:
	void SetLanguageVersion(DWORD dwVer)
	{
		if (m_dwLanguageVersion != dwVer)
		{
			m_dwLanguageVersion = dwVer;
			SetUpCPDatas();
		}
	}
	DWORD GetLanguageVersion() const
	{ return m_dwLanguageVersion; }
	void SetUpCPDatas();
public:
	virtual TEXTWORD GB18030ToUniChar(TEXTWORD twChar);
	virtual TEXTWORD UniCharToGB18030(TEXTWORD twChar);

	virtual TEXTWORD GetFirstWord(LPCTSTR lpsz, WORDPOSITION& wpos);
	virtual TEXTWORD GetNextWord(LPCTSTR lpsz, WORDPOSITION& wpos);
	//��Ԫ���±���ʾ��������
	virtual BOOL FilterSupSub(LPCTEXTWORD lptwText,
					LPWSTR lpszEng, LPWSTR lpszChn,
					int& nFilteredEng, int& nFilteredChn,
					int nMode);	

	/*@@todo
	// virtual interface
	virtual int GetNextTabPara (int nPos, KXTextTool* pTextTool, UINT uFlag = GTP_POS);
	virtual BOOL IsThereATab(LPCTEXTWORD pTextOrg, int nNumOfChars);
	virtual void CP_Draw_MakeUp(KXWpsView* pView,		CDC* pDC, 
							 LPWSTR lpszTextChn,	LPWSTR lpszTextEng,
							 LPINT	lpnPosChn,		LPINT lpnPosEng,
							 int& nOrgChn,			int& nOrgEng,
							 int& nLineExt,
							 KXCharWidthTbl* pCharWidthTblEng,
							 KXCharWidthTbl* pCharWidthTblChn,
							 LPCUNIT_VALUE pTrack,
							 LPCTEXTWORD pTextOrg,
							 int nNumOfChars,
							 BOOL bLineHead,		BOOL bLineTail,
							 BOOL bLastLineOfPara,
							 WORD wAlignment,
							 DWORD dwLineExt,
							 BOOL bCS0_Spc,
							 BOOL bCS0_Tab,
							 KXTextTool *pTextTool,
							 int nPageOrient,
							 BOOL bSS = FALSE,
							 KXTextKernel *pTextLine = NULL,
							 CUIntArray *parErrWord = NULL,
							 CUIntArray *parErrwordPos = NULL);
	virtual BOOL CP_Draw_Init(LPBYTE& lpBuf, int nBufSize, LPWSTR& lpszTextChn, LPWSTR& lpszTextEng,
							  LPINT& lpnPosChn, LPINT& lpnPosEng);
	virtual BOOL CP_ExtTextOut(HDC hDC, int x, int y, UINT nOptions, LPCRECT lpRect,
							   LPCWSTR lpszString, LPINT lpDxWidths, BOOL bIsChinese,
							   BOOL bPrinting=FALSE);
	virtual int CP_KSTextStringToTextOutBuf(LPWSTR lpOutBuf, int nOutLen, LPCTEXTWORD pText, int nLen);
	virtual TEXTWORD GetFirstWord(LPCTSTR lpsz, WORDPOSITION& wpos);
	virtual TEXTWORD GetNextWord(LPCTSTR lpsz, WORDPOSITION& wpos);
	virtual const DWORD* GetUni2Gb18030Table();

	virtual BOOL IsCJKFont (const LPLOGFONT lplf,
							const LPTEXTMETRIC lptm,
							int nFontType);
	virtual void CP_FontsFilter(CPtrArray* pArray);
	
	//
	virtual BOOL LoadCPString(CString& str, DWORD dwStrID);
	virtual CString LoadCPString(DWORD dwStrID);
	virtual BOOL IsChar(TEXTWORD twWord);
	virtual BOOL AfxFormatStr(NUM_FORMAT format, int nNum, LPTSTR pBuffer, int nBufLen, DWORD dwLanguageVer = defCHINESESIM_VERSION);
	virtual int GetBulletExtention(int nStyle, LPTSTR pBuffer,
					   KXCharWidthTbl* pCharWidthTblEng,
					   KXCharWidthTbl* pCharWidthTblChn,
					   int nLenPerLevel, BOOL bGetChar = TRUE);
	virtual int GetAutoNumberExtention(int nStyle, int nValue, LPTSTR pBuffer,
					   KXCharWidthTbl* pCharWidthTblEng,
					   KXCharWidthTbl* pCharWidthTblChn,
					   int nLenPerLevel);

	virtual BOOL QueryLineBreak(const TEXTWORD* pChar);

	//�ֽ������ֻ������ڴ��ͷ�
	virtual BOOL CP_Draw_CleanUp(LPBYTE& lpBuf, LPWSTR& lpszTextChn, LPWSTR& lpszTextEng,
								 LPINT& lpnPosChn, LPINT& lpnPosEng);
	
	//�ֽ������ֻ�����������غ���
	virtual LPWSTR  CloneTextBuffer(LPCWSTR lpszSrc);
	virtual int CopyTextBuffer(LPWSTR lpszDest, LPCWSTR lpszSrc);
	virtual BOOL FreeCloneBuffer(LPWSTR& lpszCloneText);



	//��ʾ���ֿ���ʾ��������
	virtual BOOL GetCharOffset(int nIndex, 
					LPCWSTR lpszTextChn,	LPCWSTR lpszTextEng,
					int nOrgChn,			int nOrgEng,
					LPINT lpnPosChn,		LPINT lpnPosEng,
					int& nOff1,			int& nOff2,
					BOOL bSetSpace,		BOOL& bIsChn,
					LPWSTR& lpszNewChn,	LPWSTR& lpszNewEng);

	//�����Ű���ĺ����Լ���غ���
	virtual	BOOL LineTailProcess(LPTEXTWORD& pCurChar,
								 LPCTEXTWORD pFrom,
								 LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 BOOL bSS = FALSE);
	virtual BOOL LineHeadProcess(LPTEXTWORD& pCurChar,
								 LPCTEXTWORD pFrom, 
								 LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 KXCharWidthTbl* pCharWidthTblEng,
								 KXCharWidthTbl* pCharWidthTblChn,
								 BOOL		 bIsFirstLine, 
								 BOOL&		 bGotoPrevSenEnd, 
								 BOOL bSS = FALSE);
	virtual int LineProcess(LPTEXTWORD&			pCurChar,
							LONG&				dwLineWidth,
							BOOL				bIsLineHead,
							TextLineMode		LineMode,
							LONG				dwLegalWidth,
							KXCharWidthTbl*		pCharWidthTblEng,
							KXCharWidthTbl*		pCharWidthTblChn,
							LPCUNIT_VALUE		lpCharTrack,
							int					nPageOrient,
							BOOL				bSS	= FALSE,
							int					nSSOrientOffset = 0,
							KXTextTool*			pTextTool = NULL,
							int*				pnMinLineWid = NULL);
	virtual LPCTEXTWORD PrevChar(LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 LPCTEXTWORD pWord);
	virtual LPCTEXTWORD NextChar(LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 LPCTEXTWORD pWord);
	virtual BOOL IsNonHeadPuncs(TEXTWORD wValue);
	virtual BOOL IsNonTailPuncs(TEXTWORD wValue);

	//�Ű����������ýӿ�
	virtual BOOL GetOptions(LPSTR lpszBuffer, UINT nBufferSize);
	virtual int SetOptions(LPCSTR lpszBuffer);

#ifdef _VER_MENGWEN
	// �Զ��������ӿ�
	virtual void ABCode_Draw_Init(LPSTR, LPSTR&, LPWORD&, LPINT&, LPINT&);
	virtual void ABCode_Draw_MakeUp(KXWpsView*, LPSTR, int, int*, LPCHARGLYPHMETRICS, 
						int&, int&, LPSTR, LPWORD, LPINT, LPINT, int&, int&, int&, BOOL=TRUE);
	virtual void ABCode_Draw_CleanUp(LPSTR&, LPWORD&, LPINT&, LPINT&);

	// �������е���Ӣ�ķֿ��Ű����
	virtual void GetTextExtAndPos(KXTextKernel* pTextLine, ESCSEQDATA* pED, BOOL bIsOutputing);
#endif // _VER_MENGWEN

	virtual BOOL IsMengWenCatalog(TEXTWORD dwChar, int nCharType = 1); */
};

#endif // !defined(AFX_KSCODEPAGEVI_H_INCLUDED_)
