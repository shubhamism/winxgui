/* -------------------------------------------------------------------------
//	�ļ���		��	ex_shape.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 21:20:07
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_SHAPE_H__
#define __EX_SHAPE_H__

#include <export/export.h>
#include <core/anchorobj.h>
#include "ex_objbase.h"
#include <draw/backgrnd.h>
#include <core/textpool.h>

#ifdef WPP_ONLY
#include <export/pres/ex_wppdoc.h>
#endif

// -------------------------------------------------------------------------
typedef struct RECTPOINTS
		 { 
			CPoint p[4];
		  } RectPoints;

extern CRect RecalcObjBox(const CRect& rcObjbox, const CPoint& ptCenter, int nTheta);
extern RectPoints GetRotateRectPoints( const CRect& rect,
								const CPoint& center,
								const int theta, BOOL* pbIsRegular);
extern CRect RecalcObjBox(CPoint* pPoints, int nPointCount);

extern void swap_long(LONG& a, LONG& b);
//#define SWAPHV(rct) {\
//			swap_long(rct.left, rct.top);		\
//			swap_long(rct.right, rct.bottom);}

//#define SWAPWH(rct) {\
//			int __width__  = rct.Width();			\
//			int __height__ = rct.Height();			\
//			rct.right = rct.left + __height__;		\
//			rct.bottom = rct.top + __width__;	}	
#define SWAPWH(rct) {\
	CRect temp;\
	temp.left = rct.CenterPoint().x - rct.Height() * 0.5;\
	temp.right = rct.CenterPoint().x + rct.Height() * 0.5;\
	temp.top = rct.CenterPoint().y - rct.Width() * 0.5;\
	temp.bottom = rct.CenterPoint().y + rct.Width() * 0.5;\
	rct = temp;\
}

//
//�ж϶����Ƿ���ת����϶��󣬰�����϶����ͼ�ο�
//by xushiwei: ��Ϊinline������Ϊ�˱���pObj->CheckObjType()���ö�Ρ�
//
inline
STDMETHODIMP_(BOOL) IsGroupType(int nType)
{
	return (nType == WPSGroup || nType == FRAMEPT || nType == FRAMEChart);
}

#define IsGroupObject(pObj)							\
			(IsGroupType((pObj)->CheckObjType()))


#define _TABLEINBOXADD 0//40//�������ı�����,Ӧ�Ӵ��ı������?
// -------------------------------------------------------------------------
// -------------------------------------------------------------------------

#ifndef EX_SHAPE_API
#define EX_SHAPE_API		STDMETHODIMP_(void)
#endif

// -------------------------------------------------------------------------

template <int wCode>
struct _KShapeExportTraits
{
	typedef void ShapeExportClass;
	typedef void ShapeExportBaseClass;									
};

#define ShapeExportClassOf(wCode)											\
	_KShapeExportTraits< wCode >::ShapeExportClass

#define ShapeExportTypeCast(wCode, pCode)									\
	( (_KShapeExportTraits< wCode >::ShapeExportClass*)(pCode) )

//===========================================================================
#define ShapeExportBaseTypeCast(wCode, pCode)								\
	( reinterpret_cast<_KShapeExportTraits< wCode >::ShapeExportBaseClass*>(pCode) )
	//( (_KShapeExportTraits< wCode >::ShapeExportBaseClass*)(pCode) )

#define ShapeExportClassDecl(wCode, TheClass, BaseClass)					\
template <>																	\
struct _KShapeExportTraits< wCode >											\
{																			\
	typedef TheClass ShapeExportClass;										\
	typedef BaseClass ShapeExportBaseClass;									\
}

#define CALL_BASE_CONVERT()											\
	baseexp* pBase = reinterpret_cast<baseexp*>(this);				\
	ASSERT(pBase);													\
	if (pBase)														\
	{																\
		pBase->ConvertShape(context);								\
	}																

//===========================================================================

// -------------------------------------------------------------------------
// ��λת��

#define WpsShapeToTwip(len)		((len)*1440/254)
#define WpsShapeToPptUnit(len)  ((len)*576/254)

//ת��WPS�����㵥λΪWORD��λ
#define CONVGUNITX(x) (21600 * (x) / rct.Width())
#define CONVGUNITY(y) (21600 * (y) / rct.Height())

//ת��WPS�еĵ�����ΪWORD�е�����
#define ConvActivePointX(x) context.m_opt.ForceAddPropFix(msopt_adjustValue , 21600 * (x) / rct.Width());
#define ConvActivePointY(y) context.m_opt.ForceAddPropFix(msopt_adjust2Value , 21600 * (y) / rct.Height());

#ifdef WPP_ONLY
class KPPTClientDataEx : public KPPTClientData
{
public:
	~KPPTClientDataEx()
	{
		if(m_pAnimationInfo)
			delete m_pAnimationInfo;
	}
};

#endif

class CWPSObj;
class CAnchorObj;
class CWPPSlideBaseContext;
class CShape_Context
{
public:
	KWpsExport& m_export;
#ifdef WPP_ONLY
	CWPPSlideBaseContext* m_wppSlideCtx;
	UINT8 m_nPlaceHolderID;
	KPPTClientDataEx m_pptClientData;
	KPPTClientTextBox* m_pPptClientTextBox;
#endif
public:
	KDWShape m_shape; // ZOrder(SetZOrder)����������(SetShapeType)�������ı���(SetNextShape)��
	KDWShapeOPT m_opt; // ��������
	KDWShapeOPT m_optUDef; // ����ê�㣨���š�����λ�õȣ�����
	//
	DWORD m_dwFlag;//ת����־,Ӧ�ó�������
	INT m_nPageLocation;//���Ϊҳ�����Ϊ�����ҳ�ţ���1��ʼ����0��ʾ��Ƕ�����
	BYTE m_ParagraphTableFlag;	// β�����ֶκ����ֺ�ı�����Ҫ֪��β�淽ʽ������ȷ������
public:

	CShape_Context(KWpsExport& export)
		: m_export(export), m_dwFlag(0), m_nPageLocation(0)
	{
	}
	KWpsExport& GetWpsExport()
	{
		return m_export;
	}
#ifdef WPP_ONLY
	CShape_Context(CWPPSlideBaseContext& wppSlideCtx)
		: m_export(wppSlideCtx.GetDocuCtx().GetWpsExport()), m_wppSlideCtx(&wppSlideCtx),
		m_nPlaceHolderID(PH_NONE), m_pPptClientTextBox(NULL),
		m_dwFlag(0), m_nPageLocation(1)
	{
	}
	CWPPSlideBaseContext& GetSlideBaseCtx()
	{
		return *m_wppSlideCtx;
	}
	KPPTDocument& GetPptDocument()
	{
		return GetSlideBaseCtx().GetPptDocument();
	}
	UINT8& GetPlaceHolderID()
	{
		return m_nPlaceHolderID;
	}
	KPPTClientData& GetPptClientData()
	{
		return m_pptClientData;
	}
	KPPTClientTextBox* GetPptClientTextBox()
	{
		if(m_pPptClientTextBox == NULL)
			m_pPptClientTextBox = new KPPTClientTextBox();
		return m_pPptClientTextBox;
	}
	void SetPptClientTextBox(KPPTClientTextBox* pValue)
	{
		m_pPptClientTextBox = pValue;
	}
#endif
	MsoBlipStore& GetBlipStore()
	{
#ifndef WPP_ONLY
		return m_export.GetBlipStore();
#else
		return m_wppSlideCtx->GetBlipStore();
#endif
	}
	MsoShape& GetShape()
	{
		return m_shape;
	}



	STDMETHODIMP_(BOOL) IsInlineShape() const { return m_nPageLocation == 0; } 
	STDMETHODIMP_(void) Export(CWPSObj* pObj);
	STDMETHODIMP_(void) Export(CAnchorObj* pObj);
	STDMETHODIMP_(void) ConvertShape(CWPSObj* pObj);
	STDMETHODIMP_(void) GetAnchorInfo(CWPSObj* pWpsObj, RECT rc, OUT KDWShapeAnchor& anchor);

};

/*
 *	global helper func
 */
STDMETHODIMP_(MsoBlip) gAddWpsImage2BlipStore(
		IN MsoBlipStore& blipStore, IN const CWpsImage* pImg, OUT SIZE* pImgSizeInPixel);

STDMETHODIMP gDIBFromDDB(HBITMAP hbm, OUT IKsoLockBuffer** ppLB);

#ifdef WPP_ONLY
EX_SHAPE_API gSetCurColorScheme(IColorScheme* pColorScheme);
IColorScheme* gGetCurColorScheme();
#endif

//ʵ�����
EX_SHAPE_API gConvertSolidFill(
							KDWShapeOPT& opt,
							KCOLORINDEX fillColor);
//�������
EX_SHAPE_API gConvertGradientFill(
								 KDWShapeOPT& opt,
								 int nColorDirection,
								 int nColorDistortion,
								 KCOLORINDEX fillColor,
								 KCOLORINDEX fillBackColor);
//ͼ������ת��ͼ��
EX_SHAPE_API gConvertImage(
						  MsoBlipStore& blipStore,
						  MsoShapeOPT& opt,
						  CWpsImage* pImg,
						  BOOL fFrameImage,
						  IN MsoBlip* pExistBlip = NULL,//�����ǰת����pImg,�Ͳ���Ҫÿ�ζ������µ�blip��,����ǳ��˷�
						  OUT MsoBlip* pNewBlip = NULL
						  );
//�������,���̫����
EX_SHAPE_API gConvertImage(
						  KWpsExport& docu,
						  KDWShapeOPT& opt,
						  CWpsImage* pImg,
						  BOOL fFrameImage);
//ת������
EX_SHAPE_API gCovertBackground(
						MsoShape& bgShape,
						MsoBlipStore& blipStore,
						CSlideBackground* psbg,
						CWpsImage* pImg,
						IN MsoBlip* pExistBlip = NULL,//�����ǰת����pImg,�Ͳ���Ҫÿ�ζ������µ�blip��,����ǳ��˷�
						OUT MsoBlip* pNewBlip = NULL
						);


//�����ת��
EX_SHAPE_API gConvertPolyObj(KPointList& PointList, KFlagList& FlagsList,
								   int nPolyobjShape, int nEndStyle,
								   CWPSObj* pObj,
								   CShape_Context& context);

EX_SHAPE_API gConvertPolyObj(KPointList& PointList, KFlagList& FlagsList,
								   int nPolyobjShape, int nEndStyle,
								   CWPSObj* pObj,
								   CShape_Context& context,
								   CRect* pRectRel);

EX_SHAPE_API gSetBRCEX(
				COLORREF color,//
				int nWidth,//�߿� 0.1mm
				int nStyle,//����
				OUT KDWBrc& brc,
				OUT KDWBrc* pbrcRB = NULL,
				UINT dptSpace = 0,//0.1mm
				BOOL bPageBorder = FALSE
				);

EX_SHAPE_API gSetSHDEX(
					BOOL fHaveBackColor,
					KCOLORINDEX fillBackColor,
					BOOL fHaveForeColor,
					KCOLORINDEX fillForeColor,
					LONG lbHatch,
					OUT KDWShd& shdex);

int CheckNumberFormat(LPCTEXTWORD lpszFormat);
LPWSTR TEXTWORD2Unicode(LPWSTR lpszOut, LPCTEXTWORD lpszIn);
#ifdef WPP_ONLY
inline COLORREF gWppColor2PPtColor(COLORREF wppColor, BOOL fTxt = TRUE)
{
	COLORREF pptColor;
	if(wppColor & 0xF0000000)
	{
		if(fTxt)
			pptColor = (wppColor & 0xff) << 24;
		else
			pptColor = 0x08000000 | (wppColor & 0xff);
	}
	else
	{
		pptColor = (wppColor & 0x00ffffff) | 0xfe000000;
	}
	return pptColor;
}
#endif

#ifndef WPP_ONLY
	#define gConvertObjColor(color) color
#else
	#define gConvertObjColor(color) gWppColor2PPtColor(color, FALSE)
#endif
//BOOL InsertTextAttrib(CSentence *pSen, CParagraph *pPara, CObList* plist);
void gCreateTextPool(KSTextString& kstr, CObList& _list, OUT CTextPool& textpool);

void gConvertVAlign(WORD wVAlign, KDWShapeOPT& opt);

// -------------------------------------------------------------------------


#endif /* __EX_SHAPE_H__ */
