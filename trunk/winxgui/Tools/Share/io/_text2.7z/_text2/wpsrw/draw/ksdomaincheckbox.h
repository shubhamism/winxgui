//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainCheckBox.h
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-5-24 0:34:00
//	FileDescription	:	Document protect Domain 
//
//////////////////////////////////////////////////////////////////////////////////////


// KSDomainCheckBox.h: interface for the KSDomainCheckBox class.
//
//////////////////////////////////////////////////////////////////////
#ifndef __KSDOMAINCHECKBOX_H
#define __KSDOMAINCHECKBOX_H


#include "Ptobj.h"

class KSDomainCheckBox : public CRectObj  
{
protected:
	DECLARE_SERIAL(KSDomainCheckBox);
	KSDomainCheckBox();
	
private:
	BOOL m_bSelect;
	BOOL m_bDrawFlag;
	BOOL m_bBackGround;
	//	BOOL m_bEnableField;		// û�б��棬������ֻ����ReadOnly ״̬�´β���Ч
	
public:
//	KSDomainCheckBox(const CWpsDoc* pDoc, const CRect& rect);
	//	�࿽��:
public:
	KSDomainCheckBox(const KSDomainCheckBox* obj);
	//  ������:
public:	
	virtual ~KSDomainCheckBox();
	
public:	
	virtual void Serialize_01( KSArchive& ar );
};

#endif // !if defined _KSDOMAINCHECKBOX_H_
