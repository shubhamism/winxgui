/** @file wppreader.cpp
 *  @brief
 *
 *  shaogaoyang@kingsoft.net, 05 Apr 2005
 *  Time-stamp: <2005-04-06 10:24:31 shaogaoyang>
 */

#include "stdafx.h"

#include <l10n.h>
#include <pres/wppdoc.h>
#include <export/wppexport.h>
#include <kso/io/contentsource.h>
#include <kso/io/fmtcheck.h>
#include <kso/io/component.h>

#pragma linklib("pptr")

STDAPI _wpp_CreateSourceEx(IKFilterEventNotify*, IStorage*, IKContentSource**);

class KWppReader :
	public IKContentSource,
	public IKFilterMediaInit
{
private:
	IKContentSource* m_pSrc;
	IKFilterEventNotify* m_pNotify;

public:
	KWppReader() : m_pSrc(NULL), m_pNotify(NULL)
	{
	}
	~KWppReader()
	{
		KS_RELEASE(m_pSrc);
		KS_RELEASE(m_pNotify);
	}

	void SetNotify(IKFilterEventNotify* pNotify)
	{
		m_pNotify = pNotify;
		if (m_pNotify)
			m_pNotify->AddRef();
	}

public:
	// IKFilterMediaInit

	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		if (m_pSrc != NULL)
			return E_ACCESSDENIED;

		HRESULT hr = S_OK;
		ks_stdptr<ILockBytes> spLB;
		switch(pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			hr = XCreateILockBytesOnHGlobal(NULL, TRUE, &spLB);
			KS_CHECK(hr);
			{
				ks_stdptr<IStorage> spStg;
				hr = StgCreateDocfileOnILockBytes(
					spLB, STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 0, &spStg);
				KS_CHECK(hr);

				hr = WppExportDoc(pMedium->lpszFileName, m_pNotify, spStg);
				KS_CHECK(hr);

				hr = _wpp_CreateSourceEx(m_pNotify, spStg, &m_pSrc);
				KS_CHECK(hr);
			}
			return S_OK;
		default:
			return E_INVALIDARG;
		}
KS_EXIT:
		return hr;
	}

public:
	// IKContentSource

	/*
	@fn Transfer
	@brief
		��������Դ���������ݣ���һ�����ݽ�����(IKContentHandler)�С�
	@arg [in] pHandler
		�ṩ�����ݽ�������ָ�롣���ڽ��ܴ�������ݡ�
	@return
		���ܵķ���ֵ�У�
		@val S_OK
			����ɹ���
		@val E_ACCESSDENIED
			����û��׼���á�
		@val �κ���������ֵ
			�κ���IKContentHandler���صĴ���ֵ��
	*/
	STDMETHODIMP Transfer(
		IN IKContentHandler* pAcc)
	{
		if (m_pSrc == NULL)
			return E_ACCESSDENIED;

		return m_pSrc->Transfer(pAcc);
	}

	/*
	@fn Close
	@brief
		�رո�����Դ���˺��������Transfer������E_ACCESSDENIED��
	*/
	STDMETHODIMP Close()
	{
		if (m_pSrc)
		{
			m_pSrc->Release();
			m_pSrc = NULL;
		}
		return S_OK;
	}

	BEGIN_QUERYINTERFACE(IKContentSource)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_CLASS(KWppReader)
	DECLARE_COUNT(KWppReader)
};

// -------------------------------------------------------------------------

int WPP_IdentifyFileType(LPCTSTR lpszFileName, LPTSTR lParam);

inline
STDMETHODIMP FormatCorrectWPP(IStorage* pStg)
{
	const WCHAR WPSDoc[] = { 'W', 'P', 'P', 'D', 'o', 'c', '\0' };
	IStream* pStrm = NULL;
	HRESULT hr = pStg->OpenStream(WPSDoc, 0, STGM_G_READ, 0, &pStrm);
	if (pStrm)
		pStrm->Release();
	return hr;
}

inline
STDMETHODIMP FormatCorrectWPP(IStream* pStrm)
{
	ASSERT(0);
	return E_NOTIMPL;
}

inline
STDMETHODIMP FormatCorrectWPP(LPCWSTR File)
{
	USES_CONVERSION;
	CWPPDoc::FileType fileType;
	fileType = (CWPPDoc::FileType)WPP_IdentifyFileType(W2A(File), NULL);
	if (fileType == CWPPDoc::enWPP_WPPFile
		|| fileType == CWPPDoc::enWPP_DPTFile)
	{
		return S_OK;
	}
	else
	{
		return E_UNEXPECTED;
	}
}

// -------------------------------------------------------------------------

EXPORTAPI filterpluginInitialize(IN void* pReserved)
{
	return WppInitialize();
}

EXPORTAPI filterpluginTerminate()
{
	WppTerminate();
	return S_OK;
}

EXPORTAPI filterpluginRegister(IN IKFilterPluginRegister* pReg)
{
	return pReg->Register(
		_IoFormat_WPP,
		_IoName_WPP,
		FILTER_IMPORT,
		FILTER_TYMED_FILE,
		_IoExt_WPP,
		_IoDesc_WPPFile
		);
}

EXPORTAPI filterpluginFormatCorrect(IN LPCFILTERMEDIUM pMedium, IN long lFormat)
{
	switch (lFormat)
	{
	case _IoFormat_WPP:
		{
			switch (pMedium->tymed)
			{
			case FILTER_TYMED_FILE:
				return FormatCorrectWPP(pMedium->lpszFileName);
			case FILTER_TYMED_ISTORAGE:
				return FormatCorrectWPP(pMedium->pstg);
			default:
				return E_UNEXPECTED;
			}
		}
	default:
		return E_UNEXPECTED;
	}
}

EXPORTAPI filterpluginImportCreate(
	IN long lFormat, IN IKFilterEventNotify* pNotify, OUT IKFilterMediaInit** ppv)
{
	if (lFormat == _IoFormat_WPP)
	{
		KWppReader* pRead = new KCountObject<KWppReader>;
		pRead->SetNotify(pNotify);
		*ppv = pRead;
		return S_OK;
	}
	return E_UNEXPECTED;
}


