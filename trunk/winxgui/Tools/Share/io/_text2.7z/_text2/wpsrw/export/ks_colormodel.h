/* -------------------------------------------------------------------------
//	�ļ���		��	ks_colormodel.h
//	������		��	������
//	����ʱ��	��	2002-5-3 13:34:42
//	��������	��	��ɫģ��(������ɫ������ʵ����ɫ����)
//
//-----------------------------------------------------------------------*/
#ifndef __KS_COLORMODEL_H__
#define __KS_COLORMODEL_H__

#ifndef interface 
	#define interface struct
#endif

#ifndef _DWORD_DEFINED
	#define _DWORD_DEFINED
	typedef unsigned long DWORD;
#endif //_DWORD_DEFINED

#ifndef _COLORREF_DEFINED
	#define _COLORREF_DEFINED
	typedef DWORD COLORREF;//color true value not index: 0x00bbggrr
#endif //_COLORREF_DEFINED


typedef DWORD				KCOLORINDEX;
typedef KCOLORINDEX*		LPKCOLORINDEX;

#define KCOLORINDEX_INVALIDVALUE	(KCOLORINDEX)	-1//0xffffffff

//The presence of either of the last two flags indicates that the low three 
//bytes are an index into a predefined array of colors. 
//For SchemeIndex colors, the host application provides the translation to 
//RGB colors when necessary (PowerPoint and Excel both use this)
typedef enum
{
	//ksocolorFlagPaletteIndex,		// PALETTEINDEX macro
	//ksocolorFlagPaletteRGB,		// PALETTERGB macro
	//ksocolorFlagSystemRGB,		// KSOSYSTEMRGB
	ksocolorFlagSchemeIndex = 0xf0,	// KSOSCHEMECOLOR
	ksocolorFlagSysIndex,			// KSOSYSCOLOR
}KSOCOLORINDEX;

//SysIndex colors are indices into colors tracked by KDrawing itself
typedef enum
{
	ksosyscolorButtonFace,          // COLOR_BTNFACE
	ksosyscolorWindowText,          // COLOR_WINDOWTEXT
	ksosyscolorMenu,                // COLOR_MENU
	ksosyscolorHighlight,           // COLOR_HIGHLIGHT
	ksosyscolorHighlightText,       // COLOR_HIGHLIGHTTEXT
	ksosyscolorCaptionText,         // COLOR_CAPTIONTEXT
	ksosyscolorActiveCaption,       // COLOR_ACTIVECAPTION
	ksosyscolorButtonHighlight,     // COLOR_BTNHIGHLIGHT
	ksosyscolorButtonShadow,        // COLOR_BTNSHADOW
	ksosyscolorButtonText,          // COLOR_BTNTEXT
	ksosyscolorGrayText,            // COLOR_GRAYTEXT
	ksosyscolorInactiveCaption,     // COLOR_INACTIVECAPTION
	ksosyscolorInactiveCaptionText, // COLOR_INACTIVECAPTIONTEXT
	ksosyscolorInfoBackground,      // COLOR_INFOBK
	ksosyscolorInfoText,            // COLOR_INFOTEXT
	ksosyscolorMenuText,            // COLOR_MENUTEXT
	ksosyscolorScrollbar,           // COLOR_SCROLLBAR
	ksosyscolorWindow,              // COLOR_WINDOW
	ksosyscolorWindowFrame,         // COLOR_WINDOWFRAME
	ksosyscolor3DLight,             // COLOR_3DLIGHT
	ksosyscolorMax,                 // Count of system colors
	
	ksocolorFillColor =0xF0,  // Use the fillColor property
	ksocolorLineOrFillColor,  // Use the line color only if there is a line
	ksocolorLineColor,        // Use the lineColor property
	ksocolorShadowColor,      // Use the shadow color
	ksocolorThis,             // Use this color (only valid as described below)
	ksocolorFillBackColor,    // Use the fillBackColor property
	ksocolorLineBackColor,    // Use the lineBackColor property
	ksocolorFillThenLine,     // Use the fillColor unless no fill and line
	ksocolorIndexMask =0xFF,  // Extract the color index

	ksocolorProcessMask      =0xFFFF00, // All the processing bits
	ksocolorModificationMask =0x0F00,   // Just the function
	ksocolorModFlagMask      =0xF000,   // Just the additional flags
	ksocolorDarken           =0x0100,   // Darken color by parameter/255
	ksocolorLighten          =0x0200,   // Lighten color by parameter/255
	ksocolorAdd              =0x0300,   // Add grey level RGB(param,param,param)
	ksocolorSubtract         =0x0400,   // Subtract grey level RGB(p,p,p)
	ksocolorReverseSubtract  =0x0500,   // Subtract from grey level RGB(p,p,p)
	/* In the following "black" means maximum component value, white minimum.
	The operation is per component, to guarantee white combine with
	ksocolorGray */
	ksocolorBlackWhite       =0x0600,   // Black if < uParam, else white (>=)
	ksocolorInvert           =0x2000,   // Invert color (at the *end*)
	ksocolorInvert128        =0x4000,   // Invert by toggling the top bit
	ksocolorGray             =0x8000,   // Make the color gray (before the above!)
	ksocolorBParamMask       =0xFF0000, // Parameter used as above
	ksocolorBParamShift =16,            // To extract the parameter value
}
KSOSYSCOLORINDEX;

/*struct KCOLORINDEX	// color index value, maybe is not color true value
{
	LONG index;
	 value;
};
*/

//-------------------------������ɫ�ĸ�ʽ���� start-------------------------
/*
-------------------------------------------------------------------------------
http://msdn.microsoft.com/library/default.asp?url=/workshop/author/vml/types.asp
--------------------------------------------------------------------------------
��ɫ����ڶ���ɫ�ĸ�ʽ��
0xaaddllvv��
	aa -- ��ɫ������ (0x10)
	dd -- ƫ����(0x0 -- 0xff)
	ll -- ������ʽ(pΪƫ��������dd)��
		1.Darken(p)		c2 = c1 * p / 255
		2.Lighten(p)	c2 = 255 - (255 -c1) * p /255
		3.Add(p)		c2 = c1 + p
		4.Subtract(p)	c2 = c1 - p
		5.ReverseSub(p)	c2 = p - c1
		6.BlackWhite(p)	c2 = c1 < p ? 0 : 255
	vv -- ����ֵ

�����ϱ���Ϊ��[0 -- 255 -- 0]
	ƫ�������ֵ�������м䣬������˥������ʽֵ�����ҷֱ�ΪDraken��Lighten.
*/

//��ɫ����ڶ���ɫֵ��λ���
#define defCOLORMODELFLAG_ONECOLORSHADE	0x10
enum ONECOLORSHADE_MODE
{
	oneColorShadeMode_Darken		= 1,
	oneColorShadeMode_Lighten		= 2,
	oneColorShadeMode_Add			= 3,
	oneColorShadeMode_Subtract		= 4,
	oneColorShadeMode_ReverseSub	= 5,
	oneColorShadeMode_BlackWhite	= 6
};
//-------------------------������ɫ�ĸ�ʽ���� end  -------------------------


interface IColorScheme;

class KColorModel
{
	KColorModel(){}
	~KColorModel(){}
	
public:
	static LONG GetFlagIndex(const KCOLORINDEX& indexColor);
	static LONG GetColorIndex(const KCOLORINDEX& indexColor);
	static BOOL SetFlagIndex(KCOLORINDEX& indexColor, const LONG nFlagIndex);
	static BOOL SetColorIndex(KCOLORINDEX& indexColor, const LONG nColorIndex);
	static BOOL CreateKCOLORINDEX(KCOLORINDEX& indexColor,
						const LONG nFlagIndex, const LONG nColorIndex);
			
	static LONG R(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static LONG G(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static LONG B(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static BOOL GetRGB(const KCOLORINDEX& indexColor, 
							IColorScheme* pICS, LONG& r, LONG& g, LONG& b);

	static LONG H(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static LONG S(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static LONG V(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static BOOL GetHSV(const KCOLORINDEX& indexColor, 
							IColorScheme* pICS, LONG& h, LONG& s, LONG& v);

	//judge: whether direct get color true value(COLORREF) by the KCOLORINDEX
	static BOOL CanDirectGetCOLOR(const KCOLORINDEX& indexColor);
	static BOOL RGBToColor(KCOLORINDEX& indexColor, 
								const LONG r, const LONG g, const LONG b);
	static BOOL HSVToColor(KCOLORINDEX& indexColor,
								const LONG h, const LONG s, const LONG v);
	static COLORREF IndexToRef(const KCOLORINDEX& indexColor, IColorScheme* pICS);
	static KCOLORINDEX RefToIndex(const COLORREF& color);

	/////////////////////////////////////////////////////////
	static COLORREF CalcSecondColorForOneShade(const KCOLORINDEX& indexFirst, 
												 const KCOLORINDEX& indexSecond,
												 IColorScheme* pICS);
	static KCOLORINDEX CreateSecondColorForOneShade(LONG nLightValue);	
};


///////////////////////////////////////////////////////////////////////////////
//ColorScheme
/*
#define D_CS_COLORSUM	8	//��ɫ������������ɫ��

enum E_COLORSCHEME
{
	enCSBg = 0,				//����
	enCSLine = 1,
	enCSText = enCSLine,	//�ı��������
	enCSShadow = 2,			//��Ӱ
	enCSTitletext = 3,		//�����ı�
	enCSFill = 4,			//���
	enCSAccent = 5,			//ǿ������
	enCSMark = 6,			//���
	enCSHyperLink = 7,		//��������
};
*/

////////////////////
//colorscheme for wpp, wps or et...
//wpp colorscheme color count: 8
//wps colorscheme color count: 37(maybe)

//interface IColorScheme : public IUnknown
struct IColorScheme : public IUnknown
{
	STDMETHOD (CreateCS)(LONG nCount) = 0;	
	STDMETHOD (GetColorCount)(LONG& nCount) = 0;
	
	STDMETHOD (GetColor)(const LONG index, COLORREF& color) = 0;	
	STDMETHOD (SetColor)(const LONG index, const COLORREF& color) = 0;

	STDMETHOD (SetColors)(IColorScheme* pICSSrc,
								LONG nToStart = 0, LONG nToCount = -1) = 0;
	
	STDMETHOD (GetColors)(COLORREF* pColors, const LONG nColorCount) = 0;
	STDMETHOD (SetColors)(const COLORREF* pColors, const LONG nColorCount) = 0;
	
	STDMETHOD (Clone)(IColorScheme** ppICSDest) = 0;
	
	// == ->S_OK, != ->S_FALSE
	STDMETHOD (Compare)(IColorScheme* pICSSrc) = 0;
};

///////////////////////////////////////////////////////////////////////////////
HRESULT gCoCreateColorScheme(LONG nColorCount, IColorScheme** ppICS);

#endif /* __KS_COLORMODEL_H__ */
