/* -------------------------------------------------------------------------
//	�ļ���		��	MediaKits/mds_lock.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-14 14:52:00
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __MEDIAKITS_MDS_LOCK_H__
#define __MEDIAKITS_MDS_LOCK_H__

#ifndef __MEDIA_MEDIADATA_H__
#include "media/mediadata.h"
#endif

// -------------------------------------------------------------------------

inline STDMETHODIMP_(BOOL) IsHGblLocked(HGBL hGbl)
{
	XGlobalLock(hGbl);
	return XGlobalUnlock(hGbl);
}

// -------------------------------------------------------------------------

class KMediaDataLockable : public IKMediaDataSource
{
protected:
	HGBL	_hGbl;
	
public:
	KMediaDataLockable()
	{
		_hGbl = NULL;
	}
	~KMediaDataLockable()
	{
		ASSERT(!IsHGblLocked(_hGbl));
		ClearCache();
	}
	STDMETHODIMP ClearCache()
	{
		if (_hGbl && !IsHGblLocked(_hGbl))
		{
			XGlobalFree(_hGbl);
			_hGbl = NULL;
		}
		return S_OK;
	}
	STDMETHODIMP Unlock()
	{
		if (_hGbl)
		{
			XGlobalUnlock(_hGbl);
			return S_OK;
		}
		REPORT("Unlock����ʧ�ܣ�_hGbl = NULL");
		return E_ACCESSDENIED;
	}
	
	DECLARE_COMCLASS(KMediaDataLockable, IKMediaDataSource)
};

// -------------------------------------------------------------------------

#endif /* __MEDIAKITS_MDS_LOCK_H__ */
