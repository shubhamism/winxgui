/* -------------------------------------------------------------------------
//	�ļ���		��	wppexport.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 15:41:39
//	��������	��
//
// -----------------------------------------------------------------------*/
#ifndef __WPPEXPORT_H__
#define __WPPEXPORT_H__

#ifndef __MSO_IO_POWERPOINT_WRITER_H__
//#include <mso/io/powerpoint/writer.h>
#endif

#include "pres/ex_wppdoc.h"

class CWPPDoc;

// -------------------------------------------------------------------------

STDMETHODIMP WppExportDoc(IN const CWPPDoc* pDoc, IN IStorage* pPPTRootStg);
STDMETHODIMP WppExportDoc(LPCWSTR szWppFile, IKFilterEventNotify* pNotify, IStorage* pPPTRootStg);

// -------------------------------------------------------------------------

#endif /* __WPPEXPORT_H__ */
