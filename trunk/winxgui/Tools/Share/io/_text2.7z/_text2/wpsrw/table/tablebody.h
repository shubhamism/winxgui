#ifndef __TBLBODY_H
#define __TBLBODY_H

class CTableBody: public CFrameTable
{
protected:
	DECLARE_SERIAL(CTableBody);
public:
	CTableBody();
	~CTableBody();
	virtual int	 CheckObjType() { return FRMTableBody; }
};


////////////////////////////////////////////////////////////////////////
// specialized Table Body objects

#endif // __TBLBODY_H
