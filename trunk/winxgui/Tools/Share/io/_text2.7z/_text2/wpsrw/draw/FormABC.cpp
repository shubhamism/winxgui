/////////////////////////////////////////////////////////////////////////////
//
// FormCell.cpp - implementation for CFormCell objects
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h" 

#include <imm.h>

#ifndef _WPSREADER
//#include "ResID_Cmd.h"
//#include "ResID_String.h"
#endif

#ifndef __CTRLCODE_H
//#include "ctrlcode.h"
#endif

//#include "MainFrm.h"

#ifndef __WPSOBJ_H
#include "wpsobj.h"
#endif

//#include "TextObjRender.h"	

#if !defined(AFX_KSTEXTSTRING_H_INCLUDED_)
//#include "KSTextString.h"
#endif

#ifndef __FORMULAE_H
#include "formulae.h"
#endif

#ifndef __FORMCELL_H
#include "formcell.h"
#endif

#ifndef __FORMABC_H
#include "formabc.h"
#endif

#ifndef __WPSVIEW_H
//#include "wpsview.h"
#endif

#ifndef __WPSDOC_H
//#include "wpsdoc.h"
#endif

#ifndef __OBJTOOL_H
//#include "objtool.h"
#endif

//WPP_CODE
//#include "WPPCommon.h"	//Ϊ��ʾ������Ӧ��ɫ����(WPP)
//#include "WPPDoc.h"		//for WPP

//extern CDSPRow	s_dspRow;		//	��ǰ��Ҫ��ʾ���ִ���, ���ڵ������֡���ʽ����
//extern BOOL		g_bInsert;		// ɾ��/��д״̬
//void AdjustPosition(CWpsView*, CWPSObj*, int&, int&);
//int GetCurCharWidth0_01(int, BYTE=0);
//int GetCurCharWidth(int, BYTE=0);
//int CreateDSPRow(CWpsView*, CWPSObj*);
//void TextStringToString(CString&, KSTextString&);
//CWPSObj* GetPrevObj(CWPSObj*, CObList*, BOOL);
//CWPSObj* GetNextObj(CWPSObj*, CObList*, BOOL);
//BOOL OnEditClear(CWpsView*);
//extern void ChangeFS(int nFS[4], int);
//extern void RefreshFS();
//extern void SaveFS();
//extern int FS[];
//extern int nFormulaCharMrg;
//
//#ifndef _GWSREADER
//typedef void (WINAPI* CONVPROCW)(LPWORD, DWORD);
//typedef void (WINAPI* CONVPROCDW)(LPDWORD, DWORD);
//extern CONVPROCW	g_lpConvProcW;		// ��������ʱ�Ƿ���Ҫת�����루���ֽڣ�
//extern CONVPROCDW	g_lpConvProcDW;		// ��������ʱ�Ƿ���Ҫת�����루���ֽڣ�
//#endif	// #ifndef _GWSREADER

/////////////////////////////////////////////////////////////////////////////
//	CFormABC

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//IMPLEMENT_SERIAL(CFormABC, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormABC, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormABC::CFormABC()
{
//	m_pTextObjSite = NULL;
	m_nHeadPos = -1;
	m_nCurPos = 0;
}

CFormABC::~CFormABC()
{
//	ASSERT(this);
//	if (m_pTextObjSite)
//	{
//		ASSERT_VALID(m_pTextObjSite);
//		delete m_pTextObjSite;
//	}
	DeleteContent();
}

void CFormABC::DeleteContent()
{
}      

void CFormABC::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormABC::Serialize_98(KSArchive& ar)
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		//royhoo 20041230 ԭ���˴�ʹ��KSTextString
		//�洢ʱ����ʹ����ͨCString
		ar << m_string;
		ar.Write(&m_Italic, sizeof(BYTE));
		ar.Write(&m_nWeight, sizeof(int));
		ar.Write(&m_FormCharColor, sizeof(COLORREF));
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		//royhoo 20041230 ԭ���˴�ʹ��KSTextString
		//ȡ��ʱ����ʹ����ͨCString
		// << Modify by rainfall
		CString strTemp;							// for GB18030
		strTemp.Empty();
		ar >> strTemp;

		m_string = strTemp;
		// >> Modify by rainfall
		// ���������2003�޸ĺ�����ӣ�������2002�Ĵ��룬��һ���ļ�����������
		// �ĳ�2002���Ǻõ�
//		ar >> m_string;

		/*LPCTSTR lpszOld = (LPCTSTR)strTemp;
		for (int nStrLen = 0; lpszOld[nStrLen]; nStrLen += 2);
		nStrLen = nStrLen / 2;				//	˫�ֽ��ַ���

		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		VERIFY(nStrLen == KCP_WordToTextWord(lptwBuffer,
				(LPWORD)(LPCTSTR)strTemp, nStrLen));
		m_string.Insert(0, lptwBuffer, nStrLen);
		delete lptwBuffer;		*/
/*
#ifndef _GWSREADER
		if (g_lpConvProcW)
		{	
			int nLen = m_string.GetTextSize();
			g_lpConvProcW((WORD*)m_string.GetBuffer(nLen), nLen/2);	// ��Ҫʱת����������
			m_string.ReleaseBuffer(nLen); //��Ϊ��˫�ֽڴ��м������\0�ַ�,�����ͷ�ʱ��ָ������
		}
#endif	// #ifndef _GWSREADER*/
		int nVersion = ar.GetObjectSchema();
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
				{	int nTemp;
					ar.Read(&nTemp, sizeof(int));
				}
			break;
			case 1:
			break;
		}
//		ar.Read(&m_nCharMrg, sizeof(int));
		ar.Read(&m_Italic, sizeof(BYTE));
		ar.Read(&m_nWeight, sizeof(int));
		ar.Read(&m_FormCharColor, sizeof(COLORREF));
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormABC::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_string;
		ar.Write(&m_Italic, sizeof(BYTE));
		ar.Write(&m_nWeight, sizeof(int));
		ar.Write(&m_FormCharColor, sizeof(COLORREF));
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_string;
/*
#ifndef _GWSREADER
		if (g_lpConvProcW)
		{	
			int nLen = m_string.GetTextSize();
			g_lpConvProcW((WORD*)m_string.GetBuffer(nLen), nLen/2);	// ��Ҫʱת����������
			m_string.ReleaseBuffer(nLen); //��Ϊ��˫�ֽڴ��м������\0�ַ�,�����ͷ�ʱ��ָ������
		}
#endif	// #ifndef _GWSREADER*/
		int nVersion = ar.GetObjectSchema();
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
				{	int nTemp;
					ar.Read(&nTemp, sizeof(int));
				}
			break;
			case 1:
			break;
		}
//		ar.Read(&m_nCharMrg, sizeof(int));
		ar.Read(&m_Italic, sizeof(BYTE));
		ar.Read(&m_nWeight, sizeof(int));
		ar.Read(&m_FormCharColor, sizeof(COLORREF));
	}
	CWPSObj::SerializeObjType(ar);
}

#ifndef _WPSREADER
/*******************************************************
// FUNCTION	: CFormABC::Draw
// PURPOSE	: 
// RETURN	: void 
// ARGUMENT	: CDC* pDC
// COMMENTS	: ͼ�ķ��ſ�
*******************************************************/

#endif //_WPSREADER

/*
#ifndef _WPSREADER
int GetStringWidth(const CString& string);
int CFormABC::GetWidthDeltaOnDelChar(const CString& str)
{
	int szW = 0;
	int dw = 0;
	ASSERT (m_string != STR0);
	szW = GetStringWidth(str);
	dw = max(0,s_dspRow.m_nRowW-szW+5)/10 - m_rect.Width();
	return dw;
}
#endif //_WPSREADE*/

/*
#ifndef _WPSREADER
int CFormABC::GetWidthDeltaOnAddChar(const CString& str)
{
	int szW = GetStringWidth(str);
	int dw = 0;
	if (m_string == STR0)
		dw = (szW+5)/10 - m_rect.Width();	
	else
		dw = max(0,s_dspRow.m_nRowW+szW+5)/10 - m_rect.Width();
	return dw;
}
#endif //_WPSREADER
*/


#ifndef _WPSREADER

#endif //_WPSREADER


#ifndef _WPSREADER
extern void CellToForm(CWPSObj* pCurObj, CWPSObj* pObj, CPoint& pntCrt);
extern BOOL IsKeyDown (int vKey);
#endif //_WPSREADER

#ifndef _WPSREADER

#endif //_WPSREADER


/*
#ifndef _WPSREADER
void CFormABC::ReCreateDSPRow(CWpsView* pView)
{
	//	�ؽ�������ʾ���ִ��� s_dspRow; �ֲ���̬
	CreateDSPRow(pView, this);
	AutoChangeObjW(pView);
	pView->SetPreferredWPM (CWpsView::wpm_membmp);
	pView->InvalObj(this);
}
#endif	// _WPSREADER*/

/*
#ifndef _WPSREADER
void CFormABC::ResetObj(CWpsView* pView, BOOL /*=TRUE*)
{
	//	�ؽ�����ǰ��ʾ��(�����Զ����)
	ReCreateDSPRow(pView);
	//	���� nCurSZPos �������λ��, ���ػ���
	pView->RebuildCaret(NULL);
}
#endif	// _WPSREADER
*/
/*
#ifndef _WPSREADER
//�Զ��ſ�
void CFormABC::AutoChangeObjW(CWpsView* pView)
{
	if (m_rect.Width()*10 < s_dspRow.m_nRowW)//�Զ��ſ�
	{	m_rect.right = m_rect.left+(s_dspRow.m_nRowW+5)/10;//��λ(0.01mm->0.1mm)
		CreateDSPRow(pView, this);		//	����������ؽ���ʾ��
	}
}
#endif	// _WPSREADER
*/

#ifndef _WPSREADER

#endif	// _WPSREADER

#ifndef _WPSREADER

#endif	// _WPSREADER

#ifndef _WPSREADER

#endif	// _WPSREADER

/*
extern int g_CharWidthTbl[LASTCHAREX - FIRSTCHAR + 1];//��λ(0.01mm)
extern int g_ChnCharWidth;          // ����������ȵ�λ(0.01mm)*/
void FormToCell(CWPSObj* pCurObj, CWPSObj* pObj, CPoint& pntCur);

/////////////////////////////////////////////////////////////////////////////
//	CFormSymbol

//IMPLEMENT_SERIAL(CFormSymbol, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormSymbol, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormSymbol::CFormSymbol()
{                      
}

CFormSymbol::~CFormSymbol()
{
	ASSERT(this);
}



void CFormSymbol::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormSymbol::Serialize_98(KSArchive& ar)
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_wSymbol;
		ar.Write(&m_Italic, sizeof(BYTE));
		ar.Write(&m_nWeight, sizeof(int));
		ar.Write(&m_FormCharColor, sizeof(COLORREF));
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_wSymbol;
		ar.Read(&m_Italic, sizeof(BYTE));
		ar.Read(&m_nWeight, sizeof(int));
		ar.Read(&m_FormCharColor, sizeof(COLORREF));
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormSymbol::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_wSymbol;
		ar.Write(&m_Italic, sizeof(BYTE));
		ar.Write(&m_nWeight, sizeof(int));
		ar.Write(&m_FormCharColor, sizeof(COLORREF));
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_wSymbol;
		ar.Read(&m_Italic, sizeof(BYTE));
		ar.Read(&m_nWeight, sizeof(int));
		ar.Read(&m_FormCharColor, sizeof(COLORREF));
	}
	CWPSObj::SerializeObjType(ar);
}
