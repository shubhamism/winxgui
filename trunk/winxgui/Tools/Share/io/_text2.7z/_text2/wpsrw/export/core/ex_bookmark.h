/* -------------------------------------------------------------------------
//	�ļ���		��	ex_bookmark.h
//	������		��	����
//	����ʱ��	��	2004-10-25 3:37:28 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_BOOKMARK_H__
#define __EX_BOOKMARK_H__

#ifndef __MSO_IO_WORD_WRITER_H__
#include <mso/io/word/writer.h>
#endif

#ifndef __BOOKMARK_H__
#include <core/bookmark.h>
#endif

// -------------------------------------------------------------------------

class CCtrlCode_HotRef;
class KWpsExport;
class KBookmarkExport
{
public:
	KBookmarkExport()
	{
		ClearBookmarkID();
	}
	~KBookmarkExport() {}

protected:
	int m_nBookmarkID;	// ��ǩID.
	CP m_cpBegin;		// ��ǩ����ʼλ�������λ��
	CP m_cpEnd;
	KWpsExport* m_pExport;

protected:
	void SetBookmarkID(int nID)
	{
		ASSERT(nID > 0);
		m_nBookmarkID = nID;
	}
	void ClearBookmarkID()
	{
		m_nBookmarkID = INVALID_BOOKMARKID;
		m_cpBegin = 0;
		m_cpEnd = 0;
	}
	STDMETHODIMP BMProc_1(int nBMID, CP cpBegin, CP cpEnd);
	STDMETHODIMP BMProc_2(int nBMID, CP cpBegin, CP cpEnd);
	STDMETHODIMP BMProc_3(int nBMID, CP cpBegin, CP cpEnd);
	STDMETHODIMP BMProc_Convert();

public:
	STDMETHODIMP Convert(KWpsExport& export, int nBMID, CP cpBegin, CP cpEnd);
};

// -------------------------------------------------------------------------

#endif /* __EX_BOOKMARK_H__ */
