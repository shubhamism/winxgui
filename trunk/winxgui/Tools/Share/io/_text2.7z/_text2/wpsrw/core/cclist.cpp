/* -------------------------------------------------------------------------
//	�ļ���		��	cclist.cpp
//	������		��	���
//	����ʱ��	��	2002-5-28 15:48:19
//	��������	��	
//
//-----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ctrlcode_sprm.h"
#include "cclist.h"
#include <stl/map.h>
#include "autonum.h"
#include "autonum_group.h"

#pragma warning(disable:4786)
using namespace std;
using namespace sprmCtrlAid;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// δ������CTRLCODEID
//		SETGWSREF	SETFONT			SETALIGNMENT	SETWCHARSET
//		SETCPXFONT	SETCPXFONTSIZE	SETCPXITALIC	SETCPXBOLD
//		SETINDENT
// ����δ������CTRLCODE
//		DISPLAY		OBLIQUELINE

// LABEL (Bookmark) ֻ������һ��nID��Ա�Ĵ��档
// ��ΪpszString�Ķ�ȡ�е��߼����������ͷ��ַ�����

// -------------------------------------------------------------------------
// Predeclaration of ConCreators

class _CECC_Alignment: public CCtrlCode_Alignment
{
public:
	static CCtrlCode* _CoCreate_Alignment(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Alignment(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_AspectX: public CCtrlCode_AspectX
{
public:
	static CCtrlCode* _CoCreate_AspectX(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_AspectX(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_AutoNumber: public CCtrlCode_AutoNumber
{
public:
	static CCtrlCode* _CoCreate_AutoNumber(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_AutoNumber(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_BGVein: public CCtrlCode_BGVein
{
public:
	static CCtrlCode* _CoCreate_BGVein(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_BGVein(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Bold: public CCtrlCode_Bold
{
public:
	static CCtrlCode* _CoCreate_Bold(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Bold(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_CharSet: public CCtrlCode_CharSet
{
public:
	static CCtrlCode* _CoCreate_CharSet(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_CharSet(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Color: public CCtrlCode_Color
{
public:
	static CCtrlCode* _CoCreate_Color(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Color(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_DISPLAY: public CCtrlCode_DISPLAY
{
public:
	static CCtrlCode* _CoCreate_DISPLAY(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_DISPLAY(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Font: public CCtrlCode_Font
{
public:
	static CCtrlCode* _CoCreate_Font(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Font(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_HotRef: public CCtrlCode_HotRef
{
public:
	static CCtrlCode* _CoCreate_HotRef(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_HotRef(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_HSS: public CCtrlCode_HSS
{
public:
	static CCtrlCode* _CoCreate_HSS(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_HSS(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Italic: public CCtrlCode_Italic
{
public:
	static CCtrlCode* _CoCreate_Italic(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Italic(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Label: public CCtrlCode_Label
{
public:
	static CCtrlCode* _CoCreate_Label(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Label(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_LineMargin: public CCtrlCode_LineMargin
{
public:
	static CCtrlCode* _CoCreate_LineMargin(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_LineMargin(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_ObliqueLine: public CCtrlCode_ObliqueLine
{
public:
	static CCtrlCode* _CoCreate_ObliqueLine(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_ObliqueLine(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_OutRect: public CCtrlCode_OutRect
{
public:
	static CCtrlCode* _CoCreate_OutRect(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_OutRect(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_ParaFrame: public CCtrlCode_ParaFrame
{
public:
	static CCtrlCode* _CoCreate_ParaFrame(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_ParaFrame(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_ParaIndent: public CCtrlCode_ParaIndent
{
public:
	static CCtrlCode* _CoCreate_ParaIndent(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_ParaIndent(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_ParaMargin: public CCtrlCode_ParaMargin
{
public:
	static CCtrlCode* _CoCreate_ParaMargin(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_ParaMargin(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Revise: public CCtrlCode_Revise
{
public:
	static CCtrlCode* _CoCreate_Revise(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Revise(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Size: public CCtrlCode_Size
{
public:
	static CCtrlCode* _CoCreate_Size(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Size(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_SSScript: public CCtrlCode_SSScript
{
public:
	static CCtrlCode* _CoCreate_SSScript(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_SSScript(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_StrikeOut: public CCtrlCode_StrikeOut
{
public:
	static CCtrlCode* _CoCreate_StrikeOut(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_StrikeOut(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Tabs: public CCtrlCode_Tabs
{
public:
	static CCtrlCode* _CoCreate_Tabs(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Tabs(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Tracking: public CCtrlCode_Tracking
{
public:
	static CCtrlCode* _CoCreate_Tracking(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Tracking(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_UnderLine: public CCtrlCode_UnderLine
{
public:
	static CCtrlCode* _CoCreate_UnderLine(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_UnderLine(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

class _CECC_Visible: public CCtrlCode_Visible
{
public:
	static CCtrlCode* _CoCreate_Visible(WORD sprm, WORD* pData, UINT cw);
	HRESULT _CoSave_Visible(IAppendBuffer* pBuf, _CoSaveArg* pArg);
};

// ================================================================

typedef map<WORD, fpConcreate>		_CCMAP;
typedef map<CTRLCODEID, fpSave>		_ISMAP;

class _KCCManager
{
protected:
	_CCMAP		m_ccmap;
	_ISMAP		m_ismap;
public:
	_KCCManager();
protected:
	void		RegisterCocreator(WORD wSprm, fpConcreate cc);
	void		RegisterCosaver(CTRLCODEID wid, fpSave cs);
public:
	fpConcreate	GetCocreator(WORD wSprm);
	fpSave		GetCosaver(CTRLCODEID wid);
};

_KCCManager::_KCCManager()
{
	// Register the ConCreators
	RegisterCocreator(sprm_cc_ForeColor,	_CECC_Color::_CoCreate_Color);
	RegisterCosaver  (SETCOLOR,				(fpSave)_CECC_Color::_CoSave_Color);
	RegisterCocreator(sprm_ch_CharSet,		_CECC_CharSet::_CoCreate_CharSet);
	RegisterCosaver  (SETWCHARSET,			(fpSave)_CECC_CharSet::_CoSave_CharSet);
	RegisterCocreator(sprm_ch_FontNameDef,	_CECC_Font::_CoCreate_Font);
	RegisterCosaver  (SETENGFONT,			(fpSave)_CECC_Font::_CoSave_Font);
	RegisterCocreator(sprm_ch_FontNameFE,	_CECC_Font::_CoCreate_Font);
	RegisterCosaver  (SETCHNFONT,			(fpSave)_CECC_Font::_CoSave_Font);

	RegisterCocreator(sprm_ch_FontSize,		_CECC_Size::_CoCreate_Size);
	RegisterCosaver  (SETFONTSIZE,			(fpSave)_CECC_Size::_CoSave_Size);
	RegisterCocreator(sprm_ch_ActFontSize,	_CECC_Size::_CoCreate_Size);
	RegisterCosaver  (SETACTFONTSIZE,		(fpSave)_CECC_Size::_CoSave_Size);
	RegisterCocreator(sprm_ch_FontWeight,	_CECC_Bold::_CoCreate_Bold);
	RegisterCosaver	 (SETBOLD,				(fpSave)_CECC_Bold::_CoSave_Bold);
	RegisterCocreator(sprm_ch_FontItalic,	_CECC_Italic::_CoCreate_Italic);
	RegisterCosaver  (SETITALIC,			(fpSave)_CECC_Italic::_CoSave_Italic);

	RegisterCocreator(sprm_ch_UpperLine,	_CECC_UnderLine::_CoCreate_UnderLine);
	RegisterCosaver  (SETUPPERLINE,			(fpSave)_CECC_UnderLine::_CoSave_UnderLine);
	RegisterCocreator(sprm_ch_UnderLine,	_CECC_UnderLine::_CoCreate_UnderLine);
	RegisterCosaver  (SETUNDERLINE,			(fpSave)_CECC_UnderLine::_CoSave_UnderLine);
	RegisterCocreator(sprm_ch_StrikeOut,	_CECC_StrikeOut::_CoCreate_StrikeOut);
	RegisterCosaver  (SETSTRIKEOUT,			(fpSave)_CECC_StrikeOut::_CoSave_StrikeOut);
	RegisterCocreator(sprm_ch_Stress,		_CECC_UnderLine::_CoCreate_UnderLine);
	RegisterCosaver  (SETSTRESS,			(fpSave)_CECC_UnderLine::_CoSave_UnderLine);

	RegisterCocreator(sprm_ch_SSS,			_CECC_SSScript::_CoCreate_SSScript);
	RegisterCosaver  (SETSSS,				(fpSave)_CECC_SSScript::_CoSave_SSScript);
	RegisterCocreator(sprm_ch_AspectX,		_CECC_AspectX::_CoCreate_AspectX);
	RegisterCosaver  (SETASPECTX,			(fpSave)_CECC_AspectX::_CoSave_AspectX);
	RegisterCocreator(sprm_ch_Tracking,		_CECC_Tracking::_CoCreate_Tracking);
	RegisterCosaver  (SETTRACKING,			(fpSave)_CECC_Tracking::_CoSave_Tracking);
	RegisterCocreator(sprm_ch_HSS,			_CECC_HSS::_CoCreate_HSS);
	RegisterCosaver  (SETHSS,				(fpSave)_CECC_HSS::_CoSave_HSS);

	RegisterCocreator(sprm_ch_Visible,		_CECC_Visible::_CoCreate_Visible);
	RegisterCosaver	 (SETSENVISIBLE,		(fpSave)_CECC_Visible::_CoSave_Visible);
	RegisterCocreator(sprm_ch_Revise,		_CECC_Revise::_CoCreate_Revise);
	RegisterCosaver  (SETREVISE,			(fpSave)_CECC_Revise::_CoSave_Revise);
	RegisterCocreator(sprm_ch_Border,		_CECC_OutRect::_CoCreate_OutRect);
	RegisterCosaver	 (SETOUTRECT,			(fpSave)_CECC_OutRect::_CoSave_OutRect);
	RegisterCocreator(sprm_ch_Fill,			_CECC_BGVein::_CoCreate_BGVein);
	RegisterCosaver	 (SETBGVEIN,			(fpSave)_CECC_BGVein::_CoSave_BGVein);

	RegisterCocreator(sprm_ch_HyperLink,	_CECC_HotRef::_CoCreate_HotRef);
	RegisterCosaver  (SETHYPERREF,			(fpSave)_CECC_HotRef::_CoSave_HotRef);
	RegisterCocreator(sprm_ch_BookMark,		_CECC_Label::_CoCreate_Label);
	RegisterCosaver  (SETLABEL,				(fpSave)_CECC_Label::_CoSave_Label);

	RegisterCocreator(sprm_pa_LeftIndent,	_CECC_ParaIndent::_CoCreate_ParaIndent);
	RegisterCosaver  (SETLEFTINDENT,		(fpSave)_CECC_ParaIndent::_CoSave_ParaIndent);
	RegisterCocreator(sprm_pa_FirstIndent,	_CECC_ParaIndent::_CoCreate_ParaIndent);
	RegisterCosaver  (SETFIRSTINDENT,		(fpSave)_CECC_ParaIndent::_CoSave_ParaIndent);
	RegisterCocreator(sprm_pa_RightIndent,	_CECC_ParaIndent::_CoCreate_ParaIndent);
	RegisterCosaver  (SETRIGHTINDENT,		(fpSave)_CECC_ParaIndent::_CoSave_ParaIndent);

	RegisterCocreator(sprm_pa_HorzAlign,	_CECC_Alignment::_CoCreate_Alignment);
	RegisterCosaver	 (SETHALIGNMENT,		(fpSave)_CECC_Alignment::_CoSave_Alignment);
	RegisterCocreator(sprm_pa_VertAlign,	_CECC_Alignment::_CoCreate_Alignment);
	RegisterCosaver	 (SETVALIGNMENT,		(fpSave)_CECC_Alignment::_CoSave_Alignment);

	RegisterCocreator(sprm_pa_LineHeight,	_CECC_LineMargin::_CoCreate_LineMargin);
	RegisterCosaver  (SETLINEMARGIN,		(fpSave)_CECC_LineMargin::_CoSave_LineMargin);
	RegisterCocreator(sprm_pa_ParaMargin,	_CECC_ParaMargin::_CoCreate_ParaMargin);
	RegisterCosaver  (SETPARAMARGIN,		(fpSave)_CECC_ParaMargin::_CoSave_ParaMargin);
	RegisterCocreator(sprm_pa_PostPMargin,	_CECC_ParaMargin::_CoCreate_ParaMargin);
	RegisterCosaver  (SETAFPAMARGIN,		(fpSave)_CECC_ParaMargin::_CoSave_ParaMargin);

	RegisterCocreator(sprm_pa_TabStops,		_CECC_Tabs::_CoCreate_Tabs);
	RegisterCosaver  (SETTABS,				(fpSave)_CECC_Tabs::_CoSave_Tabs);
	RegisterCocreator(sprm_pa_AutoNumber,	_CECC_AutoNumber::_CoCreate_AutoNumber);
	RegisterCosaver  (SETAUTONUMBER,		(fpSave)_CECC_AutoNumber::_CoSave_AutoNumber);
	RegisterCocreator(sprm_pa_Border,		_CECC_ParaFrame::_CoCreate_ParaFrame);
	RegisterCosaver  (SETPARAFRAME,			(fpSave)_CECC_ParaFrame::_CoSave_ParaFrame);

	// û�����ģ�_CoCreate_DISPLAY _CoCreate_ObliqueLine
}

void _KCCManager::RegisterCocreator(WORD wSprm, fpConcreate cc)
{
	m_ccmap.insert(_CCMAP::value_type(wSprm, cc));
}

void _KCCManager::RegisterCosaver(CTRLCODEID wid, fpSave cs)
{
	m_ismap.insert(_ISMAP::value_type(wid, cs));
}

fpConcreate _KCCManager::GetCocreator(WORD wSprm)
{
	_CCMAP::iterator	i;

	i = m_ccmap.find(wSprm);
	if (i != m_ccmap.end())
	{
		return i->second;
	}
	else
		return NULL;
}

fpSave _KCCManager::GetCosaver(CTRLCODEID wid)
{
	_ISMAP::iterator	i;

	i = m_ismap.find(wid);
	if (i != m_ismap.end())
	{
		return i->second;
	}
	else
		return NULL;
}

static _KCCManager	_kccmanager;

sprmCtrlAid::KNestedSprmList* gpNest = NULL;

CCtrlCode* CoCreate_CtrlCode(WORD sprm, WORD* pData, UINT cw, sprmCtrlAid::KNestedSprmList&	nest)
{
	fpConcreate fp = _kccmanager.GetCocreator(IO_SPRM_CODE(sprm));
	gpNest = &nest;
	if (fp == NULL)
		return NULL;
	else
		return fp(sprm, pData, cw);
}

HRESULT CoSave_CtrlCode(CCtrlCode* pcc, IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	fpSave fp = _kccmanager.GetCosaver(pcc->GetCodeID());

	if (fp == NULL)
	{
		ASSERT(FALSE);
		return E_FAIL;
	}
	else
		return (pcc->*fp)(pBuf, pArg);
}

// -------------------------------------------------------------------------
// Implements of CoCreators

CCtrlCode* _CECC_Alignment::_CoCreate_Alignment(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID, wAlignment;
	
	if (sprmcode == sprm_pa_HorzAlign || sprmcode == sprm_pa_VertAlign)
	{
		wID			= (sprmcode == sprm_pa_HorzAlign ? SETHALIGNMENT : SETVALIGNMENT);
		wAlignment	= sprmCtrlAid::ReadSprmWordValue(sprm, pData);
		CCtrlCode_Alignment* p = new CCtrlCode_Alignment(wID, wAlignment);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Alignment::_CoSave_Alignment(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETHALIGNMENT || m_wID == SETVALIGNMENT);
	sprmCtrlAid::SaveSprmWordValue(pBuf, m_wID == SETHALIGNMENT ? sprm_pa_HorzAlign : sprm_pa_VertAlign, m_wAlignment);
	return S_OK;
}

CCtrlCode* _CECC_AspectX::_CoCreate_AspectX(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID, wAspectX;

	if (sprmcode == sprm_ch_AspectX)
	{
		wID			= SETASPECTX;
		wAspectX	= sprmCtrlAid::ReadSprmWordValue(sprm, pData);
		CCtrlCode_AspectX* p = new CCtrlCode_AspectX(wAspectX);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_AspectX::_CoSave_AspectX(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETASPECTX);
	sprmCtrlAid::SaveSprmWordValue(pBuf, sprm_ch_AspectX, m_wAspectX);
	return S_OK;
}

extern BOOL g_fWPLPersisting;

CCtrlCode* _CECC_AutoNumber::_CoCreate_AutoNumber(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);

	if (sprmcode == sprm_pa_AutoNumber)
	{
		WORD wID = SETAUTONUMBER;
		AUTONUMPARAREF ParaRef;
		int nGroupID = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
		// [Modified] mgy 2002-11-7 19:20
		//	����ָ����洢�����⣬�������¶�ȡ�Զ����Level�������Ϊ
		int nLevel = 0;
		WORD sprmcLevel;
		PWORD pCur = gpNest->GetpCur();		// ���浱ǰָ��
		gpNest->Next(sprm, pData);
		sprmcLevel = IO_SPRM_CODE(sprm);
		if(sprmcLevel == sprm_pa_AutoNumberLevel)
		{
			nLevel = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
			int nMaxLevel = AUTONUMGROUP::GetLevelCount() - 1;
			nLevel	= min(nMaxLevel, max(nLevel, 0));
		}
		else
			gpNest->SetpCur(pCur);			// �ظ�ָ��λ��
		//	[End Modify]
/*
		if (g_fCopyPasteProc)
		{
			KAutoNumIOAdapter* pIOAdaper	= CCtrlCode_AutoNumber::s_pIOAdapter;
			ASSERT(pIOAdaper);
			if (pIOAdaper)
			{
				KAutoNumGroupSPtr spGroup;
				VERIFY(SUCCEEDED(pIOAdaper->GetGroupSPtrValue(nGroupID, spGroup)));
				ParaRef.m_AuoNumGroupSPtr	= spGroup;
				ParaRef.m_nLevel = nLevel;
			}
		}
		else
*/
		if(g_fWPLPersisting)	// ͼ�ķ��ſ���ص��Զ���Ŷ�������
		{
			WPSAN_ReadWPLParaAutonum(nGroupID, ParaRef);
			ParaRef.m_nLevel = nLevel;
		}
		else
		{
			WPSAN_ReadParaAutonum(nGroupID, ParaRef);
			ParaRef.m_nLevel = nLevel;
		}

		CCtrlCode_AutoNumber* p = new CCtrlCode_AutoNumber(&ParaRef);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_AutoNumber::_CoSave_AutoNumber(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(0);/*@@todo-autonum
	ASSERT(m_wID == SETAUTONUMBER);
	int nGroupID	= 0;
	int nLevel		= 0;
	if(g_fWPLPersisting)	// ͼ�ķ��ſ���ص��Զ���Ŵ�������
	{
		WPSAN_WriteWPLParaAutonum(&m_ParaRefData, nGroupID);
		nLevel = m_ParaRefData.m_nLevel;
	}
	else
	{
		nGroupID = WPSAN_WriteParaAutonum(0, &m_ParaRefData);
		nLevel = m_ParaRefData.m_nLevel;
	}

	sprmCtrlAid::SaveSprmDWordValue(pBuf, sprm_pa_AutoNumber, nGroupID);
	// ֱ�����Զ���ŵ�CtrlCode���nLevel������ָ����ʵ�ֵ�һ��ȱ�ݣ�ֻ�������
	sprmCtrlAid::SaveSprmDWordValue(pBuf, sprm_pa_AutoNumberLevel, nLevel); */
	return S_OK;
}

CCtrlCode* _CECC_BGVein::_CoCreate_BGVein(WORD sprm, WORD* pData, UINT cw)
{
	sprmCtrlAid::KNestedSprmList	nest;
	HRESULT		hr;
	WORD		sprmcode = IO_SPRM_CODE(sprm);
	WORD		wID;
	BGVEIN		bgvData;

	if (sprmcode != sprm_ch_Fill)
		return NULL;

	wID = SETBGVEIN;

	hr = nest.Start(sprm, pData);
	ASSERT(SUCCEEDED(hr));

	while (!nest.EndOfList())
	{
		hr = nest.Next(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		sprmcode = IO_SPRM_CODE(sprm);
		switch(sprmcode)
		{
		case sprm_cc_BrushStyle:
			bgvData.nBrushStyle = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
			break;
		case sprm_cc_ForeColor:
			bgvData.dwColor = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
			break;
		default:
			ASSERT(0);	// Unknown
		}
	}

	CCtrlCode_BGVein* p = new CCtrlCode_BGVein(wID, &bgvData);
	return p;
}

HRESULT _CECC_BGVein::_CoSave_BGVein(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETBGVEIN);

	// Calculate the size
	int cw = cw_DWordSprm + cw_DWordSprm;

	SaveSprmStructHeader(pBuf, sprm_ch_Fill, cw);
	SaveSprmDWordValue(pBuf, sprm_cc_ForeColor, m_dwColor);
	SaveSprmDWordValue(pBuf, sprm_cc_BrushStyle, m_nBrushStyle);

	return S_OK;
}

CCtrlCode* _CECC_Bold::_CoCreate_Bold(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID;
	LONG lWeight;

	if (sprmcode == sprm_ch_FontWeight)
	{
		wID		= SETBOLD;
		lWeight	= sprmCtrlAid::ReadSprmWordValue(sprm, pData);
		CCtrlCode_Bold* p = new CCtrlCode_Bold(lWeight);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Bold::_CoSave_Bold(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETBOLD);
	sprmCtrlAid::SaveSprmWordValue(pBuf, sprm_ch_FontWeight, m_lWeight);
	return S_OK;
}

CCtrlCode* _CECC_CharSet::_CoCreate_CharSet(WORD sprm, WORD* pData, UINT cw)
{
	return NULL;
}

HRESULT _CECC_CharSet::_CoSave_CharSet(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	return E_FAIL;
}

CCtrlCode* _CECC_Color::_CoCreate_Color(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID;
	KCOLORINDEX CharColor;

	if (sprmcode == sprm_cc_ForeColor)
	{
		wID		= SETCOLOR;
		CharColor	= sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
		CCtrlCode_Color* p = new CCtrlCode_Color(CharColor);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Color::_CoSave_Color(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETCOLOR);
	sprmCtrlAid::SaveSprmDWordValue(pBuf, sprm_cc_ForeColor, m_CharColor);
	return S_OK;
}

CCtrlCode* _CECC_DISPLAY::_CoCreate_DISPLAY(WORD sprm, WORD* pData, UINT cw)
{
	return NULL;
}

HRESULT _CECC_DISPLAY::_CoSave_DISPLAY(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	return E_FAIL;
}

CCtrlCode* _CECC_Font::_CoCreate_Font(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID;
	char szFaceName[LF_FACESIZE];

	if (sprmcode == sprm_ch_FontNameDef || sprmcode == sprm_ch_FontNameFE)
	{
		wID		= (sprmcode == sprm_ch_FontNameDef ? SETENGFONT : SETCHNFONT);
		sprmCtrlAid::LoadSprmStringValue(sprm, pData, szFaceName, LF_FACESIZE);
		CCtrlCode_Font* p = new CCtrlCode_Font(wID, szFaceName);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Font::_CoSave_Font(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETENGFONT || m_wID == SETCHNFONT);
	SaveSprmStringValue(pBuf, m_wID == SETENGFONT ? sprm_ch_FontNameDef : sprm_ch_FontNameFE, m_szFaceName);
	return S_OK;
}

CCtrlCode* _CECC_HotRef::_CoCreate_HotRef(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD wID;
	HOTREF hrData;

	if (sprmcode == sprm_ch_HyperLink)
	{
		wID		= SETHYPERREF;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		while (!nest.EndOfList())
		{
			hr = nest.Next(sprm, pData);
			ASSERT(SUCCEEDED(hr));

			if (SUCCEEDED(hr))
			{
				sprmcode = IO_SPRM_CODE(sprm);
				switch(sprmcode)
				{
				case sprm_hyper_Style:
					hrData.wHyperID = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
					break;
				case sprm_hyper_URL:
					sprmCtrlAid::LoadSprmStringValue(sprm, pData, hrData.szData, MAX_URL);
					break;
				case sprm_hyper_Bookmark:
					sprmCtrlAid::LoadSprmStringValue(sprm, pData, hrData.szAnchor, SIZE_BOOKMARK);
					break;
				default:
					ASSERT(0);	// Unknown
				}
			}
		};
				
		CCtrlCode_HotRef* p = new CCtrlCode_HotRef(&hrData);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_HotRef::_CoSave_HotRef(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETHYPERREF);

	// Calculate the size
	int cw = cw_DWordSprm + cw_StringSprm(m_szData) + cw_StringSprm(m_szAnchor);

	SaveSprmStructHeader(pBuf, sprm_ch_HyperLink, cw);
	SaveSprmDWordValue(pBuf, sprm_hyper_Style, m_wHyperID);
	SaveSprmStringValue(pBuf, sprm_hyper_URL, m_szData);
	SaveSprmStringValue(pBuf, sprm_hyper_Bookmark, m_szAnchor);

	return S_OK;
}

CCtrlCode* _CECC_HSS::_CoCreate_HSS(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD wID;
	CHARFXHSS hssData;
	ZeroMemory(&hssData, sizeof(CHARFXHSS));
	if (sprmcode == sprm_ch_HSS)
	{
		wID		 = SETHSS;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		while (!nest.EndOfList())
		{
			hr = nest.Next(sprm, pData);
			ASSERT(SUCCEEDED(hr));

			if (SUCCEEDED(hr))
			{
				sprmcode = IO_SPRM_CODE(sprm);
				switch(sprmcode)
				{
				case sprm_hss_Style:
					hssData.hssFlag = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
					break;				
				case sprm_hss_Depth:
					hssData.hssDepth = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
					break;
				case sprm_hss_Degree:
					hssData.hssDegree = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
					break;
				case sprm_cc_ForeColor:
					hssData.hssFromColor = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
					break;
				case sprm_hss_EndColor:
					hssData.hssToColor = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
					break;
				case sprm_hss_Para:
					hssData.hssPara = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
					break;
				default:
					ASSERT(0);	// Unknown
				}
			}
		};

		if (hssData.hssDegree == 0		&&
			hssData.hssDepth == 0		&&
			hssData.hssFlag == 0		&&
			hssData.hssFromColor ==	0	&&
			hssData.hssPara == 0		&&
			hssData.hssToColor == 0)
		{
			return NULL;
		}
		else
		{
			CCtrlCode_HSS* p = new CCtrlCode_HSS(&hssData);
			return p;
		}
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_HSS::_CoSave_HSS(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETHSS);

	// Calculate the size
	int cw = cw_WordSprm * 3 + cw_DWordSprm * 3;

	SaveSprmStructHeader(pBuf, sprm_ch_HSS, cw);

	SaveSprmWordValue(pBuf, sprm_hss_Style,		m_Data.hssFlag);
	SaveSprmWordValue(pBuf, sprm_hss_Depth,		m_Data.hssDepth);
	SaveSprmWordValue(pBuf, sprm_hss_Degree,	m_Data.hssDegree);

	SaveSprmDWordValue(pBuf, sprm_cc_ForeColor,	m_Data.hssFromColor);
	SaveSprmDWordValue(pBuf, sprm_hss_EndColor,	m_Data.hssToColor);
	SaveSprmDWordValue(pBuf, sprm_hss_Para,		m_Data.hssPara);
				
	return S_OK;
}

CCtrlCode* _CECC_Italic::_CoCreate_Italic(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID;
	WORD lDegree;

	if (sprmcode == sprm_ch_FontItalic)
	{
		wID		= SETITALIC;
		lDegree	= sprmCtrlAid::ReadSprmWordValue(sprm, pData);
		CCtrlCode_Italic* p = new CCtrlCode_Italic(lDegree);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Italic::_CoSave_Italic(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETITALIC);
	sprmCtrlAid::SaveSprmWordValue(pBuf, sprm_ch_FontItalic, m_lDegree);
	return S_OK;
}

CCtrlCode* _CECC_Label::_CoCreate_Label(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD wID;
	int nLabelID;

	if (sprmcode == sprm_ch_BookMark)
	{
		wID		= SETLABEL;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		while (!nest.EndOfList())
		{
			hr = nest.Next(sprm, pData);
			ASSERT(SUCCEEDED(hr));

			if (SUCCEEDED(hr))
			{
				sprmcode = IO_SPRM_CODE(sprm);
				switch(sprmcode)
				{
				case sprm_bmark_ID:
					nLabelID = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
					break;
				default:
					ASSERT(0);	// Unknown
				}
			}
		};
				
		CCtrlCode_Label* p = new CCtrlCode_Label(nLabelID);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Label::_CoSave_Label(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETLABEL);

	// Calculate the size
	int cw = cw_DWordSprm;

	SaveSprmStructHeader(pBuf, sprm_ch_BookMark, cw);
	SaveSprmDWordValue(pBuf, sprm_bmark_ID, m_nID);

	return S_OK;
}

void _ReadSprmUnitValueStruct(WORD sprm, WORD* pData, UNIT_VALUE* p)
{
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD	sprmcode;

	ASSERT(p != NULL);

	hr = nest.Start(sprm, pData);
	ASSERT(SUCCEEDED(hr));

	while (!nest.EndOfList())
	{
		hr = nest.Next(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		if (SUCCEEDED(hr))
		{
			sprmcode = IO_SPRM_CODE(sprm);
			switch(sprmcode)
			{
			case sprm_uval_Unit:
				p->wUnit = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
				break;
			case sprm_uval_Value:
				p->nValue = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
				break;
			default:
				ASSERT(0);	// Unknown
			}
		}
	}
}

void _SaveSprmUnitValueStruct(IAppendBuffer* pBuf, WORD sprm, UNIT_VALUE* p)
{
	// Calculate the size
	int cw = cw_WordSprm + cw_DWordSprm;

	SaveSprmStructHeader(pBuf, sprm, cw);
	SaveSprmWordValue(pBuf, sprm_uval_Unit, p->wUnit);
	SaveSprmDWordValue(pBuf, sprm_uval_Value, p->nValue);
}

CCtrlCode* _CECC_LineMargin::_CoCreate_LineMargin(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID;
	UNIT_VALUE uv;

	if (sprmcode == sprm_pa_LineHeight)
	{
		wID		= SETLINEMARGIN;
		_ReadSprmUnitValueStruct(sprm, pData, &uv);

		CCtrlCode_LineMargin* p = new CCtrlCode_LineMargin(&uv);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_LineMargin::_CoSave_LineMargin(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETLINEMARGIN);
	_SaveSprmUnitValueStruct(pBuf, sprm_pa_LineHeight, &m_LineMargin);
	return S_OK;	
}

CCtrlCode* _CECC_ObliqueLine::_CoCreate_ObliqueLine(WORD sprm, WORD* pData, UINT cw)
{
	return NULL;
}

HRESULT _CECC_ObliqueLine::_CoSave_ObliqueLine(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	return E_FAIL;
}

void _ReadSprmBorderStruct(WORD sprm, WORD* pData, KCOLORINDEX& color, int& nPenStyle, int& nWidth, LONG& lDistance)
{
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD	sprmcode;

	hr = nest.Start(sprm, pData);
	ASSERT(SUCCEEDED(hr));

	while (!nest.EndOfList())
	{
		hr = nest.Next(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		if (SUCCEEDED(hr))
		{
			sprmcode = IO_SPRM_CODE(sprm);
			switch(sprmcode)
			{
			case sprm_cc_ForeColor:
				color = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
				break;
			case sprm_cc_PenStyle:
				nPenStyle = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
				break;
			case sprm_cc_PenWidth:
				nWidth = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
				break;
			case sprm_brc_Distance:
				lDistance = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
				break;
			default:
				ASSERT(0);	// Unknown
			}
		}
	};
}

int _cwSprmBorderStruct(bool bSaveDistance = true)
{
	return cw_DWordSprm * 2 + cw_WordSprm + (bSaveDistance ? cw_DWordSprm : 0);
}

void _SaveSprmBorderStruct(IAppendBuffer* pBuf, WORD sprm, KCOLORINDEX color, int nPenStyle, int nWidth, LONG lDistance, bool bSaveDistance = true)
{
	// Calculate the size
	int cw = _cwSprmBorderStruct(bSaveDistance);

	SaveSprmStructHeader(pBuf, sprm, cw);
	SaveSprmDWordValue(pBuf, sprm_cc_ForeColor, color);
	SaveSprmDWordValue(pBuf, sprm_cc_PenStyle, nPenStyle);
	SaveSprmWordValue(pBuf, sprm_cc_PenWidth, nWidth);
	if (bSaveDistance)
		SaveSprmDWordValue(pBuf, sprm_brc_Distance, lDistance);
}

CCtrlCode* _CECC_OutRect::_CoCreate_OutRect(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	WORD wID;
	OUTRECT outrect;

	if (sprmcode == sprm_ch_Border)
	{
		wID		= SETOUTRECT;

		LONG l;
		_ReadSprmBorderStruct(sprm, pData, outrect.dwColor, outrect.nPenStyle, outrect.nWidth, l);

		CCtrlCode_OutRect* p = new CCtrlCode_OutRect(wID, &outrect);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_OutRect::_CoSave_OutRect(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETOUTRECT);
	_SaveSprmBorderStruct(pBuf, sprm_ch_Border, m_dwColor, m_nPenStyle, m_nWidth, 0, false);
	return S_OK;	
}

CCtrlCode* _CECC_ParaFrame::_CoCreate_ParaFrame(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD wID;
	PARAFRAME paraframe;

	if (sprmcode == sprm_pa_Border)
	{
		wID		= SETPARAFRAME;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		while (!nest.EndOfList())
		{
			hr = nest.Next(sprm, pData);
			ASSERT(SUCCEEDED(hr));

			if (SUCCEEDED(hr))
			{
				sprmcode = IO_SPRM_CODE(sprm);
				switch(sprmcode)
				{
				case sprm_brc_Flag:
					paraframe.dwFlag = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
					break;
				case sprm_brc_Left:
					_ReadSprmBorderStruct(sprm, pData, paraframe.dwColorLeft, paraframe.nPenStyleLeft, paraframe.nWidthLeft, paraframe.lDistanceL);
					break;
				case sprm_brc_Top:
					_ReadSprmBorderStruct(sprm, pData, paraframe.dwColorTop, paraframe.nPenStyleTop, paraframe.nWidthTop, paraframe.lDistanceT);
					break;
				case sprm_brc_Right:
					_ReadSprmBorderStruct(sprm, pData, paraframe.dwColorRight, paraframe.nPenStyleRight, paraframe.nWidthRight, paraframe.lDistanceR);
					break;
				case sprm_brc_Bottom:
					_ReadSprmBorderStruct(sprm, pData, paraframe.dwColorBottom, paraframe.nPenStyleBottom, paraframe.nWidthBottom, paraframe.lDistanceB);
					break;
				default:
					ASSERT(0);	// Unknown
				}
			}
		};
				
		CCtrlCode_ParaFrame* p = new CCtrlCode_ParaFrame(wID, &paraframe);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_ParaFrame::_CoSave_ParaFrame(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETPARAFRAME);

	// Calculate the size
	int cw = cw_DWordSprm + (_cwSprmBorderStruct() + cw_StructHeader) * 4;

	SaveSprmStructHeader(pBuf, sprm_pa_Border, cw);
	SaveSprmDWordValue(pBuf, sprm_brc_Flag, m_ParaFrame.dwFlag);
	_SaveSprmBorderStruct(pBuf, sprm_brc_Left,	 m_ParaFrame.dwColorLeft,	m_ParaFrame.nPenStyleLeft,	 m_ParaFrame.nWidthLeft,   m_ParaFrame.lDistanceL);
	_SaveSprmBorderStruct(pBuf, sprm_brc_Top,	 m_ParaFrame.dwColorTop,	m_ParaFrame.nPenStyleTop,	 m_ParaFrame.nWidthTop,	   m_ParaFrame.lDistanceT);
	_SaveSprmBorderStruct(pBuf, sprm_brc_Right,  m_ParaFrame.dwColorRight,	m_ParaFrame.nPenStyleRight,	 m_ParaFrame.nWidthRight,  m_ParaFrame.lDistanceR);
	_SaveSprmBorderStruct(pBuf, sprm_brc_Bottom, m_ParaFrame.dwColorBottom,	m_ParaFrame.nPenStyleBottom, m_ParaFrame.nWidthBottom, m_ParaFrame.lDistanceB);

	return S_OK;
}

CCtrlCode* _CECC_ParaIndent::_CoCreate_ParaIndent(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID	wid;
	UNIT_VALUE	uv;

	switch(sprmcode)
	{
	case sprm_pa_LeftIndent:
		wid = SETLEFTINDENT;
		break;
	case sprm_pa_FirstIndent:
		wid = SETFIRSTINDENT;
		break;
	case sprm_pa_RightIndent:
		wid = SETRIGHTINDENT;
		break;
	default:
		return NULL;
	}

	_ReadSprmUnitValueStruct(sprm, pData, &uv);
	CCtrlCode_ParaIndent* p = new CCtrlCode_ParaIndent(wid, &uv);
	return p;
}

HRESULT _CECC_ParaIndent::_CoSave_ParaIndent(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	WORD sprm;

	switch(m_wID)
	{
	case SETLEFTINDENT:
		sprm = sprm_pa_LeftIndent;
		break;
	case SETFIRSTINDENT:
		sprm = sprm_pa_FirstIndent;
		break;
	case SETRIGHTINDENT:
		sprm = sprm_pa_RightIndent;
		break;
	default:
		ASSERT(0);
		return E_FAIL;
	}

	_SaveSprmUnitValueStruct(pBuf, sprm, &m_Indent);
	return S_OK;
}

CCtrlCode* _CECC_ParaMargin::_CoCreate_ParaMargin(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID	wid;
	UNIT_VALUE	uv;

	switch(sprmcode)
	{
	case sprm_pa_ParaMargin:
		wid = SETPARAMARGIN;
		break;
	case sprm_pa_PostPMargin:
		wid = SETAFPAMARGIN;
		break;
	default:
		return NULL;
	}

	_ReadSprmUnitValueStruct(sprm, pData, &uv);
	CCtrlCode_ParaMargin* p = new CCtrlCode_ParaMargin(wid, &uv);
	return p;
}

HRESULT _CECC_ParaMargin::_CoSave_ParaMargin(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	WORD sprm;

	switch(m_wID)
	{
	case SETPARAMARGIN:
		sprm = sprm_pa_ParaMargin;
		break;
	case SETAFPAMARGIN:
		sprm = sprm_pa_PostPMargin;
		break;
	default:
		ASSERT(0);
		return E_FAIL;
	}

	_SaveSprmUnitValueStruct(pBuf, sprm, &m_ParaMargin);
	return S_OK;
}

void _ReadSprmReviseItemStruct(WORD sprm, WORD* pData, REVISE_DATA* p)
{
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD	sprmcode;

	ASSERT(p != NULL);

	hr = nest.Start(sprm, pData);
	ASSERT(SUCCEEDED(hr));

	while (!nest.EndOfList())
	{
		hr = nest.Next(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		if (SUCCEEDED(hr))
		{
			sprmcode = IO_SPRM_CODE(sprm);
			switch(sprmcode)
			{
			case sprm_rvi_Type:
				p->wReviseType = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
				break;
			case sprm_rvi_UserID:
				p->wUserID = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
				break;
			case sprm_rvi_Time:
				sprmCtrlAid::LoadSprmBinaryValue(sprm, pData, &p->sReviseTime, sizeof(SYSTEMTIME));
				break;
			default:
				ASSERT(0);	// Unknown
			}
		}
	}
}

int _cwSprmReviseItemStruct()
{
	return cw_WordSprm * 2 + cw_StructHeader + cw_BlockSprm(sizeof(SYSTEMTIME));
}

void _SaveSprmReviseItemStruct(IAppendBuffer* pBuf, WORD sprm, REVISE_DATA* p)
{
	// Calculate the size
	int cw = _cwSprmReviseItemStruct();

	SaveSprmStructHeader(pBuf, sprm, cw);
	SaveSprmWordValue(pBuf, sprm_rvi_Type, p->wReviseType);
	SaveSprmWordValue(pBuf, sprm_rvi_UserID, p->wUserID);
	SaveSprmBinaryValue(pBuf, sprm_rvi_Time, &p->sReviseTime, sizeof(SYSTEMTIME));
}

CCtrlCode* _CECC_Revise::_CoCreate_Revise(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;

	if (sprmcode == sprm_ch_Revise)
	{
	//	CCtrlCode_Revise* p = new CCtrlCode_Revise;
		_CECC_Revise* p = (_CECC_Revise*)new CCtrlCode_Revise;
		p->m_wID		= SETREVISE;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		hr = nest.Next(sprm, pData);
		if (SUCCEEDED(hr) && IO_SPRM_CODE(sprm) == sprm_rev_Count)
		{
			p->m_nCount = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
			int nSize = p->m_nCount * sizeof REVISE_DATA;
			p->m_pDataBuf = new char[nSize];
			ASSERT(p->m_pDataBuf != NULL);
			if (p->m_pDataBuf == NULL)
				p->m_nCount = 0;
			
			REVISE_DATA* pRVI = (REVISE_DATA*)p->m_pDataBuf;

			for (int i = 0; i < p->m_nCount; i++)
			{
				hr = nest.Next(sprm, pData);
				if (SUCCEEDED(hr) && IO_SPRM_CODE(sprm) == sprm_rev_Item)
				{
					_ReadSprmReviseItemStruct(sprm, pData, pRVI + i);
				}
			}
		}
		else
		{
			p->m_nCount = 0;
			p->m_pDataBuf = NULL;
		}
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Revise::_CoSave_Revise(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETREVISE);

	// Calculate the size
	int cw = cw_DWordSprm + (_cwSprmReviseItemStruct() + cw_StructHeader) * m_nCount;

	SaveSprmStructHeader(pBuf, sprm_ch_Revise, cw);
	SaveSprmDWordValue(pBuf, sprm_rev_Count, m_nCount);

	REVISE_DATA* pRVI = (REVISE_DATA*)m_pDataBuf;
	for (int i = 0; i < m_nCount; i++)
	{
		_SaveSprmReviseItemStruct(pBuf, sprm_rev_Item, pRVI + i);
	}

	return S_OK;
}

CCtrlCode* _CECC_Size::_CoCreate_Size(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID  wID;
	tagFONTSIZE fsData;

	if (sprmcode == sprm_ch_FontSize || sprmcode == sprm_ch_ActFontSize)
	{
		wID		= sprmcode == sprm_ch_FontSize ? SETFONTSIZE : SETACTFONTSIZE;

		UNIT_VALUE	uv;
		_ReadSprmUnitValueStruct(sprm, pData, &uv);

		fsData.nfsUnit = uv.wUnit;
		fsData.nfsSize = uv.nValue;

		CCtrlCode_Size* p = new CCtrlCode_Size(wID, &fsData);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Size::_CoSave_Size(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETFONTSIZE || m_wID == SETACTFONTSIZE);
	UNIT_VALUE u = { m_Unit, m_lCharSize };
	_SaveSprmUnitValueStruct(pBuf, m_wID == SETFONTSIZE ? sprm_ch_FontSize : sprm_ch_ActFontSize, &u);
	return S_OK;
}

CCtrlCode* _CECC_SSScript::_CoCreate_SSScript(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD wID, wFlag;
	SUPERSUBSCRIPT sss;

	if (sprmcode == sprm_ch_SSS)
	{
		wID		= SETSSS;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		while (!nest.EndOfList())
		{
			hr = nest.Next(sprm, pData);
			ASSERT(SUCCEEDED(hr));

			if (SUCCEEDED(hr))
			{
				sprmcode = IO_SPRM_CODE(sprm);
				switch(sprmcode)
				{
				case sprm_sss_Style:
					wFlag = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
					break;
				case sprm_sss_RelHeight:
					sss.nRelativeHeight = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
					break;
				case sprm_sss_RelShift:
					sss.nRelativeShift = (short)sprmCtrlAid::ReadSprmWordValue(sprm, pData);
										//~~~~~  ���sprm��Ҫ��ʾ����
					break;
				default:
					ASSERT(0);	// Unknown
				}
			}
		};
				
		CCtrlCode_SSScript* p = new CCtrlCode_SSScript(wFlag, &sss);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_SSScript::_CoSave_SSScript(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETSSS);

	// Calculate the size
	int cw = cw_WordSprm * 3;

	SaveSprmStructHeader(pBuf, sprm_ch_SSS, cw);
	SaveSprmWordValue(pBuf, sprm_sss_Style, m_wFlag);
	SaveSprmWordValue(pBuf, sprm_sss_RelHeight, m_Data.nRelativeHeight);
	SaveSprmWordValue(pBuf, sprm_sss_RelShift, m_Data.nRelativeShift);

	return S_OK;
}

void _ReadSprmLineStruct(WORD sprm, WORD* pData, WORD& wStyle, KCOLORINDEX& dwColor)
{
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD	sprmcode;

	hr = nest.Start(sprm, pData);
	ASSERT(SUCCEEDED(hr));

	while (!nest.EndOfList())
	{
		hr = nest.Next(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		if (SUCCEEDED(hr))
		{
			sprmcode = IO_SPRM_CODE(sprm);
			switch(sprmcode)
			{
			case sprm_line_Style:
				wStyle = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
				break;
			case sprm_cc_ForeColor:
				dwColor = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
				break;
			default:
				ASSERT(0);	// Unknown
			}
		}
	}
}

void _SaveSprmLineStruct(IAppendBuffer* pBuf, WORD sprm, WORD wStyle, KCOLORINDEX dwColor, bool bSaveColor = true)
{
	// Calculate the size
	int cw = cw_WordSprm + (bSaveColor ? cw_DWordSprm : 0);

	SaveSprmStructHeader(pBuf, sprm, cw);
	SaveSprmWordValue(pBuf, sprm_line_Style, wStyle);
	if (bSaveColor)
		SaveSprmDWordValue(pBuf, sprm_cc_ForeColor, dwColor);
}

CCtrlCode* _CECC_StrikeOut::_CoCreate_StrikeOut(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID	wID;
	WORD wFlag;

	if (sprmcode == sprm_ch_StrikeOut)
	{
		wID		= SETSTRIKEOUT;

		DWORD dw;
		_ReadSprmLineStruct(sprm, pData, wFlag, dw);

		CCtrlCode_StrikeOut* p = new CCtrlCode_StrikeOut(wFlag);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_StrikeOut::_CoSave_StrikeOut(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETSTRIKEOUT);
	_SaveSprmLineStruct(pBuf, sprm_ch_StrikeOut, m_wFlag, 0, false);
	return S_OK;
}

void _ReadSprmTabItemStruct(WORD sprm, WORD* pData, TABITEM* p)
{
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	WORD	sprmcode;

	ASSERT(p != NULL);

	hr = nest.Start(sprm, pData);
	ASSERT(SUCCEEDED(hr));

	while (!nest.EndOfList())
	{
		hr = nest.Next(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		if (SUCCEEDED(hr))
		{
			sprmcode = IO_SPRM_CODE(sprm);
			switch(sprmcode)
			{
			case sprm_tbi_Pos:
				p->nTabPosition = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
				break;
			case sprm_tbi_Char:
				p->wFrontChar = sprmCtrlAid::ReadSprmWordValue(sprm, pData);
				break;
			default:
				ASSERT(0);	// Unknown
			}
		}
	}
}

int _cwSprmTabItemStruct()
{
	return cw_DWordSprm + cw_WordSprm;
}

void _SaveSprmTabItemStruct(IAppendBuffer* pBuf, WORD sprm, TABITEM* p)
{
	// Calculate the size
	int cw = _cwSprmTabItemStruct();

	SaveSprmStructHeader(pBuf, sprm, cw);
	SaveSprmDWordValue(pBuf, sprm_tbi_Pos, p->nTabPosition);
	SaveSprmWordValue(pBuf, sprm_tbi_Char, p->wFrontChar);
}

CCtrlCode* _CECC_Tabs::_CoCreate_Tabs(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	HRESULT hr;
	sprmCtrlAid::KNestedSprmList nest;
	CTRLCODEID wID;
	TABITEM tabs[MAXTABSTOPS + 1];

	if (sprmcode == sprm_pa_TabStops)
	{
		wID		= SETTABS;

		hr = nest.Start(sprm, pData);
		ASSERT(SUCCEEDED(hr));

		hr = nest.Next(sprm, pData);
		if (SUCCEEDED(hr) && IO_SPRM_CODE(sprm) == sprm_tab_Count)
		{
			int nCount = sprmCtrlAid::ReadSprmDWordValue(sprm, pData);
			ASSERT(nCount == MAXTABSTOPS + 1);
			nCount = MAXTABSTOPS + 1;
			
			TABITEM* pTBI = tabs;

			for (int i = 0; i < nCount; i++)
			{
				hr = nest.Next(sprm, pData);
				if (SUCCEEDED(hr) && IO_SPRM_CODE(sprm) == sprm_tab_Item)
				{
					_ReadSprmTabItemStruct(sprm, pData, pTBI + i);
				}
			}
		}
		else
		{
			ASSERT(0);
			return NULL;
		}

		CCtrlCode_Tabs* p = new CCtrlCode_Tabs(tabs);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Tabs::_CoSave_Tabs(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETTABS);

	// Calculate the size
	int nCount = MAXTABSTOPS + 1;
	int cw = cw_DWordSprm + (_cwSprmTabItemStruct() + cw_StructHeader) * nCount;

	SaveSprmStructHeader(pBuf, sprm_pa_TabStops, cw);
	SaveSprmDWordValue(pBuf, sprm_tab_Count, nCount);

	TABITEM* pTBI = m_Tabs;
	for (int i = 0; i < nCount; i++)
	{
		_SaveSprmTabItemStruct(pBuf, sprm_tab_Item, pTBI + i);
	}

	return S_OK;
}

CCtrlCode* _CECC_Tracking::_CoCreate_Tracking(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID wID;
	UNIT_VALUE uv;

	if (sprmcode == sprm_ch_Tracking)
	{
		wID		= SETTRACKING;
		_ReadSprmUnitValueStruct(sprm, pData, &uv);

		CCtrlCode_Tracking* p = new CCtrlCode_Tracking(&uv);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Tracking::_CoSave_Tracking(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETTRACKING);
	_SaveSprmUnitValueStruct(pBuf, sprm_ch_Tracking, &m_Track);
	return S_OK;
}

CCtrlCode* _CECC_UnderLine::_CoCreate_UnderLine(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID	wid;
	UULINEPARA	lineData;

	switch(sprmcode)
	{
	case sprm_ch_UpperLine:
		wid = SETUPPERLINE;
		break;
	case sprm_ch_UnderLine:
		wid = SETUNDERLINE;
		break;
	case sprm_ch_Stress:
		wid = SETSTRESS;
		break;
	default:
		return NULL;
	}

	WORD wStyle;
	_ReadSprmLineStruct(sprm, pData, wStyle, lineData.cColor);
	lineData.uStyle = wStyle;

	CCtrlCode_UnderLine* p = new CCtrlCode_UnderLine(wid, &lineData);
	return p;
}

HRESULT _CECC_UnderLine::_CoSave_UnderLine(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	WORD sprm;

	switch(m_wID)
	{
	case SETUPPERLINE:
		sprm = sprm_ch_UpperLine;
		break;
	case SETUNDERLINE:
		sprm = sprm_ch_UnderLine;
		break;
	case SETSTRESS:
		sprm = sprm_ch_Stress;
		break;
	default:
		ASSERT(0);
		return E_FAIL;
	}

	_SaveSprmLineStruct(pBuf, sprm, m_wStyle, m_clrLineColor);
	return S_OK;
}

CCtrlCode* _CECC_Visible::_CoCreate_Visible(WORD sprm, WORD* pData, UINT cw)
{
	WORD sprmcode = IO_SPRM_CODE(sprm);
	CTRLCODEID	wID;
	BOOL	bVisible;

	if (sprmcode == sprm_ch_Visible)
	{
		wID		= SETSENVISIBLE;
		bVisible	= sprmCtrlAid::ReadSprmWordValue(sprm, pData);

		CCtrlCode_Visible* p = new CCtrlCode_Visible(wID, bVisible);
		return p;
	}
	else
	{
		return NULL;
	}
}

HRESULT _CECC_Visible::_CoSave_Visible(IAppendBuffer* pBuf, _CoSaveArg* pArg)
{
	ASSERT(m_wID == SETSENVISIBLE);
	SaveSprmWordValue(pBuf, sprm_ch_Visible, m_bVisible);
	return S_OK;
}