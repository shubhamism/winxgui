/////////////////////////////////////////////////////////////////////////////
//
// tableObj.cpp - implementation for CTableRowCol & CTableElement objects
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>

#ifndef __WPSDOC_H
#include <core/wpsdoc.h>
#endif

#ifndef __WPSOBJ_H
#include "draw/wpsobj.h"
#endif

#ifndef __FRAMEOBJ_H
#include "draw/frameobj.h"
#endif

#ifndef __FRAMETBL_H
#include "frametbl.h"
#endif

#ifndef __TABLEOBJ_H
#include "tableobj.h"
#endif

#ifndef __CTRLCODE_H
#include <core/ctrlcode.h>
#endif

#ifndef __WPSCIMG_H
#include "draw/wpsimg.h"
#endif

#ifndef __PTOBJ_H
#include "draw/ptobj.h"
#endif

#if defined(WPP_ONLY)
#include <pres/wppdoc.h>
#endif

#if !defined(AFX_KXCODEPAGEVI_H_INCLUDED_)
#include <codepage/KXCodePageVI.h>
#endif
extern KXCodePageVI* g_lpKXCodePageVI;

//	��Ԫ���ֿ� sjz-020501
#include <draw/frametext.h>

//#include "wpssubobj.h"
//#include "TExtPool.h"
//#include "Texttool.h"

//#include "WPPDoc.h" //For WPP(��ʾ)

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

extern const TCHAR g_cBlank[] = _T("��");		//	ȫ�ǿո�
void TextStringToString(CString&, KSTextString&);
int KCP_WordToTextWord(LPTEXTWORD lptw, LPWORD lpw, int nLength);
int KCP_StringToTextWord(LPTEXTWORD lptw, LPCTSTR lpsz, int nLength = -1);
CWpsView* GetCurView();

CPoint GetObliqueLeftTop(int nObli, int nRowID, int nHsz, int nHrc, int nWrc, int nWrow)
{
	CPoint pntLT(0, 0);
    int dx, dy;
    //	����һ����ʾ����ʼλ��
    if (nObli == 1)
    {   if (nRowID == 0)
	    {   dy = MulDiv(1, (nHrc -nHsz -MulDiv(nWrow, nHrc, nWrc)), 3);
			pntLT.y = max(0, dy);
		    pntLT.x = max(0, nWrc - nWrow - MulDiv(dy, nWrc, nHrc));
	   	}
	    else if (nRowID == 1)
	    {   dx = MulDiv(1, (nWrc -nWrow -MulDiv(nHsz, nWrc, nHrc)), 3);
			pntLT.x = max(0, dx);
		    pntLT.y = max(0, nHrc - nHsz - MulDiv(dx, nHrc, nWrc));
	   	}
	}
	else
	{   if (nRowID == 0)
	    {  	int rW = MulDiv(nWrc, 1, 2);
		    dy = MulDiv(1, (nHrc -nHsz -MulDiv(nWrow, nHrc, rW)), 3);
			pntLT.y = max(0, dy);
		    pntLT.x = max(0, nWrc -nWrow -MulDiv(dy,rW,nHrc));
	   	}
	    else if (nRowID == 2)
	    {  	int rH = MulDiv(nHrc, 1, 2);
		    dx = MulDiv(1, (nWrc -nWrow -MulDiv(nHsz, nWrc, rH)), 3);
			pntLT.x = max(0, dx);
		    pntLT.y = max(0, nHrc -nHsz -MulDiv(dx, rH, nWrc));
	   	}
	   	else if (nRowID == 1)
	   	{	pntLT.y = nHrc/2- nHsz;
	   		int p = nWrc/2 + MulDiv(pntLT.y, nWrc, nHrc*2);
	   		pntLT.x = max(0, (p-nWrow)/2);
	   	}
	} 
	return pntLT;
}

////////////////////////////////////////////////////////////////////////////
// CTableElement

//IMPLEMENT_SERIAL(CTableElement, CTFPBase, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CTableElement, CTFPBase, 0xA0 | VERSIONABLE_SCHEMA)

CTableElement::CTableElement()
{
	SetWPSObjType(TABLEELEMENTObj);

	m_pImg = NULL;
	m_extent = CSize(0, 0);
	m_nType = TT_free;
	m_pTbl	= NULL;
	m_pRow	= NULL;
	m_pCol	= NULL;
	//m_pTextObjSite = NULL;
	m_nCurPos	= 0;
	m_nCurRowID	= 0;
	m_nHeadPos	= -1;
	m_nHeadRowID = -1;
	m_nCurX		= -1;
	m_nTailPos	= -1;
	m_nTextH	= -1;
	m_bDefText	= FALSE;
	m_LineMode	= horz;
}

//BOOL MStringToDMString(CString& str);
CTableElement::CTableElement(const CWpsDoc* pDoc, const CRect& position)
	: CTFPBase(pDoc, position)
{
	SetWPSObjType(TABLEELEMENTObj);

	for (int i = 0; i < 4; ++i)
	{
		m_uLPenStyle[i] = PS_INSIDEFRAME;
		m_uLPenSize[i]  = TELW_DEFSIZE; //	0.1mm
		m_LPenColor[i]  = RGB(0,0,0);
	}

	m_pImg = NULL;
	m_extent = CSize(0, 0);
	//m_stringDSP = '\r';
	//m_stringDSP += (char)0;
	m_stringSAV = m_stringDSP;
	m_nTextH = -1;
	m_nAutoChangeWH.cx=0;
	m_nAutoChangeWH.cy=0;
	m_nType = TT_free;
	m_pTbl	= NULL;
	m_pRow	= NULL;
	m_pCol	= NULL;
	//m_pTextObjSite = NULL;
	m_nCurPos	= 0;
	m_nCurRowID	= 0;
	m_nHeadPos	= -1;
	m_nHeadRowID = -1;
	m_nCurX		= -1;
	m_nTailPos	= -1;
	m_bDefText	= FALSE;
	m_LineMode	= horz;
}

//extern CTableElement* s_pElem;
CTableElement::~CTableElement()
{
	ASSERT(this);
	//if (s_pElem == this)
	//	s_pElem = NULL;
	RemoveFormConnect();  //�������㹫ʽ
	
	DeleteContent();

	//ClearDSPRowArray();	//	����s_dspRowArray;
	
	DeleteImgContent();

	//if (m_pTextObjSite)
	//	delete m_pTextObjSite;
}

//���Լ��Ĺ�ʽ�����
void  CTableElement::RemoveFormConnect()
{
	POSITION pos = m_mastList.GetHeadPosition();//������ʽ�����
	CTableElement* pElem;
//add by wzh 2000.5.17
	CString strF, strU;
	int iDec;
	BOOL bMatrix; 
//end by wzh 2000.5.17
	while (pos)
	{
		pElem = (CTableElement*)m_mastList.GetNext(pos);
//add by wzh 2000.5.17 
		ASSERT(pElem);
		if (pElem->m_nType & TT_formula)
		{
			pElem->FindFormulaUnit(strF, strU, iDec);//���ֹ�ʽ�͵�λ
			bMatrix = strF.Find(_T(':')) != -1;
			if (bMatrix)
			{
				pElem->m_elemList.RemoveAt(pElem->m_elemList.Find(this));
				continue;
			}
		}
//end by wzh 2000.5.17
		pElem->SetType(TT_free);
		pElem->m_stringSAV = pElem->m_stringDSP;
		pElem->m_elemList.RemoveAt(pElem->m_elemList.Find(this));
	}
	m_mastList.RemoveAll();
	RemoveFromOtherMastList();
}

//�Լ��ǹ�ʽʱ���Լ���������Ԫ�����
void  CTableElement::RemoveFromOtherMastList()
{
	POSITION pos;
	CTableElement* pElem;
	pos = m_elemList.GetHeadPosition();  //���Լ���������Ԫ�����
	while (pos)
	{
		pElem = (CTableElement*)m_elemList.GetNext(pos);
		pElem->RemoveFromMastList(this);
	}
	m_elemList.RemoveAll();
}

//�ӱ�Ԫ������ʽ�����ָ��(pE)��Ԫ
void  CTableElement::RemoveFromMastList(CTableElement* pE)
{
	if (!pE)
		return;
	POSITION pos = m_mastList.Find(pE);
	if (pos)
		m_mastList.RemoveAt(pos);
}


void CTableElement::DeleteObliqueCell()
{
	//	ȥ��б�ߵ�Ԫ�ڶ���
	while (!m_objList.IsEmpty()) 	    
		delete m_objList.RemoveHead();
}

void CTableElement::DeleteContent()
{
	DeleteObliqueCell();
	//	ȥ�����Զ���
	while (!m_AttribList.IsEmpty()) 	    
		delete m_AttribList.RemoveHead();
}

void CTableElement::DeleteImgContent(CWpsView* /*=NULL*/)
{
	if (m_pImg)
	{//	ASSERT(_FP_OFF(m_pImg)!=0xCDCD);
		ReleaseWpsImage(m_pImg);
	}
	m_pImg = NULL;
	m_extent = CSize(0, 0);
}

#ifdef _DEBUG
void CTableElement::AssertValid() const
{
	CWPSObj::AssertValid();
	if (m_pTbl)
		ASSERT_VALID(m_pTbl);
	if (m_pRow)
		ASSERT_VALID(m_pRow);
	if (m_pCol)
		ASSERT_VALID(m_pCol);
}
#endif

#ifndef _GWSREADER
// ��������ʱ�Ƿ���Ҫת������
typedef void (WINAPI* CONVPROCDW)(LPDWORD, DWORD);	// ���ֽڽӿ�
typedef void (WINAPI* CONVPROCW)(LPWORD, DWORD);	// ˫�ֽڽӿ�
extern CONVPROCDW	g_lpConvProcDW;
extern CONVPROCW	g_lpConvProcW;
#endif	// #ifndef _GWSREADER
void CTableElement::Serialize_97(KSArchive& ar)
{
	CTFPBase::Serialize_97(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		__int16 wTemp; DWORD dwTemp;
		for (int i=0; i<2; i++)
		{	ar >> wTemp;	m_uLPenStyle[i] = (UINT)wTemp;
			ar >> wTemp;	m_uLPenSize[i]  = (UINT)wTemp;
			ar >> dwTemp;	m_LPenColor[i]  = (COLORREF)dwTemp;
		}
		CString strOld;
		ar >> strOld;
		ar >> wTemp;	m_extent.cx = wTemp;
		ar >> wTemp;	m_extent.cy = wTemp;
		ar >> m_pImg;
		if (m_pImg)
			SetImgFrame(m_pImg, this);
		m_AttribList.Serialize(ar);
		//	����97���ļ�û�й�ʽ���ԣ���
		m_nType = TT_free;

		//���ֽڴ�ת��Ϊ���ֽڴ�
// ע�⣺����������������97���ļ��Ǵ���ģ�97���ļ��Ǵ���CString�ַ�����ֻ��ÿ������ǰ��
//		 һ��û�õ�0x0d�ַ���2000�ĸ�ʽ����˫�ֽ���ʽ�ġ�
/*		LPCTSTR lpszOld = (LPCTSTR)strOld;
		for (int nStrLen = 0; lpszOld[nStrLen]; nStrLen += 2);
		nStrLen = nStrLen / 2 - 1;//˫�ֽ��ַ������˵����׵�'\r'

		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		VERIFY(nStrLen == KCP_WordToTextWord(lptwBuffer,
				((LPWORD)(LPCTSTR)strOld) + 1, nStrLen));
*/
		int nStrLen = strOld.GetLength();
		if (strOld[0] == 0x0d)
		{
			strOld = strOld.Right(nStrLen - 1);
			nStrLen = strOld.GetLength();
		}
		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		nStrLen = KCP_StringToTextWord(lptwBuffer, strOld, nStrLen);
		
		m_stringSAV.Empty();
		m_stringSAV.Insert(0, lptwBuffer, nStrLen);
		delete lptwBuffer;

		//�ɰ�����±�ת��Ϊ�µ����±�
		CString strSS1, strSS2;
		KSTextString strSSBegin, strSSEnd;
		int nSSBegin, nSSEnd;
		TEXTWORD twLabel;
		for (int nSwitch = 0; nSwitch < 2; nSwitch++)
		{
			if (nSwitch)
			{
				strSS1 = "<sup>";
				strSS2 = "</sup>";
				twLabel = def_SUP;
			}
			else
			{
				strSS1 = "<sub>";
				strSS2 = "</sub>";
				twLabel = def_SUB;
			}
			strSSBegin = strSS1;
			strSSEnd = strSS2;

			int nCurPos = 0;
			while (nCurPos < m_stringSAV.GetTextSize() &&
					-1 != (nSSBegin = m_stringSAV.Find(strSS1, nCurPos)))
			{
				if (!(nSSBegin > 0 && '\\' == m_stringSAV[nSSBegin - 1]))
				{
					nSSEnd = m_stringSAV.Find(strSS2, nSSBegin);
					if (-1 == nSSEnd)
					{
						//TRACE("%s %u: %s without %s\n", __FILE__, __LINE__, strSSBegin, strSSEnd);
						break;
					}
					int nCount = nSSEnd - nSSBegin - strSSBegin.GetTextSize();
					KSTextString strL = m_stringSAV.Left(nSSBegin),
								 strR = m_stringSAV.Mid(nSSEnd + strSSEnd.GetTextSize()),
								 strB = m_stringSAV.Mid(nSSBegin + strSSBegin.GetTextSize(), nCount);
					ASSERT(strL.GetTextSize() + strL.GetTextSize() + strL.GetTextSize() == m_stringSAV.GetTextSize() + strSSEnd.GetTextSize() + strSSBegin.GetTextSize());
					KSTextString strNewB;
					for (int nIndex = 0; nIndex < nCount; nIndex++)
					{
						TEXTWORD tw = strB[nIndex];
						if (tw >= FIRSTCHAR)
							strNewB.Insert(strNewB.GetTextSize(), &twLabel, 1);
						strNewB.Insert(strNewB.GetTextSize(), &tw, 1);
					}
					m_stringSAV = strL + strNewB + strR;
				}
				nCurPos = nSSBegin + 1;
			}
		}
		//End �ɰ�����±�ת��Ϊ�µ����±�

#ifdef _DEBUG
		CString strDebug;
		TextStringToString(strDebug, m_stringSAV);
#endif
#ifndef _GWSREADER
#if	TEXTWORDBYTES == 4
		if (g_lpConvProcDW)
		{
			int nLen = m_stringSAV.GetTextSize();
			g_lpConvProcDW(m_stringSAV.GetBuffer(nLen), nLen);	// ��Ҫʱת����������
			//m_stringSAV.ReleaseBuffer(nLen);
		}
#else
		if (g_lpConvProcW)
		{
			int nLen = m_stringSAV.GetTextSize();
			g_lpConvProcW(m_stringSAV.GetBuffer(nLen), nLen);	// ��Ҫʱת����������
			//m_stringSAV.ReleaseBuffer(nLen);
		}
#endif
#endif	// #ifndef _GWSREADER
		m_stringDSP = m_stringSAV;
		m_nAutoChangeWH.cx=0;
		m_nAutoChangeWH.cy=0;
	}
	CWPSObj::SerializeObjType(ar);
}

#ifndef	_WPSREADER
//int CreateDSPRow(CWpsView* pView, CWPSObj* pObj);
void CTableElement::CreateObliqueUnit(CWpsView* pView, CString& str1, CString& str2, CString& str3, int nT)
{
	/*
	SetType(TT_oblique);
	int nHsz = GetFontHeight(NULL)/10;
	CRect	rect = m_rect;
	int		nHrc = rect.Height();
	int		nWrc = rect.Width();
	CLineObj* pLn = NULL;
	CPoint p, q, s,t;
	
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	CWPPDoc* pWPPDoc = NULL;
	if (m_pDocument && m_pDocument->QueryWPPDocType() == TRUE)
	{
		pWPPDoc = (CWPPDoc*)m_pDocument;		
	}
	//-----WPP_CODE end  -----
#endif
	if (nT == 2)
	{	p.x = 0;			p.y = nHrc;
		q.x = nWrc;			q.y = 0;
		//	һ����
		CRect rc(p, q);
		rc.NormalizeRect();
		pLn = new CLineObj(m_pDocument, rc, CLineObj::line);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pLn);
		}
		//-----WPP_CODE end  -----
#endif
		pLn->m_linepnt[0] = p;
		pLn->m_linepnt[1] = q;
		m_objList.AddTail(pLn);
		//	��һ�����ֿ�
		CLtxtObj* pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		if (str1.IsEmpty())
		{
			//str1.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			str1 = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
	//	MStringToDMString(str1, FALSE); // amend by wdb
		
		KSTextString strtw = LPCTSTR(str1);
		pOtxt->SetString(strtw, NULL);
		CRect rcNewFrame;
		pOtxt->RefreshTextObj(pView, &rcNewFrame);
		int nWrow = rcNewFrame.Width();
		
		CPoint lt(10,10);
		pOtxt->m_rect.left = lt.x; 
		pOtxt->m_rect.top = lt.y;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
		m_objList.AddTail(pOtxt);
		//	�ڶ������ֿ�
		pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		if (str3.IsEmpty())
		{
			//str3.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			str3 = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}

	//	MStringToDMString(str3, FALSE); amend by wdb
		strtw = str3;
		pOtxt->SetString(strtw, NULL);
		pOtxt->RefreshTextObj(pView, &rcNewFrame);
		nWrow = rcNewFrame.Width();

		lt.x = nWrc-10-nWrow;
		lt.y = nHrc-nHsz;
		pOtxt->m_rect.left = lt.x; 
		pOtxt->m_rect.top = lt.y;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
		m_objList.AddTail(pOtxt);
		return;
	}
	switch (nT) {
	case 4:
		p.x = 0;			p.y = 0;
		q.x = nWrc;			q.y = nHrc;
		s.x = nWrc/2;		s.y = 0;
		t = q;
		break;
	case 5:
		p.x = 0;			p.y = 0;
		q.x = nWrc;			q.y = nHrc;
		s.x = 0;			s.y = nHrc/2;
		t = q;
		break;
	case 6:
		p.x = 0;			p.y = 0;
		q.x = nWrc/2;		q.y = nHrc;
		s = p;
		t.x = nWrc;			t.y = nHrc/2;
		break;
	case 7:
		p.x = 0;			p.y = 0;
		q.x = nWrc;			q.y = nHrc;
		s = p;
		t.x = nWrc;			t.y = nHrc/2;
		break;
	case 8:
		p.x = 0;			p.y = 0;
		q.x = nWrc;			q.y = nHrc;
		s = p;
		t.x = nWrc/2;		t.y = nHrc;
		break;
	case 9:
		p.x = 0;			p.y = nHrc/2;
		q.x = nWrc;			q.y = 0;
		s.x = nWrc/2;		s.y = nHrc;
		t = q;
		break;
	case 10:
		p.x = 0;			p.y = nHrc/2;
		q.x = nWrc;			q.y = 0;
		s.x = 0;			s.y = nHrc;
		t = q;
		break;
	case 11:
		p.x = 0;			p.y = nHrc;
		q.x = nWrc;			q.y = 0;
		s.x = nWrc/2;		s.y = nHrc;
		t = q;
		break;
	case 12:
		p.x = 0;			p.y = nHrc;
		q.x = nWrc/2;		q.y = 0;
		s = p;
		t.x = nWrc;			t.y = nHrc/2;
		break;
	case 13:
		p.x = 0;			p.y = nHrc;
		q.x = nWrc/2;		q.y = 0;
		s = p;
		t.x = nWrc;			t.y = 0;
		break;
	case 14:
		p.x = 0;			p.y = nHrc;
		q.x = nWrc;			q.y = 0;
		s = p;
		t.x = nWrc;			t.y = nHrc/2;
		break;
	}
	//	��һ����
	CRect rc(p, q);
	rc.NormalizeRect();
	pLn = new CLineObj(m_pDocument, rc, CLineObj::line);
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	if (pWPPDoc != NULL)
	{
		pWPPDoc->SetObjAttribWithDefault(pLn);
	}
	//-----WPP_CODE end  -----
#endif
	pLn->m_linepnt[0] = p;
	pLn->m_linepnt[1] = q;
	m_objList.AddTail(pLn);
	//	�ڶ�����
	rc = CRect(s, t);
	rc.NormalizeRect();
	pLn = new CLineObj(m_pDocument, rc, CLineObj::line);
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	if (pWPPDoc != NULL)
	{
		pWPPDoc->SetObjAttribWithDefault(pLn);
	}
	//-----WPP_CODE end  -----
#endif
	pLn->m_linepnt[0] = s;
	pLn->m_linepnt[1] = t;
	m_objList.AddTail(pLn);
	//	��һ�����ֿ�
	CLtxtObj* pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	if (pWPPDoc != NULL)
	{
		pWPPDoc->SetObjAttribWithDefault(pOtxt);
		pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
	}
	//-----WPP_CODE end  -----
#endif
	if (str1.IsEmpty())
	{
		//str1.LoadString(IDS_OBLIQUETEXT); //"������"
		#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
		str1 = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
	}
//	MStringToDMString(str1, FALSE); // amend by wdb
	KSTextString strtw = LPCTSTR(str1);
	
	pOtxt->SetString(strtw, NULL);
	CRect rcNewFrame;
	pOtxt->RefreshTextObj(pView, &rcNewFrame);
	int nWrow = rcNewFrame.Width();

	CPoint lt(10,10);
	pOtxt->m_rect.left = lt.x; 
	pOtxt->m_rect.top = lt.y;
	pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
	pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
	m_objList.AddTail(pOtxt);
	//	�ڶ������ֿ�
	pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	if (pWPPDoc != NULL)
	{
		pWPPDoc->SetObjAttribWithDefault(pOtxt);
		pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
	}
	//-----WPP_CODE end  -----
#endif
	if (str2.IsEmpty())
	{
		//str2.LoadString(IDS_OBLIQUETEXT); //"������"
		#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
		str2 = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
	}

	//	MStringToDMString(str2, FALSE); // amend by wdb
	strtw = str2;
	pOtxt->SetString(strtw, NULL);
	pOtxt->	RefreshTextObj(pView, &rcNewFrame);
	nWrow = rcNewFrame.Width();
	//nWrow = CreateDSPRow(pView, pOtxt)/10;

	lt.x += 10;
	lt.y = (nHrc-nHsz)/2;
	pOtxt->m_rect.left = lt.x; 
	pOtxt->m_rect.top = lt.y;
	pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
	pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
	m_objList.AddTail(pOtxt);
	//	���������ֿ�
	pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	if (pWPPDoc != NULL)
	{
		pWPPDoc->SetObjAttribWithDefault(pOtxt);
		pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
	}
	//-----WPP_CODE end  -----
#endif
	if (str3.IsEmpty())
	{
		//str3.LoadString(IDS_OBLIQUETEXT); //"������"
		#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
		str3 = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
	}

	//	MStringToDMString(str3, FALSE);
	strtw = str3;
	pOtxt->SetString(strtw, NULL);
	pOtxt->RefreshTextObj(pView, &rcNewFrame);
	nWrow = rcNewFrame.Width();
	//nWrow = CreateDSPRow(pView, pOtxt)/10;

	lt.x += 10;
	lt.y = nHrc-nHsz-10;
	pOtxt->m_rect.left = lt.x; 
	pOtxt->m_rect.top = lt.y;
	pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
	pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
	m_objList.AddTail(pOtxt);
	*/
}
#endif	//_WPSREADER

void SetFrameTextProp(CFrameText* pFT);
#ifndef	_WPSREADER
void CTableElement::CreateObliqueUnit(CWpsView* pView, CPoint& down, CPoint& last)
{
	/*
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	CWPPDoc* pWPPDoc = NULL;
	if (m_pDocument && m_pDocument->QueryWPPDocType() == TRUE)
	{
		pWPPDoc = (CWPPDoc*)m_pDocument;		
	}
	//-----WPP_CODE end  -----
#endif

	int nHsz = GetFontHeight(NULL)/10;
	if (!(m_nType & TT_oblique))
	{
		SetType(TT_oblique);
		CRect	rect = m_rect;
		int		nHrc = rect.Height();
		int		nWrc = rect.Width();
		CString str;
		TextStringToString(str, m_stringDSP);
		CString strT;
		int nPos = str.Find('\r');
		if (nPos == -1)
			strT = str;
		else
			strT = str.Left(nPos);	
		
		CLtxtObj* pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		if (strT.IsEmpty())
		{
			//strT.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			strT = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		
		//	MStringToDMString(strT, FALSE); //amend by wdb
		KSTextString str1 = strT;
		pOtxt->SetString(str1, NULL);
		CRect rcNewFrame;
		pOtxt->RefreshTextObj(pView, &rcNewFrame);
		int nWrow = rcNewFrame.Width();
		//int nWrow = CreateDSPRow(pView, pOtxt)/10;

		CPoint lt = GetObliqueLeftTop(1, 0, nHsz*10, nHrc*10, nWrc*10, nWrow*10);
		pOtxt->m_rect.left = lt.x/10; 
		pOtxt->m_rect.top = lt.y/10;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
		m_objList.AddTail(pOtxt);
		//	��һ����
		CLineObj* pLn = new CLineObj(m_pDocument, CRect(0, 0, nWrc, nHrc-1), CLineObj::line);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pLn);
		}
		//-----WPP_CODE end  -----
#endif
		pLn->m_linepnt[0] = CPoint(0,0);
		pLn->m_linepnt[1] = CPoint(nWrc, nHrc-1);
		m_objList.AddTail(pLn);
		//	�ڶ�������
		CString strOut;
		if (nPos != -1)
		{	strT = str.Mid(nPos+1);	//	����"\r"
			nPos = 0;
			char sz = strT[nPos];
			int nCnt = strT.GetLength();
			while (nPos < nCnt)
			{	if (sz == '\r')
				{	nPos += 1;
					sz = strT[nPos];
					continue;
				}
				strOut += strT[nPos];
				nPos ++;
				if (nPos < nCnt)
					sz = strT[nPos];
			}
		}
		strT = strOut;
		pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		if (strT.IsEmpty())
		{
			//strT.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			strT = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		//	MStringToDMString(strT, FALSE); // amend by wdb
		str1 = strT;
		pOtxt->SetString(str1, NULL);
		pOtxt->RefreshTextObj(pView, &rcNewFrame);
		nWrow = rcNewFrame.Width();
		//nWrow = CreateDSPRow(pView, pOtxt)/10;

		lt = GetObliqueLeftTop(1, 1, nHsz*10, nHrc*10, nWrc*10, nWrow*10);
		pOtxt->m_rect.left = lt.x/10; 
		pOtxt->m_rect.top = lt.y/10;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz;
		m_objList.AddTail(pOtxt);
	}
	else	//	��һ���ߣ���һ������
	{	CTableElement* pElem = (CTableElement*)pView->GetCurObj();
		down.Offset(-pElem->m_rect.TopLeft());
		last.Offset(-pElem->m_rect.TopLeft());
		AdjustObliLinePoint(down, 1);
		AdjustObliLinePoint(last, 2);
		CRect rc(down, last);
		rc.NormalizeRect();
		CLineObj* pLn = new CLineObj(m_pDocument, rc, CLineObj::line);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pLn);
		}
		//-----WPP_CODE end  -----
#endif
		pLn->m_linepnt[0] = down;
		pLn->m_linepnt[1] = last;
		m_objList.AddTail(pLn);
		//	����
		CLtxtObj* pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		OpenObliqueTextDlg(pView, pOtxt);
		CRect rcNewFrame;
		pOtxt->RefreshTextObj(pView, &rcNewFrame);
		int nWrow = rcNewFrame.Width();
		//int nWrow = CreateDSPRow(pView, pOtxt)/10;

		CPoint cnt = rc.CenterPoint();
		cnt.x = min(max(0, pElem->m_rect.Width()-nWrow), cnt.x); 
		cnt.y = min(max(0, pElem->m_rect.Height()-nHsz), cnt.y); 
		pOtxt->m_rect.left = cnt.x; 
		pOtxt->m_rect.top = cnt.y;
		pOtxt->m_rect.right = cnt.x+nWrow;
		pOtxt->m_rect.bottom = cnt.y+nHsz;
		m_objList.AddTail(pOtxt);
	}
	*/
}
#endif	//_WPSREADER
int MStringToDMString(CString&);
void CTableElement::Serialize_98(KSArchive& ar)
{
	CTFPBase::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		for (int i=0; i<2; i++)
		{
			ar.Write(&m_uLPenStyle[i], sizeof(UINT));
			ar.Write(&m_uLPenSize[i], sizeof(UINT));
			ar.Write(&m_LPenColor[i], sizeof(COLORREF));
		}
		ar.Write(&m_nType, sizeof(int));

		//(�°�����±�ת��Ϊ�ɵ����±�(for Export WPS2000)
#define WPS2000_SUP_BEGIN	"<sup>"
#define WPS2000_SUP_END		"</sup>"
#define	WPS2000_SUB_BEGIN	"<sub>"
#define WPS2000_SUB_END		"</sub>"
		CString strSAV;
		KSTextString strText;
		LPCTEXTWORD lptwText = m_stringSAV;
		TEXTWORD tw;
		strText = "\r";
		int len;
		int i = 0;
		for (i = 0, len = m_stringSAV.GetTextSize(); i < len; i++)
		{
			tw = lptwText[i];
			if (def_SUP == tw)
			{
				strText += WPS2000_SUP_BEGIN;
				strText += lptwText[++i];
				strText += WPS2000_SUP_END;
			}
			else if (def_SUB == tw)
			{
				strText += WPS2000_SUB_BEGIN;
				strText += lptwText[++i];
				strText += WPS2000_SUB_END;
			}
			else
				strText += tw;
		}
		::TextStringToString(strSAV, strText);
		::MStringToDMString(strSAV);
		ar << strSAV;
		//)�°�����±�ת��Ϊ�ɵ����±�(for Export WPS2000)

		ar << m_extent;
		ar << m_pImg;
		if (m_nType & TT_oblique || m_nType & TT_frametext)	//	sjz 02-5-16
			m_objList.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		for (int i=0; i<2; i++)
		{
			ar.Read(&m_uLPenStyle[i], sizeof(UINT));
			ar.Read(&m_uLPenSize[i], sizeof(UINT));
			ar.Read(&m_LPenColor[i], sizeof(COLORREF));
		}
		ar.Read(&m_nType, sizeof(int));
		CString strOld;
		ar >> strOld;
		
		LPCTSTR lpszOld = (LPCTSTR)strOld;
		int nStrLen = 0;
		for (nStrLen = 0; lpszOld[nStrLen]; nStrLen += 2);
		nStrLen = nStrLen / 2 - 1;//˫�ֽ��ַ������˵����׵�'\r'

		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		VERIFY(nStrLen == KCP_WordToTextWord(lptwBuffer,
				((LPWORD)(LPCTSTR)strOld) + 1, nStrLen));
		m_stringSAV.Insert(0, lptwBuffer, nStrLen);
		delete lptwBuffer;

#ifdef _DEBUG
		CString strDebug;
		TextStringToString(strDebug, m_stringSAV);
#endif
		//�ɰ�����±�ת��Ϊ�µ����±�
		CString strSS1, strSS2;
		KSTextString strSSBegin, strSSEnd;
		int nSSBegin, nSSEnd;
		TEXTWORD twLabel;
		for (int nSwitch = 0; nSwitch < 2; nSwitch++)
		{
			if (nSwitch)
			{
				strSS1 = "<sup>";
				strSS2 = "</sup>";
				twLabel = def_SUP;
			}
			else
			{
				strSS1 = "<sub>";
				strSS2 = "</sub>";
				twLabel = def_SUB;
			}
			strSSBegin = strSS1;
			strSSEnd = strSS2;

			int nCurPos = 0;
			while (nCurPos < m_stringSAV.GetTextSize() &&
					-1 != (nSSBegin = m_stringSAV.Find(strSS1, nCurPos)))
			{
				if (!(nSSBegin > 0 && '\\' == m_stringSAV[nSSBegin - 1]))
				{
					nSSEnd = m_stringSAV.Find(strSS2, nSSBegin);
					if (-1 == nSSEnd)
					{
						//TRACE("%s %u: %s without %s\n", __FILE__, __LINE__, strSSBegin, strSSEnd);
						break;
					}
					int nCount = nSSEnd - nSSBegin - strSSBegin.GetTextSize();
					KSTextString strL = m_stringSAV.Left(nSSBegin),
								 strR = m_stringSAV.Mid(nSSEnd + strSSEnd.GetTextSize()),
								 strB = m_stringSAV.Mid(nSSBegin + strSSBegin.GetTextSize(), nCount);
					ASSERT(strL.GetTextSize() + strR.GetTextSize() + strB.GetTextSize()  + strSSEnd.GetTextSize() + strSSBegin.GetTextSize() == m_stringSAV.GetTextSize());
					KSTextString strNewB;
					for (int nIndex = 0; nIndex < nCount; nIndex++)
					{
						TEXTWORD tw = strB[nIndex];
						if (tw >= FIRSTCHAR)
							strNewB.Insert(strNewB.GetTextSize(), &twLabel, 1);
						strNewB.Insert(strNewB.GetTextSize(), &tw, 1);
					}
					m_stringSAV = strL + strNewB + strR;
				}
				nCurPos = nSSBegin + 1;
			}
		}
		//End �ɰ�����±�ת��Ϊ�µ����±�

#ifdef _DEBUG
		TextStringToString(strDebug, m_stringSAV);
#endif
#ifndef _GWSREADER
#if	TEXTWORDBYTES == 4
		if (g_lpConvProcDW)
		{
			int nLen = m_stringSAV.GetTextSize();
			g_lpConvProcDW(m_stringSAV.GetBuffer(nLen), nLen);	// ��Ҫʱת����������
			//m_stringSAV.ReleaseBuffer(nLen);
		}
#else
		if (g_lpConvProcW)
		{
			int nLen = m_stringSAV.GetTextSize();
			g_lpConvProcW(m_stringSAV.GetBuffer(nLen), nLen);	// ��Ҫʱת����������
			//m_stringSAV.ReleaseBuffer(nLen);
		}
#endif
#endif	// #ifndef _GWSREADER
		ar >> m_extent;
		ar >> m_pImg;
		m_stringDSP = m_stringSAV;//������ʽҪ�����(��)ȥ�����趨m_stringDSP
		if (m_pImg)
			SetImgFrame(m_pImg, this);
		if (m_nType & TT_oblique || m_nType & TT_frametext)	//	sjz 02-5-16
			m_objList.Serialize(ar);
		m_nAutoChangeWH.cx=0;
		m_nAutoChangeWH.cy=0;
	}
	m_AttribList.Serialize(ar);
	CWPSObj::SerializeObjType(ar);
}

TextLineMode ParseTBLELEM_LineMode(KSTextString&);
void MakeTextStringWithBOOL(KSTextString&, BOOL);
BOOL ParseTextStringWithBOOL(KSTextString&);
void MakeTBLELEM_LineMode(KSTextString&, TextLineMode);

#ifndef __WPSRW_WPSSERIAL_H__
#include "wpsserial.h"
#endif

class _CTableElement : public CTableElement // wps2002-io-table, by tsingbo
{
public:
	STDMETHODIMP Serialize_Write_02(KSArchive& ar);
	STDMETHODIMP Serialize_Read_02(KSArchive& ar);
};

STDMETHODIMP TableElementProp_Serialize_Write(CObList& AttribList, KSArchive& ar);
STDMETHODIMP TableElementProp_Serialize_Read(CObList& AttribList, KSArchive& ar);

STDMETHODIMP _CTableElement::Serialize_Write_02(KSArchive& ar)
{
	CTFPBase::Serialize_01(ar);
	
	KWPSMainWriter wr;
	wr.Attach(&ar);

	WPSCellData rec;
	for (int i = 0; i < 4; ++i)
	{
		rec.brc[i].LPenStyle = m_uLPenStyle[i];
		rec.brc[i].LPenSize	 = m_uLPenSize[i];
		rec.brc[i].LPenColor = m_LPenColor[i];
	}
	rec.nType		= m_nType;
	rec.LineMode	= m_LineMode;
	rec.fDefText	= m_bDefText;
	rec.fHasImg		= (m_pImg ? 1 : 0);
	rec.extent		= m_extent;
	_WPSWriteRecord(wr, TAG_WPSCellData, &rec, sizeof(rec));
	if (m_pImg)
	{
		m_pImg->Serialize(ar);
	}

	// {{ wps2002-io-table-richcell, by sjz 02-5-16
	if ((m_nType & TT_oblique) || (m_nType & TT_frametext))
	{
		m_objList.Serialize(ar);
	}
	else
	{
		ar << m_stringSAV;
		TableElementProp_Serialize_Write(m_AttribList, ar);
	}
	return S_OK;
}

STDMETHODIMP _CTableElement::Serialize_Read_02(KSArchive& ar)
{
	CTFPBase::Serialize_01(ar);

	HRESULT hr;
	_KWPSRecordHeader hdr;
	KWPSMainReader wr;
	WPSCellData rec;
	wr.Attach(&ar);
	
	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSCellData, hr = E_UNEXPECTED);
	
	wr.Read(&rec, sizeof(rec));
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());
	
	{
		for (int i = 0; i < 4; ++i)
		{
			m_uLPenStyle[i]	= rec.brc[i].LPenStyle;
			m_uLPenSize[i]	= rec.brc[i].LPenSize;
			m_LPenColor[i]	= rec.brc[i].LPenColor;
		}
	}
	m_nType		= rec.nType;
	m_LineMode	= (TextLineMode)rec.LineMode;
	m_bDefText	= rec.fDefText;
	m_extent	= rec.extent;
	
	ASSERT(rec.fHasImg <= 1); // {{ only can be: 0/1
	if (rec.fHasImg == 1)
	{
		m_pImg = CreateWpsImage();
		m_pImg->Serialize(ar);
		SetImgFrame(m_pImg, this);
	}
	m_nAutoChangeWH.cx=0;
	m_nAutoChangeWH.cy=0;

	// {{ wps2002-io-table-richcell, by sjz 02-5-16
	if ((m_nType & TT_oblique) || (m_nType & TT_frametext))
	{
		m_objList.Serialize(ar);

		//��Ԫ���ֿ򸸶��� [wxb 2002-6-22]
		if (0 != (m_nType & TT_frametext))
		{
			//@@todo:�����������Ƿ��Ҫ
			//((CFrameText*)(m_objList.GetHead()))->m_pParentTableElement = this;
			//((CFrameText*)(m_objList.GetHead()))->SetParentPage(0);
		}
	}
	else
	{
		ar >> m_stringSAV;
		m_stringDSP = m_stringSAV; //������ʽҪ�����(��)ȥ�����趨m_stringDSP
		TableElementProp_Serialize_Read(m_AttribList, ar);
	}
	return S_OK;
	
KS_EXIT_HERE:
	return WPSIOThrowError(hr);
}

void CTableElement::Serialize_01(KSArchive& ar)
{
	if (g_fCompoundFile) // wps2002-io-table, serialize new version by tsingbo
	{
		if (ar.IsStoring())
			((_CTableElement*)this)->Serialize_Write_02(ar);
		else
			((_CTableElement*)this)->Serialize_Read_02(ar);
		return;
	}
	// wps2002-io-table, serialize old version by tsingbo
	CTFPBase::Serialize_01(ar);
	if (ar.IsStoring())
	{
		for (int i=0; i<2; i++)
		{
			ar.Write(&m_uLPenStyle[i], sizeof(UINT));
			ar.Write(&m_uLPenSize[i], sizeof(UINT));
			ar.Write(&m_LPenColor[i], sizeof(COLORREF));
		}
		ar.Write(&m_nType, sizeof(int));

		KSTextString strText = m_stringSAV;
		// �����ְ�ʽ����
		MakeTBLELEM_LineMode(strText, m_LineMode);
		//��Ĭ��������Ϣ����
		::MakeTextStringWithBOOL(strText, m_bDefText);
		ar << strText;

		ar << m_extent;
		ar << m_pImg;
	}
	else
	{
		for (int i=0; i<2; i++)
		{
			ar.Read(&m_uLPenStyle[i], sizeof(UINT));
			ar.Read(&m_uLPenSize[i], sizeof(UINT));
			ar.Read(&m_LPenColor[i], sizeof(COLORREF));
		}
		ar.Read(&m_nType, sizeof(int));

		//��ȡĬ��������Ϣ
		ar >> m_stringSAV;
		m_bDefText = ::ParseTextStringWithBOOL(m_stringSAV);
		// ��ȡ���ְ�ʽ
		m_LineMode = ParseTBLELEM_LineMode(m_stringSAV);

#if	TEXTWORDBYTES == 4
		if (g_lpConvProcDW)
		{
			int nLen = m_stringSAV.GetTextSize();
			g_lpConvProcDW(m_stringSAV.GetBuffer(nLen), nLen);	// ��Ҫʱת����������
		}
#else
		if (g_lpConvProcW)
		{
			int nLen = m_stringSAV.GetTextSize();
			g_lpConvProcW(m_stringSAV.GetBuffer(nLen), nLen);	// ��Ҫʱת����������
		}
#endif
		ar >> m_extent;
		ar >> m_pImg;
		m_stringDSP = m_stringSAV;//������ʽҪ�����(��)ȥ�����趨m_stringDSP
		if (m_pImg)
			SetImgFrame(m_pImg, this);		
		m_nAutoChangeWH.cx=0;
		m_nAutoChangeWH.cy=0;
	}
	if (m_nType & TT_oblique)
	{
		m_objList.Serialize(ar);
	}
	m_AttribList.Serialize(ar);
	CWPSObj::SerializeObjType(ar);
}

void CTableElement::GetString( KSTextString& str, CWpsView* pView/*= NULL*/ ) 
{
	if (IsElemFrameText())
		((CFrameText*)(GetObjList()->GetHead()))->GetCalacTextString(str);
	else if (IsObliqueElem())
	{
		KSTextString strL;
		CLtxtObj* pLObj;
		for (POSITION pos = m_objList.GetHeadPosition(); pos;)
		{
			pLObj = (CLtxtObj*)m_objList.GetNext(pos); ASSERT_VALID (pLObj);
			if (pLObj->IsKindOf(RUNTIME_CLASS(CLtxtObj)))
			{
				pLObj->GetString(strL);
				str += strL;
			}
		}
	}
	else
		str = m_stringDSP;
}

void CTableElement::SetString(KSTextString& str, CWpsView* pView) 
{
	ASSERT_VALID(this);
	int type=GetType();
	if (type & TT_oblique)
		return;
	if (type & TT_frametext)
		return;
	BOOL bUpdate = (m_stringDSP != str);
	//����δ��ȫ���ɣ����ߴ�С����Ч�ģ���ִ���Զ��Ŵ����
	if (NULL == m_pTbl || m_rect.Height() > m_pTbl->m_rect.Height() || m_rect.Width() > m_pTbl->m_rect.Width())
		bUpdate = FALSE;

	if (type&TT_formula || type&TT_autodata)
	{	//ASSERT(m_stringDSP != str);
		//ASSERT(str[0] != '\r');
		//m_stringDSP = '\r';
		//m_stringDSP	+= (char)0;
		m_stringDSP = str;
	}
	else
	{//	ע�⣺don't use "˫�ֽڴ�" !=��== "˫�ֽڴ�"
	/*	CString str1 = "\r2";
		MStringToDMString(str1);
		CString str2 = "\r123";
		MStringToDMString(str2);
		if (str1 == str2)
			str1 = str2;
		else
			str2 = str1;
		if (str1.Compare(str2) != 0)
			;
		if (m_stringSAV == str)
			;
	*/
		/*if (str.IsEmpty())
		{	m_stringSAV = '\r';
			m_stringSAV	+= (char)0;
		}
		else if (str[0] != '\r')
		{	m_stringSAV = '\r';
			m_stringSAV	+= (char)0;
			m_stringSAV += str;
		}
		else
			m_stringSAV = str;*/
		
		m_stringSAV = str;
		m_stringDSP = m_stringSAV;
	}	
}

#ifndef	_WPSREADER
int CTableElement::GetImgTypeID()
{
	if (m_pImg)
	{
		return m_pImg->GetImgSizeType();
	}
	else
	{
		return 0;
	}
}
#endif	//_WPSREADER

CPoint GetObliqueLeftTop(int nObli, int nRowID, int nHsz, int nHrc, int nWrc, int nWrow);
//	����б�߱�Ԫ
void CTableElement::ReCreateObliqueUnit(int nObli)
{
	ConvertObliqueUnit(nObli);
	//	ת����ɾ��б������
	RemoveObjAttrib(SETOBLIQUELINE);
}

BOOL CTableElement::RemoveObjAttrib( WORD nCCid )
{
	CCtrlCode* pCC;
	POSITION posCur;
	for ( POSITION pos = m_AttribList.GetHeadPosition(); pos;)
	{	posCur = pos;
	    pCC = (CCtrlCode*)m_AttribList.GetNext(pos);
	    if ( pCC->GetCodeID() == nCCid )
	    {	delete pCC;
			m_AttribList.RemoveAt( posCur );
			return TRUE;
		}
	}
	return FALSE;
}


//LLG_MODIFY_2001_5_12
//Ϊ������ʾ�ĵ��£������б�߼���������Ӧ��ɫ����...
void CTableElement::ConvertObliqueUnit(int nObli)
{
	ASSERT(nObli > 0);
	SetType(TT_oblique);
	int nHsz = GetFontHeight(NULL);
	CRect	rect = m_rect;
	int		nHrc = rect.Height();
	int		nWrc = rect.Width();
	CString str;
	TextStringToString(str, m_stringSAV);
	CString strT;
	int nPos = str.Find('\r');
	if (nPos != -1)
		strT = str.Left(nPos);
	else
	{
		//strT.LoadString(IDS_OBLIQUETEXT); //"������"
		#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
		strT = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
	}
	
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	CWPPDoc* pWPPDoc = NULL;
	if (m_pDocument && m_pDocument->QueryWPPDocType() == TRUE)
	{
		pWPPDoc = (CWPPDoc*)m_pDocument;		
	}
	//-----WPP_CODE end  -----
#endif

	CLtxtObj* pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);	
#ifdef WPP_ONLY
	//-----WPP_CODE start-----
	if (pWPPDoc != NULL)
	{
		pWPPDoc->SetObjAttribWithDefault(pOtxt);
		pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
	}
	//-----WPP_CODE end  -----
#endif

	if (strT.IsEmpty())
	{
		//strT.LoadString(IDS_OBLIQUETEXT); //"������"
		#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
		strT = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
	}
	int nO = strT.GetLength();
//	MStringToDMString(strT, FALSE); //amend by wdb
	KSTextString str1 = strT;
	pOtxt->SetString(str1, NULL);
	CRect rcNewFrame;
	//CWpsView* pView = GetCurView();	ASSERT_VALID(pView);
	//pOtxt->RefreshTextObj(pView, &rcNewFrame);
	int	nWrow = rcNewFrame.Width();//MulDiv(nHsz, nO, 2);
	CPoint lt = GetObliqueLeftTop(nObli, 0, nHsz, nHrc*10, nWrc*10, nWrow*10);
	pOtxt->m_rect.left = lt.x/10; 
	pOtxt->m_rect.top = lt.y/10;
	pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
	pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz/10;
	m_objList.AddTail(pOtxt);
	CLineObj * pLn = NULL;
	if (nObli == 1)
	{	//	��һ����
		pLn = new CLineObj(m_pDocument, CRect(0, 0, nWrc, nHrc-1), CLineObj::line);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pLn);
		}
		//-----WPP_CODE end  -----
#endif
		pLn->m_linepnt[0] = CPoint(0,0);
		pLn->m_linepnt[1] = CPoint(nWrc, nHrc-1);

		m_objList.AddTail(pLn);
		//	�ڶ�������
		if (nPos != -1)
			str = str.Mid(nPos+1);
		else
		{
			//str.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			str = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);		
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif

		if (str.IsEmpty())
		{
			//str.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			str = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		nO = str.GetLength();
	//	MStringToDMString(str, FALSE); // amend by wdb
		KSTextString str1 = str;
		pOtxt->SetString(str1, NULL);
		//pOtxt->RefreshTextObj(pView, &rcNewFrame);
		nWrow = rcNewFrame.Width();	//nWrow = MulDiv(nHsz, nO, 2);
		lt = GetObliqueLeftTop(nObli, 1, nHsz, nHrc*10, nWrc*10, nWrow*10);
		pOtxt->m_rect.left = lt.x/10; 
		pOtxt->m_rect.top = lt.y/10;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz/10;
		m_objList.AddTail(pOtxt);
	}
	else
	{
		ASSERT(nObli == 2);
		//	��һ����
		pLn = new CLineObj(m_pDocument, CRect(nWrc/2, 0, nWrc, nHrc-1), CLineObj::line);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pLn);
		}
		//-----WPP_CODE end  -----
#endif
		pLn->m_linepnt[0] = CPoint(nWrc/2, 0);
		pLn->m_linepnt[1] = CPoint(nWrc, nHrc-1);
		m_objList.AddTail(pLn);
		//	�ڶ�������
		if (nPos != -1)
		{	str = str.Mid(nPos+1);
			nPos = str.Find('\r');
			strT = str.Left(nPos);
		}
		else
		{
			//strT.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			strT = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		if (strT.IsEmpty())
		{
			//strT.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			strT = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		nO = strT.GetLength();
	//	MStringToDMString(strT, FALSE); // amend by wdb
		KSTextString str1 = strT;
		pOtxt->SetString(str1, NULL);
		//pOtxt->RefreshTextObj(pView, &rcNewFrame);
		nWrow = rcNewFrame.Width();	//nWrow = MulDiv(nHsz, nO, 2);
		lt = GetObliqueLeftTop(nObli, 1, nHsz, nHrc*10, nWrc*10, nWrow*10);
		pOtxt->m_rect.left = lt.x/10; 
		pOtxt->m_rect.top = lt.y/10;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz/10;
		m_objList.AddTail(pOtxt);
		//	�ڶ�����
		pLn = new CLineObj(m_pDocument, CRect(0, nHrc/2, nWrc, nHrc-1), CLineObj::line);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pLn);
		}
		//-----WPP_CODE end  -----
#endif
		pLn->m_linepnt[0] = CPoint(0, nHrc/2);
		pLn->m_linepnt[1] = CPoint(nWrc, nHrc-1);
		m_objList.AddTail(pLn);
		//	����������
		if (nPos != -1)
			str = str.Mid(nPos+1);
		else
		{
			//str.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			str = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		pOtxt = new CLtxtObj(m_pDocument, CRect(0,0,0,0), CLtxtObj::oblique);
#ifdef WPP_ONLY
		//-----WPP_CODE start-----
		if (pWPPDoc != NULL)
		{
			pWPPDoc->SetObjAttribWithDefault(pOtxt);
			pOtxt->SetBkMode(TRANSPARENT);//͸��(OPAQUE:��͸��)
		}
		//-----WPP_CODE end  -----
#endif
		if (str.IsEmpty())
		{
			//str.LoadString(IDS_OBLIQUETEXT); //"������"
			#pragma prompt("Ӳ����,ֻ�����ڼ������İ�")
			str = _T("������"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
		}
		nO = str.GetLength();
	//	MStringToDMString(str, FALSE); // amend by wdb
		str1 = str;
		pOtxt->SetString(str1, NULL);
		//pOtxt->RefreshTextObj(pView, &rcNewFrame);
		nWrow = rcNewFrame.Width();	//nWrow = MulDiv(nHsz, nO, 2);
		lt = GetObliqueLeftTop(nObli, 2, nHsz, nHrc*10, nWrc*10, nWrow*10);
		pOtxt->m_rect.left = lt.x/10; 
		pOtxt->m_rect.top = lt.y/10;
		pOtxt->m_rect.right = pOtxt->m_rect.left + nWrow;
		pOtxt->m_rect.bottom = pOtxt->m_rect.top + nHsz/10;
		m_objList.AddTail(pOtxt);
	}
	KSTextString strText("");
	SetString(strText, NULL);
	m_stringSAV = m_stringDSP;
}

/////////////////////////////////////////////////////////////////////////////
CTableElement* g_curTableElement = NULL;
//nMode:  0-NormalText  1-SupText  2-SubText
//���������������Ի����� [wxb 2002-4-25]
BOOL FilterSupSub(LPCTEXTWORD lptwText,
				  LPWSTR lpszEng, LPWSTR lpszChn,
				  int& nFilteredEng, int& nFilteredChn,
				  int nMode = 0)
{
	if (0 != nMode && 1 != nMode && 2 != nMode)
		{ ASSERT(0); return FALSE; }

	nFilteredEng = nFilteredChn = 0;
	if (g_curTableElement)
	{
		ASSERT_VALID(g_curTableElement);
		return g_lpKXCodePageVI->FilterSupSub(lptwText, lpszEng, lpszChn,
					nFilteredEng, nFilteredChn, nMode);
	}
	return TRUE;
}

////////////////////////////////////////////////////////////////////////

int CTableElement::GetObliqueLine97()
{
	CCtrlCode* pCD;
	for ( POSITION pos = m_AttribList.GetHeadPosition(); pos;)
	{	pCD = (CCtrlCode*)m_AttribList.GetNext(pos);
		if ( pCD->GetCodeID() == SETOBLIQUELINE )
			return ((CCtrlCode_ObliqueLine*)pCD)->GetObliqueLine();
	}
	return 0;
}

BOOL CTableElement::IsSetHide97()
{
	//	���ڱ����صı�Ԫ�����ᱻѡ�У�Ҳ�Ͳ�����c_elemProp���ʲ�������ȡ
	//	�ӱ���Ԫ������������ DISPLAY ����
	CCtrlCode* pCC;
	for ( POSITION pos = m_AttribList.GetHeadPosition(); pos;)
	{   pCC = (CCtrlCode*)m_AttribList.GetNext(pos);
	    if ( pCC->GetCodeID() == SETDSP &&
	    	 ((CCtrlCode_DISPLAY*)pCC)->IsDisp() == FALSE )
			return TRUE;
	}
	return FALSE;
}

//	unit 0.01mm
int CTableElement::GetFontHeight(CWpsView* pView)
{
	//if ( pView && pView->GetCurObj() == this )
	//	return m_pTbl->c_elemProp.nSZH;
	CCtrlCode_Size* pCC = (CCtrlCode_Size*)m_pTbl->m_AttribArray[ CC_SIZE ];
	CCtrlCode* pCD;
	for ( POSITION pos = m_AttribList.GetHeadPosition(); pos;)
	{
		pCD = (CCtrlCode*)m_AttribList.GetNext(pos);
		if ( pCD->GetCodeID() == SETFONTSIZE )
		{	pCC = (CCtrlCode_Size*)pCD;	break;	}
	}
	return m_pTbl->GetlfH( pCC );
}

//void CTableElement::Draw(CDC* pDC, CWpsView* pView, IColorScheme* pICS)
//{
//	ASSERT_VALID(this);
//	//	������Ԫ��ǰ���Ա�
////	TRACE ("c_elemProp.nSZH=%u\n", m_pTbl->c_elemProp.nSZH);
////	CreateTblElemProp();
//	CDSPElemProp* pProp = &m_pTbl->c_elemProp;
//	CRect rect = m_rect;
////	pView->DocToClient(rect);
//	rect.OffsetRect(1,1);
//	//	Ϊ�˱����������ʾ��Ч��
////	if (m_pImg)			//	����ͼƬ
////	{
////		SetClipRgnViewportOrg(pDC, pView, TRUE);
////		DrawDIB(pDC, pView);
////		//pDC->SelectClipRgn(NULL);
////		WPSSelectClipRgnEx(pDC->GetSafeHdc(),NULL);
////	}
////	else
////	{	//	����Ԫ����(��ɫ/����)
////		//	set brush
////		int nOldBkMode = pDC->GetBkMode();
////		COLORREF clrOldBk = pDC->GetBkColor();
////		CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
//		
////		RectangleDrawInside(pDC, pICS, rect, CFPBase::IsRegular);
//
////		pDC->SetBkMode(nOldBkMode);
////		pDC->SetBkColor(clrOldBk);
////		pDC->SelectObject(pOldBrush);
////	}
//	//	2.�����Ԫ�ִ�
//	if (GetType() & TT_oblique)
//		DrawObliqueUnitString(pDC, pView, pICS);	//	����Ԫб��
//	else if (GetType() & TT_frametext)
//		DrawObliqueUnitString(pDC, pView, pICS);	//	����Ԫ����
//	else
//	{	
//		//if (m_stringDSP.GetTextSize() > 0)
//		//{
////		SetClipRgnViewportOrg(pDC, pView, FALSE);
//		DrawString(pDC, pView, pICS);
//		//pDC->SelectClipRgn(NULL);
//		WPSSelectClipRgnEx(pDC->GetSafeHdc(),NULL);
//		if (HasBlock() && pView->IsObjActivated() && pView->GetCurObj() == this)
//			DrawBlock(pDC, pView);
//		//}
//		//else
//		//	m_nTextH = (pProp->nSZH+5)/10;	//	��s�ܸ� unit 0.1mm
//	}
//}
//
//void CTableElement::DrawObliqueUnitString(CDC* pDC, CWpsView* pView, IColorScheme* pICS)
//{
//	ASSERT_VALID(this);  
//	pDC->SaveDC();
//	CPoint local = m_rect.TopLeft();
//	//pView->DocToClient(local);
//	//	ԭ�������� ��Ԫ ���Ͻ�
//	pDC->OffsetViewportOrg(local.x, local.y);
//
//	// ��ʾ���ڸ�����
//	CWPSObj* pObj;
//	for (POSITION pos = GetFirstObjPos(); pos;)
//	{
//		pObj = GetNextObj(pos);
//		pObj->Draw(pDC, pView, pICS, DS_DONTCARE);
//	}            
//	pDC->RestoreDC (-1);        
//}
//void CTableElement::DrawString(CDC* pDC, CWpsView* pView, IColorScheme* pICS)
//{
//	ASSERT(m_pTbl && m_pRow && m_pCol);
//	ASSERT_VALID(pDC);
////	ASSERT_VALID(pView);
//	
////	if (!m_pTextObjSite)
////		AutoChangeObjH(pView, TRUE);
//
////	ASSERT_VALID(m_pTextObjSite);
//	pView->FillCharWidthTable(this, (m_LineMode == horz) ? FALSE : TRUE);
//	if (m_stringDSP.IsEmpty())
//		return;
//
//	CTableElement *pTEOld = SelectCurTableElement(this);
//
//	COLORREF clrText = KColorModel::IndexToRef(GetCharColor(pView), pICS);
//	//LLG_MODIFY_2001_9_10: ��ʾ�ĵ�����ɫֻ������ɫ����������һ������...
//	if (!pDC->IsPrinting() && clrText == RGB(0,0,0) && 
//			pView && pView->GetDocument()->QueryWPPDocType() == FALSE)//WPP_CODE	
//	{	
//		clrText = gsGetPreferredTextColor();
//	}
//
//	if (IsDefText() && AUTOUULINECOLOR != g_clrDefText)
//		clrText = g_clrDefText;
//
//	//	�����豸��Ļ����
//	CreateCurChnEngFont(pView, pDC);
//
//	CRect rcFrame = GetTextRect();
//	CPoint ptCenter = rcFrame.TopLeft();
//
//	CPoint ptOrg = rcFrame.TopLeft();
//	pView->DocToClient(ptOrg);
//
//	pDC->OffsetViewportOrg(ptOrg.x, ptOrg.y);
//	ASSERT(FALSE == g_bInitDebug);
//
//	CHARFXHSS HSS;
//	::ZeroMemory(&HSS, sizeof(CHARFXHSS));
//
//	m_pTextObjSite->Draw(pDC, pView, pICS, rcFrame, ptCenter, 
//						 0, clrText, HSS, 0, &m_pTbl->m_fontChn, &m_pTbl->m_fontEng);
//	pDC->OffsetViewportOrg(-ptOrg.x, -ptOrg.y);
//
//	SelectCurTableElement(pTEOld);
//}
