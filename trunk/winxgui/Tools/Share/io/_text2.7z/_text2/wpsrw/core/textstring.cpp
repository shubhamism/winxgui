/* -------------------------------------------------------------------------
//	�ļ���		��	textstring.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 16:57:59
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <basic/wpsapp.h>
#include "textpool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ����һ��˫�ֽ�ת������
int GetWORDEscSeqLength (LPWORD pEscSeq)
{                                              
	ASSERT (AfxIsValidAddress(pEscSeq, sizeof(WORD)*2));
	ASSERT (*pEscSeq == VK_ESCAPE);
	WORD wCommand = *(pEscSeq + 1);
	int nLength;
	switch (wCommand)
	{
	case INS_ANC_TEXT_OBJECT:
	case INS_ANC_PARA_OBJECT:
	case INS_PAGENUM:
	case INS_TOTALPAGE:
	case INS_SYSTIME:
	case INS_SYSDATE:
	case INS_SYSDAY:
	case INS_BOOKMARK:
		nLength = 3; break;
		// (<IWPSMACRO�깦��>
	case INS_IWPSMACRO:
		nLength = 5; break;
		// <IWPSMACRO�깦��>)
	case INS_FOOTNOTE:
		nLength = 16; break;
	case INS_PAGEREF:
		nLength = 6; break;
#ifdef _DEBUG
	case NULL:		nLength = 1; break;
#endif
	default:
		// ��Ч�Ļ������С���ESC��Ϊ�ո�(6-1-99�����ռǣ�db)
		ASSERT(FALSE);
		//		*((TEXTWORD*)pEscSeq) = (TEXTWORD)' ';
		nLength = 1; break;
	}
	return nLength;
}

// -------------------------------------------------------------------------

void SwapOldTextWord(LPTEXTWORD pWord)
{
	if (*pWord <= 0xFF)
		return;
	
	union {
		TEXTWORD tw;
		MULTIWORD mw;
	};
	if (*pWord <= 0xFFFF)
	{
		tw = 0;
		mw.w1.gb1 = ((LPBYTE)pWord)[1];
		mw.w1.gb2 = *((LPBYTE)pWord);
	}
	else
	{
		mw.w1.gb1 = ((LPBYTE)pWord)[3];
		mw.w1.gb2 = ((LPBYTE)pWord)[2];
		mw.w2.gb1 = ((LPBYTE)pWord)[1];
		mw.w2.gb2 = *((LPBYTE)pWord);
	}
	*pWord = tw;
}

int KCP_WordToTextWord(LPTEXTWORD lptw, LPWORD lpw, int nLength)
{
	LPTEXTWORD pWord = lptw;
	int i;
	for (i = 0; i < nLength; i++)
	{
		*lptw = (TEXTWORD)*lpw;
		lptw++;
		lpw++;
	}
	for (i = 0; i < nLength; pWord++, i++)
	{
		if (*pWord == VK_ESCAPE)
		{
			int nSize;
			nSize = ::GetEscSeqLength(pWord) - 1;
			pWord += nSize;
			i += nSize;
		}
		else
		{
			SwapOldTextWord(pWord);
			*pWord = g_lpKXCodePageVI->GB18030ToUniChar(*pWord);
		}
	}
	return nLength;
}

//���������������Ի����׸��� [wxb 2002-4-25]
int KCP_TextWordToString(LPTSTR lpsz, int nBufSize, LPCTEXTWORD lptw, int nLength,
						 TEXTWORD twSpWord, SPECIALCALLPROCESS pCall)
{
	LPTSTR pBuf = lpsz;
	TEXTWORD tw;
	TEXTWORD gbChar;
	int nLen;
	int i;
	for (i = 0; i < nLength; i++)
	{
		tw = *(lptw + i);
		if (tw == twSpWord && pCall)
		{
			if (pCall(nLen, lptw + i) == 1)
			{
				i += nLen - 1;
				continue;
			}
		}
		gbChar = g_lpKXCodePageVI->UniCharToGB18030(tw);
		if (gbChar & 0xFFFF0000)
		{
			if (nBufSize <= 4)
				break;
			pBuf[0] = (BYTE)(gbChar >> 24);
			pBuf[1] = (BYTE)(gbChar >> 16);
			pBuf[2] = (BYTE)(gbChar >>  8);
			pBuf[3] = (BYTE)gbChar;
			nBufSize -= 4;
			pBuf += 4;
		}
		else if (gbChar & 0x0000FF00)
		{
			if (nBufSize <= 2)
				break;
			pBuf[0] = (gbChar >> 8) & 0xFF;
			pBuf[1] = (BYTE)gbChar;
			nBufSize -= 2;
			pBuf += 2;
		}
		else if (gbChar)
		{
			if (nBufSize <= 1)
				break;
			*pBuf = BYTE(gbChar);
			nBufSize--;
			pBuf++;
		}
	}
	*pBuf = 0;
	return (pBuf - lpsz);
}

// -------------------------------------------------------------------------

BOOL ConverWORDString2DWORDString(KSTextString& strOut, LPWORD pInBuf, int nInLen)
{
	TEXTWORD wszEscBuf[MAXESCSEQLEN + 10];						// ת����˫�ֽ��ַ���
	
	WORD wCommand;
	TEXTWORD tw;
	int nSize;
	int nEscBufLen;
	for (int i = 0; i < nInLen; i++, pInBuf++)
	{
		wCommand = *pInBuf;
		if (wCommand == VK_ESCAPE && 1 < (nSize = GetWORDEscSeqLength(pInBuf)))
		{
			wCommand = *(pInBuf + 1);
			switch (wCommand)
			{
			case INS_ANC_TEXT_OBJECT:
			case INS_ANC_PARA_OBJECT:
			case INS_PAGENUM:
			case INS_TOTALPAGE:
			case INS_SYSTIME:
			case INS_SYSDATE:
			case INS_SYSDAY:
				// (<IWPSMACRO�깦��>
			case INS_IWPSMACRO:
				// <IWPSMACRO�깦��>)
				memset(wszEscBuf, 0, sizeof(TEXTWORD) * MAXESCSEQLEN + 10);
				nEscBufLen = KCP_WordToTextWord(wszEscBuf, pInBuf, nSize);
				break;
				
			case INS_PAGEREF:
				ASSERT(nSize == 6);
				memset(wszEscBuf, 0, sizeof(TEXTWORD) * MAXESCSEQLEN + 10);
				ASSERT(VK_ESCAPE == *pInBuf);
				wszEscBuf[0]	= VK_ESCAPE;
				wszEscBuf[1]	= INS_PAGEREF;
				wszEscBuf[2]	= *(pInBuf + 2);
				wszEscBuf[3]	= *(DWORD*)(pInBuf + 4);
				nEscBufLen		= nSize;
				break;
			case INS_FOOTNOTE:
				memset(wszEscBuf, 0, sizeof(TEXTWORD) * MAXESCSEQLEN + 10);
				wszEscBuf[0] = *(DWORD*)(pInBuf + 2);
				wszEscBuf[1] = *(pInBuf + 4);
				lstrcpy((char*)(wszEscBuf + 2), (char*)(pInBuf + 5));
				nEscBufLen += 2;
				break;
				
			case INS_BOOKMARK:
				ASSERT(FALSE);											// �����û����
				nEscBufLen = 0;
				break;
				
			default:
				ASSERT(FALSE);
				nEscBufLen = 0;
				break;
			}
			strOut.CatCopy(wszEscBuf, nEscBufLen);
			i += nSize - 1;
			pInBuf += nSize - 1;
		}
		else
		{
			tw = wCommand;
			SwapOldTextWord(&tw);
			ASSERT(g_lpKXCodePageVI);
			tw = g_lpKXCodePageVI->GB18030ToUniChar(tw);
			strOut += tw;
		}
	}
	
	return TRUE;
}

// -------------------------------------------------------------------------

void KSTextString::TextStringCat(LPTEXTWORD lpSrcData, int nSrcLen)
{
	ASSERT(lpSrcData);
	if (nSrcLen <= 0)
		return;
	AllocBuffer(nSrcLen + GetTextSize());
	memcpy(m_tsData.lptwTextBufEnd, lpSrcData, nSrcLen * TEXTWORDBYTES);
	m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufEnd + nSrcLen;
	*m_tsData.lptwTextBufEnd = 0;
}

void KSTextString::AllocBuffer(int nLen)
{
	ASSERT(m_tsData.lptwTextBufOrg == m_tsData.lptwData);			// Ҫ����ȣ���ΪҪ���·���ռ���
	ASSERT(nLen > 0);
	// ΪʲôҪԤ�� FREEMEMSPACE �ռ䣿���� ���������������DEFAULT_TEXTSTRING_BUFFERSIZE
	// ��Ҫ�ط����ڴ�ʱ��������delete�������
	// ����ԭ��������þ����е�buffer��m_tsData.lptwTextBufEnd�պ�ָ��new�е�����Ϣ����ʼ����������ֵ����
	// �ƻ����ڴ������Ϣ�������ԡ�����˵������m_tsData.lptwTextBufEnd������������ڴ������������������
	
	// �뿴һ�����´����к����⣿������н�������һ�仰������һֻ������
	// if (m_tsData.twBufSize - FREEMEMSPACE > nLen)
	// ���һ��ʼ m_tsData.twBufSize = 0������� DWORD(0-10) > 100 ��������е���CArchive��ǰ�Ǹ�BUG
	if (m_tsData.twBufSize > (TEXTWORD)(nLen + FREEMEMSPACE))
		return;
	else
	{
		int nAllocLen = (m_tsData.twBufSize == 0)? DEFAULT_TEXTSTRING_BUFFERSIZE:
		((nLen + FREEMEMSPACE) / DEFAULT_TEXTSTRING_BUFFERSIZE + 1) * DEFAULT_TEXTSTRING_BUFFERSIZE;
		ASSERT(nAllocLen >= nLen);
		LPTEXTWORD pData = new TEXTWORD[nAllocLen]; ASSERT(pData);
		if (!pData)
		{
			ASSERT(FALSE);
			return;													// û���κθı�
		}
#ifdef _DEBUG
		memset(pData, '@', nAllocLen * TEXTWORDBYTES);
#endif
		if (m_tsData.twBufSize > 0)
		{
			int nLength = GetTextSize();
			memcpy(pData, m_tsData.lptwTextBufOrg, nLength * TEXTWORDBYTES);
			delete []m_tsData.lptwData;
			m_tsData.lptwTextBufOrg = pData;
			m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufOrg + nLength;
		}
		else
		{
			m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufOrg = pData;
		}
		m_tsData.lptwData = pData;
		m_tsData.twBufSize = nAllocLen;
	}
}

///////////////////////////////////////////////////////////////////////////
// Function Name: KSTextString::GetBuffer
// Function		: ����Ҫ���С�Ļ�����
// Entry		: 
// Return		: LPTEXTWORD 
// Remark		: ����ʹ�ô˽ӿ�����ĳһ��С�Ļ�����������
///////////////////////////////////////////////////////////////////////////
LPTEXTWORD KSTextString::GetBuffer(int nLen)
{
	if (nLen <= 0)
		return m_tsData.lptwTextBufOrg;
	
	int noffset = m_tsData.lptwTextBufOrg - m_tsData.lptwData;
	AllocBuffer(nLen + noffset);
	return m_tsData.lptwTextBufOrg;
}

///////////////////////////////////////////////////////////////////////////
// Function Name: KSTextString::Delete
// Function		: 
// Entry		: 
// Return		: int :		The length of the string after be changed. 
// Remark		:
///////////////////////////////////////////////////////////////////////////
int KSTextString::Delete(int nIndex, int nCount/*=1*/)
{
	int nSize = GetTextSize();
	if (nIndex < 0)
		nIndex = 0;
	else if (nIndex > nSize)
		return nSize;
	if (nCount > nSize - nIndex)
		nCount = nSize - nIndex;
	memmove(m_tsData.lptwTextBufOrg + nIndex, m_tsData.lptwTextBufOrg + nIndex + nCount,
		(nSize - nIndex - nCount) * TEXTWORDBYTES);
	m_tsData.lptwTextBufEnd -= nCount;
	*m_tsData.lptwTextBufEnd = 0;
	
	return GetTextSize();
}

///////////////////////////////////////////////////////////////////////////
// Function Name: KSTextString::Insert
// Function		: ����һ��TEXTWORD�ַ���
// Entry		: nIndex	����λ�ã���TEXTWORDΪ��λ��ƫ������
//				  ptw		�����TEXTWORD�ַ���
//				  nSize		�����ַ����ĳ��ȣ���TEXTWORDΪ��λ��
// Return		: int : ���ز���󴮵ĳ���
// Remark		:
///////////////////////////////////////////////////////////////////////////
int KSTextString::Insert(int nIndex, LPCTEXTWORD ptw, int nSize)
{
	int nLength = GetTextSize();
	
	if (nSize <= 0)
		return nLength;
	
	if (nIndex < 0)
		nIndex = 0;
	else if (nIndex > nLength)
		nIndex = nLength;
	
	AllocBuffer(nLength + nSize);
	ASSERT(m_tsData.lptwData);
	ASSERT(nLength == GetTextSize());
	
	memmove(m_tsData.lptwTextBufOrg + nIndex + nSize, m_tsData.lptwTextBufOrg + nIndex,
		(nLength - nIndex) * TEXTWORDBYTES);
	memcpy(m_tsData.lptwTextBufOrg + nIndex, ptw, nSize * TEXTWORDBYTES);
	m_tsData.lptwTextBufEnd += nSize;
	*m_tsData.lptwTextBufEnd = 0;
	
	return GetTextSize();
}

int KSTextString::Insert(int nIndex, LPCSTR lpsz, int nSrcLength/*=-1*/)
{
	ASSERT(lpsz == NULL || AfxIsValidString(lpsz));
	int nSize = GetTextSize();
	if (!lpsz)
		return nSize;
	
	if (nIndex < 0)
		nIndex = 0;
	else if (nIndex > nSize)
		nIndex = nSize;

	if (nSrcLength < 0)
		nSrcLength = strlen(lpsz);
	
	if (0 == nSrcLength)
		return nSize;
	
	LPWSTR pszBuf = new WCHAR[nSrcLength];
	int nSrcSize = MultiByteToWideChar(CP_ACP, 0, lpsz, nSrcLength, pszBuf, nSrcLength);

	// TEXTWORD tw[nSrcLength];
//	int nSrcSize = KCP_StringToTextWord(tw, lpsz, nSrcLength);
	if (nSrcSize == 0)
	{
		delete []pszBuf;
		return 0;
	}
	LPTEXTWORD tw = new TEXTWORD[nSrcLength]; ASSERT(tw);
	for (int i = 0; i < nSrcLength; i++)
		tw[i] = pszBuf[i];
	delete[] pszBuf;
	pszBuf = NULL;
	
	AllocBuffer(nSize + nSrcSize);
	ASSERT(m_tsData.lptwData);
	ASSERT(nSize == GetTextSize());
	
	memmove(m_tsData.lptwTextBufOrg + nIndex + nSrcSize, m_tsData.lptwTextBufOrg + nIndex,
		(nSize - nIndex) * TEXTWORDBYTES);
	memcpy(m_tsData.lptwTextBufOrg + nIndex, tw, nSrcSize * TEXTWORDBYTES);
	m_tsData.lptwTextBufEnd += nSrcSize;
	*m_tsData.lptwTextBufEnd = 0;
	delete []tw;
	
	return GetTextSize();
}

void KSTextString::GBKToUnicode()
{
	LPTEXTWORD pWord;
	for (pWord = m_tsData.lptwTextBufOrg; pWord < m_tsData.lptwTextBufEnd; pWord++)
	{
		if (*pWord == VK_ESCAPE)
			pWord += ::GetEscSeqLength(pWord) - 1;
		if (*pWord != 0x39FE39FE)	//��Ϊ����Ĭ�����֡�����Ĭ�����֡���ԪĬ�����ֲ��ò��� [wxb 02-5-14]
		{
			SwapOldTextWord(pWord);
			*pWord = g_lpKXCodePageVI->GB18030ToUniChar(*pWord);
		}
	}
}

UINT KSTextString::Read(KSArchive& ar, WORD wSize) // ����һ��WORD�ַ���
{
	ASSERT(!g_fCompoundFile);
	
	WORD* pTextBuf = new WORD[wSize];
	ASSERT(pTextBuf);

	UINT nLen = ar.Read(pTextBuf, wSize * sizeof(WORD)); // �������ӵ��������ݣ���2�ֽ�Ϊ��λ��
	ASSERT(nLen / sizeof(WORD) == wSize);
	nLen /= sizeof(WORD);
	
	Clear();
	VERIFY(ConverWORDString2DWORDString(*this, pTextBuf, nLen));

	delete []pTextBuf; // �ͷ���2�ֽ�Ϊ��λ����ʱ����
	
	return nLen;
}

// -------------------------------------------------------------------------

KSArchive& operator<<(KSArchive& ar, const KSTextString& string)
{
	ASSERT(string.m_tsData.lptwData);
	int nLength = string.GetTextSize(); ASSERT(nLength >= 0);
	ar << nLength;
	if (nLength > 0)
		ar.Write(string.m_tsData.lptwTextBufOrg, nLength * TEXTWORDBYTES);
	return ar;
}

KSArchive& operator>>(KSArchive& ar, KSTextString& string)
{
	int nLength;
	ar >> nLength;
	ASSERT(nLength >= 0);
	string.Clear();
	if (nLength > 0)
	{
		string.AllocBuffer(nLength);
		ar.Read(string.m_tsData.lptwTextBufOrg, nLength * TEXTWORDBYTES);
		string.m_tsData.lptwTextBufEnd = string.m_tsData.lptwTextBufOrg + nLength;
		*string.m_tsData.lptwTextBufEnd = 0;
	}
	//(�����Ի����� [wxb 2002-4-30]
	if (!g_fCompoundFile)
		string.GBKToUnicode();
	//)
	return ar;
}

// -------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////
// overloaded assignment
//////////////////////////////////////////////////////////////////////

const KSTextString& KSTextString::operator=(const KSTextString& stringSrc)
{
	if (&m_tsData == &stringSrc.m_tsData)		// ���ֱȽϿ��Ա���str1 = str1�������������ǿ���̵ĸ�ֵ�أ�
		return *this;
	Empty();
	int nLength = stringSrc.GetTextSize();
	if (nLength > 0)
		AssignCopy(stringSrc.m_tsData.lptwTextBufOrg, nLength);
	return *this;
}

// -------------------------------------------------------------------------

//TEXTWORD KCP_CharToTextTextWord(TCHAR ch);
const KSTextString& KSTextString::operator=(WCHAR ch)
{
	Empty();
	TEXTWORD tw = ch;
	AssignCopy(&tw, 1);
	return *this;
}

// -------------------------------------------------------------------------

int KCP_StringToTextWord(LPTEXTWORD lptw, LPCWSTR lpsz, int/*=-1*/);
const KSTextString& KSTextString::operator=(LPCWSTR lpsz)
{
	ASSERT(lpsz == NULL || AfxIsValidString(lpsz));
	Empty();
	if (lpsz)
	{
		int nLength = wcslen(lpsz);
		if (nLength > 0)
		{
			LPTEXTWORD tw = new TEXTWORD[nLength]; ASSERT(tw);
			//int nSize = KCP_StringToTextWord(tw, lpsz);
			//AssignCopy(tw, nSize);
			delete []tw;
		}
	}
	return *this;
}

// -------------------------------------------------------------------------

int KCP_StringToTextWord(LPTEXTWORD lptw, LPCSTR lpsz, int=-1);
const KSTextString& KSTextString::operator=(LPCSTR lpsz)
{
	ASSERT(lpsz == NULL || AfxIsValidString(lpsz));
	Empty();
	if (lpsz)
	{
		int nLength = strlen(lpsz);
		if (nLength > 0)
		{
			LPTEXTWORD tw = new TEXTWORD[nLength]; ASSERT(tw);
			int nSize = KCP_StringToTextWord(tw, lpsz);
			AssignCopy(tw, nSize);
			delete []tw;
		}
	}
	return *this;
}

// -------------------------------------------------------------------------

void KSTextString::AssignCopy(LPTEXTWORD lpSrcData, int nSrcLen)
{
	ASSERT(lpSrcData);
	AllocBuffer(nSrcLen);
	memcpy(m_tsData.lptwTextBufOrg, lpSrcData, nSrcLen * TEXTWORDBYTES);
	m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufOrg + nSrcLen;
	*m_tsData.lptwTextBufEnd = 0;
}

// -------------------------------------------------------------------------

int KSTextString::Find(LPCSTR lpszSub, int nStart/*=0*/) const
{
	ASSERT(AfxIsValidString(lpszSub));
	int nLength = GetTextSize();
	int nStrLen = strlen(lpszSub);
	if (nStart > nLength || nStrLen <= 0)
		return -1;
	
	LPTEXTWORD lptw = new TEXTWORD[nStrLen];
	int nLen = KCP_StringToTextWord(lptw, lpszSub);
	// find first matching substring
	BOOL bEqu = FALSE;
	for (int i = nStart; i < nLength; i++)
	{
		if (0 == memcmp(m_tsData.lptwTextBufOrg + i, lptw, nLen * sizeof(TEXTWORD)))
		{
			delete []lptw;
			return i;
		}
	}
	delete []lptw;
	// return -1 for not found, distance from beginning otherwise
	return -1;
}

// -------------------------------------------------------------------------

KSTextString KSTextString::Mid(int nFirst) const
{
	return Mid(nFirst, GetTextSize() - nFirst);
}

// -------------------------------------------------------------------------

KSTextString KSTextString::Mid(int nFirst, int nCount) const
{
	if (nFirst < 0)
		nFirst = 0;
	if (nCount < 0)
		nCount = 0;

	int nLen = GetTextSize();
	if (nFirst + nCount > nLen)
		nCount = nLen - nFirst;
	if (nFirst > nLen)
		nCount = 0;

	ASSERT(nFirst >= 0);
	ASSERT(nFirst + nCount <= nLen);

	if (nFirst == 0 && nFirst + nCount == nLen)				// optimize case of returning entire string
		return *this;

	KSTextString stringdest(m_tsData.lptwTextBufOrg, nCount, nFirst);
	return stringdest;
}

// -------------------------------------------------------------------------

KSTextString KSTextString::Left(int nCount) const
{
	int nLen = GetTextSize();
	if (nCount < 0)
		nCount = 0;
	else if (nCount > nLen)
		nCount = nLen;

	KSTextString stringdest(m_tsData.lptwTextBufOrg, nCount);
	return stringdest;
}

// -------------------------------------------------------------------------

KSTextString KSTextString::Right(int nCount) const
{
	int nLen = GetTextSize();
	if (nCount < 0)
		nCount = 0;
	else if (nCount > nLen)
		nCount = nLen;

	KSTextString stringdest(m_tsData.lptwTextBufOrg, nCount, nLen - nCount);

	return stringdest;
}
// -------------------------------------------------------------------------

KSTextString AFXAPI operator+(const KSTextString& string1, const KSTextString& string2)
{
	KSTextString stringdest;
	stringdest.Empty();
	stringdest.ConCatCopy(string1.m_tsData.lptwTextBufOrg, string1.GetTextSize(),
							string2.m_tsData.lptwTextBufOrg, string2.GetTextSize());
	return stringdest;
}

// -------------------------------------------------------------------------

void KSTextString::ConCatCopy(LPTEXTWORD lpszSrc1Data, int nSrc1Len,
								LPTEXTWORD lpszSrc2Data, int nSrc2Len)
{
	ASSERT(lpszSrc1Data && lpszSrc2Data);
	AllocBuffer(nSrc1Len + nSrc2Len);
	memcpy(m_tsData.lptwTextBufOrg, lpszSrc1Data, nSrc1Len * TEXTWORDBYTES);
	memcpy(m_tsData.lptwTextBufOrg + nSrc1Len, lpszSrc2Data, nSrc2Len * TEXTWORDBYTES);
	m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufOrg + nSrc1Len + nSrc2Len;
	*m_tsData.lptwTextBufEnd = 0;
}

// -------------------------------------------------------------------------

const KSTextString& KSTextString::operator+=(LPCSTR lpsz)
{
	ASSERT(lpsz == NULL || AfxIsValidString(lpsz));
	if (!lpsz)
		return *this;
	int nLength = strlen(lpsz);
	if (nLength <= 0)
		return *this;
	LPTEXTWORD tw = new TEXTWORD[nLength]; ASSERT(tw);
	int nSize = KCP_StringToTextWord(tw, lpsz);
	TextStringCat(tw, nSize);
	delete []tw;
	
	return *this;
}

// -------------------------------------------------------------------------

const KSTextString& KSTextString::operator+=(const KSTextString& string)
{
	int nLength = string.GetTextSize();
	TextStringCat(string.m_tsData.lptwTextBufOrg, nLength);
	return *this;
}

// -------------------------------------------------------------------------

