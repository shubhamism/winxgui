/* -------------------------------------------------------------------------
//	�ļ���		��	wpsdocman.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 21:40:48
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if 0
#include "wpsdocman.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#define INC_NUM		8

KWIDocMan::KWIDocMan()
{
	m_nMaxIndex = 0;
	m_nCurIndex = 0;
	m_pDocuments = NULL;
}

KWIDocMan::~KWIDocMan()
{
	if (m_pDocuments)
		delete m_pDocuments;
}

CWpsDoc* KWIDocMan::GetDocument(const int nIndex)
{
	if (nIndex >= 1 && nIndex <= m_nCurIndex + 1)
		return (CWpsDoc*)m_pDocuments[nIndex - 1];
	return NULL;
}

BOOL KWIDocMan::AddDocument(const int nIndex, const CWpsDoc* pDoc)
{
	int nSize = m_nMaxIndex;
	if (!nSize)
		nSize = INC_NUM;
	else if (nIndex == nSize)
		nSize = nSize + INC_NUM;
	
	if (nSize != m_nMaxIndex)
	{
		// �ڴ���С�����仯
		UINT* pUInt;
		try
		{
			pUInt = new UINT [nSize];
		}
		catch(...)
		{
			return FALSE;
		}
		if (m_nMaxIndex)
		{
			memcpy(pUInt, m_pDocuments, m_nMaxIndex * sizeof(UINT));
			delete m_pDocuments;
		}
		m_pDocuments = pUInt;
		m_nMaxIndex = nSize;
	}
	m_nCurIndex = nIndex - 1;
	m_pDocuments[m_nCurIndex] = (UINT)pDoc;
	return TRUE;
}

void KWIDocMan::RemoveDocument(const int nIndex)
{
	ASSERT(nIndex >= 1 && nIndex <= m_nCurIndex + 1);
	m_pDocuments[nIndex - 1] = 0;
}

#endif //0
// -------------------------------------------------------------------------
