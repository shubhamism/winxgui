/* -------------------------------------------------------------------------
//	�ļ���		��	footnote.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 13:26:08
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __FOOTNOTE_H__
#define __FOOTNOTE_H__

// -------------------------------------------------------------------------
// class CFootnoteMan
enum NUM_FORMAT
{
	NUM_DECUC		= 0,			//��,��,��
		NUM_DBNUMT		= 1,			//һ,��,��
		NUM_DBNUMD		= 2,			//Ҽ,��,��
		NUM_LCRM		= 3,			//i,ii,iii
		NUM_UCRM		= 4,			//I,II,III
		
		NUM_ORD			= 5,			//1sd,2nd,3rd
		NUM_DEC			= 6,			//1,2,3
		NUM_LCLTR		= 7,			//a,b,c
		NUM_UCLTR		= 8				//A,B,C
										/*
										NUM_DBNUMK		= 0x103,		//* dbnum4
										NUM_GBNUM		= 0x200,		//1.,2.,3.
										NUM_GBNUMD		= 0x201,		//(1),(2),(3)
										NUM_GBNUML		= 0x202,		//* gb3
										NUM_GBNUMK		= 0x203,		//* gb4
										NUM_ZODIAC		= 0x300,		//��,��,��
										NUM_ZODIACD		= 0x301,		//* zodiac2
										NUM_UNPROCESS	= 0xf000		// Unprocess key.
										*/
};

class CTextPool;
class CFootnoteMan
{
	// Construction
public:
	CFootnoteMan();
	virtual ~CFootnoteMan();
	
	// Attributes
public:
	enum { FNMODE_continuous = 1, FNMODE_eachsection = 2, FNMODE_eachpage = 3 };
	enum { footnote = 1, endnote = 2};
	
public:
	typedef struct tagFNPOS
	{
		int nID;
		BOOL bAutoNum;
		int nFormatNum;												// ��ֵ������ m_wFNMode
		WORD wSection;												// �߼�ֵ
		int nIDPage;												// ����������������ֵ
		int nIDColumn;
		int nIDZone;
	} FNPOS;
	typedef FNPOS*		PFNPOS;
	
	int m_nMaxID;
	
	// Footnote Attributes
	int m_nFNStartID;
	NUM_FORMAT m_FNFormat;
	WORD m_wFNMode;
	CString m_strFNPrefix;
	CString m_strFNSuffix;
	
	// Endnote Attributes
	int m_nENStartID;
	CPtrArray m_aryENPos;
	NUM_FORMAT m_ENFormat;
	WORD m_wENMode;
	CString m_strENPrefix;
	CString m_strENSuffix;
private:
	CTextPool* m_pFNPool;
	
public:
	// footnotes

	void SetFootnotePool(CTextPool* pFNPool) { m_pFNPool = pFNPool; }

	// serialize

	void _Serialize(KSArchive& ar);
};

// -------------------------------------------------------------------------

#endif /* __FOOTNOTE_H__ */
