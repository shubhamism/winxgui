/* -------------------------------------------------------------------------
//	�ļ���		��	ex_chart.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-3 18:15:05
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_CHART_H__
#define __EX_CHART_H__

#ifndef __EX_SHAPE_H__
#include <export/draw/ex_shape.h>
#endif

#ifndef __CHART_H__
#include <chart/chart.h>
#endif

#ifndef __POLYLINE_H__
#include <chart/polyline.h>
#endif

#ifndef __HISTOGRAM_H__
#include <chart/histogram.h>
#endif

#ifndef __CAKE_H__
#include <chart/cake.h>
#endif

// -------------------------------------------------------------------------

class CFrameChart_Export : public CFrameChart
{
//���಻�ܶ����Ա�������麯��
public:
	EX_SHAPE_API ConvertShape(CShape_Context& context);
	EX_SHAPE_API CreateChartSubObj(CWPSObj*, CShape_Context&);
	EX_SHAPE_API ConvertFrame(CShape_Context& context);
};

ShapeExportClassDecl(FRAMEChart, CFrameChart_Export, CFrameObj_Export);

// -------------------------------------------------------------------------

#endif /* __EX_CHART_H__ */
