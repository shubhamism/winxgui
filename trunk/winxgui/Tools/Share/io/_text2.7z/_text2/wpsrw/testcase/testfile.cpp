/* -------------------------------------------------------------------------
//	�ļ���		��	testfile.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-10 10:08:46
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestWpsFile : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestWpsFile);
		CPPUNIT_TEST(testEncryptFile);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testEncryptFile()
	{
		testWps2DocFile("core/2000/encrypt_abcd.wps", "_encrypt_abcd_.doc");
	}
};

//CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestWpsFile);

// -------------------------------------------------------------------------
