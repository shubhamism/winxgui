/* -------------------------------------------------------------------------
//	�ļ���		��	ex_frametbl.h
//	������		��	��־��
//	����ʱ��	��	2004-11-23 15:54:41
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifdef WPP_ONLY
#include "../draw/ex_objbase.h"
#include "ex_wppframetbl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


EX_SHAPE_API CWPPFrameTable_Export::GetTablePosAndPr(CShape_Context& context,
		/*out*/KDWTablePos& tblPos, /*out*/KDWRowTablePr& tblPr)
{
	//tblPos
	if(!context.IsInlineShape())
	{
		//����ʱ���������ĵľ���(in twips)������ν������
//		tblPos.leftFromText = WpsShapeToTwip(m_MarginOutside.left);
//		tblPos.topFromText = WpsShapeToTwip(m_MarginOutside.top);
//		tblPos.rightFromText = WpsShapeToTwip(m_MarginOutside.right);
//		tblPos.bottomFromText = WpsShapeToTwip(m_MarginOutside.bottom);
//		//
		tblPos.tblOverlap = 1;
		//
		tblPos.pcHorz = mso_pcHorzPage;
		tblPos.pcVert = mso_pcVertPage;
		//tblPos.tblpXSpec = 0;
		//tblPos.tblpYSpec = 0;
		tblPos.tblpX = WpsShapeToTwip(m_rect.left);
		tblPos.tblpY = WpsShapeToTwip(m_rect.top);
	}
	else
	{
		tblPr.jc = mso_jcCenter;
	}
	//tblPr
	//�߿�����
	gSetBRCEX(m_LPenColor, m_uLPenSize, m_uLPenStyle, 
		tblPr.tblBorders[mso_tblBrcTop], &tblPr.tblBorders[mso_tblBrcBottom]);
	tblPr.tblBorders[mso_tblBrcLeft] = tblPr.tblBorders[mso_tblBrcTop];
	tblPr.tblBorders[mso_tblBrcRight] = tblPr.tblBorders[mso_tblBrcBottom];
	if(m_nfrmShape)
	{
		if(!(m_nfrmShape & FS_L))
		{
			tblPr.tblBorders[mso_tblBrcLeft].put_Delete();
		}
		if(!(m_nfrmShape & FS_T))
		{
			tblPr.tblBorders[mso_tblBrcTop].put_Delete();
		}
		if(!(m_nfrmShape & FS_R))
		{
			tblPr.tblBorders[mso_tblBrcRight].put_Delete();
		}
		if(!(m_nfrmShape & FS_B))
		{
			tblPr.tblBorders[mso_tblBrcBottom].put_Delete();
		}
	}
	//���
	COLORREF bkColor = m_logbrush.lbColor;//wps����ɫ����÷ǳ�����
	if(m_nBkMode == OPAQUE && m_logbrush.lbStyle == BS_HATCHED)
		bkColor = m_bkColor;
	gSetSHDEX(m_nBkMode == OPAQUE, bkColor,
		m_logbrush.lbStyle == BS_HATCHED, m_logbrush.lbColor, m_logbrush.lbHatch, tblPr.shd);
	//
	tblPr.typeCellWidth = mso_vetDxa;
}

EX_SHAPE_API CWPPFrameTable_Export::GetCellPr(CTableElement* pEle, /*out*/KDWCellPr& cellPr)
{
	//�߿�����
	gSetBRCEX(pEle->m_LPenColor[0], pEle->m_uLPenSize[0], pEle->m_uLPenStyle[0], 
		cellPr.tcBorders[mso_tcBrcRight]);
	gSetBRCEX(pEle->m_LPenColor[1], pEle->m_uLPenSize[1], pEle->m_uLPenStyle[1], 
		cellPr.tcBorders[mso_tcBrcBottom]);

	gSetBRCEX(pEle->m_LPenColor[2], pEle->m_uLPenSize[2], pEle->m_uLPenStyle[2], 
		cellPr.tcBorders[mso_tcBrcLeft]);
	gSetBRCEX(pEle->m_LPenColor[3], pEle->m_uLPenSize[3], pEle->m_uLPenStyle[3], 
		cellPr.tcBorders[mso_tcBrcTop]);

	//���
	COLORREF bkColor = pEle->m_logbrush.lbColor;//wps����ɫ����÷ǳ�����
	if(pEle->m_nBkMode == OPAQUE && pEle->m_logbrush.lbStyle == BS_HATCHED)
	{
		bkColor = pEle->m_bkColor;
	}
	if(pEle->m_nBkMode == GRADIENT)//���������ʵ�����
	{
		bkColor = pEle->m_bkColor;
	}
	gSetSHDEX(pEle->m_nBkMode == OPAQUE || pEle->m_nBkMode == GRADIENT, bkColor,
			pEle->m_logbrush.lbStyle == BS_HATCHED, pEle->m_logbrush.lbColor,
			pEle->m_logbrush.lbHatch, cellPr.shd);
	//��Ԫ��ֱ����
	CCtrlCode_Alignment* pCodeV = NULL;
	for(POSITION pos = pEle->m_AttribList.GetHeadPosition(); pos;)
	{
		CCtrlCode* pCode = (CCtrlCode*)pEle->m_AttribList.GetNext(pos);
		ASSERT_VALID(pCode);
		if(pCode->GetCodeID() == SETVALIGNMENT)
		{
			pCodeV = (CCtrlCode_Alignment*)pCode;
			break;
		}
	}
	if(!pCodeV)
	{
		pCodeV = (CCtrlCode_Alignment*)m_AttribArray[CC_ALIGV];
	}
	ASSERT_VALID(pCodeV);
	WORD vAlign = pCodeV->GetAlignment();
	if(vAlign == TAL_VCENTER)
	{
		cellPr.vertAlign = mso_tcVAlignCenter;//TC_VERTALIGN
	}
	else if(vAlign == TAL_BOTTOM)
	{
		cellPr.vertAlign = mso_tcVAlignBottom;
	}
}

static void GetCellFillIdx(int rowCount, int* pptRow,
					int colCount, int* pptCol,
					RECT& rcCell,
					OUT int& rowIdxStart, OUT int& rowIdxEnd,
					OUT int& colIdxStart, OUT int& colIdxEnd
					)
{
	rowIdxStart = rowIdxEnd = -1;
	colIdxStart = colIdxEnd = -1;
	int i;
	for(i = 0; i < rowCount; i++)
	{
		if(rcCell.top == pptRow[i])
			rowIdxStart = i;
		if(rcCell.bottom == pptRow[i])
			rowIdxEnd = i;
	}
	for(i = 0; i < colCount; i++)
	{
		if(rcCell.left == pptCol[i])
			colIdxStart = i;
		if(rcCell.right == pptCol[i])
			colIdxEnd = i;
	}
	ASSERT(rowIdxStart != -1 && rowIdxEnd != -1 && rowIdxStart <= rowIdxEnd);
	ASSERT(colIdxStart != -1 && colIdxEnd != -1 && colIdxStart <= colIdxEnd);

}

void CWPPFrameTable_Export::FixTextStyles(CObList& attrList, CObArray& styleList)
{
	for (int i = 0; i < styleList.GetSize();i++)
	{
		CCtrlCode* pCC = (CCtrlCode*)styleList.GetAt(i);
		if (!pCC) continue;
		
		BOOL bFind = FALSE;
		CCtrlCode* pCD = NULL;
		for ( POSITION pos = attrList.GetHeadPosition(); pos;)
		{
			pCD = (CCtrlCode*)attrList.GetNext(pos);
			if (pCC->GetCodeID() == pCD->GetCodeID())
			{
				bFind = TRUE;
				break;
			}
		}
		if (!bFind)
		{
			CCtrlCode* pNewCode = pCC->Clone();
			ASSERT(pNewCode);
			attrList.AddTail(pNewCode);
		}
	}
}

#define _CP(rowIdx, colIdx) (pcp[(rowIdx) * (colCount) + (colIdx)])
EX_SHAPE_API CWPPFrameTable_Export::ConvertTable(/*out*/_CellInfo*& pcp,
												CShape_Context& context,
												TableData* pTable)
{
	int rowCount = GetRowCount();
	int colCount = GetColCount();
	ASSERT(rowCount > 0 && colCount > 0);
	int rowIdx, colIdx;
	//ÿ��"ԭʼ"��Ĵ�С
	int* pptRow = new int[rowCount + 1];
	int* pptCol = new int[colCount + 1];

	pTable->SetSize(rowCount, colCount);

	CTableRowCol* pRow;
	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
	{
		pRow = GetRow(rowIdx);
		ASSERT(pRow);
		pptRow[rowIdx] = pRow->m_rect.top;
		pTable->SetHoriBorderPos(rowIdx, WpsShapeToPptUnit(pRow->m_rect.top));
	}
	pptRow[rowCount] = pRow->m_rect.bottom;
	pTable->SetHoriBorderPos(rowIdx, WpsShapeToPptUnit(pRow->m_rect.bottom));

	//
	CTableRowCol* pCol;
	for(colIdx = 0; colIdx < colCount; colIdx++)
	{
		pCol = GetCol(colIdx);
		ASSERT(pCol);
		pptCol[colIdx] = pCol->m_rect.left;
		pTable->SetVertBorderPos(colIdx, WpsShapeToPptUnit(pCol->m_rect.left));
	}
	pptCol[colCount] = pCol->m_rect.right;
	pTable->SetVertBorderPos(colIdx, WpsShapeToPptUnit(pCol->m_rect.right));
	
	context.m_opt.AddPropBool(msopt_fLockRotation, TRUE);
	// ���ñ�����Ϣ
	context.m_optUDef.ForceAddPropFix(msopt_objTableSignature, 1);
	context.m_optUDef.ForceAddPropFix(msopt_objTableWpp, TRUE);

	UINT len = sizeof(PPT_TableInfo) + sizeof(DWORD) * (rowCount - 1);
	char* pData = new char[len];
	
	PPT_TableInfo* pInfo = (PPT_TableInfo*)pData;
	pInfo->numOfRow = rowCount;
	pInfo->unknown1 = (pInfo->numOfRow / 4 + 1) * 4;
	pInfo->unknown2 = 4;
	UINT* pHeights = (UINT*)&pInfo->rowHeights;

	//
	pcp = new _CellInfo[rowCount * colCount];
	BOOL bIsFirstLine = TRUE;
	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
	{
		_CP(rowIdx, 0).height = WpsShapeToTwip(pptRow[rowIdx + 1] - pptRow[rowIdx]);//ÿ�е�һ����Ԫ���¼���еĸ߶�

		pHeights[rowIdx] = WpsShapeToPptUnit(pptRow[rowIdx + 1] - pptRow[rowIdx]);

		CTableRowCol* pRow = GetRow(rowIdx);
		ASSERT(pRow);
		BOOL bIsFirstElm = TRUE;
		for(colIdx = 0; colIdx < pRow->GetElemSize(); colIdx++)
		{
			CTableElement* pEle = pRow->GetElem(colIdx);
			ASSERT(pEle);
			int rowIdxStart, rowIdxEnd;
			int colIdxStart, colIdxEnd;
			GetCellFillIdx(rowCount + 1, pptRow, colCount + 1, pptCol, pEle->m_rect,
				rowIdxStart, rowIdxEnd, colIdxStart, colIdxEnd);
			GetCellPr(pEle, _CP(rowIdxStart, colIdxStart).cp);
			_CP(rowIdxStart, colIdxStart).pEle = pEle;
			
			TableCell* pCell = pTable->AddCell(rowIdxStart, colIdxStart, 
				rowIdxEnd - rowIdxStart, colIdxEnd - colIdxStart);
			pCell->SetAlloc(&(context.GetSlideBaseCtx().GetDocuCtx().GetAutoFreeAlloc()));

			if (pCell)
			{
				pCell->m_pContent = new CShape_Context(context.GetSlideBaseCtx());
				pCell->m_pContent->m_shape = pTable->m_parentShape.NewShape(FALSE);
				pTable->GenChildAnchor(pCell->m_pContent->m_shape, 
					pCell->m_rowStart, pCell->m_colStart, 
					pCell->m_rowStart + pCell->m_rowSpan,	pCell->m_colStart + pCell->m_colSpan);

				FixTextStyles(pEle->m_AttribList, m_AttribArray);
				pCell->SetAttrs(pEle, *this);
			}
			
			// �����ĸ��߿�, ֻ���ұߺ��±ߣ������Ǳ߿�Ĳ���
			if (rowIdxEnd < rowCount)
			{
				BorderSegment* pBottom = pTable->AddHoriSegment(rowIdxEnd, colIdxStart,
					colIdxEnd - colIdxStart);
				ASSERT(pBottom);
				if (pBottom)
					pBottom->SetAttrs(pEle->m_LPenColor[1], pEle->m_uLPenSize[1], pEle->m_uLPenStyle[1]);
			}

			if (colIdxEnd < colCount)
			{
				BorderSegment* pRight = pTable->AddVertSegment(colIdxEnd, rowIdxStart,
					rowIdxEnd - rowIdxStart);
				ASSERT(pRight);
				if (pRight)
					pRight->SetAttrs(pEle->m_LPenColor[0], pEle->m_uLPenSize[0], pEle->m_uLPenStyle[0]);
			}
			
			bIsFirstElm = FALSE;
		}
		bIsFirstLine = FALSE;
	}

	// ���������߿�
	if((m_nfrmShape & FS_L)) // left
	{
		BorderSegment* pLeft = pTable->AddVertSegment(0, 0,
			rowCount);
		if (pLeft)
			pLeft->SetAttrs(m_LPenColor, m_uLPenSize, m_uLPenStyle);
	}
	if((m_nfrmShape & FS_T)) // top
	{
		BorderSegment* pTop = pTable->AddHoriSegment(0, 0,
			colCount);
		ASSERT(pTop);
		if (pTop)
			pTop->SetAttrs(m_LPenColor, m_uLPenSize, m_uLPenStyle);
	}
	if((m_nfrmShape & FS_R)) // right
	{
		BorderSegment* pRight = pTable->AddVertSegment(colCount, 0,
			rowCount);
		ASSERT(pRight);
		if (pRight)
			pRight->SetAttrs(m_LPenColor, m_uLPenSize, m_uLPenStyle);
	}
	if((m_nfrmShape & FS_B)) // bottom
	{
		BorderSegment* pBottom = pTable->AddHoriSegment(rowCount, 0,
			colCount);
		ASSERT(pBottom);
		if (pBottom)
			pBottom->SetAttrs(m_LPenColor, m_uLPenSize, m_uLPenStyle);
	}

	context.m_optUDef.AddPropVar(msopt_objTableInfo, pInfo, len);
	delete []pData;

	delete []pptRow;
	delete []pptCol;
}

EX_SHAPE_API CWPPFrameTable_Export::SetPapxAndChpx(CShape_Context& context, CTableElement* pEle,
								OUT KDWPropBuffer& papx, OUT KDWPropBuffer& chpx)
{
	PapxCtrlCode_Context papxctrlcode(context.m_export);
	ChpxCtrlCode_Context chpxctrlcode(context.m_export);
	UINT uStyleID = context.m_export.AddStyle_Text(TSID_TEXT_0, "");
	papx.AddIstd(uStyleID);
	CCtrlCode* pCode;
	POSITION pos;
	int i;

	for(i = 0; i < m_AttribArray.GetSize(); i++)
	{
		pCode = (CCtrlCode*)m_AttribArray.GetAt(i);
		if(pCode == 0)
			continue;

		ASSERT_VALID(pCode);
		if (CCtrlCodeTool::FindCtrlCode(&pEle->m_AttribList, pCode->GetCodeID()) == 0)
			pEle->m_AttribList.AddTail(pCode->Clone());
	}

	context.m_export.m_pTblEleAttri = &pEle->m_AttribList;
	for(pos = pEle->m_AttribList.GetHeadPosition(); pos;)
	{
		pCode = (CCtrlCode*)pEle->m_AttribList.GetNext(pos);
		ASSERT_VALID(pCode);
		if(gIsPapxCtrlCode(pCode->GetCodeID()))
			papxctrlcode.ConvCtrlCode(pCode, papx);
		else
			chpxctrlcode.ConvCtrlCode(pCode, chpx);
	}
	context.m_export.m_pTblEleAttri = NULL;
}

EX_SHAPE_API CWPPFrameTable_Export::AddContent(KDWDocument& docu, KSTextString& kstr, 
					KDWPropBuffer& papxE, KDWPropBuffer& chpxE)
{
	docu.NewParagraph(&papxE);
	docu.NewSpan(&chpxE);
	CString str;
	TextStringToString(str, kstr);
	BSTR bstr = str.AllocSysString();
	WCHAR chLastEscChar = 0;
	for (int i = 0; i < SysStringLen(bstr); i++)
	{
		WCHAR chCur = bstr[i];
		if (chCur == def_SUP || chCur == def_SUB)			// �ϱ�
		{
			if (chLastEscChar != chCur)	// ��Ҫ��ʼ�¾�
			{
				KDWPropBuffer chpx;
				chpx.AddProps(chpxE.GetData(docu.GetAllocater()));
				chpx.AddPropFix(sprmCIss,chCur == def_SUP ? 1 : 2);
				docu.NewSpan(&chpx);
			}
			chLastEscChar = chCur;
			i++;
			if (i >= SysStringLen(bstr))
			{
				ASSERT(FALSE);
				break;
			}
			chCur = bstr[i];
		}
		else
		{
			if (chLastEscChar == def_SUP || chLastEscChar == def_SUB)
			{
				docu.NewSpan(&chpxE);
				chLastEscChar = 0;
			}
		}
		docu.AddContent(chCur);
		if (chCur == 0x0d)
		{
			docu.NewParagraph(&papxE);
			docu.NewSpan(&chpxE);
		}
	}
	if (chLastEscChar == def_SUP || chLastEscChar == def_SUB)
	{
		docu.NewSpan(&chpxE);
		chLastEscChar = 0;
	}
	SysFreeString(bstr);
	docu.AddContent(0x0d);
}
BOOL CWPPFrameTable_Export::AllocaDiagonal(CTableElement* pEle, OUT std::vector<KDWDiagonal>& vecDiagonal)
{
	BOOL fOblique = FALSE;
	if(pEle->m_nType == CTableElement::TT_oblique)//б�߱�Ԫ
	{
		fOblique = TRUE;
		for(POSITION pos = pEle->m_objList.GetHeadPosition(); pos;)
		{
			CObject* pObj = pEle->m_objList.GetNext(pos);
			if(pObj->IsKindOf(RUNTIME_CLASS(CLineObj)))
			{
				CLineObj* pLineObj = (CLineObj*)pObj;
				ASSERT_VALID(pLineObj);
				int diaPercent[2];
				for(int i = 0; i < 2; i++)
				{
					POINT& pt = pLineObj->m_linepnt[i];
					CRect& rc = pEle->m_rect;
					if(pt.y == 0)
					{
						diaPercent[i] = (pt.x * 100 / rc.Width() + 100) * 50;
					}
					else if(pt.x == 0)
					{
						diaPercent[i] = ((rc.Height() - pt.y) * 100 / rc.Height()) * 50;
					}
					else if(pt.x == rc.Width())
					{
						diaPercent[i] = (pt.y * 100 / rc.Height() + 200) * 50;
					}
					else if(pt.y == rc.Height())
					{
						diaPercent[i] = ((rc.Width() - pt.x) * 100 / rc.Width() + 300) * 50;
					}
					else
					{
						ASSERT(FALSE);
					}
				}
				KDWDiagonal dia;
				dia.put_Diagonal(diaPercent[0], diaPercent[1]);
				vecDiagonal.push_back(dia);
			}
		}
	}
	return fOblique;
}

EX_SHAPE_API CWPPFrameTable_Export::ConvertShape(CShape_Context& context)
{
	KDWTablePos tblPos;//���ñ����λ�����Եġ�
	KDWRowTablePr tblPr;//���ñ�����е����Եġ�
	
	GetTablePosAndPr(context, tblPos, tblPr);

	int rowCount = GetRowCount();
	int colCount = GetColCount();
	
	_CellInfo* pcp;

	TableData Table;
	Table.m_parentShape = context.m_shape;

	ConvertTable(pcp, context, &Table);

	context.m_shape.SetShapeType(msosptMin);
	
	Table.ConvertToShapes();

	delete[] pcp;
}

BorderSegment::BorderSegment(UINT rStart, UINT cStart, 
							 UINT rSpan, UINT cSpan)
	: m_rowStart(rStart), m_colStart(cStart), 
	  m_rowSpan(rSpan), m_colSpan(cSpan)
{
}

HRESULT BorderSegment::SetAttrs()// KROAttributes* pAttrs, 
								//MsoDrawBlipHandlerContext& blipStore)
{
	return S_OK; //InfuseShapeLineProp(m_opt, pAttrs, blipStore);	
}

HRESULT BorderSegment::SetAttrs(COLORREF color,//
				int nWidth,//�߿� 0.1mm
				int nStyle//����
				)
{
	m_opt.AddPropFix(msopt_lineColor, gConvertObjColor(color));
	int lineDasing = msolineSolid;
	if(nStyle <= PS_DASHDOTDOT)
		lineDasing = nStyle;
	if(lineDasing != msolineSolid)
		m_opt.AddPropFix(msopt_lineDashing, lineDasing);

	//����
	int lineStyle = msolineSimple;
	if(nStyle >= PS_NULL)
	{
		switch(nStyle)
		{
		default:
			//lijun ���ӿ�������
			//context.m_opt.ForceAddPropFix(ksextopt_lineStyle2, msolineNull);
			break;
		case PS_NULL:
			//lijun ��������ж���Ŀ�������ȫ��ת������������ɫ
			//context.m_opt.ForceAddPropBool(msopt_fLine, FALSE);
			break;
		case PS_DOUBLETHIN:		
			lineStyle = msolineDouble;
			break;		
		case PS_DOUBLETHICK:
			lineStyle = msolineThickThin;
			//lijun ���Ӵ�˫������
			m_opt.AddPropFix(ksextopt_lineStyle2, msolineThickThick);
			break;
		case PS_THICKTHIN:
			lineStyle = msolineThickThin;
			break;
		case PS_THINTHICK:
			lineStyle = msolineThinThick;
			break;
		case PS_THINTHICKTHIN:
			lineStyle = msolineTriple;
			break;
		}
	}
	if(lineStyle != msolineSimple)
		m_opt.AddPropFix(msopt_lineStyle, lineStyle);
	
	m_opt.AddPropBool(msopt_fLine, nStyle != PS_NULL);

	int lineWidth = nWidth * 3600;
	if(lineWidth)
		m_opt.AddPropFix(msopt_lineWidth, lineWidth);

	return S_OK;
}

HRESULT BorderSegment::ConvertToShape(TableData* pTable)
{
	MsoShape newShape = pTable->m_parentShape.NewShape(FALSE);
	newShape.SetShapeType(msosptLine);
	newShape.SetProperties(m_opt);

	pTable->GenChildAnchor(newShape, 
		m_rowStart, m_colStart, 
		m_rowStart + m_rowSpan,	m_colStart + m_colSpan);
	return S_OK;
}

// -------------------------------------------------------------------------
TableCell::TableCell(UINT rStart, UINT cStart, 
					 UINT rSpan, UINT cSpan)
:	m_rowStart(rStart), m_colStart(cStart), 
	m_rowSpan(rSpan), m_colSpan(cSpan),
	m_pDiagDownOpt(NULL), m_pDiagUpOpt(NULL), m_pAlloc(NULL),m_pEle(NULL),m_pContent(NULL)
{
}

TableCell::~TableCell()
{
	delete m_pDiagDownOpt;
	delete m_pDiagUpOpt;
	delete m_pContent;
}

void SetDefaultCellProp(MsoShapeOPT& opt)
{
	opt.AddPropBool(msopt_fFilled,	FALSE);
	opt.AddPropFix(msopt_dxTextLeft, 0x00015F90);
}


HRESULT TableCell::InfuseText(CTableElement* pEle, CWPSObj& obj)
{
	KSTextString kstr("");
	if(pEle->m_nType == CTableElement::TT_frametext)//frametext
	{
		CFrameText* pft = (CFrameText*)pEle->m_objList.GetHead();
		ASSERT_VALID(pft);
		CTextPool* ptp = (CTextPool*)pft->c_pTextPool;
		ASSERT_VALID(ptp);
		gConvertVAlign(pft->m_wVAlign, m_pContent->m_opt);
		gExport_WppText(*m_pContent, *ptp, obj);
	}
	else if(pEle->m_nType == CTableElement::TT_oblique)//б�߱�Ԫ
	{
		std::vector<CLtxtObj*> vecDiaText;
		for(POSITION pos = pEle->m_objList.GetHeadPosition(); pos;)
		{
			CObject* pObj = pEle->m_objList.GetNext(pos);
			if(pObj->IsKindOf(RUNTIME_CLASS(CLtxtObj)))
			{
				CLtxtObj* pLtxObj = (CLtxtObj*)pObj;
				ASSERT_VALID(pLtxObj);
				vecDiaText.push_back(pLtxObj);
			}
		}
		int DiaTextSize = vecDiaText.size();
		if (DiaTextSize > 0)
		{
			m_pContent->GetPptClientTextBox()->SetTextType(TT_HalfBody);
			for(int i = 0; i < vecDiaText.size(); i++)
			{
				CString str;
				TextStringToString(str, vecDiaText[i]->m_string);
				m_pContent->GetPptClientTextBox()->AppendText(ks_wstring((LPCTSTR)str));
				if (i < vecDiaText.size() - 1)
					m_pContent->GetPptClientTextBox()->AppendText(ks_wstring(__X("\r")));
			}
			MsoKernData* pTextBox = m_pContent->GetPptClientTextBox()->PersistTextBox(m_pAlloc);
			m_pContent->m_shape.SetClientTextBox(pTextBox);
		}
	}
	else
	{
		KSTextString* pkstr;
		if(pEle->m_nType == CTableElement::TT_formula ||
			pEle->m_nType == CTableElement::TT_roformula ||
			pEle->m_nType == CTableElement::TT_autodata ||
			pEle->m_nType == CTableElement::TT_roautodata
			)
			pkstr = &pEle->GetDSPString();//�Ҳ���������
		else
			pkstr = &pEle->GetDSPString();
#ifdef _DEBUG
		CString str;
		TextStringToString(str, *pkstr);
#endif
		CTextPool textpool;
		gCreateTextPool(*pkstr, pEle->m_AttribList, textpool);
		gExport_WppText(*m_pContent, textpool, obj, WPPCONVERT_SPECIAL_VALIGN);
		pEle->m_AttribList.RemoveAll();

//		CString str;
//		TextStringToString(str, *pkstr);
//		if (str.GetLength() > 0)
//		{
//			m_pContent->GetPptClientTextBox()->SetTextType(TT_HalfBody);
//			m_pContent->GetPptClientTextBox()->AppendText(ks_wstring((LPCTSTR)str));
//			MsoKernData* pTextBox = m_pContent->GetPptClientTextBox()->PersistTextBox(m_pAlloc);
//			m_pContent->m_shape.SetClientTextBox(pTextBox);
//		}
	}
	return S_OK;
}

HRESULT TableCell::SetAttrs(CTableElement* pEle, CWPSObj& obj)
{
	ASSERT(m_pContent);
	InfuseText(pEle, obj);
	// InfuseTextBoxProp(m_opt, pAttrs);
	InfuseShapeFillProp(pEle, m_pContent->m_opt);
	// SetDefaultCellProp(m_opt);
	SetExtraAttrs();
	/*
	KROAttributes* pSubAttrs = NULL;
	if (SUCCEEDED(pAttrs->GetByID(kso::pres_tbl_diag_down_style, &pSubAttrs)))
	{
		m_pDiagDownOpt = new MsoShapeOPT;
		
		InfuseShapeLineProp(
			*m_pDiagDownOpt, pAttrs, blipStore, 
			kso::pres_tbl_diag_down_style);
	}

	if (SUCCEEDED(pAttrs->GetByID(kso::pres_tbl_diag_up_style, &pSubAttrs)))
	{
		m_pDiagUpOpt = new MsoShapeOPT;
		InfuseShapeLineProp(
			*m_pDiagUpOpt, pAttrs, blipStore, 
			kso::pres_tbl_diag_up_style);
	}*/
	return S_OK;
}

HRESULT TableCell::InfuseShapeFillProp(CTableElement* pEle, MsoShapeOPT& opt)
{
	if (pEle->m_nBkMode == TRANSPARENT && pEle->m_logbrush.lbStyle != BS_HATCHED)
	{
		// ������ٿ�����ͼƬ���
		if (pEle->GetImage() != NULL)
		{
			gConvertImage(m_pContent->GetBlipStore(), m_pContent->m_opt,
				pEle->GetImage(), FALSE);
			m_pContent->m_opt.AddPropBool(msopt_fFilled, TRUE);
		}
	}
	else
		((CTFPBase_Export*)pEle)->ConvertShape(*m_pContent);
	return S_OK;
}

void TableCell::SetExtraAttrs()
{
	m_pContent->m_opt.ForceAddPropBool(msopt_fLockText, FALSE);
	m_pContent->m_opt.ForceAddPropBool(msopt_fNoFillHitTest, TRUE);
	m_pContent->m_opt.ForceAddPropBool(msopt_fLine, FALSE);
}

HRESULT TableCell::ConvertToShape(TableData* pTable)
{
	ASSERT(m_pContent);
	// m_pContent->m_shape = pTable->m_parentShape.NewShape(FALSE);
	m_pContent->m_shape.SetShapeType(msosptRectangle);
	m_pContent->m_shape.SetProperties(m_pContent->m_opt);

	// client data ������Ŀ����
	/*
	KPPTClientData* pData = new KPPTClientData;
	pData->SetClientTextBox(&m_txt);
	
	MsoKernData* pClientData = pData->PersistClientData(m_pAlloc);
	m_pContent->m_shape.SetClientData(pClientData);

	MsoKernData* pTextBox = m_txt.PersistTextBox(m_pAlloc);
	m_pContent->m_shape.SetClientTextBox(pTextBox);
	*/

//	pTable->GenChildAnchor(m_pContent->m_shape, 
//		m_rowStart, m_colStart, 
//		m_rowStart + m_rowSpan,	m_colStart + m_colSpan);
	return S_OK;
}

HRESULT TableCell::ConvertDiagBorders(TableData* pTable)
{
	if (m_pDiagDownOpt != NULL)
	{
		ConvertDiagBorder(*m_pDiagDownOpt, pTable, false);
	}

	if (m_pDiagUpOpt != NULL)
	{
		ConvertDiagBorder(*m_pDiagUpOpt, pTable, true);
	}
	return S_OK;
}

void TableCell::ConvertDiagBorder(MsoShapeOPT& opt, 
								  TableData* pTable,
								  bool isDiagUp)
{
	MsoShape newShape = pTable->m_parentShape.NewShape(FALSE);
	newShape.SetShapeType(msosptLine);
	if (isDiagUp)
		newShape.SetFlipV(TRUE);

	opt.ForceAddPropFix(msopt_lineEndCapStyle, msolineEndCapRound);	
	newShape.SetProperties(opt);
	
	pTable->GenChildAnchor(newShape, 
		m_rowStart, m_colStart, 
		m_rowStart + m_rowSpan,	m_colStart + m_colSpan);
}

// -------------------------------------------------------------------------
TableData::~TableData()
{
	for (int i = 0; i < m_cells.size(); ++i)
		delete m_cells[i];

	for (int i = 0; i < m_horiSegments.size(); ++i)
		delete m_horiSegments[i];

	for (int i = 0; i < m_vertSegments.size(); ++i)
		delete m_vertSegments[i];
}

void TableData::ConvertToShapes()
{
	for_each(m_cells.begin(), m_cells.end(),
		bind2nd(std::mem_fun1(&TableCell::ConvertToShape), this));

	for_each(m_horiSegments.begin(), m_horiSegments.end(),
		bind2nd(std::mem_fun1(&BorderSegment::ConvertToShape), this));

	for_each(m_vertSegments.begin(), m_vertSegments.end(),
		bind2nd(std::mem_fun1(&BorderSegment::ConvertToShape), this));
	
	for_each(m_cells.begin(), m_cells.end(),
		bind2nd(std::mem_fun1(&TableCell::ConvertDiagBorders), this));
}

void TableData::GenChildAnchor(MsoShape& shape, UINT rs, UINT cs, UINT re, UINT ce)
{
	INT32 l = m_vertPos[cs];
	INT32 r = m_vertPos[ce];
	INT32 t = m_horiPos[rs];
	INT32 b = m_horiPos[re];
	ASSERT(l >= 0);
	ASSERT(r >= 0);
	ASSERT(t >= 0);
	ASSERT(b >= 0);
	shape.SetChildAnchor(l, t, r, b);
}

#endif