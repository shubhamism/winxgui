/* -------------------------------------------------------------------------
//	�ļ���		��	anchorobj.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 18:11:25
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __ANCHOROBJ_H__
#define __ANCHOROBJ_H__

// -------------------------------------------------------------------------

enum AnchorTextType
{
	AnchorChar = 0,
	AnchorLineFree,
	AnchorLineLeft,
	AnchorLineCenter,
	AnchorLineRight,
};

class CWPSObj;
class CAnchorObj : public KSObject
{
	DECLARE_SERIAL(CAnchorObj);
public:
	CAnchorObj();	//for serialize
	CAnchorObj(CWPSObj* pObj, int nType = AnchorChar, int nHorz = 0, int nVert = 0);
	virtual ~CAnchorObj();
	
protected:
	CWPSObj* m_pAnchorObj;
	int m_AnchorType;
	int m_nOffsetHorz;
	int m_nOffsetVert;
	
public:
	void Serialize(KSArchive& ar);
	int GetType() { return m_AnchorType; }
	int GetOffsetHorz() { return m_nOffsetHorz; }
	int GetOffsetVert() { return m_nOffsetVert; }
	CWPSObj* GetWPSObj(){ return m_pAnchorObj;  }
	void Attach(CWPSObj* pObj)
	{
		ASSERT(NULL == m_pAnchorObj);
		m_pAnchorObj = pObj;
	}
	CWPSObj* Detach()
	{
		ASSERT(m_pAnchorObj);
		CWPSObj* pObj = m_pAnchorObj;
		m_pAnchorObj = NULL;
		return pObj;
	}
};

// -------------------------------------------------------------------------

#endif /* __ANCHOROBJ_H__ */
