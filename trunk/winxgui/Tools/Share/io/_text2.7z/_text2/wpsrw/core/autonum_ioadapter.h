/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_ioadapter.h
//	������		��	����
//	����ʱ��	��	2004-10-26 2:51:58 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __AUTONUM_IOADAPTER_H__
#define __AUTONUM_IOADAPTER_H__

#include <stl/map.h>

#ifndef __AUTONUM_DECLARE_H
	#include "autonum_declare.h"		// ��������
#endif // __AUTONUM_DECLARE_H

// -------------------------------------------------------------------------

class KAutoNumIOAdapter
{
public:
	typedef std::map<KAutoNumGroupSPtr,	KAutoNumGroupSPtr>		mapAutoNumDoubleGroupSPtr;
	typedef std::map<KAutoNumAtomSPtr,	KAutoNumAtomSPtr>		mapAutoNumDoubleAtomSPtr;

	typedef std::map<KAutoNumGroupSPtr, int>	mapAutoNumSPtrKey;
	typedef std::map<int, KAutoNumAtomSPtr>		mapAutoNumAtomIntKey;
	typedef std::map<KAutoNumAtomSPtr, int>		mapAutoNumAtomSPtrKey;
	typedef std::map<int, KAutoNumGroupSPtr>	mapAutoNumIntKey;
	typedef std::map<KAutoNumGroupSPtr, int>	mapAutoNumSPtrKey;
	typedef std::map<int, int>					mapAutoNumOldGroupID2Level;
private:
	mapAutoNumDoubleGroupSPtr	m_MapDoubleGroupSPtr;	// for atom copy
	mapAutoNumDoubleAtomSPtr	m_MapDoubleAtomSPtr;	// for group copy

	mapAutoNumAtomIntKey		m_MapAtomIntKey;		// for atom load
	mapAutoNumAtomSPtrKey		m_MapAtomSPtrKey;		// for atom store
	mapAutoNumIntKey			m_MapGroupIntKey;		// for group load
	mapAutoNumSPtrKey			m_MapGroupSPtrKey;		// for group load
	mapAutoNumOldGroupID2Level	m_MapOldGroupID2Level;	// for old KABINFO load
public:
	~KAutoNumIOAdapter()
	{
		Clear();
	}
	void Clear()
	{
		m_MapDoubleGroupSPtr.clear();
		m_MapDoubleAtomSPtr.clear();

		m_MapAtomIntKey.clear();
		m_MapAtomSPtrKey.clear();
		m_MapGroupIntKey.clear();
		m_MapGroupSPtrKey.clear();
		m_MapOldGroupID2Level.clear();
	}
/*	//@@ appendix
public:
	HRESULT AddGroupSPtrPair(const KAutoNumGroupSPtr& key, const KAutoNumGroupSPtr& spGroup);
	HRESULT GetGroupSPtrPair(const KAutoNumGroupSPtr& key, KAutoNumGroupSPtr& spGroup);
	HRESULT AddAtomSPtrPair(const KAutoNumAtomSPtr& key, const KAutoNumAtomSPtr& spAtom);
	HRESULT GetAtomSPtrPair(const KAutoNumAtomSPtr& key, KAutoNumAtomSPtr& spAtom);

*/	//@@ appendix
	HRESULT AddOldGroupIDKey(const int& key, const int& nOldLevel);
/*	//@@ appendix
	HRESULT GetOldLevelValue(const int& key, int& nOldLevel);

	HRESULT AddAtomIDKey(const int& key, const KAutoNumAtomSPtr& value);
	HRESULT AddAtomSPtrKey(const KAutoNumAtomSPtr& key, const int& value);
	HRESULT GetAtomSPtrValue(const int& key, KAutoNumAtomSPtr& value);
	HRESULT GetAtomIDValue(const KAutoNumAtomSPtr& key, int& value);

*/	//@@ appendix
	HRESULT AddGroupIDKey(const int& key, const KAutoNumGroupSPtr& value);
/*	//@@ appendix
	HRESULT AddGroupSPtrKey(const KAutoNumGroupSPtr& key, const int& value);
*/	//@@ appendix
	HRESULT GetGroupSPtrValue(const int& key, KAutoNumGroupSPtr& value);
/*	//@@ appendix
	HRESULT GetGroupIDValue(const KAutoNumGroupSPtr& key, int& value);
*/	//@@ appendix
};

// -------------------------------------------------------------------------

#endif /* __AUTONUM_IOADAPTER_H__ */
