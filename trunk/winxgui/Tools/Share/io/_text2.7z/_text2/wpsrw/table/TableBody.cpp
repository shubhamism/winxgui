/////////////////////////////////////////////////////////////////////////////
//
// tablebody.cpp - implementation for FrameTable objects
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

//#ifndef __STYLESHT_H
//#include "stylesht.h"		// �����������йصĲ���
//#endif

//#ifndef __WPSVIEW_H
//#include "wpsview.h"
//#endif

#include <draw/wpsobj.h>

#ifndef __FRAMEOBJ_H
#include "draw/frameobj.h"
#endif

#ifndef __FRAMETBL_H
#include "frametbl.h"
#endif

#ifndef __TABLEOBJ_H
#include "tableobj.h"
#endif

#ifndef __PTOBJ_H
#include "draw/ptobj.h"
#endif

#ifndef __WPSDOC_H
#include <core/wpsdoc.h>
#endif

#include "core/wpspage.h"

//#ifndef	_WPSREADER
//#ifndef __OBJPROP_H
//#include "objprop.h"
//#endif
//#endif	//_WPSREADER

#ifndef __CTRLCODE_H__
#include <core/ctrlcode.h>
#endif

#ifndef __FRAMETXT_H
#include <draw/frametext.h>
#endif

#ifndef __TBLBODY_H
#include "tablebody.h"
#endif

//#ifndef __SCRPTSHT_H
//#include "scrptsht.h"
//#endif

#ifndef __WPSCIMG_H
#include "draw/wpsimg.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
//	CTableBody
//IMPLEMENT_SERIAL(CTableBody, CFrameTable, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CTableBody, CFrameTable, 0xA0 | VERSIONABLE_SCHEMA)


CTableBody::CTableBody()
{
}

CTableBody::~CTableBody() 
{
}

CFPBase* FindMasterObj(CFPBase* pBdy, CObList* pList, BOOL bRemove)
{
	if (pList == NULL || pBdy == NULL)
		return NULL;

	DWORD nFindID = pBdy->GetObjID();
	POSITION pos = pList->GetHeadPosition();
	CFPBase* pHeaderMaybe = NULL;
	while (pos)
	{
		pHeaderMaybe = (CFrameTable*)pList->GetAt(pos);
		for (INT nSlvIndex = 0; nSlvIndex < pHeaderMaybe->GetSlvObjIDSize(); nSlvIndex++)
		{
			if (pHeaderMaybe->GetSlvObjID(nSlvIndex) == nFindID)
			{
				if (bRemove)
					pList->RemoveAt(pos);
				
				return pHeaderMaybe;
			}
		}
		pList->GetNext(pos);
	}

	return NULL;
}

//	��ҳ��ĸ�����ȫ��������ı���, ����������ҳ����������
void CWpsDoc::ClearTableBody(CObList& AllTableBodyList, BOOL bRemoveFrameTable)
{
	CWPSPage* pPage;
	CObList* pList;
	CTableBody* pBdy = NULL;
	CFrameTable* pTbl = NULL;
	POSITION pos, posNow;
	int		 nIDcnt;
	DWORD	dwID;
	//	������ҳ
	int nPnum = NumOfPages();
	for (int nP = 1; nP <= nPnum; nP++)
	{
		pPage = GetWPSPage(nP);
		pList = pPage->GetObjList();
		//	������ҳ��������
		for (pos = pList->GetHeadPosition(); pos;)
		{
			posNow = pos;
			pBdy = (CTableBody*)pList->GetNext(pos);
			ASSERT_VALID(pBdy);
			if (pBdy->IsKindOf(RUNTIME_CLASS(CTableBody)))
			{
				pTbl = (CFrameTable*)FindMasterObj(pBdy, pList, bRemoveFrameTable);
				ASSERT(pTbl);
				if (!pTbl)
					continue;

				if (!pTbl->IsKindOf(RUNTIME_CLASS(CFrameTable)))
					continue;

				pList->RemoveAt(posNow);	//���б�ͷ�ı���Ӷ������ժ��

				ASSERT_VALID(pTbl);

				int nRowOffset = pTbl->GetRowCount();

				//�����б�������ͷ��ɾ�����б���
				int nBodyNum = nP;
				while (pBdy)
				{
					//����������ͷ
					pTbl->JoinRowToTail(pBdy, nRowOffset);

					nIDcnt = pBdy->GetSlvObjIDSize();
					if (nIDcnt > 0)	//	˵������ҳ����
					{
						ASSERT(nIDcnt == 1);
						dwID = pBdy->GetSlvObjID(0);
						
						//ɾ������
						delete pBdy;
						pBdy = NULL;

						if (nP < nPnum)
						{
							//	ȡ��һҳ�ı��岢����һҳ��ɾ��
							pBdy = GetAndRemoveTableBodyFromPage(nBodyNum + 1, dwID);
							nBodyNum++;
						}
					}
					else
					{
						//ɾ������
						delete pBdy;
						pBdy = NULL;
					}
				}
				
				//�б���ı�ͷҪȥ������ı����Լ�����
				if (pTbl->GetSlvObjList())
					pTbl->GetSlvObjList()->RemoveAll();

				//�б���ı�ͷҪ���ù̶��и�
				pTbl->SetFixRowCol(nRowOffset, 0);

				//�б���ı�ͷҪ�������ɹ�ʽ
				pTbl->CreateFormElem();
				
				CFrameText* pTxt = (CFrameText*)FindMasterObj(pTbl, pList, FALSE);
				if (pTxt != NULL && pTxt->IsKindOf(RUNTIME_CLASS(CFrameText)))
				{
					pTxt->GetSlvObjList()->RemoveAll();
					if (bRemoveFrameTable)
						FindMasterObj(pTbl, pList, TRUE);
					AllTableBodyList.AddTail(pTxt);
				}

				AllTableBodyList.AddTail(pTbl);
			}
		}
	}
}

//�ҵ�ָ��ҳ�е�ָ�����岢�Ӷ���������ɾ��
CTableBody* CWpsDoc::GetAndRemoveTableBodyFromPage(int nP, DWORD dwID)
{
	ASSERT(nP <= NumOfPages());
	CWPSPage* pPage = GetWPSPage(nP);
	ASSERT_VALID(pPage);
	CObList* pList = pPage->GetObjList();
	CTableBody* pObj;
	//	������ҳ��������
	for (POSITION pos = pList->GetHeadPosition(); pos;)
	{
		pObj = (CTableBody*)pList->GetAt(pos);
		ASSERT_VALID(pObj);
		if (pObj->GetObjID() == dwID)
		{
			ASSERT(pObj->IsKindOf(RUNTIME_CLASS(CTableBody)));
			pList->RemoveAt(pos);
			return pObj;
		}
		pList->GetNext(pos);
	}
	return NULL;
}


void AddDefAttribToElement(CTableElement* pElem, CCtrlCode* pCD)
{
	CCtrlCode* pE = NULL;
	POSITION pos = pElem->m_AttribList.GetHeadPosition();
	while (pos)
	{
		pE = (CCtrlCode*)pElem->m_AttribList.GetNext(pos);
		if (pE && pE->GetCodeID() == pCD->GetCodeID())
		{
			return;
		}
	}
	pE = pCD->Clone();
	pElem->m_AttribList.AddTail(pE);
}

void AddDefAttribsToElement(CTableElement* pElem, const CObList& DiffList)
{
	CCtrlCode* pCD = NULL;
	POSITION pos = DiffList.GetHeadPosition();
	while (pos)
	{
		pCD = (CCtrlCode*)DiffList.GetNext(pos);
		if (pCD)
		{
			AddDefAttribToElement(pElem, pCD);
		}
	}
}

//�ڲ�ר��
//��pBody�еı�Ԫ�����ͷβ��
//����ִ�����, pBody�����
int CFrameTable::JoinRowToTail(CFrameTable* pBody, int nRowOffset)
{
	int height = pBody->m_rect.Height();
	int zoomH = m_rect.Height();
	POSITION pos;
	CTableRowCol* pRow;
	CTableRowCol* pCol1;
	CTableRowCol* pCol2;
	CTableElement* pElem;
	int n, m;

	CObList	AttribDiffList;

	CCtrlCode* pCD = NULL;
	CCtrlCode* pCDBody = NULL;
	for (int i = 0; i < CC_COUNT; i++)
	{
		pCD = (CCtrlCode*)m_AttribArray[i];
		pCDBody = (CCtrlCode*)pBody->m_AttribArray[i];
		if (pCD && pCDBody)
		{
			AttribDiffList.AddTail(pCDBody);
		}
	}
	
	pos = pBody->GetFirstRowPos();				  //���ƶ�pBody�еĳߴ�͹�ʽ
	while (pos)
	{
		pRow = pBody->GetNextRow(pos);
		pRow->MoveRow(zoomH);

		if (nRowOffset != 0)
		{
			for (n = 0; n < pRow->GetElemSize(); n++)
			{
				pElem = pRow->GetElem(n);
				ASSERT_VALID(pElem);
				m = pElem->GetType();
				if (m & CTableElement::TT_formula)
				{
					pElem->ChangeRowInFormula(0, nRowOffset);
				}
			}
		}
	}
	m_rect.bottom += height;
	Row.AddTail(&(pBody->Row));
	pBody->Row.RemoveAll();

	pos = pBody->GetFirstColPos();
	while (pos)
	{
		pCol2 = pBody->GetNextCol(pos);

		pCol1 = GetCol(XatCol(pCol2->m_rect.left));
		ASSERT(pCol1);

		if (pCol1)
		{
			pCol1->m_rect.bottom += height;

			m = pCol2->GetElemSize();
			for (n = 0; n < m; n++)
			{
				pElem = pCol2->GetElem(n);
				pElem->m_pCol = pCol1;
				pElem->m_pTbl = this;
				AddDefAttribsToElement(pElem, AttribDiffList);
				pCol1->GetElemArray()->Add((CObject*)pElem);
			}
		}
		
		pCol2->RemoveAllElem();
		delete pCol2;
	}
	pBody->Col.RemoveAll();

	return height;
}
