/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wpsdoc.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 15:33:47
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_WPSDOC_H__
#define __EX_WPSDOC_H__

#ifndef __WPSDOC_H__
#include <core/wpsdoc.h>
#endif

#ifndef __EXPORT_H__
#include <export/export.h>
#endif

#ifndef __WPSPAGE_H__
#include <core/wpspage.h>
#endif

#ifndef EX_CONV_API
#define EX_CONV_API		__forceinline STDMETHODIMP_(void)
#endif

// -------------------------------------------------------------------------

#define EX_BEGIN_CONV(TheClass)												\
STDMETHODIMP_(void) TheClass::ConvCtrlCode(									\
					CCtrlCode* pCode, KDWPropBuffer& propx)					\
{																			\
	switch ((pCode)->GetCodeID())											\
	{

#define EX_ADD_CONV(wCode, Convert)											\
	case wCode:																\
		Convert(CtrlCodeTypeCast(wCode, pCode), propx);						\
		break;

#define EX_END_CONV()														\
	default:																\
		REPORT("Unknown Propx!!!");											\
	}																		\
}

// -------------------------------------------------------------------------

template <int wCode>
struct _KCtrlCodeTraits
{
	typedef CCtrlCode CtrlCodeClass;
};

#define CtrlCodeClassOf(wCode)												\
	_KCtrlCodeTraits< wCode >::CtrlCodeClass

#define CtrlCodeTypeCast(wCode, pCode)										\
	( (_KCtrlCodeTraits< wCode >::CtrlCodeClass*)(pCode) )

#define CtrlCodeClassDecl(wCode, TheClass)									\
template <>																	\
struct _KCtrlCodeTraits< wCode >											\
{																			\
	typedef TheClass CtrlCodeClass;											\
}

// -------------------------------------------------------------------------

class CWpsDoc_Export : public CWpsDoc
{
public:
	STDMETHODIMP Export(KWpsExport& export) const;
	STDMETHODIMP NewSection(KWpsExport& export) const;
	STDMETHODIMP ExportPerPageObjs(KWpsExport& export) const;//����ÿҳ����
	STDMETHODIMP ExportAllPageObjs(KWpsExport& export) const;//��������ҳ����żҳ����

};


class CSectionInfo_Export : public CSectionInfo
{
public:
	STDMETHODIMP Convert(KWpsExport& export, KDWPropBuffer& sepx) const;
	STDMETHODIMP AddHeaderFooter(KWpsExport& export) const;
	STDMETHODIMP AddHeaderFooter(KWpsExport& export, 
							 HEADERFOOTER_TYPE headerfooterType,
							 CFrameText* pFrameText)const;
//	STDMETHODIMP AddHeaderFooter(KWpsExport& export, 
//							 HEADERFOOTER_TYPE headerfooterType,
//							 CFrameText* pFrameText, int nID)const;
	STDMETHODIMP ConvertPageBorder(KDWPropBuffer& sepx) const;
	STDMETHODIMP AddBackground(KWpsExport& export) const;
	STDMETHODIMP ConvertScriptSheet(KWpsExport& export,
									KDWPropBuffer& sepx,
									SIZE pageSize, RECT pageMargin) const;
};

class CTextPool_Export : public CTextPool
{
public:
	STDMETHODIMP Export(KWpsExport& export) const;
	STDMETHODIMP Export_FN(KWpsExport& export, const int nFNID) const;
};

class CParagraph_Content
{
private:
	KWpsExport *m_pExport;
	CParagraph *m_pParagraph;
public:
	CParagraph_Content()
	{
		m_pExport = NULL;
		m_pParagraph = NULL;
	}
	~CParagraph_Content(){}
	void SetExport(KWpsExport *pExport) { m_pExport = pExport; }
	void SetParagraph(CParagraph *pPara) { m_pParagraph = pPara; }
	KWpsExport *GetExport() { return m_pExport; }
	CParagraph *GetParagraph() { return m_pParagraph; }
};

class CParagraph_Export : public CParagraph
{
public:
	STDMETHODIMP Convert(KDWPropBuffer& papx, KWpsExport& export) const;
	STDMETHODIMP Export(CParagraph_Content& pParaContent) const;
	STDMETHODIMP Export_FN(CParagraph_Content& pParaContent, const int nFNID) const;
	STDMETHODIMP ExportContent(CParagraph_Content& pParaContent, KDWPropBuffer& papx) const;
	STDMETHODIMP CreateTocParagraphBookmark(KWpsExport& export) const;

};

class CSentence_Content
{
private:
	CParagraph *m_pParagraph;
	CSentence *m_pSentence;
	KWpsExport *m_pExport;
	BOOL bSenHasFS;
public:
	CSentence_Content()
	{
		m_pParagraph = NULL;
		m_pSentence = NULL;
		m_pExport = NULL;
		bSenHasFS = FALSE;
	}
	~CSentence_Content(){}
	void SetParagraph(CParagraph *pPara) { m_pParagraph = pPara; }
	void SetSentence(CSentence *pSen) { m_pSentence = pSen; }
	void SetExport(KWpsExport *pExport) { m_pExport = pExport; }
	void SetSenHasFS(BOOL bHasFS) { bSenHasFS = bHasFS; }

	CParagraph *GetParagraph() { return m_pParagraph; }
	CSentence *GetSentence() { return m_pSentence; }
	KWpsExport *GetExport() { return m_pExport; }
	BOOL GetSenHasFS() { return bSenHasFS; }
};

class CSentence_Export : public CSentence
{
public:
	STDMETHODIMP Convert(KDWPropBuffer& chpx, KWpsExport& export) const;
	STDMETHODIMP Export(CSentence_Content& pSenContent) const;
};

// -------------------------------------------------------------------------

// Move by Frank
class PapxCtrlCode_Context
{
private:
	KWpsExport& m_export;

	//lijun
	CParagraph_Content *m_ParaContent;
private:
	EX_CONV_API GenHAlignmentCode(CCtrlCode_Alignment* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenVAlignmentCode(CCtrlCode_Alignment* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenLineMarginCode(CCtrlCode_LineMargin* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenParaMarginCode(CCtrlCode_ParaMargin* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenAfterParaMarginCode(CCtrlCode_ParaMargin* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenFirstIndentCode(CCtrlCode_ParaIndent* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenLeftIndentCode(CCtrlCode_ParaIndent* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenRightIndentCode(CCtrlCode_ParaIndent* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenTabsCode(CCtrlCode_Tabs* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenAutoNumberCode(CCtrlCode_AutoNumber* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenParaFrameCode(CCtrlCode_ParaFrame* pCode, KDWPropBuffer& papx);
	
public:
	PapxCtrlCode_Context(KWpsExport& export) : m_export(export)
	{
		m_ParaContent = NULL;
	}

	STDMETHODIMP_(void) ConvCtrlCode(CCtrlCode* pCode, KDWPropBuffer& propx);
	STDMETHODIMP_(void) ConvertPapx(
		UINT uStyleID,
		const CObList* pAttribList,
		KDWPropBuffer& propx);
//lijun
	void SetParContent(CParagraph_Content *pParaContent) {m_ParaContent = pParaContent; }
	CParagraph_Content* GetParaContent() {return m_ParaContent;}
};

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(void) PapxCtrlCode_Context::ConvertPapx(
													  UINT uStyleID,
													  const CObList* pAttribList,
													  KDWPropBuffer& propx)
{
	propx.AddIstd(uStyleID);

	if (pAttribList)
	{
		for (POSITION pos = pAttribList->GetHeadPosition(); pos;)
		{
			CCtrlCode* pCode = (CCtrlCode*)pAttribList->GetNext(pos);
			ASSERT_VALID(pCode);
			
			ConvCtrlCode(pCode, propx);
		}
	}

	// Word��Normal��ʽ�У����п��Ƶ�ȱʡֵ���棬WPSû��������ܣ���������
	if (uStyleID == stiNormal)
		propx.AddPropFix(sprmPFWidowControl, 0);
}

// -------------------------------------------------------------------------
// Move by Frank

class ChpxCtrlCode_Context
{
private:
	KWpsExport& m_export;
	int			m_nBookmarkID;		// ���ڸ���ʵ����ǩ��ת��
	CCtrlCode_HotRef*	m_pHotRef;	// ���ڸ���ʵ��hyperlink��ת��
	
	CSentence_Content *m_pSenContent;
private:
	EX_CONV_API GenChnFontCode(CCtrlCode_Font* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenEngFontCode(CCtrlCode_Font* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenSizeCode(CCtrlCode_Size* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenAspectXCode(CCtrlCode_AspectX* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenTrackingCode(CCtrlCode_Tracking* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenItalicCode(CCtrlCode_Italic* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenBoldCode(CCtrlCode_Bold* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenUnderLineCode(CCtrlCode_UnderLine* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenUpperLineCode(CCtrlCode_UnderLine* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenStressCode(CCtrlCode_UnderLine* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenStrikeOutCode(CCtrlCode_StrikeOut* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenSSScriptCode(CCtrlCode_SSScript* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenHSSCode(CCtrlCode_HSS* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenOutRectCode(CCtrlCode_OutRect* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenBGVeinCode(CCtrlCode_BGVein* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenCharSetCode(CCtrlCode_CharSet* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenSenVisibleCode(CCtrlCode_Visible* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenReviseCode(CCtrlCode_Revise* pCode, KDWPropBuffer& papx);
	EX_CONV_API GenColorCode(CCtrlCode_Color* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenLabelCode(CCtrlCode_Label* pCode, KDWPropBuffer& chpx);
	EX_CONV_API GenHotRefCode(CCtrlCode_HotRef* pCode, KDWPropBuffer& chpx);

public:
	ChpxCtrlCode_Context(KWpsExport& export) : m_export(export)
	{
		m_nBookmarkID = INVALID_BOOKMARKID;
		m_pHotRef = NULL;
		m_pSenContent = NULL;
	}

	STDMETHODIMP_(void) ConvCtrlCode(CCtrlCode* pCode, KDWPropBuffer& propx);
	STDMETHODIMP_(void) ConvertChpx(
		const CObList* pAttribList,
		KDWPropBuffer& propx);

	int GetBookMarkID() const { return m_nBookmarkID; }
	CCtrlCode_HotRef* GetHotRef() const { return m_pHotRef; }

	void SetSenContent(CSentence_Content *pSenContent){ m_pSenContent = pSenContent; }
	CSentence_Content *GetSenContent(){ return m_pSenContent;}
};

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(void) ChpxCtrlCode_Context::ConvertChpx(
													  const CObList* pAttribList,
													  KDWPropBuffer& propx)
{
	m_nBookmarkID = INVALID_BOOKMARKID;
	m_pHotRef = NULL;

	if (pAttribList)
	{
		for (POSITION pos = pAttribList->GetHeadPosition(); pos;)
		{
			CCtrlCode* pCode = (CCtrlCode*)pAttribList->GetNext(pos);
			ASSERT_VALID(pCode);
			
			ConvCtrlCode(pCode, propx);
		}
	}

}

// -------------------------------------------------------------------------

inline
STDMETHODIMP CParagraph_Export::Convert(KDWPropBuffer& papx, KWpsExport& export) const
{
	PapxCtrlCode_Context ctrlcode(export);
	
	//����ʽ��
	UINT uStyleID = export.AddStyle_Text(m_dwStyleID, (LPCTSTR)m_strStyleName);
	
	//�����ԣ�
	ctrlcode.ConvertPapx(uStyleID, m_pAttribList, papx);
	
	return S_OK;
}

inline
STDMETHODIMP CSentence_Export::Convert(
									   KDWPropBuffer& chpx,
									   KWpsExport& export) const
{
	//����ʽ��
	if (m_dwStyleID != TSID_CHAR_DEFAULT)
		// Ϊ���д�if? ��WPS2003��Ŀ��CTextTool::GetStyleAttrib()�����ڵ�if
		// ����: ��WPS2003��, �����m_dwStyleID��ֵΪTSID_CHAR_DEFAULT, ���ֵ
		//		 �ᱻ����, ת���Ӿ����ڵĶ���������õ���ʽ
	{
		UINT uStyleID = export.AddStyle_Text(m_dwStyleID, (LPCTSTR)m_strStyleName);
		chpx.AddPropFix(sprmCIstd, uStyleID);
	}
	
	//������
	ChpxCtrlCode_Context ctrlcode(export);
	ctrlcode.ConvertChpx(m_pAttribList, chpx);
		
	return S_OK;
}

/*
 *global helper func
 */
STDMETHODIMP_(void) AddContent(KWpsExport& export, const KSWPSTextString& ts);
//��CtrlCode_Size2��ֵת��Ϊ���
INT32 gConvertCtrlCode_Size2HalfPt(const CCtrlCode_Size* pCode);

inline BOOL gIsPapxCtrlCode(CTRLCODEID id)
{
	switch(id)
	{
		case SETHALIGNMENT:
		case SETVALIGNMENT:
		case SETLINEMARGIN:
		case SETPARAMARGIN:
		case SETAFPAMARGIN:
		case SETFIRSTINDENT:
		case SETLEFTINDENT:
		case SETRIGHTINDENT:
		case SETTABS:
		case SETAUTONUMBER:
		case SETPARAFRAME:
			return TRUE;
	}
	return FALSE;
}

// -------------------------------------------------------------------------

#endif /* __EX_WPSDOC_H__ */
