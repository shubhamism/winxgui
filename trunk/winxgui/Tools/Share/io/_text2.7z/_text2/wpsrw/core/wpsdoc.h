/* -------------------------------------------------------------------------
//	�ļ���		��	wpsdoc.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 10:54:39
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPSDOC_H__
#define __WPSDOC_H__

#ifndef __WPSRW_COMMON_H__
#include <wpsrw/common.h>
#endif

#ifndef __PRES_BASIC_H__
#include <pres/basic.h>
#endif

#ifndef __TEXTPOOL_H__
#include "textpool.h"
#endif

#ifndef __SECTION_H__
#include "section.h"
#endif

#ifndef __FOOTNOTE_H__
#include "footnote.h"
#endif

#ifndef __TOCMAN_H__
#include "tocman.h"
#endif

#ifndef __DEFPROP_H__
#include "defprop.h"
#endif

#ifndef __BOOKMARK_H__
#include "bookmark.h"
#endif

#ifndef __COMMENT_H__
#include "comment.h"
#endif

#ifndef __KSOLEDATA_H__
#include "KSOledata.h"
#endif

#ifndef __REVISE_H__
#include "revise.h"
#endif

#include "core/anchorobj.h"

#pragma pack()

// -------------------------------------------------------------------------
// ���¶������ CWpsDoc::FL_EncryptedWPSFile() �����ķ���ֵ

#define	FLEF_NORMALFILE		1		// ���������������ļ���δ������
#define	FLEF_FAILTODECRYPT	2		// δ�ܳɹ��ؽ��ļ�����
#define	FLEF_DECRYPTED		3		// �ɹ��ؽ��ļ�����
#define	FLEF_DECRYPTEDCANCEL		4

// -------------------------------------------------------------------------
// ���¶������ CWpsDoc::FL_ZippedWPSFile() �����ķ���ֵ

#define	FLZF_NORMALFILE		1		// ���������������ļ���δ��ѹ��
#define	FLZF_FAILTOUNZIP	2		// δ�ܳɹ��ؽ��ļ���ѹ
#define	FLZF_UNZIPPED		3		// �ɹ��ؽ��ļ���ѹ

// -------------------------------------------------------------------------
// class CWpsDoc

class CBookMarkMan;
class CAnchorObj;
class CStyleSheet;
class CStyleSheet_Text;
interface IKFilterEventNotify;
class CWPSPage;
class CTableBody;

class CWpsDoc : public COleDocument, public _WPS_FileType
{
private:
public:
	CTextPool* c_pTextPool;
	CTextPool* c_pFootnoteTextPool;
	CObArray m_WPSPages;
	CSectionInfoManager	m_SectionInfoManager;
	CFootnoteMan m_FootnoteMan;
	
	BOOL m_bIsRevise; // �Ƿ����޶�״̬
	
	WPSFILEHEADER m_FileHeader; // �ļ�ͷ
	int	m_nCurrentPage;	// ��ǰ���ڴ�����ҳ (����ҳ��)
	
	//	ÿ���ļ��ж�������֤ID�ŵļ�������������
	//	����һ�����ļ�����ֵΪ1������һ�����ļ���Doc Serialize������Ķ���ID��+1 ���� m_nObjIDCount��������ֵ��� Undone!
	mutable DWORD	m_dwObjIDCount;		
	
	KSObList	m_lstMasterObjs;			// �������еĶ�����ʾ��ÿһҳ/��/ż��ҳ
	KSObArray	m_newAryAnchoredObjs;
	
	WPSTOCPARAS	m_TOCParas;		// ����ȡ/����Ŀ¼�йصĸ�������

	BOOL	m_bReadOnly;
	CString m_sDomainPassword; //password ����amend:wdb 
	BOOL    m_bBackGround;
	
	// ����������ʾ���������йص����������
	bmPresBgMusicPara	m_BgMusic;
//	CCdAudio			m_CDAudio;		// CD ��������.
//	CMidiWav			m_MidiWav;		// MIDI �� WAV ��������.
	
	// �������й������Ű�������õ��йر���������(by wxb)
	CString	m_strHeadPuncs;
	CString	m_strTailPuncs;
	int		m_nCP;
	BOOL	m_bGBEC;
	BOOL	m_bWWE;
	BOOL	m_bWWF;
	BOOL	m_bWWN;

	// �޶�
	KSObArray m_UserArray;								// �û���������
	// �������й��ĵ����Ե�һЩ����
protected:
	CString m_strAuthor;
	CString m_strTitle;
	CString m_strComment;
public:
	CUser*	GetUser(WORD);
	int		GetUserNum() const { return m_UserArray.GetSize(); }
	
	friend class CTextPool;

public:
	KCDefProp	m_DefProp;			//	���档ȱʡ������sjz
	int			m_nFilterIndex;		// enum FileType 
	
private:
	// serialize process

	void SetWPSFileVersion(WORD V)
	{
		ASSERT (V == VER_WINWPS97 || V == VER_WINWPS98 || V == VER_WINWPS01);
		m_FileHeader.wfhVersion = V;
	}
	
	void	SerializeNonagg(KSArchive& ar);
	void	Serialize_97(KSArchive&);
	void	Serialize_98(KSArchive&);
	void	Serialize_98_Write(KSArchive&);
	void	Serialize_98_Read(KSArchive&);
	void	Serialize_01(KSArchive&);
	void	Serialize_01_Write(KSArchive&);
	void	Serialize_01_Read(KSArchive&);
	void	Serialize_Revise(KSArchive&);
	void	Serialize_AnchoredMasterObjs(KSArchive&);
	void	ConvertOldAnchorObj();

	BOOL LoadFileHeader(CFile* pFile);
	BOOL IsValidHeader(CFile* pFile) const;
	BOOL CreateTextPoolOnFileLoad();

	BOOL ProcessWPTFile(CFile* pFile);
	BOOL ProcessAfsFile(CFile* pFile);

	BOOL LoadOLEBlockData(CFile* pFile);
	BOOL LoadStyleSheet(CFile* pFile);
	BOOL LoadDocumentData(CFile* pFile);
	BOOL LoadDocumentDataEx(BOOL fCompoundFile);
	BOOL LoadMainText(CFile* pFile);
	BOOL LoadSummaryInfo(CFile* pFile);
	BOOL LoadWPSPage(CFile* pFile, int iPage);
	BOOL LoadTOC(BOOL fCompound);
	

// ����������ʽ�йص����������
protected:
public:
	CStyleSheet_Text*	m_StySht_Text;
//	CStyleSheet			m_StySht_Image;

//	virtual BOOL InitStyleSheet();
public:
	CStyleSheet_Text* GetStyleSheet_Text() const { return m_StySht_Text; }
//	const CStyleSheet* GetStyleSheet(CWPSObj*) const;

//	BOOL ModifyTextStyleAttrib(CObList*, DWORD, CString);
	CCtrlCode* GetTextStyleAttrib(UINT, DWORD, CString);

// �й���ǩ�ı���������.
protected:
	CBookMarkMan m_BookMarkMan;
protected:
	BOOL LoadBookMarkInfo(CFile* pFile);
public:
	const CBookMarkMan* GetBookMarkMan() const { return &m_BookMarkMan; }

// �й���ע�ı���������

protected:
	KSCommentMan m_CommentMan;
	BOOL LoadCommentMan(BOOL fCompound);
public:
	KSCommentMan* GetCommentMan() { return &m_CommentMan; }

public:
	//����TableBody�����躯��
	int		NumOfPages() const { return m_WPSPages.GetUpperBound(); }
	CWPSPage* GetWPSPage(int nIndex) const { return (CWPSPage*)m_WPSPages.GetAt(nIndex); }
	//	��ҳ��ĸ�����ȫ��������ı���, ����������ҳ����������
	void ClearTableBody(CObList& AllTableBodyList, BOOL bRemoveFrameTable);
	CTableBody* GetAndRemoveTableBodyFromPage(int, DWORD);
	HANDLE	AddAnchoredObj(CWPSObj*, int = AnchorChar, int = 0,int = 0);

public:
	IStorage* m_pVBAStg;

// �������й�OLE���ݿ�
protected:
	CPtrArray m_OleDataArray;
protected:
//	BOOL LoadOLEBlockData(CFile*);
//	BOOL SaveOLEBlockData(CFile*);
public:
	HRESULT CreateStorage(LPCTSTR, COLEData**, DWORD = STGM_READWRITE);
	COLEData* OpenStorage(LPCTSTR, DWORD);

	// after wps2002 
	
	HRESULT OnWPSFileLoad2002(LPCTSTR pszFile, IStorage* pStg = NULL);
	HRESULT BeforeStorageOpened(IStorage* pIStorage, IStorage** ppIStorage);
		
	// wps2001 and before

	BOOL FL_NormalWPSFile(LPCTSTR pszFileOrNull, CFile* pFile);
	BOOL FL_NormalWPSFile_Core(LPCTSTR pszFileOrNull, CFile* pFile);

	int FL_OldWPSFile(CFile* pFile);
	BOOL ReadOldWPSFile(LPCTSTR, BOOL = FALSE);

	IKFilterEventNotify* m_pNotify;
	HRESULT DecryptWPSFile(LPCTSTR lpszFileSrc, LPCTSTR lpszFileDst);
	HRESULT DoDecryption(const char* pszFileName, LPCSTR lpszDestFile);
	UINT FL_EncryptedWPSFile(CFile* pFile);
	
	UINT FL_ZippedWPSFile(CFile* pFile);

	// initialize

	void InitTextPool();
	void InitPaperPara(int = 0);
	void InitFirstPage();
	void InitHeaderFooter(int = 0);
	BOOL InitMacroManager()
	{
		return TRUE;
	}
	
	// terminate

	void DeleteUserObjs();
	void DeleteWPSPages();
	void DeleteMasterObjects();
	void DeleteAnchoredObjects();

public:
	// document

	CWpsDoc();
	~CWpsDoc();

	BOOL InitDocument();
	void DeleteContents();

	WORD GetWPSFileVersion() const;
	
	CTextPool* GetAccessToTextPool() const { return c_pTextPool; }
	CTextPool* GetAccessToFootnoteTextPool() const { return c_pFootnoteTextPool; }

	// section

	int NumOfSection() { return m_SectionInfoManager.NumOfSection(); }
	int	GetMainSection() const { return 0; }

	CSectionInfo* GetSectionInfo(int nSection)
	{
		return m_SectionInfoManager.GetSection(nSection);
	}
	BOOL InsertSectionAt(int nSection,CSectionInfo* pSection)
	{
		ASSERT_VALID(pSection);
		m_SectionInfoManager.InsertSectionAt(nSection,pSection);
		return TRUE;
	}

	// ���������ļ���ͼ�йص����������
	CFrameImage* SetBackGroundImage(LPCTSTR, int = 0);
	CFrameImage* SetBackGroundImage(CFrameImage*, int = 0);
	BOOL IsBackGroundImage(CFrameImage* pImg) const
		;//{ return m_SectionInfoManager.IsBackGroundImage(pImg); }
	BOOL DoesBackGroundImageExist(int nSection = 0)
		;//{ return m_SectionInfoManager.DoesBackGroundImageExist(nSection); }
	BOOL IsBackGroundImageTransparent(int nSection = 0)
		;//{ return m_SectionInfoManager.IsBackGroundImageTransparent(nSection); }
	CFrameImage* GetBackGroundImage(int nSection = 0)
		{ return m_SectionInfoManager.GetBackGroundImage(nSection); }
	CSlideBackground* GetPageBackGround(int nSection = 0)
		{ return m_SectionInfoManager.GetPageBackGround(nSection); }
	
	//	����:	ȡ��ӡֽ��С
	void	GetPaperSize(CSize* pSize, BOOL bAdjust =TRUE, int nSection = 0) { m_SectionInfoManager.GetPaperSize(pSize, bAdjust, nSection); }
	void	SetPaperSize(CSize &pageSize, int nSection = 0)	{ m_SectionInfoManager.SetPaperSize(pageSize, nSection);}
	
	// 	���ܣ�	�趨ֽ������ (ͬʱ���������趨ֽ�ųߴ�. ��λ: 0.1mm)
	virtual void SetPaperType(int nType, int nSection = 0) { m_SectionInfoManager.SetPaperType(nType, nSection); }
	void	SetPaperTypeDirectly(int nType, int nSection = 0) { m_SectionInfoManager.SetPaperTypeDirectly(nType, nSection); }
	int		GetPaperType(int nSection = 0) { return m_SectionInfoManager.GetPaperType(nSection); }
	void	SetPaperOrient(int nOrient, int nSection = 0) { m_SectionInfoManager.SetPaperOrient(nOrient, nSection); }
	int		GetPaperOrient(int nSection = 0) { return m_SectionInfoManager.GetPaperOrient(nSection); }
	
	int		GetPageRectRange(int nSection = 0) { return m_SectionInfoManager.GetPageRectRange(nSection); }
	void	SetPageRectRange(int nRange, int nSection = 0){ m_SectionInfoManager.SetPageRectRange(nRange, nSection); }
	tagKPAGERECT GetPageRectInfo(int nSection = 0) { return m_SectionInfoManager.GetPageRectInfo(nSection); }	//������ȡֵ��Χ��ϲ�֪��Ч��
	void	SetPageRectInfo(tagKPAGERECT PageRect, int nSection = 0) { m_SectionInfoManager.SetPageRectInfo(PageRect, nSection); }

	// ҳüҳ��

	void	SetHeaderToTop(int n, int nSection = 0) { m_SectionInfoManager.SetHeaderToTop(n, nSection); }
	int		GetHeaderToTop(int nSection = 0) { return m_SectionInfoManager.GetHeaderToTop(nSection); }
	void	SetHeaderHeight(int n, int nSection = 0) { m_SectionInfoManager.SetHeaderHeight(n, nSection); }
	int		GetHeaderHeight(int nSection = 0) { return m_SectionInfoManager.GetHeaderHeight(nSection); }
	void	SetFooterToBottom(int n, int nSection = 0) { m_SectionInfoManager.SetFooterToBottom(n, nSection); }
	int		GetFooterToBottom(int nSection = 0) { return m_SectionInfoManager.GetFooterToBottom(nSection); }
	void	SetFooterHeight(int n, int nSection = 0) { m_SectionInfoManager.SetFooterHeight(n, nSection); }
	int		GetFooterHeight(int nSection = 0) { return m_SectionInfoManager.GetFooterHeight(nSection); }
	
	void	SetMultiHeader(BOOL bValue, int nSection = 0) { m_SectionInfoManager.SetMultiHeader(bValue, nSection); }
	BOOL	IsMultiHeader(int nSection = 0) { return m_SectionInfoManager.IsMultiHeader(nSection); }
	void	SetMultiFooter(BOOL bValue, int nSection = 0) { m_SectionInfoManager.SetMultiFooter(bValue, nSection); }
	BOOL	IsMultiFooter(int nSection = 0) { return m_SectionInfoManager.IsMultiFooter(nSection); }
	void	SetNoHeaderAtStart(BOOL bValue, int nSection = 0) { m_SectionInfoManager.SetNoHeaderAtStart(bValue, nSection); }
	BOOL	IsNoHeaderAtStart(int nSection = 0) { return m_SectionInfoManager.IsNoHeaderAtStart(nSection); }
	void	SetNoFooterAtStart(BOOL bValue, int nSection = 0) { m_SectionInfoManager.SetNoFooterAtStart(bValue, nSection); }
	BOOL	IsNoFooterAtStart(int nSection = 0) { return m_SectionInfoManager.IsNoFooterAtStart(nSection); }

	//ҳüҳ�ŵ����ʣ�����: >1��û��: 0��ͬǰ��: -1��
	int		HeaderOddStyle (int nSection) { return m_SectionInfoManager.HeaderOddStyle (nSection);}
	int		HeaderEvenStyle(int nSection) { return m_SectionInfoManager.HeaderEvenStyle(nSection);}
	int		FooterOddStyle (int nSection) { return m_SectionInfoManager.FooterOddStyle (nSection);}
	int		FooterEvenStyle(int nSection) { return m_SectionInfoManager.FooterEvenStyle(nSection);}

	// ����:	����ҳ�߽�
	void	SetPaperMargin(CRect rcSrc, int nSection = 0) { m_SectionInfoManager.SetPaperMargin(rcSrc, nSection); }
	// ȡҳ�߽�(�����˺�/�����ӡ������ҳ�Գ�, ����ҳ��ʼ�����ص�Ӱ��)
	void	GetPaperMargin(CRect* pRC, int nPage =1) { m_SectionInfoManager.GetPaperMargin(pRC, nPage); }
	
	CFrameText* GetDefaultHeaderOdd() { return m_SectionInfoManager.GetDefaultHeaderOdd(); }
	CFrameText* GetDefaultHeaderEven() { return m_SectionInfoManager.GetDefaultHeaderEven(); }
	CFrameText* GetDefaultFooterOdd() { return m_SectionInfoManager.GetDefaultFooterOdd(); }
	CFrameText* GetDefaultFooterEven() { return m_SectionInfoManager.GetDefaultFooterEven(); }
	void SetDefaultHeaderOdd(CFrameText* Header) { m_SectionInfoManager.SetDefaultHeaderOdd(Header); }
	void SetDefaultHeaderEven(CFrameText* Header) { m_SectionInfoManager.SetDefaultHeaderEven(Header); }
	void SetDefaultFooterOdd(CFrameText* Header) { m_SectionInfoManager.SetDefaultFooterOdd(Header); }
	void SetDefaultFooterEven(CFrameText* Header) { m_SectionInfoManager.SetDefaultFooterEven(Header); }
	
	void	SetSymmetric(BOOL bValue, int nSection = 0) { m_SectionInfoManager.SetSymmetric(bValue, nSection); }
	BOOL	IsSymmetric(int nSection = 0) { return m_SectionInfoManager.IsSymmetric(nSection); }
	void	SetStartFromLeft(BOOL bValue, int nSection = 0) { m_SectionInfoManager.SetStartFromLeft(bValue, nSection); }
	BOOL	IsStartFromLeft(int nSection = 0) { return m_SectionInfoManager.IsStartFromLeft(nSection); }
	
	void SetSectionTextLineMode(TextLineMode lm, int nSection) { m_SectionInfoManager.SetTextLineMode(lm, nSection); }

	void SetPageNumOrg(int, int = 0);
	int GetPageNumOrg(int nSection = 0) { return m_SectionInfoManager.GetPageNumOrg(nSection); }
	int GetRealPageNumOrg(int nSection = 0) { return m_SectionInfoManager.GetRealPageNumOrg(nSection);}
	
	// --> ����

	void SetColumns(int nColumns, int nSection) { m_SectionInfoManager.SetColumns(nColumns, nSection); }
	void SetColumnGap(int nGap, int nSection) { m_SectionInfoManager.SetColumnGap(nGap, nSection); }
	void SetColLineWidth(int nLineWidth, int nSection) { m_SectionInfoManager.SetColLineWidth(nLineWidth, nSection); }
	void SetColLineStyle(int nLineStyle, int nSection) { m_SectionInfoManager.SetColLineStyle(nLineStyle, nSection); }
	void SetColLineColor(COLORREF color, int nSection) { m_SectionInfoManager.SetColLineColor(color, nSection); }
	
	// --> ��ֽ

	void	SetScriptSheetFlag(BOOL bFlag=TRUE, int nSection = 0) { m_SectionInfoManager.SetScriptSheetFlag(bFlag, nSection); }
	BOOL	IsScriptSheet(int nSection = 0) { return m_SectionInfoManager.IsScriptSheet(nSection); }
	int		GetScriptSheetType(int nSection = 0) { return m_SectionInfoManager.GetScriptSheetType(nSection); }
	COLORREF GetScriptSheetColor(int nSection = 0) { return m_SectionInfoManager.GetScriptSheetColor(nSection); }
	void	SetScriptSheetColor(COLORREF clr, int nSection = 0) { m_SectionInfoManager.SetScriptSheetColor(clr, nSection); }
	BOOL	SetScriptSheetType(int nType, int nSection = 0) { return m_SectionInfoManager.SetScriptSheetType(nType, nSection); }
	
	/***************************************************************************
	���ܣ�	��ȡָ�������Ķ����ָ��
	��ڣ�	hID: ���������ָ������
	���ڣ�	�ɹ�ʱ���ض���ָ�룬ʧ��ʱ����NULL
	***************************************************************************/
	CAnchorObj* GetNewAnchoredObj(HANDLE hID) const
	{
		ASSERT_VALID(this);
		if (IsValidAOHandle(hID))
			return ((CAnchorObj*)(m_newAryAnchoredObjs[((int)hID)-1]));
		ASSERT(FALSE); return NULL;
	}
	
	/***************************************************************************
	���ܣ�	�жϸ��������Ķ������Ƿ�Ϸ� (AO��Anchored-Object)
	***************************************************************************/
	BOOL IsValidAOHandle(HANDLE hID) const
	{
		ASSERT_VALID(this);
		int i = ((int)hID) - 1;
		int nSize = NumOfAnchoredObjs();
		return (i >= 0 && i < nSize);
	}
	int	NumOfAnchoredObjs() const { return m_newAryAnchoredObjs.GetSize(); }
	
	DWORD GetObjIDCount() const { return m_dwObjIDCount++; }
	
#if defined(WPS_ONLY)
	BOOL QueryWPPDocType()	{ return FALSE; }
#else
	BOOL QueryWPPDocType()	{ return TRUE; }
#endif
	
public:
	// serial

	STDMETHODIMP OnWPSFileLoad(LPCTSTR pszFile);
	STDMETHODIMP OnWPSFileLoad(LPSTORAGE pStg);
	
	HRESULT PersistSections(IStorage* pRootStg, BOOL fSave); //������ȡSection����Ϣ
	CFootnoteMan* GetFootnoteMan() { return &m_FootnoteMan; }
	enum EditMode {	edit_page, edit_outline, edit_web, edit_nomal };

};

// -------------------------------------------------------------------------

int ReadWPSHeader(void* wpsHeader, CFile* file, int len);//���ڸ�д�ļ�ͷ

inline WORD CWpsDoc::GetWPSFileVersion() const
{
	ASSERT_VALID(this);
#ifdef _GWS
	ASSERT (m_FileHeader.wfhVersion == VER_GWS98 ||
		m_FileHeader.wfhVersion == VER_GWS2000);
#elif defined _WPSGW
	ASSERT (m_FileHeader.wfhVersion == VER_WINWPS97 ||
		m_FileHeader.wfhVersion == VER_WINWPS98 ||
		m_FileHeader.wfhVersion == VER_WINWPS98_GW);
#else
	ASSERT (m_FileHeader.wfhVersion == VER_WINWPS97 ||
		m_FileHeader.wfhVersion == VER_WINWPS98 ||
		m_FileHeader.wfhVersion == VER_WINWPS01);
#endif
	if (g_pWPSFHeader)
		return g_pWPSFHeader->wfhVersion;
	return  m_FileHeader.wfhVersion;
}

/*************************************************************************
���ܣ�	��������ͼ�������Ϊҳ���ͼ
��ڣ�	pImg: ����ͼ�����
���ڣ�	�ɹ�ʱ���ط��㣬ͼ�����������m_pBkGndImg��
ʧ��ʱ����FALSE
*************************************************************************/
inline CFrameImage* CWpsDoc::SetBackGroundImage (CFrameImage* pImg, int nSection/*=0*/)
{
	ASSERT_VALID (this);
	return m_SectionInfoManager.SetBackGroundImage(pImg, nSection);
}

inline void CWpsDoc::SetPageNumOrg(int nOrg, int nSection/* =0*/)
{
	m_SectionInfoManager.SetPageNumOrg(nOrg, nSection);
	/*@@todo - ����Ҫ�����Ű�
	if (m_SectionInfoManager.SetPageNumOrg(nOrg, nSection))
	{
		int nBegin, nEnd;
		int nSection = m_SectionInfoManager.GetSectionFromPage(GetCurPage());
		if (m_SectionInfoManager.GetBeginEndPageOfSection(nSection, nBegin, nEnd))
		{
			//SetPageNumOrg������ֵ������-1���ѱ�ʾ���Ͻڣ�����Ҫ����ȡһ�㱾�ڵ��߼���ʼҳ�š�
			nOrg = GetPageNumOrg(nSection);
			VERIFY(ReNumberThePages(nOrg, nBegin, nEnd));	// �ӵ�nFromҳ��ʼ��nToҳΪֹ�ر�ҳ��
		}
	} */
}

// -------------------------------------------------------------------------
// Serial Process

inline
STDMETHODIMP WPS_DoLoadWPS2002PlusExt(CWpsDoc* pDoc, IStorage* pRootStg)
{
	if (!pDoc || !pRootStg)
		return E_INVALIDARG;
	
	return pDoc->PersistSections(pRootStg, FALSE);
}

STDMETHODIMP_(BOOL) LoadAutoNumber(CFile* pFile, DWORD dwAutoNumOffset);

// -------------------------------------------------------------------------

#endif /* __WPSDOC_H__ */
