/* -------------------------------------------------------------------------
//	�ļ���		��	wpsfileiden.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 17:31:23
//	��������	��	
//	$Id: wpsfileiden.cpp,v 1.2 2005/04/25 01:58:11 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <core/wpsdoc.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

// ֻ���ݰ汾���б�
inline BOOL IsOldWpsHeader(void* pvHeader,int nHdrLen)
{
	WORD wVer;
	if (nHdrLen < 0x300)				// ����һ���汾ͷ��0x300.
		return FALSE;
	
	wVer = *(WORD*)pvHeader;
	if (wVer >= VER_DOSWINWPSFIRST &&wVer <= VER_DOSWINWPSLAST || wVer == 0xff80)
		return TRUE;
	return FALSE;	
}

// -------------------------------------------------------------------------

int ReadWPSHeader(void* wpsHeader, CFile* file, int len);

int WPS_IdentifyFileType(LPCTSTR lpszFileName, LPTSTR lParam)
{
	ASSERT(lParam == NULL);

	if (IsWPS2002File(lpszFileName))
		return CWpsDoc::wpsfile;

	CFile file;
#ifdef _GWS
	GWSFILEHEADER* pHdr;
#else
	WPSFILEHEADER* pHdr;
#endif

	int nFileType = CWpsDoc::unknownfile;
	int nReadSize;
	CFileException e;

	if (!file.Open(lpszFileName, CFile::modeRead|CFile::shareDenyNone, &e))
		return CWpsDoc::unknownfile;

	nReadSize = ReadWPSHeader(szWpsHead, &file, WPSHEADSIZE);
	file.Close();
	//
	// @@note:
	//	����ֻ�ж��Ƿ�ΪDOS WPS��ʽ��
	//	��nReadSize == 0ʱ����ʶ��ʧ�ܴ�����
	//
	if (!nReadSize)
		return CWpsDoc::unknownfile;
	

	if (nReadSize >= sizeof (WPSFILEHEADER) * sizeof(TCHAR))
	{
		// �����Ƿ�Ϊwpsfile.
		WORD wVer = *(WORD*)szWpsHead;
		
		//Ϊ��ȡ���İ��ļ��������޸�--------------------------
		if(wVer == VER_GWS2000) wVer = VER_WINWPS98;
		//----------------------------------------------------

#ifdef _GWS
		if (wVer >= VER_WINWPSFIRST || wVer >= VER_GWSFIRST)
#else
		if (wVer >= VER_WINWPSFIRST)
#endif
		{
			if (!::memcmp((LPCTSTR)szWpsHead + 2, "WPS", 3) ||
				!::memcmp((LPCTSTR)szWpsHead + 2, "GWS", 3))

			{
#ifdef _GWS
				if (wVer >= VER_WINWPSFIRST)
				{
					WPSFILEHEADER* pWpsHdr = (WPSFILEHEADER*)szWpsHead;
					if (pWpsHdr->wfhTemplateInfo)
						nFileType = CWpsDoc::wptfile;
					else if (pWpsHdr->wfhAutoSaveInfo)
						nFileType = CWpsDoc::afsfile;
					else if (pWpsHdr->wfhVersion < VER_WINWPSLATEST)
						nFileType = CWpsDoc::wpsfile; //oldwpsfile;
					else
						// ��������˸߰�ʽ����wps�ļ���
						nFileType = CWpsDoc::wpsfile;
				}
				else
				{
				pHdr = (GWSFILEHEADER*)szWpsHead;
#else
				{
				pHdr = (WPSFILEHEADER*)szWpsHead;
#endif
				if (pHdr->wfhTemplateInfo)
					nFileType = CWpsDoc::wptfile;
				else if (pHdr->wfhAutoSaveInfo)
					nFileType = CWpsDoc::wpsfile;//afsfile;
				else
				{
#ifdef _GWS
					if (pHdr->wfhVersion < VER_GWSLATEST)
#else
					if (pHdr->wfhVersion < VER_WINWPSLATEST)
#endif
						nFileType = CWpsDoc::wpsfile;//oldwpsfile;
					else
						// ��������˸߰�ʽ����wps�ļ���
						nFileType = CWpsDoc::wpsfile;
				}
				}
				// wps file don't auto-detect.
				return nFileType;
			}
		}
	}

	// �����Ƿ�Ϊ�ɰ汾��wps�ļ���
	if (IsOldWpsHeader(szWpsHead, nReadSize))
	{
		nFileType = CWpsDoc::wpstextfile;
	}

	return nFileType;
}

// -------------------------------------------------------------------------
// $Log: wpsfileiden.cpp,v $
// Revision 1.2  2005/04/25 01:58:11  wangdong
// ���಻�ٸ����ж�ĳ�ļ��Ƿ�Ϊ���ı���
//
