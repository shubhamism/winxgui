/* -------------------------------------------------------------------------
//	�ļ���		��	ctrlcode.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 22:04:06
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ctrlcode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(CCtrlCode_Color, CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Font,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Size,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_AspectX,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Tracking,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Italic,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Bold,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_UnderLine,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_StrikeOut,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Alignment,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_LineMargin,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_ParaIndent,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_ParaMargin,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Tabs,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_SSScript,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_HSS,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_DISPLAY, CCtrlCode, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CCtrlCode_ObliqueLine, CCtrlCode, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CCtrlCode_AutoNumber,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_HotRef,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Label,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Revise,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_OutRect,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_BGVein,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_CharSet,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_Visible,  CCtrlCode, VERSIONABLE_SCHEMA | 98)
IMPLEMENT_SERIAL(CCtrlCode_ParaFrame,  CCtrlCode, VERSIONABLE_SCHEMA | 98)

// -------------------------------------------------------------------------

IMPLEMENT_DYNAMIC(CCtrlCode, CObject)

void CCtrlCode::Serialize(KSArchive& ar)
{
//	CWpsDoc* pDoc = (CWpsDoc*)ar.m_pDocument;
//	WORD wVer;
//	if (pDoc)
//		wVer = pDoc->GetWPSFileVersion();
//	else
//		wVer = VER_WINWPSLATEST;

// => 2-26,'99�����ռǣ���WPS2000��paste WPS97 ������ (db)

 	WORD wVer;
	if (ar.IsLoading())
	{
		int nSchema = ar.GetObjectSchema();
		ASSERT(nSchema != -1);
		if (nSchema == 0x1000)
			wVer = VER_WINWPS97;
		else if (nSchema == 0x1001 || nSchema == 98)
			wVer = VER_WINWPS98;
		else
		{
			ASSERT(FALSE);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
	else
		wVer = VER_WINWPS98;

	switch(wVer)
	{
	case VER_WINWPS97: Serialize_97(ar); break;
	case VER_WINWPS98: Serialize_98(ar); break;
//	case VER_WINWPS01: Serialize_01(ar); break;
	}	// the last case is same as VER_WINWPSLATEST
}

// -------------------------------------------------------------------------

inline void CCtrlCode::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
}
inline void CCtrlCode::Serialize_98(KSArchive& ar)
{
	if (ar.IsStoring())
		ar << m_wID;
	else
	{
		ar >> m_wID;
		if (m_wID >= FIRSTCHARATTRIB && m_wID <= LASTCHARATTRIB)
			NULL;
		else if (m_wID >= FIRSTPARAATTRIB && m_wID <= LASTPARAATTRIB)
			NULL;
		else if (m_wID >= FIRSTTBLELEMATTRIB && m_wID <= LASTTBLELEMATTRIB)
			NULL;
		else
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/***************************************************************************
����:	������ɫ���Ʒ�����
***************************************************************************/

void CCtrlCode_Color::Serialize_97(KSArchive& ar)
{
	Serialize_98(ar);
}

void CCtrlCode_Color::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar.Write(&m_CharColor, sizeof(KCOLORINDEX));
	else
		ar.Read(&m_CharColor, sizeof(KCOLORINDEX));
}

/*-------------------------------------------------------------------------
����:	����������Ʒ�����
-------------------------------------------------------------------------*/
TCHAR g_pGBSong[6]	= _T("����");
TCHAR g_pGBKai[12]	= _T("����_GB2312");
TCHAR g_pB5Ming[10] = _T("�s�ө���");
TCHAR g_pB5Kai[8]	= _T("�з���");

void TransToGBFont(LPTSTR lpsz)
{
	strcpy(lpsz, strcmp(g_pB5Kai, lpsz) ? g_pGBSong : g_pGBKai);
}

void TransToB5Font(LPTSTR lpsz)
{
	strcpy(lpsz, strcmp(g_pGBKai, lpsz) ? g_pB5Ming : g_pB5Kai);
}

void CCtrlCode_Font::TransFaceName()
{
	if (g_wLangID == 0x0804)
		TransToGBFont(m_szFaceName);
	else
		TransToB5Font(m_szFaceName);
}

void CCtrlCode_Font::Serialize_97(KSArchive& ar)
{
	Serialize_98(ar);
}

void CCtrlCode_Font::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	WORD wLen;
	if (ar.IsStoring())
	{
		wLen = (WORD)(lstrlen(m_szFaceName)+1);	// +1: include NULL
		ar << wLen;
		ar.Write(&m_szFaceName, wLen);
	}
	else
	{
		ar >> wLen;
		ar.Read(&m_szFaceName, wLen);
#ifndef _GWSREADER
		if (m_wID == SETCHNFONT && g_wLangID != g_wCurLangID)
			TransFaceName();
#endif	// #ifndef _GWSREADER
		InvalidateLF();
	}
}

/*-------------------------------------------------------------------------
����:	�����ֺſ��Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Size::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp;
		ar >> nTemp; m_lCharSize = (LONG)nTemp;
		ar >> m_Unit;
		if (m_Unit != FSU_SIZE && m_Unit != FSU_POUND)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}
void CCtrlCode_Size::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_lCharSize;
		ar << m_Unit;
	}
	else
	{
		ar >> m_lCharSize;
		ar >> m_Unit;
		if (m_Unit != FSU_SIZE && m_Unit != FSU_POUND)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	�����ֺſ��Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_AspectX::Serialize_97(KSArchive& ar)
{
	Serialize_98(ar);
}
void CCtrlCode_AspectX::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar << m_wAspectX;
	else
	{
		ar >> m_wAspectX;
		if (m_wAspectX < ASP_MINASPECTX || m_wAspectX > ASP_MAXASPECTX)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	�����ּ����Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Tracking::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
#endif	// #ifndef _WPSREADER
	{
		INT16 nTemp;
		ar >> m_Track.wUnit;
		ar >> nTemp; m_Track.nValue = (int)nTemp;
		
		// ���������ݵĺϷ���
		if (!IsValidTracking(&m_Track))
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}
void CCtrlCode_Tracking::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_Track.wUnit;
		ar << (DWORD)m_Track.nValue;
	}
	else
	{
		DWORD	dwTemp;
		ar >> m_Track.wUnit;
		ar >> dwTemp; m_Track.nValue = (int)dwTemp;
		
		// ��WORD��ʽת�������з��ֻ���ִ�����Ӧ����һ��bug
		if (!IsValidTracking(&m_Track))
		{
			ASSERT(FALSE);
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			if (m_Track.wUnit == UNIT_METRIC)
			{
				if (m_Track.nValue < MINTRK_BYM )
					m_Track.nValue = MINTRK_BYM;
				if (m_Track.nValue > MAXTRK_BYM)
					m_Track.nValue = MAXTRK_BYM;
			}
			else if (m_Track.wUnit == UNIT_PERCENT)
			{
				m_Track.nValue = 0;
			}
		}
	}
}

/*-------------------------------------------------------------------------
����:	����б����Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Italic::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	INT16 nTemp;
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{ ar >> nTemp; m_lDegree = (LONG)nTemp; }
}
void CCtrlCode_Italic::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar << m_lDegree;
	else
		ar >> m_lDegree;
}

/*-------------------------------------------------------------------------
����:	���������Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Bold::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp; ar >> nTemp; m_lWeight = (LONG)nTemp;
		if (m_lWeight < FW_DONTCARE || m_lWeight > FW_HEAVY)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}
void CCtrlCode_Bold::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar << m_lWeight;
	else
	{
		ar >> m_lWeight;
		if (m_lWeight < FW_DONTCARE || m_lWeight > FW_HEAVY)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	�����»��߿��Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_UnderLine::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		ar >> m_wStyle;
		if (m_wStyle < PS_SOLID || m_wStyle > PS_INSIDEFRAME)
		{
			ASSERT(FALSE);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
		
		if (m_wStyle == PS_SOLID || m_wStyle == PS_INSIDEFRAME)// Ϊ�����97�ж�������̫��
			m_wStyle = PS_THIEFSOLID;							// ������ת����ϸʵ��
		m_clrLineColor = AUTOUULINECOLOR;
	}
}

void CCtrlCode_UnderLine::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_wStyle;
		ar << m_clrLineColor;
	}
	else
	{
		ar >> m_wStyle;
		ar >> m_clrLineColor;
		if ((m_wStyle != PS_WAVE) && (m_wStyle != PS_THIEFSOLID) &&
			(m_wStyle < PS_SOLID || m_wStyle > PS_INSIDEFRAME) &&
			(m_wStyle < SS_FIRST || m_wStyle > SS_LAST))
		{
			ASSERT(FALSE);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	���������Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_StrikeOut::Serialize_97(KSArchive& ar)
{
	Serialize_98(ar);
}
void CCtrlCode_StrikeOut::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar << m_wFlag;
	else
	{
		ar >> m_wFlag;
		if (m_wFlag != CC_DISABLED && m_wFlag != CC_ENABLED)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	������뷽ʽ���Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Alignment::Serialize_97(KSArchive& ar)
{
	Serialize_98(ar);
}
void CCtrlCode_Alignment::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar << m_wAlignment;
	else
		ar >> m_wAlignment;
}

/*-------------------------------------------------------------------------
����:	�����ֺſ��Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_LineMargin::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp;
		ar >> m_LineMargin.wUnit;
		ar >> nTemp; m_LineMargin.nValue = (int)nTemp;
		if (m_LineMargin.wUnit != UNIT_PERCENT && m_LineMargin.wUnit != UNIT_METRIC)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}
void CCtrlCode_LineMargin::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar.Write(&m_LineMargin, sizeof(UNIT_VALUE));
	else
	{
		ar.Read(&m_LineMargin, sizeof(UNIT_VALUE));
		if (m_LineMargin.wUnit != UNIT_PERCENT && m_LineMargin.wUnit != UNIT_METRIC
			&& m_LineMargin.wUnit != UNIT_EXACT && m_LineMargin.wUnit != UNIT_MIN
			)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	������������Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_ParaIndent::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp;
		ar >> m_Indent.wUnit;
		ar >> nTemp; m_Indent.nValue = (int)nTemp;
		if (m_Indent.wUnit != UNIT_METRIC && m_Indent.wUnit != UNIT_GRID)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}
void CCtrlCode_ParaIndent::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar.Write(&m_Indent, sizeof(UNIT_VALUE));
	}
	else
	{
		ar.Read(&m_Indent, sizeof(UNIT_VALUE));
		if (m_Indent.wUnit != UNIT_METRIC && m_Indent.wUnit != UNIT_GRID)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	����μ����Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_ParaMargin::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp;
		ar >> m_ParaMargin.wUnit;
		ar >> nTemp; m_ParaMargin.nValue = (int)nTemp;
		if (m_ParaMargin.wUnit!=UNIT_METRIC && m_ParaMargin.wUnit!=UNIT_PERCENT)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}
void CCtrlCode_ParaMargin::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar.Write(&m_ParaMargin, sizeof(UNIT_VALUE));
	else
	{
		ar.Read(&m_ParaMargin, sizeof(UNIT_VALUE));
		if (m_ParaMargin.wUnit != UNIT_METRIC && m_ParaMargin.wUnit != UNIT_PERCENT)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	����μ����Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Tabs::Serialize_97(KSArchive& ar)
{
	Serialize_98(ar);
}
void CCtrlCode_Tabs::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar.Write(m_Tabs, sizeof(m_Tabs));
	else
		ar.Read(m_Tabs, sizeof(m_Tabs));
}

/*-------------------------------------------------------------------------
����:	�������±���Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_SSScript::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp;
		ar >> m_wFlag;
		ar >> nTemp; int nHeight = (int)nTemp;
		ar >> nTemp; int nShift  = (int)nTemp;
		
		// �Ϸ��Լ��
		if (((m_wFlag < SSS_FIRST || m_wFlag > SSS_LAST) && m_wFlag != CC_DISABLED)||
			nHeight < SSS_MINHEIGHT || nHeight > SSS_MAXHEIGHT ||
			nShift < SSS_MINSHIFT || nShift > SSS_MAXSHIFT)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
		m_Data.nRelativeHeight = nHeight;
		m_Data.nRelativeShift  = nShift;
	}
}
void CCtrlCode_SSScript::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_wFlag;
		ar << (DWORD)m_Data.nRelativeHeight;
		ar << (DWORD)m_Data.nRelativeShift;
	}
	else
	{
		DWORD dwTemp;
		ar >> m_wFlag;
		ar >> dwTemp; int nHeight = (int)dwTemp;
		ar >> dwTemp; int nShift  = (int)dwTemp;
		
		// �Ϸ��Լ��
		if (((m_wFlag < SSS_FIRST || m_wFlag > SSS_LAST) && m_wFlag != CC_DISABLED)||
			nHeight < SSS_MINHEIGHT || nHeight > SSS_MAXHEIGHT ||
			nShift < SSS_MINSHIFT || nShift > SSS_MAXSHIFT)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
		m_Data.nRelativeHeight = nHeight;
		m_Data.nRelativeShift  = nShift;
	}
}

/*-------------------------------------------------------------------------
����:	�������±���Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_HSS::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		INT16 nTemp; DWORD dwTemp;
		ar >> nTemp; m_Data.hssFlag = (int)nTemp;
		ar >> nTemp; m_Data.hssDepth = (int)nTemp;
		ar >> nTemp; m_Data.hssDegree = (int)nTemp;
		ar >> dwTemp;m_Data.hssFromColor = (KCOLORINDEX)dwTemp;
		ar >> dwTemp;m_Data.hssToColor = (KCOLORINDEX)dwTemp;
		ar >> nTemp; m_Data.hssPara = (int)nTemp;
		
		// �Ϸ��Լ��
		if ((m_Data.hssFlag < HSS_FIRST || m_Data.hssFlag > HSS_LAST) &&
			m_Data.hssFlag != CC_DISABLED)
		{	TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		AfxThrowArchiveException(CArchiveException::badIndex);
		}
		// �����Ӱ���ԣ���'98����
		if (m_Data.hssFlag == SETSHADOW && m_Data.hssPara)
			m_Data.hssPara = SD_SOLIDCHAR;
	}
}

void CCtrlCode_HSS::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar.Write(&m_Data, sizeof(CHARFXHSS));
	}
	else
	{
		ar.Read(&m_Data, sizeof(CHARFXHSS));
		// �Ϸ��Լ��
		if ((m_Data.hssFlag < HSS_FIRST || m_Data.hssFlag > HSS_LAST) &&
			m_Data.hssFlag != CC_DISABLED)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_DISPLAY::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		WORD wTemp;
		ar >> wTemp;    m_bDisp = (BOOL)wTemp;
	}
}

void CCtrlCode_DISPLAY::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar.Write(&m_bDisp, sizeof(BOOL));
	else
		ar.Read(&m_bDisp, sizeof(BOOL));
}

// -------------------------------------------------------------------------

void CCtrlCode_ObliqueLine::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		INT16 nTemp;
		ar >> nTemp;    m_nObliqueLine = nTemp;
	}
}

void CCtrlCode_ObliqueLine::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
		ar.Write(&m_nObliqueLine, sizeof(int));
	else
		ar.Read(&m_nObliqueLine, sizeof(int));
}

/*-------------------------------------------------------------------------
����:	�����Զ���ſ��Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_AutoNumber::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	ASSERT(FALSE);
}

void CCtrlCode_AutoNumber::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	int nGroupID2	= 0;
	if (ar.IsStoring())
	{
		ASSERT(FALSE);
/*
		if (!g_fCompoundFile)
		{
			ar << nGroupID2; // ��ʵ��Ҳû�ã����ֵ�copy/pasteʹ������Ĵ���
		}
		else
		{
			// ��ʱ���õ�����?
			ASSERT(0);
			ar << WPSAN_WriteParaAutonum(nGroupID2, &m_ParaRefData);
		}
*/
	}
	else
	{
		if (!g_fCompoundFile)
		{
			ar >> nGroupID2;
			m_ParaRefData.m_nLevel	= nGroupID2;
			// ��level�ݴ�group����,��KABGroupInfoMan::Serialize�и���
		}
		else
		{
			ASSERT(0);	// ���������������
			int nGroupID = -1;
			ar >> nGroupID;
		//	nGroupID2 = WPSAN_ReadParaAutonum(nGroupID, m_ParaRefData);
		}
	}
}

/*-------------------------------------------------------------------------
����:	���� HotRef ���Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_HotRef::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	ASSERT(FALSE);
}

void CCtrlCode_HotRef::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	WORD wLen;
	if (ar.IsStoring())
	{
		ar << m_wHyperID;
		wLen = (WORD)(::lstrlen(m_szData) + 1);		// +1: include NULL
		ar << wLen;
		ar.Write(&m_szData, wLen);
		wLen = (WORD)(::lstrlen(m_szAnchor) + 1);		// +1: include NULL
		ar << wLen;
		ar.Write(m_szAnchor, wLen);
	}
	else
	{
		ar >> m_wHyperID;
		ar >> wLen;
		ar.Read(&m_szData, wLen);
		ar >> wLen;
		ar.Read(&m_szAnchor, wLen);
		if (m_wHyperID > LAST_REFERENCE)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

/*-------------------------------------------------------------------------
����:	���� Label ���Ʒ�����
-------------------------------------------------------------------------*/
void CCtrlCode_Label::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	ASSERT(FALSE);
}

void CCtrlCode_Label::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	WORD wLength;
	if (ar.IsStoring())
	{
		ar << m_nID;
		if (pszString)
		{
			wLength = (WORD)::lstrlen(pszString) + 1;
			ASSERT(wLength > 1);
			ar << wLength;
			ar.Write(pszString, wLength);
			ar << bIsBlock;
		}
		else
			// ���澯�棺д��Ͷ����Ĵ�СҪ��ͬ�� ʵ���ǲ�С�ġ�����ϸ�Ľ��� :( ��
			// ar << (int)0;
			ar << (WORD)0;
	}
	else
	{
		ar >> m_nID;
		ar >> wLength;
		if (wLength > 0)
		{
			ASSERT(pszString == NULL);
			pszString = new TCHAR[wLength];
			ASSERT(pszString);
			ar.Read(pszString, wLength);
			ar >> bIsBlock;
		}
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_Revise::Serialize_97(KSArchive& ar)
{
	CCtrlCode::Serialize_97(ar);
	ASSERT(FALSE);
}

void CCtrlCode_Revise::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98 (ar);
	if (ar.IsStoring())
	{
		ar << m_nCount;
		ar.Write(m_pDataBuf, m_nCount * sizeof REVISE_DATA);
	}
	else
	{
		ar >> m_nCount;
		int nSize = m_nCount * sizeof REVISE_DATA;
		TRY
		{
			m_pDataBuf = new TCHAR[nSize];
			ar.Read(m_pDataBuf, nSize);
		}
		CATCH_ALL(e)
		{
			m_nCount = 0;
		}
		END_CATCH_ALL
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_OutRect::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}
void CCtrlCode_OutRect::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_dwColor;
		ar << m_nPenStyle;
		ar << m_nWidth;
	}
	else
	{
		ar >> m_dwColor;
		ar >> m_nPenStyle;
		ar >> m_nWidth;
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_BGVein::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}

void CCtrlCode_BGVein::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_dwColor;
		ar << m_nBrushStyle;
	}
	else
	{
		ar >> m_dwColor;
		ar >> m_nBrushStyle;
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_CharSet::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}

void CCtrlCode_CharSet::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_dwCharSet;
	}
	else
	{
		ar >> m_dwCharSet;
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_Visible::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}

void CCtrlCode_Visible::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_bVisible;
	}
	else
	{
		ar >> m_bVisible;
	}
}

// -------------------------------------------------------------------------

void CCtrlCode_ParaFrame::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}

void CCtrlCode_ParaFrame::Serialize_98(KSArchive& ar)
{
	CCtrlCode::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_ParaFrame.dwFlag;
		ar << m_ParaFrame.dwColorLeft;
		ar << m_ParaFrame.nPenStyleLeft;
		ar << m_ParaFrame.nWidthLeft;
		ar << m_ParaFrame.lDistanceL;
		ar << m_ParaFrame.dwColorTop;
		ar << m_ParaFrame.nPenStyleTop;
		ar << m_ParaFrame.nWidthTop;
		ar << m_ParaFrame.lDistanceT;
		ar << m_ParaFrame.dwColorRight;
		ar << m_ParaFrame.nPenStyleRight;
		ar << m_ParaFrame.nWidthRight;
		ar << m_ParaFrame.lDistanceR;
		ar << m_ParaFrame.dwColorBottom;
		ar << m_ParaFrame.nPenStyleBottom;
		ar << m_ParaFrame.nWidthBottom;
		ar << m_ParaFrame.lDistanceB;
	}
	else
	{
		ar >> m_ParaFrame.dwFlag;
		ar >> m_ParaFrame.dwColorLeft;
		ar >> m_ParaFrame.nPenStyleLeft;
		ar >> m_ParaFrame.nWidthLeft;
		ar >> m_ParaFrame.lDistanceL;
		ar >> m_ParaFrame.dwColorTop;
		ar >> m_ParaFrame.nPenStyleTop;
		ar >> m_ParaFrame.nWidthTop;
		ar >> m_ParaFrame.lDistanceT;
		ar >> m_ParaFrame.dwColorRight;
		ar >> m_ParaFrame.nPenStyleRight;
		ar >> m_ParaFrame.nWidthRight;
		ar >> m_ParaFrame.lDistanceR;
		ar >> m_ParaFrame.dwColorBottom;
		ar >> m_ParaFrame.nPenStyleBottom;
		ar >> m_ParaFrame.nWidthBottom;
		ar >> m_ParaFrame.lDistanceB;
	}
}

// -------------------------------------------------------------------------
