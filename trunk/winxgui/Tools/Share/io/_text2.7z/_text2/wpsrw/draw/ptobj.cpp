/* -------------------------------------------------------------------------
//	�ļ���		��	ptobj.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-21 14:58:13
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CPTObj, CFPBase, 0xA0 | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

void CPTObj::Serialize_97( KSArchive& ar)
{
	CFPBase::Serialize_97(ar);
	if (ar.IsStoring())
	{
		// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		INT16 wTemp;
		ar >> wTemp;	m_center.x	= wTemp;
		ar >> wTemp;	m_center.y	= wTemp;
		ar >> wTemp;	m_theta		= (int)wTemp;
		ar >> wTemp;	m_nEndStyle = (int)wTemp;
		ar >> wTemp;	m_nEndShape[0] = (int)wTemp;
		ar >> wTemp;	m_nEndShape[1] = (int)wTemp;
	}
}

void CPTObj::Serialize_98( KSArchive& ar)
{
	CFPBase::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_center;
		ar << m_theta;
		ar << m_nEndStyle;
		ar << m_nEndShape[0];
		ar << m_nEndShape[1];
	}
	else
	{
		ar >> m_center;
		ar >> m_theta;
		ar >> m_nEndStyle;
		ar >> m_nEndShape[0];
		ar >> m_nEndShape[1];
	}
}

STDMETHODIMP CPTObj::Serialize_Write_02(CArchive& ar)
{
	WPSPTObjData rec;
	ZeroMemory(&rec, sizeof(rec));
	rec.ptCenter		= m_center;
	rec.theta			= m_theta;
	rec.nEndStyle		= m_nEndStyle;
	rec.nEndShape[0]	= m_nEndShape[0];
	rec.nEndShape[1]	= m_nEndShape[1];
	rec.bEnableField    = m_bEnableField;	// wdb[]2002-9-25]
	
	__WPSWriteRecord(ar, TAG_WPSPTObjData, rec);
	return S_OK;
}

STDMETHODIMP CPTObj::Serialize_Read_02(CArchive& ar)
{
	HRESULT hr;
	WPSPTObjData rec;
	
	rec.bEnableField = TRUE;
	hr = ReadWPSRecord<TAG_WPSPTObjData>(ar, rec);
	if (hr == S_OK)
	{
		m_center		= rec.ptCenter;
		m_theta			= rec.theta;
		m_nEndStyle		= rec.nEndStyle;
		m_nEndShape[0]	= rec.nEndShape[0];
		m_nEndShape[1]	= rec.nEndShape[1];
		m_bEnableField  = rec.bEnableField; // wdb[2002-9-25]
	}
	return hr;
}

void CPTObj::Serialize_01( KSArchive& ar)
{
	CFPBase::Serialize_01(ar);
	if (ar.IsStoring())
	{
		if (g_fCompoundFile) // wps2002-io-beta2, by tsingbo
		{
			Serialize_Write_02(ar);
			return;
		}
		ar << m_center;
		ar << m_theta;
		ar << m_nEndStyle;
		ar << m_nEndShape[0];
		ar << m_nEndShape[1];
	}
	else
	{
		if (g_fWpsObjBeta2)	// wps2002-io-beta2, by tsingbo
		{
			Serialize_Read_02(ar);
			return;
		}
		ar >> m_center;
		ar >> m_theta;
		ar >> m_nEndStyle;
		ar >> m_nEndShape[0];
		ar >> m_nEndShape[1];
	}
}

CPoint* CPTObj::NewPoints(int nPoints)
{
	CPoint* p;
	TRY
	{	p = (CPoint*)new BYTE[nPoints * sizeof(CPoint)];
		ASSERT( p);
	}
	CATCH_ALL(e)
	{	TRACE0 ("ptobj.cpp: NewPoints() failed.\n"); 
		return NULL;
	}
	END_CATCH_ALL
	if (!p)
		return NULL;
	return p;
}

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(CBarCodeObj, CPTObj, 0xA0 | VERSIONABLE_SCHEMA)

void CBarCodeObj::Serialize_97( KSArchive& ar)
{
	CPTObj::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		__int16  wTemp;
		ar >> wTemp; m_nBCSTD = (int)wTemp;
		ar >> m_strBCID;
		ar >> wTemp; m_nBCFontH = (int)wTemp;
	}
	CWPSObj::SerializeObjType(ar);
}     

void CBarCodeObj::Serialize_98( KSArchive& ar)
{
	CPTObj::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_nBCSTD;
		ar << m_strBCID;
		ar << m_nBCFontH;
	}
	else
	{
		ar >> m_nBCSTD;
		ar >> m_strBCID;
		ar >> m_nBCFontH;
	}
	CWPSObj::SerializeObjType(ar);
}

void CBarCodeObj::Serialize_01( KSArchive& ar)
{
	CPTObj::Serialize_01(ar);
	if (ar.IsStoring())
	{
		ar << m_nBCSTD;
		ar << m_strBCID;
		ar << m_nBCFontH;
	}
	else
	{
		ar >> m_nBCSTD;
		ar >> m_strBCID;
		ar >> m_nBCFontH;
	}
	CWPSObj::SerializeObjType(ar);
}

// -------------------------------------------------------------------------
