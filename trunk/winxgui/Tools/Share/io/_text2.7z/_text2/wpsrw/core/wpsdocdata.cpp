/* -------------------------------------------------------------------------
//	�ļ���		��	wpsdocdata.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 16:00:03
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <draw/frametext.h>
#include <draw/frameimg.h>
#include <draw/backgrnd.h>
#include <gws/remarks.h>
#include "wpsdoc.h"
#include "wpspage.h"
#include "scrptsht.h"
#include "anchorobj.h"

#include "autonum.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

inline CWpsImage* _GetBackGroundImage(CWpsDoc* pThis, int nSection = 0)
{
	CFrameImage* pFrame = pThis->GetBackGroundImage(nSection);
	if (pFrame)
		return pFrame->GetImage();
	return NULL;
}

void CWpsDoc::ConvertOldAnchorObj()
{
	CObject* pObj = NULL;
	for (int i = 0, len = m_newAryAnchoredObjs.GetSize(); i < len; i++)
	{
		pObj = m_newAryAnchoredObjs[i];
		if (pObj)
		{
			ASSERT_VALID(pObj);
			ASSERT(pObj->IsKindOf(RUNTIME_CLASS(CWPSObj)));
			if (!pObj->IsKindOf(RUNTIME_CLASS(CAnchorObj)))	//��һ����ȫ��Ϊ�˷�ֹ����
				pObj = new CAnchorObj((CWPSObj*)pObj);
			m_newAryAnchoredObjs[i] = pObj;
		}
	}
}

void CWpsDoc::Serialize_97(KSArchive& ar)
{
	char szDocID[] = FILEID_DOCINFT;

	if (ar.IsStoring())
		ASSERT(FALSE);
	else
	{
		__int16	wTemp;
		ar.Read(&szDocID, sizeof(szDocID) - 1);	// minus 1: exclude NULL
		if (lstrcmpi(szDocID, FILEID_DOCINFT) != 0)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
		ar >> wTemp; SetHeaderToTop(wTemp, GetMainSection());
		ar >> wTemp; SetFooterToBottom(wTemp, GetMainSection());
		ar >> wTemp; SetMultiHeader(wTemp, GetMainSection());
		ar >> wTemp; SetMultiFooter(wTemp, GetMainSection());
		ar >> wTemp; SetNoHeaderAtStart(wTemp, GetMainSection());
		ar >> wTemp; SetNoFooterAtStart(wTemp, GetMainSection());
		ar >> wTemp; SetSymmetric(wTemp, GetMainSection());
		ar >> wTemp; SetStartFromLeft(wTemp, GetMainSection());
		ar >> wTemp; SetPaperOrient(wTemp, GetMainSection());
		ar >> wTemp; SetPaperType(wTemp, GetMainSection());
		ar >> wTemp; SetScriptSheetFlag(wTemp, GetMainSection());
		ar >> wTemp; SetScriptSheetType(wTemp, GetMainSection());
		//	ar >> m_cszPageSize;
		CSize sz;
		ar >> wTemp; sz.cx = wTemp;
		ar >> wTemp; sz.cy = wTemp;
		SetPaperSize(sz, GetMainSection());
		//	ar >> m_crcOddMargin;
		CRect margin;
		ar >> wTemp; margin.left   = wTemp;
		ar >> wTemp; margin.top    = wTemp;
		ar >> wTemp; margin.right  = wTemp;
		ar >> wTemp; margin.bottom = wTemp;
		SetPaperMargin(margin, GetMainSection());
		//ar >> m_crcEvenMargin;
		ar >> wTemp; SetHeaderHeight(wTemp, GetMainSection());	// ���԰�һ��, �ļ���ʽ�������׸Ķ�
		ar >> wTemp; SetHeaderHeight(wTemp, GetMainSection());	// 4��WORD, �൱��1��m_crcEvenMargin
		ar >> wTemp; SetFooterHeight(wTemp, GetMainSection());
		ar >> wTemp; SetFooterHeight(wTemp, GetMainSection());

		ar >> wTemp; m_nCurrentPage = wTemp;

		// ���������ݵĺϷ���
		int nScriptSheetType = GetScriptSheetType(GetMainSection());
		int nPaperOrient = GetPaperOrient(GetMainSection());
		if ((nScriptSheetType < SSTYPE_FIRST || nScriptSheetType > SSTYPE_LAST) ||
			(nPaperOrient != DMORIENT_PORTRAIT && nPaperOrient != DMORIENT_LANDSCAPE))
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}

		CFrameText* pFrame = NULL;
		ar >> pFrame;
		if (pFrame)
			pFrame->SetCompLoca(CWPSObj::CL_OddPage);
		SetDefaultHeaderOdd(pFrame); pFrame = NULL; // c_pHeaderOdd;
		ar >> pFrame;
		if (pFrame)
			pFrame->SetCompLoca(CWPSObj::CL_OddPage);
		SetDefaultFooterOdd(pFrame); pFrame = NULL; // c_pFooterOdd;
		ar >> pFrame;
		if (pFrame)
			pFrame->SetCompLoca(CWPSObj::CL_EvenPage);
		SetDefaultHeaderEven(pFrame); pFrame = NULL; // c_pHeaderEven;
		ar >> pFrame;
		if (pFrame)
			pFrame->SetCompLoca(CWPSObj::CL_EvenPage);
		SetDefaultFooterEven(pFrame); pFrame = NULL; // c_pFooterEven;

		// �ر���ԭ��ֽ��ʽ
		if (IsScriptSheet(GetMainSection()))
		{
			CSize PaperSize;
			GetPaperSize(&PaperSize);
			if (!ScriptSheet.QueryQualification(&PaperSize, GetScriptSheetType(GetMainSection()), GetPaperOrient(GetMainSection())))
			{
				TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
				SetScriptSheetFlag(FALSE);	// ��ǰ��ӡֽ�ߴ粻��ԭ��ֽ��Ҫ��
			}
			//if (c_pTextPool->GetTextLineMode() != horz)	// ����ʱ����Ϊ��ֽ��ʽ
			//{	TRACE2("%s %u: Error.\n", __FILE__, __LINE__);
			//	SetScriptSheetFlag(FALSE);// =>4-21,'97�����ռ�:��ֽ��ʽ�������ì��
			//}		// =>4-24,'97�����ռ�: �򿪸�ֽ�ļ�����
			ScriptSheet.SetType(GetScriptSheetType(GetMainSection()),this,GetMainSection());
		}
	}

	// ��ȡȫ�Ķ������Ķ���
	TRY
	{
		m_newAryAnchoredObjs.Serialize(ar);
		m_lstMasterObjs.Serialize(ar);
		if (!ar.IsStoring())
		{
			DiaToRectPoly(m_newAryAnchoredObjs, this);	// ������תΪ�������
			DiaToRectPoly(m_lstMasterObjs, this);
			ConvertOldAnchorObj();	//ת�����Ķ����µĸ�ʽ[wxb 2002-5-7]
		}
	}
	CATCH_ALL(e)
	{
		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		THROW_LAST();
	}
	END_CATCH_ALL
}

// -------------------------------------------------------------------------

void CWpsDoc::Serialize_98_Write(KSArchive& ar)
{
	char	szDocID[] = FILEID_DOCINFT;
	ar.Write(&szDocID, sizeof(szDocID) - 1);	// minus 1: exclude NULL
	int nOutput;
	nOutput = GetHeaderToTop(GetMainSection());		ar << nOutput;
	nOutput = GetFooterToBottom(GetMainSection());	ar << nOutput;
	BOOL bIs;
	bIs = IsMultiHeader(GetMainSection());			ar << bIs;
	bIs = IsMultiFooter(GetMainSection());			ar << bIs;
	bIs = IsNoHeaderAtStart(GetMainSection());		ar << bIs;
	bIs = IsNoFooterAtStart(GetMainSection());		ar << bIs;
	bIs = IsSymmetric(GetMainSection());			ar << bIs;
	bIs = IsStartFromLeft(GetMainSection());		ar << bIs;
	nOutput = GetPaperOrient(GetMainSection());		ar << nOutput;
	nOutput = GetPaperType(GetMainSection());		ar << nOutput;
	bIs = IsScriptSheet(GetMainSection());			ar << bIs;
	nOutput = GetScriptSheetType(GetMainSection());	ar << nOutput;
	CSize sz; 
	GetPaperSize(&sz, FALSE, GetMainSection());		// ֱ��дԭ����
	ar << sz;
	CRect rect;
	GetPaperMargin(&rect);
	ar << rect;

	nOutput = GetHeaderHeight(GetMainSection());	ar << nOutput;	// ���԰�һ��, �ļ���ʽ�������׸Ķ�
									ar << nOutput;	// 4��WORD, �൱��1��m_crcEvenMargin
	nOutput = GetFooterHeight(GetMainSection());	ar << nOutput;
	nOutput = GetPageNumOrg(GetMainSection());		ar << nOutput;

	ar << m_nCurrentPage;

	CFrameText* pFrame;
	pFrame = GetDefaultHeaderOdd();	ar << pFrame;	// c_pHeaderOdd;
	pFrame = GetDefaultFooterOdd();	ar << pFrame;	// c_pFooterOdd;
	pFrame = GetDefaultHeaderEven();ar << pFrame;	// c_pHeaderEven;
	pFrame = GetDefaultFooterEven();ar << pFrame;	// c_pFooterEven;

	if (!g_fCompoundFile)	// by tsingbo, wps2002-io-pagebg, �°汾������˱�����
	{
		CFrameImage* pBkGndImg = GetBackGroundImage(GetMainSection());
		ar << pBkGndImg;	// ������ͼ
	}

	ar.Write(&m_TOCParas, sizeof(m_TOCParas));

	// =>��Ver.3.01.99 �Ƴ���ΪOEM���������޶�������16��
	COLORREF clr = GetScriptSheetColor(GetMainSection());
	ar << clr;		// m_clrScriptSheet;

//	BYTE byBuf[64];	// ����
	BYTE byBuf[60];	// 4 �ֽڣ�����m_clrScriptSheet
	::memset(byBuf, 0, sizeof(byBuf));
	ar.Write(byBuf, sizeof(byBuf));
}

void CWpsDoc::Serialize_98_Read(KSArchive& ar)
{
	char	szDocID[] = FILEID_DOCINFT;
	ar.Read(&szDocID, sizeof(szDocID) - 1);	// minus 1: exclude NULL
	if (lstrcmpi(szDocID, FILEID_DOCINFT) != 0)
	{
		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		AfxThrowArchiveException(CArchiveException::badIndex);
	}
	int nInput;
	ar >> nInput; SetHeaderToTop(nInput, GetMainSection());
	ar >> nInput; SetFooterToBottom(nInput, GetMainSection());
	BOOL bIs;
	ar >> bIs; SetMultiHeader(bIs, GetMainSection());
	ar >> bIs; SetMultiFooter(bIs, GetMainSection());
	ar >> bIs; SetNoHeaderAtStart(bIs, GetMainSection());
	ar >> bIs; SetNoFooterAtStart(bIs, GetMainSection());
	ar >> bIs; SetSymmetric(bIs, GetMainSection());
	ar >> bIs; SetStartFromLeft(bIs, GetMainSection());
	ar >> nInput; SetPaperOrient(nInput, GetMainSection());
	ar >> nInput; SetPaperType(nInput, GetMainSection());
	ar >> bIs; SetScriptSheetFlag(bIs, GetMainSection());
	ar >> nInput;
	if (bIs)
	{	// ���ScriptSheetFlagΪFALSEʱ�����ô˺������һ�����ԣ������������ι���
		SetScriptSheetType(nInput, GetMainSection());
	}
	//	ar >> m_cszPageSize;
	CSize sz;
	ar >> sz;	SetPaperSize(sz, GetMainSection());
	//	ar >> m_crcOddMargin;
	CRect margin;
	ar >> margin;	SetPaperMargin(margin, GetMainSection());
	//ar >> m_crcEvenMargin;
	ar >> nInput; SetHeaderHeight(nInput, GetMainSection());		// ���԰�һ��, �ļ���ʽ�������׸Ķ�
	ar >> nInput; SetHeaderHeight(nInput, GetMainSection());		// 4��WORD, �൱��1��m_crcEvenMargin
	ar >> nInput; SetFooterHeight(nInput, GetMainSection());	
	ar >> nInput; SetPageNumOrg(nInput, GetMainSection());	

	ar >> m_nCurrentPage;

	// ���������ݵĺϷ���
	int nScriptSheetType = GetScriptSheetType(GetMainSection());
	int nPaperOrient = GetPaperOrient(GetMainSection());
	if ((nScriptSheetType < SSTYPE_FIRST || nScriptSheetType > SSTYPE_LAST) ||
		(nPaperOrient != DMORIENT_PORTRAIT && nPaperOrient != DMORIENT_LANDSCAPE))
	{
		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		AfxThrowArchiveException(CArchiveException::badIndex);
	}

	CFrameText* pFrame = NULL;
	ar >> pFrame;
	if (pFrame)
		pFrame->SetCompLoca(CWPSObj::CL_OddPage);
	SetDefaultHeaderOdd(pFrame); pFrame = NULL; // c_pHeaderOdd;
	ar >> pFrame;
	if (pFrame)
		pFrame->SetCompLoca(CWPSObj::CL_OddPage);
	SetDefaultFooterOdd(pFrame); pFrame = NULL; // c_pFooterOdd;
	ar >> pFrame;
	if (pFrame)
		pFrame->SetCompLoca(CWPSObj::CL_EvenPage);
	SetDefaultHeaderEven(pFrame); pFrame = NULL; // c_pHeaderEven;
	ar >> pFrame;
	if (pFrame)
		pFrame->SetCompLoca(CWPSObj::CL_EvenPage);
	SetDefaultFooterEven(pFrame); pFrame = NULL; // c_pFooterEven;

	CFrameImage* pBkGndImg = NULL;
	if (!g_fCompoundFile)	// by tsingbo, wps2002-io-pagebg, �°汾������˱�����
	{
		ar >> pBkGndImg;	// ������ͼ, �� m_pPageBg ȡ����
		SetBackGroundImage(pBkGndImg, GetMainSection());
	}
	CSlideBackground* pPageBg = GetPageBackGround(GetMainSection());
	if (pPageBg && pBkGndImg)
		pPageBg->m_nFillType = enBG_PICTUREFILL;
	
	ar.Read(&m_TOCParas, sizeof(m_TOCParas));

	// =>��Ver.3.01.99 �Ƴ���ΪOEM���������޶�������16��
	COLORREF clrTmp;
	ar >> clrTmp;
	if (clrTmp != 0)
		SetScriptSheetColor(clrTmp, GetMainSection());

//	BYTE byBuf[64];	// ����
	BYTE byBuf[60];	// 4 �ֽڣ�����m_clrScriptSheet
	ar.Read(byBuf, sizeof(byBuf));
#ifdef _DEBUG
	// ȷ�϶��� byBuf �е�������ȫ��
	for (int i = 0; i < sizeof(byBuf)/sizeof(byBuf[0]); i++)
		{ ASSERT(byBuf[i] == 0); }
#endif
	// �ر���ԭ��ֽ��ʽ
	if (IsScriptSheet(GetMainSection()))
	{
//		ScriptSheet.SetOrient(GetPaperOrient(GetMainSection()));
		CSize PaperSize; GetPaperSize(&PaperSize, TRUE, GetMainSection());
		if (!ScriptSheet.QueryQualification(&PaperSize,
			 								GetScriptSheetType(GetMainSection()), GetPaperOrient(GetMainSection())))
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			SetScriptSheetFlag(FALSE);	// ��ǰ��ӡֽ�ߴ粻��ԭ��ֽ��Ҫ��
		}
		//if (c_pTextPool->GetTextLineMode() != horz)	// ����ʱ����Ϊ��ֽ��ʽ
		//{	TRACE2("%s %u: Error.\n", __FILE__, __LINE__);
		//	SetScriptSheetFlag(FALSE);// =>4-21,'97�����ռ�:��ֽ��ʽ�������ì��
		//}		// =>4-24,'97�����ռ�: �򿪸�ֽ�ļ�����
		ScriptSheet.SetType(GetScriptSheetType(GetMainSection()),this,GetMainSection());
	}
}

void CWpsDoc::Serialize_98(KSArchive& ar)
{
 	if (ar.IsStoring())
	{
		Serialize_98_Write(ar);
	}
	else
	{
		Serialize_98_Read(ar);
	}
	//	��ȡ�޶�����
	Serialize_Revise(ar);
	//	��������
	m_BgMusic.Serialize_98(ar);
	// ��ȡȫ�Ķ������Ķ���
	Serialize_AnchoredMasterObjs(ar);
}

// -------------------------------------------------------------------------

void CWpsDoc::Serialize_01(KSArchive& ar)
{
	if (ar.IsStoring())
		Serialize_01_Write(ar);
	else
		Serialize_01_Read(ar);

	//	��ȡ�޶�����
	Serialize_Revise(ar);
	
	//	��������
#if defined(WPS_ONLY)
	if (!g_fCompoundFile)
#endif	// {{ wps2002-io-bgmusic, wps2002������˱���
		m_BgMusic.Serialize_98(ar);

	// ��ȡȫ�Ķ������Ķ���
	Serialize_AnchoredMasterObjs(ar);
	//lijun wps2002��һ��beta�汾���Զ���ŵ�ʱ��������,����wps2003�Ĵ����������
	if (g_fCompoundFile)	
		WPSAN_ReadAutonumBeta(ar);	
	/**@@todo
	if (g_fCompoundFile)
	{
		CSlideBackground* pPageBg=GetPageBackGround(GetMainSection());
		if (ar.IsStoring())
		{
			WPSAN_WriteAutonumBeta(ar);	// wps2002-io-autonum-beta, by tsingbo
			// {{ wps2002-io-pagebg, by wdb
			pPageBg->Serialize_Write_02(ar, _GetBackGroundImage(this));
		}
		else
		{
			// wps2002-io-autonum-beta, by tsingbo
			WPSAN_ReadAutonumBeta(ar);

			// {{ wps2002-io-pagebg, by wdb
			ASSERT(GetBackGroundImage(GetMainSection()) == NULL);
			CWpsImage* pImg = NULL;
			pPageBg->Serialize_Read_02(ar, &pImg);
			if (pImg)
			{
				CFrameImage* pBkGndImg = new CFrameImage(this,CRect(0,0,0,0));
				pBkGndImg->SetImage(pImg);
				SetBackGroundImage(pBkGndImg, GetMainSection());
				if (pPageBg)
					pPageBg->m_nFillType = enBG_PICTUREFILL;
			}
		}
	}*/
}

void CWpsDoc::Serialize_01_Write(KSArchive& ar)
{
	Serialize_98_Write(ar);

	//Ϊ������ǰ���ļ�����Ӧ�Ķ�(wxb)
	// ar.Write(&m_DefProp, sizeof(m_DefProp) - DEFPROP_INCREASE_SIZE);
	// {{ ------->
	// wps2002-io-defprop, bugfix, by tsingbo
	OldDefProp_Serialize_Write_02(ar, m_DefProp);
	
	ar << m_bReadOnly;  //amend:wdb
	ar << m_sDomainPassword;
	ar << m_bBackGround;

	//ҳ��߿�=====Added by shq	23/6	2000
	tagKPAGERECT rectinfo = GetPageRectInfo(GetMainSection());
	ar.Write(&rectinfo, sizeof(rectinfo));
	int nRectrange = GetPageRectRange(GetMainSection());
	ar << nRectrange;
}

void CWpsDoc::Serialize_01_Read(KSArchive& ar)
{
	Serialize_98_Read(ar);

	//Ϊ������ǰ���ļ�����Ӧ�Ķ�(wxb)
	// ar.Read(&m_DefProp, sizeof(m_DefProp) - DEFPROP_INCREASE_SIZE);
	// {{ -------->
	// wps2002-io-defprop, bugfix, by tsingbo
	OldDefProp_Serialize_Read_02(ar, m_DefProp);
	
	ar >> m_bReadOnly; //amend:wdb
	ar >> m_sDomainPassword;
	ar >> m_bBackGround;
	tagKPAGERECT rectinfo; 
	//ҳ��߿�=====Added by shq	23/6	2000
	ar.Read(&rectinfo, sizeof(rectinfo));
	SetPageRectInfo(rectinfo, GetMainSection());
	int nRectrange;
	ar >> nRectrange;
	SetPageRectRange(nRectrange, GetMainSection());
}

// -------------------------------------------------------------------------

void CWpsDoc::SerializeNonagg(KSArchive& ar)
{
	WORD wVer = GetWPSFileVersion();
	switch (wVer)
	{
	case VER_WINWPS97:
#ifdef _GWS
	case VER_GWS98:
#endif
		Serialize_97 (ar);
		break;
	case VER_WINWPS98:
#ifdef _WPSGW
	case VER_WINWPS98_GW:
#endif
#ifdef _GWS
	case VER_GWS2000:
#endif
		Serialize_98 (ar);
		break;
	case VER_WINWPS01:
		Serialize_01(ar); 
		break;
	}
}

/**************************************************************************
	����: ���� WPS �ĵ����й����� (�ļ�ָ��ı�)
			�������������ĵ���� Serialize() ����
**************************************************************************/
BOOL CWpsDoc::LoadDocumentData(CFile* pFile)
{
	ASSERT_VALID(pFile);
	// Create an KSArchive object for loading
	CAfxArchive loadArchive(pFile, KSArchive::load | KSArchive::bNoFlushOnDelete);
	loadArchive.m_pDocument = this;
	loadArchive.m_bForceFlat = FALSE;

	// Now load the page
	TRY
	{
		SerializeNonagg((CArchive&)loadArchive);
		loadArchive.Close();
	}
	CATCH_ALL(e)
	{
		pFile->Abort(); // will not throw an exception
		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		::ReportWPSSaveLoadException(102);
		return FALSE;
	}
	END_CATCH_ALL
	return TRUE;
}

// -------------------------------------------------------------------------

void CWpsDoc::Serialize_Revise(KSArchive& ar)
{
	if (g_bExport2Wps2000)
	{
		if (m_UserArray.GetSize() > 0)
			g_uExportflag |= LOSS_REVISEUSERINFO;	// �������޶��û���Ϣ
	}
	else

	if (m_FileHeader.wfhHeaderVersion > VER_WPS2000FILEHEADER)
	{
		m_UserArray.Serialize(ar);	// ��ȡ�޶��û�����
		if (!ar.IsStoring())
		{
		/**@@todo
			void AddUser(CUser*);
			int nUsers = m_UserArray.GetSize();
			for (int n = 0; n < nUsers; n++)
				AddUser((CUser*)m_UserArray[n]);
			
			//add by zxw for BUGID:4092
			int nUserID = FindUserID(g_strUserName);
			if(nUserID == -1)
				CreateNewUser();
			else
				SetCurUserID(nUserID);
			//add by zxw end 2002-12-02 */
		}
	}
	if (m_FileHeader.wfhHeaderVersion >= 0x9902)
	{
		// ��ȡ�������Ű�ѹ����ʽ��

		{
			ar >> m_nCP;
			ar >> m_strHeadPuncs;
			ar >> m_strTailPuncs;
			ar >> m_bGBEC;
			ar >> m_bWWE;
			ar >> m_bWWF;
			ar >> m_bWWN;
		}

		CRemarks m_Remarks;              //���ڹ��İ�����ӵ�
		if (ar.IsStoring())
			m_Remarks.SaveToFile(ar);
		else
			m_Remarks.LoadFromFile(ar);
	}
}

// -------------------------------------------------------------------------

/*@@todo
inline BOOL IsWPS2001Object(CWPSObj* pObj)
{
	if (NULL == pObj)
		return FALSE;
	ASSERT_VALID(pObj);
	if (pObj->IsKindOf(RUNTIME_CLASS(CTextObj)) ||
		pObj->IsKindOf(RUNTIME_CLASS(KSDomainCalendar)) ||
		pObj->IsKindOf(RUNTIME_CLASS(KSDomainComboBox)) ||
		pObj->IsKindOf(RUNTIME_CLASS(KSDomainMailButton)) ||
		pObj->IsKindOf(RUNTIME_CLASS(KSDomainText)) ||
		pObj->IsKindOf(RUNTIME_CLASS(KSDomainCheckBox)) ||
		pObj->IsKindOf(RUNTIME_CLASS(KSDomainOption)))
		return TRUE;
	return FALSE;
}

BOOL CreateAlikeObjsForAO(CObArray* pDestArray, const CObArray* pSrcArray, CObArray* pNewObArray, CWpsDoc* pDoc)
{
	ASSERT_VALID(pDoc);
	ASSERT_VALID(pNewObArray);
	ASSERT(pNewObArray->GetSize() == 0);
	if (pSrcArray == NULL || !pSrcArray->GetSize())
		return FALSE;
	ASSERT_VALID(pDestArray);
	ASSERT_VALID(pSrcArray);
	
	BOOL bNew = FALSE;
	CAnchorObj* pAObj = NULL;
	CWPSObj* pObj = NULL;
	CWPSObj* pNewObj = NULL;
	for (int i = 0; i < pSrcArray->GetSize(); i++)
	{
		pAObj = (CAnchorObj*)pSrcArray->GetAt(i);
		ASSERT(pAObj->IsKindOf(RUNTIME_CLASS(CAnchorObj)));
		pObj = pAObj->GetWPSObj();
		if (
			::IsWPS2001Object(pObj) && 
			ULL != (pNewObj = ::CreateAlikeObjectForWPS2000(pObj, pDoc)))
		{
			// ת�����ռ�2001���ж���
			bNew = TRUE;
			pNewObArray->Add(pNewObj);
			pDestArray->Add(pNewObj);
			pNewObj = NULL;
		}
		else
			// �ռ����ж���
			pDestArray->Add(pObj);
	}
	return bNew;
}
*/

void CWpsDoc::Serialize_AnchoredMasterObjs(KSArchive& ar)
{
	// ��ȡȫ�Ķ������Ķ���
	TRY
	{
// 12-8'99 ������ GWS �ļ�����Ϊ WPS �ļ�ʱ�����湫�Ķ��󣬲���תΪ�������ֶ���
// 4-3'00 �����������ļ�����Ϊ WPS 2000 �ļ�ʱ�������Ķ���תΪ�������ֶ���
#if defined _WPSGW && !defined _WPSREADER
		if (g_bExport2Wps2000)
		{	// ���̲������������ļ���Ϊ WPS 2000 �ļ�
			CObArray array1, array2;
			CObArray* pArray;
			CObList* pList;
			pArray = CopyAlikeObjs(&m_aryAnchoredObjs, &array1);
			pList = CopyAlikeObjs(&m_lstMasterObjs, &array2);
			if (pArray)
			{
				pArray->Serialize(ar);
				delete pArray;
				while (array1.GetSize())		// ɾ���´����ĵ������ֶ���
				{
					delete array1.GetAt(0);
					array1.RemoveAt(0);
				}
				g_uExportflag  |=  LOSS_GWOBJ;	// ���Ķ���ת��
			}
			else
				m_aryAnchoredObjs.Serialize(ar);

			if (pList)
			{
				pList->Serialize(ar);
				delete pList;
				while (array2.GetSize())	// ɾ���´����ĵ������ֶ���
				{
					delete array2.GetAt(0);
					array2.RemoveAt(0);
				}
				g_uExportflag  |= LOSS_GWOBJ;
			}
			else
				m_lstMasterObjs.Serialize(ar);
		}
		else
#elif !defined _WPSREADER
		if (g_bExport2Wps2000)
		{
			ASSERT(0);/*@@todo
			// ���̲������������ļ���Ϊ WPS2000 �ļ�
			CObArray array;
			CObArray *pOrgArray, ObArray;

			pOrgArray = &m_newAryAnchoredObjs;
			//ObArray.Copy(*pOrgArray);
			//pOrgArray->RemoveAll();
			BOOL b = CreateAlikeObjsForAO(&ObArray, pOrgArray, &array, this);
			ObArray.Serialize(ar);
			if (b)
			{
				while (array.GetSize())		// ɾ���´����ĵ������ֶ���
				{
					delete array.GetAt(0);
					array.RemoveAt(0);
				}
			}
			ObArray.RemoveAll();

			CObList * pOrgList, list;
			pOrgList = &m_lstMasterObjs;
			list.AddTail(pOrgList);
			pOrgList->RemoveAll();
			b = CreateAlikeObjsForPage(pOrgList, &list, &array, this);
			pOrgList->Serialize(ar);
			if (b)
			{
				while (array.GetSize())		// ɾ���´����ĵ������ֶ���
				{
					delete array.GetAt(0);
					array.RemoveAt(0);
				}
			}
			pOrgList->RemoveAll();
			pOrgList->AddTail(&list);
			list.RemoveAll(); */
		}
		else
#endif	// #if defined _WPSGW && !defined _WPSREADER
		{
			m_newAryAnchoredObjs.Serialize(ar);
			if (!g_fCompoundFile)		//ת�����Ķ����µĸ�ʽ[wxb 2002-5-7]
				ConvertOldAnchorObj();
			
			//���´������ڹ��İ�---------------------
			{
				int nSize = m_newAryAnchoredObjs.GetSize();
				for(int i=0; i<nSize; i++)
				{
					CObject *pObj;
					pObj = m_newAryAnchoredObjs.GetAt(i);
					pObj = ConvertGWToRotateText(pObj);
					
					if(pObj) 
					   m_newAryAnchoredObjs.SetAt(i, pObj);
				}
			}
			//---------------------------------------
			m_lstMasterObjs.Serialize(ar);
			//���´������ڹ��İ�---------------------
			{
				for(POSITION pos = m_lstMasterObjs.GetHeadPosition(); pos != NULL; )
				{
					CObject *pObj;
					POSITION oldPos = pos;
					pObj = m_lstMasterObjs.GetNext( pos );
					pObj = ConvertGWToRotateText(pObj);
					
					if(pObj) 
						m_lstMasterObjs.SetAt(oldPos, pObj);
				}
			}
		}
	}
	CATCH_ALL(e)
	{
		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		THROW_LAST();
	}
	END_CATCH_ALL
}

// -------------------------------------------------------------------------
