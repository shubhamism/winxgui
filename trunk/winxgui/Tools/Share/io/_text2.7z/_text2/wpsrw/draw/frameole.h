/* -------------------------------------------------------------------------
//	�ļ���		��	frameole.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 10:18:35
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __FRAMEOLE_H__
#define __FRAMEOLE_H__

#ifndef __FRAMEOBJ_H__
#include "frameobj.h"
#endif

// -------------------------------------------------------------------------
// class CWPSOleItem

class CFrameOLE;
class CWPSOleItem : public COleClientItem
{
public:
	CFrameOLE* m_pDrawObj;    // back pointer to OLE draw object
	
public:
	DECLARE_SERIAL(CWPSOleItem)

	CWPSOleItem(COleDocument* pContainer = NULL, CFrameOLE* pDrawObj = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.
	
	BOOL IsItemCreated() const	{ return (NULL != m_lpObject); }
	void GetStorage(IStorage** ppStg)
	{
		if (!ppStg)
			return;
		*ppStg = NULL;
		if (m_lpStorage)
		{
			*ppStg = m_lpStorage;
			m_lpStorage->AddRef();
		}
	}

public:
	// needed by COleClientItem

	void CWPSOleItem::GetItemStorage() // allocate storage for new item
	{
		if (m_lpStorage && m_lpLockBytes)
			return;
		GetItemStorageFlat();
	}
	virtual void ReadItem(CArchive& ar);   // read item from archive
	virtual void WriteItem(CArchive& ar);   // write item to archive
	virtual void CommitItem(BOOL bSuccess); // commit item's storage
};

// -------------------------------------------------------------------------
// class CFrameOLE

class CFrameOLE : public CFrameObj
{
private:
	CSize 			m_extent; // current extent is tracked separate from scaled position
	CWPSOleItem* 	m_pClientItem;
	
public:
	DECLARE_SERIAL(CFrameOLE);

	CFrameOLE():m_extent(0, 0)
	{
		m_pClientItem = NULL;
/*@@todo
		m_bGenerateBackImged = TRUE;
		
		m_bDrawing = FALSE;
		m_bActivating = FALSE;
		m_bDeactivating = FALSE; */
	}

	virtual int	 CheckObjType() { return FRAMEOLE; }
	virtual void Serialize_97(KSArchive&);
	virtual void Serialize_98(KSArchive&);
	virtual void Serialize_01(KSArchive&);	

	STDMETHODIMP Serialize_Write_02(CArchive& ar);
	STDMETHODIMP Serialize_Read_02(CArchive& ar);
};

// -------------------------------------------------------------------------

#endif /* __FRAMEOLE_H__ */
