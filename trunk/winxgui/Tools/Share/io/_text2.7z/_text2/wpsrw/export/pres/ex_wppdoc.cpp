/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wppdoc.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 15:49:59
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if defined(WPP_ONLY)
#include "ex_wppdoc.h"
//tank: �ĸ��ļ�������SU��
#ifndef SU
#	define SU SUCCEEDED
#endif
#include "mso/io/powerpoint/writer.c"

#include "ex_wppanimate.h"
#include "ex_wppsound.h"
#include "ex_wppesc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/*
 *	document
 */
STDMETHODIMP CWPPDocContext::AddFont(OUT UINT16& fontIndex,
									LPCTSTR pszFontName, UINT8 lfCharSet/* = 0*/)
{
	HRESULT hr = S_OK;
	ASSERT(pszFontName && _tcslen(pszFontName));
	KPPTFontCollectionEx* pFontColl = (KPPTFontCollectionEx*)m_pptDocument.GetFontCollection();
	int iIdx = pFontColl->GetFontIndex(pszFontName);
	if(iIdx >= 0)
	{
		fontIndex = iIdx;
		return hr;
	}
	USES_CONVERSION;
	PSR_FontEntityAtom fontEntry = {0};
	wcscpy(fontEntry.lfFaceName, T2CW(pszFontName));
	fontEntry.lfCharSet = lfCharSet;
	pFontColl->AddFont(fontEntry);
	fontIndex = pFontColl->GetFontConnectionSize() - 1;
	return hr;
}

STDMETHODIMP CWPPDocContext::AddSound(IN INT nSoundid, IN BSTR strFileName, OUT INT& nRefid)
{
	SoundIt it_begin = m_Sounds.begin();
	for(; it_begin != m_Sounds.end(); it_begin++)
	{
		SoundItem& item = *it_begin;
		if ( ((nSoundid != 0) && (item.nSoundID == nSoundid)) ||
			( (strFileName != NULL) && (item.strFile == strFileName) ) )
		{
			nRefid = item.nRefID;
			return S_OK;
		}
	}
	
	PSR_Sound pSound;
	int nBuildid = 0;
	memset(&pSound, 0, sizeof(pSound));
	if (nSoundid > 0)
		pSound.SoundBuf = CreateSound(nSoundid, pSound.SoundBufLen, &pSound.SoundName, nBuildid);
	else if (!strFileName)
		pSound.SoundBuf = CreateSound(strFileName, pSound.SoundBufLen, &pSound.SoundName);
	if (!pSound.SoundBuf)
		return E_FAIL;
	pSound.SoundID = m_nLastSoundRef++;
	pSound.SoundBuildInID = nBuildid;
	pSound.SoundType = SysAllocString(__X(".WAV"));
	
	m_pptDocument.GetSoundCollection()->AddSound(&pSound);
	
	SoundItem item;
	item.nSoundID = nSoundid;
	if (strFileName)
		item.strFile = strFileName;
	item.nRefID = pSound.SoundID;
	item.nBuildid = nBuildid;

	m_Sounds.push_back(item);
	
	{
		SysFreeString(pSound.SoundName);
		SysFreeString(pSound.SoundType);
		delete pSound.SoundBuf;
	}

	nRefid = pSound.SoundID;
	return S_OK;
}

STDMETHODIMP CWPPDocContext::AddHyperLink(OUT UINT& nLinkID,
								IN CString* pstrFriendlyName, 
								IN CString* pstrLocation, 
								IN CString* pstrSubAddress)
{
	KPPTExObjList*  pExtObjs = m_pptDocument.GetExObjList();
	KPPTExHyperlink* pHyperLink = (KPPTExHyperlink*)pExtObjs->CreateExObj(PST_ExHyperlink);
	if (pstrFriendlyName)
		pHyperLink->m_strFriendName = (LPCTSTR)*pstrFriendlyName;
	if (pstrLocation)
		pHyperLink->m_strLocation = (LPCTSTR)*pstrLocation;
	if (pstrSubAddress)
		pHyperLink->m_strSubAddress = (LPCTSTR)*pstrSubAddress;
	
	nLinkID = pHyperLink->GetObjID();
	return S_OK;
}

STDMETHODIMP CWPPDocContext::AddHyperLinkDelay(OUT UINT& nLinkID, INT nIndex)
{
	KPPTExObjList*  pExtObjs = m_pptDocument.GetExObjList();
	KPPTExHyperlink* pHyperLink = (KPPTExHyperlink*)pExtObjs->CreateExObj(PST_ExHyperlink);
	DelayHyper delay;
	delay.nSlideID = nIndex;
	delay.pHyper = pHyperLink;
	m_DelayHypers.push_back(delay);
	nLinkID = pHyperLink->GetObjID();
	return S_OK;
}

STDMETHODIMP CWPPDocContext::FinishDelayHypers()
{
	INT nCount = m_DelayHypers.size();
	for (int i = 0; i < nCount;i++)
	{
		DelayHyper& delay = m_DelayHypers[i];
		SlideMapIt it = m_SlideMap.begin();
		KPPTSlide* pSlide = NULL;
		int nSlideIndex = 1;
		for (; it != m_SlideMap.end(); it++)
		{
			CWPPSlideExport* pWppSlide = (CWPPSlideExport*)(it->first);
			if (delay.nSlideID == pWppSlide->GetSlideID())
			{
				pSlide = (KPPTSlide*)(it->second);
				break;
			}
			nSlideIndex++;
		}
		if (pSlide)
		{
			int nID = pSlide->GetSlideID();
			TCHAR frendName[256] = {0};
			TCHAR subName[256] = {0};
			wsprintf(frendName, __T("�õ�Ƭ %d"), nSlideIndex);
			wsprintf(subName,__T("%d,%d,�õ�Ƭ %d"), nID, nSlideIndex, nSlideIndex);
			delay.pHyper->m_strFriendName = frendName;
			delay.pHyper->m_strSubAddress = subName;
		}
		else
		{
			ASSERT(!"�����������û���ҵ���Ӧ��slide");
		}
	}
	return S_OK;
}

STDMETHODIMP CWPPDocContext::RegisterSlideMap(CWPPSlideExport* pWppSlide, 
											  KPPTSlide* pPPTSlide)
{
	if (m_SlideMap.find(pWppSlide) != m_SlideMap.end())
		ASSERT(!"���slide�Ѿ�ע����");
	m_SlideMap[pWppSlide] = pPPTSlide;
	return S_OK;
}
BOOL CWPPDocContext::GetBlipFromImg(CWpsImage& img, OUT MsoBlip& blip)
{
	ImgBlipMap::iterator it = m_ImgBlipMap.find(&img);
	if(it != m_ImgBlipMap.end())
	{
		blip = (*it).second;
		return TRUE;
	}
	else
		return FALSE;
}
void CWPPDocContext::StoreBlip(CWpsImage& img, MsoBlip blip)
{
	m_ImgBlipMap.insert(ImgBlipMap::value_type(&img, blip));
}


StyleAttrCacheItem*	CWPPDocContext::FindStyleAttrCacheItem(PPT_TextType textType,
		int nLevel, CShape_Context* shapeCtx)
{
	StyleSheetAttrCache::iterator it = m_AttrCache.begin();
	while (it != m_AttrCache.end())
	{
		StyleAttrCacheItem* pItem = (StyleAttrCacheItem*)*it;
		if (pItem->textType == textType && pItem->nLevel == nLevel)
			return pItem;
		it++;
	}
	StyleAttrCacheItem* pItem = new StyleAttrCacheItem;
	pItem->nLevel = nLevel;
	pItem->textType = textType;
	pItem->m_nPlaceHolderID = shapeCtx->GetPlaceHolderID();
	m_AttrCache.push_back(pItem);
	return pItem;
}

StyleAttrCacheItem* CWPPDocContext::GetStyleAttrItem(PPT_TextType textType,
		int nLevel)
{
	StyleSheetAttrCache::iterator it = m_AttrCache.begin();
	while (it != m_AttrCache.end())
	{
		StyleAttrCacheItem* pItem = (StyleAttrCacheItem*)*it;
		if (pItem->textType == textType && pItem->nLevel == nLevel)
			return pItem;
		it++;
	}
	return NULL;
}

STDMETHODIMP CWPPDocContext::BeforeExportStyle(PPT_TextType textType,
	int nLevel, CObList* pList)
{
	StyleSheetAttrCache::iterator it = m_AttrCache.begin();
	while (it != m_AttrCache.end())
	{
		StyleAttrCacheItem* pItem = (StyleAttrCacheItem*)*it;
		if (pItem->textType == textType && pItem->nLevel == nLevel)
		{
			for (POSITION pos = pItem->m_List.GetHeadPosition();pos;)
			{
				CCtrlCode* pCode = (CCtrlCode*)pItem->m_List.GetNext(pos);
				ASSERT(pCode);
				pList->AddTail(pCode);
			}
		}
		it++;
	}
	return S_OK;
}

CWPPDocContext::~CWPPDocContext()
{
	StyleSheetAttrCache::iterator it = m_AttrCache.begin();
	while (it != m_AttrCache.end())
	{
		StyleAttrCacheItem* pItem = (StyleAttrCacheItem*)*it;
		ASSERT(pItem);
		while (!pItem->m_List.IsEmpty())
			pItem->m_List.RemoveHead();
		delete pItem;
		it++;
	}
	m_AttrCache.clear();
}

STDMETHODIMP CWPPDocExport::ExportNamedShows(CWPPDocContext& docuCtx) const
{
#ifdef _DEBUG
	m_SelfDefList.Dump(afxDump);
#endif
	int nShowIndex = 0;
	CSelfDefList* defList = (CSelfDefList*)&m_SelfDefList;
	for (POSITION pos = defList->GetHeadPosition(); pos;)
	{
		CSelfDefObj* pNamedShow = &(defList->GetNext(pos));
		ASSERT(pNamedShow);
		ASSERT(pNamedShow->m_SelfDef.size() > 0);
		if (!pNamedShow) continue;
		nShowIndex ++;
		int nSlideCount = pNamedShow->m_SelfDef.size();
		if (nSlideCount <= 0) continue;

		KPPTCustomSlideShow* pCustom = docuCtx.GetPptDocument().AddCustomShow();

		BSTR strName = NULL;
		if (!pNamedShow->m_szName.IsEmpty())
			strName = pNamedShow->m_szName.AllocSysString();
		else
		{
			CString str;
			str.Format("�Զ��岥�� %d", nShowIndex);
			strName = str.AllocSysString();
		}
		pCustom->SetName(strName);
		::SysFreeString(strName);

		
		CSelfDef::iterator itSlide = pNamedShow->m_SelfDef.begin();
		for (int i = 0; i < nSlideCount; i ++)
		{
			CWPPSlideExport* pWppSlide = (CWPPSlideExport*)*itSlide;
			if (docuCtx.m_SlideMap.find(pWppSlide) == docuCtx.m_SlideMap.end())
			{
				ASSERT(!"Slide û�ҵ�");
				continue;
			}
			KPPTSlide* pSlide = docuCtx.m_SlideMap[pWppSlide];
			pCustom->AddSlide(pSlide->GetSlideID());
			itSlide++;
		}
	}
	return S_OK;
}
STDMETHODIMP CWPPDocExport::Export(CWPPDocContext& docuCtx) const
{
	HRESULT hr = S_OK;
	//
	hr = ExportGlobal(docuCtx);
	//
	hr = ExportMasters(docuCtx);
	//
	hr = ExportSlides(docuCtx);

	// ��������Ҫ���Ķ��⹤��
	docuCtx.FinishDelayHypers();

	ExportNamedShows(docuCtx);
	return hr;
}

STDMETHODIMP CWPPDocExport::ExportGlobal(CWPPDocContext& docuCtx) const
{
	HRESULT hr = S_OK;
	//����Ĭ�ϵ�Ӣ ������
	UINT16 fontIdx;
	docuCtx.AddFont(fontIdx, _T("Arial"));//_T("Times New Roman"))
	docuCtx.AddFont(fontIdx, _T("����"), GB2312_CHARSET);
	//
	// liupeng: �����ҳ�����õ�ֽ�Ŵ�С�Ǵ���ģ�

	docuCtx.GetPptDocument().SetSlideSizeType(DA_Custom);
	CSize wppPaperSize;
	docuCtx.GetWppDocument().GetPaperSize(&wppPaperSize);
	docuCtx.GetPptDocument().SetSlideSize(WpsShapeToPptUnit(wppPaperSize.cx), WpsShapeToPptUnit(wppPaperSize.cy));
	//
	docuCtx.GetPptDocument().SetFirstSlide(docuCtx.GetWppDocument().GetPageNumOrg());
	
	return hr;
}

STDMETHODIMP CWPPDocExport::ExportMasters(CWPPDocContext& docuCtx) const
{
	HRESULT hr = S_OK;
	//
	{
		CWPPMasterExport* wppSlideMasterEx = (CWPPMasterExport*)m_pSlideMaster;
		ASSERT(wppSlideMasterEx);
		CWPPMasterContext slideMasterCtx(docuCtx, PS_MainMaster);
		hr = wppSlideMasterEx->Export(slideMasterCtx);
	
		CWPPMasterExport* wppTitleMasterEx = (CWPPMasterExport*)m_pTitleMaster;
		ASSERT(wppTitleMasterEx);
		CWPPMasterContext titleMasterCtx(docuCtx, PS_TitleMaster);
		hr = wppTitleMasterEx->Export(titleMasterCtx);

		hr = wppSlideMasterEx->ExportStyles(slideMasterCtx);
	}

	return hr;
}

STDMETHODIMP CWPPDocExport::ExportSlides(CWPPDocContext& docuCtx) const
{
	HRESULT hr = S_OK;

	const CObArray& wppPages = GetWPPEditEnv() == enWPP_SlideEditEnv ? m_WPSPages : m_arPagesEnvBak;
	int nWppPages = wppPages.GetSize();
	int i;
	for(i = 1; i < nWppPages; ++i)
	{
		CWPPSlideExport* pWppSlideEx = (CWPPSlideExport*)wppPages[i];
		ASSERT(pWppSlideEx);
		CWPPSlideContext slideCtx(docuCtx, PS_Slide);
		hr = pWppSlideEx->Export(slideCtx);
		docuCtx.RegisterSlideMap(pWppSlideEx, slideCtx.GetPptSlide());
	}
	return hr;
}

/*
 *	slidebase
 */
MsoShape CWPPSlideBaseContext::AddShape(const RECT& rc, BOOL fGroupShape /*= FALSE*/)
{
	KPPTClientAnchor clientAnchor = {
			WpsShapeToPptUnit(rc.left), WpsShapeToPptUnit(rc.top),
			WpsShapeToPptUnit(rc.right), WpsShapeToPptUnit(rc.bottom)
	};
	MsoShape shape = GetPptSlide()->GetDrawing()->GetRootShape().NewShape(fGroupShape);
	shape.SetClientAnchor(clientAnchor.PersistAnchor(
				&(GetDocuCtx().GetAutoFreeAlloc()))
			);
	return shape;
}

int g_ObjIndex2ObjLayoutFlag[MAX_OBJS_IN_LAYOUT] = 
{
	enumWPP_ObjLayoutFlag_Title,	//���ʽ�ı������
	enumWPP_ObjLayoutFlag_Body,		//���ʽ������(Body)���
	enumWPP_ObjLayoutFlag_Body_2,	//���ʽ������(Body)��أ��ڶ������Ķ���
	enumWPP_ObjLayoutFlag_Body_3,	//���ʽ������(Body)��أ����������Ķ���
	enumWPP_ObjLayoutFlag_Body_4,	//���ʽ������(Body)��أ����ĸ����Ķ���
	enumWPP_ObjLayoutFlag_Body_5,	//���ʽ������(Body)��أ���������Ķ���
	enumWPP_ObjLayoutFlag_Body_6,	//���ʽ������(Body)��أ����������Ķ���
	enumWPP_ObjLayoutFlag_Body_7	//���ʽ������(Body)��أ����߸����Ķ���
};

UINT8 CWPPSlideBaseContext::FindPlaceHolderID(CWPSObj& wpsObj, const CObList& oblist)
{
	UINT8 retVal = PH_NONE;
	for(POSITION pos = oblist.GetHeadPosition(); pos;)
	{
		if((int)&wpsObj == (int)oblist.GetNext(pos))
		{
			for (int i = 0; i < MAX_OBJECTS_IN_LAYOUT;i++)
			{
				if((m_layout.placeholderId[i] != PH_NONE) && 
				   (wpsObj.GetWPPObjLayoutFlag() == g_ObjIndex2ObjLayoutFlag[i]))
				{					
					return m_layout.placeholderId[i];
				}
			}
		}		
	}
	return PH_NONE;
}


STDMETHODIMP CWPPSlideBaseExport::Export(CWPPSlideBaseContext& slideBaseCtx) const
{
	HRESULT hr = S_OK;
	//��ɫ����
	ASSERT(m_pICS);
	MSOPPTCOLORSCHEME colorScheme = {0};
	m_pICS->GetColors((COLORREF*)colorScheme.m_Colors, 8);
	for(int i = 0; i < 8 ; i++)
	{
		colorScheme.m_Colors[i] &= 0x00ffffff;
	}
	hr = slideBaseCtx.GetPptSlide()->SetSlideColorScheme(colorScheme);
	//background
	hr = ExportBackground(slideBaseCtx);
	//

	return hr;
}

class MsoBlipEx : public MsoBlip
{
public:
	MsoBlipEx()
	{
		m_data = NULL;
	}
};
STDMETHODIMP CWPPSlideBaseExport::ExportBackground(CWPPSlideBaseContext& slideBaseCtx) const
{
	HRESULT hr = S_OK;
	CWPPDoc& wppDoc = slideBaseCtx.GetWppDocument();
	CWpsImage* pImg = NULL;
	if(m_Background.m_nImgId != -1)
	{
		KCWPPImgPackage* pImgPack = wppDoc.GetDocImgPackage(m_Background.m_nImgId);
		ASSERT(pImgPack);
		if (pImgPack)
			pImg = pImgPack->m_pImg;
	}
	MsoBlipEx ExistBlip;
	MsoBlipEx NewBlip;
	BOOL fSetNewBlip = FALSE;

	if(pImg)
	{
		slideBaseCtx.GetDocuCtx().GetBlipFromImg(*pImg, ExistBlip);
	}
	gCovertBackground(
		slideBaseCtx.GetPptSlide()->GetDrawing()->GetBackground(),
		slideBaseCtx.GetPptDocument().GetDrawingGroup()->GetBlipStore(),
		(CSlideBackground*)&m_Background, pImg, &ExistBlip, &NewBlip
		);
	if(pImg && NewBlip.Good())
	{
		slideBaseCtx.GetDocuCtx().StoreBlip(*pImg, NewBlip);
	}
	return hr;
}


/*
 *	master
 */
STDMETHODIMP CWPPMasterExport::Export(CWPPMasterContext& masterCtx)
{
	HRESULT hr = S_OK;
	BOOL fMainMaster = masterCtx.GetSlideType() == PS_MainMaster;
	KPPTSlide* pptMaster = masterCtx.GetPptDocument().AddSlide(masterCtx.GetSlideType());
	masterCtx.SetPptSlide(pptMaster);
	masterCtx.GetDocuCtx().SetPptMaster(pptMaster, fMainMaster);
	//title master ����mainmaster
	if(!fMainMaster)
	{
		pptMaster->SetMasterSlide(masterCtx.GetDocuCtx().GetPptMaster(TRUE));
	}
	//layout
	hr = gExport_Layout(masterCtx, fMainMaster ? -1 : -2);
	//baseslide
	CWPPSlideBaseContext slideBaseCtx(masterCtx);
	
	hr = ((CWPPSlideBaseExport*)this)->Export(slideBaseCtx);

	hr = ExportObjects(masterCtx);

	hr = ExportFooter(masterCtx);
	//
	if(fMainMaster)//main mster����
	{
		//
		hr = ExportColorScheme(masterCtx);
		//
	}
	//
	hr = ExportTransition(masterCtx);
	return hr;
}

STDMETHODIMP CWPPMasterExport::ExportTransition(CWPPMasterContext& slideCtx)
{
	bmDialogPara* pPara = GetPresPara();
	if (!pPara)
		return E_FAIL;
	long lType = -1, lDirection = -1;
	if (pPara->m_showType != show_normal)
	{
		WPPTransition2PPTTransition(pPara->m_showType, lType, lDirection);
	}
	else
	{
		lType = 0;
		lDirection = 2;
	}

	PSR_SSSlideInfoAtom AtomSSSlideInfo;
	AtomSSSlideInfo.soundRef = 0;
	AtomSSSlideInfo.slideTime = 0;
	AtomSSSlideInfo.TransitionType = lType;
	AtomSSSlideInfo.TransitionDir = lDirection;
	AtomSSSlideInfo.speed = WPP2PPT_TransSpeed(pPara->m_bmSpeed);
	AtomSSSlideInfo.options = TR_AdvanceOnMouseClick;
	if (!pPara->m_bMouseType)
	{
		AtomSSSlideInfo.options &= ~TR_AdvanceOnMouseClick;
		AtomSSSlideInfo.options |= TR_AdvanceOnTime;
	}

	if (pPara->m_nSoundId > 0)
	{
		int nRefid = 0;
		if (SUCCEEDED(slideCtx.GetDocuCtx().AddSound(pPara->m_nSoundId, NULL, nRefid)))
		{
			AtomSSSlideInfo.options |= TR_SlideHasSound;
			AtomSSSlideInfo.soundRef = nRefid;
		}
	}
	else if (!pPara->m_cstrSoundName.IsEmpty())
	{
		BSTR strFile = pPara->m_cstrSoundName.AllocSysString();
		int nRefid = 0;
		if (SUCCEEDED(slideCtx.GetDocuCtx().AddSound(0, strFile, nRefid)))
		{
			AtomSSSlideInfo.options |= TR_SlideHasSound;
			AtomSSSlideInfo.soundRef = nRefid;
		}
		SysFreeString(strFile);
	}
	
	if (pPara->m_bSoundLoopPlay)
		AtomSSSlideInfo.options |= TR_LoopUntilNextSound;

	AtomSSSlideInfo.slideTime = pPara->m_nTime;
	
	slideCtx.GetPptSlide()->SetSlideTransInfo(&AtomSSSlideInfo);
	return S_OK;
}

STDMETHODIMP CWPPMasterExport::ExportColorScheme(CWPPMasterContext& masterCtx)
{
	HRESULT hr = S_OK;
	int i;
	CWPPDoc& wppDoc = masterCtx.GetWppDocument();
	//��ɫ������
	for(i = 0; i < wppDoc.m_arColorScheme.GetSize(); i++)
	{
		IColorScheme* pscheme = wppDoc.m_arColorScheme.GetAt(i);
		ASSERT(pscheme);
		MSOPPTCOLORSCHEME colorScheme = {0};
		pscheme->GetColors((COLORREF*)colorScheme.m_Colors, 8);
		for(int i = 0; i < 8 ; i++)
		{
			colorScheme.m_Colors[i] &= 0x00ffffff;
		}
		hr = masterCtx.GetPptSlide()->AddStockColorScheme(colorScheme);
	}
	return hr;
}
#ifdef _DEBUG
#define DUMPLEVEL0	dc
#define DUMPLEVEL1	dc<<"\t"
#define DUMPLEVEL2	dc<<"\t\t"
#define DUMPLEVEL3	dc<<"\t\t\t"
#define DUMPLEVEL4	dc<<"\t\t\t\t"

void DumpStyleSheet(CDumpContext& dc, CStyleSheet_Text* pWppStyleSheet)
{
	DUMPLEVEL0<<"CStyleSheet_Text start:--------------------------------------------------------\n";
	for(int i = 0; i < pWppStyleSheet->NumOfStyles(); i++)
	{
		const CStyle_Text* pWppStyleText = (CStyle_Text*)pWppStyleSheet->GetStyleViaIndex(i);
		ASSERT_VALID(pWppStyleText);
		DUMPLEVEL1<<"CStyle_Text start: --------------------------\n";

		DUMPLEVEL2<<"m_dwStyle\t\t\t"<<pWppStyleText->GetStyleID()<<"\n";
		DUMPLEVEL2<<"m_strName\t\t\t"<<pWppStyleText->m_strName<<"\n";
		DUMPLEVEL2<<"m_dwBaseStyle\t\t\t"<<pWppStyleText->m_dwBaseStyle<<"\n";
		DUMPLEVEL2<<"m_strBaseStyleName\t\t\t"<<pWppStyleText->m_strBaseStyleName<<"\n";
		DUMPLEVEL2<<"m_dwPreStyle\t\t\t"<<pWppStyleText->m_dwPreStyle<<"\n";
		DUMPLEVEL2<<"m_strPreStyleName\t\t\t"<<pWppStyleText->m_strPreStyleName<<"\n";
		DUMPLEVEL2<<"m_dwFollowStyle\t\t\t"<<pWppStyleText->m_dwFollowStyle<<"\n";
		DUMPLEVEL2<<"m_strFollowStyleName\t\t\t"<<pWppStyleText->m_strFollowStyleName<<"\n";
		
		DUMPLEVEL2<<"�����ԣ�"<<pWppStyleText->GetPAList()->GetCount()<<"\n";
		POSITION pos = NULL;
		for(pos = pWppStyleText->GetPAList()->GetHeadPosition(); pos;)
		{
			CCtrlCode* pWppCode = (CCtrlCode*)pWppStyleText->GetPAList()->GetNext(pos);
			ASSERT_VALID(pWppCode);
			pWppCode->Dump(dc);
		}
		DUMPLEVEL2<<"\n";

		DUMPLEVEL2<<"�����ԣ�"<<pWppStyleText->GetCAList()->GetCount()<<"\n";
		for(pos = pWppStyleText->GetCAList()->GetHeadPosition(); pos;)
		{
			CCtrlCode* pWppCode = (CCtrlCode*)pWppStyleText->GetCAList()->GetNext(pos);
			ASSERT_VALID(pWppCode);
			pWppCode->Dump(dc);
		}
		
		DUMPLEVEL1<<"CStyle_Text end: --------------------------\n\n";
	}
	DUMPLEVEL0<<"CStyleSheet_Text end:---------------------------------------------------------------\n";

	dc.Flush();
}
#endif

void CopyList(CObList* pListDest, CObList* pListSrc)
{
	for (POSITION pos = pListSrc->GetHeadPosition();pos;)
	{
		CCtrlCode* pCode = (CCtrlCode*)pListSrc->GetNext(pos);
		ASSERT(pCode);
		pListDest->AddTail(pCode);
	}
}

void ClearList(CObList* pListDest)
{
	while (!pListDest->IsEmpty())
		pListDest->RemoveHead();
}

STDMETHODIMP CWPPMasterExport::ExportStyles(CWPPMasterContext& masterCtx)
{
	HRESULT hr = S_OK;
	//wpp's stylesheet
	CWPPDoc& wppDoc = masterCtx.GetWppDocument();
	CStyleSheet_Text* pWppStyleSheet = wppDoc.m_StySht_Text;
	ASSERT_VALID(pWppStyleSheet);

#ifdef _DEBUG
	{
		CFile file("c:/stylesheet.txt", CFile::modeCreate | CFile::modeWrite);
		CDumpContext dc(&file);
		DumpStyleSheet(dc, pWppStyleSheet);
	}
#endif

	for(int i = 0; i < pWppStyleSheet->NumOfStyles(); i++)
	{
		CStyle_Text* pWppStyleText = (CStyle_Text*)pWppStyleSheet->GetStyleViaIndex(i);
		ASSERT_VALID(pWppStyleText);
		const CString& wppStyleName = pWppStyleText->m_strName;
		PPT_TextType pptTextType;
		__StyleType styleType;
		int npptLevel;
		gExport_GetStyleLevel(wppStyleName, pptTextType, styleType, npptLevel);
		if(styleType == __ST_Null)
			continue;
		//
		KPPTTextPropSheet* pPptStyleSheet;
		if(pptTextType == TT_Other)
		{
			pPptStyleSheet = masterCtx.GetPptDocument().GetOtherTxtPropSheet();
		}
		else if(pptTextType == TT_Invalid)//��ʾdefault
		{
			//default��ʽ��wpp����5������ppt��ֻ��Ҫһ��
			if(npptLevel != 0)
				continue;
			pPptStyleSheet = masterCtx.GetPptDocument().GetDefaultTxtPropSheet();
		}
		else
		{
			pPptStyleSheet = masterCtx.GetPptSlide()->GetTextPropSheet(pptTextType);
		}
		KPPTTxPFStyle* pPptPfStyle = pPptStyleSheet->GetParaStyle(npptLevel);
		int iNumTypeNo = -1;

		// ��������
		CObList tmpList;
		CopyList(&tmpList, &pWppStyleText->m_PAList);
		masterCtx.GetDocuCtx().BeforeExportStyle(pptTextType, npptLevel, &pWppStyleText->m_PAList);

		PSR_NumberingFormat* pFormat = NULL;
		gExport_TxPFStyle(*pPptPfStyle, masterCtx.GetDocuCtx(), *pWppStyleText, *pWppStyleSheet, &pFormat);
		if (pFormat)
		{
			StyleAttrCacheItem * pAtem = masterCtx.GetDocuCtx().GetStyleAttrItem(pptTextType, npptLevel);
			if (pAtem)
			{
				PSR_ExtendedParagraphMasterAtom* pExPara = masterCtx.GetExParaAtom(pptTextType);
				ASSERT(npptLevel >= 0 && npptLevel < countof(pExPara->NumberFmt));
				
				pExPara->nRealLevel = countof(pExPara->NumberFmt);
				pExPara->NumberFmt[npptLevel] = new PSR_NumberingFormat;
				*pExPara->NumberFmt[npptLevel] = *pFormat;
			}
			else
			{
				ASSERT(!"���ѽ����ôû�ж�Ӧ��StyleAttrCacheItem");
			}
			delete pFormat;
		}
		// �ָ�
		ClearList(&pWppStyleText->m_PAList);
		CopyList(&pWppStyleText->m_PAList, &tmpList);
		
		ClearList(&tmpList);

		KPPTTxCFStyle* pPptCfStyle = pPptStyleSheet->GetTextStyle(npptLevel);
		gExport_TxCFStyle(*pPptCfStyle, masterCtx.GetDocuCtx(), *pWppStyleText, *pWppStyleSheet);

		if (npptLevel == 0 && (pptTextType == TT_Title || 
							   pptTextType == TT_Body ||
							   pptTextType == TT_Notes ||
							   pptTextType == TT_CenterBody))
		{
			gExport_DefaultTxPFStyle(*pPptPfStyle,  pptTextType);
			gExport_DefaultTxCFStyle(*pPptCfStyle,  pptTextType);
		}
		//ǿ�����ñ�ע������Ϊ12pt
		if(pptTextType == TT_Notes)
			continue;

		//wpp��Ĭ�ϵ�Ӣ������ΪTimes New Roman,���û����,������һ��
		{
			UINT16 fontIdx;
			masterCtx.GetDocuCtx().AddFont(fontIdx, _T("Times New Roman"));
			if(!pPptCfStyle->HasEnglishFont())
			{
				pPptCfStyle->SetEnglishFont(fontIdx);
			}
			if(!pPptCfStyle->HasDefaultFont())
			{
				pPptCfStyle->SetDefaultFont(fontIdx);
			}
		}

		//����Ĭ���о�
		if(!pPptPfStyle->HasSpaceWithin() || (pptTextType == TT_Other && npptLevel == 0))
		{
			pPptPfStyle->SetSpaceWithin(110);
		}
		//����Ĭ���Ʊ�λ
		if(!pPptPfStyle->HasDefaultTab())
		{
			pPptPfStyle->SetDefaultTab(335);
		}
		//����Ĭ�϶��뷽ʽ
		if(!pPptPfStyle->HasAdjust())
		{
			pPptPfStyle->SetAdjust(PF_Justify);
		}
		//
		if(!pPptPfStyle->HasFontAlign())
		{
			pPptPfStyle->SetFontAlign(PF_UpHoldingFixed);
		}
	
	}
	//
	return hr;
}
STDMETHODIMP CWPPMasterExport::ExportObjects(CWPPMasterContext& masterCtx)
{
	HRESULT hr = S_OK;
	CObList placeHolderList;
	placeHolderList.AddTail(m_pTitleObj);
	placeHolderList.AddTail(m_pTextObj);

	IColorScheme* pOldGlobalColorScheme = gGetCurColorScheme();
	gSetCurColorScheme(this->m_pICS);

	gExport_WppObjects(m_WPSObjectList, placeHolderList, masterCtx, &m_lstShowObjOrder);

	gSetCurColorScheme(pOldGlobalColorScheme);
	return hr;
}

STDMETHODIMP CWPPMasterExport::ExportFooter(CWPPMasterContext& masterCtx)
{
	HRESULT hr = S_OK;
	ks_wstring strFooter;
	CSectionInfoManager& wppSecInfoMgr = (CSectionInfoManager&)masterCtx.GetWppDocument().m_SectionInfoManager;
	CFrameText* pWppFrameText = wppSecInfoMgr.GetDefaultFooterOdd();
	CShape_Context shapeCtx(masterCtx);
	KPPTClientTextBox* pPptTextBox = new KPPTClientTextBox;
	if(pWppFrameText)
	{
		CTextPool* pWppTextPool = pWppFrameText->c_pTextPool;
		if(pWppTextPool)
		{
			for(int i = 0; i < pWppTextPool->NumOfParagraphs(); i++)
			{
				CParagraph* pWppPara = pWppTextPool->GetParagraph(i);
				for(int j = 0; j < pWppPara->NumOfSentences(); j++)
				{
					CSentence* pWppSen = pWppPara->GetSentence(j);
					int cbSenChar = pWppSen->GetTextSize();
					LPCTEXTWORD pszChar = pWppSen->GetDataPtr();
					CWppEscSeq_Export esp(pszChar + cbSenChar, pPptTextBox, &shapeCtx);
					for(int iChar = 0; iChar < cbSenChar;)
					{
						if (pszChar[iChar] == VK_ESCAPE)
						{
							LPCTEXTWORD pCur = pszChar + iChar;
							iChar += esp.SCP_Escape(pCur) - pCur;
						}
						else
						{
							WCHAR wsz[2];
							wsz[0] = pszChar[iChar];
							wsz[1] = 0;
							pPptTextBox->AppendText(wsz);
							iChar++;
						}
					}
				}
			}
		}
	}
	strFooter = pPptTextBox->GetText();
	delete pPptTextBox;
	if(strFooter.size())
	{
		KPPTClientData& pptClientData = shapeCtx.GetPptClientData();
		//Ѱ��place holder id....
		shapeCtx.GetPlaceHolderID() = PH_MASTERFOOTER;//slideBaseCtx.FindPlaceHolderID(*pWpsObj, placeHolderList);
		//export!
		shapeCtx.Export(pWppFrameText);
		//client data
		MsoKernData* pClientDataKernData = pptClientData.PersistClientData(&masterCtx.GetDocuCtx().GetAutoFreeAlloc());
		if(pClientDataKernData)
			shapeCtx.GetShape().SetClientData(pClientDataKernData);
		
		KPPTHeaderFooters* pPpthf = masterCtx.GetPptDocument().GetSlideHeadersFooters();
		pPpthf->SetFooter((LPWSTR)(LPCWSTR)strFooter);
		pPpthf->SetFlags(HF_Footer);
	}
	return hr;
}


/*
 *	slide
 */
STDMETHODIMP CWPPSlideExport::Export(CWPPSlideContext& slideCtx)
{
	HRESULT hr = S_OK;
	KPPTSlide* pPptSlide = slideCtx.GetPptDocument().AddSlide(slideCtx.m_pptSlideType);
	slideCtx.SetPptSlide(pPptSlide);
	//����masterslide
	pPptSlide->SetMasterSlide(slideCtx.GetDocuCtx().GetPptMaster(m_nLayoutId != 0));
	//layout
	hr = gExport_Layout(slideCtx, m_nLayoutId);
	//baseslide
	CWPPSlideBaseContext slideBaseCtx(slideCtx);

	IColorScheme* pOldGlobalColorScheme = gGetCurColorScheme();
	gSetCurColorScheme(this->m_pICS);
	hr = ((CWPPSlideBaseExport*)this)->Export(slideBaseCtx);
	gSetCurColorScheme(pOldGlobalColorScheme);

	//objects
	hr = ExportTransition(slideCtx);
	hr = ExportObjects(slideCtx);
	hr = ExportNote(slideCtx);

	pPptSlide->SetFollowMasterObj(TRUE);
	return hr;
}

STDMETHODIMP CWPPSlideExport::ExportTransition(CWPPSlideContext& slideCtx)
{	
	bmDialogPara* pPara = GetPresPara();
	if (!pPara)
		return E_FAIL;
	long lType = -1, lDirection = -1;
	if (pPara->m_showType != show_normal)
	{
		WPPTransition2PPTTransition(pPara->m_showType, lType, lDirection);
	}
	else
	{
		lType = 0;
		lDirection = 2;
	}
	

	PSR_SSSlideInfoAtom AtomSSSlideInfo;
	AtomSSSlideInfo.soundRef = 0;
	AtomSSSlideInfo.slideTime = 0;
	AtomSSSlideInfo.TransitionType = lType;
	AtomSSSlideInfo.TransitionDir = lDirection;
	AtomSSSlideInfo.speed = WPP2PPT_TransSpeed(pPara->m_bmSpeed);
	AtomSSSlideInfo.options = TR_AdvanceOnMouseClick;
	if (!pPara->m_bMouseType)
	{
		AtomSSSlideInfo.options &= ~TR_AdvanceOnMouseClick;
		AtomSSSlideInfo.options |= TR_AdvanceOnTime;
	}

	if (pPara->m_nSoundId > 0)
	{
		int nRefid = 0;
		if (SUCCEEDED(slideCtx.GetDocuCtx().AddSound(pPara->m_nSoundId, NULL, nRefid)))
		{
			AtomSSSlideInfo.options |= TR_SlideHasSound;
			AtomSSSlideInfo.soundRef = nRefid;
		}
	}
	else if (!pPara->m_cstrSoundName.IsEmpty())
	{
		BSTR strFile = pPara->m_cstrSoundName.AllocSysString();
		int nRefid = 0;
		if (SUCCEEDED(slideCtx.GetDocuCtx().AddSound(0, strFile, nRefid)))
		{
			AtomSSSlideInfo.options |= TR_SlideHasSound;
			AtomSSSlideInfo.soundRef = nRefid;
		}
		SysFreeString(strFile);
	}
	
	if (pPara->m_bSoundLoopPlay)
		AtomSSSlideInfo.options |= TR_LoopUntilNextSound;

	AtomSSSlideInfo.slideTime = pPara->m_nTime;
	slideCtx.GetPptSlide()->SetSlideTransInfo(&AtomSSSlideInfo);

	return S_OK;
}

STDMETHODIMP CWPPSlideExport::ExportObjects(CWPPSlideContext& slideCtx)
{
	HRESULT hr = S_OK;
	IColorScheme* pOldGlobalColorScheme = gGetCurColorScheme();
	gSetCurColorScheme(this->m_pICS);

	gExport_WppObjects(m_WPSObjectList, m_lstLayoutObj, slideCtx, &m_lstShowObjOrder);

	gSetCurColorScheme(pOldGlobalColorScheme);
	return hr;
}
STDMETHODIMP CWPPSlideExport::ExportNote(CWPPSlideContext& slideCtx)
{
	HRESULT hr = S_OK;
	if(!m_strNote.IsEmpty())
	{
		KPPTSlide* pPptNote = slideCtx.GetPptDocument().AddSlide(PS_NoteSlide);
		KPPTClientAnchor clientAnchor = {
			432, 2736,
			3888, 5328
		};
		MsoShape shape = pPptNote->GetDrawing()->GetRootShape().NewShape(FALSE);
		shape.SetClientAnchor(clientAnchor.PersistAnchor(
				&(slideCtx.GetDocuCtx().GetAutoFreeAlloc()))
		);
		shape.SetShapeType(msosptRectangle);
		KPPTClientTextBox* pPptTextBox = new KPPTClientTextBox();
		USES_CONVERSION;
		pPptTextBox->AppendText(T2CW(m_strNote));
		pPptTextBox->SetTextType(TT_Notes);
		pPptNote->AddPlaceHolder(PH_NOTESBODY, pPptTextBox);
		KPPTClientData pptClientData;
		pptClientData.SetOEPlaceHolder(0, PH_NOTESBODY, 0);
		pptClientData.SetClientTextBox(pPptTextBox);
		//
		MsoKernData* pClientTextBoxKernData = pPptTextBox->PersistTextBox(&slideCtx.GetDocuCtx().GetAutoFreeAlloc());
		shape.SetClientTextBox(pClientTextBoxKernData);
		MsoKernData* pClientDataKernData = pptClientData.PersistClientData(&slideCtx.GetDocuCtx().GetAutoFreeAlloc());
		shape.SetClientData(pClientDataKernData);
		//
		slideCtx.GetPptSlide()->SetNoteSlide(pPptNote);
	}
	return hr;
}
/*
 *	global helper func
 */
STDMETHODIMP gExport_WppObjects(CObList& ObjList, CObList& placeHolderList,
		CWPPSlideBaseContext& slideBaseCtx, CIndexObList* pShowOrder /*= NULL*/)
{
	HRESULT hr = S_OK;

	//int iAnimateOrder = 1;
	for(POSITION pos = ObjList.GetHeadPosition(); pos != NULL;)
	{
		CWPSObj* pWpsObj;
		pWpsObj = (CWPSObj*)ObjList.GetNext(pos);
		ASSERT_VALID(pWpsObj);
		//
		CShape_Context shapeCtx(slideBaseCtx);
		KPPTClientData& pptClientData = shapeCtx.GetPptClientData();
		//Ѱ��place holder id....
		BYTE nPalceHolderID = slideBaseCtx.FindPlaceHolderID(*pWpsObj, placeHolderList);
		shapeCtx.GetPlaceHolderID() = nPalceHolderID;
		//��ռλ��֮action
		if(nPalceHolderID == PH_NONE)
		{
			ExportShapeAction(pWpsObj, &slideBaseCtx.GetDocuCtx(), &pptClientData); 
//				nPalceHolderID != PH_NONE, nPalceHolderID != PH_NONE ? shapeCtx.GetPptClientTextBox() : NULL);
		}
		//export!
		shapeCtx.Export(pWpsObj);
		//animate
		{
			int iShowOrder = -1;
			if(pShowOrder)
			{
				iShowOrder = pShowOrder->FindForIndex(pWpsObj);
			}
			if(iShowOrder >= 0)
			{
				ExportAnimate(pWpsObj, &slideBaseCtx.GetDocuCtx(), &pptClientData, iShowOrder + 1);
			}
		}
		//	iAnimateOrder++;
		//client data
		{
			pptClientData.SetOEPlaceHolder(nPalceHolderID == PH_NONE ? -1 : 0,
				nPalceHolderID, 0);
			MsoKernData* pClientDataKernData = pptClientData.PersistClientData(&slideBaseCtx.GetDocuCtx().GetAutoFreeAlloc());
			if(pClientDataKernData)
				shapeCtx.GetShape().SetClientData(pClientDataKernData);
		}
	}
	return hr;
}

class KPPTTextRulerEx : public KPPTTextRuler
{
public:
	BOOL HasDefaultTab()
	{
		return (m_Mask & TR_DefaultTable) != 0;
	}
	
};

STDMETHODIMP CacheAttr(CObList* pAttrListDest, CObList* pAttrListSrc, 
					   CObList* pResList)
{
	for (POSITION i = pAttrListSrc->GetHeadPosition();i;)
	{
		CCtrlCode* pCode = (CCtrlCode*)pAttrListSrc->GetNext(i);
		int nSrcID = pCode->GetCodeID();
		BOOL bFind = FALSE;
		for (POSITION j = pAttrListDest->GetHeadPosition();j;)
		{
			CCtrlCode* p = (CCtrlCode*)pAttrListDest->GetNext(j);
			if (p->GetCodeID() == nSrcID)
			{
				bFind = FALSE;
				break;
			}
		}
		if (!bFind)
		{
			pResList->AddTail(pCode);
		}
	}
	return S_OK;
}

// �ռ�����ʽ�йص���Ϣ����Щ��ʽ��Ҫ����Ϣ����ڶ�Ӧ�Ķ�����������
STDMETHODIMP CacheParaAttrToStyle(PPT_TextType textType, int nLevel, 
							  CObList* pAttrList, CWPPSlideBaseContext& slideBase,
							  CShape_Context& shapeCtx)
{
	CWPPDoc& wppDoc = slideBase.GetWppDocument();
	CStyleSheet_Text* pWppStyleSheet = wppDoc.m_StySht_Text;
	if (!pWppStyleSheet)
		return S_OK;
	if (!pAttrList)
		return S_OK;

	StyleAttrCacheItem *pItem = slideBase.GetDocuCtx().FindStyleAttrCacheItem(textType, nLevel, &shapeCtx);

	for(int i = 0; i < pWppStyleSheet->NumOfStyles(); i++)
	{
		CStyle_Text* pWppStyleText = (CStyle_Text*)pWppStyleSheet->GetStyleViaIndex(i);
		ASSERT_VALID(pWppStyleText);
		const CString& wppStyleName = pWppStyleText->m_strName;
		PPT_TextType pptTextType;
		__StyleType styleType;
		int npptLevel;
		gExport_GetStyleLevel(wppStyleName, pptTextType, styleType, npptLevel);
		if (textType == pptTextType && nLevel == npptLevel)
		{
			ASSERT(pItem);
			CacheAttr(&pWppStyleText->m_PAList, pAttrList, &pItem->m_List);
		}
	}
	return S_OK;
}

STDMETHODIMP gExport_WppText(CShape_Context& shapeCtx,
							 const CTextPool& textPool,
							 CWPSObj& wpsObj,
							 DWORD dwFlag /*= 0*/
							 )
{
	MsoShape& shape = shapeCtx.GetShape();
	CWPPSlideBaseContext& slideBaseCtx = shapeCtx.GetSlideBaseCtx();
	HRESULT hr = S_OK;
	KPPTClientTextBox* pPptTextBox = shapeCtx.GetPptClientTextBox();//new KPPTClientTextBox();
	KPPTClientData& pptClientData = shapeCtx.GetPptClientData();
	BYTE nPalceHolderID = shapeCtx.GetPlaceHolderID();
	PPT_TextType pptTextTypeSaved;
	int nPara = textPool.NumOfParagraphs();

	for(int iPara = 0; iPara < nPara; iPara++)
	{
		CParagraph* pWppPara = textPool.GetParagraph(iPara);
		ASSERT_VALID(pWppPara);
		int cbParaChar = 0;
		CObList* pWppCfList = NULL;
		int nSen = pWppPara->NumOfSentences();
		for(int iSen = 0; iSen < nSen; iSen++)
		{
			CSentence* pWppSen = pWppPara->GetSentence(iSen);
			ASSERT_VALID(pWppSen);
			LPCTEXTWORD pszChar = pWppSen->GetDataPtr();
			int cbSenChar = pWppSen->GetTextSize();
			CWppEscSeq_Export esp(pszChar + cbSenChar, pPptTextBox, &shapeCtx);
			
			int nSaveSize = pPptTextBox->GetText().length();
			for(int iChar = 0; iChar < cbSenChar;)
			{
				if (pszChar[iChar] == VK_ESCAPE)
				{
					LPCTEXTWORD pCur = pszChar + iChar;
					iChar += esp.SCP_Escape(pCur) - pCur;
				}
				else
				{
					WCHAR wsz[2];
					wsz[0] = pszChar[iChar];
					wsz[1] = 0;
					pPptTextBox->AppendText(wsz);
					iChar++;
				}
			}
			if((iPara < nPara - 1) && (iSen == nSen - 1))//���ϻس�
			{
				WCHAR wsz[2];
				wsz[0] = 0x0d;
				wsz[1] = 0;
				pPptTextBox->AppendText(wsz);
			}
			int nCurSenChars = pPptTextBox->GetText().length() - nSaveSize;
			cbParaChar += nCurSenChars;
			//������
			{
				KPPTTxCFStyle pptCfStyle;
				if(pWppSen->m_pAttribList)
				{
					gExport_TxCFStyle(pptCfStyle, slideBaseCtx.GetDocuCtx(), *pWppSen->m_pAttribList);
					if(pWppCfList == NULL)
					{
						pWppCfList = pWppSen->m_pAttribList;
					}
				}
				pPptTextBox->AddTxStyle(nCurSenChars, pptCfStyle);
			}
		}
		//������
		{
			KPPTTxPFStyle pptPfStyle;
			PPT_TextType pptTextType;
			__StyleType styleType;
			int npptLevel;
			gExport_GetStyleLevel(pWppPara->m_strStyleName, pptTextType, styleType, npptLevel);
			
			//һ���ı��򣨷�placeholder��
			if(styleType == __ST_Null)
			{
				pptTextType = TT_Other;
			}
			pptTextTypeSaved = pptTextType;
			pPptTextBox->SetTextType(pptTextType);
			//���⴦��valign
			if(dwFlag & WPPCONVERT_SPECIAL_VALIGN)
			{
				WORD wVAlign = TAL_TOP;
				if(pWppPara->m_pAttribList)
				{
					CCtrlCode_Alignment* pWppAlignCode = (CCtrlCode_Alignment*)
						CCtrlCodeTool::FindCtrlCode(pWppPara->m_pAttribList, SETVALIGNMENT);
					if(pWppAlignCode)
					{
						ASSERT_VALID(pWppAlignCode);
						wVAlign = pWppAlignCode->GetAlignment();
					}
				}
				gConvertVAlign(wVAlign, shapeCtx.m_opt);
			}
			if((slideBaseCtx.GetSlideType() == PS_MainMaster || slideBaseCtx.GetSlideType() == PS_TitleMaster)
				&& pptTextType != TT_Other)
			{
				pPptTextBox->SetMasterSlideBaseTextProp(cbParaChar, npptLevel);
				// liupeng: ĸ���ϵ���Ŀ�����Ǳ����ڶ����Լ���������������
				// ���ｫ����ľ����Ժϲ�����Ӧ����ʽ������
				// ��ʽ�����������������
				if ((nPalceHolderID > 0) && 
					((pptTextType == TT_Title) || 
					 (pptTextType == TT_Body) ||
					 (pptTextType == TT_CenterBody) || 
					 (pptTextType == TT_CenterTitle) ||
					 (pptTextType == TT_HalfBody) || 
					 (pptTextType == TT_QuarterBody))) 
				{
					// ���ﱾ��Ӧ�����ö�Ӧ����ʽ�ȼ����ռ�
					// ���ǿ��ǵ�ĸ���ϵ����ֵ���ʽ�ǹ̶���
					// ��������ֱ���þ�ı������Ϊ����levelֵ
					// ʵ����Ҳ��û�а취����: 2003���Զ���Ŵ����Щ���
					CacheParaAttrToStyle(pptTextType, iPara, 
						pWppPara->m_pAttribList, slideBaseCtx, shapeCtx);
				}
			}
			else
			{
				pptPfStyle.SetLevel(npptLevel);
				if(pWppPara->m_pAttribList)
				{
					KPPTTextRuler* pPptTextRuler;
					pPptTextRuler = pPptTextBox->GetTextRuler();
					int iNumTypeNo = -1;
					gExport_TxPFStyle(pptPfStyle, slideBaseCtx.GetDocuCtx(), *pWppPara->m_pAttribList, pWppCfList, 
						pPptTextRuler, npptLevel, pPptTextBox, &iNumTypeNo);
					// liupeng: ��������������û���Զ���ţ����������ʽ�е�
					// �Զ����
					if (!pptPfStyle.HasBulletVisible())
						pptPfStyle.SetBulletVisible(FALSE);
					if(!((KPPTTextRulerEx*)pPptTextRuler)->HasDefaultTab())
					{
						pPptTextRuler->SetDefaultTab(335);
					}
					if(iNumTypeNo >= 0)
					{
						((KPPTClientTextBoxEx*)pPptTextBox)->AddNumTypeNoToCf(nSen, iNumTypeNo);
					}
				}
				pPptTextBox->AddPfStyle(cbParaChar, pptPfStyle);
			}
		}
	}
	//
	ks_wstring& strText = pPptTextBox->GetText();
	if(strText == L"�����˴����ӱ���" || strText == L"�����˴����Ӹ�����" ||
		strText == L"�����˴���������")//����������
	{
		delete pPptTextBox;
		pPptTextBox = new KPPTClientTextBox();
		pPptTextBox->SetTextType(pptTextTypeSaved);
		shapeCtx.SetPptClientTextBox(pPptTextBox);
	}
	//ռλ��action
	if(nPalceHolderID != PH_NONE)
	{
		ExportShapeAction(&wpsObj, &shapeCtx.GetSlideBaseCtx().GetDocuCtx(),
			&pptClientData, TRUE, pPptTextBox, 0, pPptTextBox->GetText().size()); 
	}
	//clienttextbox
	{
		BOOL bStoreTxtInGlobal = FALSE;
		if(nPalceHolderID != PH_NONE)
		{
			bStoreTxtInGlobal = S_OK == slideBaseCtx.GetPptSlide()->AddPlaceHolder(
				nPalceHolderID, pPptTextBox);
		}
		pptClientData.SetOEPlaceHolder(nPalceHolderID == PH_NONE ? -1 : 0,
				nPalceHolderID, 0);
		if (!bStoreTxtInGlobal) // ռλ������ͳһ����ȫ�֣��Ͳ��������������
			pptClientData.SetClientTextBox(pPptTextBox);
		//
		MsoKernData* pClientTextBoxKernData = pPptTextBox->PersistTextBox(&slideBaseCtx.GetDocuCtx().GetAutoFreeAlloc());
		shapeCtx.GetShape().SetClientTextBox(pClientTextBoxKernData);
	}
	return hr;
}
STDMETHODIMP gExport_TxPFStyle(KPPTTxPFStyle& pptPfStyle,
							   CWPPDocContext& docuCtx,
							   const CObList& wppPfList,
							   const CObList* pWppCfList /*= NULL*/,
							   KPPTTextRuler* pPptTextRuler /*= NULL*/,
							   int nLevelInRuler /*= 0*/,
							   KPPTClientTextBox* pPptClientTextBox /*= NULL*/,//for �Զ����
							   OUT int* pNumTypeNo /*= NULL*/, 
							   PSR_NumberingFormat** ppFormat
							   )
{
	HRESULT hr = S_OK;
	for(POSITION pos = wppPfList.GetHeadPosition(); pos;)
	{
		CCtrlCode* pWppCode = (CCtrlCode*)wppPfList.GetNext(pos);
		ASSERT_VALID(pWppCode);
		switch(pWppCode->GetCodeID())
		{
		case SETHALIGNMENT:// �趨�ı���ˮƽ���뷽ʽ
			if(!pptPfStyle.HasAdjust())
			{
				CCtrlCode_Alignment* pWppAlignCode = (CCtrlCode_Alignment*)pWppCode;
				ASSERT_VALID(pWppAlignCode);
				UINT16 pptAdjust = PF_Center;
				switch(pWppAlignCode->GetAlignment())
				{
				case TAL_LEFT:
					pptAdjust = PF_Left;
					break;
				case TAL_HCENTER:
					pptAdjust = PF_Center;
					break;
				case TAL_RIGHT:
					pptAdjust = PF_Right;
					break;
				case TAL_JUSTIFIED:
					pptAdjust = PF_Justify;
					break;
				case TAL_FULLJUSTIFIED:
					pptAdjust = PF_Distributed;
					break;
				}
				pptPfStyle.SetAdjust(pptAdjust);
			}
			break;
		case SETVALIGNMENT:// �趨�ı��д�ֱ���뷽ʽ
			if(!pptPfStyle.HasFontAlign())
			{
				CCtrlCode_Alignment* pWppAlignCode = (CCtrlCode_Alignment*)pWppCode;
				ASSERT_VALID(pWppAlignCode);
				UINT16 pttFontAlign = PF_Roman;
				switch(pWppAlignCode->GetAlignment())
				{
				case TAL_TOP:
					pttFontAlign = PF_Hanging;
					break;
				case TAL_VCENTER:
					pttFontAlign = PF_Centered;
					break;		
				case TAL_BOTTOM:
					pttFontAlign = PF_UpHoldingFixed;
					break;
				}
				pptPfStyle.SetFontAlign(pttFontAlign);
			}
			break;

		case SETLINEMARGIN:// �趨�ı��м��
			if(!pptPfStyle.HasSpaceWithin())
			{
				CCtrlCode_LineMargin* pWppLineMarginCode = (CCtrlCode_LineMargin*)pWppCode;
				ASSERT_VALID(pWppLineMarginCode);
				const UNIT_VALUE* pWppValue = pWppLineMarginCode->GetLineMargin();
				INT16 pptValue;
				gExport_ParaMargin(pptValue, *pWppValue, __PMT_Line, pWppCfList);
				pptPfStyle.SetSpaceWithin(pptValue);
			}
			break;
		case SETPARAMARGIN:// �趨��ǰ���
			if(!pptPfStyle.HasSpaceBefore())
			{
				CCtrlCode_ParaMargin* pWppParaMarginCode = (CCtrlCode_ParaMargin*)pWppCode;
				ASSERT_VALID(pWppParaMarginCode);
				const UNIT_VALUE* pWppValue = pWppParaMarginCode->GetParaMargin();
				INT16 pptValue;
				gExport_ParaMargin(pptValue, *pWppValue, __PMT_Before, pWppCfList);
				pptPfStyle.SetSpaceBefore(pptValue);
			}
			break;
		case SETAFPAMARGIN:// �趨�κ���
			if(!pptPfStyle.HasSpaceAfter())
			{
				CCtrlCode_ParaMargin* pWppParaMarginCode = (CCtrlCode_ParaMargin*)pWppCode;
				ASSERT_VALID(pWppParaMarginCode);
				const UNIT_VALUE* pWppValue = pWppParaMarginCode->GetParaMargin();
				INT16 pptValue;
				gExport_ParaMargin(pptValue, *pWppValue, __PMT_After, pWppCfList);
				pptPfStyle.SetSpaceAfter(pptValue);
			}
			break;
		//	wpp�е����������������� ��ppt�и�����ȫ��ͬ,��ͬѼ��!
		case SETFIRSTINDENT:// �趨��������
			if(pPptTextRuler || !pptPfStyle.HasBulletOfs())
			{
				CCtrlCode_ParaIndent* pWppParaIndentCode = (CCtrlCode_ParaIndent*)pWppCode;
				ASSERT_VALID(pWppParaIndentCode);
				const UNIT_VALUE* pWppValue = pWppParaIndentCode->GetIndent();
				INT16 pptValue;
				gExport_ParaMargin((INT16&)pptValue, *pWppValue, __PMT_FirstIndent, pWppCfList);
				UINT16 leftIndent;
				gExport_LeftIndent(leftIndent, NULL, &wppPfList, pWppCfList);
				leftIndent = abs((INT16)leftIndent);
				pptValue += leftIndent;
				if(pPptTextRuler)
				{
					pPptTextRuler->SetBulletOfs(nLevelInRuler, pptValue);
				}
				else
				{
					pptPfStyle.SetBulletOfs(pptValue);
				}
			}
			break;
		case SETLEFTINDENT:// �趨��������
			if(pPptTextRuler || !pptPfStyle.HasTextOfs())
			{
				CCtrlCode_ParaIndent* pWppParaIndentCode = (CCtrlCode_ParaIndent*)pWppCode;
				ASSERT_VALID(pWppParaIndentCode);
				UINT16 pptValue;
				gExport_LeftIndent(pptValue, pWppParaIndentCode, NULL, pWppCfList);
				pptValue = abs((INT16)pptValue);
				if(pPptTextRuler)
				{
					pPptTextRuler->SetTextOfs(nLevelInRuler, pptValue);
				}
				else
				{
					pptPfStyle.SetTextOfs(pptValue);
				}
			}
			break;
		case SETRIGHTINDENT:// �趨��������
			//ppt��û��
			break;
		case SETTABS:// �趨Tabλ��
			{
				CCtrlCode_Tabs* pWppTabsCode = (CCtrlCode_Tabs*)pWppCode;
				ASSERT_VALID(pWppTabsCode);
				PTABITEM pWppTabs = pWppTabsCode->GetTabs();
				for(int i = 0; i < MAXTABSTOPS + 1; i++)
				{
					TABITEM& wppti = pWppTabs[i];
					if(wppti.nTabPosition == 0)
						break;
					UINT pptValue = WpsShapeToPptUnit(wppti.nTabPosition);
					//����Ĭ���Ʊ�λ
					if(i == 0)
					{
						if(pPptTextRuler)
						{
							pPptTextRuler->SetDefaultTab(pptValue);
						}
						else if(!pptPfStyle.HasDefaultTab())
						{
							pptPfStyle.SetDefaultTab(pptValue);
						}
					}
					else
					{
						if(pPptTextRuler)
						{
							pPptTextRuler->AddTextTab(pptValue, 0);
						}
						else
						{
							pptPfStyle.AddTextTab(pptValue, 0);
						}
					}
				}
			}
			break;
		case SETAUTONUMBER:
			{
				CCtrlCode_AutoNumber* pWppAutoNumber = (CCtrlCode_AutoNumber*)pWppCode;
				if (!pWppAutoNumber)
					break;
				ASSERT_VALID(pWppAutoNumber);
				AUTONUMPARAREF* pWppParaRef = (AUTONUMPARAREF*)pWppAutoNumber->GetRefData();
				if (!pWppParaRef)
					break;
				KAutoNumGroupPtr* pWppGroup = pWppParaRef->m_AuoNumGroupSPtr;
				if (!pWppGroup)
					break;
				AUTONUMGROUP* pWppAutoGroup = *pWppGroup;
				AUTONUMATOM* pWppAuto = *pWppAutoGroup->GroupData[pWppParaRef->m_nLevel];
				if (!pWppAuto)
					break;
				//COLORREF fontColor = pWppAuto->AutoNumCharAttrib.clrText;
				//if(fontColor & 0xF0000000)
				//{
				//	fontColor = (fontColor & 0xff) << 24;
				//}
				//pptPfStyle.SetBulletColor(fontColor);
				if(pWppAuto->lAutoNumType == enumAutoNumTypeNumbered)//�Զ����
				{
					pptPfStyle.SetBulletType(Bullet_Numbered);
					PSR_NumberingFormat numberingFmt = {0};
					numberingFmt.nNumberType = gExport_NumberingType(pWppAuto->twAutoNumContent);
					numberingFmt.bIsNumber = 1;
					numberingFmt.nBuInstance = -1;
					numberingFmt.nBuStart = pWppAuto->lAutoNumStartAt;
					numberingFmt.mask = BF_NumberingType | BF_BuStart;
					if (pPptClientTextBox)
					{
						pPptClientTextBox->AddNumFmt(numberingFmt);
						 ASSERT_VALID(pNumTypeNo);
						*pNumTypeNo = ((KPPTClientTextBoxEx*)pPptClientTextBox)->GetNumFmtsSize() - 1;
					}
					else if (ppFormat)
					{
						if (ppFormat)
						{
							*ppFormat = new PSR_NumberingFormat;
							*(*ppFormat) = numberingFmt;
						}
					}
					else
						ASSERT(!"��������ѽ");
				}
				else
				{
					ASSERT(pWppAuto->lAutoNumType == enumAutoNumTypeBulletChar);//�ַ���Ŀ����
					//ASSERT(pWppAuto->lAutoNumCharAttribFlag & );
					pptPfStyle.SetBulletType(Bullet_Char);
					WCHAR wch = pWppAuto->twAutoNumContent[0];
					
					if (!wch)
						wch = pWppAuto->twAutoNumFormat[0];
					
					if (wch)
					{
						pptPfStyle.SetBulletCharChanged(TRUE);
						pptPfStyle.SetBulletChar(wch);
					}

					LPCTSTR pszFontName = pWppAuto->AutoNumCharAttrib.szCFontNameH;
					if(pszFontName && _tcslen(pszFontName))
					{
						UINT16 fontIdx;
						docuCtx.AddFont(fontIdx, pszFontName, GB2312_CHARSET);
						pptPfStyle.SetBulletFontId(fontIdx);
					}
					
					if (pWppAuto->lAutoNumCharShowScale)
						pptPfStyle.SetBulletHeight(pWppAuto->lAutoNumCharShowScale);
					else
						pptPfStyle.SetBulletHeight(100);
					pptPfStyle.SetBulletHeightChanged(TRUE);
				}
				pptPfStyle.SetBulletVisible(TRUE);
			}
			break;
		case SETPARAFRAME:
			//ppt��û��
			break;
		default:
			break;
		}
	}//end for
	return hr;	
}

STDMETHODIMP gExport_DefaultTxPFStyle(KPPTTxPFStyle& pptPfStyle, int styleType)
{
	if (TT_Body == styleType && !pptPfStyle.HasBulletVisible())
		pptPfStyle.SetBulletVisible(TRUE);
	if (TT_CenterBody == styleType && !pptPfStyle.HasBulletVisible())
		pptPfStyle.SetBulletVisible(FALSE);
	if (!pptPfStyle.HasBulletColor())
		pptPfStyle.SetBulletColor(0xff000000);
	if (!pptPfStyle.HasBulletChar())
		pptPfStyle.SetBulletChar(0x2022);
	if (!pptPfStyle.HasBulletFontId())
		pptPfStyle.SetBulletFontId(0);
	if (!pptPfStyle.HasBulletHeight())
		pptPfStyle.SetBulletHeight(100);

	if (!pptPfStyle.HasAdjust())
	{
		switch (styleType) {
		case TT_Title:
			pptPfStyle.SetAdjust(PF_Center);
			break;
		case TT_Body: // liupeng: wpp2003��bodyĬ�Ͼ��Ǿ��ȶ���
			pptPfStyle.SetAdjust(PF_Justify);
			break;
		case TT_Notes:
			pptPfStyle.SetAdjust(PF_Left);
			break;
		}
	}

	if (TT_Body == styleType)
	{
		if (!pptPfStyle.HasFontAlign())
			pptPfStyle.SetFontAlign(PF_UpHoldingFixed);
	}
	else
	{
		if (!pptPfStyle.HasFontAlign())
			pptPfStyle.SetFontAlign(PF_Roman);
	}

	if (!pptPfStyle.HasBulletOfs())
		pptPfStyle.SetBulletOfs(0);
	if (!pptPfStyle.HasTextOfs())
		pptPfStyle.SetTextOfs(0);
	if (!pptPfStyle.HasDefaultTab())
		pptPfStyle.SetDefaultTab(0x240);
	if (!pptPfStyle.HasLineBreak())
	{
		pptPfStyle.SetKinsoku(TRUE);
		pptPfStyle.SetHangingPunctuation(TRUE);
		pptPfStyle.SetWordWrap(TRUE);
	}
	
	return S_OK;
}

STDMETHODIMP gExport_DefaultTxCFStyle(KPPTTxCFStyle& pptCfStyle, int level)
{
	return S_OK;
}

PPT_NumeringType gExport_NumberingType(LPCTEXTWORD lpszFormat)
{
	PPT_NumeringType theNFCs[] = {
		NT_ArabicWithDot,		//[DBNum0] ��ǰ��������֣�0-9������Ĭ�������µ���ֵ��ҳ��
		NT_LChineseWithDot,	//[DBNum1] ����Сд����-�ţ�
		NT_LChineseWithDot,	//[DBNum2] ���Ĵ�д����-����
		NT_ArabicWithDot,		//[DBNum3] ȫ�ǰ��������֣���-����
		NT_URomaWithDot,		//[DBNum4] ������д
		NT_LRomaWithDot,		//[DBNum5] ����Сд
		NT_ULetterWithDot,	//[DBNum6] ascii���д
		NT_LLetterWithDot,	//[DBNum7] ascii��Сд
		NT_ArabicWithDot,		//[DBNum8] �����ʣ�1st 2nd 3rd ...��
		NT_ArabicWithDot,		//[DBNum9] �����ʣ�First Second Third ...��
		NT_ArabicWithDot,	//[DBNum10] �����ʣ�One Two Three ...��
		NT_ArabicWithDot,			//[DBNum11] ʮ��������
		NT_LChineseWithDot,		//[DBNum12] �� �� �� ...
		NT_LChineseWithDot,		//[DBNum13] �� �� ...
		NT_ArabicWithDot,			//[DBNum14] �� �� �� ...
		NT_ArabicWithLRBracket,			//[DBNum15] �� �� �� ... �� ��
		NT_ArabicWithRound,			//[DBNum16] �� �� �� ...
		NT_ULetterWithDot,			//[DBNum17] �� �� �� ...
	};

	PPT_NumeringType theNFC;
	int nFormat = ::CheckNumberFormat(lpszFormat);
	if (nFormat >= 0 && nFormat < sizeof(theNFCs)/sizeof(theNFCs[0]))
		theNFC = theNFCs[nFormat];
	else
	{
		ASSERT(FALSE);
		theNFC = NT_ArabicWithDot;
	}
	return theNFC;
}

STDMETHODIMP gExport_TxPFStyle(KPPTTxPFStyle& pptPfStyle,
							   CWPPDocContext& docuCtx,
							   const CStyle_Text& wppStyleText,
							   const CStyleSheet_Text& wppStyleSheet,
							   // for �Զ����
							   PSR_NumberingFormat** ppFormat
							   )
{
	HRESULT hr = S_OK;
	const CObList& wppPfList = wppStyleText.m_PAList;
	const CObList& wppCfList = wppStyleText.m_CAList;

	INT nNumTypeNo = 0;
	gExport_TxPFStyle(pptPfStyle, docuCtx, wppPfList, &wppCfList, 0, 0, NULL, &nNumTypeNo, ppFormat);
	//export base style
	if(wppStyleText.m_strBaseStyleName.GetLength() && 
		_tcsicmp(wppStyleText.m_strBaseStyleName, wppStyleText.m_strName))
	{
		const CStyle_Text* pWppStyleTextBase = wppStyleSheet.GetStyle(
			wppStyleText.m_dwBaseStyle, wppStyleText.m_strBaseStyleName);
		ASSERT(pWppStyleTextBase);
		gExport_TxPFStyle(pptPfStyle, docuCtx, *pWppStyleTextBase, wppStyleSheet, ppFormat);
	}

	return hr;
}

/*
 *cf
 */
STDMETHODIMP gExport_TxCFStyle(KPPTTxCFStyle& pptCfStyle,
							   CWPPDocContext& docuCtx,
							   const CObList& wppCfList
							   )
{
	HRESULT hr = S_OK;
	for(POSITION pos = wppCfList.GetHeadPosition(); pos;)
	{
		CCtrlCode* pWppCode = (CCtrlCode*)wppCfList.GetNext(pos);
		ASSERT_VALID(pWppCode);
		switch(pWppCode->GetCodeID())
		{
		case	SETCHNFONT://		0x1001      // �趨��������
			{
				CCtrlCode_Font* pWppChnCode = (CCtrlCode_Font*)pWppCode;
				ASSERT_VALID(pWppChnCode);
				UINT16 fontIdx;
				docuCtx.AddFont(fontIdx, pWppChnCode->GetFaceName(), GB2312_CHARSET);
				if(!pptCfStyle.HasFarEastFont())
				{
					pptCfStyle.SetFarEastFont(fontIdx);
				}
			}
			break;
		case	SETENGFONT://		0x1002      // �趨��������
			{
				CCtrlCode_Font* pWppEngCode = (CCtrlCode_Font*)pWppCode;
				ASSERT_VALID(pWppEngCode);
				UINT16 fontIdx;
				docuCtx.AddFont(fontIdx, pWppEngCode->GetFaceName());
				if(!pptCfStyle.HasEnglishFont())
				{
					pptCfStyle.SetEnglishFont(fontIdx);
				}
				if(!pptCfStyle.HasDefaultFont())
				{
					UINT16 fontIdxDef;
					docuCtx.AddFont(fontIdxDef, __T("Arial"));
					pptCfStyle.SetDefaultFont(fontIdxDef);
				}
			}
			break;
		case	SETFONTSIZE://		0x1003		// �趨�ֺ�
			if(!pptCfStyle.HasFontSize())
			{
				CCtrlCode_Size* pWppSizeCode = (CCtrlCode_Size*)pWppCode;
				ASSERT_VALID(pWppSizeCode);
				UINT16 fontSize;
				gExport_FontSize(fontSize, pWppSizeCode);
				pptCfStyle.SetFontSize(fontSize);
			}
			break;
		case	SETCOLOR://		0x1006		// �趨�ַ���ɫ
			if(!pptCfStyle.HasColor())
			{
				CCtrlCode_Color* pWppColorCode = (CCtrlCode_Color*)pWppCode;
				ASSERT_VALID(pWppColorCode);
				KCOLORINDEX wppColor = pWppColorCode->GetColor();
				COLORREF pptColor = gWppColor2PPtColor(wppColor);
				pptCfStyle.SetColor(pptColor);
			}
			break;
		case	SETITALIC://		0x1007		// �趨б��
			if(!pptCfStyle.HasItalic())// && wppItalicCode->GetDegree())
			{
				CCtrlCode_Italic* pWppItalicCode = (CCtrlCode_Italic*)pWppCode;
				ASSERT_VALID(pWppItalicCode);
				if(pWppItalicCode->GetDegree() > 1)
				{
					pptCfStyle.SetItalic(TRUE);
				}
			}
			break;
		case	SETBOLD://			0x1008		// �趨����
			if(!pptCfStyle.HasBold())// && wppBoldCode->GetWeight() > FW_NORMAL)
			{
				CCtrlCode_Bold* pWppBoldCode = (CCtrlCode_Bold*)pWppCode;
				ASSERT_VALID(pWppBoldCode);
				if(pWppBoldCode->GetWeight() > FW_NORMAL)
				{
					pptCfStyle.SetBold(TRUE);
				}
			}
			break;
		case	SETUNDERLINE://	0x1009		// �趨�»���
			if(!pptCfStyle.HasUnderLine())// &&)
			{
				CCtrlCode_UnderLine* pWppUnderLineCode = (CCtrlCode_UnderLine*)pWppCode;
				ASSERT_VALID(pWppUnderLineCode);
				if(pWppUnderLineCode->GetType() != PS_NULL)
				{
					pptCfStyle.SetUnderLine(TRUE);
				}
			}
			break;
		case	SETSSS://			0x100B		// �趨���±�
			if(!pptCfStyle.HasSubScript())
			{
				CCtrlCode_SSScript* pWppSSSCode = (CCtrlCode_SSScript*)pWppCode;
				ASSERT_VALID(pWppSSSCode);
				const SUPERSUBSCRIPT* pssData = pWppSSSCode->GetData();
				if(pWppSSSCode->GetFlag() == SSS_SUPER || pWppSSSCode->GetFlag() == SSS_SUB)
				{
					pptCfStyle.SetSubScript(-pssData->nRelativeShift);
				}
			}
			break;
		case 	SETHSS://			0x100C		// �趨����/����/��Ӱ��
			{
				CCtrlCode_HSS* pWppHssCode = (CCtrlCode_HSS*)pWppCode;
				ASSERT_VALID(pWppHssCode);
				const CHARFXHSS* pchFxhss = pWppHssCode->GetData();	
				switch(pchFxhss->hssFlag)
				{
				case SETSHADOW:
					if(!pptCfStyle.HasShadow())
					{
						pptCfStyle.SetShadow(TRUE);
					}
					break;
				case SETEMBOSS_POS:
					if(!pptCfStyle.HasEmboss())
					{
						pptCfStyle.SetEmboss(TRUE);
					}
					break;
				}
			}
			break;
		}
	}
	return hr;
}


STDMETHODIMP gExport_TxCFStyle(KPPTTxCFStyle& pptCfStyle, 
							   CWPPDocContext& docuCtx,
							   const CStyle_Text& wppStyleText,
							   const CStyleSheet_Text& wppStyleSheet
							   )
{
	HRESULT hr = S_OK;
	const CObList& wppCfList = wppStyleText.m_CAList;
	gExport_TxCFStyle(pptCfStyle, docuCtx, wppCfList);
	//export base style
	if(wppStyleText.m_strBaseStyleName.GetLength() && 
		_tcsicmp(wppStyleText.m_strBaseStyleName, wppStyleText.m_strName))
	{
		const CStyle_Text* pWppStyleTextBase = wppStyleSheet.GetStyle(
			wppStyleText.m_dwBaseStyle, wppStyleText.m_strBaseStyleName);
		ASSERT(pWppStyleTextBase);
		gExport_TxCFStyle(pptCfStyle, docuCtx, *pWppStyleTextBase, wppStyleSheet);
	}

	return hr;
}
STDMETHODIMP gExport_FontSize(OUT UINT16& fontSize, const CCtrlCode_Size* pWppSizeCode,
					  const CObList* pWppCfList/* = NULL*/)
{
	HRESULT hr = S_OK;
	fontSize = 28;
	if(pWppSizeCode == NULL)
	{
		if(pWppCfList)
		{
			pWppSizeCode = (const CCtrlCode_Size*)CCtrlCodeTool::FindCtrlCode(
				(CObList*)pWppCfList, SETFONTSIZE);
		}
	}
	if(pWppSizeCode)
	{
		switch(pWppSizeCode->GetActualUnit())
		{
		case FSU_SIZE:
			fontSize = gGetFontPtFromSize(pWppSizeCode->GetActualSize());
			break;
		case FSU_POUND:
			fontSize = pWppSizeCode->GetActualSize();
			break;
		case FSU_HM:
			fontSize = hm2pt(pWppSizeCode->GetActualSize());
		}
	}
	return hr;
}

//enum __ParaMarginType{__PMT_Line, __PMT_Before, __PMT_After, __PMT_FirstIndent, __PMT_LeftIndent};
STDMETHODIMP gExport_ParaMargin(INT16& pptValue, const UNIT_VALUE& wppValue, __ParaMarginType pmt,
							const CObList* pWppCfList/* = NULL*/)
{
	HRESULT hr = S_OK;
	pptValue = 100;
	if(pmt == __PMT_Line)//wpp:�м��;ppt:�о�
	{
		switch(wppValue.wUnit)
		{
		case UNIT_METRIC://		(WORD)1		// ���Ե�λ��0.1mm
			{
				UINT16 fontSize;
				gExport_FontSize(fontSize, NULL, pWppCfList);
				pptValue = -(fontSize * 20 * 1.25 / 2.5 + WpsShapeToPptUnit(wppValue.nValue));
			}
			break;
		case UNIT_PERCENT://	(WORD)2		// ��Ե�λ���ٷֱ�
			{
				pptValue = 100 + wppValue.nValue;
			}
			break;
		case UNIT_EXACT://		(WORD)3		// �̶�ֵ�� 0.1mm �����м��ʱָ���̶�ֵ�������Word����ͬ��
			{
				pptValue = -WpsShapeToPptUnit(wppValue.nValue);
			}
			break;
			
		case UNIT_MIN://		(WORD)4		// ��Сֵ:  0.1mm �����м��ʱָ����Сֵ�������Word����ͬ��
			{
				ASSERT(FALSE);
				//@@todo ��֪��ʲô����!
			}
			break;
		default:
			ASSERT(FALSE);
			break;
		}
	}
	else if(pmt == __PMT_Before || pmt == __PMT_After)
	{
		switch(wppValue.wUnit)
		{
		case UNIT_METRIC://		(WORD)1		// ���Ե�λ��0.1mm
			{
				pptValue = -WpsShapeToPptUnit(wppValue.nValue);
			}
			break;
		case UNIT_PERCENT://	(WORD)2		// ��Ե�λ���ٷֱ�
			{
				pptValue = wppValue.nValue;
			}
			break;
		default:
			ASSERT(FALSE);
			break;
		}

	}
	else if(pmt == __PMT_FirstIndent || pmt == __PMT_LeftIndent)
	{
		switch(wppValue.wUnit)
		{
		case UNIT_METRIC://		(WORD)1		// ���Ե�λ��0.1mm
			{
				pptValue = WpsShapeToPptUnit(wppValue.nValue);
			}
			break;
		case UNIT_GRID://		(WORD)2		// ��Ե�λ���ַ�(��)��
			{
				UINT16 fontSize;
				gExport_FontSize(fontSize, NULL, pWppCfList);
				pptValue = fontSize * 20  * WpsShapeToPptUnit(wppValue.nValue) / 2.5;
			}
			break;
		default:
			ASSERT(FALSE);
			break;
		}
	}
	else
	{
		ASSERT(FALSE);
	}
	return hr;
}

STDMETHODIMP gExport_LeftIndent(OUT UINT16& leftIndent, const CCtrlCode_ParaIndent* pWppParaIndentCode,
					const CObList* pWppPfList /*= NULL*/, const CObList* pWppCfList /*= NULL*/)
{
	HRESULT hr = S_OK;
	leftIndent = 0;
	if(pWppParaIndentCode == NULL)
	{
		if(pWppPfList)
		{
			pWppParaIndentCode = (const CCtrlCode_ParaIndent*)CCtrlCodeTool::FindCtrlCode(
				(CObList*)pWppPfList, SETLEFTINDENT);
		}
	}
	if(pWppParaIndentCode)
	{
		const UNIT_VALUE* wppValue = pWppParaIndentCode->GetIndent();
		gExport_ParaMargin((INT16&)leftIndent, *wppValue, __PMT_LeftIndent, pWppCfList);
	}
	return hr;
}

void gExport_GetStyleLevel(const CString& wppStyleName,
						   OUT PPT_TextType& pptTextType,
						   OUT __StyleType& styleType,
						   OUT int& npptLevel)
{
	pptTextType = TT_Invalid;
	styleType = __ST_5Level;
	npptLevel = 0;
	//�ԡ�_H����β����ʽ��ʾ��H1-H5 5��
	if(wppStyleName.Find(_T("WPPS_SLIDE_H")) >= 0)
	{
		pptTextType = TT_Body;
	}
	else if(wppStyleName.Find(_T("WPPS_SLIDE_TITLE")) >= 0)
	{
		pptTextType = TT_Title;
		styleType = __ST_Single;
	}
	else if(wppStyleName.Find(_T("WPPS_TITLE_H")) >= 0)
	{
		pptTextType = TT_CenterBody;
	}
	else if(wppStyleName.Find(_T("WPPS_TITLE_TITLE")) >= 0)
	{
		pptTextType = TT_CenterTitle;
		styleType = __ST_Single;
	}
	else if(wppStyleName.Find(_T("WPPS_NOTES_H")) >= 0)
	{
		pptTextType = TT_Notes;
	}
	else if(wppStyleName.Find(_T("WPPS_HALFBODY_H")) >= 0)
	{
		pptTextType = TT_HalfBody;
	}
	else if(wppStyleName.Find(_T("WPPS_QUARTERBODY_H")) >= 0)
	{
		pptTextType = TT_QuarterBody;
	}
	else if(wppStyleName.Find(_T("WPPS_DEFAULTTEXTBOX_H")) >= 0)
	{
		pptTextType = TT_Other;
	}
	else if(wppStyleName.Find(_T("WPPS_DEFAULT_H")) >= 0)
	{
		//pptTextType = TT_???;
	}
	else if(wppStyleName.CompareNoCase(_T("����")) == 0)
	{
		pptTextType = TT_Other;
		npptLevel = 0;
		return;
	}
	else
	{
		styleType = __ST_Null;
	}
	//
	if(styleType == __ST_5Level)
	{
		TCHAR szLevel[2] = {0};
		szLevel[0] = wppStyleName[wppStyleName.GetLength() - 1];
		npptLevel = _ttoi(szLevel) - 1;
		ASSERT(npptLevel >= 0 && npptLevel < PPT_MAXLEVEL);
	}
}
//slide layout
//layoutID����g_SlideLayout[]����
STDMETHODIMP gExport_Layout(CWPPSlideBaseContext& slideBaseCtx, UINT layoutID)
{
//	ASSERT(layoutID < MAX_SLIDE_LAYOUT_ID);
	HRESULT hr = S_OK;
	PSR_SSlideLayoutAtom pptlo = {0};
	switch(layoutID)
	{
	case -1://main master
		pptlo.geom = SL_TITLEANDBODYSLIDE;
		pptlo.placeholderId[0] = PH_MASTERTITLE;
		pptlo.placeholderId[1] = PH_MASTERBODY;
		pptlo.placeholderId[2] = PH_MASTERDATE;
		pptlo.placeholderId[3] = PH_MASTERFOOTER;
		pptlo.placeholderId[4] = PH_MASTERSLIDENUMBER;
		break;
	case -2://title master
		pptlo.geom = SL_TITLEMASTERSLIDE;
		pptlo.placeholderId[0] = PH_MASTERCENTEREDTITLE;
		pptlo.placeholderId[1] = PH_MASTERSUBTITLE;
		pptlo.placeholderId[2] = PH_MASTERDATE;
		pptlo.placeholderId[3] = PH_MASTERFOOTER;
		pptlo.placeholderId[4] = PH_MASTERSLIDENUMBER;
		break;
	case 0://����ҳ 2
		pptlo.geom = SL_TITLESLIDE;
		pptlo.placeholderId[0] = PH_CENTEREDTITLE;
		pptlo.placeholderId[1] = PH_SUBTITLE;
		break;
	case 1://����ҳ 2
		pptlo.geom = SL_TITLEANDBODYSLIDE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_BODY;
		break;
	case 2://�������� 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_BODY;
		pptlo.placeholderId[2] = PH_BODY;
		break;
	case 3://�հ�ҳ 0
		pptlo.geom = SL_BLANCSLIDE;
		break;
	case 4://���� 2
		pptlo.geom = SL_TITLEANDBODYSLIDE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_TABLE;
		break;
	case 5://ͼ�� 2
		pptlo.geom = SL_TITLEANDBODYSLIDE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_GRAPH;
		break;
	case 6://���⣬�������� 2   							
		pptlo.geom = SL_TITLEANDBODYSLIDE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_VERTICALTEXTBODY;
		break;
	case 7://���ű��⼰���� 2
		pptlo.geom = SL_TITLERIGHTBODYLEFT;
		pptlo.placeholderId[0] = PH_VERTICALTEXTTITLE;
		pptlo.placeholderId[1] = PH_VERTICALTEXTBODY;
		break;
	case 8://���⣬���֣����� 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_BODY;
		pptlo.placeholderId[2] = PH_TABLE;
		break;
	case 9://���⣬���֣�ͼ�� 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_BODY;
		pptlo.placeholderId[2] = PH_GRAPH;
		break;
	case 10://���⣬�������� 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_TABLE;
		pptlo.placeholderId[2] = PH_BODY;
		break;
	case 11://���⣬ͼ�������� 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_GRAPH;
		pptlo.placeholderId[2] = PH_BODY;
		break;
	case 12://ֻ�б��� 1
		pptlo.geom = SL_ONLYTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		break;
	case 13://ͼ�� 2
		pptlo.geom = SL_TITLEANDBODYSLIDE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_CLIPART;
		break;
	case 14://���⣬ͼ������ 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_CLIPART;
		pptlo.placeholderId[2] = PH_BODY;
		break;
	case 15://���⣬���֣�ͼ�� 3
		pptlo.geom = SL_2COLUMNSANDTITLE;
		pptlo.placeholderId[0] = PH_TITLE;
		pptlo.placeholderId[1] = PH_BODY;
		pptlo.placeholderId[2] = PH_CLIPART;
		break;
	case 16://���ű��⣬������������ 3
		pptlo.geom = SL_TITLERIGHT2BODIESLEFT;
		pptlo.placeholderId[0] = PH_VERTICALTEXTTITLE;
		pptlo.placeholderId[1] = PH_BODY;
		pptlo.placeholderId[2] = PH_TABLE;
		break;
	case 17://���ű��⣬ͼ���������� 3
		pptlo.geom = SL_TITLERIGHT2BODIESLEFT;
		pptlo.placeholderId[0] = PH_VERTICALTEXTTITLE;
		pptlo.placeholderId[1] = PH_BODY;
		pptlo.placeholderId[2] = PH_GRAPH;
		break;
	case 18://���ű��⣬�����ڱ����� 3
		pptlo.geom = SL_TITLERIGHT2BODIESLEFT;
		pptlo.placeholderId[0] = PH_VERTICALTEXTTITLE;
		pptlo.placeholderId[1] = PH_TABLE;
		pptlo.placeholderId[2] = PH_BODY;
		break;
	case 19://���ű��⣬������ͼ���� 3
		pptlo.geom = SL_TITLERIGHT2BODIESLEFT;
		pptlo.placeholderId[0] = PH_VERTICALTEXTTITLE;
		pptlo.placeholderId[1] = PH_GRAPH;
		pptlo.placeholderId[2] = PH_BODY;
		break;
	default:
		ASSERT(FALSE);
		break;
	}
	slideBaseCtx.GetLayout() = pptlo;
	hr = slideBaseCtx.GetPptSlide()->SetSlideLayout(pptlo);
	return hr;
}

#endif// defined(WPP_ONLY)