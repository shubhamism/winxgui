/* -------------------------------------------------------------------------
//	�ļ���		��	ex_frametbl.h
//	������		��	��־��
//	����ʱ��	��	2004-11-23 15:54:41
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_frametbl.h"
#include "../../core/ctrlcodetool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


EX_SHAPE_API CFrameTable_Export::GetTablePosAndPr(CShape_Context& context,
		/*out*/KDWTablePos& tblPos, /*out*/KDWRowTablePr& tblPr)
{
	//tblPos
	if(!context.IsInlineShape())
	{
		//����ʱ���������ĵľ���(in twips)������ν������
//		tblPos.leftFromText = WpsShapeToTwip(m_MarginOutside.left);
//		tblPos.topFromText = WpsShapeToTwip(m_MarginOutside.top);
//		tblPos.rightFromText = WpsShapeToTwip(m_MarginOutside.right);
//		tblPos.bottomFromText = WpsShapeToTwip(m_MarginOutside.bottom);
//		//
		tblPos.tblOverlap = 1;
		//
		tblPos.pcHorz = mso_pcHorzPage;
		tblPos.pcVert = mso_pcVertPage;
		//tblPos.tblpXSpec = 0;
		//tblPos.tblpYSpec = 0;
		tblPos.tblpX = WpsShapeToTwip(m_rect.left);
		tblPos.tblpY = WpsShapeToTwip(m_rect.top);
	}
	else
	{
		if (context.m_ParagraphTableFlag == INS_ANC_TEXT_OBJECT)
			tblPr.jc = mso_jcLeftJustify;
		else
			tblPr.jc = mso_jcCenter;
	}
	//tblPr
	//�߿�����
	gSetBRCEX(m_LPenColor, m_uLPenSize, m_uLPenStyle, 
		tblPr.tblBorders[mso_tblBrcTop], &tblPr.tblBorders[mso_tblBrcBottom]);
	tblPr.tblBorders[mso_tblBrcLeft] = tblPr.tblBorders[mso_tblBrcTop];
	tblPr.tblBorders[mso_tblBrcRight] = tblPr.tblBorders[mso_tblBrcBottom];
	if(m_nfrmShape)
	{
		if(!(m_nfrmShape & FS_L))
		{
			tblPr.tblBorders[mso_tblBrcLeft].put_Delete();
		}
		if(!(m_nfrmShape & FS_T))
		{
			tblPr.tblBorders[mso_tblBrcTop].put_Delete();
		}
		if(!(m_nfrmShape & FS_R))
		{
			tblPr.tblBorders[mso_tblBrcRight].put_Delete();
		}
		if(!(m_nfrmShape & FS_B))
		{
			tblPr.tblBorders[mso_tblBrcBottom].put_Delete();
		}
	}
	//���
	COLORREF bkColor = m_logbrush.lbColor;//wps����ɫ����÷ǳ�����
	if(m_nBkMode == OPAQUE && m_logbrush.lbStyle == BS_HATCHED)
		bkColor = m_bkColor;
	gSetSHDEX(m_nBkMode == OPAQUE, bkColor,
		m_logbrush.lbStyle == BS_HATCHED, m_logbrush.lbColor, m_logbrush.lbHatch, tblPr.shd);
	//
	tblPr.typeCellWidth = mso_vetDxa;
}

EX_SHAPE_API CFrameTable_Export::GetCellPr(CTableElement* pEle, /*out*/KDWCellPr& cellPr)
{
	//�߿�����
	gSetBRCEX(pEle->m_LPenColor[0], pEle->m_uLPenSize[0], pEle->m_uLPenStyle[0], 
		cellPr.tcBorders[mso_tcBrcRight]);
	gSetBRCEX(pEle->m_LPenColor[1], pEle->m_uLPenSize[1], pEle->m_uLPenStyle[1], 
		cellPr.tcBorders[mso_tcBrcBottom]);

	//���
	COLORREF bkColor = pEle->m_logbrush.lbColor;//wps����ɫ����÷ǳ�����
	if(pEle->m_nBkMode == OPAQUE && pEle->m_logbrush.lbStyle == BS_HATCHED)
	{
		bkColor = pEle->m_bkColor;
	}
	if(pEle->m_nBkMode == GRADIENT)//���������ʵ�����
	{
		bkColor = pEle->m_bkColor;
	}
	gSetSHDEX(pEle->m_nBkMode == OPAQUE || pEle->m_nBkMode == GRADIENT, bkColor,
			pEle->m_logbrush.lbStyle == BS_HATCHED, pEle->m_logbrush.lbColor,
			pEle->m_logbrush.lbHatch, cellPr.shd);
	//��Ԫ��ֱ����
	CCtrlCode_Alignment* pCodeV = NULL;
	for(POSITION pos = pEle->m_AttribList.GetHeadPosition(); pos;)
	{
		CCtrlCode* pCode = (CCtrlCode*)pEle->m_AttribList.GetNext(pos);
		ASSERT_VALID(pCode);
		if(pCode->GetCodeID() == SETVALIGNMENT)
		{
			pCodeV = (CCtrlCode_Alignment*)pCode;
			break;
		}
	}
	if(!pCodeV)
	{
		pCodeV = (CCtrlCode_Alignment*)m_AttribArray[CC_ALIGV];
	}
	ASSERT_VALID(pCodeV);
	WORD vAlign = pCodeV->GetAlignment();
	if(vAlign == TAL_VCENTER)
	{
		cellPr.vertAlign = mso_tcVAlignCenter;//TC_VERTALIGN
	}
	else if(vAlign == TAL_BOTTOM)
	{
		cellPr.vertAlign = mso_tcVAlignBottom;
	}
}
void GetCellFillIdx(int rowCount, int* pptRow,
					int colCount, int* pptCol,
					RECT& rcCell,
					OUT int& rowIdxStart, OUT int& rowIdxEnd,
					OUT int& colIdxStart, OUT int& colIdxEnd
					)
{
	rowIdxStart = rowIdxEnd = -1;
	colIdxStart = colIdxEnd = -1;
	int i;
	for(i = 0; i < rowCount; i++)
	{
		if(rcCell.top == pptRow[i])
			rowIdxStart = i;
		if(rcCell.bottom == pptRow[i])
			rowIdxEnd = i - 1;
	}
	for(i = 0; i < colCount; i++)
	{
		if(rcCell.left == pptCol[i])
			colIdxStart = i;
		if(rcCell.right == pptCol[i])
			colIdxEnd = i - 1;
	}
	ASSERT(rowIdxStart != -1 && rowIdxEnd != -1 && rowIdxStart <= rowIdxEnd);
	ASSERT(colIdxStart != -1 && colIdxEnd != -1 && colIdxStart <= colIdxEnd);

}

#define _CP(rowIdx, colIdx) (pcp[(rowIdx) * (colCount) + (colIdx)])
EX_SHAPE_API CFrameTable_Export::AllocCellPr(/*out*/_CellInfo*& pcp)
{
	int rowCount = GetRowCount();
	int colCount = GetColCount();
	ASSERT(rowCount > 0 && colCount > 0);
	int rowIdx, colIdx, i, j;
	//ÿ��"ԭʼ"��Ĵ�С
	int* pptRow = new int[rowCount + 1];
	int* pptCol = new int[colCount + 1];
	CTableRowCol* pRow;
	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
	{
		pRow = GetRow(rowIdx);
		ASSERT(pRow);
		pptRow[rowIdx] = pRow->m_rect.top;
	}
	pptRow[rowCount] = pRow->m_rect.bottom;
	//
	CTableRowCol* pCol;
	for(colIdx = 0; colIdx < colCount; colIdx++)
	{
		pCol = GetCol(colIdx);
		ASSERT(pCol);
		pptCol[colIdx] = pCol->m_rect.left;
	}
	pptCol[colCount] = pCol->m_rect.right;
	//
	pcp = new _CellInfo[rowCount * colCount];
	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
	{
		_CP(rowIdx, 0).height = WpsShapeToTwip(pptRow[rowIdx + 1] - pptRow[rowIdx]);//ÿ�е�һ����Ԫ���¼���еĸ߶�
		CTableRowCol* pRow = GetRow(rowIdx);
		ASSERT(pRow);
		for(colIdx = 0; colIdx < pRow->GetElemSize(); colIdx++)
		{
			CTableElement* pEle = pRow->GetElem(colIdx);
			ASSERT(pEle);
			int rowIdxStart, rowIdxEnd;
			int colIdxStart, colIdxEnd;
			GetCellFillIdx(rowCount + 1, pptRow, colCount + 1, pptCol, pEle->m_rect,
				rowIdxStart, rowIdxEnd, colIdxStart, colIdxEnd);
			GetCellPr(pEle, _CP(rowIdxStart, colIdxStart).cp);
			_CP(rowIdxStart, colIdxStart).pEle = pEle;
			for(i = rowIdxStart; i <= rowIdxEnd; i++)
			{
				for(j = colIdxStart; j <= colIdxEnd; j++)
				{
					if(i != rowIdxStart || j != colIdxStart)
					{
						_CP(i, j) = _CP(rowIdxStart, colIdxStart);
					}

					if(i == rowIdxStart && rowIdxStart < rowIdxEnd)
					{
						_CP(i, j).cp.vertMerge = mso_tcVertFirstMerge;
					}
					else if(i > rowIdxStart)
					{
						_CP(i, j).cp.vertMerge = mso_tcVertMerged;
					}
					//
					if(j == colIdxStart && colIdxStart < colIdxEnd)
					{
						_CP(i, j).cp.horiMerge = mso_tcHoriFirstMerge;
					}
					else if(j > colIdxStart)
					{
						_CP(i, j).cp.horiMerge = mso_tcHoriMerged;
					}
					//����
					_CP(i, j).cp.tcWidth = WpsShapeToTwip(pptCol[j + 1] - pptCol[j]);//
				}
			}
		}
	}
	//
	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
	{
		for(colIdx = 0; colIdx < colCount; colIdx++)
		{
			//�������Ԫ���ұ�Ϊ����,����һ����Ԫ����߲���
			if(_CP(rowIdx, colIdx).cp.tcBorders[mso_tcBrcRight].is_BrcDelete())
			{
				if(colIdx < colCount -1)
				{
					_CP(rowIdx, colIdx + 1).cp.tcBorders[mso_tcBrcLeft].put_Delete();
				}
			}
			//�������Ԫ���±�Ϊ����,����һ����Ԫ���ϱ߲���
			if(_CP(rowIdx, colIdx).cp.tcBorders[mso_tcBrcBottom].is_BrcDelete())
			{
				if(rowIdx < rowCount -1)
				{
					_CP(rowIdx + 1, colIdx).cp.tcBorders[mso_tcBrcTop].put_Delete();
				}
			}
			//����һ���±߲��ܻ�
			if(rowIdx == rowCount - 1)
			{
				_CP(rowIdx, colIdx).cp.tcBorders[mso_tcBrcBottom].put_Nil();
			}
			//����һ���ұ߲��ܻ�
			if(colIdx == colCount - 1)
			{
				//ˮƽ�ϲ�������
				for(i = colIdx; _CP(rowIdx, i).cp.horiMerge == mso_tcHoriMerged; i--);
				_CP(rowIdx, i).cp.tcBorders[mso_tcBrcRight].put_Nil();
			}
			//"ˮƽ�ϲ�"�������
			if(_CP(rowIdx, colIdx).cp.horiMerge == mso_tcHoriFirstMerge)
			{
				for(i = colIdx + 1; _CP(rowIdx, i).cp.horiMerge == mso_tcHoriMerged; i++)
				{
					_CP(rowIdx, colIdx).cp.tcWidth += _CP(rowIdx, i).cp.tcWidth;//�������
				}
			}

		}
	}
	delete []pptRow;
	delete []pptCol;
}

EX_SHAPE_API CFrameTable_Export::SetPapxAndChpx(CShape_Context& context, CTableElement* pEle,
								OUT KDWPropBuffer& papx, OUT KDWPropBuffer& chpx)
{
	PapxCtrlCode_Context papxctrlcode(context.m_export);
	ChpxCtrlCode_Context chpxctrlcode(context.m_export);
	UINT uStyleID = context.m_export.AddStyle_DefaultTable();
	papx.AddIstd(uStyleID);
	CCtrlCode* pCode;
	POSITION pos;

	for(int i = 0; i < m_AttribArray.GetSize(); i++)
	{
		pCode = (CCtrlCode*)m_AttribArray.GetAt(i);
		if(pCode == 0)
			continue;
		
		ASSERT_VALID(pCode);
		if (CCtrlCodeTool::FindCtrlCode(&pEle->m_AttribList, pCode->GetCodeID()) == 0)
			pEle->m_AttribList.AddTail(pCode->Clone());
	}
	
	context.m_export.m_pTblEleAttri = &pEle->m_AttribList;
	for(pos = pEle->m_AttribList.GetHeadPosition(); pos;)
	{
		pCode = (CCtrlCode*)pEle->m_AttribList.GetNext(pos);
		ASSERT_VALID(pCode);
		if(gIsPapxCtrlCode(pCode->GetCodeID()))
			papxctrlcode.ConvCtrlCode(pCode, papx);
		else
			chpxctrlcode.ConvCtrlCode(pCode, chpx);
	}
	context.m_export.m_pTblEleAttri = NULL;
}

EX_SHAPE_API CFrameTable_Export::AddContent(KDWDocument& docu, KSTextString& kstr, 
					KDWPropBuffer& papxE, KDWPropBuffer& chpxE)
{
	docu.NewParagraph(&papxE);
	docu.NewSpan(&chpxE);
	CString str;
	TextStringToString(str, kstr);
	BSTR bstr = str.AllocSysString();
	WCHAR chLastEscChar = 0, chLastChar = 0;
	for (int i = 0; i < SysStringLen(bstr); i++)
	{
		WCHAR chCur = bstr[i];
		if (chCur == def_SUP || chCur == def_SUB)			// �ϱ�
		{
			if (chLastEscChar != chCur)	// ��Ҫ��ʼ�¾�
			{
				KDWPropBuffer chpx;
				chpx.AddProps(chpxE.GetData(docu.GetAllocater()));
				chpx.AddPropFix(sprmCIss,chCur == def_SUP ? 1 : 2);
				docu.NewSpan(&chpx);
			}
			chLastEscChar = chCur;
			i++;
			if (i >= SysStringLen(bstr))
			{
				ASSERT(FALSE);
				break;
			}
			chCur = bstr[i];
		}
		else
		{
			if (chLastEscChar == def_SUP || chLastEscChar == def_SUB)
			{
				docu.NewSpan(&chpxE);
				chLastEscChar = 0;
			}
		}
		if (chLastChar == __X(' ') && chCur == __X(' '))
		{
			chLastChar = 0;
			continue;
		}
		chLastChar = chCur;
		docu.AddContent(chCur);
		if (chCur == 0x0d)
		{
			docu.NewParagraph(&papxE);
			docu.NewSpan(&chpxE);
		}
	}
	if (chLastEscChar == def_SUP || chLastEscChar == def_SUB)
	{
		docu.NewSpan(&chpxE);
		chLastEscChar = 0;
	}
	SysFreeString(bstr);
	docu.AddContent(0x0d);
}
BOOL CFrameTable_Export::AllocaDiagonal(CTableElement* pEle, 
										OUT std::vector<KDWDiagonal>& vecDiagonal,
										BOOL* bNeedReverse)
{
	// �ж��Ƿ���Ҫ��תб�߱�Ԫ�����ֵ�˳��
	// ��Ϊv6�е�˳���Ƿ����wpsһ�»��෴��ֻ��ȡ����б�ߵĶ���
	// ���£����ϣ�һ�£������ϣ����£��෴��
	// �����ֻ��һ��б�ߣ���\�Ķ��������ϣ�/�Ķ���������
	// �ж϶�������ͣ�ֻ��Ҫ֪������б�߼���
	*bNeedReverse = FALSE;
	int diaPercentTwo[2][2];

	BOOL fOblique = FALSE;
	int nIndex = 0, lDiaLineCnt = 0;
	if(pEle->m_nType == CTableElement::TT_oblique)//б�߱�Ԫ
	{
		fOblique = TRUE;
		for(POSITION pos = pEle->m_objList.GetHeadPosition(); pos;)
		{
			CObject* pObj = pEle->m_objList.GetNext(pos);
			if(pObj->IsKindOf(RUNTIME_CLASS(CLineObj)))
			{
				lDiaLineCnt++;
				CLineObj* pLineObj = (CLineObj*)pObj;
				ASSERT_VALID(pLineObj);
				int diaPercent[2];
				for(int i = 0; i < 2; i++)
				{
					POINT& pt = pLineObj->m_linepnt[i];
					CRect& rc = pEle->m_rect;
					if(pt.y == 0)
					{
						diaPercent[i] = (pt.x * 100 / rc.Width() + 100) * 50;
					}
					else if(pt.x == 0)
					{
						diaPercent[i] = ((rc.Height() - pt.y) * 100 / rc.Height()) * 50;
					}
					else if(pt.x == rc.Width())
					{
						diaPercent[i] = (pt.y * 100 / rc.Height() + 200) * 50;
					}
					else if(pt.y == rc.Height())
					{
						diaPercent[i] = ((rc.Width() - pt.x) * 100 / rc.Width() + 300) * 50;
					}
					else
					{
						ASSERT(FALSE);
					}
				}
				if (nIndex < 2)
					::memcpy(diaPercentTwo[nIndex], diaPercent, sizeof(int) * 2);

				KDWDiagonal dia;
				dia.put_Diagonal(diaPercent[0], diaPercent[1]);
				vecDiagonal.push_back(dia);
				nIndex++;
			}
		}

		// diaPercentTwo ����������ǣ�
		// ԭ�������½ǣ��ǶȰ���˳ʱ��չ������Χ��[0, 20000]
		// 5000---10000
		// |		|
		// 0------15000
		// wps�����ĳЩ���͵�б�߱�Ԫ�����д�Լ50���ҵ����
		#define WPSDIALINE_EQUAL(x, y)	(abs((x) - (y)) <= 100)

		if (lDiaLineCnt == 1)
		{
			if (WPSDIALINE_EQUAL(diaPercentTwo[0][0], 5000) || 
				WPSDIALINE_EQUAL(diaPercentTwo[0][1], 5000))
				*bNeedReverse = TRUE;
		}
		else if (lDiaLineCnt > 1)
		{
			int nOrg = 0;
			if (WPSDIALINE_EQUAL(diaPercentTwo[0][0], diaPercentTwo[1][0]))
				nOrg = diaPercentTwo[1][0];
			else if (WPSDIALINE_EQUAL(diaPercentTwo[0][0], diaPercentTwo[1][1]))
				nOrg = diaPercentTwo[1][1];
			else if (WPSDIALINE_EQUAL(diaPercentTwo[0][1], diaPercentTwo[1][0]))
				nOrg = diaPercentTwo[1][0];
			else if (WPSDIALINE_EQUAL(diaPercentTwo[0][1], diaPercentTwo[1][1]))
				nOrg = diaPercentTwo[1][1];

			if (WPSDIALINE_EQUAL(nOrg, 5000) || WPSDIALINE_EQUAL(nOrg, 15000))
				*bNeedReverse = TRUE;
		}
	}
	return fOblique;
}

EX_SHAPE_API CFrameTable_Export::ConvertShape(CShape_Context& context)
{
#ifdef WPP_ONLY
	ASSERT(FALSE);
	return;
#endif
	KDWDocument& docu = context.GetWpsExport();

	KDWTablePos tblPos;//���ñ����λ�����Եġ�
	KDWRowTablePr tblPr;//���ñ�����е����Եġ�
	
	GetTablePosAndPr(context, tblPos, tblPr);

	int rowCount = GetRowCount();
	int colCount = GetColCount();
	int rowIdx, colIdx;
	_CellInfo* pcp;
	AllocCellPr(pcp);

	if(context.IsInlineShape())
	{
	}
	else//�����ı���������һ���ı���,��v6�¸�ҳ�ķ����ı��������ȷ��ʾ
	{
		context.m_shape.SetShapeType(msosptTextBox);
		//����ͼ������Ӧ�ı�
		//context.m_opt.AddPropBool(msopt_fFitShapeToText, TRUE);
		context.m_opt.AddPropFix(msopt_dxTextLeft, 0);
		context.m_opt.AddPropFix(msopt_dyTextTop, 0);
		context.m_opt.AddPropFix(msopt_dxTextRight, 0);
		context.m_opt.AddPropFix(msopt_dyTextBottom, 0);
		context.m_opt.AddPropBool(msopt_fFilled, FALSE);
		context.m_opt.AddPropBool(msopt_fLine, FALSE);
		//��չ����
		context.m_optUDef.AddPropFix(ksextopt_IsVirtualShape, 1);
		docu.EnterTextBox(context.m_shape);
	}
	//
	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
	{
		//
		// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
		// ע�⣺
		// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
		// ǰ��Ч�����Ҳ����޸ģ�����
		//
		docu.rowtbl_StartTable(context.IsInlineShape() ? NULL : &tblPos);//��ʼ��������
		//���и߶�
		tblPr.trHeight.put_Exact(_CP(rowIdx, 0).height);
		//�Ƿ��Ǳ�ͷ
		tblPr.tblHeader = (rowIdx < m_szFixRowCol.cy);
		//
		docu.rowtbl_NewRow(&tblPr);
		for(colIdx = 0; colIdx < colCount; colIdx++)
		{
			CTableElement* pEle = _CP(rowIdx, colIdx).pEle;
			if(_CP(rowIdx, colIdx).cp.horiMerge == mso_tcHoriFirstMerge)//ˮƽ��ʼ�ϲ�
			{
				_CP(rowIdx, colIdx).cp.horiMerge = mso_tcHoriNoneMerged;
			}
			else if(_CP(rowIdx, colIdx).cp.horiMerge == mso_tcHoriMerged)
			{
				continue;//��ʵ�����ڵ�Ԫ���ˮƽ�ϲ�
			}
			//б�߱�Ԫ�Ĵ���
			BOOL fOblique;
			BOOL fNeedReverse = FALSE;
			std::vector<KDWDiagonal> vecDiagonal;
			fOblique = AllocaDiagonal(pEle, vecDiagonal, &fNeedReverse);
			//
			if(fOblique)
			{
				ASSERT(vecDiagonal.size() > 0);
				docu.rowtbl_NewCell(_CP(rowIdx, colIdx).cp, &vecDiagonal[0], vecDiagonal.size());//�½���Ԫ��
			}
			else
			{
				docu.rowtbl_NewCell(_CP(rowIdx, colIdx).cp);//�½���Ԫ��
			}
			//
			//����ת��
			//
			KSTextString kstrNil("");
			if(pEle->m_nType == CTableElement::TT_frametext)//frametext
			{
				CFrameText* pft = (CFrameText*)pEle->m_objList.GetHead();
				ASSERT_VALID(pft);
				CTextPool_Export* ptpe = (CTextPool_Export*)pft->c_pTextPool;
				ASSERT_VALID(ptpe);
				ptpe->Export(context.GetWpsExport());
			}
			else if(pEle->m_nType == CTableElement::TT_oblique)//б�߱�Ԫ
			{
				std::vector<CLtxtObj*> vecDiaText;
				for(POSITION pos = pEle->m_objList.GetHeadPosition(); pos;)
				{
					CObject* pObj = pEle->m_objList.GetNext(pos);
					if(pObj->IsKindOf(RUNTIME_CLASS(CLtxtObj)))
					{
						CLtxtObj* pLtxObj = (CLtxtObj*)pObj;
						ASSERT_VALID(pLtxObj);
						vecDiaText.push_back(pLtxObj);
					}
				}
				int DiaTextSize = vecDiaText.size();
				int DiagonalSize = vecDiagonal.size();
				KDWPropBuffer papxE;
				KDWPropBuffer chpxE;
				papxE.AddIstd(context.m_export.AddStyle_DefaultTable());
				papxE.AddPropFix(sprmPJc, mso_jcCenter);
				papxE.AddPropFix(sprmPJcEx, mso_jcCenter);

				if (!fNeedReverse)
				{
					for(int i = 0; i <= DiagonalSize; i++)
					{
						if (i != 0)
							docu.rowtbl_NewDiagonal();
						AddContent(docu, i < DiaTextSize ? vecDiaText[i]->m_string : kstrNil, papxE, chpxE);
					}
				}
				else
				{
					for(int i = DiagonalSize; i >= 0; i--)
					{
						if (i != DiagonalSize)
							docu.rowtbl_NewDiagonal();
						AddContent(docu, i < DiaTextSize ? vecDiaText[i]->m_string : kstrNil, papxE, chpxE);
					}
				}
			}
			else
			{
				if(_CP(rowIdx, colIdx).cp.vertMerge == mso_tcVertMerged)
				{
					KDWPropBuffer papxE;
					KDWPropBuffer chpxE;
					papxE.AddIstd(0);
					docu.NewParagraph(&papxE);
					docu.NewSpan(&chpxE);
					docu.AddContent(0x0d);
				}
				else
				{
					KSTextString* pkstr;
					if(pEle->m_nType == CTableElement::TT_formula ||
						pEle->m_nType == CTableElement::TT_roformula ||
						pEle->m_nType == CTableElement::TT_autodata ||
						pEle->m_nType == CTableElement::TT_roautodata
						)
					{
						//pkstr = &kstr;
						pkstr = &pEle->GetDSPString();//�Ҳ���������
					}
					else
					{
						//pkstr = &pEle->GetSAVString();
						pkstr = &pEle->GetDSPString();
					}
					
					KDWPropBuffer papxE;
					KDWPropBuffer chpxE;
					SetPapxAndChpx(context, pEle, papxE, chpxE);
					AddContent(docu, *pkstr, papxE, chpxE);
				}
			}
		}
		docu.rowtbl_EndTable();//������������
	}
	if(context.IsInlineShape())
	{
		if(!context.GetWpsExport().m_bLastInineTable)
		{
			docu.NewNullPapxParagraph();
			docu.NewNullChpxSpan();
			docu.AddContent(0x0d);
		}
	}
	else
	{
		// �ı������������һ���س�
		docu.NewNullPapxParagraph();
		docu.AddContent(0x0d);
		docu.LeaveTextBox();
	}

//#ifdef _DEBUG
//	extern int getHor(UINT8 x);
//	extern int getVer(UINT8 x);
//	for(rowIdx = 0; rowIdx < rowCount; rowIdx++)
//	{
//		for(colIdx = 0; colIdx < colCount; colIdx++)
//		{
//			CString str, str2;
//			TextStringToString(str, _CP(rowIdx, colIdx).pEle->GetSAVString());
//			str2.Format("%s%c%c ", (LPCSTR)str, getVer(_CP(rowIdx, colIdx).cp.vertMerge), getHor(_CP(rowIdx, colIdx).cp.horiMerge)); 
//			TRACEA((LPCSTR)str2);
//		}
//		TRACEA("\n");
//	}
//#endif
	delete []pcp;
}

//#ifdef _DEBUG
//int getHor(UINT8 x)
//{
//	switch(x)
//	{
//	case mso_tcHoriNoneMerged:
//		return 'h';
//	case mso_tcHoriFirstMerge:
//		return 'H';
//	case mso_tcHoriMerged:
//		return '<';
//	default:
//		ASSERT(FALSE);
//		return ' ';
//	}
//}
//int getVer(UINT8 x)
//{
//	switch(x)
//	{
//	case mso_tcVertNoneMerged:
//		return 'v';
//	case mso_tcVertFirstMerge:
//		return 'V';
//	case mso_tcVertMerged:
//		return '^';
//	default:
//		ASSERT(FALSE);
//		return ' ';
//	}
//}
//#endif

// -------------------------------------------------------------------------
