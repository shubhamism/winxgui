/* -------------------------------------------------------------------------
//	�ļ���		��	ex_barcode.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-25 19:33:40
//	��������	��	
//
//	$Id: ex_barcode.cpp,v 1.9 2005/06/23 02:48:58 liupeng Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_ptobj.h"
#include "../ks_colormodel.h"
#include "../export_tools.h"

////////////////////////////////////////////////////////////////////////////////////
//from WINGDI.h
#define MM_MAX_NUMAXES      16

typedef struct tagDESIGNVECTOR
{
    DWORD  dvReserved;
    DWORD  dvNumAxes;
    LONG   dvValues[MM_MAX_NUMAXES];
} DESIGNVECTOR, *PDESIGNVECTOR, FAR *LPDESIGNVECTOR;

typedef WINGDIAPI HANDLE (WINAPI* KGDI_AddFontMemResourceEx)(PVOID, DWORD, DESIGNVECTOR *, DWORD*);
typedef WINGDIAPI BOOL (WINAPI* KGDI_RemoveFontMemResourceEx)(HANDLE);
/////////////////////////////////////////////////////////////////////////////////////

#include "barcode_fonts.cpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//	�����׼������������ձ�
TCHAR* g_BCSTDName[6] = { "UpcP36Tt", "UpcEP36Tt",	"EanP36Tt", "EanP36Tt", "IntHrP36DlTt",	"C39HrP36DmTt" };

//	�����ֿ����ݶ��ձ�
BYTE* g_BCSTDFontData[6] = {Fonts_BC_UPCA, Fonts_BC_UPCE, Fonts_BC_EAN, Fonts_BC_EAN, Fonts_BC_INTLV, Fonts_BC_C39};
DWORD g_BCSTDFontDataSize[6] = {sizeof(Fonts_BC_UPCA), sizeof(Fonts_BC_UPCE), sizeof(Fonts_BC_EAN), sizeof(Fonts_BC_EAN), sizeof(Fonts_BC_INTLV), sizeof(Fonts_BC_C39)};
//	�����ֿ��ļ�����
//TCHAR* BCTTFFileName[5] = { "bc_Upca",	"bc_Upce",  "bc_Ean", "bc_Intlv", "bc_C39" };

enum { UPC_A = 0, UPC_E, EAN_13, EAN_8, Interleave2_5, Code39 };

HANDLE AddBarCodeTTFont(int nBCSTD)
{
	HANDLE hfont = NULL;
	if (nBCSTD >= UPC_A && nBCSTD <= Code39)
	{
		KDynLib gdi32(__X("gdi32.dll"));
		KGDI_AddFontMemResourceEx gAddFontMemResourceEx = NULL;
		gdi32.GetProc(__X("AddFontMemResourceEx"), (void**)&gAddFontMemResourceEx);
		if (gAddFontMemResourceEx)
		{
			DWORD nFonts = 0;
			DWORD nSize = g_BCSTDFontDataSize[nBCSTD];
			hfont = gAddFontMemResourceEx(g_BCSTDFontData[nBCSTD],
										g_BCSTDFontDataSize[nBCSTD],
										NULL, &nFonts);
			ASSERT(nFonts <= 1);
		}
	}

	return hfont;
}

BOOL RemoveBarCodeTTFont(HANDLE hfont)
{
	BOOL bRet = FALSE;
	if (hfont)
	{
		KDynLib gdi32(__X("gdi32.dll"));
		KGDI_RemoveFontMemResourceEx gRemoveFontMemResourceEx = NULL;
		gdi32.GetProc(__X("RemoveFontMemResourceEx"), (void**)&gRemoveFontMemResourceEx);
		if (gRemoveFontMemResourceEx)
		{
			bRet = gRemoveFontMemResourceEx(hfont);
		}
	}

	return bRet;
}

//---------------------------------------------------------------------------
//	���ܣ�	UPC-A����ת������
//	��ڣ�	strBCID		�����š�
//	���ڣ�	ת��������봮��
//---------------------------------------------------------------------------
CString UPCACvt(const CString& strBCID)
{
	CString strOut = "";
	CString strSrc = strBCID;
	if (strSrc.GetLength() != 11)
		return strOut;
	
	strOut = (char)(atoi(strSrc.Left(1)) + __toascii('#'));	//������λ
	strOut = strOut + strSrc.Mid(1, 5);						//���ɽ�������5λ
	strOut = strOut + "-";                          		//�����зָ���
	for (int i = 6; i < 11; i++)                             //���ɽ�������5λ
		strOut = strOut + (char)(atoi(strSrc.Mid(i, 1)) + __toascii('A'));
	//��������CheckSum
	int nSO = 0;
	int j;
	for (j = 0; j < 11; j += 2)
		nSO = nSO + atoi(strSrc.Mid(j, 1));
	int nSP = 0;
	for (j = 1; j < 11; j += 2)
		nSP = nSP + atoi(strSrc.Mid(j, 1));
	ldiv_t r = ldiv((long)nSP + 3 * nSO, 10);
	int nCheckSum = (r.rem == 0)? 10 : (int)r.rem;
//	nCheckSum = 10 - nCheckSum;
	strOut = strOut + (char)(__toascii('a') + 10 - nCheckSum);//����У��λ
	return strOut;
}

//---------------------------------------------------------------------------
//	���ܣ�	UPC-E����ת������
//	��ڣ�	strBCID		�����š�
//	���ڣ�	ת��������봮��
//---------------------------------------------------------------------------
CString UPCECvt(const CString& strBCID)
{
	CString strOut = "";
	CString strSrc = strBCID;
	if (strSrc.GetLength() != 6)
		return strOut;
   	CString strScuery;
	switch (strBCID[0])
	{
	case '0':	 strScuery = "170000001717"; break;
	case '1':    strScuery = "170000171700"; break;
	case '2':    strScuery = "170017170000"; break;
	case '3':    strScuery = "171700000017"; break;
	case '4':    strScuery = "171700001700"; break;
	case '5':    strScuery = "171700170000"; break;
	case '6':    strScuery = "171717000000"; break;
	case '7':    strScuery = "170000170017"; break;
	case '8':    strScuery = "170017000017"; break;
	case '9':    strScuery = "170017001700"; break;
	default:     strScuery = "000000000000"; break;
	}
	strOut = "!";                                   //���ɿ�ʼ��
	for (int i = 1; i <= 6; i++)                      //����6λ
		strOut = strOut + (char)(__toascii(strSrc[i - 1]) +
		 					atoi(strScuery.Mid(i * 2 - 2, 2)));
	//���¿�ʼ����У��λ
	CString strTmp = "0";
	if (strSrc.Right(1) < "3")
		strTmp = strTmp + strSrc.Left(2) + strSrc.Right(1) + strSrc.Right(4);
	else if (strSrc.Right(1) == "3")
		strTmp = strTmp + strSrc.Left(3) + "0" + strSrc.Right(3);
	else if (strSrc.Right(1) == "4")
		strTmp = strTmp + strSrc.Left(4) + "0" + strSrc.Mid(4, 1);
	else
		strTmp = strTmp + strSrc;
	int nSO = 0;
	int j;
	for (j = 0; j < strTmp.GetLength(); j += 2)
		nSO = nSO + atoi(strTmp.Mid(j, 1));
	int nSP = 0;
	for (j = 1; j < 6; j += 2)
		nSP = nSP + atoi(strTmp.Mid(j, 1));
	     
	ldiv_t r = ldiv((long)nSP+3*nSO, 10);
	int nCheckSum = (r.rem == 0)? 10 : (int)r.rem;
//	nCheckSum = 10-nCheckSum;
	strOut = strOut + (char)(__toascii('a') + 10 - nCheckSum);//����У��λ
	return strOut;
}

//---------------------------------------------------------------------------
//	���ܣ�	Ean-13����ת������
//	��ڣ�	strBCID		�����š�
//	���ڣ�	ת��������봮��
//---------------------------------------------------------------------------
CString Ean13Cvt(const CString& strBCID)
{
	CString strOut = "";
	CString strSrc = strBCID;
	if (strSrc.GetLength() != 12)
		return strOut;
   	CString strScuery;
	switch (strSrc[0])
	{
	case '0':	 strScuery = "000000000000"; break;
	case '1':    strScuery = "000017001717"; break;
	case '2':    strScuery = "000017170017"; break;
	case '3':    strScuery = "000017171700"; break;
	case '4':    strScuery = "001700001717"; break;
	case '5':    strScuery = "001717000017"; break;
	case '6':    strScuery = "001717170000"; break;
	case '7':    strScuery = "001700170017"; break;
	case '8':    strScuery = "001700171700"; break;
	case '9':    strScuery = "001717001700"; break;
	default:     strScuery = "000000000000"; break;
	}
	int nSO = 0;								//	����У��λ
	int i;
	for (i = 1; i < 7; i++)
	    nSO = nSO + atoi(strBCID.Mid(2 * i - 1, 1));
	nSO = nSO * 3;
	int nSP = 0;
	for (i = 1; i < 7; i++)
	    nSP = nSP + atoi(strBCID.Mid(2 * i - 2, 1));
	ldiv_t r = ldiv((long)nSP + nSO, 10);
	nSP = (int)r.rem;
	if (nSP == 0)	    nSP = 10;
	     
	strSrc = strSrc + (char)(__toascii(':') - nSP);	//	������ĩλ
	strOut = strOut + (char)(__toascii('#')		//	������λ
							 + atoi(strSrc.Left(1)));
	strOut = strOut + "!";						//  �����׷ָ���;
	for (i = 1; i < 7; i++)						//  ����ǰ6λ
		strOut = strOut + (char)(__toascii(strSrc[i])
							   + atoi(strScuery.Mid(i * 2 - 2, 2)));
	strOut = strOut + "-";						//	�����зָ���
	for (i = 1; i < 7; i++)						//	����ĩ6λ
	    strOut = strOut + (char)(__toascii('a')
	    					   + atoi(strSrc.Mid(i + 6, 1)));
	strOut = strOut + "! ";      				//	����β�ָ���
	return strOut;
}

//---------------------------------------------------------------------------
//	���ܣ�	Ean-8����ת������
//	��ڣ�	strBCID		�����š�
//	���ڣ�	ת��������봮��
//---------------------------------------------------------------------------
CString Ean8Cvt(const CString& strBCID)
{
	CString strOut = "";
	CString strSrc = strBCID;
	if (strSrc.GetLength() != 7)
		return strOut;
	strOut = "!";                       //������ʼ��־
	strOut = strOut + strSrc.Left(4);   //���ɿ�ʼ4λ
	strOut = strOut + "-";              //�����зָ���
	int i;
	for (i = 4; i < 7; i++)          //���ɺ�3λ
		strOut = strOut + (char)(__toascii('a') + atoi(strSrc.Mid(i, 1)));
	//���¿�ʼ����У��λ
	int nSO = 0;
	for (i = 1; i <= 4; i++)
		nSO = nSO + atoi(strSrc.Mid(2 * i - 2, 1));
	int nSP = 0;
	for (i =1; i<=3; i++)
		nSP = nSP + atoi(strSrc.Mid(2 * i - 1, 1));
	ldiv_t r = ldiv((long)nSP+3*nSO, 10);
	int nCheckSum = (r.rem==0)? 10 : (int)r.rem;
//	char sz[2];	sz[0] = (char)(58-nCheckSum); sz[1] ='\0';
//	strOut = strOut +(char)(__toascii('a')+atoi(sz))+"!";//����У��λ
//	nCheckSum = 10-nCheckSum;
	strOut = strOut + (char)(__toascii('a') + 10 - nCheckSum) + "!";//����У��λ
	return strOut;
}

//---------------------------------------------------------------------------
//	���ܣ�	InterLeave 5/2����ת������
//	��ڣ�	strBCID		�����š�
//	���ڣ�	ת��������봮��
//	ע��InterLeave 5/2 ��׼��֧��
//		atoi(strSrc.Mid(i-1, 2))==92,93,94,95,96,97,98,99������������
//---------------------------------------------------------------------------
CString IntLv25Cvt(const CString& strBCID)
{
	CString strOut = "";
	CString strSrc = strBCID;
	//����InterLeave 5/2 ���Բ����� CheckSum
	div_t r = div(strSrc.GetLength(), 2);
	if (r.rem == 1)	//������ĳ�������������λ��"0"
		strSrc = "0" + strSrc;
	strOut = "!";                       //������ʼλ
	for (int i = 1; i < strSrc.GetLength(); i += 2)
		strOut = strOut + (char)(__toascii('#') + atoi(strSrc.Mid(i - 1, 2)));
	strOut = strOut + "\"";
	return strOut;
}

//---------------------------------------------------------------------------
//	���ܣ�	Code39����ת������
//	��ڣ�	strBCID		�����š�
//	���ڣ�	ת��������봮��
//---------------------------------------------------------------------------
CString Code39Cvt(const CString& strBCID)
{
	CString strOut = "";
	//����Code39���Բ�����CheckSum
	strOut = "*" + strBCID + "*";
	return strOut;
}

int AdjustAngle( int theta, BOOL* pbIsRegular=NULL)
{
	if ( pbIsRegular)
		*pbIsRegular = TRUE;
	if ( abs(theta)<5)
		return 0;
	else if ( abs(theta-1800)<5 || abs(theta+1800)<5)
		return 1800;
	else if ( abs(theta-900)<5 || abs(theta+2700)<5)
		return 900;
	else if ( abs(theta+900)<5 || abs(theta-2700)<5)
		return -900;
	if ( pbIsRegular)
		*pbIsRegular = FALSE;
	return theta;
}

void GetRotatePoint( CPoint* point, const CPoint& center, const int theta)
{
	int atht = AdjustAngle( theta);
	double dx, dy;
	dx =  point->x - center.x;
	dy = -point->y + center.y;
	double tht = atht*PI/1800;
	double cost = cos( tht);
	double sint = sin( tht);
	point->x = center.x + (int)(dx*cost - dy*sint);
	point->y = center.y - (int)(dx*sint + dy*cost);
}

void GetBarCodeLF( char sz[], LPLOGFONT lplf)
{
	lplf->lfEscapement 	= 0;
	lplf->lfOrientation = 0;
	lplf->lfWeight      = FW_NORMAL;
	lplf->lfItalic		= 0;
	lplf->lfUnderline   = 0;
	lplf->lfStrikeOut	= 0;
	lplf->lfCharSet 	= ANSI_CHARSET;
	lplf->lfOutPrecision 	= OUT_DEFAULT_PRECIS;//OUT_STROKE_PRECIS;
	lplf->lfClipPrecision	= CLIP_DEFAULT_PRECIS;//CLIP_STROKE_PRECIS;
	lplf->lfQuality			= DEFAULT_QUALITY;
	lplf->lfPitchAndFamily 	= DEFAULT_PITCH;
	lstrcpy( lplf->lfFaceName, sz);
/*	static char szFN[LF_FACESIZE];
	static LOGFONT lf;
	if ( lstrcmp( szFN, sz) != 0)
	{	g_pPrinter->GetSafeLF( sz, lplf);
		lf = *lplf;
		lstrcpy( szFN, sz);
	}
	else
		*lplf = lf;
*/
}

//---------------------------------------------------------------------------
//	���ܣ�	����ת������
//	��ڣ�	nBCSTD		�����׼��
//			strBCID		�����š�
//	���ڣ�	strDst		ת��������봮��
//			����ֵ��	TRUE:ת���ɹ���
//---------------------------------------------------------------------------
BOOL BarCodeConvert(int nBCSTD, CString& strBCID, CString& strDst)
{
	switch (nBCSTD)
	{
	case UPC_A:
		strDst = ::UPCACvt(strBCID);
		return TRUE;
	case UPC_E:
		strDst = ::UPCECvt(strBCID);
		return TRUE;
	case EAN_13:
		strDst = ::Ean13Cvt(strBCID);
		return TRUE;
	case EAN_8:
		strDst = ::Ean8Cvt(strBCID);
		return TRUE;
	case Interleave2_5:
		strDst = ::IntLv25Cvt(strBCID);
		return TRUE;
	case Code39:
        strDst = ::Code39Cvt(strBCID);
		return TRUE;
	default:
		strDst = CString("");
		return FALSE;
	}
}

EX_SHAPE_API CBarCodeObj_Export::Draw(CDC* pDC, IColorScheme* pICS)
{
	HANDLE HFont = AddBarCodeTTFont(m_nBCSTD);
	if (HFont == NULL)
	{
		return;
    }
	CRect mrct = m_rect;
	CPoint rPnt(mrct.left, mrct.top);
	// liupeng: �ڵ��������Ե�ʱ���Ѿ���������ת���ԣ������ڻ���ͼ��ʱ
	// ����������ת�ˣ������ʹ��ת���Ե���
	// �����ȱ�����ת���ԣ��Ȼ�����������
	int savetheta = m_theta;
	m_theta = 0;
	if ( m_theta != 0)
		::GetRotatePoint( &rPnt, GetObjCenter(), m_theta);
	int nW = mrct.Width();
	int	nH = mrct.Height();
	CPoint lfH( 10, m_nBCFontH);	//	���˸���1���׿հ�
	int nMM1 = lfH.x;
	int nBW = nW;
	int nBH = lfH.y;
	CSize dwExt;
	if ( m_theta == 0 || m_theta == 1800)
	   	dwExt = CSize( nW+6, nBH+6);
  	else
  		dwExt = CSize( nBH+6, nW+6);
	CBitmap  Bmp;
	if ( Bmp.CreateCompatibleBitmap(pDC, dwExt.cx, dwExt.cy))
	{	LOGFONT scrlf;
		GetBarCodeLF( g_BCSTDName[m_nBCSTD], &scrlf);
		scrlf.lfHeight = -nBH;
		scrlf.lfWidth  = 0;
	    scrlf.lfWeight = FW_NORMAL;
		scrlf.lfEscapement = m_theta;
		CFont scrfont;
		scrfont.CreateFontIndirect(&scrlf);
		CDC dcBits;
		dcBits.CreateCompatibleDC( pDC);
		//	��ʼ��λͼ�ı���
		CBitmap* pOldBmp;
		CString str;
		pOldBmp = dcBits.SelectObject( &Bmp);
		CBrush brush( KColorModel::IndexToRef(m_logbrush.lbColor, pICS));//	�趨���ˢ
		dcBits.FillRect( CRect(0,0,dwExt.cx,dwExt.cy), &brush);
		//	�·�����������ڸı���ʾ����ʱ
		//dcBits.BitBlt(0, 0, dwExt.cx, dwExt.cy, &dcBits, 0, 0, WHITENESS);//��ɫ
		//	��ʼһ��������ʾ,ѡ������������豸������
		CFont* pOldScrFont = dcBits.SelectObject(&scrfont);
	    ::BarCodeConvert(m_nBCSTD, m_strBCID, str);
		dcBits.SetBkMode( TRANSPARENT);
		if ( m_theta == 900)
			dcBits.TextOut( 0, nW-nMM1, str);	
		else if ( m_theta == 2700)
			dcBits.TextOut( nBH, nMM1, str);	
		else if ( m_theta == 0)
			dcBits.TextOut( nMM1, 0, str);	
		else	//	 theta == 1800
			dcBits.TextOut( nW-nMM1, nBH, str);	
		
		dcBits.SelectObject(pOldScrFont);
		scrfont.DeleteObject();

		int dd = nBH/2;
		//	λ�鴫��
		COLORREF oldTxtClr = pDC->SetTextColor( RGB(0,0,0));
		if ( m_theta == 900)
		{	if ( nH < nBH)
				pDC->BitBlt(rPnt.x, rPnt.y-nBW, nH+1, nW, &dcBits, nBH-nH+1, 0, SRCCOPY);
			else
			{	pDC->BitBlt(rPnt.x, rPnt.y-nBW, nBH+1, nBW, &dcBits, 0, 0, SRCCOPY);
				if ( nH > nBH)
				{	int nR = rPnt.x+nH;
					rPnt.x += dd;
					while ( rPnt.x+nBH-5 < nR)
					{	pDC->BitBlt(rPnt.x, rPnt.y-nBW, nBH+1, nBW, &dcBits, 5, 0, SRCCOPY);
						rPnt.x += dd;
					}
					pDC->BitBlt(nR-nBH+5, rPnt.y-nBW, nBH, nBW, &dcBits, 5, 0, SRCCOPY);
				}
			}
		}
		else if ( m_theta == 2700)
		{	if ( nH < nBH)
				pDC->BitBlt(rPnt.x-nH, rPnt.y, nH+1, nW, &dcBits, 0, 0, SRCCOPY);
			else
			{	pDC->BitBlt(rPnt.x-nBH, rPnt.y, nBH+1, nBW, &dcBits, 0, 0, SRCCOPY);
				if ( nH > nBH)
				{	int nL = rPnt.x-nH;
					rPnt.x -= dd;
					while ( rPnt.x-nBH+5 > nL)
					{	pDC->BitBlt(rPnt.x-nBH+5, rPnt.y, nBH-5, nBW, &dcBits, 0, 0, SRCCOPY);
						rPnt.x -= dd;
					}
					pDC->BitBlt(nL, rPnt.y, nBH-5, nBW, &dcBits, 0, 0, SRCCOPY);
				}
			}
		}
		else if ( m_theta == 0) 
		{	int nX = mrct.left;
			int nY = mrct.top;
			if ( nH < nBH)
				pDC->BitBlt(nX, nY, nBW, nH+1, &dcBits, 0, nBH-nH+1, SRCCOPY);
			else
			{	pDC->BitBlt(nX, nY, nBW, nBH+1, &dcBits, 0, 0, SRCCOPY);
				if ( nH > nBH)
				{	nY += dd;
					while ( nY+nBH-5 < mrct.bottom)
					{	pDC->BitBlt(nX, nY, nBW, nBH, &dcBits, 0, 5, SRCCOPY);
						nY += dd;
					}
					pDC->BitBlt(nX, mrct.bottom-nBH+5, nBW, nBH, &dcBits, 0, 5, SRCCOPY);
				}
			}
		}
		else	//	 theta == 1800
		{	int nX = mrct.left;
			int nY = mrct.top;
			if ( nH < nBH)
				pDC->BitBlt(nX, nY, nBW, nH+1, &dcBits, 0, 0, SRCCOPY);
			else
			{	pDC->BitBlt(nX, nY+nH-nBH, nBW, nBH+1, &dcBits, 0, 0, SRCCOPY);
				if ( nH > nBH)
				{	int nT = nY + nH - dd;
					while ( nT-nBH+5 > mrct.top)
					{	pDC->BitBlt(nX, nT-nBH+5, nBW, nBH-5, &dcBits, 0, 0, SRCCOPY);
						nT -= dd;
					}
					pDC->BitBlt(nX, nY, nBW, nBH-5, &dcBits, 0, 0, SRCCOPY);
				}
			}
		}
		pDC->SetTextColor(oldTxtClr);
		dcBits.SelectObject(pOldBmp);
		Bmp.DeleteObject();
	}

	if (HFont)
		RemoveBarCodeTTFont(HFont);
	
	m_theta = savetheta;
}

EX_SHAPE_API CBarCodeObj_Export::ConvertShape(CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	dc.m_hAttribDC = dc.m_hDC;
	Draw(&dc, NULL);
	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, context);
}

// -------------------------------------------------------------------------
// $Log: ex_barcode.cpp,v $
// Revision 1.9  2005/06/23 02:48:58  liupeng
// *** empty log message ***
//
// Revision 1.8  2005/01/07 03:51:08  wanli
// *** empty log message ***
//
// Revision 1.7  2005/01/07 03:20:46  shenjiazheng
// *** empty log message ***
//
// Revision 1.6  2005/01/06 02:54:13  wanli
// *** empty log message ***
//
// Revision 1.5  2005/01/05 10:10:06  xushiwei
// ����������Ĳ��԰�����
//
