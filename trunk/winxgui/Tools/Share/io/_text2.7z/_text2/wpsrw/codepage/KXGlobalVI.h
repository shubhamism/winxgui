// KXGlobalVI.h: interface for the KXGlobalVI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KXGLOBALVI_H_INCLUDED_)
#define AFX_KXGLOBALVI_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class KXScriptSheet;

class KXGlobalVI
{
public:
	KXScriptSheet*	m_pScriptSheet;
	TEXTWORD		m_Default_Outword;
	
public:
	KXGlobalVI(KXScriptSheet* pScriptSheet, TEXTWORD Default_Outword)
	{
		m_pScriptSheet = pScriptSheet;
		m_Default_Outword = Default_Outword;
	}
};

/*@@todo
class KXWpsView;
class KXScriptSheet;
class KXGlobalVI
{
public:
	KXGlobalVI(KXScriptSheet* pScriptSheet, TEXTWORD Default_Outword)
	{	m_pScriptSheet = pScriptSheet;
	m_Default_Outword = Default_Outword;
	}
	virtual ~KXGlobalVI(){};
	
public:
	KXScriptSheet*	m_pScriptSheet;
	TEXTWORD		m_Default_Outword;
public:
	// virtual function
	virtual BOOL IsThereAnAO(KXWpsView* pView, LPCTEXTWORD pTextOrg, int nNumOfChars) { ASSERT(FALSE); return FALSE; }
	virtual int GetEscSeqLength (LPCTEXTWORD pEscSeq) { ASSERT(FALSE); return 0; }
	virtual void Draw_DoJustification (KXWpsView* pView, DWORD dwExt, LPCTEXTWORD pTextOrg,
		DWORD dwLineExt, LPINT lpnPosChn, LPINT lpnPosEng,
		int nNumOfChars, int nNumOfGaps, BOOL bLineHead) { ASSERT(FALSE); }
	virtual void Draw_PosRelToAbs(KXWpsView*		pView,
		LPINT			lpnPosChn,
		LPINT			lpnPosEng,
		int			&nLineExt,
		int			&nOrgChn,
		int			&nOrgEng,
		BOOL			bLineHead,
		int			nNumOfChars,
		LPCTEXTWORD	pTextOrg) { ASSERT(FALSE); }
	
	virtual int NumOfGaps(LPCTEXTWORD pTextOrg, int nNumOfChars, BOOL bIsLastLine) { ASSERT(FALSE); return 0; }
	
	//(�����Ի����� [wxb 2002-4-25]
	virtual DWORD GetCharLang(TEXTWORD) = 0;
	virtual LPCWSTR GBKToUnicode(LPCSTR) = 0;
	//)
};
*/

#endif // !defined(AFX_KXGLOBALVI_H_INCLUDED_)
