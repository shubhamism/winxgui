/* -------------------------------------------------------------------------
//	�ļ���		��	ks_colormodel_impl.h
//	������		��	������
//	����ʱ��	��	2002-5-3 13:33:57
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __KS_COLORMODEL_IMPL_H__
#define __KS_COLORMODEL_IMPL_H__

#include "ks_colormodel.h"

///////////////////////////////////////////////////////////////////////////////
//ColorScheme
class KColorScheme : public IColorScheme
{
public:
	KColorScheme();
	virtual ~KColorScheme();

public:
	//IUnknown
	STDMETHOD (QueryInterface)(const IID& iid, void** ppv);
	STDMETHOD_(ULONG, AddRef)();
	STDMETHOD_(ULONG, Release)();
		
	//IColorScheme
	STDMETHOD (CreateCS)(LONG nCount);
	STDMETHOD (GetColorCount)(LONG& nCount);
	
	STDMETHOD (GetColor)(const LONG index, COLORREF& color);	
	STDMETHOD (SetColor)(const LONG index, const COLORREF& color);

	STDMETHOD (SetColors)(IColorScheme* pICSSrc,
								LONG nToStart = 0, LONG nToCount = -1);
	
	STDMETHOD (GetColors)(COLORREF* pColors, const LONG nColorCount);
	STDMETHOD (SetColors)(const COLORREF* pColors, const LONG nColorCount);
	
	STDMETHOD (Clone)(IColorScheme** ppICSDest);
	
	// == ->S_OK, != ->S_FALSE
	STDMETHOD (Compare)(IColorScheme* pICSSrc);
	
protected:	
	LONG		m_nColorCount;
	COLORREF*	m_pColors;
	
private:
	ULONG m_nRef;
};

#endif /* __KS_COLORMODEL_IMPL_H__ */
