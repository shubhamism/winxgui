/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wppsound.h
//	������		��	liupeng
//	����ʱ��	��	2005-4-2 15:49:48
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if defined(WPP_ONLY)
#include <draw/wpsobj.h>
#include "../draw/ex_ptobj.h"

#include "ex_wppdoc.h"
#include "ex_wppaction.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

inline LONG WPS2XML_Action(OBJACTIONTYPE ntype)
{
	LONG nActionType = PI_NoAction;
	switch(ntype)
	{
		case enumObjAction_None:	nActionType = PI_NoAction;break;
		case enumObjAction_PageJump: nActionType = PI_JumpAction;break;
		case enumObjAction_DocJump:	 nActionType = PI_HyperlinkAction;break;
		case enumObjAction_Run:		 nActionType = PI_RunProgramAction;break;
		case enumObjAction_HLink:	 nActionType = PI_HyperlinkAction;break;
		case enumObjAction_Email:	 nActionType = PI_NoAction;break;
		case enumObjAction_Comment:	 nActionType = PI_NoAction;break;
	}
	
	return nActionType;
}

inline int FormatJUMP(CString& jmpStr)
{
	if (jmpStr == _T("WPP_N"))
		return PI_NextSlide;
	else if (jmpStr == _T("WPP_P"))
		return PI_PreviousSlide;
	else if (jmpStr == _T("WPP_F"))
		return PI_FirstSlide;
	else if (jmpStr == _T("WPP_L"))
		return PI_LastSlide;
	else if (jmpStr == _T("WPP_S"))
		return PI_LastSlideViewed;
	else if (jmpStr == _T("WPP_E"))
		return PI_EndShow;
	return PI_NoJump;
}

inline INT ParseSlideIndex(CString& jmpStr)
{
	ASSERT(jmpStr.Mid(0, 5) == _T("WPP_D"));
	INT res =  atoi((LPCSTR)jmpStr.Mid(6, jmpStr.GetLength() - 6));
	if (!res)	ASSERT(!"slide id ��������!");
	return res;
}

inline CString JmpType2HyperSubStr(int nJmpType)
{
	switch(nJmpType) {
	case PI_NextSlide:
		return CString(_T("1,-1,NEXT"));
	case PI_PreviousSlide:
		return CString(_T("1,-1,PREV"));
	case PI_FirstSlide:
		return CString(_T("1,-1,FIRST"));
	case PI_LastSlide:
		return CString(_T("1,-1,LAST"));
	default:
		return CString(_T(""));
	}
}

inline CString JmpType2HyperStr(int nJmpType)
{
	switch(nJmpType) {
	case PI_NextSlide:
		return CString(_T("NEXT"));
	case PI_PreviousSlide:
		return CString(_T("PREV"));
	case PI_FirstSlide:
		return CString(_T("FIRST"));
	case PI_LastSlide:
		return CString(_T("LAST"));
	default:
		return CString(_T(""));
	}
}

HRESULT ExportShapeAction(CWPSObj* pObj, CWPPDocContext* context,
						  KPPTClientData* client, BOOL bIsPlaceHolder,
						  KPPTClientTextBox* pBox, INT nTextStart, INT nTextEnd)
{
	PSR_InteractiveInfoAtom actionMouseDown;
	memset(&actionMouseDown, 0, sizeof(actionMouseDown));
	BSTR pstrMDRun = NULL;
	BOOL bMDHasSound = FALSE;
	{
		int nType = WPS2XML_Action(pObj->GetLBObjActionType());
		actionMouseDown.LinkTo = PI_None;
		actionMouseDown.ActionType = nType;
		if (pObj->GetLBPlaySoundFlag())
		{
			bMDHasSound = TRUE;
			INT nSoundId = 0;
			CString strSoundName;
			pObj->GetLBPlaySoundData(nSoundId, strSoundName);
			BSTR strSound = strSoundName.AllocSysString();
			INT nRef = 0;
			context->AddSound(nSoundId, strSound, nRef);
			actionMouseDown.SoundRef = nRef;
			SysFreeString(strSound);
		}
		if (nType != PI_NoAction)
		{
			CString jmpStr;
			pObj->GetLBObjAction(jmpStr);
			switch(nType) 
			{
			case PI_JumpAction:
				{
					actionMouseDown.LinkTo = 0;
					actionMouseDown.Jump = FormatJUMP(jmpStr);
					if (actionMouseDown.Jump == PI_NoJump)
					{
						INT nSlideID = ParseSlideIndex(jmpStr);
						ASSERT(nSlideID);
						actionMouseDown.ActionType = PI_HyperlinkAction;
						actionMouseDown.LinkTo = PI_Slide;
						actionMouseDown.Jump = PI_NextSlide;
						context->AddHyperLinkDelay(actionMouseDown.ExHyperlinkID, nSlideID);
					}
					else if (actionMouseDown.Jump == PI_LastSlideViewed)
					{
						actionMouseDown.LinkTo = PI_None;
					}
					else if (actionMouseDown.Jump == PI_EndShow)
					{
						actionMouseDown.LinkTo = PI_None;
					}
					else
					{
						CString strHyper = JmpType2HyperStr(actionMouseDown.Jump);
						CString strSub = JmpType2HyperSubStr(actionMouseDown.Jump);
						context->AddHyperLink(actionMouseDown.ExHyperlinkID,
							&strHyper, NULL, &strSub);
					}
				}
				break;
			case PI_RunProgramAction:
				actionMouseDown.LinkTo = 0;
				pstrMDRun = jmpStr.AllocSysString();
				break;
			case PI_HyperlinkAction:
				if (pObj->GetLBObjActionType() == enumObjAction_DocJump)
				{
					actionMouseDown.LinkTo = PI_OtherFile;
					actionMouseDown.Jump = PI_EndShow;
				}
				else
					actionMouseDown.LinkTo = PI_URL;
				context->AddHyperLink(actionMouseDown.ExHyperlinkID,&jmpStr,&jmpStr);
				break;
			default:
				ASSERT(!"�����ܵ�������!");
				break;
			}
		}
	}

	PSR_InteractiveInfoAtom actionMouseMove;
	memset(&actionMouseMove, 0, sizeof(actionMouseMove));
	BSTR pstrMMRun = NULL;
	BOOL bMmHasSound = FALSE;
	{
		int nType = WPS2XML_Action(pObj->GetMoveObjActionType());
		actionMouseMove.LinkTo = PI_None;
		actionMouseMove.ActionType = nType;
		if (pObj->GetMovePlaySoundFlag())
		{
			bMmHasSound = TRUE;
			INT nSoundId = 0;
			CString strSoundName;
			pObj->GetMovePlaySoundData(nSoundId, strSoundName);
			BSTR strSound = strSoundName.AllocSysString();
			INT nRef = 0;
			context->AddSound(nSoundId, strSound, nRef);
			actionMouseMove.SoundRef = nRef;
			SysFreeString(strSound);
		}
		if (nType != PI_NoAction)
		{
			CString jmpStr;
			pObj->GetMoveObjAction(jmpStr);
			
			switch(nType) 
			{
			case PI_JumpAction:
				{
					actionMouseMove.LinkTo = 0;
					actionMouseMove.Jump = FormatJUMP(jmpStr);
					if (actionMouseDown.Jump == PI_NoJump)
					{
						INT nSlideID = ParseSlideIndex(jmpStr);
						actionMouseMove.ActionType = PI_HyperlinkAction;
						actionMouseMove.LinkTo = PI_Slide;
						actionMouseMove.Jump = PI_NextSlide;
						context->AddHyperLinkDelay(actionMouseMove.ExHyperlinkID, nSlideID);
					}
					else if (actionMouseMove.Jump == PI_LastSlideViewed)
					{
						actionMouseMove.LinkTo = PI_None;
					}
					else if (actionMouseMove.Jump == PI_EndShow)
					{
						actionMouseMove.LinkTo = PI_None;
					}
					else
					{
						CString strHyper = JmpType2HyperStr(actionMouseMove.Jump);
						CString strSub = JmpType2HyperSubStr(actionMouseMove.Jump);
						context->AddHyperLink(actionMouseMove.ExHyperlinkID,
											&strHyper, NULL, &strSub);
					}
				}
				break;
			case PI_RunProgramAction:
				actionMouseMove.LinkTo = PI_URL;
				actionMouseMove.Jump = PI_NextSlide;
				pstrMMRun = jmpStr.AllocSysString();
				break;
			case PI_HyperlinkAction:
				if (pObj->GetLBObjActionType() == enumObjAction_DocJump)
				{
					actionMouseMove.LinkTo = PI_OtherFile;
					actionMouseMove.Jump = PI_EndShow;
				}
				else
					actionMouseMove.LinkTo = PI_URL;
				context->AddHyperLink(actionMouseMove.ExHyperlinkID, &jmpStr, &jmpStr);
				break;
			default:
				ASSERT(!"�����ܵ�������!");
				break;
			}
		}
	}

	if ((actionMouseDown.ActionType != PI_NoAction) || bMDHasSound ||
		(actionMouseMove.ActionType != PI_NoAction) || bMmHasSound)
	{
		if (!bIsPlaceHolder)
		{
			KPPTActionInfo* pInfo = new KPPTActionInfo();
			pInfo->SetMouseClickActionInfo(&actionMouseDown, -1, -1, pstrMDRun);
			pInfo->SetMouseOverActionInfo(&actionMouseMove, -1, -1, pstrMMRun);
			client->SetActionInfo(pInfo);
		}
		else
		{
			ASSERT(pBox);
			KPPTActionInfo* pInfo = pBox->AddTextActionInfo();
			pInfo->SetMouseClickActionInfo(&actionMouseDown, nTextStart, nTextEnd, pstrMDRun);
			pInfo->SetMouseOverActionInfo(&actionMouseMove, nTextStart, nTextEnd, pstrMMRun);
		}
	}
	return S_OK;
}
#endif