/* -------------------------------------------------------------------------
//	�ļ���		��	ptrect.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-25 11:51:48
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CRectObj, CPTObj, 0xA0 | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

void CRectObj::Serialize_97(CArchive& ar)
{
	CPTObj::Serialize_97(ar);

	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{	__int16 wTemp;
		ar >> wTemp;	m_nrectobjShape = (int)wTemp;
		ar >> wTemp;	m_nellipseArcType = (int)wTemp;
		ar >> wTemp;	m_roundness.x = wTemp;
		ar >> wTemp;	m_roundness.y = wTemp;
	}
	CWPSObj::SerializeObjType(ar);
}

void CRectObj::Serialize_98(CArchive& ar)
{
	CPTObj::Serialize_98(ar);

	if (ar.IsStoring())
	{
		ar << m_nrectobjShape;
		ar << m_nellipseArcType;
		ar << m_roundness;
		if (m_nrectobjShape == cube)
		{
			ar << m_nScale;
			ar << m_nCubeView; 
		}
		if (m_nrectobjShape == cylinder || m_nrectobjShape == pieColumn)
			ar << m_nScale;
	}
	else
	{	ar >> m_nrectobjShape;
		ar >> m_nellipseArcType;
		ar >> m_roundness;
		if (m_nrectobjShape == cube)
		{	ar >> m_nScale;
			ar >> m_nCubeView; 
		}
		if (m_nrectobjShape == cylinder || m_nrectobjShape == pieColumn)
			ar >> m_nScale;
	}
	CWPSObj::SerializeObjType(ar);
}

void CRectObj::Serialize_01(CArchive& ar)
{
	CPTObj::Serialize_01(ar);

	if (ar.IsStoring())
	{
		ar << m_nrectobjShape;
		ar << m_nellipseArcType;
		ar << m_roundness;
		if (m_nrectobjShape == cube)
		{
			ar << m_nScale;
			ar << m_nCubeView; 
		}
		if (m_nrectobjShape == cylinder || m_nrectobjShape == pieColumn)
			ar << m_nScale;
	}
	else
	{	ar >> m_nrectobjShape;
		ar >> m_nellipseArcType;
		ar >> m_roundness;
		if (m_nrectobjShape == cube)
		{	ar >> m_nScale;
			ar >> m_nCubeView; 
		}
		if (m_nrectobjShape == cylinder || m_nrectobjShape == pieColumn)
			ar >> m_nScale;
	}
	CWPSObj::SerializeObjType(ar);
}

// -------------------------------------------------------------------------
