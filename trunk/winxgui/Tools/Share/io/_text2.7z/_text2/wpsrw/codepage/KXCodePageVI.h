// KXCodePageVI.h: interface for the KXCodePageVI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KXCODEPAGEVI_H_INCLUDED_)
#define AFX_KXCODEPAGEVI_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//ȫ���ַ�
enum QJ_CHAR_TYPE
{
	QJ_SPACE			= 1,	//ȫ�ǿո�
	QJ_BULLET			= 2,	//ȫ��BULLET�ַ�"��"
	QJ_INTEGRAL			= 3,	//ȫ�ǻ��ַ�"��"
	QJ_COMMA			= 4,	//"��"
	QJ_SBRACKET_LEFT	= 5,	//"��"

	QJ_SBRACKET_RIGHT	= 6,	//"��"
	QJ_FULL_STOP		= 7,	//"��"
	QJ_RBRACKET_LEFT	= 8,	//"��"
	QJ_RBRACKET_RIGHT	= 9,	//"��"
	QJ_SIMI_STOP		= 10,	//"��"

	QJ_QUESTION			= 11,	//"��"
	QJ_SUSPENSION		= 12,	//"��"
	QJ_SEMICOLON		= 13,	//"��"
	QJ_COLON			= 14,	//"��"

	QJ_SQUOTATION_LEFT	= 15,	//��
	QJ_SQUOTATION_RIGHT	= 16,	//��
	QJ_DQUOTATION_LEFT	= 17,	//��
	QJ_DQUOTATION_RIGHT	= 18,	//��
	QJ_SQUARE			= 19,	//"��"
};

#define MAXPUNCTUATION	256
#define WORDPOSITION int

class KXCharWidthTbl;
class KXTextTool;
class KXTextKernel;
class KXWpsView;

class KXCodePageVI
{
public:
	virtual TEXTWORD GB18030ToUniChar(TEXTWORD twChar) = 0;
	virtual TEXTWORD UniCharToGB18030(TEXTWORD twChar) = 0;
	virtual TEXTWORD GetFirstWord(LPCTSTR lpsz, WORDPOSITION& wpos) = 0;
	virtual TEXTWORD GetNextWord(LPCTSTR lpsz, WORDPOSITION& wpos) = 0;
	
	//��Ԫ���±���ʾ��������
	virtual BOOL FilterSupSub(LPCTEXTWORD lptwText,
				  LPWSTR lpszEng, LPWSTR lpszChn,
				  int& nFilteredEng, int& nFilteredChn,
				  int nMode) = 0;
};

/*@@todo
//ע: ���ӿ��ྭ�������Ի����� [wxb 2002-4-25]
class KXCodePageVI
{
public:
	KXCodePageVI() {};
	virtual ~KXCodePageVI() {};

public:
	// virtual interface
	virtual int GetNextTabPara (int nPos, KXTextTool* pTextTool, UINT uFlag = GTP_POS) = 0;
	virtual BOOL IsThereATab(LPCTEXTWORD pTextOrg, int nNumOfChars) = 0;
	virtual void CP_Draw_MakeUp(KXWpsView* pView,		CDC* pDC, 
							 LPWSTR lpszTextChn,	LPWSTR lpszTextEng,
							 LPINT	lpnPosChn,		LPINT lpnPosEng,
							 int& nOrgChn,			int& nOrgEng,
							 int& nLineExt,
							 KXCharWidthTbl* pCharWidthTblEng,
							 KXCharWidthTbl* pCharWidthTblChn,
							 LPCUNIT_VALUE pTrack,
							 LPCTEXTWORD pTextOrg,
							 int nNumOfChars,
							 BOOL bLineHead,		BOOL bLineTail,
							 BOOL bLastLineOfPara,
							 WORD wAlignment,
							 DWORD dwLineExt,
							 BOOL bCS0_Spc,
							 BOOL bCS0_Tab,
							 KXTextTool *pTextTool,
							 int nPageOrient,
							 BOOL bSS = FALSE,
							 KXTextKernel *pTextLine = NULL,
							 CUIntArray *parErrWord = NULL,
							 CUIntArray *parErrwordPos = NULL) = 0;
	virtual BOOL CP_Draw_Init(LPBYTE& lpBuf, int nBufSize, LPWSTR& lpszTextChn, LPWSTR& lpszTextEng,
							LPINT& lpnPosChn, LPINT& lpnPosEng) = 0;
	virtual BOOL CP_ExtTextOut(HDC hDC, int x, int y, UINT nOptions, LPCRECT lpRect,
							LPCWSTR lpszString, LPINT lpDxWidths, BOOL bIsChinese,
							BOOL bPrinting=FALSE) = 0;
	virtual int CP_KSTextStringToTextOutBuf(LPWSTR lpOutBuf, int nOutLen, LPCTEXTWORD pText, int nLen) = 0;
	virtual TEXTWORD GetFirstWord(LPCTSTR lpsz, WORDPOSITION& wpos) = 0;
	virtual TEXTWORD GetNextWord(LPCTSTR lpsz, WORDPOSITION& wpos) = 0;
	virtual TEXTWORD GB18030ToUniChar(TEXTWORD twChar) = 0;
	virtual TEXTWORD UniCharToGB18030(TEXTWORD twChar) = 0;
	virtual const DWORD* GetUni2Gb18030Table() = 0;
	virtual void CP_FontsFilter(CPtrArray* pArray) = 0;
	virtual BOOL IsCJKFont (const LPLOGFONT lplf,
							const LPTEXTMETRIC lptm,
							int nFontType) = 0;
	//
	virtual BOOL LoadCPString(CString& str, DWORD dwStrID) = 0;
	virtual CString LoadCPString(DWORD dwStrID) = 0;
	virtual BOOL IsChar(TEXTWORD twWord) = 0;
	virtual BOOL AfxFormatStr(NUM_FORMAT format, int nNum, LPTSTR pBuffer, int nBufLen, DWORD dwLanguageVer = defCHINESESIM_VERSION) = 0;
	virtual int GetBulletExtention(int nStyle, LPTSTR pBuffer,
					   KXCharWidthTbl* pCharWidthTblEng,
					   KXCharWidthTbl* pCharWidthTblChn,
					   int nLenPerLevel, BOOL bGetChar = TRUE) = 0;
	virtual int GetAutoNumberExtention(int nStyle, int nValue, LPTSTR pBuffer,
					   KXCharWidthTbl* pCharWidthTblEng,
					   KXCharWidthTbl* pCharWidthTblChn,
					   int nLenPerLevel) = 0;
	virtual BOOL QueryLineBreak(const TEXTWORD* pChar) = 0;

	//�ֽ������ֻ������ڴ��ͷ�
	virtual BOOL CP_Draw_CleanUp(LPBYTE& lpBuf, LPWSTR& lpszTextChn, LPWSTR& lpszTextEng,
							LPINT& lpnPosChn, LPINT& lpnPosEng) = 0;
	
	//�ֽ������ֻ�����������غ���
	virtual LPWSTR  CloneTextBuffer(LPCWSTR lpszSrc) = 0;
	virtual int CopyTextBuffer(LPWSTR lpszDest, LPCWSTR lpszSrc) = 0;
	virtual BOOL FreeCloneBuffer(LPWSTR& lpszCloneText) = 0;

	//��Ԫ���±���ʾ��������
	virtual BOOL FilterSupSub(LPCTEXTWORD lptwText,
				  LPWSTR lpszEng, LPWSTR lpszChn,
				  int& nFilteredEng, int& nFilteredChn,
				  int nMode) = 0;

	//��ʾ���ֿ���ʾ��������
	virtual BOOL GetCharOffset(int nIndex, 
				   LPCWSTR lpszTextChn,	LPCWSTR lpszTextEng,
				   int nOrgChn,			int nOrgEng,
				   LPINT lpnPosChn,		LPINT lpnPosEng,
				   int& nOff1,			int& nOff2,
				   BOOL bSetSpace,		BOOL& bIsChn,
				   LPWSTR& lpszNewChn,	LPWSTR& lpszNewEng) = 0;

	//�����Ű���ĺ����Լ���غ���
	virtual	BOOL LineTailProcess(LPTEXTWORD& pCurChar,
								 LPCTEXTWORD pFrom,
								 LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 BOOL bSS = FALSE) = 0;
	virtual BOOL LineHeadProcess(LPTEXTWORD& pCurChar,
								 LPCTEXTWORD pFrom, 
								 LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 KXCharWidthTbl* pCharWidthTblEng,
								 KXCharWidthTbl* pCharWidthTblChn,
								 BOOL		 bIsFirstLine, 
								 BOOL&		 bGotoPrevSenEnd, 
								 BOOL bSS = FALSE) = 0;
	virtual int LineProcess(
				LPTEXTWORD&			pCurChar,
				LONG&				dwLineWidth,
				BOOL				bIsLineHead,
				TextLineMode		LineMode,
				LONG				dwLegalWidth,
				KXCharWidthTbl*		pCharWidthTblEng,
				KXCharWidthTbl*		pCharWidthTblChn,
				LPCUNIT_VALUE		lpCharTrack,
				int					nPageOrient,
				BOOL				bSS	= FALSE,
				int					nSSOrientOffset = 0,
				KXTextTool*			pTextTool = NULL,
				int*				pnMinLineWid = NULL) = 0;
	virtual LPCTEXTWORD PrevChar(LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 LPCTEXTWORD pWord) = 0;
	virtual LPCTEXTWORD NextChar(LPCTEXTWORD pBegin,
								 LPCTEXTWORD pEnd,
								 LPCTEXTWORD pWord) = 0;
	virtual BOOL IsNonHeadPuncs(TEXTWORD wValue) = 0;
	virtual BOOL IsNonTailPuncs(TEXTWORD wValue) = 0;

	//�Ű����������ýӿ�
	virtual BOOL GetOptions(LPSTR lpszBuffer, UINT nBufferSize) = 0;
	virtual int SetOptions(LPCSTR lpszBuffer) = 0;

#ifdef _VER_MENGWEN
	// �Զ��������ӿ�
	virtual void ABCode_Draw_Init(LPSTR, LPSTR&, LPWORD&, LPINT&, LPINT&) = 0;
	virtual void ABCode_Draw_MakeUp(KXWpsView*, LPSTR, int, int*, LPCHARGLYPHMETRICS, 
				int&, int&, LPSTR, LPWORD, LPINT, LPINT, int&, int&, int&, BOOL=TRUE) = 0;
	virtual void ABCode_Draw_CleanUp(LPSTR&, LPWORD&, LPINT&, LPINT&) = 0;

	// �������е���Ӣ�ķֿ��Ű����
	virtual void GetTextExtAndPos(KXTextKernel* pTextLine, ESCSEQDATA* pED, BOOL bIsOutputing) = 0;
#endif // _VER_MENGWEN

	virtual BOOL IsMengWenCatalog(TEXTWORD dwChar, int nCharType = 1) = 0;
};

//�����Ի������������ַ����ȱ��ӿ�
class KXCharWidthTbl
{
public:
	virtual BOOL Use() = 0;
	virtual BOOL Discard() = 0;
	virtual int  GetTextWordWidth(TEXTWORD wChar, DWORD dwLang = CL_NONE)const = 0;
};

//�Զ���һ��{}�ڲ�ʵ�� CharWidthTbl �� Use �� Discard
//ʹ�÷�����
//   ��{}��һ������һ�� KSAutoUseCharTbl ���͵���ʱ����
class KSAutoUseCharTbl
{
private:
	KXCharWidthTbl* m_pCharWidthTbl;
public:
	KSAutoUseCharTbl(KXCharWidthTbl* pTbl)
	{
		ASSERT(pTbl);
		m_pCharWidthTbl = pTbl;
		pTbl->Use();
	}
	~KSAutoUseCharTbl()
	{
		m_pCharWidthTbl->Discard();
	}
};*/

#endif // !defined(AFX_KXCODEPAGEVI_H_INCLUDED_)
