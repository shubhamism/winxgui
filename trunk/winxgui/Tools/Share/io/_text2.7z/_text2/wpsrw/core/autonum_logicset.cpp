/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_logicset.cpp
//	������		��	����
//	����ʱ��	��	2004-11-10 5:16:56 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __AUTONUM_ATOM_H
#include "autonum_atom.h"
#endif

#ifndef __TEXTPOOL_H__
#include "textpool.h"
#endif

#ifndef __CTRLCODE_H__
#include "ctrlcode.h"
#endif

#ifndef __CTRLCODETOOL_H__
#include "ctrlcodetool.h"
#endif

//#include "autonum_logicset.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CCtrlCodeTool CtrlCodeTool;

// -------------------------------------------------------------------------

/////////////////////////////////////////////////////
// ������	��		GetAutoNumRefData
// ����		��		ȡ�εı����������(group + level)
/////////////////////////////////////////////////////
const AUTONUMPARAREF* CParagraph::GetAutoNumRefData()
{
	CObList* pList	= m_pAttribList;
	if (!pList)
		return NULL;
	CCtrlCode_AutoNumber* pCode	= (CCtrlCode_AutoNumber*)CtrlCodeTool.FindCtrlCode(pList, SETAUTONUMBER);
	if (!pCode)
		return NULL;
	return pCode->GetRefData();
}

// -------------------------------------------------------------------------
