/* -------------------------------------------------------------------------
//	�ļ���		��	io/fileadpt.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-18 1:15:36
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IO_FILEADPT_H__
#define __IO_FILEADPT_H__

#if defined(__Disable_All_File_Adapter)
#define __Disable_IStream_Adapter
#define __Disable_FILE_Adapter
#define __Disable_HFILE_Adapter
#endif

typedef long FILEOFF;
typedef unsigned long FILESIZE;	// �������޷��ŵ�

// =========================================================================

#if !defined(__WIN32__)
#define __Disable_HFILE_Adapter
#endif

#if !defined(__Disable_HFILE_Adapter)

#ifndef _WINBASE_
#include <winbase.h>	// windows-standard-io-routine
#endif

inline STDMETHODIMP _ioSeekFile(HANDLE pFile, FILEOFF lOff, int from)
{
	return SetFilePointer(pFile, lOff, NULL, from) == (DWORD)-1 ? E_FAIL : S_OK;
};

inline STDMETHODIMP_(UINT) _ioReadFile(HANDLE pFile, LPVOID pData, UINT nMax)
{
	DWORD nReaded = 0;
	ReadFile(pFile, pData, nMax, &nReaded, NULL);
	return nReaded;
}

inline STDMETHODIMP_(UINT) _ioWriteFile(HANDLE pFile, LPCVOID pData, UINT nMax)
{
	ULONG nWritten = 0;
	WriteFile(pFile, pData, nMax, &nWritten, NULL);
	return nWritten;
}

inline STDMETHODIMP_(FILEOFF) _ioGetOffset(HANDLE pFile)
{
	return SetFilePointer(pFile, 0, NULL, FILE_CURRENT);
}

inline STDMETHODIMP_(void) _ioFlush(HANDLE pFile)
{
	FlushFileBuffers(pFile);
}

#endif // !defined(__Disable_HFILE_Adapter)

// =========================================================================

#if !defined(__Disable_IStream_Adapter)

#ifndef LISet32
#define LISet32(li, v) ((li).HighPart = (v) < 0 ? -1 : 0, (li).LowPart = (v))
#endif

#ifndef ULISet32
#define ULISet32(li, v) ((li).HighPart = 0, (li).LowPart = (v))
#endif

inline STDMETHODIMP _ioSeekFile(IStream* pFile, FILEOFF lOff, int from)
{
	LARGE_INTEGER dlibMove;
	LISet32(dlibMove, lOff);
	return pFile->Seek(dlibMove, from, (ULARGE_INTEGER*)&dlibMove);
};

inline STDMETHODIMP_(UINT) _ioReadFile(IStream* pFile, LPVOID pData, UINT nMax)
{
	ULONG nReaded = 0;
	pFile->Read(pData, nMax, &nReaded);
	return nReaded;
}

inline STDMETHODIMP_(UINT) _ioWriteFile(IStream* pFile, LPCVOID pData, UINT nMax)
{
	ULONG nWritten = 0;
	pFile->Write(pData, nMax, &nWritten);
	return nWritten;
}

inline STDMETHODIMP_(FILEOFF) _ioGetOffset(IStream* pFile)
{
	LARGE_INTEGER dlibMove;
	ULISet32(dlibMove, 0);
	pFile->Seek(dlibMove, SEEK_CUR, (ULARGE_INTEGER*)&dlibMove);
	return dlibMove.LowPart;
}

inline STDMETHODIMP_(void) _ioFlush(IStream* pFile)
{
}

#endif // !defined(__Disable_IStream_Adapter)

// =========================================================================

#if !defined(__Disable_FILE_Adapter)

#ifndef _INC_STDIO
#include <stdio.h>	// c-standard-io-roution
#endif

inline STDMETHODIMP _ioSeekFile(FILE* pFile, FILEOFF lOff, int from)
{
	fseek(pFile, lOff, from);
	return S_OK;
};

inline STDMETHODIMP_(UINT) _ioReadFile(FILE* pFile, LPVOID pData, UINT nMax)
{
	return fread(pData, 1, nMax, pFile);
}

inline STDMETHODIMP_(UINT) _ioWriteFile(FILE* pFile, LPCVOID pData, UINT nMax)
{
	return fwrite(pData, 1, nMax, pFile);
}

inline STDMETHODIMP_(FILEOFF) _ioGetOffset(FILE* pFile)
{
	return ftell(pFile);
}

inline STDMETHODIMP_(void) _ioFlush(FILE* pFile)
{
	fflush(pFile);
}

#endif // !defined(__Disable_FILE_Adapter)

// =========================================================================

#endif /* __IO_FILEADPT_H__ */
