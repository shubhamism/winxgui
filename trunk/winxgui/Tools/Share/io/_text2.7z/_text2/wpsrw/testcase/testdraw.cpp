/* -------------------------------------------------------------------------
//	�ļ���		��	testdraw.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-21 11:43:22
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestDrawing : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestDrawing);
		CPPUNIT_TEST(testFill);
		CPPUNIT_TEST(testPen);
		CPPUNIT_TEST(testImage);
		CPPUNIT_TEST(testTextBox);
		CPPUNIT_TEST(testPoly);
		CPPUNIT_TEST(testOle);

		CPPUNIT_TEST(testRotateText);
		CPPUNIT_TEST(testRotateText1);
		CPPUNIT_TEST(testRect);
		CPPUNIT_TEST(testRect1);
		CPPUNIT_TEST(testEllipse);
		CPPUNIT_TEST(testLText); // ��������
		CPPUNIT_TEST(testGroupShape);

		CPPUNIT_TEST(testChartBasic);

		CPPUNIT_TEST(testTable);
		CPPUNIT_TEST(testTableBody);
		CPPUNIT_TEST(testLine);
		CPPUNIT_TEST(testFormula);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:

	void testFill()
	{
		//�������
		testWps2DocFile("draw/embFill.wps", "_draw_embFill_.doc");
		//�������
		testWps2DocFile("draw/embGradFill.wps", "_draw_embGradFill_.doc");
		//ͼƬ���
		testWps2DocFile("draw/embPicFill.wps", "_draw_embPicFill_.doc");
	}
	void testPen()
	{
		testWps2DocFile("draw/embPen.wps", "_draw_embPen_.doc");
	}
	void testImage()
	{
		testWps2DocFile("draw/2000/embimage_gif.wps", "_draw_2000_embimage_gif_.doc");
		testWps2DocFile("draw/embimage_pcx.wps", "_draw_embimage_pcx_.doc");
		testWps2DocFile("draw/embimage_gif.wps", "_draw_embimage_gif_.doc");
		testWps2DocFile("draw/embImage.wps", "_draw_embImage_.doc");
	}
	void testTextBox()
	{
		testWps2DocFile("draw/embTextBox.wps", "_draw_embTextBox_.doc");
	}
	void testPoly()
	{
		testWps2DocFile("draw/embPoly.wps", "_draw_embPoly_.doc");
	}
	void testOle()
	{
		testWps2DocFile("draw/embole.wps", "_draw_embole_.doc");
	}

	void testRotateText1()
	{
		testWps2DocFile("draw/rotatetext.wps", "_draw_rotatetext_.doc");
	}
	void testRotateText()
	{
		testWps2DocFile("draw/embrotatetext.wps", "_draw_embrotatetext_.doc");
	}
	void testRect1()
	{
		testWps2DocFile("draw/rect.wps", "_draw_rect_.doc");
	}
	void testEllipse()
	{
		testWps2DocFile("draw/ellipse.wps", "_draw_ellipse_.doc");
	}
	void testRect()
	{
		testWps2DocFile("draw/embrect.wps", "_draw_embrect_.doc");
		testWps2DocFile("draw/embroundrect.wps", "_draw_embroundrect_.doc");
		testWps2DocFile("draw/embellipse.wps", "_draw_embellipse_.doc");
		testWps2DocFile("draw/embcube.wps", "_draw_embcube_.doc");
		testWps2DocFile("draw/embcylinder.wps", "_draw_embcylinder_.doc");
		testWps2DocFile("draw/embrectpoly.wps", "_draw_embrectpoly_.doc");
	}
	void testLText()
	{
		testWps2DocFile("draw/embltxt.wps", "_draw_embltxt_.doc");
	}
	void testGroupShape()
	{
		testWps2DocFile("draw/embgroup.wps", "_draw_embgroup_.doc");
	}
	void testChartBasic()
	{
		testWps2DocFile("chart/basic.wps", "_chart_basic_.doc");
	}
	void testTable()
	{
		//testWps2DocFile("�ۺ�/��ְ����ر���/���������.wps", "_draw_���������_.doc");
		testWps2DocFile("draw/table.wps", "_draw_table_.doc");
	}
	void testTableBody()
	{
		testWps2DocFile("�ۺ�/����WPS��������/WPS����/�ɼ�ͳ�Ʊ�.WPS", "_�ɼ�ͳ�Ʊ�_.doc");
		testWps2DocFile("draw/tablebody.wps", "_draw_tablebody_.doc");
	}
	void testFormula()
	{
		testWps2DocFile("formula/basic.wps", "_formula_basic.doc");
	}
	void testLine()
	{
		testWps2DocFile("draw/line.wps", "_draw_line_.doc");
	}
};  

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestDrawing);

// -------------------------------------------------------------------------
