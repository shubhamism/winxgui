/* -------------------------------------------------------------------------
//	�ļ���		��	wpsrw/common.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 11:03:43
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPSRW_COMMON_H__
#define __WPSRW_COMMON_H__

class CWpsDoc;

// -------------------------------------------------------------------------

#undef private
#define private protected
//#undef protected
//#define protected public

#undef ASSERT_VALID
#define ASSERT_VALID(p)	ASSERT(p)

#define	TRACERD0(sz)					NULL
#define	TRACERD1(sz, p1)				NULL
#define	TRACERD2(sz, p1, p2)			NULL
#define	TRACERD3(sz, p1, p2, p3)		NULL

#define	TRACEPIR0(sz)					NULL
#define	TRACEPIR1(sz, p1)				NULL
#define	TRACEPIR2(sz, p1, p2)			NULL
#define	TRACEPIR3(sz, p1, p2, p3)		NULL

#define	TRACEROD0(sz)					NULL
#define	TRACEROD1(sz, p1)				NULL
#define	TRACEROD2(sz, p1, p2)			NULL
#define	TRACEROD3(sz, p1, p2, p3)		NULL

#ifndef REPORT
#define REPORT(s)		ASSERT(0)
#endif

#ifndef WpsLog_EnterFunction
#define WpsLog_EnterFunction(func)
#endif

#ifndef WpsLog_LeaveFunction
#define WpsLog_LeaveFunction(func)
#endif

// -------------------------------------------------------------------------

typedef CObject		KSObject;
typedef CObList		KSObList;
typedef CObArray	KSObArray;

typedef DWORD KCOLORINDEX;

#ifndef KSArchive
#define KSArchive	CArchive
#endif

#ifndef STGM_G_CREATE

#define STGM_G_READ				(STGM_READ | STGM_SHARE_EXCLUSIVE)
#define STGM_G_WRITE			(STGM_READWRITE | STGM_SHARE_EXCLUSIVE)
#define STGM_G_CREATE			(STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE)

#define STGM_T_READ				(STGM_READ | STGM_TRANSACTED)
#define STGM_T_WRITE			(STGM_READWRITE | STGM_TRANSACTED)
#define STGM_T_CREATE			(STGM_READWRITE | STGM_TRANSACTED | STGM_CREATE)

#endif

// -------------------------------------------------------------------------

#define DECLARE_WPSSERIAL(class_name) \
public: \
	void ChangeRuntimeClassName (); \
	DECLARE_SERIAL (class_name)

#define IMPLEMENT_WPSSERIAL(class_name, base_class_name, wSchema) \
	IMPLEMENT_SERIAL (class_name, base_class_name, wSchema) \
	static char _lpszWPS##class_name[] = #class_name; \
	void class_name::ChangeRuntimeClassName () \
	{ \
		static BOOL bChanged = FALSE; \
		if (bChanged == FALSE) \
		{ \
			bChanged = TRUE; \
			for (int i = 0; _lpszWPS##class_name[i] != '\0'; i++) \
				_lpszWPS##class_name[i] ^= 0x7F; \
			class_name::class##class_name.m_lpszClassName = \
				_lpszWPS##class_name; \
		} \
	}

// -------------------------------------------------------------------------

#ifndef __KS_UNITHELPER_H__
#include "unithelper.h"
#endif

#ifndef __WPSRW_STDDEFINE_H__
#include "stddefine.h"
#endif

#ifndef __WPSRW_BUILTIN_STYLE_H__
#include "builtin_style.h"
#endif

#ifndef __WPSRW_WPSSERIAL_H__
#include "wpsserial.h"
#endif

#ifndef __WPSRW_WPSSERIALEXT_H__
#include "wpsserialext.h"
#endif

#ifndef __WPSRW_WPSRECORD_H__
#include "wpsrecord.h"
#endif

#pragma pack()

// -------------------------------------------------------------------------
// Locale Converter

HINSTANCE InitLocaleConverter(WORD wVersion, DWORD dwLocale);
BOOL FreeLocaleConverter(HINSTANCE hLib);

typedef BYTE (WINAPI* CONVPROC)(LPSTR, DWORD);
typedef void (WINAPI* CONVPROCW)(LPWORD, DWORD);
typedef void (WINAPI* CONVPROCDW)(LPDWORD, DWORD);
extern CONVPROCW	g_lpConvProcW;		// ��������ʱ�Ƿ���Ҫת�����루���ֽڣ�
extern CONVPROCDW	g_lpConvProcDW;		// ��������ʱ�Ƿ���Ҫת�����루���ֽڣ�
extern CONVPROC		g_lpConvProc;		// ��������ʱ�Ƿ���Ҫת������

#define GB2B5			2
#define B52GB			3

#define GB2B5W			4		// ��˫�ֽڴ�������
#define B52GBW			5

#define GB2B5DW			6		// ��˫�ֽڴ�������
#define B52GBDW			7

typedef struct tagCODEPAGECONVERTER
{
	CONVPROC ConvProc;
	CONVPROCW ConvProcW;
	CONVPROCDW ConvProcDW;
}CODEPAGECONVERTER;

// -------------------------------------------------------------------------

extern DWORD dwSentenceID;

extern LANGID g_wLangID;
extern LANGID g_wCurLangID;
extern DWORD g_dwLanguageVersion;
extern DWORD g_dwResourceLanguage;

extern UINT g_wVersion;
extern BOOL g_bExport2Wps2000;
extern WPSFILEHEADER* g_pWPSFHeader;
extern TCHAR szWpsHead[];

inline BOOL IsMengWen_Resource(DWORD dwResourceLan)
{
	return ((BOOL)(defMENGWEN_VERSION == dwResourceLan));
}


// -------------------------------------------------------------------------
// ���¶���������� WPS2000 �ļ���ʧ���ݵ���Ϣ������ g_uExportflag
#define LOSS_REVISE						0x1
#define LOSS_BOOKMARK					0x2
#define LOSS_HYPERLINK					0x4
#define LOSS_FOOTNOTE					0x8
#define LOSS_GWOBJ						0x10
#define LOSS_REVISEUSERINFO				0x20

extern UINT g_uExportflag;
extern class KXCodePageVI* g_lpKXCodePageVI;

// -------------------------------------------------------------------------
// ���³��������ļ�����
#define		SIZE_PASSWORD		(33)		// ���볤��(�ֽ�, ������βNULL�ַ�)
#define		MAXPASSWORD			(8)			// �ɰ�WPS���볤��(�ֽ�, ������β���ַ�)
#define		ENCRYPT				(1)			// ��ȡ���������ļ�����
#define		DECRYPT				(2)			// ��ȡ�������ڽ��Ѽ����ļ�����

extern BYTE szPassword [MAXPASSWORD + 1];

// -------------------------------------------------------------------------

extern const TCHAR WMD_CRYPT[];
extern const TCHAR WMD_WPSCONFIG[];
extern const TCHAR WMD_RESGBK[];
extern const TCHAR WMD_GBTOB5[];
extern const TCHAR WMD_18030TOB5[];
extern const TCHAR WMD_WPSTOOL[];
extern const TCHAR WMD_HMJD[];
extern const TCHAR WMD_WPPHDRFTR[];

// -------------------------------------------------------------------------

#define WPSHEADSIZE		1024

#endif /* __WPSRW_COMMON_H__ */
