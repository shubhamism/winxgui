/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_group.h
//	������		��	����
//	����ʱ��	��	2004-10-26 2:35:14 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __AUTONUM_GROUP_H__
#define __AUTONUM_GROUP_H__

// -------------------------------------------------------------------------

#define _MAX_AUTONUMATOMS_EACHGROUP		(10)
#define ISVALIDAUTONUMLEVEL(nLevel)		((nLevel) >= 0 && (nLevel) < (_MAX_AUTONUMATOMS_EACHGROUP))
struct tagAUTONUMGROUP
{
	KAutoNumAtomSPtr GroupData[_MAX_AUTONUMATOMS_EACHGROUP];
public:
	tagAUTONUMGROUP();
	tagAUTONUMGROUP(const tagAUTONUMGROUP& BigGroup);
	~tagAUTONUMGROUP();
public:
//	HRESULT Reset();
	const tagAUTONUMGROUP& operator=(const tagAUTONUMGROUP& BigGroup);
	HRESULT ChangeSpecialLevelData(int nLevel, const KAutoNumAtomSPtr& pAtomPtr);
	HRESULT GetSpecialLevelData(int, KAutoNumAtomSPtr&);
	static int GetLevelCount()
	{
		return (int)_MAX_AUTONUMATOMS_EACHGROUP;
	}
};
typedef tagAUTONUMGROUP		AUTONUMGROUP;
typedef tagAUTONUMGROUP*	PAUTONUMGROUP;


// -------------------------------------------------------------------------

#endif /* __AUTONUM_GROUP_H__ */
