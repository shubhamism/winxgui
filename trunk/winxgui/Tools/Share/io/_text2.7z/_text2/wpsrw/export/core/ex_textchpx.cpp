/* -------------------------------------------------------------------------
//	�ļ���		��	ex_textchpx.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 9:37:51
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_wpsdoc.h"
#include <mso/filefmt/word/helper.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

CtrlCodeClassDecl(SETCHNFONT, CCtrlCode_Font);
CtrlCodeClassDecl(SETENGFONT, CCtrlCode_Font);
CtrlCodeClassDecl(SETFONTSIZE, CCtrlCode_Size);
CtrlCodeClassDecl(SETASPECTX, CCtrlCode_AspectX);
CtrlCodeClassDecl(SETTRACKING, CCtrlCode_Tracking);
CtrlCodeClassDecl(SETITALIC, CCtrlCode_Italic);
CtrlCodeClassDecl(SETBOLD, CCtrlCode_Bold);
CtrlCodeClassDecl(SETUNDERLINE, CCtrlCode_UnderLine);
CtrlCodeClassDecl(SETUPPERLINE, CCtrlCode_UnderLine);
CtrlCodeClassDecl(SETSTRIKEOUT, CCtrlCode_StrikeOut);
CtrlCodeClassDecl(SETCOLOR, CCtrlCode_Color);
CtrlCodeClassDecl(SETSSS, CCtrlCode_SSScript);
CtrlCodeClassDecl(SETHSS, CCtrlCode_HSS);
CtrlCodeClassDecl(SETREVISE, CCtrlCode_Revise);
CtrlCodeClassDecl(SETSTRESS, CCtrlCode_UnderLine);
CtrlCodeClassDecl(SETOUTRECT, CCtrlCode_OutRect);
CtrlCodeClassDecl(SETBGVEIN, CCtrlCode_BGVein);
CtrlCodeClassDecl(SETWCHARSET,	CCtrlCode_CharSet);
CtrlCodeClassDecl(SETSENVISIBLE,  CCtrlCode_Visible);

// �Ǿ�����
CtrlCodeClassDecl(SETHYPERREF, CCtrlCode_HotRef);
CtrlCodeClassDecl(SETGWSREF, CCtrlCode_HotRef);
CtrlCodeClassDecl(SETLABEL,	CCtrlCode_Label);

// -------------------------------------------------------------------------

extern CCtrlCode_Size *GetFSFormStyleSheet(KWpsExport& export, DWORD dwID, CString styleName);
// @@todo

EX_CONV_API GenGWSRefCode(CCtrlCode_HotRef* pCode, KDWPropBuffer& papx)
{
}
// -------------------------------------------------------------------------

EX_CONV_API ChpxCtrlCode_Context::GenChnFontCode(CCtrlCode_Font* pCode, KDWPropBuffer& chpx)
{
	LPCSTR szFace = pCode->GetFaceName();
	UINT ftc = m_export.AddFont(szFace);
	chpx.AddPropFix(sprmCRgFtc1, ftc);
}

EX_CONV_API ChpxCtrlCode_Context::GenEngFontCode(CCtrlCode_Font* pCode, KDWPropBuffer& chpx)
{
	LPCSTR szFace = pCode->GetFaceName();
	UINT ftc = m_export.AddFont(szFace);
	chpx.AddPropFix(sprmCRgFtc0, ftc);
	chpx.AddPropFix(sprmCRgFtc2, ftc);
}

//�������ֺŶ�Ӧ��ֵ,(��λ: 0.1��)
//int uFontPound[15] = 
//{
//	360	/* 0: ����*/, 320	/*1: С����*/,
//	280	/* 2: һ��*/, 240	/*3: Сһ��*/,
//	200	/* 4: ����*/, 180	/*5: С����*/,
//	160	/* 6: ����*/,
//	140	/* 7: �ĺ�*/, 120	/*8: С�ĺ�*/,
//	100	/* 9: ���*/, 90	/*10:С���*/,
//	80	/*11: ����*/, 70	/*12:С����*/,
//	60	/*13: �ߺ�*/, 50	/*14:С�ߺ�*/
//};
INT32 gConvertCtrlCode_Size2HalfPt(const CCtrlCode_Size* pCode, CSentence_Content *pSenContent)
{
	INT32 iRet = 0;
	switch (pCode->GetActualUnit())
	{
	case FSU_SIZE:
		{
			UINT nSize = pCode->GetActualSize();

			//lijun ���漸���ֺ�ת����׼ȷ,���������ķ���.
			switch(nSize)
			{
			case 9:			iRet = 21;				break;
			case 10:		iRet = 18;				break;
			case 11:		iRet = 15;				break;
			case 12:		iRet = 13;				break;
			case 14:		iRet = 10;				break;
			default:		iRet = hm2pt(GetFontSizeHM(nSize, FALSE)) * 2;
			}
			break;
		}
	case FSU_POUND:
		iRet = pCode->GetActualSize() * 2;
		break;
	case FSU_HM:
		iRet = hm2pt(pCode->GetActualSize()) * 2;
		break;
	}
	if (pSenContent && pSenContent->GetSenHasFS() == FALSE)
		pSenContent->SetSenHasFS(TRUE);
	return iRet;
}

EX_CONV_API ChpxCtrlCode_Context::GenSizeCode(CCtrlCode_Size* pCode, KDWPropBuffer& chpx)
{
	chpx.AddPropFix(sprmCHps, gConvertCtrlCode_Size2HalfPt(pCode, GetSenContent()));
}

EX_CONV_API ChpxCtrlCode_Context::GenAspectXCode(CCtrlCode_AspectX* pCode, KDWPropBuffer& chpx)
{
	WORD wAspect;
	wAspect=pCode->GetAspectX();
	chpx.AddPropFix(sprmCCharScale,wAspect);	
}

EX_CONV_API ChpxCtrlCode_Context::GenTrackingCode(CCtrlCode_Tracking* pCode, KDWPropBuffer& chpx)
{
	const UNIT_VALUE* uVal;	
	uVal=pCode->GetTracking();
	
	switch(uVal->wUnit)
	{
	case UNIT_METRIC:
// 		chpx.AddPropFix(sprmCDxaSpace,lm2pt(uVal->nValue));
		//lijun ���浥λת���������Ѿ��޸���
		chpx.AddPropFix(sprmCDxaSpace, uVal->nValue * 5.6726 * 0.5);
		break;
	case UNIT_PERCENT://to do
		{
			//lijun
			tagFONTSIZE fontSize;
			WORD wAspectX = 100;
			CSentence* sen = NULL;
			CParagraph *pPara = NULL;
			CCtrlCode_Size *pCodesize = NULL;
			CCtrlCode_AspectX *pAspectX = NULL;
			CCtrlCode *pCtrlCode = NULL;
			//�������Ժ��������Բ�ͬ,�ȿ��Ǳ�������
			if (m_export.m_pTblEleAttri != NULL)
			{
				POSITION pos = 0;
				for(pos = m_export.m_pTblEleAttri->GetHeadPosition(); pos;)
				{
					pCtrlCode = (CCtrlCode*)m_export.m_pTblEleAttri->GetNext(pos);
					if (pCtrlCode->GetCodeID() == SETFONTSIZE)
						pCodesize = (CCtrlCode_Size *)pCtrlCode;
				}
			}
			else
			{							
				if (GetSenContent() == NULL || GetSenContent()->GetSentence() == NULL)
				{
					fontSize.nfsSize = 9;
					fontSize.nfsUnit = 1;
				}
				else
				{
					sen = GetSenContent()->GetSentence();
					pCodesize = (CCtrlCode_Size*)sen->GetCtrlCode(SETFONTSIZE);
					pAspectX = (CCtrlCode_AspectX*)sen->GetCtrlCode(SETASPECTX);
					if (pAspectX != NULL)			
						wAspectX = pAspectX->GetAspectX();
				}
			}
			if (sen != NULL)
			{
				if (pCodesize == NULL)
				{	
					pCodesize = GetFSFormStyleSheet(m_export, sen->GetStyleID(), sen->GetStyleName());
					if (pCodesize != NULL)
					{
						fontSize.nfsSize = pCodesize->GetSize();
						fontSize.nfsUnit = pCodesize->GetUnit();
					}
					else
					{
						pPara = sen->GetCurParagraph();
						if (pPara != NULL)
						{
							pCodesize = GetFSFormStyleSheet(m_export, pPara->m_dwStyleID, pPara->m_strStyleName);
							if (pCodesize != NULL)
							{
								fontSize.nfsSize = pCodesize->GetSize();
								fontSize.nfsUnit = pCodesize->GetUnit();
							}
							else
							{
								fontSize.nfsSize = 9;
								fontSize.nfsUnit = 1;
							}
						}
					}
				}
				else
				{			
					fontSize.nfsSize = pCodesize->GetSize();
					fontSize.nfsUnit = pCodesize->GetUnit();
				} 
			}
			chpx.AddPropFix(sprmCDxaSpace, 
					GetFontSizeHM(fontSize.nfsSize, fontSize.nfsUnit == FSU_POUND) *
					0.56736 * wAspectX * 0.01 * uVal->nValue * 0.01 * 0.5);
			break;
		}		
	default:
		break;
	}
}

EX_CONV_API ChpxCtrlCode_Context::GenItalicCode(CCtrlCode_Italic* pCode, KDWPropBuffer& chpx)
{
	//@@todo:WORD�˴�ֵΪ 0(��),1, 0x80 - ����ʽ��ͬ 0x81 - ����ʽ�෴
	LONG lDegree = pCode->GetDegree() == CC_DISABLED ? 0 : 1;
	chpx.AddPropFix(sprmCFItalic, lDegree != 0 ? 0x01 : 0x00);
}

EX_CONV_API ChpxCtrlCode_Context::GenBoldCode(CCtrlCode_Bold* pCode, KDWPropBuffer& chpx)
{
	LONG lWeight=pCode->GetWeight();
	chpx.AddPropFix(sprmCFBold, lWeight > FW_NORMAL ? 0x01 : 0x00);
}

EX_CONV_API ChpxCtrlCode_Context::GenUnderLineCode(CCtrlCode_UnderLine* pCode, KDWPropBuffer& chpx)
{
	typedef enum
	{
		wk_dotted=4,
		wk_dash=7,
		wk_single=1,
		wk_wave=11,
		wk_dot_dash=9,
		wk_dot_dot_dash=10,
		wk_thick=6
	}word_kul_line_type;	
	WORD wType=pCode->GetType();
	switch(wType)
	{
	case PS_WAVE:
		chpx.AddPropFix(sprmCKul,wk_wave);
		break;
	case PS_SOLID:
	case PS_THIEFSOLID:		
		chpx.AddPropFix(sprmCKul,wk_single);
		break;
	case PS_INSIDEFRAME:
		chpx.AddPropFix(sprmCKul,wk_thick);
		break;
	case PS_DASH:
		chpx.AddPropFix(sprmCKul,wk_dash);
		break;		
	case PS_DOT:
		chpx.AddPropFix(sprmCKul,wk_dotted);
		break;		
	case PS_DASHDOT:
		chpx.AddPropFix(sprmCKul,wk_dot_dash);
		break;		
	case PS_DASHDOTDOT:
		chpx.AddPropFix(sprmCKul,wk_dot_dot_dash);
		break;
	default:
		//ASSERT_ONCE(0);
		return;
	}
	KCOLORINDEX iUnlnColor=pCode->GetUULineColor();
	chpx.AddPropFix(sprmCKulColor,iUnlnColor);
}

EX_CONV_API ChpxCtrlCode_Context::GenUpperLineCode(CCtrlCode_UnderLine* pCode, KDWPropBuffer& chpx)
{	
	//�ǹ����ϻ��ߵĲ���ת����
}

EX_CONV_API ChpxCtrlCode_Context::GenStressCode(CCtrlCode_UnderLine* pCode, KDWPropBuffer& papx)
{
	//to do
	//lijun
	papx.AddPropFix(sprmCKcd, 1);
}

EX_CONV_API ChpxCtrlCode_Context::GenStrikeOutCode(CCtrlCode_StrikeOut* pCode, KDWPropBuffer& chpx)
{
	//@@todo:WORD�˴�ֵΪ 0(��),1, 0x80 - ����ʽ��ͬ 0x81 - ����ʽ�෴
	WORD wFlag=pCode->GetFlag() == CC_DISABLED ? 0 : 1;	
	chpx.AddPropFix(sprmCFStrike,wFlag);
}

EX_CONV_API ChpxCtrlCode_Context::GenSSScriptCode(CCtrlCode_SSScript* pCode, KDWPropBuffer& papx)
{	
	WORD wFlag=pCode->GetFlag();
	switch(wFlag)
	{
	case SSS_SUPER:
		papx.AddPropFix(sprmCIss,1);
		break;
	case SSS_SUB:
		papx.AddPropFix(sprmCIss,2);
		break;
	case CC_DISABLED:
		papx.AddPropFix(sprmCIss,0);
		break;
	default:
		ASSERT_ONCE(0);
	}
}

EX_CONV_API ChpxCtrlCode_Context::GenHSSCode(CCtrlCode_HSS* pCode, KDWPropBuffer& papx)
{	
	const CHARFXHSS* chFxhss=pCode->GetData();	
	switch(chFxhss->hssFlag)
	{
	case SETHOLLOW:
		papx.AddPropFix(sprmCFOutline,1);
		break;
	case SETSHADOW:
		papx.AddPropFix(sprmCFShadow,1);
		if (!(chFxhss->hssPara & SD_SOLIDCHAR))
			papx.AddPropFix(sprmCFOutline,1);//��Ӱ�ӿ���
		break;
	case SETEMBOSS_POS:
		papx.AddPropFix(sprmCFEmboss,1);
		break;
	case SETEMBOSS_NEG:
		papx.AddPropFix(sprmCFImprint,1);
		break;			
	case SETTRACKEDGE:	//0x17		// �趨����
		if (!(chFxhss->hssPara & SD_SOLIDCHAR))
			papx.AddPropFix(sprmCFOutline,1);//���߼ӿ���
	case SETTRANSITION:	//0x16		// �趨����
		//@@todo:WORD��û�ж�Ӧ��Ч������Ҫ��������ö��ֵ
		break;
	default:
		//@@todo: ASSERT_ONCE(0)
		;
	}
}

EX_CONV_API ChpxCtrlCode_Context::GenOutRectCode(CCtrlCode_OutRect* pCode, KDWPropBuffer& papx)
{	
	typedef enum
	{
		wbrc_single=1,
		wbrc_dash_large_gap=7,
		wbrc_dot=6,
		wbrc_dot_dash=8,
		wbrc_dot_dot_dash=9,
		wbrc_none=0
	}word_brc_line_type;
	int tranLineTypeArr[]={wbrc_single,wbrc_dash_large_gap,wbrc_dot,wbrc_dot_dash,wbrc_dot_dot_dash,wbrc_none,wbrc_single};
	union
	{
		BRC brc;
		DWORD brcValue;
	};
	brcValue = 0;
	brc.dptLineWidth = lm2pt(8*pCode->GetWidth());
	brc.brcType =tranLineTypeArr[pCode->GetStyle()];
	brc.ico = MatchRGB2Ico(pCode->GetColor());
	papx.AddPropFix(sprmCBrc,brcValue);
}

EX_CONV_API ChpxCtrlCode_Context::GenBGVeinCode(CCtrlCode_BGVein* pCode, KDWPropBuffer& papx)
{
	typedef enum
	{
		shd_Solid=1,
		shd_Horizontal=20,
		shd_Vertical,
		shd_Forward_Diagonal,
		shd_Backward_Diagonal,
		shd_Cross,
		shd_Diagonal_Cross
	}shdPatType;
	WORD tranpatArr[]={shd_Solid,shd_Horizontal,shd_Vertical,shd_Forward_Diagonal,shd_Backward_Diagonal,shd_Cross,shd_Diagonal_Cross};
	union
	{
		SHD shd;
		WORD shdValue;
	};
	shd.icoBack=0;
	shd.ipat=tranpatArr[pCode->GetStyle()];
	shd.icoFore=MatchRGB2Ico(pCode->GetColor());
	papx.AddPropFix(sprmCShd,shdValue);
}

EX_CONV_API ChpxCtrlCode_Context::GenCharSetCode(CCtrlCode_CharSet* pCode, KDWPropBuffer& papx)
{	
	//@@todo: ���ָ�ָ���˸���xushiwei��
	ASSERT_ONCE(0);
}

EX_CONV_API ChpxCtrlCode_Context::GenSenVisibleCode(CCtrlCode_Visible* pCode, KDWPropBuffer& papx)
{
	//@@todo: wps�������ظ�ʽ���ַ�?
	//���ָ�ָ���˸���xushiwei��
	ASSERT_ONCE(0);
}

UINT ExportRevisionUser(KWpsExport& export, const REVISE_DATA* pData)
{
	UINT usrid = 0;
	CWpsDoc* pDoc = (CWpsDoc*)export.m_pDoc;
	CUser *pUser = pDoc->GetUser(pData->wUserID);

	export.GetRevisionUsers().Add(
		__X("Unknown"),
		__X("Unknown"),
		&usrid);
	
	export.GetRevisionUsers().Add(
		pUser->GetUserName().AllocSysString(),
		pUser->GetUserName().AllocSysString(),
		&usrid);

	return usrid;
}

void AddRevisionProp(const REVISE_DATA *pData, KDWPropBuffer& papx, UINT usrid)
{
	DTTM dttm;

	dttm.yr   = (pData->sReviseTime).wYear - 1900; 
	dttm.mon  = (pData->sReviseTime).wMonth;
	dttm.dom  = (pData->sReviseTime).wDay;
	dttm.wdy  = (pData->sReviseTime).wDayOfWeek;
	dttm.hr   = (pData->sReviseTime).wHour;
	dttm.mint = (pData->sReviseTime).wMinute;
	
	if (pData->wReviseType == REVISE_INSERT)
	{
		papx.AddPropFix(sprmCFRMark, 0x81);
		papx.AddPropFix(sprmCIbstRMark, usrid);
		papx.AddPropFix(sprmCDttmRMark, (UINT32&)dttm);
	}
	else if (pData->wReviseType == REVISE_DELETE)	//
	{
		papx.AddPropFix(sprmCFRMarkDel, 0x81);
		papx.AddPropFix(sprmCIbstRMarkDel, usrid);
		papx.AddPropFix(sprmCDttmRMarkDel, (UINT32&)dttm);
	}
	//wps����û�жԸ�ʽ���޶�
	//	else if (pCode->GetReviseType() == REVISE_FORMAT)	
	//	{
	//		SprmCPropRMarkExOprand oprand;
	//		oprand.dttmPropRMark = dttm;
	//		oprand.fPropRMark = 0x01;
	//		oprand.ibstPropRMark = usrid;
	//		papx.AddPropVar(sprmCPropRMarkEx, &oprand, sizeof(oprand));
	//		papx.AddPropFix(sprmCFPropRMarkEx, 0x01);
	//		
	//		papx.AddPropFix(sprmCTextColor, 0xff0000);
//	}
}

EX_CONV_API ChpxCtrlCode_Context::GenReviseCode(CCtrlCode_Revise* pCode, KDWPropBuffer& papx)
{
//	
//#define     REVISE_UNKNOWN		0		//δ֪
//#define		REVISE_INSERT		1		// ��ǲ��������
//#define		REVISE_DELETE		2		// ���ɾ��������
//#define		REVISE_FORMAT		3		// �޸Ĺ���ʽ������
	
	// �����û�:
	UINT usrid;
	const REVISE_DATA *pData;

	pData = pCode->GetReviseData();	

	usrid = ExportRevisionUser(m_export, pData);
	
	AddRevisionProp(pData, papx, usrid);

//	ASSERT_ONCE(0);
}

EX_CONV_API ChpxCtrlCode_Context::GenColorCode(CCtrlCode_Color* pCode, KDWPropBuffer& chpx)
{
	KCOLORINDEX cr = pCode->GetColor();
	chpx.AddPropFix(sprmCIco, MatchRGB2Ico(cr));
	chpx.AddPropFix(sprmCTextColor, cr);
}

EX_CONV_API ChpxCtrlCode_Context::GenLabelCode(CCtrlCode_Label* pCode, KDWPropBuffer& chpx)
{
	m_nBookmarkID = pCode->GetID();
}

EX_CONV_API ChpxCtrlCode_Context::GenHotRefCode(CCtrlCode_HotRef* pCode, KDWPropBuffer& chpx)
{
	m_pHotRef = pCode;
}

// -------------------------------------------------------------------------

EX_BEGIN_CONV(ChpxCtrlCode_Context)
	EX_ADD_CONV(SETCOLOR,       GenColorCode)
	EX_ADD_CONV(SETCHNFONT,		GenChnFontCode)
	EX_ADD_CONV(SETENGFONT,		GenEngFontCode)
	EX_ADD_CONV(SETFONTSIZE,	GenSizeCode)
	EX_ADD_CONV(SETASPECTX,     GenAspectXCode)
	EX_ADD_CONV(SETITALIC,      GenItalicCode)
	EX_ADD_CONV(SETBOLD,        GenBoldCode)
	EX_ADD_CONV(SETUNDERLINE,   GenUnderLineCode)
	EX_ADD_CONV(SETUPPERLINE,   GenUpperLineCode)
	EX_ADD_CONV(SETSTRIKEOUT,   GenStrikeOutCode)
	EX_ADD_CONV(SETSSS,		    GenSSScriptCode)
	EX_ADD_CONV(SETHSS,		    GenHSSCode)
	EX_ADD_CONV(SETREVISE,	    GenReviseCode)
	EX_ADD_CONV(SETSTRESS,	    GenStressCode)
	EX_ADD_CONV(SETOUTRECT,	    GenOutRectCode)
	EX_ADD_CONV(SETBGVEIN,	    GenBGVeinCode)
	EX_ADD_CONV(SETWCHARSET,	GenCharSetCode)
	EX_ADD_CONV(SETSENVISIBLE,  GenSenVisibleCode)
	EX_ADD_CONV(SETTRACKING,    GenTrackingCode)
	EX_ADD_CONV(SETHYPERREF,	GenHotRefCode)
	EX_ADD_CONV(SETLABEL,	    GenLabelCode)
	#ifdef _GWS
//	EX_ADD_CONV(SETGWSREF,	GenGWSRefCode)
	#endif // #ifdef _GWS
EX_END_CONV()

// -------------------------------------------------------------------------
