/* -------------------------------------------------------------------------
//	�ļ���		��	ex_style.h
//	������		��	����
//	����ʱ��	��	2004-10-25 9:28:09 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_STYLE_H__
#define __EX_STYLE_H__

// -------------------------------------------------------------------------

class KWpsExport;
class CStyle_Text;
typedef struct tagSTYLEEXPORTCONTEXT
{
	KWpsExport*			pExport;
	const CStyle_Text*	pStyle_WPS;
	KDWStyle*			pStyle_Word;
	DWORD				dwID;
	LPCTSTR				lpszName;
}STYLEEXPORTCONTEXT;

// -------------------------------------------------------------------------

class CStyle_Export
{
public:
	CStyle_Export() {}
	~CStyle_Export() {}

protected:
	typedef DWORD TextStyleIDType;
	typedef __std::hash_map<TextStyleIDType, UINT> TextStyleIDMapType;
	TextStyleIDMapType m_TextStyleIDMap;

	typedef ks_string TextStyleNameType;
	typedef __std::hash_map<TextStyleNameType, UINT> TextStyleNameMapType;
	TextStyleNameMapType m_TextStyleNameMap;

protected:
	BOOL Init(STYLEEXPORTCONTEXT* pSEC, KWpsExport* pExport, DWORD dwID,
				LPCTSTR lpszName, KDWStyle* pStyle_Word);
	BOOL CreateWordStyle(const STYLEEXPORTCONTEXT& sec);
	BOOL Convert_BaseStyle(const STYLEEXPORTCONTEXT& sec);
	BOOL Convert_StyleFollowed(const STYLEEXPORTCONTEXT& sec);
	BOOL Convert_CharAttribs(const STYLEEXPORTCONTEXT& sec);
	BOOL Convert_ParaAttribs(const STYLEEXPORTCONTEXT& sec);

	STYLE_SGC GetStyleType(const STYLEEXPORTCONTEXT& sec);

public:
	STDMETHODIMP_(UINT) Convert(KWpsExport& export, DWORD dwID, ks_string strStyleName);
	STDMETHODIMP_(UINT) ConvertDefaultTable(KWpsExport& export);
};

// -------------------------------------------------------------------------

#endif /* __EX_STYLE_H__ */
