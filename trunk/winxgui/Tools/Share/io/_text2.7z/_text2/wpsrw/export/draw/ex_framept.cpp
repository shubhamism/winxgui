////////////////////////////////////////////////
// File : ex_framept.cpp
//
// Function : 
//
// Creater : �
//
// CreateTime : 2005-1-10 16:38:51
//
// Comments: ...
////////////////////////////////////////////////
#include "stdafx.h"
#include "ex_framept.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
EX_SHAPE_API CFramePT_Export::ConvertFrame(CShape_Context& context)
{
	/*
	 *	�߿���״
	 */
	CRect rct = GetMrect();
	ASSERT(rct.right - rct.left > 0);
	ASSERT(rct.bottom - rct.top > 0);
//Tank:
//Ϊʲô����ô���ظ�����?!!!!!!!!!!!!!!!!!!!!!!
//��������һ���ط�ͳһ����
//wpsrw����ȱ������ѿ�,����Э��ʱ������������
#ifndef WPP_ONLY
	CShape_Context thisshape(context.GetWpsExport());
	thisshape.m_shape = context.m_shape.NewShape(FALSE)
		.SetChildAnchor(
			WpsShapeToTwip(0),
			WpsShapeToTwip(0),
			WpsShapeToTwip(rct.right - rct.left),
			WpsShapeToTwip(rct.bottom - rct.top));
#else
	CShape_Context thisshape(context.GetSlideBaseCtx());
	thisshape.m_shape = context.m_shape.NewShape(FALSE)
		.SetChildAnchor(
			WpsShapeToPptUnit(0),
			WpsShapeToPptUnit(0),
			WpsShapeToPptUnit(rct.right - rct.left),
			WpsShapeToPptUnit(rct.bottom - rct.top));
#endif

	(ShapeExportBaseTypeCast(FRAMEPT,this))->ConvertShape(thisshape);
	if(m_nfrmShape == FS_ROUNDRECT)//Բ�Ǿ���
	{
		thisshape.m_shape.SetShapeType(msosptRoundRectangle);
		CRect rct = GetMrect();
		thisshape.m_opt.ForceAddPropFix(msopt_adjustValue , CONVGUNITX(m_roundness.x));
		thisshape.m_opt.ForceAddPropFix(msopt_adjustValueY, CONVGUNITY(m_roundness.y));
	}
	else//����
	{
		thisshape.m_shape.SetShapeType(msosptRectangle);
	}

	thisshape.m_shape.SetProperties(thisshape.m_opt);
	thisshape.m_shape.SetUDefProperties(thisshape.m_optUDef);
}

EX_SHAPE_API CFramePT_Export::ConvertSubshape(CShape_Context& context)
{
	/*
	 *	��϶���
	 */
	for (POSITION pos = m_ptobjList.GetHeadPosition(); pos; )
	{
		CWPSObj* pWpsObj = (CWPSObj*)m_ptobjList.GetNext(pos);
		ASSERT(
			pWpsObj->IsKindOf(RUNTIME_CLASS(CWPSObj)));

		BOOL fGroup = IsGroupObject(pWpsObj);
		CRect rc = pWpsObj->GetMrect();
#ifndef WPP_ONLY
		CShape_Context subshape(context.GetWpsExport());
		subshape.m_shape = context.m_shape.NewShape(fGroup)
			.SetChildAnchor(
				WpsShapeToTwip(rc.left),
				WpsShapeToTwip(rc.top),
				WpsShapeToTwip(rc.right),
				WpsShapeToTwip(rc.bottom));
#else
		CShape_Context subshape(context.GetSlideBaseCtx());
		subshape.m_shape = context.m_shape.NewShape(fGroup)
			.SetChildAnchor(
				WpsShapeToPptUnit(rc.left),
				WpsShapeToPptUnit(rc.top),
				WpsShapeToPptUnit(rc.right),
				WpsShapeToPptUnit(rc.bottom));
#endif
		subshape.ConvertShape(pWpsObj);
		subshape.m_shape.SetProperties(subshape.m_opt);
		subshape.m_shape.SetUDefProperties(subshape.m_optUDef);
	}
}

EX_SHAPE_API CFramePT_Export::ConvertShape(CShape_Context& context)
{
	ConvertFrame(context);
	ConvertSubshape(context);
}

// -------------------------------------------------------------------------
