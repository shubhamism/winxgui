/* -------------------------------------------------------------------------
//	�ļ���		��	anchorobj.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 18:12:07
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <draw/wpsobj.h>
#include "anchorobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

//(���Ķ����ҳ�и���� [wxb 2002-5-7]
IMPLEMENT_SERIAL(CAnchorObj, CObject, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)

CAnchorObj::CAnchorObj()
{
	m_pAnchorObj	= NULL;
	m_AnchorType	= AnchorChar;
	m_nOffsetVert	=
		m_nOffsetHorz	= 0;
}

CAnchorObj::CAnchorObj(CWPSObj* pObj, int nType/* = AnchorChar*/,
					   int nHorz/* = 0*/, int nVert/* = 0*/)
{
	ASSERT_VALID(pObj);
	m_pAnchorObj	= pObj;
	m_AnchorType	= nType;
	m_nOffsetVert	= nVert;
	m_nOffsetHorz	= nHorz;
}

CAnchorObj::~CAnchorObj()
{
	if (m_pAnchorObj)
	{
		delete m_pAnchorObj;
		m_pAnchorObj = NULL;
	}
}

void CAnchorObj::Serialize(KSArchive& ar)
{
#define CUR_DATA_SIZE	(3 * sizeof(int))
	WORD wBufSize;	//���ƻ�������С���ļ���ʽ���¼���
	if (ar.IsLoading())
	{
		ASSERT(g_fCompoundFile);
		ar >> wBufSize;	ASSERT(wBufSize >= CUR_DATA_SIZE);
		ar >> m_AnchorType;
		ar >> m_nOffsetHorz;
		ar >> m_nOffsetVert;
		if (wBufSize > CUR_DATA_SIZE)
		{
			BYTE byte;
			for (int i = CUR_DATA_SIZE; i < wBufSize; i++)
				ar >> byte;
		}

#if defined(_DEBUG)
		try
		{
			ar >> (CObject*&)m_pAnchorObj;
		}
		catch (...)
		{
			REPORT_ONCE("δ֪���� -- ���ܸö���û�м����wpsrw����!!!");
		}
#else
		ar >> (CObject*&)m_pAnchorObj;
#endif

	}
	else
	{
		wBufSize = CUR_DATA_SIZE;
		ar << wBufSize;
		ar << m_AnchorType;
		ar << m_nOffsetHorz;
		ar << m_nOffsetVert;
		ar << m_pAnchorObj;
	}
}

// -------------------------------------------------------------------------
