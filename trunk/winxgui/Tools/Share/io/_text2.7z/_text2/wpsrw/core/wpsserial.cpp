/* -------------------------------------------------------------------------
//	�ļ���		��	wpsserial.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 20:28:58
//	��������	��	
//
//	$Id: wpsserial.cpp,v 1.4 2005/01/24 01:28:59 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*********************************************************************
�����������˺����������ѹ��İ���ļ�ͷ
ת����2000���ļ�ͷ,���Ǽӽ��˹�����Ϣ��

  typedef struct tagWPSFILEHEADER
  {
  WORD	wfhVersion;
  char	wfhCopyright[42];
  WORD	wfhHeaderSize;
  DWORD	wfhTemplateInfo;
  DWORD	wfhDocInfo;
  DWORD	wfhMainText;
  DWORD	wfhFramePT;
  __int16	wfhNumOfPage;
  DWORD	wfhAutoSaveInfo;
  WORD	wfhHeaderVersion;
  DWORD	wfhSumInfo;
  WORD	wfhSumSize;				// Header Version 0x9701 stops here
  DWORD	wfhLocale;				// Header Version 0x9702 stops here
  DWORD	wfhEncrypt;
  DWORD	wfhStyleSheet;			// WPS2000 beta stops here, with version 0x9800
  DWORD	wfhSerialNum;			// Header Version 0x9800 stops here ()
  DWORD	wfhBookMarkInfo;		// BookMark Information
  DWORD	wfhBookMarkSize;		// Length of BookMark
  DWORD	wfhGWInfo;
  WORD	wfhGWInfoSize;
  WORD	wfhCompress;			// ����ѹ����־
  
	FILETIME wfFileTime;
	DWORD	wfhSystemCodePage;		// ���ɵ�ϵͳ����
	DWORD	wfhOLEBlock;			// ole block offset
	DWORD	wfhOLEBlockSize;		// ole block offset size
	DWORD	wMultiLanguageID;		// ���Ӷ����԰汾��ʶ[shq	July 23,2001]
	DWORD	wIsReviseState;			// �����޶�״̬����[zxw	18/10/2002]
	DWORD	wReserve[14];			// Reserve 15 * DWORD - ole block
	DWORD	dwAutoNumOffset;		// AutoNum�Ĵ���λ��
	DWORD	dwFlagEx;				// WPS2002���(after beta, equal FLAGEX_WPS2002)
	} WPSFILEHEADER;
**********************************************************************/
BOOL ConverHeaderFromGW(WPSFILEHEADER* pFileHeader, GWSFILEHEADER* pGWHeader)
{
	ASSERT(pFileHeader && pGWHeader);
	BOOL bRet = FALSE;
	::memset(pFileHeader, 0, sizeof(WPSFILEHEADER));
	
    if(pFileHeader->wfhCompress)
		pFileHeader->wfhVersion = VER_WINWPS98_ZIP;
	else
		pFileHeader->wfhVersion = VER_WINWPS98;
	
	::lstrcpyn(pFileHeader->wfhCopyright, pGWHeader->wfhCopyright, 42);
	pFileHeader->wfhHeaderSize = pGWHeader->wfhHeaderSize;
	
	pFileHeader->wfhTemplateInfo = pGWHeader->wfhTemplateInfo;
	pFileHeader->wfhDocInfo = pGWHeader->wfhDocInfo;
	pFileHeader->wfhMainText = pGWHeader->wfhMainText;
	pFileHeader->wfhFramePT = pGWHeader->wfhFramePT;
	pFileHeader->wfhNumOfPage = pGWHeader->wfhNumOfPage;
	pFileHeader->wfhAutoSaveInfo = pGWHeader->wfhAutoSaveInfo;
	pFileHeader->wfhHeaderVersion = pGWHeader->wfhHeaderVersion;
	pFileHeader->wfhSumInfo = pGWHeader->wfhSumInfo;
	pFileHeader->wfhSumSize = pGWHeader->wfhSumSize;
	
	pFileHeader->wfhLocale = pGWHeader->wfhLocale;
	pFileHeader->wfhEncrypt = pGWHeader->wfhEncrypt;
	pFileHeader->wfhStyleSheet = pGWHeader->wfhStyleSheet;
	pFileHeader->wfhSerialNum = pGWHeader->wfhSerialNum;
	pFileHeader->wfhBookMarkInfo = pGWHeader->wfhBookMarkInfo;
	pFileHeader->wfhBookMarkSize = pGWHeader->wfhBookMarkSize;
	pFileHeader->wfhCompress = pGWHeader->wfhCompress;
    pFileHeader->wfhGWInfo = pGWHeader->wfhGWInfo;
	pFileHeader->wfhGWInfoSize = pGWHeader->wfhGWInfoSize;
    memset(&pFileHeader->wfFileTime, 0, 40);
	
	return bRet;
}

/*******************************************************
�������������ļ�ͷ�Ĳ����ɴ˺���ͳһ���й���
*******************************************************/
int ReadWPSHeader(void* wpsHeader, CFile* file, int len)
{
	ASSERT(wpsHeader && file);
	int pos;
	WORD wVer;
	TCHAR *szBuf;
	
	szBuf = (TCHAR*)malloc(len*sizeof(TCHAR));
	::memset(szBuf, 0, len);
	pos = file->GetPosition();
	file->SeekToBegin();
	file->Read(&wVer, sizeof(WORD));
	
	if(wVer == VER_GWS2000)
	{
		GWSFILEHEADER gwHeader;
		WPSFILEHEADER wpsFileHeader;
		file->SeekToBegin();
		
		file->Read(&gwHeader, sizeof(GWSFILEHEADER));
		::memset(wpsHeader, 0, len);
		ConverHeaderFromGW(&wpsFileHeader, &gwHeader);
		
		if(len <= sizeof(WPSFILEHEADER))
			::memcpy(wpsHeader, (void*)(&wpsFileHeader), len);
		else
			::memcpy(wpsHeader, (void*)(&wpsFileHeader), sizeof(WPSFILEHEADER));
	}
	else
	{
		file->SeekToBegin();
		len = file->Read(szBuf, len);	
		memcpy(wpsHeader, szBuf, len);
	}
	
	file->Seek(pos, CFile::begin);
	free(szBuf);
	return len;
}

// -------------------------------------------------------------------------

KMemFile::KMemFile(BOOL fCompoundFile, HGBL hGbl)
{
	_fCompoundFile = fCompoundFile;
	XCreateStreamOnHGlobal(hGbl, FALSE, &m_lpStream);
}

KMemFile::KMemFile(CFile* pFile, DWORD dwSize)
{
	_fCompoundFile = _IsCompoundFile(pFile);
	HGBL hGbl = XGlobalAlloc(GHND, dwSize);
	if (hGbl)
	{
		LPVOID pData = XGlobalLock(hGbl);
		pFile->Read(pData, dwSize);
		XGlobalUnlock(hGbl);
	}
	XCreateStreamOnHGlobal(hGbl, FALSE, &m_lpStream);
}

STDMETHODIMP_(HGBL) KMemFile::Detach()
{
	HGBL hGbl = NULL;
	if (m_lpStream)
	{
		XGetHGlobalFromStream(m_lpStream, &hGbl);
		m_lpStream->Release();
		m_lpStream = NULL;
	}
	return hGbl;	
}

KMemFile::~KMemFile()
{
	if (m_lpStream)
	{
		XGlobalFree(Detach());
	}
}

// -------------------------------------------------------------------------
// $Log: wpsserial.cpp,v $
// Revision 1.4  2005/01/24 01:28:59  xushiwei
// �޸�KMemFile���ڴ�й©���⡣
//
