   /*************************************************************************
�ļ���: FormVect.cpp
˵��:	����������WPS98��ʽ�༭���ܵ�һ����, ����ʵ�ָ�����ѧʽ.
���:	��ѧ��
����:	1998�� 7��14��
************************************************************************/

#include "stdafx.h"
#include "math.h" 

#ifndef _WPSREADER
//#include "ResID_Dlg.h"
#endif

#ifndef __WPSOBJ_H
#include "wpsobj.h"
#endif

#if !defined(AFX_KSTEXTSTRING_H_INCLUDED_)
//#include "KSTextString.h"
#endif

#ifndef __FORMULAE_H
#include "formulae.h"
#endif
#ifndef __FORMCELL_H
#include "formcell.h"
#endif
#ifndef __WPSVIEW_H
//#include "wpsview.h"
#endif
#ifndef __FRAMEOBJ_H
#include "frameobj.h"
#endif
#ifndef __WPSDOC_H
//#include "wpsdoc.h"
#endif
#ifndef __DlgOP_H
//#include "Pageop.h"
#endif

#ifndef _WPSREADER
//	#include "FormulaDlg.h"
#endif	// #ifndef _WPSREADER

#ifndef __OBJTOOL_H
//#include "objtool.h"
#endif
#ifndef __FORMABC_H
#include "formabc.h"
#endif
//#include "MainFrm.h"
#ifndef __CTRLCODE_H
//#include "ctrlcode.h"
#endif

#ifndef __PTOBJ_H
#include "ptobj.h"
#endif
#include "FormVect.h"   
#include "FormBracket.h"

#ifndef _WPSREADER
//#include "FormBracketDlg.h" 
#endif
#ifdef _GWS
extern TCHAR szSysCFontName[];
#else
extern TCHAR szDefCFontName[];
#endif

#ifndef _GWSREADER
typedef void (WINAPI* CONVPROCW)(LPWORD,DWORD);
extern CONVPROCW g_lpConvProcW;		// ��������ʱ�Ƿ���Ҫת������
#endif	// #ifndef _GWSREADER

#define FRAC_EXT	4		//��Ƿ��������ߵ����¿��ߵĳߴ磺0.4mm
#define FRAC_W		2		//�����߿���0.2mm
#define INTERVAL	4		//�����С��0.4mm
#define ARROWL		12		//��ͷ��:1.2mm 
#define ARROWH		6		//��ͷ��0.6mm

/*-----------------------------
���´�������"��/��ʽ���"�� 
------------------------------*/
//IMPLEMENT_SERIAL(CFormLabel, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormLabel, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormLabel::CFormLabel()
{                      
}

CFormLabel::~CFormLabel()
{
	ASSERT(this);
	DeleteContent();
}

void CFormLabel::DeleteContent()
{
}      


//���ܣ��������


void CFormLabel::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormLabel::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_rectLabel;
	    ar << m_LabelType;
		ar << m_LabelLocation;
		m_formulaObj.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_rectLabel;
	    ar >> m_LabelType;
		ar >> m_LabelLocation;
		m_formulaObj.Serialize(ar);
		m_formulaObj.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormLabel::Serialize_01(KSArchive& ar)
{   
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_rectLabel;
	    ar << m_LabelType;
		ar << m_LabelLocation;
		m_formulaObj.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_rectLabel;
	    ar >> m_LabelType;
		ar >> m_LabelLocation;
		m_formulaObj.Serialize(ar);
		m_formulaObj.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


/*------------------
���´�������"��ʽ"��
------------------*/
#define TAILWIDTH	8		//��ʽ��β�͵Ŀ�
#define TAILHEIGHT	6		//��ʽ��β�͵ĸ�
//IMPLEMENT_SERIAL(CFormRadical, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormRadical, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormRadical::CFormRadical()
{                      
}

CFormRadical::~CFormRadical()
{
	ASSERT(this);
	DeleteContent();
}

void CFormRadical::DeleteContent()
{
}      

void CFormRadical::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormRadical::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{	
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formExpon.Serialize(ar);
		m_formRadCell.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{   
		m_formExpon.Serialize(ar);
		m_formExpon.SetMstObj(this);
		m_formRadCell.Serialize(ar);
		m_formRadCell.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormRadical::Serialize_01(KSArchive& ar)
{	
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formExpon.Serialize(ar);
		m_formRadCell.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{   
		m_formExpon.Serialize(ar);
		m_formExpon.SetMstObj(this);
		m_formRadCell.Serialize(ar);
		m_formRadCell.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*---------------------------
���´�������"��ע��ͷ"��
----------------------------*/
//IMPLEMENT_SERIAL(CFormLabArrow, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormLabArrow, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormLabArrow::CFormLabArrow()
{                      
}

CFormLabArrow::~CFormLabArrow()
{
	ASSERT(this);
	DeleteContent();
}

void CFormLabArrow::DeleteContent()
{
}      

void CFormLabArrow::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormLabArrow::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormLabArrow::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


/*---------------------------
���´�������"���±�"��
----------------------------*/
//IMPLEMENT_SERIAL(CFormTBscript, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormTBscript, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormTBscript::CFormTBscript()
{                      
}

CFormTBscript::~CFormTBscript()
{
	ASSERT(this);
	DeleteContent();
}

void CFormTBscript::DeleteContent()
{
}      

void CFormTBscript::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormTBscript::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormTBscript::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


/*---------------------------
���´�������"��ʽ��"��
----------------------------*/
//IMPLEMENT_SERIAL(CFormPower, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormPower, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormPower::CFormPower()
{                      
}

CFormPower::~CFormPower()
{
	ASSERT(this);
	DeleteContent();
}

void CFormPower::DeleteContent()
{
}      


void CFormPower::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormPower::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   //���ݴ�ȡ
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_str;
		ar << nRingType;
	    m_formulaTop.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_str;
#ifndef _GWSREADER
		if (g_lpConvProcW)
		{
			int nLen = m_str.GetLength();
			g_lpConvProcW((WORD*)m_str.GetBuffer(nLen), nLen/2);	// ��Ҫʱת����������
			m_str.ReleaseBuffer(nLen); //��Ϊ��˫�ֽڴ��м������\0�ַ�,�����ͷ�ʱ��ָ������
		}
#endif	// #ifndef _GWSREADER
		ar >> nRingType;
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormPower::Serialize_01(KSArchive& ar)
{   //���ݴ�ȡ
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_str;
		ar << nRingType;
	    m_formulaTop.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_str;
#ifndef _GWSREADER
		if (g_lpConvProcW)
		{
			int nLen = m_str.GetLength();
			g_lpConvProcW((WORD*)m_str.GetBuffer(nLen), nLen/2);	// ��Ҫʱת����������
			m_str.ReleaseBuffer(nLen); //��Ϊ��˫�ֽڴ��м������\0�ַ�,�����ͷ�ʱ��ָ������
		}
#endif	// #ifndef _GWSREADER
		ar >> nRingType;
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*---------------------------
���´�������"����"��
----------------------------*/
//IMPLEMENT_SERIAL(CFormIntegral, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormIntegral, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormIntegral::CFormIntegral()
{                      
}

CFormIntegral::~CFormIntegral()
{
	ASSERT(this);
	DeleteContent();
}

void CFormIntegral::DeleteContent()
{
}      


void CFormIntegral::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormIntegral::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_HowMany;
		ar << m_ringed;
		ar << m_str;
		ar << m_rectChar;
		m_formula.Serialize(ar);	
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_HowMany;
		ar >> m_ringed;
		ar >> m_str;
#ifndef _GWSREADER
		if (g_lpConvProcW)
		{
			int nLen = m_str.GetLength();
			g_lpConvProcW((WORD*)m_str.GetBuffer(nLen), nLen/2);	// ��Ҫʱת����������
			m_str.ReleaseBuffer(nLen); //��Ϊ��˫�ֽڴ��м������\0�ַ�,�����ͷ�ʱ��ָ������
		}
#endif	// #ifndef _GWSREADER
		ar >> m_rectChar;
		m_formula.Serialize(ar);
		m_formula.SetMstObj(this);
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormIntegral::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_HowMany;
		ar << m_ringed;
		ar << m_str;
		ar << m_rectChar;
		m_formula.Serialize(ar);	
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_HowMany;
		ar >> m_ringed;
		ar >> m_str;
#ifndef _GWSREADER
		if (g_lpConvProcW)
		{
			int nLen = m_str.GetLength();
			g_lpConvProcW((WORD*)m_str.GetBuffer(nLen), nLen/2);	// ��Ҫʱת����������
			m_str.ReleaseBuffer(nLen); //��Ϊ��˫�ֽڴ��м������\0�ַ�,�����ͷ�ʱ��ָ������
		}
#endif	// #ifndef _GWSREADER
		ar >> m_rectChar;
		m_formula.Serialize(ar);
		m_formula.SetMstObj(this);
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


/*---------------------------
���´�������"�����µ���"��
----------------------------*/
//IMPLEMENT_SERIAL(CFormTMB, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormTMB, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormTMB::CFormTMB()
{                      
}

CFormTMB::~CFormTMB()
{
	ASSERT(this);
	DeleteContent();
}

void CFormTMB::DeleteContent()
{
}      




void CFormTMB::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormTMB::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaMid.Serialize(ar);	
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormTMB::Serialize_01(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaMid.Serialize(ar);	
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*-----------------------------
���´�������"б��ʽ"��
------------------------------*/
//IMPLEMENT_SERIAL(CFormDivide, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormDivide, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormDivide::CFormDivide()
{                      
}

CFormDivide::~CFormDivide()
{
	ASSERT(this);
	DeleteContent();
}

void CFormDivide::DeleteContent()
{
}      

void CFormDivide::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormDivide::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   //���ݴ�ȡ
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{ 
	    m_formulaTop.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormDivide::Serialize_01(KSArchive& ar)//WPS98���ݴ�ȡ
{   //���ݴ�ȡ
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{ 
	    m_formulaTop.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*-----------------------------
���´�������"�³�ʽ"��
------------------------------*/
//IMPLEMENT_SERIAL(CFormRemain, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormRemain, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormRemain::CFormRemain()
{                      
}

CFormRemain::~CFormRemain()
{
	ASSERT(this);
	DeleteContent();
}

void CFormRemain::DeleteContent()
{
}      
void CFormRemain::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormRemain::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{ 
	    m_formulaLeft.Serialize(ar);
		m_formulaIn.Serialize(ar);
		m_formulaRight.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		m_formulaLeft.Serialize(ar);
		m_formulaLeft.SetMstObj(this);
		m_formulaIn.Serialize(ar);
		m_formulaIn.SetMstObj(this);
		m_formulaRight.Serialize(ar);
		m_formulaRight.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormRemain::Serialize_01(KSArchive& ar)//WPS98���ݴ�ȡ
{   
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{ 
	    m_formulaLeft.Serialize(ar);
		m_formulaIn.Serialize(ar);
		m_formulaRight.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		m_formulaLeft.Serialize(ar);
		m_formulaLeft.SetMstObj(this);
		m_formulaIn.Serialize(ar);
		m_formulaIn.SetMstObj(this);
		m_formulaRight.Serialize(ar);
		m_formulaRight.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}




/*-----------------------------
���´�������"���в��"��
------------------------------*/
//IMPLEMENT_SERIAL(CFormTM, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormTM, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormTM::CFormTM()
{                      
}

CFormTM::~CFormTM()
{
	ASSERT(this);
	DeleteContent();
}

void CFormTM::DeleteContent()
{
}      
void CFormTM::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormTM::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaMid.Serialize(ar);	
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormTM::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaMid.Serialize(ar);	
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


/*-----------------------------
���´�������"���²��"��	 
------------------------------*/
//IMPLEMENT_SERIAL(CFormMB, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormMB, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormMB::CFormMB()
{                      
}

CFormMB::~CFormMB()
{
	ASSERT(this);
	DeleteContent();
}

void CFormMB::DeleteContent()
{
}      

void CFormMB::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormMB::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaMid.Serialize(ar);	
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormMB::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		m_formulaMid.Serialize(ar);	
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


/*-----------------------------
���´�������"������"��
-----------------------------*/
//IMPLEMENT_SERIAL(CFormFuntion, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormFuntion, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormFuntion::CFormFuntion()
{                      
}

CFormFuntion::~CFormFuntion()
{
	ASSERT(this);
	DeleteContent();
}

void CFormFuntion::DeleteContent()
{
}  
    
void CFormFuntion::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormFuntion::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   //���ݴ�ȡ
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_nLineKind;
		ar << m_nOutputKind;
	    m_form.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_nLineKind;
		ar >> m_nOutputKind;
		m_form.Serialize(ar);
		m_form.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormFuntion::Serialize_01(KSArchive& ar)
{   //���ݴ�ȡ
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_nLineKind;
		ar << m_nOutputKind;
	    m_form.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_nLineKind;
		ar >> m_nOutputKind;
		m_form.Serialize(ar);
		m_form.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}


//IMPLEMENT_SERIAL(CChemLink, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CChemLink, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CChemLink::CChemLink()
{                      
}

CChemLink::~CChemLink()
{
	ASSERT(this);
	DeleteContent();
}

void CChemLink::DeleteContent()
{
}      

void CChemLink::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CChemLink::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		for(int i = 0; i < 8; i++)
			ar << m_nBondData[i];
		m_ChemBondObj.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		for(int i = 0; i < 8; i++)
			ar >> m_nBondData[i];
	   	m_ChemBondObj.Serialize(ar);
		m_ChemBondObj.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CChemLink::Serialize_01(KSArchive& ar)
{   
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		for(int i = 0; i < 8; i++)
			ar << m_nBondData[i];
		m_ChemBondObj.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		for(int i = 0; i < 8; i++)
			ar >> m_nBondData[i];
	   	m_ChemBondObj.Serialize(ar);
		m_ChemBondObj.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*----------------------------------
���´������ڻ�ѧ��״�ṹʽ��
-----------------------------------*/
//IMPLEMENT_SERIAL(CChemRing, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CChemRing, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CChemRing::CChemRing()
{                      
}

CChemRing::~CChemRing()
{
	ASSERT(this);
	DeleteContent();
}

void CChemRing::DeleteContent()
{
	for (int i=0; i<m_objArray.GetSize(); i++)	//	ע��m_objArray�ڶ�̬�仯
		delete m_objArray[i];
	m_objArray.RemoveAll();
}      

void CChemRing::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CChemRing::Serialize_98(KSArchive& ar)
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nRingNum;
	    ar << m_nCenterCirKind;
		for(int i=0;i<6;i++)
		{	
			ar << m_nElem[i];
		    ar << m_nBondData[i];
		}
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_nRingNum;
		ar >> m_nCenterCirKind;
		for(int i=0;i<6;i++)
		{
			ar >> m_nElem[i];
			ar >> m_nBondData[i];
		}
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n=0; n<m_nRingNum; n++)
		{	
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj(this);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CChemRing::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nRingNum;
	    ar << m_nCenterCirKind;
		for(int i=0;i<6;i++)
		{	
			ar << m_nElem[i];
		    ar << m_nBondData[i];
		}
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_nRingNum;
		ar >> m_nCenterCirKind;
		for(int i=0;i<6;i++)
		{
			ar >> m_nElem[i];
			ar >> m_nBondData[i];
		}
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n=0; n<m_nRingNum; n++)
		{	
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj(this);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

/*--------------------------------
���´������ڻ�ѧ��״��дʽ��
--------------------------------*/
//IMPLEMENT_SERIAL(CChemLogogram, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CChemLogogram, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CChemLogogram::CChemLogogram()
{                      
}

CChemLogogram::~CChemLogogram()
{
	ASSERT(this);
	DeleteContent();
}

void CChemLogogram::DeleteContent()
{
}      

void CChemLogogram::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CChemLogogram::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nWhatKind;
		ar << m_nCirKind;
		ar << m_bHasCross;
		for(int i=0;i<6;i++)
		    ar << m_nBondData[i];
	}		
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_nWhatKind;
		ar >> m_nCirKind;
		ar >> m_bHasCross;
		int nVersion = ar.GetObjectSchema();
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
			{	switch(m_nWhatKind)
				{	
				case 0://THREE_EDGE:
				case 1://FOUR_EDGE:
					break;
				case 2://FIVE_EDGE_T:
					{	for(int i=0;i<6;i++)
							m_nBondData[i]=1;
					}
				break;
				default:
					{
						m_nWhatKind ++;
						m_nBondData[0]=2;
						m_nBondData[1]=1;
						m_nBondData[2]=2;
						m_nBondData[3]=1;
						m_nBondData[4]=2;
						m_nBondData[5]=1;
					}
				}
			}
			break;
			case 1:
			{	
				for(int i=0;i<6;i++)
					ar >> m_nBondData[i];
			}
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CChemLogogram::Serialize_01(KSArchive& ar)
{   
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nWhatKind;
		ar << m_nCirKind;
		ar << m_bHasCross;
		for(int i=0;i<6;i++)
		    ar << m_nBondData[i];
	}		
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_nWhatKind;
		ar >> m_nCirKind;
		ar >> m_bHasCross;
		int nVersion = ar.GetObjectSchema();
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
			{	switch(m_nWhatKind)
				{	
				case 0://THREE_EDGE:
				case 1://FOUR_EDGE:
					break;
				case 2://FIVE_EDGE_T:
					{	for(int i=0;i<6;i++)
							m_nBondData[i]=1;
					}
				break;
				default:
					{
						m_nWhatKind ++;
						m_nBondData[0]=2;
						m_nBondData[1]=1;
						m_nBondData[2]=2;
						m_nBondData[3]=1;
						m_nBondData[4]=2;
						m_nBondData[5]=1;
					}
				}
			}
			break;
			case 1:
			{	
				for(int i=0;i<6;i++)
					ar >> m_nBondData[i];
			}
		}
	}
	CWPSObj::SerializeObjType(ar);
}

//�������㻭����





#ifndef _WPSREADER


//	��Ϊ pObj ����ʽ�ڲ������š�
//	���룺dw,dh �� pObj ����Ŀ��߸ı���
//	�����dw,dh �ǵ����󱾶���Ŀ�������


// point is in logical coordinates of formulae

#endif

/*---------------------------
���´�������"��ѧ��Ӧʽ"��
----------------------------*/
//IMPLEMENT_SERIAL(CChemResponse, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CChemResponse, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CChemResponse::CChemResponse()
{                      
}

CChemResponse::~CChemResponse()
{
	ASSERT(this);
	DeleteContent();
}

void CChemResponse::DeleteContent()
{
}      



void CChemResponse::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CChemResponse::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   //���ݴ�ȡ
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{ 
	    m_formulaTop.Serialize(ar);
	    m_formulaMid.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj(this);
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CChemResponse::Serialize_01(KSArchive& ar)
{   //���ݴ�ȡ
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{ 
	    m_formulaTop.Serialize(ar);
	    m_formulaMid.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj(this);
		m_formulaMid.Serialize(ar);
		m_formulaMid.SetMstObj(this);
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*-----------------
���´������ڶ��Ƽ���
------------------*/
//IMPLEMENT_SERIAL(CChemBond, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CChemBond, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CChemBond::CChemBond()
{                      
}

CChemBond::~CChemBond()
{
	ASSERT(this);
	DeleteContent();
}

void CChemBond::DeleteContent()
{
}      

void CChemBond::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CChemBond::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{   
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nDirection;
		ar << m_nBondKind;
		ar << m_nBondLength;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_nDirection;
		ar >> m_nBondKind;
		ar >> m_nBondLength;
	}
	CWPSObj::SerializeObjType(ar);
}

void CChemBond::Serialize_01(KSArchive& ar)
{   
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nDirection;
		ar << m_nBondKind;
		ar << m_nBondLength;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_nDirection;
		ar >> m_nBondKind;
		ar >> m_nBondLength;
	}
	CWPSObj::SerializeObjType(ar);
}

void DrawPointLine(CDC* pDC,CPoint pointS, CPoint pointE, int nCount ,int nPointSize=3);
void DrawPointLine(CDC* pDC,CPoint pointS, CPoint pointE, int nCount ,int nPointSize/*=3*/)
{
	int ndx,ndy;
	ndx=(pointE.x-pointS.x)/nCount;
	ndy=(pointE.y-pointS.y)/nCount;
	for(int i=0;i<=nCount-1;i++)
		pDC->Ellipse(CRect(CPoint(pointS.x+ndx/2+ndx*i-1,pointS.y+ndy/2+ndy*i-1),CSize(nPointSize,nPointSize)));
}


/*---------------------------
���´�������"��Ӧ����"��
----------------------------*/
//IMPLEMENT_SERIAL(CChemRespSym, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CChemRespSym, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CChemRespSym::CChemRespSym()
{                      
}

CChemRespSym::~CChemRespSym()
{
	ASSERT(this);
	DeleteContent();
}

void CChemRespSym::DeleteContent()
{
}      

void CChemRespSym::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CChemRespSym::Serialize_98(KSArchive& ar)//WPS98���ݴ�ȡ
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar <<m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >>m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CChemRespSym::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar <<m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >>m_ArrowType;
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj(this);
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj(this);
	}
	CWPSObj::SerializeObjType(ar);
}

