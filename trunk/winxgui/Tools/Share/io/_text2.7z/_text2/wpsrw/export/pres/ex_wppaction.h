/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wppsound.h
//	������		��	liupeng
//	����ʱ��	��	2005-4-2 15:49:48
//	��������	��	
//
// -----------------------------------------------------------------------*/

#ifndef _EX_WPPSOUND_H__
#define _EX_WPPSOUND_H__

#ifndef __KFC_IO_ARCHIVE_H__
#include "kfc/io/archive.h"
#endif

#ifndef __KSO_IO_CONTENTHANDLER_H__
#include <kso/io/contenthandler.h>
#endif

#ifndef __KSO_IO_SCHEMA_H__
#include <kso/io/schema.h>
#endif

#ifndef __KSO_IO_V6_STD_SCHEMA_OFFICE_H__
#include "kso/io/v6/std/schema_office.h"
#endif


#ifndef __KFC_COMPRESSION_ZLIB_H__
#include <kfc/compression/zlib.h>
#endif

#ifndef __KFC_ALLOCATER_KERNDATA_H__
#include "kfc/allocater/kerndata.h"
#endif

//
#ifndef __IOACCEPTOR_H__
#include "ioacceptor/ioacceptor.h"
#endif

#ifndef __IOHEADER_IOHEADER_H__
#include "ioheader/ioheader.h"
#endif

#ifndef __MSO_IO_BASIC_LOCKBUFFER_H__
#include "mso/io/basic/lockbuffer.h"
#endif

#ifndef __MSO_IO_BASIC_AUTOFREE_H__
#include "mso/io/basic/autofree.h"
#endif

#ifndef __STL_ALGORITHM_H__
#include <stl/algorithm.h>
#endif

#ifndef __STL_HASH_SET_H__
#include <stl/hash_set.h>
#endif

#ifndef __MSO_IO_POWERPOINT_WRITER_H__
#include "mso/io/powerpoint/writer.h"
#endif

#ifndef __PPTFMT_PPTHELP_H__
#include "pptfmt/ppthelp.h"
#endif

//=======
//extern HRESULT ExportShapeAction(CWPSObj* pObj, CWPPDocContext* context,
//						  KPPTClientData* client, BOOL bIsPlaceHolder = FALSE,
//						  KPPTClientTextBox* pBox = NULL);
#endif