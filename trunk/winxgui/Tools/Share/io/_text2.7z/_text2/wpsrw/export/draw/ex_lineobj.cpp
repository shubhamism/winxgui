/* -------------------------------------------------------------------------
//	�ļ���		��	ex_lineobj.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-23 9:38:34
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_ptobj.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern void GetRotatePoint( CPoint* point, const CPoint& center, const int theta);

//////////////////////
//
//
typedef std::vector<INT16> INT16vector;

// liupeng:��GDI���͵�path����ת����ppt�ļ��еĵ���������
// ����������ݸ�ʽ�����뿴\Document\arch\drawing\����ʽ���ݷ���.txt

EX_SHAPE_API gConvertPath(KPointList& PointList, 
						  KFlagList& FlagsList, 
						  INT16vector& rgVertices,
						  INT16vector& rgSegmentInfo,
						  CPoint& pointRel)
{
#ifdef _DEBUG
	int nVecs = PointList.GetCount();
	int iCount = FlagsList.GetCount();
	ASSERT(nVecs == iCount);
	{
		POSITION posVer;
		posVer = PointList.GetHeadPosition();
		while(posVer != NULL)
		{
			CPoint point = PointList.GetNext(posVer);
			ASSERT(point.x >= pointRel.x);
			ASSERT(point.y >= pointRel.y);
			ASSERT(point.x - pointRel.x < 65536);
			ASSERT(point.y - pointRel.y < 65536);
		}
	}
#endif

	int iPos = 0;
	POSITION posSeg, posVer;
	BYTE byFlag, lastFlag;
	posSeg = FlagsList.GetHeadPosition();
	posVer = PointList.GetHeadPosition();
	while(posSeg != NULL)
	{
		byFlag = FlagsList.GetNext(posSeg);
		if (byFlag == PT_MOVETO)
		{
			rgSegmentInfo.push_back((INT16)0x4000);
			ASSERT(posVer);
			if (!posVer)
				break;
			CPoint point = PointList.GetNext(posVer);
			rgVertices.push_back((INT16)(point.x - pointRel.x));
			rgVertices.push_back((INT16)(point.y - pointRel.y));
			lastFlag = byFlag;
		}

		if (byFlag == PT_LINETO)
		{
			rgSegmentInfo.push_back((INT16)0xac00); // AutioLine
			rgSegmentInfo.push_back((INT16)0x0001);	
			ASSERT(posVer);
			if (!posVer)
				break;
			CPoint point = PointList.GetNext(posVer);
			rgVertices.push_back((INT16)(point.x - pointRel.x));
			rgVertices.push_back((INT16)(point.y - pointRel.y));
			lastFlag = byFlag;
		}
			
		if (byFlag == PT_BEZIERTO)
		{
			rgSegmentInfo.push_back((INT16)0xad00);	// AutoCurve
			rgSegmentInfo.push_back((INT16)0x2001);
			ASSERT(posVer);
			if (!posVer)
				break;
			CPoint point = PointList.GetNext(posVer);
			rgVertices.push_back((INT16)(point.x - pointRel.x));
			rgVertices.push_back((INT16)(point.y - pointRel.y));
			ASSERT(posVer);
			if (!posVer)
				break;
			point = PointList.GetNext(posVer);
			rgVertices.push_back((INT16)(point.x - pointRel.x));
			rgVertices.push_back((INT16)(point.y - pointRel.y));
			ASSERT(posVer);
			if (!posVer)
				break;
			point = PointList.GetNext(posVer);
			rgVertices.push_back((INT16)(point.x - pointRel.x));
			rgVertices.push_back((INT16)(point.y - pointRel.y));

			if (!posSeg)
				break;
			byFlag = FlagsList.GetNext(posSeg);
			if (!posSeg)
				break;
			byFlag = FlagsList.GetNext(posSeg);
			lastFlag = byFlag;
		}
			
		if (byFlag & PT_CLOSEFIGURE)
		{
			rgSegmentInfo.push_back((INT16)0x6001);
			lastFlag = byFlag;
		}

	}
	if (lastFlag == PT_BEZIERTO)
		rgSegmentInfo.push_back((INT16)0xac00);
	rgSegmentInfo.push_back((INT16)0x8000);
	ASSERT(!posVer);

}

EX_SHAPE_API gConvertPolyObj(KPointList& PointList, KFlagList& FlagsList,
								   int nPolyobjShape, int nEndStyle,
								   CWPSObj* pObj,
								   CShape_Context& context,
								   CRect* pRectRel)
{
{
#ifdef _DEBUG
	{
		TRACE(__X("gConvertPolyObj(nPolyobjShape=%d):list points and flags...\n"), nPolyobjShape);
		POSITION pos = PointList.GetHeadPosition();
		CPoint point;
		BYTE byFlag;
		while (pos != NULL)
		{
			point = PointList.GetNext(pos);
			TRACE(__X("(%d, %d)\n"), point.x, point.y);
		}

		pos = FlagsList.GetHeadPosition();
		while (pos != NULL)
		{
			byFlag = FlagsList.GetNext(pos);
			TRACE(__X("flag:%d\n"), byFlag);
		}
		TRACE(__X("gConvertPolyObj():end\n"));
	}
#endif

	INT16vector rgVertices;
	INT16vector rgSegmentInfo;
	CPoint pointRel;
	if (pRectRel)
	{
		pointRel.x = pRectRel->left;
		pointRel.y = pRectRel->top;
	}
	else
	{
		pointRel.x = pObj->m_rect.left;
		pointRel.y = pObj->m_rect.top;
	}

	gConvertPath(PointList, FlagsList, rgVertices, rgSegmentInfo, pointRel);

	//
	//IMsoArray��ǰ���ṹ��
	FMsoArrayHeader pVerticesHead, pSegmentInfoHead;
	pVerticesHead.size = (INT16)0xfff0;//�˵���һ����,4�ֽڴ�,Ȼ��Ҫ��ɴ�
	pVerticesHead.count = pVerticesHead.cntInMem = rgVertices.size() / 2;
	pSegmentInfoHead.size = sizeof(INT16);//segmentԪ�ش�С
	pSegmentInfoHead.count = rgSegmentInfo.size();
	pSegmentInfoHead.cntInMem = pSegmentInfoHead.count + (nEndStyle ? 2 : 1);

	//
	//��ǰ���ṹ��������ϲ���һ��
	rgVertices.insert(rgVertices.begin(), pVerticesHead.size);
	rgVertices.insert(rgVertices.begin(), pVerticesHead.cntInMem);
	rgVertices.insert(rgVertices.begin(), pVerticesHead.count);
	rgSegmentInfo.insert(rgSegmentInfo.begin(), pSegmentInfoHead.size);
	rgSegmentInfo.insert(rgSegmentInfo.begin(), pSegmentInfoHead.cntInMem);
	rgSegmentInfo.insert(rgSegmentInfo.begin(), pSegmentInfoHead.count);
	//

	//
	//����ָ��
	context.m_shape.SetShapeType(msosptNotPrimitive);
	CRect rc = NULL;
	if (pRectRel)
		rc = pRectRel;
	else
		rc = pObj->GetMrect();

//	if(xMin < 0)
//	{
//		context.m_opt.AddPropFix(msopt_geoLeft, WpsShapeToTwip(-xMin));
//	}
//	if(yMin < 0)
//	{
//		context.m_opt.AddPropFix(msopt_geoTop, WpsShapeToTwip(-yMin));
//	}
	context.m_opt.AddPropFix(msopt_geoRight, /*WpsShapeToTwip*/(rc.Width() /*+ (-xMin)*/));
	context.m_opt.AddPropFix(msopt_geoBottom, /*WpsShapeToTwip*/(rc.Height() /*+ (-yMin)*/));
	context.m_opt.AddPropFix(msopt_shapePath, msoshapeComplex);
	context.m_opt.AddPropVar(msopt_pVertices, &rgVertices[0], 
		rgVertices.size() * sizeof(INT16));
	context.m_opt.AddPropVar(msopt_pSegmentInfo, &rgSegmentInfo[0],
		rgSegmentInfo.size() * sizeof(INT16));
}
}

EX_SHAPE_API gConvertPolyObj(KPointList& PointList, KFlagList& FlagsList,
								   int nPolyobjShape, int nEndStyle,
								   CWPSObj* pObj,
								   CShape_Context& context)
{
	gConvertPolyObj(PointList, FlagsList, nPolyobjShape, nEndStyle, pObj, context, NULL);
}

EX_SHAPE_API CLineObj_Export::ConvertShape(CShape_Context& context)
{
	if(m_nlineobjShape == CLineObj::linkLine || m_nlineobjShape == CLineObj::linkBezier)
	{
		KPointList PointList;
		KFlagList FlagsList;
		CPoint point1, point2;
		BYTE byFlag;
		//
		PointList.AddTail(m_linepnt[0]);
		byFlag = PT_MOVETO;
		FlagsList.AddTail(byFlag);
		//
		byFlag = m_nlineobjShape == CLineObj::linkLine ? PT_LINETO : PT_BEZIERTO;
		point1.x = m_bVert == 0 ? (m_handle3.x + m_linepnt[0].x) : m_linepnt[0].x;
		point1.y = m_bVert == 0 ? m_linepnt[0].y : (m_linepnt[0].y + m_handle3.y);
		PointList.AddTail(point1);
		FlagsList.AddTail(byFlag);
		//
		point2.x = m_bVert == 0 ? point1.x : m_linepnt[1].x;
		point2.y = m_bVert == 0 ? m_linepnt[1].y : point1.y;
		PointList.AddTail(point2);
		FlagsList.AddTail(byFlag);
		//
		PointList.AddTail(m_linepnt[1]);
		FlagsList.AddTail(byFlag);

		gConvertPolyObj(PointList, FlagsList,
			m_nlineobjShape == CLineObj::linkLine ? CPolyObj::polyLine : CPolyObj::bezierLine,
			ES_Open, this, context, NULL);
		return;
	}

	
	//***
	//FlipH & FlipV
	//
	//ˮƽ�봹ֱ�ķ�ת,����m_linepnt[2],��m_linepnt[0]ĳֵ����m_linepnt[1]ĳֵ,��������Ӧ�ķ�ת
	//if(this->m_linepnt[0].x > this->m_linepnt[1].x)
	//	context.m_shape.SetFlipH(TRUE);
	//if(this->m_linepnt[0].y > this->m_linepnt[1].y)
	//	context.m_shape.SetFlipV(TRUE);

	CPoint pointStart, pointEnd;           //�ߵ�������յ�
	
	pointStart = m_linepnt[0];
	pointEnd = m_linepnt[1];
	::GetRotatePoint(&pointStart, m_center, m_theta);
	::GetRotatePoint(&pointEnd, m_center, m_theta);

	if (pointStart.y > pointEnd.y) //���������ȿ�ʼ�㻹�ߣ�����Ҫ�Ի�
	{
		CPoint pt;
		pt = pointStart;
		pointStart = pointEnd;
		pointEnd = pt;
	}
	//�ж��Ƿ���Ҫ��ת��Ҫʹ��δ��תǰ�ĵ���У��ƺ�WORD�����ȷ�ת�������ת�ġ�
	pointStart = m_linepnt[0];
	pointEnd = m_linepnt[1];
	
	long nFlipH = 0;
	long nFlipV = 0;
	BOOL bNegative = FALSE; //@@todo:�������������߽Ƕ�ת����Ŀǰֻ��ˮƽ�߲����˴�������ˮƽ�߿��ܻ����쳣���
	if (pointStart.x == pointEnd.x || pointStart.y == pointEnd.y)	// �������������ϵ����
	{
		if (pointStart == pointEnd)
		{
			nFlipV = 0;
			nFlipH = 0;
			bNegative = TRUE;
		}
		else if (pointStart.x == pointEnd.x)
		{
			if (pointStart.y > pointEnd.y)
			{
				nFlipV = 1;
				bNegative = TRUE;
			}
			else
				nFlipV = 0;
		}
		else if (pointStart.y == pointEnd.y)
		{
			if (pointStart.x > pointEnd.x)
				nFlipH = 1;
			else nFlipV = 1;
			bNegative = TRUE;
		}		
	}
	else if (pointStart.x <= pointEnd.x && pointStart.y <= pointEnd.y)    //��ʼ�������Ͻ�
	{
		nFlipH = 0;
		nFlipV = 0;
	}
	else if (pointStart.x < pointEnd.x && pointStart.y > pointEnd.y)  //�����½�
	{
		nFlipH = 0;
		nFlipV = 1;
	}
	else if (pointStart.x > pointEnd.x && pointStart.y > pointEnd.y)  //�����½�
	{
		nFlipH = 1;
		nFlipV = 1;
	}
	else if (pointStart.x > pointEnd.x && pointStart.y < pointEnd.y)       //�����Ͻ�
	{
		nFlipH = 1;
		nFlipV = 0;
	}

	if (nFlipH == 1)
		context.m_shape.SetFlipH(TRUE);
	if (nFlipV == 1)
		context.m_shape.SetFlipV(TRUE);

	/*
	 *	��ת�Ƕ� msopt_Rotation(4)
	 *  
	 */
	
	INT32 nAngle = m_theta / 10;
	ASSERT(nAngle > -360 && nAngle < 360);
	if (nAngle)
	{
		if(nAngle < 0)
			nAngle = -nAngle;
		else
			nAngle = 360 - nAngle;
		if (nFlipV != nFlipH || bNegative)
			nAngle = 65536 - nAngle;
		
		int nIndex = context.m_opt.FindProp(msopt_Rotation);
		if (nIndex == -1)
			context.m_opt.AddPropFix(msopt_Rotation, nAngle << 16);
		else
			context.m_opt.ModifyPropFix(nIndex, msopt_Rotation, nAngle << 16);
	}
	
	if(m_nlineobjShape == CLineObj::line)
	{
		context.m_shape.SetShapeType(msosptLine);

	}
	else
	{
		ASSERT(FALSE);
	}
}

//	����ǰ��ת����תǰ�ĵ�
void GetNoRotatePoint( CPoint& point,
					   const CPoint& center,
					   const int theta)
{
	double dx, dy;
	dx =  point.x - center.x;
	dy =  point.y - center.y;
	double tht = theta*PI/1800;
	double cost = cos( -tht);
	double sint = sin( -tht);
	point.x = center.x + (int)(dx*cost - dy*sint);
	point.y = center.y + (int)(dx*sint + dy*cost);
}

//�����
EX_SHAPE_API CPolyObj_Export::ConvertShape(CShape_Context& context)
{
	// liupeng: m_PointList������Ǿ�������, ��ת����v6֮ǰҪת�������
	// ����, �������ת��Ҫ������ת����������.
	if (!m_theta)
		gConvertPolyObj(m_PointList, m_FlagsList, m_nPolyobjShape, m_nEndStyle, this, context, NULL);
	else
	{
		int left = INT_MAX;
		int top = INT_MAX;
		int right = INT_MIN;
		int bottom = INT_MIN;

		POSITION pos = m_PointList.GetHeadPosition();
		CPoint pointnew;
		while (pos != NULL)
		{
			pointnew = m_PointList.GetNext(pos);
			if (pointnew.x < left)
				left = pointnew.x;
			if (pointnew.y < top)
				top = pointnew.y;
			if (pointnew.x > right)
				right = pointnew.x;
			if (pointnew.y > bottom)
				bottom = pointnew.y;
		}
		CRect rc;
		rc.left = left;
		rc.top = top;
		rc.bottom = bottom;
		rc.right = right;

		gConvertPolyObj(m_PointList, m_FlagsList, m_nPolyobjShape, m_nEndStyle, this, context, &rc);
	}
}

//

// ����BeZier����߶�
void CalcBeZierPoints( const CPoint* pnt, CPoint* p, int num, float s)
{
	double t = 0.0;
	double tx,ty;
	for ( int i=0; i<num; i++)
	{
		tx = (1-t)*(1-t)*(1-t)*pnt[0].x + 3*t*(1-t)*(1-t)*pnt[1].x
		   + 3*t*t*(1-t)*pnt[2].x 		+ t*t*t*pnt[3].x;
		ty = (1-t)*(1-t)*(1-t)*pnt[0].y + 3*t*(1-t)*(1-t)*pnt[1].y
		   + 3*t*t*(1-t)*pnt[2].y 		+ t*t*t*pnt[3].y;
		p[i].x = (int) tx;
		p[i].y = (int) ty;
		t += s;
	}
	tx = pnt[3].x;
	ty = pnt[3].y;
	p[num].x = (int) tx;
	p[num].y = (int) ty;
}

CRect GetPointBox(CPoint* p, int num)
{
	CRect res;
	res.left = INT_MAX;
	res.top = INT_MAX;
	res.bottom = INT_MIN;
	res.right = INT_MIN;
	int i = 0;
	for (i = 0; i < num; i ++)
	{
		if (p[i].x < res.left)
			res.left = p[i].x;
		if (p[i].x > res.right)
			res.right = p[i].x;
		if (p[i].y < res.top)
			res.top = p[i].y;
		if (p[i].y > res.bottom)
			res.bottom = p[i].y;
	}
	return res;
}

// liupeng: bugid 15233 ���ߵ���������Զ��������
EX_SHAPE_API CCurveObj_Export::ConvertShape(CShape_Context& context)
{
	typedef std::vector<INT16> INT16vector;
	INT16vector rgVertices;
	INT16vector rgSegmentInfo;
	
	rgSegmentInfo.push_back((INT16)0x4000);//��ʼ
	rgSegmentInfo.push_back((INT16)0xad00);
	rgSegmentInfo.push_back((INT16)0x2001);//д�������Ƶ�,һ���˵�
	rgSegmentInfo.push_back((INT16)0xac00);
	rgSegmentInfo.push_back((INT16)0x8000);//����segment

	float s = 0.01f;
	int num = (int)(1/s);
	CPoint* p = (CPoint*)new BYTE[ (num+1)*sizeof(CPoint) ];
	CalcBeZierPoints( m_curvepnt, p, num, s);
	CRect box = GetPointBox(p, num + 1);
	delete[] p;

	for(int i = 0; i < 4; i++)
	{
		rgVertices.push_back((INT16)(m_curvepnt[i].x - box.left));
		rgVertices.push_back((INT16)(m_curvepnt[i].y - box.top));
	}

	FMsoArrayHeader pVerticesHead, pSegmentInfoHead;
	pVerticesHead.size = (INT16)0xfff0;//�˵���һ����,4�ֽڴ�,Ȼ��Ҫ��ɴ�
	pVerticesHead.count = pVerticesHead.cntInMem = rgVertices.size() / 2;
	pSegmentInfoHead.size = sizeof(INT16);//segmentԪ�ش�С
	pSegmentInfoHead.count = rgSegmentInfo.size();
	pSegmentInfoHead.cntInMem = pSegmentInfoHead.count;

	rgVertices.insert(rgVertices.begin(), pVerticesHead.size);
	rgVertices.insert(rgVertices.begin(), pVerticesHead.cntInMem);
	rgVertices.insert(rgVertices.begin(), pVerticesHead.count);
	rgSegmentInfo.insert(rgSegmentInfo.begin(), pSegmentInfoHead.size);
	rgSegmentInfo.insert(rgSegmentInfo.begin(), pSegmentInfoHead.cntInMem);
	rgSegmentInfo.insert(rgSegmentInfo.begin(), pSegmentInfoHead.count);
	
	context.m_shape.SetShapeType(msosptNotPrimitive);
	CRect rc = GetMrect();
	context.m_opt.AddPropFix(msopt_geoRight, /*WpsShapeToTwip*/(box.Width() /*+ (-xMin)*/));
	context.m_opt.AddPropFix(msopt_geoBottom, /*WpsShapeToTwip*/(box.Height() /*+ (-yMin)*/));
	context.m_opt.AddPropFix(msopt_shapePath, msoshapeComplex);
	context.m_opt.AddPropVar(msopt_pVertices, &rgVertices[0], 
		rgVertices.size() * sizeof(INT16));
	context.m_opt.AddPropVar(msopt_pSegmentInfo, &rgSegmentInfo[0],
		rgSegmentInfo.size() * sizeof(INT16));
}

EX_SHAPE_API CCurveObj_Export::GetShapeRect(CShape_Context& context, CRect& rcOut )
{
	if (m_theta)
	{
		float s = 0.01f;
		int num = (int)(1/s);
		CPoint* p = (CPoint*)new BYTE[ (num+1)*sizeof(CPoint) ];
		CalcBeZierPoints( m_curvepnt, p, num, s);
		CRect rct = GetPointBox(p, num + 1);
		delete[] p;
		
		int nThea = 0;
		nThea = m_theta + nThea;
		nThea = nThea > 0 ? 360 - nThea / 10 : -nThea / 10;
		if(45 <= nThea && nThea < 135
			|| 225 <= nThea && nThea < 315)
		{
			SWAPWH(rct);
		}
		rcOut = rct;
	}
}

// -------------------------------------------------------------------------

EX_SHAPE_API CPolyObj_Export::GetShapeRect(CShape_Context& context, CRect& rcOut, BOOL b)
{
	if (m_theta)
	{
		POSITION pos = m_PointList.GetHeadPosition();
		CPoint pointnew;
		int left = INT_MAX;
		int top = INT_MAX;
		int right = INT_MIN;
		INT bottom = INT_MIN;

		while (pos != NULL)
		{
			pointnew = m_PointList.GetNext(pos);
			// GetNoRotatePoint(pointnew, m_center, m_theta);
			if (pointnew.x < left)
				left = pointnew.x;
			if (pointnew.x > right)
				right = pointnew.x;
			if (pointnew.y < top)
				top = pointnew.y;
			if (pointnew.y > bottom)
				bottom = pointnew.y;
		}
		CRect rct;
		rct.left = left;
		rct.top = top;
		rct.right = right;
		rct.bottom = bottom;

		int nWidth = rct.Width();
		int nHeight = rct.Height();

		
		int nThea = 0;
		nThea = m_theta + nThea;
		nThea = nThea > 0 ? 360 - nThea / 10 : -nThea / 10;
		if(45 <= nThea && nThea < 135
			|| 225 <= nThea && nThea < 315)
		{
			SWAPWH(rct);
		}
		rcOut = rct;
	}
}

// -------------------------------------------------------------------------

EX_SHAPE_API CLineObj_Export::GetShapeRect(CShape_Context& context, CRect& rcOut)
{	
	CRect rct = rcOut;
	int nThea = 0;
	
	nThea = m_theta + nThea;

	CRect rct1;
	rct1.left = m_linepnt[0].x;
	rct1.top = m_linepnt[0].y;
	rct1.right = m_linepnt[1].x;
	rct1.bottom = m_linepnt[1].y;
	rct1.NormalizeRect();
	
	rct = RecalcObjBox(rct1, m_center, nThea);

	nThea = nThea > 0 ? 360 - nThea / 10 : -nThea / 10;
	if(45 <= nThea && nThea < 135
		|| 225 <= nThea && nThea < 315)
	{
		SWAPWH(rct);
	}
	
	rcOut = rct;
}

// -------------------------------------------------------------------------
