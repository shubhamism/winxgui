//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainComboBox.cpp
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-5-28 15:41:30
//	FileDescription	:	
//
//////////////////////////////////////////////////////////////////////////////////////

// KSDomainComboBox.cpp: implementation of the KSDomainComboBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "KSDomainComboBox.h"



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(KSDomainComboBox,CLtxtObj,0xA0 | VERSIONABLE_SCHEMA)

KSDomainComboBox::KSDomainComboBox()
{
}

KSDomainComboBox::~KSDomainComboBox()
{
	ASSERT_VALID(this);
}

KSDomainComboBox::KSDomainComboBox(const CWpsDoc* pDoc, 
							     const CRect& position, 
							   int nShape/*=rectangle*/)
					   :CLtxtObj(pDoc,position,rectangle)
{
	m_bSelect = FALSE;
	m_uLPenStyle = PS_NULL;
//	KCOLORINDEX indexBkColor;
//	KColorModel::RGBToColor(indexBkColor, 192, 192, 192);

//	SetBkMode(OPAQUE);					// �����:���
//	SetBkColor(indexBkColor);		// ��ɫ
//	SetFillLogBrush(BS_HATCHED, RGB(192, 192, 192), NULL);
//	SetFillLogBrush(0, indexBkColor, 0);
}

KSDomainComboBox::KSDomainComboBox(const KSDomainComboBox* pObj)
{
	ASSERT_VALID(pObj);
//	CopyObj(pObj,TRUE);
	m_bSelect = FALSE;
	m_bBackGround = FALSE;
}

void KSDomainComboBox::Serialize_01(KSArchive& ar)
{
	CLtxtObj::Serialize_01(ar);
	int nCount = m_strArray.GetSize();
	if (ar.IsStoring())
	{
	  ar << m_bSelect;
	  ar << m_bBackGround;
	  ar << nCount;
	  for (int i = 0; i <= nCount -1; i++)
	  {
		 m_sItem = m_strArray.GetAt(i);
		 ar << m_sItem;
	  }	  
	}
	else
	{
		ar >> m_bSelect;
		ar >> m_bBackGround;
		ar >> nCount;
		CString sData;
		for (int i = 0; i <= nCount -1; i++)
		{
			ar >> sData;
			m_strArray.InsertAt(i,sData);		  
		} 		
	}

	CWPSObj::SerializeObjType(ar);
}