/* -------------------------------------------------------------------------
//	�ļ���		��	autonum.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 15:53:47
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __TEXTPOOL_H__
#include "textpool.h"
#endif

#ifndef __AUTONUM_ABGROUPINFOMAN_H__
#include "autonum_abgroupinfoman.h"
#endif

#include "autonum.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#define	TAG_WPSNullRecord		0x7fff

KPersistAutoNumber g_ANPersist;

// -------------------------------------------------------------------------
STDMETHODIMP_(IStream*) _QueryObjStream(CFile* pFile);

STDMETHODIMP ReadAutonumAtom(CFile* pFile, ULONG uID, tagAUTONUMATOM& Atom)
{
	HRESULT hr = E_FAIL;
	IStream* pStrm = _QueryObjStream(pFile);
	if(pStrm == NULL)
		return E_FAIL;

	ULONG olduID = _ioGetOffset(pStrm);
	_LARGE_INTEGER li;
	li.HighPart = 0;
	li.LowPart = uID;
	pStrm->Seek(li, STREAM_SEEK_SET, NULL);
	AUTONUMATOM_FORIO AtomForIO;
	ZeroMemory(&AtomForIO, sizeof(AUTONUMATOM_FORIO));
	hr = g_LoadAutoNumAtom(pStrm, AtomForIO);
	li.HighPart = 0;
	li.LowPart = olduID;
	pStrm->Seek(li, STREAM_SEEK_SET, NULL);
	if(FAILED(hr))
		return hr;
	Atom = AtomForIO;
	return hr;
}

// -------------------------------------------------------------------------

KPersistAutoNumber::KPersistAutoNumber()
{
	_pCurGroupMap = NULL;
	_pCurTextPool = NULL;
}
/*
STDMETHODIMP_(void) KPersistAutoNumber::Init(int fStoring)
{
}

STDMETHODIMP_(void) KPersistAutoNumber::Clear()
{
}

STDMETHODIMP_(CTextPool*) KPersistAutoNumber::EnterTextPool(CTextPool* pTextPool)
{
	return pTextPool;
}

STDMETHODIMP_(void) KPersistAutoNumber::LeaveTextPool(CTextPool* pOldPool)
{
}
*/

STDMETHODIMP_(void) KPersistAutoNumber::ReadAutonum(CFile* pFile)
{
	ASSERT(!_fStoring);
	ASSERT(_vecAutonum.size() == 0);
	if(!pFile)
		return;
	_vecAutonum.clear();
	
	KWPSRecordReader<CFile*> wr;
	wr.Attach(pFile);
	m_pFile = pFile;

	_KWPSRecordHeader hdr;
	WPSSaveAutonum recsave;
	while (wr.NextRec(&hdr) == S_OK)
	{
		if (hdr.wTag != TAG_WPSAutonumData)
			break;
		if(hdr.wSize == 4 * sizeof(short))
		{
			//��ȡ2002�汾����
			ZeroMemory(&recsave, sizeof(recsave));
			wr.Read(&recsave, sizeof(WPSAutonumData));
			_vecSave.push_back(recsave);
		}
		else
		{
			//��ȡpatch2�汾����
			ZeroMemory(&recsave, sizeof(recsave));
			wr.Read(&recsave, sizeof(recsave));
			_vecSave.push_back(recsave);
		}
	}
	ASSERT(hdr.wTag == TAG_WPSNullRecord);
	
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());

	_fBeta = 0;
}

//lijun
STDMETHODIMP_(void) KPersistAutoNumber::ReadAutonumBeta(CArchive& ar)
{
	ASSERT(!_fStoring);
	if ((_vecSave.size() != 0))
		return;
	m_pFile = ar.GetFile();
	
	KWPSRecordReader<CArchive*> wr;
	wr.Attach(&ar);
	_KWPSRecordHeader hdr;
	WPSSaveAutonum recsave;
	
	if (!_fBeta) // д��һ���ռ�¼����Ҫ������
	{
		wr.NextRec(&hdr);
		ASSERT(hdr.wTag == TAG_WPSNullRecord);
		return;
	}
//	TRACEX("{{ ---> ����һ��Beta�汾�������ļ�....\n");
	
	_vecAutonum.clear();
	while (wr.NextRec(&hdr) == S_OK)
	{
		if (hdr.wTag != TAG_WPSAutonumData)
			break;
		
		ZeroMemory(&recsave, sizeof(recsave));
		wr.Read(&recsave, sizeof(WPSAutonumData));
		
		_vecSave.push_back(recsave);
	}
	ASSERT(hdr.wTag == TAG_WPSNullRecord);
	
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());
	
	// {{ ----> ����Beta�汾���򽫳���TextPool���Զ���Ź�����֮ǰ��ȡ����
	WPSGroupPairVector::iterator iter;
	for (iter = _vecGroupPair.begin(); iter != _vecGroupPair.end(); ++iter)
	{
		WPSGroupPair& pair = *iter;
		ASSERT(pair._nGblGroupID < _vecSave.size());
		
		if (pair._nGblGroupID < _vecSave.size())
		{
			KABGROUPINFO* pElement = pair._pInfo;
			WPSSaveAutonum rec  = _vecSave[pair._nGblGroupID];
			pElement->nType		= rec.nType;
			pElement->nStyle	= rec.nStyle;
			pElement->nLevel	= rec.nLevel;
			pElement->nStartNumber = rec.nStartNumber;
			
		}
	}
	_vecGroupPair.clear();

}

// -------------------------------------------------------------------------
// ����		: HasInRefMap
// ����		: �жϸ�id�Ƿ��Ѿ��������������������ͷ���ref��ֵ
// ����ֵ	: STDMETHODIMP_(BOOL) 
// ����		: const int nID
// ����		: AUTONUMPARAREF& WPLParaRef
// ��ע		: 
// -------------------------------------------------------------------------
STDMETHODIMP_(BOOL) KPersistAutoNumber::HasInRefMap(const int nID, AUTONUMPARAREF& WPLParaRef)
{
	MapIntToRef::iterator it = m_mapIntToRef.find(nID);
	if(m_mapIntToRef.end() != it)
	{
		WPLParaRef = (*it).second;
		return TRUE;
	}
	else
		return FALSE;
}

// -------------------------------------------------------------------------
// ����		: ReadWPLParaAutonum
// ����		: 
// ����ֵ	: STDMETHODIMP 
// ����		: const int nID
// ����		: AUTONUMPARAREF& WPLParaRef
// ��ע		: 
// -------------------------------------------------------------------------
STDMETHODIMP KPersistAutoNumber::ReadWPLParaAutonum(const int nID, AUTONUMPARAREF& WPLParaRef)
{
	if(m_vecWplAutonumGroup.size() == 0)
		return E_FAIL;

	if(TRUE == HasInRefMap(nID, WPLParaRef))	// ��ѯ�Ƿ��Ѿ�������
		return S_OK;

	// �����µ��Զ��������
	KABGroupInfoMan* pAutonumMan = _pCurTextPool->GetABGroupInfoMan();

	AUTONUMGROUP *pAutoNumGroup = new AUTONUMGROUP;
	for(int i = 0; i < m_vecWplAutonumGroup[nID].nCount; ++i)
	{
		AUTONUMATOM* pAtom = m_vecWplAutonumAtom[m_vecWplAutonumGroup[nID].nID[i]];
		KAutoNumAtomSPtr	AtomSPtr;
		AtomSPtr = pAutonumMan->AddAtom(pAtom, FALSE);
		
		pAutoNumGroup->ChangeSpecialLevelData(i, AtomSPtr);
	}
	KAutoNumGroupSPtr GroupSPtr;
	GroupSPtr = pAutonumMan->AddGroup(pAutoNumGroup, TRUE);

	if(pAutoNumGroup)
		delete pAutoNumGroup;

	AUTONUMPARAREF AutoNumParaRef(GroupSPtr, 0);
	WPLParaRef = AutoNumParaRef;
	// ���뵽map��
	m_mapIntToRef.insert(MapIntToRef::value_type(nID, WPLParaRef));
		
	return S_OK;
}

STDMETHODIMP_(CTextPool*) KPersistAutoNumber::EnterTextPool(CTextPool* pNewPool)
{
	CTextPool* pOldPool	= _pCurTextPool;
	//Mgy modify for wanli bug
	MakeUp = FALSE;		//ÿ�ν���TextPoolʱ���ô˿��أ��Ӷ����¹���manager
	
	_pCurGroupMap = NULL;
	_pCurTextPool = pNewPool;
	return pOldPool;
}

STDMETHODIMP_(void) KPersistAutoNumber::LeaveTextPool(CTextPool* pOldPool)
{
	if (_pCurGroupMap)
	{
		_mapTextPool.erase(_pCurTextPool);
		delete _pCurGroupMap;
		_pCurGroupMap = NULL;
	}
	if (pOldPool)
	{
		MapTextPoolAutoNumber::iterator iter = _mapTextPool.find(pOldPool);
		if (iter != _mapTextPool.end())
			_pCurGroupMap = (*iter).second;
	}
	_pCurTextPool = pOldPool;
}

STDMETHODIMP_(void) KPersistAutoNumber::Clear()
{
	_vecSave.clear();
	_vecAutonum.clear();
	_vecGroupPair.clear();
	m_mapLevel.clear();

	ASSERT(_mapTextPool.size() == 0);

	MapTextPoolAutoNumber::iterator iter;
	for (iter = _mapTextPool.begin(); iter != _mapTextPool.end(); ++iter)
	{
		delete (*iter).second;
	}
	_mapTextPool.clear();
	_pCurGroupMap = NULL;
	_pCurTextPool = NULL;
	
//	vecWPLAutoNumAtom::iterator  it;
//	for(it = m_vecWplAutonumAtom.begin(); it != m_vecWplAutonumAtom.end(); it++)
//	{
//		PAUTONUMATOM pAtom = *it;
//		if(pAtom)
//			delete pAtom;
//	}
	m_vecWplAutonumAtom.clear();

	m_vecWplAutonumGroup.clear();
	m_mapIntToRef.clear();
}

STDMETHODIMP_(int) KPersistAutoNumber::ReadParaAutonum(int nGblGroupID, AUTONUMPARAREF& ParaRefData)
{
	ASSERT(!_fStoring);
	
	if (nGblGroupID < 0)
		return -1;

	if (_pCurTextPool == NULL)
	{
		ASSERT(0);
		return -1;
	}

	if (_pCurGroupMap == NULL)
	{
	//	TRACEX("{{ ---> Creating AutoNumberMan for TextPool %p ...\n", _pCurTextPool);
		_pCurGroupMap = new MapIntToInt;
		_mapTextPool[_pCurTextPool] = _pCurGroupMap;
	}
	ASSERT(_pCurGroupMap != NULL);
		
	KABGroupInfoMan* pAutonumMan = _pCurTextPool->GetABGroupInfoMan();
	if(!pAutonumMan)
	{
		ASSERT(0);
		return -1;
	}

	if(FALSE == MakeUp)
	{
		// _vecAutonumӦ���浱ǰ��manager�Ķ����ԣ����ÿ�ι����µ�manager
		// Ӧ����մ�vector
		_vecAutonum.clear();//[bug 4220] modified by mgy

		ASSERT_ONCE(m_mapLevel.size() == 0);
		WPSSaveVector::iterator it; 
		for(it = _vecSave.begin(); it != _vecSave.end(); it ++)
		{	
			WPSSaveAutonum *recsave = it;
			if(!recsave)
				continue;

			tagAUTONUMATOM pAtom;	// tagAUTONUMATOM �ṹ���ܵ�����պ�����
									// ��Ϊ�乹�캯���е�����Init()!"
			//ZeroMemory(&pAtom, sizeof(pAtom));
			KAutoNumAtomSPtr	AtomSPtr;
			AUTONUMGROUP *pAutoNumGroup = new AUTONUMGROUP;
			KAutoNumGroupSPtr GroupSPtr;
			if(recsave->nNum == 0)
			{
				// �ɵͰ汾��������
				BOOL bMake = g_MakeupAutoNumAtomFromOldInfo(&pAtom, 
															recsave->nType, 
															recsave->nStyle,
															recsave->nStartNumber,
															recsave->nLevel);
				if(FALSE == bMake)
					return -1;
				AtomSPtr = pAutonumMan->AddAtom(&pAtom, TRUE);	//ʹAtom��container����

				//����Group
				for(int i = 0; i< _MAX_AUTONUMATOMS_EACHGROUP; ++i)
				{
					pAutoNumGroup->ChangeSpecialLevelData(i, AtomSPtr);		//���Ͱ汾����������ÿһ�һ��
				}
				GroupSPtr = pAutonumMan->AddGroup(pAutoNumGroup, FALSE);

				AUTONUMPARAREF AutoNumParaRef(GroupSPtr, 0);
				_vecAutonum.push_back(AutoNumParaRef);
				// ���Ͱ汾��2002����Level���뵽map����
				m_mapLevel.insert(MapWPSAutonumLevel::value_type(pAutoNumGroup, recsave->nLevel));
			}
			else	//��ȡ�߰汾��������
			{
				for(int i = 0; i< recsave->nNum; i++)
				{
					HRESULT hr = ReadAutonumAtom(m_pFile, recsave->ulAtom[i], pAtom);
					if(FAILED(hr))
						return -1;
					AtomSPtr = pAutonumMan->AddAtom(&pAtom, TRUE);
					//
					pAutoNumGroup->ChangeSpecialLevelData(i, AtomSPtr);
				}
				GroupSPtr = pAutonumMan->AddGroup(pAutoNumGroup, FALSE);
				AUTONUMPARAREF AutoNumParaRef(GroupSPtr, 0);
				_vecAutonum.push_back(AutoNumParaRef);
				// �߰汾��patch2���Ͳ��账��Level������FindLevel��������
			}
		}
		MakeUp = TRUE;
	}

	if(nGblGroupID >= _vecAutonum.size())
	{
		ASSERT(0);
		return -1;
	}
	else
	{
		ParaRefData = _vecAutonum[nGblGroupID];
		return nGblGroupID;
	}
	
}

// -------------------------------------------------------------------------

STDMETHODIMP_(BOOL) LoadAutoNumber(CFile* pFile, DWORD dwAutoNumOffset)
{
	if (dwAutoNumOffset <= 48)
	{
		REPORT("��ô���ԣ���Ȼ�ǷǷ����ļ�ƫ�ƣ�");
		return FALSE;
	}
	else
	{
		try
		{
			pFile->Seek(dwAutoNumOffset, CFile::begin);
			WPSAN_ReadAutonum(pFile);
		}
		catch(...)
		{
			REPORT("Exception: �ļ�ƫ�ƷǷ�?");
			return FALSE;
		}
	}
	return TRUE;
}

// -------------------------------------------------------------------------
