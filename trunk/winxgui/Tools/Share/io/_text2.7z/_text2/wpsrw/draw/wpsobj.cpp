/* -------------------------------------------------------------------------
//	�ļ���		��	wpsobj.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 20:05:53
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <core/wpsdoc.h>
#include "wpsobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//	01�汾�Ķ����ʶ��Ϊ 0xA0
IMPLEMENT_DYNAMIC(CWPSObj, CObject)//, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

void CWPSObj::SetMrect(const CRect& rc)
{
	CRect rect = rc;
	rect.NormalizeRect();
	m_rect = rect;
	// ������ͼ
	// @@todo -- �Ƿ�Ҫ����
	// AdjustImgTopLeft();
}

void CWPSObj::AdjustImgTopLeft()
{
	/*@@todo
	CWpsImage* pImg = GetImage();
	if (pImg == NULL)
		return;
	CSize size;
	if (pImg->IsThereAnimate())
		return;
	else
	{
		size = GetWidthHeight(pImg);
	}
	int iW = ::MulDiv(size.cx, INCH2MM, afxData.cxPixelsPerInch);
	int iH = ::MulDiv(size.cy, INCH2MM, afxData.cyPixelsPerInch);
	int nx, ny;
	if (IMG_SIZE_TYPE_TITLE != pImg->GetImgSizeType())
	{	int rW = m_rect.Width();
		int rH = m_rect.Height();
		double r;
		if ((double)iH*rW < (double)iW*rH)
			r = (double)rW/(double)iW;
		else
			r = (double)rH/(double)iH;
		nx = max(0, (rW-(int)(r*iW))/2);
		ny = max(0, (rH-(int)(r*iH))/2);
	}
	else
	{	nx = max(0,(m_rect.Width() -iW)/2);
		ny = max(0,(m_rect.Height()-iH)/2);
	}
	pImg->SetTopLeft(nx, ny, FALSE); */
}

// -------------------------------------------------------------------------

extern BOOL g_fWpsObjBeta2 = FALSE;

void CWPSObj::Serialize(CArchive& ar)
{
	WORD wVer;
	g_fWpsObjBeta2 = FALSE;

	// �������Ӧ edit paste...
	// => 2-26,'99�����ռǣ���WPS2000�� paste WPS97 ������ (db)
	CWpsDoc* pDoc = (CWpsDoc*)ar.m_pDocument;
	if (ar.IsLoading())
	{
		ASSERT(
			!ar.GetFile()->IsKindOf(RUNTIME_CLASS(CSharedFile)));

		if (0)//ar.GetFile() && ar.GetFile()->IsKindOf(RUNTIME_CLASS(CSharedFile)))
		{
			ASSERT (ar.m_nObjectSchema!=-1);
			int nSchema = ar.GetObjectSchema();
			ASSERT (ar.m_nObjectSchema==-1);
			ar.m_nObjectSchema = nSchema;

			int nVersion;
			nVersion = (int)LOWORD(nSchema);
			nVersion = (int)LOBYTE(nVersion);
			switch (nVersion)
			{
			case WPS_VERSION_SCHEMA_01:	// WPS2001�У��������schema
				wVer = VER_WINWPS01;
				break;
			case WPS_VERSION_SCHEMA_98:	// WPS2000�У��������schema
				wVer = VER_WINWPS98;
				break;
			case WPS_VERSION_SCHEMA_97:
				wVer = VER_WINWPS97;
				break;
			/*@@todo -- WPS2000���԰棬����֧�֣�������
			case 1:	// WPS2000���԰汾�У�CFrameText��schema
				if (IsKindOf(RUNTIME_CLASS(CFrameText)))
					wVer = VER_WINWPS98;
				else
					wVer = VER_WINWPS97;
				break; */
			default:
				ASSERT(0);
				TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
				AfxThrowArchiveException (CArchiveException::badIndex);
				return;
			// ����schema: CCtrlCode_XXX��0x1000��0x1001��CStyle_Text��2��
			// CStyleBase��CStyleSheet��CStyleSheet_Text��1���������ڴ�����
			// ԭ����Щ�಻�Ǵ�CWPSObj�����ġ�
			}
		}
		else if (pDoc)
			wVer = pDoc->GetWPSFileVersion();
		else
		{	//	������98��Ķ����ļ�ʱ��û��pDoc
			int nVersion = ar.m_nObjectSchema;
			nVersion = (int)LOWORD(nVersion);

			if (nVersion == WPS_VERSION_SCHEMA_98 || nVersion ==(WPS_VERSION_SCHEMA_98 | 0x0100))
				wVer = VER_WINWPS98;
			else
			{	//	ASSERT(nVersion == (int)0xA0); //	0xA0��ʾ01��
				wVer = VER_WINWPSLATEST;
			}
		}
	}
	// �����һ����ļ���ȡ...
	else
	{
		ASSERT(ar.IsStoring());
		if (g_bExport2Wps2000 && g_pWPSFHeader)
			wVer = g_pWPSFHeader->wfhVersion;
		else if (pDoc)
			wVer = pDoc->GetWPSFileVersion();
		else
		{	//	ASSERT(nVersion == (int)0xA0); //	0xA0��ʾ01��
			wVer = VER_WINWPSLATEST;
		}
	}
	switch (wVer)
	{
	case VER_WINWPS97:
#ifdef _GWS
	case VER_GWS98:
#endif
		Serialize_97(ar);
		break;
	case VER_WINWPS98:
#ifdef _GWS
	case VER_GWS2000:
#endif
		Serialize_98(ar);
		break;
	case VER_WINWPS01:
		Serialize_01(ar);
		// We need to reset the name of Obj when the file is loading
		/*@@todo - Ӧ��������
		if (ar.IsLoading() && pDoc)
		{
			SetObjName(pDoc->GetName(GetObjID()));
		}*/
		break;
	}	// the last case is same as VER_WINWPSLATEST
}

void CWPSObj::Serialize_97(CArchive& ar)
{
	g_fWpsObjBeta2 = FALSE;
	if (ar.IsStoring())
	{
		ASSERT(FALSE);	// Cannot saved as a WPS97 file.
	}
	else
	{
		//@@todo
		//m_pDocument = (CWpsDoc*)ar.m_pDocument;
		//ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWpsDoc)));
		
		SHORT  wTemp;
		ar >>  wTemp; m_rect.left   = wTemp;
		ar >>  wTemp; m_rect.top    = wTemp;
		ar >>  wTemp; m_rect.right  = wTemp;
		ar >>  wTemp; m_rect.bottom = wTemp;
		
		m_nLBObjActionType = enumObjAction_None;	//������
		m_strLBObjAction.Empty();
		m_bLBObjActionValid = FALSE;		//	������δ��Ч
		m_bLBPlaySound		= FALSE;
		m_nLBSoundId		= 0;
		m_strLBSoundName	= "";
		
		m_nMoveObjActionType = enumObjAction_None;
		m_strMoveObjAction.Empty();
		m_bMoveObjActionValid = FALSE;		//	������δ��Ч
		m_bMovePlaySound	= FALSE;
		m_nMoveSoundId		= 0;
		m_strMoveSoundName	= "";
		
#if defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
		m_bmPresPara.InitClass();
		m_nWPPLayoutFlag  = enumWPP_ObjLayoutFlag_None;//�˶�����WPP��ʽ�޹�
		m_bUserEditFlag   = TRUE; //�û��༭���:�ѱ��༭��..
		m_nWPPCreateByWho = enumWPP_ObjCreateByUser; //Ĭ�ϸö������û�����
#endif
	}
}

void CWPSObj::Serialize_98(CArchive& ar)
{
	g_fWpsObjBeta2 = FALSE;
	if (ar.IsStoring())
		ar << m_rect;
	else
	{
		//@@todo
		//m_pDocument = (CWpsDoc*)ar.m_pDocument;
		//ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWpsDoc)));
		
		ar >> m_rect;
		
		m_nLBObjActionType = enumObjAction_None; //������
		m_strLBObjAction.Empty();
		m_bLBObjActionValid = FALSE;		//	������δ��Ч
		m_bLBPlaySound		= FALSE;
		m_nLBSoundId		= 0;
		m_strLBSoundName	= "";
		
		m_nMoveObjActionType = enumObjAction_None;
		m_strMoveObjAction.Empty();
		m_bMoveObjActionValid = FALSE;		//	������δ��Ч
		m_bMovePlaySound	= FALSE;
		m_nMoveSoundId		= 0;
		m_strMoveSoundName	= "";
		
#if defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
		m_nWPPLayoutFlag  = enumWPP_ObjLayoutFlag_None;//�˶�����WPP��ʽ�޹�
		m_bUserEditFlag   = TRUE; //�û��༭���:�ѱ��༭��..
		m_nWPPCreateByWho = enumWPP_ObjCreateByUser; //Ĭ�ϸö������û�����
#endif
	}
	
#if !defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
	bmDialogPara m_bmPresPara;
#endif
	m_bmPresPara.Serialize_98(ar);
}

// -------------------------------------------------------------------------

class KIOWPSObj : public CWPSObj	// wps2002-io-wait-wpsobj
{
public:
	STDMETHODIMP Serialize_Write_02(CArchive& ar);
	STDMETHODIMP Serialize_Read_02(CArchive& ar);
};

#define WPSOBJ_WPP_FLAGS		0x8000
#define WPSOBJ_BETA2_FLAG		0x4000

STDMETHODIMP KIOWPSObj::Serialize_Write_02(CArchive& ar)
{
	WORD wFlags = 	
#if defined(WPP_ONLY)			// wps2002-io-wpswpp, by tsingbo
		WPSOBJ_WPP_FLAGS |		// wps2002-io-copypaste-between-wpswpp, bugfix, by tsingbo
#endif
		WPSOBJ_BETA2_FLAG |		// wps2002-io-beta2, bugfix, by tsingbo
		(m_nLBObjActionType ? 1 : 0) | (m_nMoveObjActionType ? 0x100 : 0);

	//@@todo
	//m_pDocument->AddName(GetObjID(), GetObjName()); //Storage the shape name         

	ar << m_rect;
	ar << wFlags;

	if (m_nLBObjActionType)
	{
		ar << m_nLBObjActionType;
		ar << m_strLBObjAction;
		ar << m_bLBObjActionValid;
		ar << m_bLBPlaySound;
		ar << m_nLBSoundId;
		ar << m_strLBSoundName;			
	}
	if (m_nMoveObjActionType)
	{
		ar << m_nMoveObjActionType;
		ar << m_strMoveObjAction;
		ar << m_bMoveObjActionValid;
		ar << m_bMovePlaySound;
		ar << m_nMoveSoundId;
		ar << m_strMoveSoundName;
	}
#if defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
	ar << m_bUserEditFlag;	 //�û��༭���
	ar << m_nWPPLayoutFlag;	 //�˶�����WPP��ʽ������־
	ar << m_nWPPCreateByWho; //�ö�����˭����
	m_bmPresPara.Serialize_01(ar);
#endif
	return S_OK;
}

STDMETHODIMP KIOWPSObj::Serialize_Read_02(CArchive& ar)
{
	m_pDocument = (CWpsDoc*)ar.m_pDocument;

	WORD wFlags = 0;
	ar >> m_rect;
	ar >> wFlags;	// wps2002-io-beta2, bugfix, by tsingbo
	g_fWpsObjBeta2 = (wFlags & WPSOBJ_BETA2_FLAG);

	if (wFlags & 1)
	{
		ar >> (int&)m_nLBObjActionType;
		ar >> m_strLBObjAction;
		ar >> m_bLBObjActionValid;
		ar >> m_bLBPlaySound;
		ar >> m_nLBSoundId;
		ar >> m_strLBSoundName;
	}
	if (wFlags & 0x100)
	{
		ar >> (int&)m_nMoveObjActionType;
		ar >> m_strMoveObjAction;
		ar >> m_bMoveObjActionValid;
		ar >> m_bMovePlaySound;
		ar >> m_nMoveSoundId;
		ar >> m_strMoveSoundName;
	}
	if (wFlags & WPSOBJ_WPP_FLAGS)
	{
#if !defined(WPP_ONLY)	// wps2002-io-copypaste-between-wpswpp, bugfix, by tsingbo
		BOOL m_bUserEditFlag;
		int  m_nWPPLayoutFlag, m_nWPPCreateByWho;
		bmDialogPara m_bmPresPara;
#endif
		ar >> m_bUserEditFlag;	 //�û��༭���
		ar >> m_nWPPLayoutFlag;	 //�˶�����WPP��ʽ������־
		ar >> m_nWPPCreateByWho; //�ö�����˭����
		m_bmPresPara.Serialize_01(ar);
	}
	return S_OK;
}

void CWPSObj::Serialize_01(CArchive& ar)
{
	if (g_fCompoundFile) // {{ wps2002-io-wpsobj, new version serialize
	{
		if (ar.IsStoring())
			((KIOWPSObj*)this)->Serialize_Write_02(ar);
		else
			((KIOWPSObj*)this)->Serialize_Read_02(ar);
		return;
	}

	// {{ wps2002-io-wpsobj, old version serialize
	g_fWpsObjBeta2 = FALSE;
	if (ar.IsStoring())
	{
		ar << m_rect;
		
		//	01����
		ar << m_nLBObjActionType;	//������
		ar << m_strLBObjAction;
		ar << m_bLBObjActionValid;
		ar << m_bLBPlaySound;
		ar << m_nLBSoundId;
		ar << m_strLBSoundName;

		ar << m_nMoveObjActionType;
		ar << m_strMoveObjAction;
		ar << m_bMoveObjActionValid;
		ar << m_bMovePlaySound;
		ar << m_nMoveSoundId;
		ar << m_strMoveSoundName;
	

#if defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
		ar << m_bUserEditFlag;		//�û��༭���
		ar << m_nWPPLayoutFlag;		//�˶�����WPP��ʽ������־
		ar << m_nWPPCreateByWho;	//�ö�����˭����
#else
		ar << (BOOL)TRUE;
		ar << (int)enumWPP_ObjLayoutFlag_None;
		ar << (int)enumWPP_ObjCreateByUser;
#endif
	}
	else
	{
		//@@todo ΪʲôҪע�͵�!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		//�ҵ���!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		m_pDocument = (CWpsDoc*)ar.m_pDocument;
		ASSERT((int)m_pDocument != 0xcdcdcdcd);
		//ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWpsDoc)));

		ar >> m_rect;

		ar >> (int&)m_nLBObjActionType;	//������
		ar >> m_strLBObjAction;
		ar >> m_bLBObjActionValid;
		ar >> m_bLBPlaySound;
		ar >> m_nLBSoundId;
		ar >> m_strLBSoundName;

		ar >> (int&)m_nMoveObjActionType;
		ar >> m_strMoveObjAction;
		ar >> m_bMoveObjActionValid;
		ar >> m_bMovePlaySound;
		ar >> m_nMoveSoundId;
		ar >> m_strMoveSoundName;

#if defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
		ar >> m_bUserEditFlag;	 //�û��༭���
		ar >> m_nWPPLayoutFlag;  //�˶�����WPP��ʽ������־
		ar >> m_nWPPCreateByWho; //�ö�����˭����
#else
		int nTemp;
		ar >> nTemp;
		ar >> nTemp;
		ar >> nTemp;
#endif
	}
#if !defined(WPP_ONLY)
	bmDialogPara m_bmPresPara;
#endif
	m_bmPresPara.Serialize_01(ar);
}

// -------------------------------------------------------------------------

CWPSObj::CWPSObj()
{
	m_wpsObjType = 0;
	//m_bstrObjName = NULL; --@@todo

#if defined(WPP_ONLY)	// wps2002-io-wpswpp, by tsingbo
	m_bmPresPara.InitClass();
	
	m_nWPPLayoutFlag = enumWPP_ObjLayoutFlag_None;//�˶�����WPP��ʽ�޹�
	m_bUserEditFlag = FALSE; //�û��༭��ǣ�δ���༭��...
	m_nWPPCreateByWho = enumWPP_ObjCreateByUser; //Ĭ�ϸö������û�����
#endif
	
	m_rect.SetRectEmpty();
	
	//������
	m_nLBObjActionType = enumObjAction_None;
	m_strLBObjAction.Empty();
	m_bLBObjActionValid = FALSE;		//	������δ��Ч
	m_bLBPlaySound = FALSE;
	m_nLBSoundId = 0;
	m_strLBSoundName = "";
	
	m_nMoveObjActionType = enumObjAction_None;
	m_strMoveObjAction.Empty();
	m_bMoveObjActionValid = FALSE;		//	������δ��Ч
	m_bMovePlaySound = FALSE;
	m_nMoveSoundId = 0;
	m_strMoveSoundName = "";
	
	//@@todo
	//m_pDocument = NULL;
	//m_bIsSplitted = FALSE;
	//gAddNewObject(this);
    //m_bDisableRotate = FALSE;
}

CWPSObj::CWPSObj(const CWPSObj* pObj)	//	�������캯��
{
	ASSERT(0);/*@@todo
	ASSERT_VALID(this);
	CopyObj(pObj);
	m_bIsSplitted = FALSE; */
}

CWPSObj::CWPSObj(const CWpsDoc*, const CRect& position)
{
/*@@todo
	if (pDoc)
	{
		ASSERT_VALID(pDoc);
		m_pDocument = (CWpsDoc*)pDoc;
	}
	else
		m_pDocument = NULL;
	
	SetWPSObjType(WPSObj);
*/	
	if (position)
		m_rect = position;
	
#if defined(WPP_ONLY) // wps2002-io-wpswpp, by tsingbo
	m_bmPresPara.InitClass();
	
	//WPP_CODE_2000_9_14 -start
	m_nWPPLayoutFlag = enumWPP_ObjLayoutFlag_None;//�˶�����WPP��ʽ�޹�
	m_bUserEditFlag = FALSE; //�û��༭��ǣ�δ���༭��...
	//WPP_CODE_2000_9_14 -end
	
	//WPP_CODE_2000_11_4 -start
	m_nWPPCreateByWho = enumWPP_ObjCreateByUser; //Ĭ�ϸö������û�����
	//WPP_CODE_2000_11_4 -end
#endif
	
	//������
	m_nLBObjActionType = enumObjAction_None;
	m_bLBObjActionValid = FALSE;		//	������δ��Ч
	m_bLBPlaySound = FALSE;
	m_nLBSoundId = 0;
	
	m_nMoveObjActionType = enumObjAction_None;
	m_bMoveObjActionValid = FALSE;		//	������δ��Ч
	m_bMovePlaySound = FALSE;
	m_nMoveSoundId = 0;

/*@@todo	
	m_bIsSplitted = FALSE;
	
	gAddNewObject(this);
	
	m_bstrObjName = NULL;
    m_bDisableRotate = FALSE; */
}

CWPSObj::~CWPSObj()
{
	//@@todo
	//gRemoveObject(this);
	//UnRegisterWpsObj();
}

// -------------------------------------------------------------------------
//��	��:	�ָ�����(ҳ��/��)��ƴ�ӹ�ϵ
//˵	��:	�����ָ�ͬҳ�ڶ���֮���ƴ�ӹ�ϵ
void ResumeObjConnect(const CObList* pObjList, DWORD& nObjIDCount)
{
	//ASSERT(0);
/**@@todo Connect - ����
	CWPSObj* pSObj;
	DWORD	dwID;
	int		nIDcnt;
	CObList* pSList;
	CWPSObj* pMObj;
	int i;
	POSITION pos1;
	BOOL	bFound = FALSE;
	CDWordArray array;
	//��ѭ��pObjList
	for (POSITION pos = pObjList->GetHeadPosition(); pos;)
	{
		pMObj = (CWPSObj*)pObjList->GetNext(pos);	ASSERT_VALID (pMObj);
		//��ǰ����ĴԶ�������
		nIDcnt = pMObj->GetSlvObjIDSize();
		nObjIDCount = max(nObjIDCount, pMObj->GetObjID());
		if (nIDcnt > 0)
		{
			//��ǰ����Ĵ�����
			pSList = pMObj->GetSlvObjList();		//	���ӡ�����
			array.RemoveAll();
			//pObjList�ж�������дӶ���ѭ��
			for (i = 0; i < nIDcnt; i++)
			{ 
				//ȡĳ���Ӷ����ID
				dwID = pMObj->GetSlvObjID(i);
				bFound = FALSE;
				//��pObjList�������Ҿ�����ͬID�Ķ���
				for (pos1 = pObjList->GetHeadPosition(); pos1;)
				{	
					pSObj = (CWPSObj*)pObjList->GetNext(pos1);
					ASSERT_VALID (pSObj);
					
					if (dwID == pSObj->GetObjID() && !pSList->Find(pSObj))
					{	//���ID��ͬ�����ڴ�������û��
						pSList->AddTail(pSObj);	//	���ӡ���ӡ�
						if (pSObj->CalcConnLineObjEnd(pMObj)==0)
							pSObj->SetMstObj(pMObj);	//	���䡰����
						else
							pSObj->SetMstObj2(pMObj);	//	���䡰����
						ASSERT(pSObj->GetMstObj() != pSObj);
						ASSERT(pSObj->GetMstObj2() != pSObj);
						nObjIDCount = max(nObjIDCount, pSObj->GetObjID());
						bFound = TRUE;
						break;
					}
				}
				if (!bFound)
					array.Add(dwID);
			}
			ASSERT(pMObj->GetSlvObjIDArray());
			pMObj->GetSlvObjIDArray()->RemoveAll();
			pMObj->GetSlvObjIDArray()->Append(array);
		}
	}
	nObjIDCount++;	//	!!!
*/
}

// -------------------------------------------------------------------------
