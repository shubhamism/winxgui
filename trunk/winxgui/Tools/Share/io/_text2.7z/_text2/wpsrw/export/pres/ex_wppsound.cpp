/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wppsound.cpp
//	������		��	liupeng
//	����ʱ��	��	2005-4-1 15:49:48
//	��������	��	
//
// -----------------------------------------------------------------------*/
#include "stdafx.h"
#if defined(WPP_ONLY)
#include "ex_wppsound.h"
#include "kso/dircfginfo.h"
#include "kso/linklib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

WCHAR* g_Wpp2003_BuildinSoundNames[] = 
{
	__X("nosound"),
	__X("flyout.wav"),
	__X("page.wav"),
	__X("inaugurate.wav"),
	__X("shutter.wav"),
	__X("click.wav"),	// 119
	__X("string.wav"),
	__X("knock.wav"),
	__X("glideout.wav"),
	__X("spread.wav"),
	__X("telephone.WAV"),
	__X("whistle.wav"),
	__X("fireworks.wav"),
	__X("star-spangled.wav"),
	__X("wind.wav"),	// 125
	__X("brake.wav"),
	__X("loudspeaker.wav"),
	__X("frequency.wav"),
	__X("keyboard.wav"),
	__X("cheers.wav"),
	__X("applause.wav"), // 108
};

WCHAR* g_Wpp2003_BuildInSound_Path = __X("/media/");

const int g_nBuildInSounds = sizeof(g_Wpp2003_BuildinSoundNames) / sizeof(WCHAR*);

void* CreateSound(INT nSoundid, INT& nLen, BSTR* pStrSoundName, int& buildid)
{
	buildid = 0;
	if (nSoundid < 1 || nSoundid > 20)
		return NULL;
	WCHAR mediapath[MAX_PATH] = {0};
	_kso_GetDirInfo(_kso_dir_resource, KSO_LANGUAGE_AUTO, TRUE, mediapath, MAX_PATH - 1);

	ks_wstring path = mediapath;
	path += g_Wpp2003_BuildInSound_Path;
	path += g_Wpp2003_BuildinSoundNames[nSoundid];
	
	if (nSoundid == 5)
		buildid = 119;
	if (nSoundid == 14)
		buildid = 125;
	if (nSoundid == 20)
		buildid = 108;

	return CreateSound((BSTR)(ks_bstr((LPCWSTR)path)), nLen, pStrSoundName);
}

void* CreateSound(BSTR strFileName, INT& nLen, BSTR* pStrSoundName)
{
	FILE* file = _wfopen(strFileName, __X("rb"));
	if (!file)
	{
		ASSERT(FALSE);
		return NULL;
	}

	fseek(file, 0, SEEK_END);
	int nFilelen = ftell(file);
	fseek(file, 0, SEEK_SET);

	BYTE* pBuf = new BYTE[nFilelen];
	if (!pBuf)
	{
		fclose(file);
		return NULL;
	}
	VERIFY( (nFilelen == fread(pBuf, 1, nFilelen, file)) );

	if (pStrSoundName)
	{
		WCHAR szName[_MAX_FNAME] = {0};
		WCHAR szExt[_MAX_EXT] = {0};
		_wsplitpath(strFileName, NULL, NULL, szName, szExt);
		wcscat(szName, szExt);
		*pStrSoundName = SysAllocString(szName);
	}
	
	nLen = nFilelen;
	fclose(file);
	return pBuf;
}
#endif // #if defined(WPP_ONLY)