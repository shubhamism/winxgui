/* -------------------------------------------------------------------------
//	�ļ���		��	backgrnd.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 19:03:35
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "backgrnd.h"
#include <draw/wpsimg.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

void CSlideBackground::_Serialize(KSArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_nFillType;
		ar << m_clrSolid;
		
		ar << m_ShadeCtrl.shadeColor[0];
		ar << m_ShadeCtrl.shadeColor[1];
		ar << m_ShadeCtrl.shadeDir;
		ar << m_ShadeCtrl.shadeStyle;
		
		ar << m_nTextureIndex;
		ar << m_nImgId;
	}
	else
	{
		ar >> m_nFillType;
		ar >> m_clrSolid;
		
		ar >> m_ShadeCtrl.shadeColor[0];
		ar >> m_ShadeCtrl.shadeColor[1];
		ar >> m_ShadeCtrl.shadeDir;
		ar >> m_ShadeCtrl.shadeStyle;
		
		ar >> m_nTextureIndex;
		ar >> m_nImgId;
	}
}

// -------------------------------------------------------------------------

STDMETHODIMP CSlideBackground::Serialize_Write_02(KSArchive& ar, CWpsImage* pImg)
{
	WPSBackgroundData rec;
	ZeroMemory(&rec, sizeof(rec));

	UINT cbRecord = 4;

	KWPSMainWriter wr;
	wr.Attach(&ar);

	switch (m_nFillType)
	{
	case enBG_SOLIDFILL:
		rec.fillMode = WPSFill_Solid;
		rec.solidFill.fillColor = m_clrSolid;
		cbRecord += sizeof(rec.solidFill);
		break;

	case enBG_PICTUREFILL:
		if (pImg) // special
		{
			rec.fillMode = WPSFill_Image;
			_WPSWriteRecord(wr, TAG_WPSBackground, &rec, cbRecord);
			pImg->Serialize(ar);
			return S_OK;
		}
		rec.fillMode = WPSFill_ImageIndex;
		rec.imgIndexFill.nImgId = m_nImgId;
		cbRecord += sizeof(rec.imgIndexFill);
		break;

	case enBG_SHADEDFILL:
		rec.fillMode = WPSFill_Gradient;
		rec.gradientFill.shadeColor[0] = m_ShadeCtrl.shadeColor[0];
		rec.gradientFill.shadeColor[1] = m_ShadeCtrl.shadeColor[1];
		rec.gradientFill.shadeDir		= m_ShadeCtrl.shadeDir;
		rec.gradientFill.shadeStyle	= m_ShadeCtrl.shadeStyle;
		cbRecord += sizeof(rec.gradientFill);
		break;

	case enBG_TEXTUREDFILL:
		rec.fillMode = WPSFill_Texture;
		rec.textureFill.nImgId = m_nImgId;
		rec.textureFill.nTextureIndex = m_nTextureIndex;
		cbRecord += sizeof(rec.textureFill);
		break;

	default:
		REPORT_ONCE("δ֪�����ģʽ");
	}
	_WPSWriteRecord(wr, TAG_WPSBackground, &rec, cbRecord);
	return S_OK;
}

STDMETHODIMP CSlideBackground::Serialize_Read_02(KSArchive& ar, CWpsImage** ppImg)
{
	HRESULT hr;
	_KWPSRecordHeader hdr;
	WPSBackgroundData rec;
	KWPSMainReader wr;
	wr.Attach(&ar);

	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSBackground, hr = E_UNEXPECTED);

	wr.Read(&rec, sizeof(rec));
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());

	switch (rec.fillMode)
	{
	case WPSFill_Solid:
		m_nFillType = enBG_SOLIDFILL;
		m_clrSolid = rec.solidFill.fillColor;
		break;

	case WPSFill_Image:
		m_nFillType = enBG_PICTUREFILL;
		*ppImg = CreateWpsImage();
		(*ppImg)->Serialize(ar);
		break;

	case WPSFill_ImageIndex:
		m_nFillType = enBG_PICTUREFILL;
		m_nImgId = rec.imgIndexFill.nImgId;
		break;

	case WPSFill_Gradient:
		m_nFillType = enBG_SHADEDFILL;
		m_ShadeCtrl.shadeColor[0]	= rec.gradientFill.shadeColor[0];
		m_ShadeCtrl.shadeColor[1]	= rec.gradientFill.shadeColor[1];
		m_ShadeCtrl.shadeDir		= rec.gradientFill.shadeDir;
		m_ShadeCtrl.shadeStyle		= rec.gradientFill.shadeStyle;
		break;

	case WPSFill_Texture:
		m_nFillType = enBG_TEXTUREDFILL;
		m_nImgId = rec.textureFill.nImgId;
		m_nTextureIndex = rec.textureFill.nTextureIndex;
		break;

	default:
		REPORT_ONCE("CBackground::Serialize - δ֪�����ģʽ");
	}
	return S_OK;

KS_EXIT:
	return WPSIOThrowError(hr);
}

// -------------------------------------------------------------------------
