/* -------------------------------------------------------------------------
//	�ļ���		��	media/mediadata.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-14 14:26:59
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __MEDIA_MEDIADATA_H__
#define __MEDIA_MEDIADATA_H__

// -------------------------------------------------------------------------

#ifndef STDPROC
#define STDPROC				virtual HRESULT __stdcall
#define STDPROC_(type)		virtual type __stdcall
#endif

typedef ULONG MDSOFF;
typedef UINT  MDSSIZE;

// -------------------------------------------------------------------------

typedef IKLockBuffer IKMediaDataSource;

#define IID_IKMediaDataSource __uuid(IKLockBuffer)

// -------------------------------------------------------------------------

#define E_MD_NOSOURCE		E_FAIL
#define E_INVALID_FILESIZE	E_FAIL
#define E_READFILE_FAIL		E_FAIL
#define E_SEEKFILE_FAIL		E_FAIL

#undef	HFILE
#define	HFILE				HANDLE

#ifndef NULL_HFILE
#define NULL_HFILE			(INVALID_HANDLE_VALUE)
#endif

STDMETHODIMP CreateHGblFromFile(LPCTSTR szFile, HGBL* phGbl);
STDMETHODIMP CreateHGblFromFile(HFILE hFile, MDSOFF off, MDSSIZE size, HGBL* phGbl);
STDMETHODIMP CreateHGblFromStream(IStream* pStrm, MDSOFF off, MDSSIZE size, HGBL* phGbl);

STDMETHODIMP CreateMDSFromFile(LPCTSTR szFile, IKMediaDataSource** ppMDS);
STDMETHODIMP CreateMDSFromFile(HFILE hFile, MDSOFF off, IKMediaDataSource** ppMDS);
STDMETHODIMP CreateMDSFromStream(IStream* pStrm, MDSOFF off, MDSSIZE size, IKMediaDataSource** ppMDS);
STDMETHODIMP CreateMDSFromAttachHGbl(HGBL hGbl, IKMediaDataSource** ppMDS);

// -------------------------------------------------------------------------

namespace wpsrw
{
	inline
	STDMETHODIMP_(HGBL) CreateHGblFromBuffer(LPCVOID pData, UINT cbData)
	{
		HGBL hGbl = XGlobalAlloc(GHND, cbData);
		if (hGbl)
		{
			LPVOID pDest = XGlobalLock(hGbl);
			CopyMemory(pDest, pData, cbData);
			XGlobalUnlock(hGbl);
		}
		return hGbl;
	}

	inline
	STDMETHODIMP_(HGBL) CloneHGlobal(HGBL hGbl)
	{
		HGBL hGblClone = NULL;
		if (hGbl)
		{
			hGblClone = CreateHGblFromBuffer(XGlobalLock(hGbl), XGlobalSize(hGbl));
			XGlobalUnlock(hGbl);
		}
		return hGblClone;
	}
}

// -------------------------------------------------------------------------

#endif /* __MEDIA_MEDIADATA_H__ */
