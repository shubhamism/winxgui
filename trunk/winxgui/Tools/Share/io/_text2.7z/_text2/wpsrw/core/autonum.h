/* -------------------------------------------------------------------------
//	�ļ���		��	autonum.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 11:38:47
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __AUTONUM_H__
#define __AUTONUM_H__

#include <stl/deque.h>
#include <stl/map.h>
#include <stl/vector.h>

#ifndef __WPSRW_COMMON_H__
#include <wpsrw/common.h>
#endif

#ifndef __AUTONUM_ATOM_H
#include "autonum_atom.h"
#endif

#ifndef __AUTONUM_CCHELPER_H
#include "autonum_cchelper.h"
#endif

#ifndef _MAX_AUTONUMATOMS_EACHGROUP
#define _MAX_AUTONUMATOMS_EACHGROUP		(10)
#endif

#ifndef ISVALIDAUTONUMLEVEL
#define ISVALIDAUTONUMLEVEL(nLevel)		((nLevel) >= 0 && (nLevel) < (_MAX_AUTONUMATOMS_EACHGROUP))
#endif

//typedef void* KAutoNumGroupSPtr; // @@todo

// -------------------------------------------------------------------------
/*
struct tagAUTONUMPARAREF
{
	KAutoNumGroupSPtr	m_AuoNumGroupSPtr;
	int					m_nLevel;
public:
	tagAUTONUMPARAREF() : m_AuoNumGroupSPtr(NULL), m_nLevel(0)
	{
	}
	tagAUTONUMPARAREF(const tagAUTONUMPARAREF& data)
	{
		m_AuoNumGroupSPtr	= data.m_AuoNumGroupSPtr;
		m_nLevel			= data.m_nLevel;
	}
	tagAUTONUMPARAREF(KAutoNumGroupSPtr GroupPtr, int nLevel)
		: m_AuoNumGroupSPtr(GroupPtr), 	m_nLevel(nLevel)
	{
	}
	BOOL IsValidRefData() const
	{
		BOOL bRet	= TRUE;
		if (!ISVALIDAUTONUMLEVEL(m_nLevel) || !m_AuoNumGroupSPtr)
			bRet	= FALSE;
		return bRet;
	}
};

typedef tagAUTONUMPARAREF		AUTONUMPARAREF;
typedef tagAUTONUMPARAREF*		PAUTONUMPARAREF;

BOOL operator==(const tagAUTONUMPARAREF& data0, const tagAUTONUMPARAREF& data1);
BOOL operator!=(const tagAUTONUMPARAREF& data0, const tagAUTONUMPARAREF& data1);

*/

// -------------------------------------------------------------------------

// ��ʱ�ṹ��
#pragma pack(1)
typedef struct tagWPSSaveAutonum{
	SHORT	nType;			// ���Զ���Ż�����Ŀ����
	SHORT	nStyle;			// ����ľ�����(����1)
	SHORT	nLevel;			// ����Ĳ��(����0)
	SHORT	nStartNumber;	// �����Զ���ŵ���ʼ��ţ�����Ŀ��������Ч
	SHORT   nNum;			// ��¼Atom�ĸ���
	ULONG	ulAtom[10];		// 10��Atom
}WPSSaveAutonum;
#pragma pack()

// wpl�Ĵ���
// �洢Atom��vector
typedef std::vector<PAUTONUMATOM> vecWPLAutoNumAtom;
// �洢Group��vector
typedef struct tagWPLAUTONUMGROUPINFO
{
	SHORT	nCount;					// ����
	SHORT	nID[10];				// ��Ӧ��id
}WPLAUTONUMGROUPINFO;

typedef std::vector<WPLAUTONUMGROUPINFO> vecWPLAutoNumGroup;

typedef std::map<int, AUTONUMPARAREF> MapIntToRef;
//

class CTextPool;

typedef std::vector<WPSSaveAutonum> WPSSaveVector;
//typedef std::vector_paged<AUTONUMPARAREF> WPSAutonumVector;
typedef std::deque<AUTONUMPARAREF> WPSAutonumVector;
typedef std::map<int, int> MapIntToInt;
typedef std::map<CTextPool*, MapIntToInt*> MapTextPoolAutoNumber;

typedef std::map<AUTONUMGROUP*, SHORT> MapWPSAutonumLevel;

struct WPSGroupPair
{
	int _nGblGroupID;
	struct KABGROUPINFO* _pInfo;
public:
	WPSGroupPair(int nGblGroupID, KABGROUPINFO* pInfo)
	{
		_nGblGroupID = nGblGroupID;
		_pInfo = pInfo;
	}
};

typedef std::vector<WPSGroupPair> WPSGroupPairVector;

// -------------------------------------------------------------------------
// class KPersistAutoNumber
//lijun
struct KABGROUPINFO{
	int nType;			// ���Զ���Ż�����Ŀ����
	int	nStyle;			// ����ľ�����(����1)
	int	nLevel;			// ����Ĳ��(����0)
	int	nStartNumber;	// �����Զ���ŵ���ʼ��ţ�����Ŀ��������Ч
	
	// functions
	BOOL operator!=(KABGROUPINFO data)
	{
		if (nType != data.nType || nStyle != data.nStyle || nLevel != data.nLevel || 
			nStartNumber != data.nStartNumber)
			return TRUE;
		return FALSE;
	}
	KABGROUPINFO& operator=(const KABGROUPINFO& that)
	{
		nType = that.nType;
		nStyle = that.nStyle;
		nLevel = that.nLevel;
		nStartNumber = that.nStartNumber;
		
		return *this;
	}
	
};

class CTextPool;
class KPersistAutoNumber
{
public:
	KPersistAutoNumber();
	~KPersistAutoNumber() { Clear(); }

protected:
	CFile* m_pFile;
	WPSSaveVector _vecSave;
	WPSAutonumVector _vecAutonum;
	MapTextPoolAutoNumber _mapTextPool;
	MapIntToInt* _pCurGroupMap;
	CTextPool* _pCurTextPool;
	int _fStoring;
	BOOL MakeUp;
public:
	int _fBeta;

//
protected:
	MapWPSAutonumLevel m_mapLevel;		// �ɰ汾�Զ���ŵ�Levelӳ���

public:
//	STDMETHODIMP FindLevel(const AUTONUMGROUP* pParaGroup, SHORT& shLevel);
	
// ������wpl�йص��Զ������Ϣ
protected:
	vecWPLAutoNumAtom	m_vecWplAutonumAtom;	// ����ͼ�ķ������Զ����Atom
	vecWPLAutoNumGroup	m_vecWplAutonumGroup;	//����ͼ�ķ������Զ����Group

	MapIntToRef			m_mapIntToRef;			// ID��Ref��ӳ��

public:
	STDMETHODIMP_(void) Clear();
	STDMETHODIMP_(void) Init(int fStoring)
	{
		m_pFile = NULL;
		//Mgy modify for wanli bug
		//MakeUp = FALSE;
		//Mgy modify for wanli bug
		_fStoring = fStoring;
		_fBeta = 1;
		Clear();
	}

	STDMETHODIMP_(CTextPool*) EnterTextPool(CTextPool* pTextPool);
	STDMETHODIMP_(void) LeaveTextPool(CTextPool* pOldPool);
	
	STDMETHODIMP_(void)	WriteAutonum(CFile* pFile);
	STDMETHODIMP_(void) ReadAutonum(CFile* pFile);
	
	STDMETHODIMP_(void)	WriteAutonumBeta(CArchive& ar);
	STDMETHODIMP_(void) ReadAutonumBeta(CArchive& ar);

	STDMETHODIMP_(int)	ReadParaAutonum(int nGblGroupID, AUTONUMPARAREF& ParaRefData);
	STDMETHODIMP ReadWPLParaAutonum(const int nID, AUTONUMPARAREF& WPLParaRef);
	STDMETHODIMP WriteWPLAutonum(CFile* pFile);
	STDMETHODIMP ReadWPLAutonum(CFile* pFile);

	STDMETHODIMP_(BOOL) HasInRefMap(const int nID, AUTONUMPARAREF& WPLParaRef);

protected: // ֻ���ڶ���Beta�汾��WPS�ļ��õ�!
	WPSGroupPairVector _vecGroupPair;
};

// -------------------------------------------------------------------------

extern KPersistAutoNumber g_ANPersist;

#define WPSAN_IsBetaVersion()				_fBeta
#define WPSAN_Init(fStoring)				g_ANPersist.Init(fStoring)
#define WPSAN_Clear()						g_ANPersist.Clear()

#define WPSAN_EnterTextPool(pTextPool)		g_ANPersist.EnterTextPool(pTextPool)
#define WPSAN_LeaveTextPool(pOldPool)		g_ANPersist.LeaveTextPool(pOldPool)

#define WPSAN_WriteAutonum(ar)							g_ANPersist.WriteAutonum(ar)
#define WPSAN_WriteAutonumBeta(ar)						g_ANPersist.WriteAutonumBeta(ar)
#define WPSAN_WriteParaAutonum(nGroupID, pParaRefData)	g_ANPersist.WriteParaAutonum(nGroupID, pParaRefData)

#define WPSAN_WriteWPLParaAutonum(pWPLParaRef, nID)		g_ANPersist.WriteWPLParaAutonum(pWPLParaRef, nID)
#define WPSAN_ReadWPLParaAutonum(nID, WPLParaRef)		g_ANPersist.ReadWPLParaAutonum(nID, WPLParaRef)

#define WPSAN_ReadAutonum(ar)								g_ANPersist.ReadAutonum(ar)
#define WPSAN_ReadAutonumBeta(ar)							g_ANPersist.ReadAutonumBeta(ar)
#define WPSAN_ReadParaAutonum(nGblGroupID, pParaRefData)	g_ANPersist.ReadParaAutonum(nGblGroupID, pParaRefData)

// -------------------------------------------------------------------------

#endif /* __AUTONUM_H__ */
