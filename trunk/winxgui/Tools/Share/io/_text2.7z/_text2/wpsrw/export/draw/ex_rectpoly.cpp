/* -------------------------------------------------------------------------
//	�ļ���		��	ex_rectpoly.cpp
//	������		��	��־��
//	����ʱ��	��	2004-10-17 10:21:41
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_ptobj.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

EX_SHAPE_API CRectPoly_Export::ConvertShape(CShape_Context& context)
{
	//m_nNum = 3,4,5,6,8���Σ����ң�m_nScale Ϊ 100 ʱ������ʹ��WORD�еĶ�Ӧ��״
	MSOSPT eShape = msosptNotPrimitive; 
	//@@todo:CRectPoly û��ת�����ߡ��Խ���
	//ASSERT(!"û��ת�����ߡ��Խ���");

	//lijun ���Ӷ������������ߺ�����߶�������
	context.m_opt.ForceAddPropFix(ksextopt_LinkTop, m_bLinkTop);
	context.m_opt.ForceAddPropFix(ksextopt_LinkMid, m_bLinkMid);

	Trans(context);
	context.m_shape.SetShapeType(eShape);
}


void CRectPoly_Export::Trans(CShape_Context& context)
{
	CRect rct = GetMrect();
	if (rct.Width() % 2 != 0)
		rct.right++;
	if (rct.Height() % 2 != 0)
		rct.bottom++;
	
	//rct.NormalizeRect();
	rct.bottom = rct.Height();
	rct.right  = rct.Width();
	rct.top	   = 0;
	rct.left   = 0;

	CPoint centerPoint;			//	������Ϊ���ε�����,һ�����ζ�����������ı㲻�ɸı�
	centerPoint.x = (rct.left + rct.right) / 2;
	centerPoint.y = (rct.top + rct.bottom) / 2;
	UINT i,j;
 	CPoint* pPoint = new CPoint[sizeof(CPoint) * 2 * m_nNum + 1];
	if (m_nNum == 4 && m_nScale == 100) //���ı��������⴦��
	{
		(pPoint+0)->x = centerPoint.x;
		(pPoint+0)->y = rct.top;
		(pPoint+2)->x = rct.left;
		(pPoint+2)->y = centerPoint.y;
		(pPoint+4)->x = centerPoint.x;
		(pPoint+4)->y = rct.bottom;
		(pPoint+6)->x = rct.right;
		(pPoint+6)->y = centerPoint.y;

		(pPoint+1)->x = ((pPoint+0)->x + (pPoint+2)->x) / 2;
		(pPoint+1)->y = ((pPoint+0)->y + (pPoint+2)->y) / 2;
		(pPoint+3)->x = ((pPoint+2)->x + (pPoint+4)->x) / 2;
		(pPoint+3)->y = ((pPoint+2)->y + (pPoint+4)->y) / 2;
		(pPoint+5)->x = ((pPoint+4)->x + (pPoint+6)->x) / 2;
		(pPoint+5)->y = ((pPoint+4)->y + (pPoint+6)->y) / 2;
		(pPoint+7)->x = ((pPoint+6)->x + (pPoint+0)->x) / 2;
		(pPoint+7)->y = ((pPoint+6)->y + (pPoint+0)->y) / 2;
	}
	else 
	{
		int a,b;	//��Բ�ĳ��̰��ᡣ
		a = abs(rct.right - rct.left) / 2;
		b =	abs(rct.bottom - rct.top) / 2;
		double angle = 2 * PI / m_nNum;
	//	TRACE1("angle=%f\n",angle*180/PI);
		for (i = 0,j = 0; i < m_nNum + 1; i += 2,j++)	//�����ż������Ϊ����εĶ��㡣
		{	
			(pPoint+i)->x = (long) (centerPoint.x + a * cos(j * angle - PI / 2));
			(pPoint+i)->y = (long) (centerPoint.y + b * sin(j * angle - PI / 2));
			(pPoint+2*m_nNum-i)->x = 2 * centerPoint.x - (pPoint+i)->x;
			(pPoint+2*m_nNum-i)->y = (pPoint+i)->y;
		}
		
		for (i=1; i<m_nNum+1; i+=2)	//���������ζ���֮����е���Ϊ�����㡣
		{	(pPoint+i)->x = (((pPoint+i)+1)->x + ((pPoint+i)-1)->x) / 2;
			(pPoint+i)->y = (((pPoint+i)+1)->y + ((pPoint+i)-1)->y) / 2;
			(pPoint+i)->x = MulDiv(m_nScale, (pPoint+i)->x - centerPoint.x, 100) + centerPoint.x;
			(pPoint+i)->y = MulDiv(m_nScale, (pPoint+i)->y - centerPoint.y, 100) + centerPoint.y;
			(pPoint+2*m_nNum-i)->x = 2 * centerPoint.x - (pPoint+i)->x;
			(pPoint+2*m_nNum-i)->y = (pPoint+i)->y;
		}
	}

	KPointList ptlist;
	KFlagList flaglist;

	CRect rc;
	rc.left = INT_MAX;
	rc.top = INT_MAX;
	rc.right = INT_MIN;
	rc.bottom = INT_MIN;
	for (i = 0;i < 2*m_nNum; i++)
	{
		CPoint * pCurPoint = pPoint + i;
		if (pCurPoint->x < rc.left)
			rc.left = pCurPoint->x;
		if (pCurPoint->y < rc.top)
			rc.top = pCurPoint->y;
		if (pCurPoint->x > rc.right)
			rc.right = pCurPoint->x;
		if (pCurPoint->y > rc.bottom)
			rc.bottom = pCurPoint->y;
	}
	
	BYTE byFlag = PT_MOVETO;
	ptlist.AddTail(*pPoint);
	flaglist.AddTail(byFlag);
	byFlag = PT_LINETO;
	for (i = 1; i < 2*m_nNum; i ++)
	{		
		ptlist.AddTail(*(pPoint+i));
		flaglist.AddTail(byFlag);
	}
	ptlist.AddTail(*pPoint);
	flaglist.AddTail(byFlag);
	
	gConvertPolyObj(ptlist, flaglist, CPolyObj::polyLine, 1, this, context, &rc);

	delete []pPoint;
	
	/*
	context.m_opt.AddPropFix(msopt_geoLeft, rct.left);
	context.m_opt.AddPropFix(msopt_geoTop, rct.top);
	context.m_opt.AddPropFix(msopt_geoRight, rct.right);
	context.m_opt.AddPropFix(msopt_geoBottom, rct.bottom);
	*/
}
// -------------------------------------------------------------------------
EX_SHAPE_API CRectPoly_Export::GetShapeRect(CShape_Context& context, CRect& rcOut)
{
	CRect rct = rcOut;

	int nThea = 0;
	
	nThea = m_theta + nThea;

	rct = RecalcObjBox(rcOut, m_center, nThea);
	
	nThea = nThea > 0 ? 360 - nThea / 10 : -nThea / 10;
	if(45 <= nThea && nThea < 135
		|| 225 <= nThea && nThea < 315)
	{
		SWAPWH(rct);
	}
	
	rcOut = rct;
}

