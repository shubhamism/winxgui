//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainMailButton.cpp
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-6-6 14:16:32
//	FileDescription	:	Domain Mail Button 
//
//////////////////////////////////////////////////////////////////////////////////////
// KSDomainMailButton.cpp: implementation of the KSDomainMailButton class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#ifndef __WPSOBJ_H
	#include "Wpsobj.h"
#endif

#ifndef __PTOBJ_H
	#include "Ptobj.h"
#endif

#include "KSDomainMailButton.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL(KSDomainMailButton,CLtxtObj,98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(KSDomainMailButton,CLtxtObj,0xA0 | VERSIONABLE_SCHEMA)

KSDomainMailButton::KSDomainMailButton()
{
}

KSDomainMailButton::~KSDomainMailButton()
{

}
/*

KSDomainMailButton::KSDomainMailButton(const CWpsDoc* pDoc, 
									   const CRect& position, 
									   int nShape/ *=rectangle* /)
				   :CLtxtObj(pDoc,position,rectangle)     
{
	m_bSelect = FALSE;
}
*/

KSDomainMailButton::KSDomainMailButton(const KSDomainMailButton* obj)
{
	ASSERT_VALID(obj);
//	CopyObj(obj,TRUE);
	m_bSelect = FALSE;
}

void KSDomainMailButton::Serialize_01(KSArchive& ar)
{
	CLtxtObj::Serialize_01(ar);
	if (ar.IsStoring())
	{
		ar << m_bSelect;
		ar << m_sSubject;
		ar << m_sSendTo;
		ar << m_sSendCc;
	}
	else
	{
		ar >> m_bSelect;
		ar >> m_sSubject;
		ar >> m_sSendTo;
		ar >> m_sSendCc;
	}

 	CWPSObj::SerializeObjType(ar);
}
