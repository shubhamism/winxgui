/////////////////////////////////////////////////////////////////////////////
//
// FormCell.cpp - implementation for CFormCell objects
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h" 

#ifndef __CTRLCODE_H
//#include "ctrlcode.h"
#endif

#ifndef __WPSOBJ_H
#include "wpsobj.h"
#endif

//#include "MainFrm.h"

#if !defined(AFX_KSTEXTSTRING_H_INCLUDED_)
//#include "KSTextString.h"
#endif

#ifndef __FORMULAE_H
#include "formulae.h"
#endif

#ifndef __FORMCELL_H
#include "formcell.h"
#endif

#ifndef __FORMABC_H
#include "formabc.h"
#endif

#ifndef __WPSVIEW_H
//#include "wpsview.h"
#endif

#ifndef __WPSDOC_H
//#include "wpsdoc.h"
#endif

#ifndef __OBJTOOL_H
//#include "objtool.h"
#endif

#ifndef __PTOBJ_H
#include "ptobj.h"
#endif

#ifndef _WPSREADER
//	#include "ResID_Dlg.h"
//	#include "formmatrdlg.h"
#endif	// #ifndef _WPSREADER

//#include "WPPDoc.h" //for WPP

extern FS[4];
extern BOOL IsKeyDown (int vKey);
extern int MStringToDMString( CString& str, BOOL bIsEng );
extern void ChangeFS(int nFS[4], int nCharMrg);
extern void RefreshFS();
extern void SaveFS();
extern int nFormulaCharMrg;//	��ʽ���ֵļ��(12%)

/////////////////////////////////////////////////////////////////////////////
//	CFormCell

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//IMPLEMENT_SERIAL(CFormCell, CWPSObj, 98 | VERSIONABLE_SCHEMA | 0x0100 )
IMPLEMENT_SERIAL(CFormCell, CWPSObj, 0xA0 | VERSIONABLE_SCHEMA | 0x0100 )

CFormCell::CFormCell()
{                      
	//LLG_TEMP_2001_3_31
	//�����������Ҫ�����ô�WPP Copy ��WPS�Ĺ�ʽ������ȫ�Ĳ�ɫ...
	//����m_bkColor���������ϣ����󲻻ᱻ�����ط�����...
	//m_bkColor = RGB(0, 0, 0);
}

CFormCell::~CFormCell()
{
	ASSERT( this );
	DeleteContent();
}

void CFormCell::DeleteContent()
{
}      



void CFormCell::Serialize_97( KSArchive& ar )
{
	ASSERT(FALSE);
}     

void CFormCell::Serialize_98( KSArchive& ar )
{
	CWPSObj::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nCompLoca, sizeof(int));
		ar.Write(&m_nFSIndex, sizeof(int));
		ar.Write(&m_nHor, sizeof(int));
		ar.Write(&m_nVer, sizeof(int));
		ar.Write(&m_nType, sizeof(int));
		ar << m_bHasFather;
		if(!m_bHasFather)//�ޡ�����������ֺ�
		{	for(int i=0;i<4; i++)
					ar << m_nFontSize[i];
			ar.Write(&m_nFormulaCharMrg, sizeof(int));
		}
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nCompLoca, sizeof(int));
		ar.Read(&m_nFSIndex, sizeof(int));
		ar.Read(&m_nHor, sizeof(int));
		ar.Read(&m_nVer, sizeof(int));
		ar.Read(&m_nType, sizeof(int));
		SetMstObj( NULL );
		int nVersion = ar.GetObjectSchema();
		ar.SetObjectSchema( nVersion );
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
			{	int nOldFS[4] = { 637, 425, 247, 185 };
				for(int i=0;i<4; i++)
					m_nFontSize[i] = nOldFS[i];
				m_nFormulaCharMrg = 12;//��ֵΪ12
			}
			break;
			case 1:
			{	ar >> m_bHasFather;
				if(!m_bHasFather)//�ޡ�����������ֺ�
				{	for(int i=0;i<4; i++)
						ar >> m_nFontSize[i];
					ar.Read(&m_nFormulaCharMrg, sizeof(int));
				}
			}
			break;
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormCell::Serialize_01(KSArchive& ar)
{
	CWPSObj::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nCompLoca, sizeof(int));
		ar.Write(&m_nFSIndex, sizeof(int));
		ar.Write(&m_nHor, sizeof(int));
		ar.Write(&m_nVer, sizeof(int));
		ar.Write(&m_nType, sizeof(int));
		ar << m_bHasFather;
		if(!m_bHasFather)//�ޡ�����������ֺ�
		{	for(int i=0;i<4; i++)
					ar << m_nFontSize[i];
			ar.Write(&m_nFormulaCharMrg, sizeof(int));
		}
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nCompLoca, sizeof(int));
		ar.Read(&m_nFSIndex, sizeof(int));
		ar.Read(&m_nHor, sizeof(int));
		ar.Read(&m_nVer, sizeof(int));
		ar.Read(&m_nType, sizeof(int));
		SetMstObj( NULL );
		int nVersion = ar.GetObjectSchema();
		ar.SetObjectSchema( nVersion );
		nVersion = (int)LOWORD(nVersion);
		nVersion = (int)HIBYTE(nVersion); 
        switch(nVersion)
        {
			case 0:            // read in previous version of 
			{	int nOldFS[4] = { 637, 425, 247, 185 };
				for(int i=0;i<4; i++)
					m_nFontSize[i] = nOldFS[i];
				m_nFormulaCharMrg = 12;//��ֵΪ12
			}
			break;
			case 1:
			{	ar >> m_bHasFather;
				if(!m_bHasFather)//�ޡ�����������ֺ�
				{	for(int i=0;i<4; i++)
						ar >> m_nFontSize[i];
					ar.Read(&m_nFormulaCharMrg, sizeof(int));
				}
			}
			break;
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormCell::SetMstObj( CWPSObj* pObj )
{	m_pMstObj = pObj;
	if(pObj)
		m_bHasFather=TRUE;
	else 
		m_bHasFather=FALSE;
}

/*
void CFormCell::RenewCurObjDSPRows( CWpsView* pView, CreateProp cp/*=CP_Auto*)
{
	if ( pView->c_pCurCell && pView->c_pCurCell->IsKindOf(RUNTIME_CLASS(CFormABC)) )
	{	ASSERT( pView->c_pCurCell->GetWPSObjType() >= 0);
		pView->c_pCurCell->RenewCurObjDSPRows( pView, cp );
	}
}*/

//LLG_ADD_2001_3_31
//ȡ��ǰ����ʽ�������ɫ...


/////////////////////////////////////////////////////////////////////////////
//	CFormTB

//IMPLEMENT_SERIAL(CFormTB, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormTB, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormTB::CFormTB()
{                      
}

CFormTB::~CFormTB()
{
	ASSERT( this );
	DeleteContent();
}

void CFormTB::DeleteContent()
{
}      

void CFormTB::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormTB::Serialize_98(KSArchive& ar)
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_str;
		ar << m_rectChar;
		m_formula.Serialize(ar);	//	don't use ar.Write(&m_formula, sizeof(CFormula));
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_str;
		ar >> m_rectChar;
		m_formula.Serialize(ar);
		m_formula.SetMstObj( this );
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj( this );
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj( this );
			 if( m_str == "��" )
			m_str = "� ";	//	����Symbol�ַ�
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormTB::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_str;
		ar << m_rectChar;
		m_formula.Serialize(ar);	//	don't use ar.Write(&m_formula, sizeof(CFormula));
		m_formulaeTop.Serialize(ar);
		m_formulaeBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_str;
		ar >> m_rectChar;
		m_formula.Serialize(ar);
		m_formula.SetMstObj( this );
		m_formulaeTop.Serialize(ar);
		m_formulaeTop.SetMstObj( this );
		m_formulaeBot.Serialize(ar);
		m_formulaeBot.SetMstObj( this );
			 if( m_str == "��" )
			m_str = "� ";	//	����Symbol�ַ�
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
		else if( m_str == "��" )
			m_str = "� ";
	}
	CWPSObj::SerializeObjType(ar);
}

//BOOL CurObjIsMyFather( CWPSObj* pObj, CWPSObj* pFth );
extern TCHAR szDefCFontName[];
void DrawHalftoneRect( CDC* pDC, CRect& rc );
int GetCurFontDevHeight( CWpsView*, const int nHszLog );
extern int c_nInte;
CFont* GetFontObj( CDC* pDC, int nH, char*, BYTE lfItalic, int nWeight );
BOOL CreateSymbolFont(CFont& font, int nH, BYTE Italic, int nWeight);


//	��Ϊ pObj ����ʽ�ڲ������š�
//	���룺dw,dh �� pObj ����Ŀ��߸ı���
//	�����dw,dh �ǵ����󱾶���Ŀ�������
/////////////////////////////////////////////////////////////////////////////
//	CFormFrac

//IMPLEMENT_SERIAL(CFormFrac, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormFrac, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormFrac::CFormFrac()
{                      
}

CFormFrac::~CFormFrac()
{
	ASSERT( this );
	DeleteContent();
}

void CFormFrac::DeleteContent()
{
}      

#define FRAC_EXT		4		//	��������ͷ������ֵĳߴ磺0.4mm
#define FRAC_W		2			//	�������߿���0.2mm



void CFormFrac::Serialize_97( KSArchive& ar )
{
	ASSERT(FALSE);
}     

void CFormFrac::Serialize_98( KSArchive& ar )
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_rectFLine;
		m_formulaTop.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_rectFLine;
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj( this );
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj( this );
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormFrac::Serialize_01( KSArchive& ar )
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_rectFLine;
		m_formulaTop.Serialize(ar);
		m_formulaBot.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_rectFLine;
		m_formulaTop.Serialize(ar);
		m_formulaTop.SetMstObj( this );
		m_formulaBot.Serialize(ar);
		m_formulaBot.SetMstObj( this );
	}
	CWPSObj::SerializeObjType(ar);
}


/////////////////////////////////////////////////////////////////////////////
//	CFormMatr

//IMPLEMENT_SERIAL(CFormMatr, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormMatr, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormMatr::CFormMatr()
{   
	// �������ʼ��������������������!
	m_nCurR = 0;
	m_nCurC = 0;
}

CFormMatr::~CFormMatr()
{
	ASSERT( this );
	DeleteContent();
}

void CFormMatr::DeleteContent()
{
//  for ( int n=0; n<m_nR*m_nC; n++ )
	for (int i=0; i<m_objArray.GetSize(); i++ )	//	ע��m_objArray�ڶ�̬�仯
		delete m_objArray[i];
	m_objArray.RemoveAll();
}      





//	nR, nC��ʾ��������кţ���1��ʼ


void CFormMatr::Serialize_97( KSArchive& ar )
{
	ASSERT(FALSE);
}     

void CFormMatr::Serialize_98( KSArchive& ar )
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nR, sizeof(int));
		ar.Write(&m_nC, sizeof(int));
		ar.Write(&m_nHAlign, sizeof(int));
		ar.Write(&m_nVAlign, sizeof(int));
		ar.Write(&m_nBracket, sizeof(int));
		for(int n=0;n<=m_nR;n++)
			ar << m_nRow[n];
		for(int n=0;n<=m_nC;n++)
			ar << m_nColumn[n];
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nR, sizeof(int));
		ar.Read(&m_nC, sizeof(int));
		ar.Read(&m_nHAlign, sizeof(int));
		ar.Read(&m_nVAlign, sizeof(int));
		ar.Read(&m_nBracket, sizeof(int));
		for(int n=0;n<=m_nR;n++)
			ar >> m_nRow[n];
		for(int n=0;n<=m_nC;n++)
			ar >> m_nColumn[n];
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n=0; n<m_nR*m_nC; n++)
		{
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj( this );
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormMatr::Serialize_01( KSArchive& ar )
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar.Write(&m_nR, sizeof(int));
		ar.Write(&m_nC, sizeof(int));
		ar.Write(&m_nHAlign, sizeof(int));
		ar.Write(&m_nVAlign, sizeof(int));
		ar.Write(&m_nBracket, sizeof(int));
		for(int n=0;n<=m_nR;n++)
			ar << m_nRow[n];
		for(int n=0;n<=m_nC;n++)
			ar << m_nColumn[n];
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar.Read(&m_nR, sizeof(int));
		ar.Read(&m_nC, sizeof(int));
		ar.Read(&m_nHAlign, sizeof(int));
		ar.Read(&m_nVAlign, sizeof(int));
		ar.Read(&m_nBracket, sizeof(int));
		for(int n=0;n<=m_nR;n++)
			ar >> m_nRow[n];
		for(int n=0;n<=m_nC;n++)
			ar >> m_nColumn[n];
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n=0; n<m_nR*m_nC; n++)
		{	pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj( this );
		}
	}
	CWPSObj::SerializeObjType(ar);
}


/////////////////////////////////////////////////////////////////////////////
