/* -------------------------------------------------------------------------
//	�ļ���		��	style_text.cpp
//	������		��	����
//	����ʱ��	��	2004-10-22 12:27:29 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ctrlcode.h"
#include "ctrlcodetool.h"
#include "style_text.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(CStyle_Text, CStyleBase, VERSIONABLE_SCHEMA | 98)

CStyle_Text::CStyle_Text()
{
	m_dwBaseStyle = TSID_TEXT_NORMAL;
	m_dwStyle = TSID_USERDEFINEDPS;
	m_dwPreStyle = TSID_NULL;
	m_dwFollowStyle = TSID_NULL;
//	m_nStyleType = tst_para;
}

CStyle_Text::~CStyle_Text()
{
	DeleteAttribList();
}

CCtrlCode* CStyle_Text::GetCtrlCode(UINT uID)
{
	ASSERT_VALID(this);
	CCtrlCode* pCode = NULL;
	
	pCode = CtrlCodeTool.FindCtrlCode(&m_CAList, uID);
	if (NULL == pCode)
	{
		pCode = CtrlCodeTool.FindCtrlCode(&m_PAList, uID);
	}
	
	return pCode;
}

void CStyle_Text::DeleteAttribList(UINT uFlag/*=DAL_BOTH*/)
{
	POSITION pos;
	CObject* pObj;
	if ((uFlag & DAL_CHAR)!=NULL)
	{	for(pos=m_CAList.GetHeadPosition(); pos;)
		{	pObj = m_CAList.GetNext(pos); ASSERT_VALID(pObj);
			delete pObj;
		}
		m_CAList.RemoveAll();
	}

	if ((uFlag & DAL_PARA)!=NULL)
	{	for(pos=m_PAList.GetHeadPosition(); pos;)
		{	pObj = m_PAList.GetNext(pos); ASSERT_VALID(pObj);
			delete pObj;
		}
		m_PAList.RemoveAll();
	}
}

STDMETHODIMP StylePara_Serialize_Write(CObList& PAList, KSArchive& ar);
STDMETHODIMP StylePara_Serialize_Read(CObList& PAList, KSArchive& ar);
STDMETHODIMP StyleSent_Serialize_Write(CObList& PAList, KSArchive& ar);
STDMETHODIMP StyleSent_Serialize_Read(CObList& PAList, KSArchive& ar);

void CStyle_Text::Serialize_98(CArchive& ar)
{
	CStyleBase::Serialize_98(ar);

	if (ar.IsStoring())
	{
		ASSERT(FALSE);
	}
	else
	{
		ar >> m_dwStyle;
		ar >> m_dwBaseStyle;
		ar >> m_strBaseStyleName;
#ifndef _GWSREADER
		if (g_lpConvProc && !m_strBaseStyleName.IsEmpty())
		{
			// ��Ҫʱת����������
			CString* pStr = &m_strBaseStyleName;
			int nLen = pStr->GetLength();
			LPTSTR lpsz = pStr->GetBuffer(nLen);
			g_lpConvProc(lpsz, nLen);
			pStr->ReleaseBuffer(nLen);
		}
#endif	// #ifndef _GWSREADER
		DWORD dwTemp;
		ar >> dwTemp;		// 16 �ֽڻ���
		ar >> dwTemp;
		ar >> dwTemp;
		ar >> dwTemp;
	//	m_nStyleType = tst_para;
	}

#ifdef _GWS
	// δ��WPS2001�����е���
#endif	// #ifdef _GWS

	if (g_fCompoundFile) // wps2002-io-ctrlcode, by tsingbo
	{
		if (ar.IsStoring())
		{
			StylePara_Serialize_Write(m_PAList, ar);
			StyleSent_Serialize_Write(m_CAList, ar);
		}
		else
		{
			StylePara_Serialize_Read(m_PAList, ar);
			StyleSent_Serialize_Read(m_CAList, ar);
		}
		return;
	}
	
	// {{ wps2002-io-ctrlcode, old version serialize, by tsingbo

	m_PAList.Serialize(ar);
	
	// ����� WPS 2000 �� WPS �����ļ����ڴ��˵� wps2001 �����п�����
	CObList List;
	CCtrlCode* pObj;
	POSITION pos1, pos2;
	WORD wID;
	if (g_bExport2Wps2000 && ar.IsStoring())
	{
		for (pos1 = m_CAList.GetHeadPosition(); (pos2 = pos1) != NULL;)
		{
			pObj = (CCtrlCode*)m_CAList.GetNext(pos1);
			ASSERT_VALID(pObj);
			wID = pObj->GetCodeID();
			if (wID == SETGWSREF || (g_bExport2Wps2000 &&
					(wID == SETHYPERREF || wID == SETLABEL
					|| wID == SETREVISE || SETOUTRECT == wID
					|| SETBGVEIN == wID)))
			{
				m_CAList.RemoveAt(pos2);
				List.AddTail(pObj);
			}
		}
	}
	m_CAList.Serialize(ar);
	for (pos1 = List.GetHeadPosition(); (pos2 = pos1) != NULL;)
	{
		pObj = (CCtrlCode*)List.GetNext(pos1);
		ASSERT_VALID(pObj);
#ifdef _DEBUG
		wID = pObj->GetCodeID();
		ASSERT (wID == SETHYPERREF || wID == SETLABEL
			|| wID == SETREVISE || wID == SETGWSREF
			|| SETOUTRECT == wID || SETBGVEIN == wID);
#endif // #ifdef _DEBUG
		List.RemoveAt(pos2);
		m_CAList.AddTail(pObj);
	}

#ifdef _GWS
#ifndef _GWSREADER
	// ��ȥ��ɾ��Ϊ���̶���ʱ�����ӵĿ�����
	// �����Ϊ���̶���ʱ�Ƴ���ԭ�п�����
	if (m_dwStyle == TSID_TEXT_FIRST && g_pWPSFHeader != NULL)
	{
		if (pCode0)
			RemoveCtrlCode(pList, pCode0, TRUE);
		else if (pCode1)
			pList->AddTail(pCode1);
		if (pCode2)
			RemoveCtrlCode(pList, pCode2, TRUE);
		else if (pCode3)
			pList->AddTail(pCode3);
	}
#endif	// #ifndef _GWSREADER
#endif
}

void CStyle_Text::Serialize_01(CArchive& ar)
{
	Serialize_98(ar);

	if (ar.IsStoring())
	{
		ASSERT(FALSE);
	}
	else
	{
		ar >> m_dwPreStyle;
		ar >> m_strPreStyleName;
		ar >> m_dwFollowStyle;
		ar >> m_strFollowStyleName;

		if (g_lpConvProc && !m_strPreStyleName.IsEmpty())
		{
			// ��Ҫʱת����������
			CString* pStr = &m_strPreStyleName;
			int nLen = pStr->GetLength();
			LPTSTR lpsz = pStr->GetBuffer(nLen);
			g_lpConvProc(lpsz, nLen);
			pStr->ReleaseBuffer(nLen);
		}
		if (g_lpConvProc && !m_strFollowStyleName.IsEmpty())
		{
			// ��Ҫʱת����������
			CString* pStr = &m_strFollowStyleName;
			int nLen = pStr->GetLength();
			LPTSTR lpsz = pStr->GetBuffer(nLen);
			g_lpConvProc(lpsz, nLen);
			pStr->ReleaseBuffer(nLen);
		}
	}
}



// -------------------------------------------------------------------------
