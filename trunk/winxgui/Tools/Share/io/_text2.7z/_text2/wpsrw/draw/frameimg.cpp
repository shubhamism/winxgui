/* -------------------------------------------------------------------------
//	�ļ���		��	frameimg.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 18:45:48
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "frameimg.h"

#if defined(WPP_ONLY)
#include <pres/wppdoc.h> // for CFrameImage constructor
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CFrameImage, CFrameObj, 0xA0 | VERSIONABLE_SCHEMA)	// for WPS01

// -------------------------------------------------------------------------

//����ͼ���m_extent���ã�
//����beta�汾�������Ѷ����ݲ����޸�
CFrameImage::CFrameImage() //: m_extent(0,0)
{
	m_pImg = NULL;
}

CFrameImage::CFrameImage(const CWpsDoc* pDoc, const CRect& position)
	: CFrameObj(pDoc, position) //, m_extent(0, 0)
{
	m_pImg = NULL;

/*@@todo
	SetWPSObjType(FRAMEImg);
	SetLPenStyle(PS_NULL);	// �ޱ߿�
	m_bTiled = FALSE;
	m_regRect = CRect(0, 0, 0, 0);
*/
	
#if defined(WPP_ONLY)
	//LLG_ADD_2001_3_1
	//ͼ��򲻾�CWxxDoc::NewObject(...)������������û��������WPP��س�ֵ
	//��ص��ļ���viewByhy.cpp -> BOOL CWpsView::OnInsertPicture(UINT uID)
	//��̫�淶���������ܱ�֤������ȷ...
	if (pDoc)
	{
		CWPPDoc* pWPPDoc = (CWPPDoc*)pDoc;
		pWPPDoc->SetObjAttribWithDefault(this);
	}
#endif
}

// -------------------------------------------------------------------------

void CFrameImage::Serialize_97(KSArchive& ar)
{
	ASSERT_VALID(this);

	CFrameObj::Serialize_97(ar);

	if (ar.IsStoring())
	{
		ASSERT(FALSE);
	}
	else
	{
		__int16 wTemp;
		ar >> wTemp; m_extent.cx = wTemp;
		ar >> wTemp; m_extent.cy = wTemp;
		ar >> m_pImg;
		
		if (m_pImg)
		{
			SetImgFrame(m_pImg, this);
			CheckImgSizeType();
		}
		m_bTiled = FALSE;
	}

	CWPSObj::SerializeObjType(ar);
}

void CFrameImage::Serialize_98(KSArchive& ar)
{
	ASSERT_VALID(this);

	CWpsImage* pBak = m_pImg;
	m_pImg = NULL;		// => 7-7,'99������־��db
	CFrameObj::Serialize_98(ar);
	m_pImg = pBak;

	if (ar.IsStoring())
	{
		ar << m_extent;
		ar << m_bTiled;
		ar << m_regRect;
		ar << m_pImg;
	}
	else
	{
		ar >> m_extent;
		ar >> m_bTiled;																 
		ar >> m_regRect;
		ar >> m_pImg;
		if (m_pImg)
		{
			SetImgFrame(m_pImg, this);		
			CheckImgSizeType();
		}
		else
		{
			ASSERT(FALSE);
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFrameImage::Serialize_01(KSArchive& ar)
{
	ASSERT_VALID(this);

	CWpsImage* pBak = m_pImg;
	m_pImg = NULL;		// => 7-7,'99������־��db
	CFrameObj::Serialize_01(ar);
	m_pImg = pBak;

	if (ar.IsStoring())
	{
		ar << m_extent;
		ar << m_bTiled;
		ar << m_regRect;
		ar << m_pImg;
	}
	else
	{
		ar >> m_extent;
		ar >> m_bTiled;																 
		ar >> m_regRect;
		ar >> m_pImg;

		if (m_pImg)
		{
			SetImgFrame(m_pImg, this);		
			CheckImgSizeType();
		}
		else
		{
			ASSERT(FALSE);
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

// -------------------------------------------------------------------------
