/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_ioadapter.cpp
//	������		��	����
//	����ʱ��	��	2004-11-10 5:07:17 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __AUTONUM_ATOM_H
#include "autonum_atom.h"
#endif

#include "autonum_ioadapter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

HRESULT KAutoNumIOAdapter::AddGroupIDKey(const int& key, const KAutoNumGroupSPtr& value)
{
	HRESULT hr	= S_OK;
	mapAutoNumIntKey::iterator iter;
	std::pair<mapAutoNumIntKey::iterator, bool> prRet;
	prRet	= m_MapGroupIntKey.insert(mapAutoNumIntKey::value_type(key, value));
	hr	= prRet.second ? S_OK : E_FAIL;
	return hr;
}

// oldgroupID map old level
HRESULT KAutoNumIOAdapter::AddOldGroupIDKey(const int& key, const int& nOldLevel)
{
	HRESULT hr	= S_OK;
	mapAutoNumOldGroupID2Level::iterator iter;
	std::pair<mapAutoNumOldGroupID2Level::iterator, bool> prRet;
	prRet	= m_MapOldGroupID2Level.insert(mapAutoNumOldGroupID2Level::value_type(key, nOldLevel));
	hr	= prRet.second ? S_OK : E_FAIL;
	return hr;
}

HRESULT KAutoNumIOAdapter::GetGroupSPtrValue(const int& key, KAutoNumGroupSPtr& value)
{
	HRESULT hr							= S_OK;
	value								= NULL;
	mapAutoNumIntKey::iterator iter	= m_MapGroupIntKey.find(key);
	if (m_MapGroupIntKey.end() != iter)
		value	= (*iter).second;
	else
		hr		= E_FAIL;
	return hr;
}

// -------------------------------------------------------------------------
