/* -------------------------------------------------------------------------
//	�ļ���		��	bookmark.cpp
//	������		��	����
//	����ʱ��	��	2004-10-15 5:39:19 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __TEXTPOOL_H__
#include "textpool.h"
#endif

#include "bookmark.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CBookMark::CBookMark(int nID, BOOL bIsBlock, LPCTSTR lp, CParagraph* pPa)
{
	m_nBookMarkID = nID;
	m_bIsBlock = bIsBlock;
	m_pParagraph = pPa;
	if (lp)
	{
		ASSERT(::lstrlen(lp) < SIZE_BOOKMARK);
		::lstrcpy(m_szBookMark, lp);
	}
}

void CBookMark::SerializeEx (CFile& memFile, BOOL bIsOutput)
{
	WORD wLen;
	if (bIsOutput)
	{
		ASSERT(FALSE);
	}
	else
	{
		memFile.Read(&m_nBookMarkID, sizeof(int));
		memFile.Read(&m_bIsBlock, sizeof(BOOL));
		memFile.Read(&wLen, sizeof(WORD));
		memFile.Read(&m_szBookMark, wLen);
//		m_pParagraph = NULL;		// ע�⣺�˱������ڽ������ļ�����������������

		if (m_nBookMarkID <= 0 || wLen < 0)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

// -------------------------------------------------------------------------

CBookMarkMan::CBookMarkMan()
{
}

CBookMarkMan::~CBookMarkMan()
{
	int nSize = NumOfBookMarks();
	for (int i = 0; i < nSize; i++)
		delete m_aryBookMarks[i];
}

CBookMark* CBookMarkMan::GetBookMark(int i) const
{
	ASSERT_VALID(this);
	ASSERT(i >= 0 && i < NumOfBookMarks());
	if (i >= 0 && i < NumOfBookMarks())
		return (CBookMark*)m_aryBookMarks[i];
	return NULL;
}

const CBookMark* CBookMarkMan::GetBookMarkFromID(int nID) const
{
	ASSERT_VALID(this);
	const CBookMark* pbk;
	int nSize = NumOfBookMarks();
	for (int i = 0; i < nSize; i++)
	{
		pbk = (const CBookMark*)m_aryBookMarks[i];
		ASSERT_VALID(pbk);
		if (pbk && nID == pbk->GetBookMarkID())
			return pbk;
	}
	TRACEA("--------------> ��֣���ôû���ҵ������ǩ�أ�\n");
	return NULL;
}

void CBookMarkMan::SerializeEx (CTextPool* pPool, CFile& memFile, BOOL bIsOutput)
{
#ifdef _DEBUG
	if (pPool)
		ASSERT_VALID(pPool);
	ASSERT_VALID(&memFile);
#endif // #ifdef _DEBUG

	CBookMark* pBM;
	int nSize;
	int nPara;
	if (bIsOutput)
	{
		ASSERT(FALSE);
	}
	else
	{
		CParagraph* pPara;
		memFile.Read(&nSize, sizeof(int));
		for (int i = 0; i < nSize; i++)
		{
			memFile.Read(&nPara, sizeof(int));
			pPara = NULL;
			if (pPool)
			{
				ASSERT_VALID(pPool);
				pPara = pPool->GetParagraph(nPara);
				ASSERT_VALID(pPara);
			}

			pBM = new CBookMark(0, 0, NULL, pPara);
			ASSERT_VALID(pBM);
			if (pBM)
			{
				pBM->SerializeEx (memFile, bIsOutput);
				m_aryBookMarks.Add(pBM);
			}
		}

		if (nSize < 0)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}
	}
}

