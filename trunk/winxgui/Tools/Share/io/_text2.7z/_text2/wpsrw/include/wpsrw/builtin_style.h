/* -------------------------------------------------------------------------
//	�ļ���		��	wpsrw/builtin_style.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 14:29:26
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPSRW_BUILTIN_STYLE_H__
#define __WPSRW_BUILTIN_STYLE_H__

// -------------------------------------------------------------------------

#define		LIMIT_CBSTYLENAME		64		// ��ʽ����󳤶� (��λ��TCHAR)

// TSID: tEXT sTYLE id

#define		TSID_PARASTYLE			1
#define		TSID_CHARSTYLE			2

// 0x0 �� 0x1F������
#define		TSID_RESERVED_FIRST		0x00
#define		TSID_NULL				0X00
#define		TSID_UNDETERMINED		0X01
#define		TSID_USERDEFINED		0X02
#define		TSID_USERDEFINEDPS		0X02	// �û��Զ������ʽ
#define		TSID_USERDEFINEDCS		0X03	// �û��Զ�������ʽ

#define		TSID_RESERVED_LAST		0x1F

// ������ʽ (�ں���������) �� ID ��Χ
#define		TSID_PARASTYLE_FIRST	0x0020
#define		TSID_PARASTYLE_LAST		0x1FFF

// ������ʽ�� ID ��Χ
#define		TSID_CHARSTYLE_FIRST	0x2000
#define		TSID_CHARSTYLE_LAST		0x3FFF

//=====================================================================

// 0x20 ~ 0x2F: Ŀ¼
#define		TSID_TOC_FIRST		0x20
#define		TSID_TOC_0			0x20
#define		TSID_TOC_1			0x21
#define		TSID_TOC_2			0x22
#define		TSID_TOC_3			0x23
#define		TSID_TOC_4			0x24
#define		TSID_TOC_5			0x25
#define		TSID_TOC_6			0x26
#define		TSID_TOC_7			0x27
#define		TSID_TOC_8			0x28
#define		TSID_TOC_9			0x29
#define		TSID_TOC_A			0x2A
#define		TSID_TOC_B			0x2B
#define		TSID_TOC_C			0x2C
#define		TSID_TOC_D			0x2D
#define		TSID_TOC_E			0x2E
#define		TSID_TOC_F			0x2F
#define		TSID_TOC_LAST		0x2F

// 0x30 ~ 0x3F: ���±���
#define		TSID_TITLE_FIRST	0x30
#define		TSID_TITLE_0		0x30
#define		TSID_TITLE_1		0x31
#define		TSID_TITLE_2		0x32
#define		TSID_TITLE_3		0x33
#define		TSID_TITLE_4		0x34
#define		TSID_TITLE_5		0x35
#define		TSID_TITLE_6		0x36
#define		TSID_TITLE_7		0x37
#define		TSID_TITLE_8		0x38
#define		TSID_TITLE_9		0x39
#define		TSID_TITLE_A		0x3A
#define		TSID_TITLE_B		0x3B
#define		TSID_TITLE_C		0x3C
#define		TSID_TITLE_D		0x3D
#define		TSID_TITLE_E		0x3E
#define		TSID_TITLE_F		0x3F
#define		TSID_TITLE_LAST		0x3F

// 0x30 ~ 0x3F: �½ڱ���
#define		TSID_HEADER_FIRST	0x40
#define		TSID_HEADER_0		0x40
#define		TSID_HEADER_1		0x41
#define		TSID_HEADER_2		0x42
#define		TSID_HEADER_3		0x43
#define		TSID_HEADER_4		0x44
#define		TSID_HEADER_5		0x45
#define		TSID_HEADER_6		0x46
#define		TSID_HEADER_7		0x47
#define		TSID_HEADER_8		0x48
#define		TSID_HEADER_9		0x49
#define		TSID_HEADER_A		0x4A
#define		TSID_HEADER_B		0x4B
#define		TSID_HEADER_C		0x4C
#define		TSID_HEADER_D		0x4D
#define		TSID_HEADER_E		0x4E
#define		TSID_HEADER_F		0x4F
#define		TSID_HEADER_LAST	0x4F

// 0x40 ~ 0x4F: ����
#define		TSID_TEXT_FIRST		0x50
#define		TSID_TEXT_0			0x50
#define		TSID_TEXT_1			0x51
#define		TSID_TEXT_2			0x52
#define		TSID_TEXT_3			0x53
#define		TSID_TEXT_4			0x54
#define		TSID_TEXT_5			0x55
#define		TSID_TEXT_6			0x56
#define		TSID_TEXT_7			0x57
#define		TSID_TEXT_8			0x58
#define		TSID_TEXT_9			0x59
#define		TSID_TEXT_A			0x5A
#define		TSID_TEXT_B			0x5B
#define		TSID_TEXT_C			0x5C
#define		TSID_TEXT_D			0x5D
#define		TSID_TEXT_E			0x5E
#define		TSID_TEXT_F			0x5F
#define		TSID_TEXT_LAST		0x5F

// 0x60 ~ 0x6F: Ŀ¼����
#define		TSID_TOCTITLE_FIRST	0x60
#define		TSID_TOCTITLE_0		0x60
#define		TSID_TOCTITLE_1		0x61
#define		TSID_TOCTITLE_2		0x62
#define		TSID_TOCTITLE_3		0x63
#define		TSID_TOCTITLE_4		0x64
#define		TSID_TOCTITLE_5		0x65
#define		TSID_TOCTITLE_6		0x66
#define		TSID_TOCTITLE_7		0x67
#define		TSID_TOCTITLE_8		0x68
#define		TSID_TOCTITLE_9		0x69
#define		TSID_TOCTITLE_A		0x6A
#define		TSID_TOCTITLE_B		0x6B
#define		TSID_TOCTITLE_C		0x6C
#define		TSID_TOCTITLE_D		0x6D
#define		TSID_TOCTITLE_E		0x6E
#define		TSID_TOCTITLE_F		0x6F
#define		TSID_TOCTITLE_LAST	0x6F

#define		TSID_TEXT_NORMAL	TSID_TEXT_0

// ������ʽ
#define		TSID_CHAR_DEFAULT	0x2000

// -------------------------------------------------------------------------

#endif /* __WPSRW_BUILTIN_STYLE_H__ */
