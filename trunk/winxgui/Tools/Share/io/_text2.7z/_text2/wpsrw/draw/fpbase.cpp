/* -------------------------------------------------------------------------
//	�ļ���		��	fpbase.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-21 14:56:10
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <core/wpsdoc.h>
#include "fpbase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CTFPBase, CWPSObj, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)	//	01�汾�Ķ����ʶ��Ϊ 0xA0
IMPLEMENT_SERIAL(CFPBase, CTFPBase, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)	//	01�汾�Ķ����ʶ��Ϊ 0xA0

// -------------------------------------------------------------------------

CTFPBase::CTFPBase(const CWpsDoc* pDoc, const CRect& position)
	: CWPSObj(pDoc, position)
{
	ASSERT_VALID(this);
	//	���������
	SetWPSObjType(TFPBase);
	
	m_nBkMode			= pDoc->m_DefProp.m_nBkMode;
	m_bkColor			= pDoc->m_DefProp.m_bkColor;
	m_logbrush.lbStyle	= pDoc->m_DefProp.m_logbrush.lbStyle;
	m_logbrush.lbColor	= pDoc->m_DefProp.m_logbrush.lbColor;
	m_logbrush.lbHatch	= pDoc->m_DefProp.m_logbrush.lbHatch;
	m_nColorDirection	= pDoc->m_DefProp.m_nColorDirection;
	m_nColorDistortion	= pDoc->m_DefProp.m_nColorDistortion;
	m_nTransparence     = pDoc->m_DefProp.m_nTransparence;        // wps2002-io-wait-wdb  
}

void CTFPBase::Serialize_97(CArchive& ar)
{
	CWPSObj::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		SHORT wTemp;
		DWORD dwTemp;
		ar >> wTemp; 	m_nBkMode = (BOOL)wTemp;
		ar >> dwTemp;	m_bkColor = (DWORD)dwTemp;
		ar >> wTemp; 	m_logbrush.lbStyle = wTemp;
		ar >> dwTemp; 	m_logbrush.lbColor = dwTemp;
		ar >> wTemp; 	m_logbrush.lbHatch = wTemp;
		//	01�����������趨
		m_nColorDirection	= GRAD_HORIZ;
		m_nColorDistortion	= GRAD_LEFTTOP;
		m_nTransparence = 0;					// wps2002-io-wait-wdb
	}
}

void CTFPBase::Serialize_98(CArchive& ar)
{
	CWPSObj::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_nBkMode;
		ar << m_bkColor;
		ar.Write(&m_logbrush, sizeof(LOGBRUSH));
	}
	else
	{
		ar >> m_nBkMode;
		ar >> m_bkColor;
		ar.Read(&m_logbrush, sizeof(LOGBRUSH));
		//	01�����������趨
		m_nColorDirection	= GRAD_HORIZ;
		m_nColorDistortion	= GRAD_LEFTTOP;
		m_nTransparence = 0;					// wps2002-io-wait-wdb
	}
}

STDMETHODIMP CTFPBase::Serialize_Write_02(KSArchive& ar)
{
	WPSObjFillData rec0;
	WPSFill& rec = rec0.fill;
	ZeroMemory(&rec, sizeof(rec));

	UINT cbRecord = sizeof(rec0.fillOpcity) + 4;
	
	KWPSMainWriter wr;
	wr.Attach(&ar);

	rec0.fillOpcity = (SHORT)(m_nTransparence*10);
	rec.lbStyle		= m_logbrush.lbStyle;
	rec.lbHatch		= m_logbrush.lbHatch;
	switch (m_nBkMode)
	{
	case INVERT:
		rec.fillMode = WPSFill_Invert;
		rec.invertFill.fillColor = m_logbrush.lbColor;
		rec.invertFill.bkColor = m_bkColor;
		cbRecord += sizeof(rec.invertFill);
		break;
	case TRANSPARENT:
		rec.fillMode = WPSFill_Transparent;
		rec.transparentFill.fillColor = m_logbrush.lbColor;
		cbRecord += sizeof(rec.transparentFill);
		break;
	case OPAQUE:
		rec.fillMode = WPSFill_Solid;
		rec.solidFill.fillColor = m_logbrush.lbColor;
		rec.solidFill.bkColor = m_bkColor;
		cbRecord += sizeof(rec.solidFill);
		break;
	case GRADIENT:
		rec.fillMode = WPSFill_Gradient;
		rec.gradientFill.shadeColor[0] = m_logbrush.lbColor;
		rec.gradientFill.shadeColor[1] = m_bkColor;
		rec.gradientFill.shadeDir	= m_nColorDirection;
		rec.gradientFill.shadeStyle = m_nColorDistortion;
		cbRecord += sizeof(rec.gradientFill);
		break;
	default:
		REPORT_ONCE("δ֪�����ģʽ");
	}
	_WPSWriteRecord(wr, TAG_WPSObjFillData, &rec0, cbRecord);
	return S_OK;
}

STDMETHODIMP CTFPBase::Serialize_Read_02(KSArchive& ar)
{
	HRESULT hr;
	WPSObjFillData rec0;
	hr = __WPSReadRecord(ar, TAG_WPSObjFillData, rec0);
	if (hr != S_OK)
		return hr;
	
	WPSFill& rec = rec0.fill;
	m_nTransparence		= rec0.fillOpcity / 10;
	m_logbrush.lbStyle	= rec.lbStyle;
	m_logbrush.lbHatch	= rec.lbHatch;
	switch (rec.fillMode)
	{
	case WPSFill_Invert:
		m_nBkMode			= INVERT;
		m_logbrush.lbColor	= rec.invertFill.fillColor;
		m_bkColor			= rec.invertFill.bkColor;
		break;
	case WPSFill_Transparent:
		m_nBkMode			= TRANSPARENT;
		m_logbrush.lbColor	= rec.transparentFill.fillColor;
		break;
	case WPSFill_Solid:
		m_nBkMode			= OPAQUE;
		m_logbrush.lbColor	= rec.solidFill.fillColor;
		m_bkColor			= rec.solidFill.bkColor;
		break;
	case WPSFill_Gradient:
		m_nBkMode			= GRADIENT;
		m_logbrush.lbColor	= rec.gradientFill.shadeColor[0];
		m_bkColor			= rec.gradientFill.shadeColor[1];
		m_nColorDirection	= rec.gradientFill.shadeDir;
		m_nColorDistortion	= rec.gradientFill.shadeStyle;
		break;
	default:
		REPORT_ONCE("δ֪�����ģʽ");
	}
	return S_OK;	
}

void CTFPBase::Serialize_01(CArchive& ar)
{
	CWPSObj::Serialize_01(ar);
	if (g_fCompoundFile) // wps2002-io-tfpbase, by tsingbo
	{
		if (ar.IsStoring())
			Serialize_Write_02(ar);
		else
			Serialize_Read_02(ar);
		return;
	}
	// wps2002-io-tfpbase, old version serialize, by tsingbo
	if (ar.IsStoring())
	{
		ar << m_nBkMode;
		ar << m_bkColor;
		ar.Write(&m_logbrush, sizeof(LOGBRUSH));
		//	01����
		ar << m_nColorDirection;
		ar << m_nColorDistortion;
	}
	else
	{
		ar >> m_nBkMode;
		ar >> m_bkColor;
		ar.Read(&m_logbrush, sizeof(LOGBRUSH));
		//	01����
		ar >> m_nColorDirection;
		ar >> m_nColorDistortion;

		//LLG_MODIFY_2002_5_31
		//����һ���������������ȱ�ݣ�
		//�����������öԻ��򣬻��н���ɫ����ɫֵΪ��Чֵ�����(0xffffffff)��
		//��ʱ�ͻ���ֽ���ɫ��ڵ�����...
		//�Ի��򸳳�ֵ�Ĵ�~~
		if (m_nBkMode == GRADIENT)
		{			
			if (m_logbrush.lbColor == CPID_SYSTEM_INVALIDVALUE)
				m_logbrush.lbColor = RGB(255, 255, 255);
			if (m_bkColor == CPID_SYSTEM_INVALIDVALUE)
				m_bkColor  = RGB(255, 255, 255);
		}
	}
}

// -------------------------------------------------------------------------

void CFPBase::Serialize_97(CArchive& ar)
{
	CTFPBase::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		__int16  wTemp;
		DWORD dwTemp;
		ar >> wTemp;	m_nCompLoca  = (int)wTemp;
		ar >> wTemp;	m_nDispStyle = (int)wTemp;
		ar >> wTemp;	m_bNoPrint 	 = (BOOL)wTemp;
		ar >> wTemp;	m_uLPenStyle = (UINT)wTemp;
		ar >> wTemp;	m_uLPenSize  = (UINT)wTemp;
		ar.Read(&m_LPenColor, sizeof(COLORREF));
		ar >> wTemp;    m_shadowPnt.x = wTemp;
		ar >> wTemp;    m_shadowPnt.y = wTemp;
		ar >> dwTemp;	m_shadowColor = (DWORD)dwTemp;
		ar >> wTemp;	m_shadowStyle = (int)wTemp;
		//	98�����������趨
		m_bLock = FALSE;

		//@@todo
		//m_dwObjID = m_pDocument->GetObjIDCount();
		//--> ��Ϊ��
		CWpsDoc* pDocument = (CWpsDoc*)ar.m_pDocument;
		ASSERT_VALID(pDocument);
		m_dwObjID = pDocument->GetObjIDCount();

		m_pMstObj = NULL;
		m_pMstObj2 = NULL;
		m_ObjConnPnt = CPoint(0,0);
	}
}

void CFPBase::Serialize_98(CArchive& ar)
{
	CTFPBase::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_nCompLoca;
		ar << m_nDispStyle;
		ar << m_bNoPrint;
		ar.Write(&m_uLPenStyle, sizeof(UINT));
		ar.Write(&m_uLPenSize,  sizeof(UINT));
		ar.Write(&m_LPenColor, sizeof(COLORREF));
		ar << m_shadowPnt;
		ar << m_shadowColor;
		ar << m_shadowStyle;
		//	98����
		ar << m_bLock;
		ar << m_dwObjID;
		int nNum = m_SlvObjIDArray.GetSize();
		if (nNum != 0)	//	�ر�Ϊ���ܱ�������е�ƴ�ӹ�ϵ����
		{
			ar << nNum;
			DWORD dw;
			for (int i=0; i < nNum; i++)
			{	dw = m_SlvObjIDArray.GetAt(i);
				ar << dw;
			}
		}
		else
		{	ar << m_SlvObjList.GetCount();
			POSITION pos = m_SlvObjList.GetHeadPosition();
			CFPBase* pObj;
			while (pos)
			{	pObj = (CFPBase*)m_SlvObjList.GetNext(pos);	ASSERT_VALID(pObj);
				ASSERT(pObj->m_dwObjID != m_dwObjID);
				ar << pObj->m_dwObjID;
			}
		}
		ar << m_ObjConnPnt;
	}
	else
	{
		ar >> m_nCompLoca;
		ar >> m_nDispStyle;
		ar >> m_bNoPrint;
		ar.Read(&m_uLPenStyle, sizeof(UINT));
		ar.Read(&m_uLPenSize,  sizeof(UINT));
		ar.Read(&m_LPenColor, sizeof(COLORREF));
		ar >> m_shadowPnt;
		ar >> m_shadowColor;
		ar >> m_shadowStyle;
		//	98����
		ar >> m_bLock;
		ar >> m_dwObjID;
		int nNum = 0;
		ar >> nNum;
		//	����m_SlvObjList�����������ǰҳ�ļ��������ܽ���������m_SlvObjIDArray
		//	���桰��ӡ������ID�ţ��ڵ�::ResumeObjConnect()ʱ
		//	��m_SlvObjIDArrayȥ����m_SlvObjList��
		m_SlvObjIDArray.RemoveAll();
		DWORD dwTemp;
		for (int i=0; i < nNum; i++)
		{	ar >> dwTemp;
			m_SlvObjIDArray.Add(dwTemp);
		}
		m_pMstObj = NULL;		//	���䡰����Ϊ��
		m_pMstObj2 = NULL;
		ar >> m_ObjConnPnt;
	}
}

// -------------------------------------------------------------------------

CFPBase::CFPBase(const CWpsDoc* pDoc, const CRect& position)
	: CTFPBase(pDoc, position)
{
	ASSERT_VALID(this);
	//	���������
	SetWPSObjType(FPBase);
	m_nCompLoca = pDoc->m_DefProp.m_nCompLoca;	//	�Ű�λ������
	m_nDispStyle = pDoc->m_DefProp.m_nDispStyle;	//	����Ļ��Ʋ�����
	m_bNoPrint = pDoc->m_DefProp.m_bNoPrint;		//	���󲻴�ӡ
	m_uLPenStyle = pDoc->m_DefProp.m_uLPenStyle;	//	�������
	m_uLPenSize  = pDoc->m_DefProp.m_uLPenSize;	//	0.2 mm
	m_LPenColor = pDoc->m_DefProp.m_LPenColor;
	m_shadowPnt = pDoc->m_DefProp.m_shadowPnt;	//	��Ӱƫ������
	m_shadowColor = pDoc->m_DefProp.m_shadowColor;//	��Ӱɫ
	m_shadowStyle = pDoc->m_DefProp.m_shadowStyle;//	��Ӱ���(��ɫ)
	//	98��������
	m_bLock = pDoc->m_DefProp.m_bLock;	//	��������
	//	����ƴ��
	m_pMstObj	= NULL;
	m_pMstObj2	= NULL;
	if (pDoc)
	{
		m_dwObjID = 0;
		SetObjID(pDoc->GetObjIDCount());
	}
	m_ObjConnPnt= CPoint(0,0);
}

#define _WPS_CntSlvObj_Max		((WPSRecordSizeMax - sizeof(WPSFPBaseData))/sizeof(DWORD))

STDMETHODIMP CFPBase::Serialize_Write_02(KSArchive& ar)
{
	UINT nCntSlvObj;
	WPSFPBaseData rec;
	KWPSMainWriter wr;
	wr.Attach(&ar);
	
	nCntSlvObj = m_SlvObjIDArray.GetSize();
	if (nCntSlvObj == 0)
		nCntSlvObj = m_SlvObjList.GetCount();

	ASSERT(nCntSlvObj <= _WPS_CntSlvObj_Max);
	if (nCntSlvObj > _WPS_CntSlvObj_Max)
		nCntSlvObj = _WPS_CntSlvObj_Max;
	
	rec.nCompLoca		= m_nCompLoca;
	rec.nDispStyle		= m_nDispStyle;
	rec.fNoPrint		= m_bNoPrint;
	rec.fLock			= m_bLock;
	rec.shdStyle		= m_shadowStyle;
	rec.shd.shadowColor = m_shadowColor;
	rec.shd.shadowPntX	= m_shadowPnt.x;
	rec.shd.shadowPntY	= m_shadowPnt.y;
	rec.brc.LPenColor	= m_LPenColor;
	rec.brc.LPenSize	= m_uLPenSize;
	rec.brc.LPenStyle	= m_uLPenStyle;
	rec.dwObjID			= m_dwObjID;
	
	TRACE1("\n>>OBJID:%d\n", m_dwObjID);

	rec.ObjConnPnt		= m_ObjConnPnt;
	rec.nCntSlvObj		= nCntSlvObj;
	
	wr.BeginWriteRec(TAG_WPSFPBaseData, sizeof(rec) + sizeof(DWORD)*nCntSlvObj);
		wr.Write(&rec, sizeof(rec));
		if (m_SlvObjIDArray.GetSize())	//	�ر�Ϊ���ܱ�������е�ƴ�ӹ�ϵ����
		{
			wr.Write(m_SlvObjIDArray.GetData(), sizeof(DWORD)*nCntSlvObj);
		}
		else
		{
			CFPBase* pObj;
			POSITION pos = m_SlvObjList.GetHeadPosition();
			for (UINT i = 0; i < nCntSlvObj; ++i)
			{
				pObj = (CFPBase*)m_SlvObjList.GetNext(pos);
				ASSERT(pObj->m_dwObjID != m_dwObjID);
				wr.Write(&pObj->m_dwObjID, sizeof(DWORD));
			}
		}
	wr.EndWriteRec();
	
	return S_OK;
}

STDMETHODIMP CFPBase::Serialize_Read_02(KSArchive& ar)
{
	HRESULT hr;
	_KWPSRecordHeader hdr;
	WPSFPBaseData rec;
	KWPSMainReader wr;
	wr.Attach(&ar);
	
	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSFPBaseData, hr = E_UNEXPECTED);
	
	ZeroMemory(&rec, sizeof(rec));
	wr.Read(&rec, sizeof(rec));

	m_nCompLoca		= rec.nCompLoca;
	m_nDispStyle	= rec.nDispStyle;
	m_bNoPrint		= rec.fNoPrint;
	m_bLock			= rec.fLock;
	m_shadowStyle	= rec.shdStyle;
	m_shadowColor	= rec.shd.shadowColor;
	m_shadowPnt.x	= rec.shd.shadowPntX;
	m_shadowPnt.y	= rec.shd.shadowPntY;
	m_LPenColor		= rec.brc.LPenColor;
	m_uLPenSize		= rec.brc.LPenSize;
	m_uLPenStyle	= rec.brc.LPenStyle;
	m_dwObjID		= rec.dwObjID;

	TRACE1("\n>>OBJID:%d\n", m_dwObjID);

	m_ObjConnPnt	= rec.ObjConnPnt;

	m_SlvObjIDArray.SetSize(rec.nCntSlvObj);
	wr.Read(m_SlvObjIDArray.GetData(), sizeof(DWORD)*rec.nCntSlvObj);

	m_pMstObj = NULL;		//	���䡰����Ϊ��
	m_pMstObj2 = NULL;
	
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());

	return S_OK;
	
KS_EXIT:
	return WPSIOThrowError(hr);
}

void CFPBase::Serialize_01(CArchive& ar)
{
	CTFPBase::Serialize_01(ar);
	if (g_fCompoundFile) // wps2002-io-fpbase, by tsingbo
	{
		if (ar.IsStoring())
			Serialize_Write_02(ar);
		else
			Serialize_Read_02(ar);
		return;
	}
	// wps2002-io-fpbase, old version serialize, by tsingbo
	if (ar.IsStoring())
	{
		ar << m_nCompLoca;
		ar << m_nDispStyle;
		ar << m_bNoPrint;
		ar.Write(&m_uLPenStyle, sizeof(UINT));
		ar.Write(&m_uLPenSize,  sizeof(UINT));
		ar.Write(&m_LPenColor, sizeof(COLORREF));
		ar << m_shadowPnt;
		ar << m_shadowColor;
		ar << m_shadowStyle;
		//	98����
		ar << m_bLock;
		ar << m_dwObjID;
		int nNum = m_SlvObjIDArray.GetSize();
		if (nNum != 0)	//	�ر�Ϊ���ܱ�������е�ƴ�ӹ�ϵ����
		{
			ar << nNum;
			DWORD dw;
			for (int i=0; i < nNum; i++)
			{	dw = m_SlvObjIDArray.GetAt(i);
				ar << dw;
			}
		}
		else
		{	ar << m_SlvObjList.GetCount();
			POSITION pos = m_SlvObjList.GetHeadPosition();
			CFPBase* pObj;
			while (pos)
			{	pObj = (CFPBase*)m_SlvObjList.GetNext(pos);	ASSERT_VALID(pObj);
				ASSERT(pObj->m_dwObjID != m_dwObjID);
				ar << pObj->m_dwObjID;
			}
		}
		ar << m_ObjConnPnt;
	}
	else
	{
		ar >> m_nCompLoca;
		ar >> m_nDispStyle;
		ar >> m_bNoPrint;
		ar.Read(&m_uLPenStyle, sizeof(UINT));
		ar.Read(&m_uLPenSize,  sizeof(UINT));
		ar.Read(&m_LPenColor, sizeof(COLORREF));
		ar >> m_shadowPnt;
		ar >> m_shadowColor;
		ar >> m_shadowStyle;
		//	98����
		ar >> m_bLock;
		ar >> m_dwObjID;
		int nNum = 0;
		ar >> nNum;
		//	����m_SlvObjList�����������ǰҳ�ļ��������ܽ���������m_SlvObjIDArray
		//	���桰��ӡ������ID�ţ��ڵ�::ResumeObjConnect()ʱ
		//	��m_SlvObjIDArrayȥ����m_SlvObjList��
		m_SlvObjIDArray.RemoveAll();
		DWORD dwTemp;
		for (int i=0; i < nNum; i++)
		{	ar >> dwTemp;
			m_SlvObjIDArray.Add(dwTemp);
		}
		m_pMstObj = NULL;		//	���䡰����Ϊ��
		m_pMstObj2 = NULL;
		ar >> m_ObjConnPnt;
	}
}

//void CTFPBase::RectangleDrawInside(CDC* pDC, IColorScheme* pICS, CRect& rct, int nType)
//{
//	if (GetBkMode() == GRADIENT && nType == CFPBase::IsRegular)
//	{
//		BOOL bOK = FALSE;
//		//if (pDC->IsPrinting() == FALSE)
//		{
//			COLORREF clrBk = KColorModel::IndexToRef(GetBkColor(), pICS);
//			//LLG_MODIFY_2002_5_25 ����ڶ���ɫ����(��ΪWPS�ĵڶ�����ɫ�����ɫ��ͬһ����!)
//			COLORREF clrFill = KColorModel::CalcSecondColorForOneShade(GetBkColor(),
//																GetFillColor(), pICS);
//			bOK = ::GradientDrawRect(pDC, rct, CPoint(0, 0), CRectObj::rectangle, clrBk, clrFill,
//									 GetColorDirection(), GetColorDistortion(), m_nTransparence);
//		}
//		if (!bOK)
//		{
//			ASSERT(GetBkMode() == GRADIENT);
//			SetBkMode(OPAQUE);
//			KCOLORINDEX indexOldColor = GetFillColor();
//			SetFillColor(GetBkColor());
//			CBrush* pOldB = SetBrushBkModeBkColor(pDC, pICS);
//		
//			CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
//			pDC->Rectangle(rct);
//			pDC->SelectObject(pOldPen);
//
//			pDC->SelectObject(pOldB);
//			SetFillColor(indexOldColor);
//			SetBkMode(GRADIENT);		
//		}
//	}
//	else	// wdb[bug id 2284]
//	{	
//		if (nType != CFPBase::IsRegular) // ����Ƥ����ʱ��û�����ɫ��
//		{
//			CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
//			pDC->Rectangle(rct);
//			pDC->SelectObject(pOldPen);
//			return;
//		}
//
//		if (m_nBkMode == TRANSPARENT)
//		{				
//			CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);			
//			CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
//			pDC->Rectangle(rct);
//			pDC->SelectObject(pOldBrush);
//			pDC->SelectObject(pOldPen);
//		}
//		else
//		{
//			if (::FillDrawRect(this, pDC, pICS, rct, CPoint(0, 0), CRectObj::rectangle))
//			{			
//			//	::FillDrawRect(this, pDC, pICS, rct, CPoint(0, 0), CRectObj::rectangle);
//				CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
//				CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
//				pDC->Rectangle(rct);	//device coordinate
//				pDC->SelectObject(pOldBrush);
//				pDC->SelectObject(pOldPen);
//			}
//			else
//			{
//				CBrush* pOldB = SetBrushBkModeBkColor(pDC, pICS);
//				CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
//				pDC->Rectangle(rct);
//				pDC->SelectObject(pOldB);
//				pDC->SelectObject(pOldPen);
//			}
//		}
//	}
//}
//
