/* -------------------------------------------------------------------------
//	�ļ���		��	export.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 21:01:16
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "export.h"
#include <media/lockstrm.h>
#include <draw/wpsimg.h>
#include <export/core/ex_wpsdoc.h>
#include <gdiplus.h>
#include <kgdip/linklib.h>
#include "../core/doswps.h"
#include <stl/vector.h>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace Gdiplus;

// -------------------------------------------------------------------------

STDMETHODIMP_(UINT) KWpsExport::AddFont(ks_string strFace)
{
	UINT& ftc = m_fontMap[strFace];
	if (ftc == 0)
	{
		USES_CONVERSION;

		KDWFontTable& fonts = GetFontTable();
		KDWFont font;
		ZeroMemory(&font, sizeof(font));

		font.name = A2W( strFace.c_str() );
		font.fTrueType = 1;
		fonts.Add(font, &ftc);
		++ftc;
	}
	return ftc - 1;
}

STDMETHODIMP_(BOOL) KWpsExport::IsLastSection() const
{
	return (m_iSection + 1) >= ((CWpsDoc*)m_pDoc)->NumOfSection();
}
//����ÿҳ�еķ����Ķ���ҳ�����
STDMETHODIMP_(void) KWpsExport::ExportPerPageObjs() 
{
	((CWpsDoc_Export*)m_pDoc)->ExportPerPageObjs(*this);
}
//��������ҳ/��żҳ�ķ����Ķ���ҳ�����
STDMETHODIMP_(void) KWpsExport::ExportAllPageObjs()
{
	((CWpsDoc_Export*)m_pDoc)->ExportAllPageObjs(*this);
}

//
STDMETHODIMP KWpsExport::CreateTocReferencedParagraphBookmark(CTextPool* pTextPool)
{
	//m_TocParaVec.clear();
	int nCount = pTextPool->NumOfParagraphs();
	for (int i = 0; i < nCount; ++i)
	{
		CParagraph* pPara = pTextPool->GetParagraph(i);
		ASSERT(pPara);
		if(pPara->m_lSerialID < 0)
		{
			KTocParagraph item;
			item.serialID = -pPara->m_lSerialID;
			swprintf(item.bookmarkName, __X("_Toc%d"), item.serialID);
			ASSERT(pPara->m_dwStyleID >= TSID_TOC_0 && pPara->m_dwStyleID <= TSID_TOC_9);
			item.POutLvl = pPara->m_dwStyleID - TSID_TOC_0;
			m_TocParaVec.push_back(item);
		}
	}
	return S_OK;
}
KTocParagraph* KWpsExport::GetTocParagraph(INT32 serialID)
{
	for(int i = 0; i < m_TocParaVec.size(); i++)
	{
		if(m_TocParaVec[i].serialID == serialID)
			return &m_TocParaVec[i];
	}
	return NULL;
}


// -------------------------------------------------------------------------
// GetEncoderClsid

STDMETHODIMP _XGetEncoderClsid(const WCHAR* format, CLSID* pCLSID) 
{ 
	UINT num = 0; // number of image encoders 
	UINT size = 0; // size of the image encoder array in bytes 
	
	ImageCodecInfo* pImageCodecInfo = NULL; 
	
	GetImageEncodersSize(&num, &size); 
	if(size == 0) 
		return E_FAIL; // Failure 
	
	pImageCodecInfo = (ImageCodecInfo*)(malloc(size)); 
	if(pImageCodecInfo == NULL) 
		return E_FAIL; // Failure 
	
	GetImageEncoders(num, size, pImageCodecInfo); 
	
	for(UINT j = 0; j < num; ++j) 
	{ 
		if( wcscmp(pImageCodecInfo[j].MimeType, format) == 0 ) 
		{ 
			*pCLSID = pImageCodecInfo[j].Clsid; 
			free(pImageCodecInfo); 
			return S_OK; // Success
		} 
	}
	
	free(pImageCodecInfo);
	return E_FAIL; // Failure
} 

// -------------------------------------------------------------------------

struct _WpsImageExport
{
	const GUID* format;
	MSOBLIPTYPE blipType;
};

const _WpsImageExport g_ImageExportTable[] =
{
	{ &ImageFormatJPEG, msoblipJPEG },
	{ &ImageFormatPNG,	msoblipPNG },
	{ &ImageFormatTIFF,	msoblipPNG },
	{ &ImageFormatGIF,	msoblipGIF },
	{ &ImageFormatBMP,	msoblipBMP },
	{ &ImageFormatWMF,	msoblipWMF },
	{ &ImageFormatEMF,	msoblipEMF },
//	{ &ImageFormatMemoryBMP, msoblipBMP }, // @@todo: ����ʲô��ʽ??
//	{ &ImageFormatEXIF, ? },
//	{ &ImageFormatIcon, ? },
};

WORD DIBNumColors(LPBITMAPINFOHEADER lpBMInfoHdr)
{
	WORD wBitCount;  // DIB bit count
	DWORD dwClrUsed;

	dwClrUsed = lpBMInfoHdr->biClrUsed;
	if (dwClrUsed != 0)
		return (WORD)dwClrUsed;

	wBitCount = lpBMInfoHdr->biBitCount;
	switch (wBitCount)
	{
		case 1:
			return 2;

		case 4:
			return 16;

		case 8:
			return 256;

		default:
			return 0;
	}
}

#define DIB_HEADER_MARKER	((WORD) ('M' << 8) | 'B')

STDMETHODIMP CreateDibPicStreamOnBuf(LPBITMAPINFOHEADER lpBmpInfoHdr, UINT dwBytes, IStream **ppStream) 
{
	BITMAPFILEHEADER	BmpFileHdr;
	DWORD dwBitmapInfoSize = 
		sizeof(BITMAPINFOHEADER) + DIBNumColors(lpBmpInfoHdr)*sizeof(RGBQUAD);
	
	BmpFileHdr.bfOffBits = dwBitmapInfoSize + sizeof(BITMAPFILEHEADER);
	BmpFileHdr.bfType = DIB_HEADER_MARKER;
	BmpFileHdr.bfSize = sizeof(BITMAPFILEHEADER) + dwBytes;
	BmpFileHdr.bfReserved1 = 0;
	BmpFileHdr.bfReserved2 = 0;
	
	//Allocate memory for DIB
	HGBL hGbl = XGlobalAlloc(GHND, BmpFileHdr.bfSize);
	INT m_dwLength = BmpFileHdr.bfSize;
	
	if (!hGbl)
		return E_FAIL;
	BYTE* m_lpBuf = NULL;
	m_lpBuf = (BYTE*)XGlobalLock(hGbl);

	if (!m_lpBuf)
	{
		XGlobalFree(hGbl);
		return E_FAIL;
	}

	CopyMemory(m_lpBuf, &BmpFileHdr, sizeof(BITMAPFILEHEADER));
	CopyMemory(m_lpBuf + sizeof(BITMAPFILEHEADER), lpBmpInfoHdr, dwBytes);
	
	LPBITMAPFILEHEADER m_lpBMFH = (LPBITMAPFILEHEADER)m_lpBuf;
	LPBITMAPINFOHEADER m_lpBMIH = (LPBITMAPINFOHEADER)(m_lpBuf + sizeof(BITMAPFILEHEADER));
	LPBITMAPINFO m_lpBMI  = (LPBITMAPINFO)m_lpBMIH;
	// �������
	if (m_lpBMIH->biSizeImage == 0)
		m_lpBMIH->biSizeImage = m_dwLength - m_lpBMFH->bfOffBits;

	XGlobalUnlock(hGbl);

	return XCreateStreamOnHGlobal(hGbl, TRUE, ppStream);
}

inline int GetStreamSize (IStream* pStream)
{
	STATSTG stg;
	pStream->Stat (&stg, STATFLAG_NONAME);
	return stg.cbSize.LowPart;
}

inline HRESULT 
SeekStream (IStream* pStream, DWORD dwOrign, int nOffset, ULONG* pNewPos/*NULL*/)
{ 
 	LARGE_INTEGER li;
	li.QuadPart = nOffset;

	if (pNewPos)
	{
		HRESULT hr = pStream->Seek ( li, dwOrign, (ULARGE_INTEGER*)&li );
		*pNewPos = li.LowPart;
		return hr;
	}

	return pStream->Seek ( li, dwOrign, NULL);
}

STDMETHODIMP CreateLockBufferOnStream(IStream* pStream, IKLockBuffer** ppBuf)
{
	ULONG uSize = GetStreamSize(pStream);
	BYTE* pBuf = new BYTE[uSize];
	SeekStream(pStream, STREAM_SEEK_SET, 0, NULL);
	
	ULONG uRead = 0;
	pStream->Read(pBuf, uSize, &uRead);

	SeekStream(pStream, STREAM_SEEK_SET, 0, NULL);
	ASSERT(uSize == uRead);

	_XCreateLBFromBuffer(ppBuf, pBuf, uRead);
	if (pBuf)
		delete [] pBuf;

	return S_OK;
}

INT GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
{
   UINT  num = 0;          // number of image encoders
   UINT  size = 0;         // size of the image encoder array in bytes

   ImageCodecInfo* pImageCodecInfo = NULL;

   GetImageEncodersSize(&num, &size);
   if(size == 0)
      return -1;  // Failure

   pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
   if(pImageCodecInfo == NULL)
      return -1;  // Failure

   GetImageEncoders(num, size, pImageCodecInfo);

   for(UINT j = 0; j < num; ++j)
   {
      if( wcscmp(pImageCodecInfo[j].MimeType, format) == 0 )
      {
         *pClsid = pImageCodecInfo[j].Clsid;
         free(pImageCodecInfo);
         return j;  // Success
      }    
   }

   free(pImageCodecInfo);
   return -1;  // Failure
}

STDMETHODIMP_(MsoBlip) gAddWpsAnimImage2BlipStore(
		IN MsoBlipStore& blipStore, IN const CWpsImage* pImg, OUT SIZE* pImgSizeInPixel)
{
	int i = 0;
	LPVOID lpBuffer = NULL;
	UINT dwDataLen = 0;
	pImg->m_pSource->Lock(&lpBuffer, &dwDataLen);
	if (!lpBuffer || (dwDataLen == 0))
	{
		static KDWBlip blipNil;
		return blipNil;
	}
	
	DWORD dwOffset, dwOffsetNext;
	WPSDibAnimationHeader* wdaHeader = (WPSDibAnimationHeader*)lpBuffer;
	WPSDibAnimationFrame*  wdaFrames = (WPSDibAnimationFrame*)(wdaHeader + 1);
	
	if (wdaHeader->dwTag != TAG_WPSDibAnimation)
	{
		static KDWBlip blipNil;
		return blipNil;
	}
	
	BOOL m_bHasAnimate = TRUE;
	INT m_nTotalDIBNum = wdaHeader->nTotalDIBNum;
	INT m_nDibNumber = wdaHeader->iCurrDibNumber;
	if (m_nDibNumber >= m_nTotalDIBNum)
	{
		REPORT("CreateWpsDibAnimation����: ��ǰ֡ > ��֡��");
		static KDWBlip blipNil;
		return blipNil;
	}
	
	dwOffset = sizeof(WPSDibAnimationHeader) + m_nTotalDIBNum*sizeof(WPSDibAnimationFrame);

	EncoderParameters encoderParameters;
	ULONG             parameterValue;

	// An EncoderParameters object has an array of
	// EncoderParameter objects. In this case, there is only
	// one EncoderParameter object in the array.
	encoderParameters.Count = 1;

	// Initialize the one EncoderParameter object.
	encoderParameters.Parameter[0].Guid = EncoderSaveFlag;
	encoderParameters.Parameter[0].Type = EncoderParameterValueTypeLong;
	encoderParameters.Parameter[0].NumberOfValues = 1;
	encoderParameters.Parameter[0].Value = &parameterValue;
	Status            stat;

	CLSID encoderClsid;
	GetEncoderClsid(__X("image/tiff"), &encoderClsid);

	HRESULT hr;
	IStream* pTotalStream = NULL;
	XCreateStreamOnHGlobal(NULL, TRUE, &pTotalStream);
	ASSERT(pTotalStream);
	
	vector<IStream*> vecPicStreams;
	Image * pImage = NULL;
	for (UINT i = 0; i < m_nTotalDIBNum; i++)
	{
		dwOffsetNext = wdaFrames[i].bmOffsetNext;
		if (dwOffsetNext <= dwOffset + sizeof(BITMAPFILEHEADER))
		{
			REPORT("CreateWpsDibAnimation����֡����ƫ�ƷǷ�");
			static KDWBlip blipNil;
			return blipNil;
		}
		
		IStream *pStreamPic = NULL;

		hr = CreateDibPicStreamOnBuf(
			(BITMAPINFOHEADER*)((BYTE*)wdaHeader + dwOffset + sizeof(BITMAPFILEHEADER)),
			dwOffsetNext - dwOffset - sizeof(BITMAPFILEHEADER),
			&pStreamPic
			);
		if (SUCCEEDED(hr))
		{
			if (!pImage)
			{
#ifdef new
#undef new
#endif
				pImage = new Image(pStreamPic);
#ifdef _DEBUG
#define new DEBUG_NEW
#endif
				if ((pImage->GetLastStatus() == Ok))
				{
					parameterValue = EncoderValueMultiFrame;
					stat = pImage->Save(pTotalStream, &encoderClsid, &encoderParameters);
					ASSERT(stat == Ok);
				}
			}
			else
			{
				Image img(pStreamPic);
				if ((img.GetLastStatus() == Ok))
				{
					parameterValue = EncoderValueFrameDimensionPage;
					stat = pImage->SaveAdd(&img, &encoderParameters);
					ASSERT(stat == Ok);
				}
			}
		}
		if (pStreamPic)
			vecPicStreams.push_back(pStreamPic);

		dwOffset = dwOffsetNext;
	}
	if (pImage)
	{
		parameterValue  = EncoderValueFlush;
		pImage->SaveAdd(&encoderParameters);
		delete pImage;
	}
	
	if (vecPicStreams.size() > 0)
	{
		for (int i = 0; i < vecPicStreams.size();i++)
		{
			vecPicStreams[i]->Release();
		}
	}

	pImg->m_pSource->Unlock();
	
	ks_stdptr<IKLockBuffer> spSource;
	CreateLockBufferOnStream(pTotalStream, &spSource);

	if (pTotalStream)
		pTotalStream->Release();

	return blipStore.NewBlip(msoblipPNG, spSource);
}

STDMETHODIMP_(MsoBlip) gAddWpsImage2BlipStore(
		IN MsoBlipStore& blipStore, IN const CWpsImage* pImg, OUT SIZE* pImgSizeInPixel)
{
	if (pImg->m_srcCategory == FILE_DIBANIMATION)
	{
		return gAddWpsAnimImage2BlipStore(blipStore, pImg, pImgSizeInPixel);
	}

	ks_stdptr<IKLockBuffer> pNewSource;
	IKLockBuffer* pSource = pImg->m_pSource;
	ASSERT(pSource);
RETRY:
	if (pImgSizeInPixel)
	{
		pImgSizeInPixel->cx = pImg->m_nDrawWidth;
		pImgSizeInPixel->cy = pImg->m_nDrawHeight;
	}
	if (pSource == NULL)
	{
		static KDWBlip blipNil;
		return blipNil;
	}

	KSLockStream strm(pSource);
	Image image(&strm);
	if (image.GetLastStatus() != Ok)
	{
		//REPORT_ONCE("��֧�ֵ�ͼƬ��ʽ?");
		if(pImg->m_srcCategory == FILE_DIB)//�Ӹ�ͷ
		{
			BYTE* pBuf = NULL;
			UINT nSize = 0;
			pSource->Lock((void**)&pBuf, &nSize);
			// �ٸ�һ�λ��ῴ��
			BITMAPINFOHEADER* pbi = &((LPBITMAPINFO)pBuf)->bmiHeader;
			{
				ks_stdptr<IStream> spStream;
				CreateDibPicStreamOnBuf(pbi, nSize, &spStream);
				if (spStream)
				{
					Image img (spStream);
					if (img.GetLastStatus() == Ok)
					{
						ks_stdptr<IStream> spStrm;
						XCreateStreamOnHGlobal(NULL, FALSE, &spStrm);
					
						// Get the class identifier for the PNG encoder.
						CLSID pngClsid;
						_XGetEncoderClsid(__X("image/png"), &pngClsid);
						Status status = img.Save(spStrm, &pngClsid);
						if (status == Ok)
						{
							HGBL hGbl = NULL;
							XGetHGlobalFromStream(spStrm, &hGbl);
							ks_stdptr<IKLockBuffer> spLB;
							_XCreateLBAttachHGbl(&spLB, hGbl);
							
							pSource->Unlock();
							return blipStore.NewBlip(msoblipPNG, spLB);
						}
						else
						{
							HGBL hGbl = NULL;
							XGetHGlobalFromStream(spStrm, &hGbl);
							XGlobalFree(hGbl);
						}
					}
				}
			}
			
			//
			UINT nNewSize = nSize + sizeof(BITMAPFILEHEADER);
			BYTE* pNewBuf = new BYTE[nNewSize];
			BITMAPFILEHEADER* pfh = (BITMAPFILEHEADER*)pNewBuf;
			pfh->bfType = MAKEWORD('B', 'M');
			pfh->bfSize = nNewSize;
			pfh->bfOffBits = pfh->bfSize - pbi->biSizeImage;
			pfh->bfReserved1 = pfh->bfReserved2 = 0;
			memcpy(pNewBuf + sizeof(BITMAPFILEHEADER), pBuf, nSize);
			_XCreateLBFromBuffer(&pNewSource, pNewBuf, nNewSize);
			delete []pNewBuf;
			pSource->Unlock();
			pSource = pNewSource;
			goto RETRY;
		}
		goto lzUnknownFormat;
	}
	else if (pImgSizeInPixel)
	{
		pImgSizeInPixel->cx = image.GetWidth();
		pImgSizeInPixel->cy = image.GetHeight();
	}
	
	// �ж�ͼ���ʽ��������ʣ����뵽BlipStore�У�
	GUID guidFormat;
	image.GetRawFormat(&guidFormat);
	for (int i = 0; i < countof(g_ImageExportTable); ++i)
	{
		if (*g_ImageExportTable[i].format == guidFormat)
		{
			if (guidFormat == ImageFormatBMP)
			{
				ks_stdptr<IStream> spStrm;
				XCreateStreamOnHGlobal(NULL, FALSE, &spStrm);
			
				// Get the class identifier for the PNG encoder.
				CLSID pngClsid;
				_XGetEncoderClsid(__X("image/png"), &pngClsid);
				Status status = image.Save(spStrm, &pngClsid);
				if (status == Ok)
				{
					HGBL hGbl = NULL;
					XGetHGlobalFromStream(spStrm, &hGbl);
					ks_stdptr<IKLockBuffer> spLB;
					_XCreateLBAttachHGbl(&spLB, hGbl);
					return blipStore.NewBlip(msoblipPNG, spLB);
				}
				else
				{
					HGBL hGbl = NULL;
					XGetHGlobalFromStream(spStrm, &hGbl);
					XGlobalFree(hGbl);
				}
			}
			
			return blipStore.NewBlip(g_ImageExportTable[i].blipType, pSource);
		}
	}

	// ͼ���ʽ����֧�֣���Ҫ����ת��(����ת��Ϊpng)��
	{
		ks_stdptr<IStream> spStrm;
		XCreateStreamOnHGlobal(NULL, FALSE, &spStrm);
	
		// Get the class identifier for the PNG encoder.
		CLSID pngClsid;
		_XGetEncoderClsid(__X("image/png"), &pngClsid);
		Status status = image.Save(spStrm, &pngClsid);
		if (status == Ok)
		{
			HGBL hGbl = NULL;
			XGetHGlobalFromStream(spStrm, &hGbl);
			ks_stdptr<IKLockBuffer> spLB;
			_XCreateLBAttachHGbl(&spLB, hGbl);
			return blipStore.NewBlip(msoblipPNG, spLB);
		}
		REPORT("ת��ͼ���ʽʧ�ܣ�");
	}

lzUnknownFormat:
	return blipStore.NewBlip(msoblipFirstClient, pSource);
}
/*
//////////////////////////////////////////////////////////////////
Function Name :HANDLE DDBToDIB(CBitmap &bitmap,
                               DWORD dwCompression,
                               CPalette *pPal)
Parameters:
  CBitmap &bitmap : Compatible Device Dependent Bitmap
  DWORD dwCompression : Compression format for Bitmap must not be
  BI_BITFIELDS in this case.
  CPalette *pPal : Pointer to Palette. If this is NULL, the
  default system palette will be used.

//////////////////////////////////////////////////////////////////
*/
HGBL DDBToDIB(CBitmap &bitmap, DWORD dwCompression,
			  CPalette *pPal)
{
	
	BITMAP              bm;
	BITMAPINFOHEADER    bi;
	LPBITMAPINFOHEADER  lpbi;
	DWORD               dwLen;
	HGBL                hDIB;
	BYTE*               pDIB;
	HDC                 hDC;
	HPALETTE            hPal;
	
	
	ASSERT( bitmap.GetSafeHandle() );
	
	// The function has no arg for bitfields
	if( dwCompression == BI_BITFIELDS )
		return NULL;
	
	// If a palette has not been supplied, use default palette
	hPal = (HPALETTE) pPal->GetSafeHandle();
	if (hPal==NULL)
		hPal = (HPALETTE) GetStockObject(DEFAULT_PALETTE);
	
	// Get bitmap information
	bitmap.GetObject(sizeof(bm),(LPSTR)&bm);
	
	// Initialize the bitmap infoheader
	bi.biSize          = sizeof(BITMAPINFOHEADER);
	bi.biWidth         = bm.bmWidth;
	bi.biHeight        = bm.bmHeight;
	bi.biPlanes        = 1;
	bi.biBitCount      = bm.bmPlanes * bm.bmBitsPixel;
    //bm.bmPlanes    * bm.bmBitsPixel;
	bi.biCompression   = dwCompression;
	bi.biSizeImage     = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed       = 0;
	bi.biClrImportant  = 0;
	
	// Compute the size of the infoheader and the color table
	int nColors = (1 << bi.biBitCount);
	if( nColors > 256 )
		nColors = 0;
	dwLen  = bi.biSize + nColors * sizeof(RGBQUAD) + sizeof(BITMAPFILEHEADER);
	
	// We need a device context to get the DIB from
	hDC = ::GetDC(NULL);
	hPal = SelectPalette(hDC,hPal,FALSE);
	RealizePalette(hDC);
	
	// Allocate enough memory to hold bitmap infoheader and
	// color table
	hDIB = XGlobalAlloc(GHND, dwLen);
	pDIB = (BYTE*)XGlobalLock(hDIB);
	pDIB += sizeof(BITMAPFILEHEADER);
	lpbi = (LPBITMAPINFOHEADER)pDIB;
	*lpbi = bi;
	
	// Call GetDIBits with a NULL lpBits param, so the device
	// driver will calculate the biSizeImage field
	GetDIBits(hDC, (HBITMAP)bitmap.GetSafeHandle(), 0L,
		(DWORD)bi.biHeight,
		(LPBYTE)NULL, (LPBITMAPINFO)lpbi,
		(DWORD)DIB_RGB_COLORS);
	
	bi = *lpbi;
	
	// If the driver did not fill in the biSizeImage field, then
	// compute it
	// Each scan line of the image is aligned on a DWORD (32bit)
	// boundary
	if (bi.biSizeImage == 0){
		bi.biSizeImage = ((((bi.biWidth * bi.biBitCount) + 31)
			& ~31) / 8) * bi.biHeight;
		
		// If a compression scheme is used, the result may in fact
		// be larger
		// Increase the size to account for this.
		if (dwCompression != BI_RGB)
			bi.biSizeImage = (bi.biSizeImage * 3) / 2;
	}
	
	XGlobalUnlock(hDIB);
	
	// Realloc the buffer so that it can hold all the bits
	dwLen += bi.biSizeImage;
	hDIB = XGlobalReAlloc(hDIB, dwLen, GHND);
	
	pDIB = (BYTE*)XGlobalLock(hDIB);
	BYTE* pAll = pDIB;
	pDIB += sizeof(BITMAPFILEHEADER);
	// Get the bitmap bits
	lpbi = (LPBITMAPINFOHEADER)pDIB;
	
	// FINALLY get the DIB
	BOOL bGotBits = GetDIBits( hDC, (HBITMAP)bitmap.GetSafeHandle(),
        0L,                        // Start scan line
        (DWORD)bi.biHeight,        // # of scan lines
        (LPBYTE)lpbi               // address for bitmap bits
        + (bi.biSize + nColors * sizeof(RGBQUAD)),
        (LPBITMAPINFO)lpbi,        // address of bitmapinfo
        (DWORD)DIB_RGB_COLORS);    // Use RGB for color table
	if(bGotBits)
	{
		BITMAPFILEHEADER* pfh = (BITMAPFILEHEADER*)pAll;
		pfh->bfType = MAKEWORD('B', 'M');
		pfh->bfSize = dwLen;
		pfh->bfOffBits = sizeof(BITMAPFILEHEADER) + bi.biSize + nColors * sizeof(RGBQUAD);
//		{	
//		CFile file;
//		static int i = 0;
//		CString strFile;
//		strFile.Format("c:/%d.bmp", i);
//		file.Open(strFile, CFile::modeCreate | CFile::modeWrite);
//		file.Write(pAll, dwLen);
//		file.Close();
//		i++;
//		}
	}
	XGlobalUnlock(hDIB);
	
	if( !bGotBits )
	{
		XGlobalFree(hDIB);
		
		SelectPalette(hDC,hPal,FALSE);
		::ReleaseDC(NULL,hDC);
		return NULL;
	}
	
	SelectPalette(hDC,hPal,FALSE);
	::ReleaseDC(NULL,hDC);
	
	return hDIB;
	
	//End of the function
}
STDMETHODIMP gDIBFromDDB(HBITMAP hbm, OUT IKsoLockBuffer** ppv)
{
	HRESULT hr = E_FAIL;
	CBitmap bm;
	bm.Attach((HBITMAP)hbm);
	HGBL hGbl = DDBToDIB(bm, BI_RGB, NULL);
	if(hGbl)
	{
		hr = CreateLBAttachHGbl(ppv, hGbl);
	}
	bm.Detach();
	return hr;
}

STDMETHODIMP_(KDWBlip) KWpsExport::AddImage(
											IN const CWpsImage* pImg,
											OUT SIZE* pImgSizeInPixel)
{
	return gAddWpsImage2BlipStore(GetBlipStore(), pImg, pImgSizeInPixel);
}

// -------------------------------------------------------------------------

// ����ָ���Ľ�עβע����
// nFNID: ��עβע��ID
// ˵��: ��WPS��, ��עβע��ͬһtextpool��, ��ͬһ��ID����ռ�
STDMETHODIMP KWpsExport::Export_FootnoteText(const int nFNID)
{
	CTextPool* pFNPool = m_pDoc->GetAccessToFootnoteTextPool();
	return ((CTextPool_Export*)pFNPool)->Export_FN(*this, nFNID);
}

// -------------------------------------------------------------------------

STDMETHODIMP KWpsExport::BookmarkProcessor(int nBMID, CP cpBegin, CP cpEnd)
{
	return m_BookmarkExport.Convert(*this, nBMID, cpBegin, cpEnd);
}

STDMETHODIMP KWpsExport::HyperlinkProcessor(CCtrlCode_HotRef* pHotRef)
{
	return m_HyperLinkExport.Convert(*this, pHotRef);
}

STDMETHODIMP_(UINT) KWpsExport::AddStyle_DefaultTable()
{
	if (m_lWpsDefaultTableStyle == 0)
		m_lWpsDefaultTableStyle = m_StyleExport.ConvertDefaultTable(*this);
	return m_lWpsDefaultTableStyle;
}

STDMETHODIMP_(UINT) KWpsExport::AddStyle_Text(DWORD dwID, ks_string strStyleName)
{
	return m_StyleExport.Convert(*this, dwID, strStyleName);
}

STDMETHODIMP_(UINT) KWpsExport::AddAutonumGroup(KAutoNumGroupPtr* pGroupPtr)
{
	return m_AutonumExport.Convert(*this, pGroupPtr);
}

// -------------------------------------------------------------------------

STDMETHODIMP WpsExportDoc(IN const CWpsDoc* pDoc, IN IStorage* pWordRootStg)
{
	KWpsExport export(pDoc);
	HRESULT hr = export.NewDocument(pWordRootStg);
	KS_CHECK(hr);
	KS_TRY
	{
		hr = E_FAIL;
		CWpsDoc_Export* pDocEx = (CWpsDoc_Export*)pDoc;
		hr = pDocEx->Export(export);

		if (pDoc->m_pVBAStg)
		{
			ks_stdptr<IStorage> pWordVBA;
			ks_stdptr<IStorage> pTemp;
			pDoc->m_pVBAStg->OpenStorage(L"The VBA Project", NULL, STGM_READ | STGM_SHARE_EXCLUSIVE, 0, 0, &pTemp);
			ASSERT(pTemp);
			pTemp->OpenStorage(L"_VBA_Project", NULL, STGM_READ | STGM_SHARE_EXCLUSIVE, 0, 0, &pWordVBA);
			ASSERT(pWordVBA);
			IStorage* pNoMacroStg = NULL;
			pWordRootStg->CreateStorage(L"Macros",
										STGM_SHARE_EXCLUSIVE|STGM_CREATE|STGM_READWRITE,
										0, 0,
										&pNoMacroStg);
			if (pNoMacroStg)
			{
				pWordVBA->CopyTo(0, 0, NULL, pNoMacroStg);
				pNoMacroStg->Release();
			}
		}
	}
	KS_CATCH(...)
	{
		REPORT("WpsExportDoc Failed - Unknown Exception");
	}
	// WPS�ǲ�ϣ��DocWriter�Զ��������һ���س��������������������
	// һ�����䲻��0x0d��������񣩣���һ����
	{
		KDWTextPool& MainPool = export.GetMainSubdoc()->TextPool();
		if (MainPool.back() != 0x0d)
		{
			export.SwitchToMainSubdoc();
			export.NewNullPapxParagraph();
			export.AddContent(0x0d);
		}
	}
	export.Close(FAILED(hr));

KS_EXIT:
	return hr;
}

STDMETHODIMP WpsExportDoc(IN LPSTORAGE pstg, IN IKFilterEventNotify* pNotify, IN IStorage* pWordRootStg)
{
	USES_CONVERSION;
	HRESULT hr;
	CWpsDoc doc;
	doc.m_pNotify = pNotify;
	hr = doc.OnWPSFileLoad(pstg);
	if (SUCCEEDED(hr))
		hr = WpsExportDoc(&doc, pWordRootStg);
	//lijun ���¾Ͳ�����dos�汾��wps��
//	else
//	{
//		KDosWpsFileExport doswps;
//		if (SUCCEEDED(doswps.Load(W2A(szWpsFile), pNotify)))
//		{
//			hr = doswps.Export(pWordRootStg);
//		}
//	}
	return hr;
}

STDMETHODIMP WpsExportDoc(IN LPCWSTR szWpsFile, IN IKFilterEventNotify* pNotify, IN IStorage* pWordRootStg)
{
	USES_CONVERSION;
	HRESULT hr;
	CWpsDoc doc;
	doc.m_pNotify = pNotify;
	hr = doc.OnWPSFileLoad(W2A(szWpsFile));

	if (SUCCEEDED(hr))
		hr = WpsExportDoc(&doc, pWordRootStg);
	else
	{
		KDosWpsFileExport doswps;
		if (SUCCEEDED(doswps.Load(W2A(szWpsFile), pNotify)))
		{
			hr = doswps.Export(pWordRootStg);
		}
	}

	return hr;
}

STDMETHODIMP WpsExportDoc(IN LPCWSTR szWpsFile, IN IKFilterEventNotify* pNotify, IN LPCWSTR szDocFile)
{
	USES_CONVERSION;
	HRESULT hr;
	CWpsDoc doc;
	doc.m_pNotify = pNotify;
	hr = doc.OnWPSFileLoad(W2A(szWpsFile));

	if (FAILED(hr))
	{
		KDosWpsFileExport doswps;
		if (SUCCEEDED(doswps.Load(W2A(szWpsFile), pNotify)))
		{
			hr = doswps.Export(szDocFile);
		}
		return hr;
	}

	ks_stdptr<IStorage> spWordRootStg;
	hr = StgCreateDocfile(szDocFile, STGM_G_CREATE, 0, &spWordRootStg);
	ASSERT_OK(hr);
	if (FAILED(hr))
		return hr;
	
	return WpsExportDoc(&doc, spWordRootStg);
}


int SkipEscape(LPCTEXTWORD pCurChar)
{
	ASSERT(*pCurChar == VK_ESCAPE);
	
	switch (pCurChar[1])
	{
	case INS_ANC_TEXT_OBJECT:	return 3;
	case INS_ANC_PARA_OBJECT:	return 3;
	case INS_PAGENUM:			return 3;
	case INS_TOTALPAGE:			return 3;
	case INS_SYSTIME:			return 3;
	case INS_SYSDATE:			return 3;
	case INS_SYSDAY:			return 3;
	case INS_PAGEREF:			return 6;
	case INS_FOOTNOTE:			return 16;
	case INS_BOOKMARK:			return 3;
	case INS_COMMENT:			return 3;
	case INS_DEFTEXT:			return 21;
	default:	ASSERT(0);		return 1;
	}
}

void GetTextPoolContent(CTextPool& textPool, OUT ks_wstring& szContent)
{
	WCHAR wsz[2] = {0};
	for(int iPara = 0; iPara < textPool.NumOfParagraphs(); iPara++)
	{
		CParagraph* pPara = textPool.GetParagraph(iPara);
		ASSERT_VALID(pPara);
		for(int iSen = 0; iSen < pPara->NumOfSentences(); iSen++)
		{
			CSentence* pSen = pPara->GetSentence(iSen);
			ASSERT_VALID(pSen);
			int cbSenChar = pSen->GetTextSize();
			LPCTEXTWORD pszChar = pSen->GetDataPtr();
			for(int iChar = 0; iChar < cbSenChar; iChar++)
			{
				if(pszChar[iChar] == VK_ESCAPE)
				{
					iChar = SkipEscape(&pszChar[iChar]);
				}
				else
				{
					wsz[0] = pszChar[iChar];
					szContent += wsz;
				}
			}
		}
	}
}
STDMETHODIMP WpsGetContent(CWpsDoc& doc, OUT BSTR& bstrContent)
{
	ks_wstring szContent;
	//����
	GetTextPoolContent(*doc.c_pTextPool, szContent);
	bstrContent = szContent.AllocBSTR();
	return S_OK;
}
// -------------------------------------------------------------------------

HRESULT OnExportWpsData()
{
	extern void FillCharLangTbl();
	FillCharLangTbl();
	return S_OK;
}

EXPORTAPI WpsExport(IN LPCWSTR szWpsFile, IN IStorage* pWordRootStg)
{
	OnExportWpsData();
	return WpsExportDoc(szWpsFile, NULL, pWordRootStg);
}

// -------------------------------------------------------------------------

EXPORTAPI WpsConvert(IN LPCWSTR szWpsFile, IN LPCWSTR szDocFile)
{
	OnExportWpsData();
	return WpsExportDoc(szWpsFile, NULL, szDocFile);
}

EXPORTAPI WpsConvertEx(IN LPCWSTR szWpsFile, 
					   IN LPCWSTR szDocFile, 
					   IN IKFilterEventNotify* pNotify)
{
	OnExportWpsData();
	return WpsExportDoc(szWpsFile, pNotify, szDocFile);
}

//Tank 5/20/2005:Ϊgoogle�������������WpsIndexer���������ĺ���
//����һ���ļ������õ��ļ��еĴ�����
//��ǰֻ�ܶ�ȡwps2003�����ݣ�Ҳ���Ժ������v6��ʽ��֧��
#ifndef WPSRW_NO_GETCONTENT
#define WPSRWAPI EXTERN_C __declspec(dllexport) HRESULT STDAPICALLTYPE 

WPSRWAPI WpsGetContent(IN LPCWSTR szWpsFile, OUT BSTR* pbstrContent)
{
	ASSERT(szWpsFile && pbstrContent);
	OnExportWpsData();
	USES_CONVERSION;
	HRESULT hr;
	CWpsDoc doc;
	doc.m_pNotify = NULL;
	hr = doc.OnWPSFileLoad(W2A(szWpsFile));
	if(SUCCEEDED(hr))
	{
		hr = WpsGetContent(doc, *pbstrContent);
	}
	return hr;
}
#endif//WPSRW_NO_GETCONTENT
// -------------------------------------------------------------------------
