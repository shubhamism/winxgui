/* -------------------------------------------------------------------------
//	�ļ���		��	stylebase.cpp
//	������		��	����
//	����ʱ��	��	2004-10-22 11:40:40 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "wpsdoc.h"
#include "stylebase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL (CStyleBase, CObject, VERSIONABLE_SCHEMA | 98)

/********************************************************************
	���ܣ�	Serialize()��Ҫ���������Ĺ��캯��
********************************************************************/
CStyleBase::CStyleBase()
{

}

CStyleBase::~CStyleBase()
{

}

void CStyleBase::Serialize (CArchive& ar)
{
//	Serialize_98 (ar);
	CWpsDoc* pDoc = (CWpsDoc*)ar.m_pDocument;
	if (!pDoc)												// ����ʽģ���ļ� Normal.stl ʱ
	{
		Serialize_01(ar);
		return;
	}

	ASSERT_VALID (pDoc);
	WORD wVer = pDoc->GetWPSFileVersion();					// ��ͨ�ĵ�ʱ
//	UINT uSchema = ar.GetObjectSchema();
	switch (wVer)
	{
	case VER_WINWPS98: Serialize_98(ar); break;
	case VER_WINWPS01: Serialize_01(ar); break;
	default: ASSERT(FALSE); break;
	}
}

#ifndef _GWSREADER
typedef BYTE (WINAPI* CONVPROC)(LPTSTR, DWORD);
extern CONVPROC g_lpConvProc;		// ��������ʱ�Ƿ���Ҫת������
#endif	// #ifndef _GWSREADER

void CStyleBase::Serialize_98 (CArchive& ar)
{
	CObject::Serialize(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
		ar << m_strName;
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_strName;
#ifndef _GWSREADER
		if (g_lpConvProc && !m_strName.IsEmpty())
		{
			// ��Ҫʱת����������
			CString* pStr = &m_strName;
			int nLen = pStr->GetLength();
			LPTSTR lpsz = pStr->GetBuffer(nLen);
			g_lpConvProc(lpsz, nLen);
			pStr->ReleaseBuffer(nLen);
		}
#endif	// #ifndef _GWSREADER
	}
}

void CStyleBase::Serialize_01(CArchive& ar)
{
	Serialize_98(ar);
}


// -------------------------------------------------------------------------
