/* -------------------------------------------------------------------------
//	�ļ���		��	wpsimg.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 18:50:20
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <wpsrw/io/zip.h>
#include "wpsimg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CWpsImage, CWPSObj, 0xA0|VERSIONABLE_SCHEMA) // for WPS01

// -------------------------------------------------------------------------

struct WPSMediaDataParam : public WPSMediaDataHeader
{
	KMediaDataSource* pSource;
	ULONG mediaOffset;
};

inline STDMETHODIMP WriteMediaData(IStream* pPicStream,  WPSMediaDataParam& media)
{
/**@@todo
	HRESULT	hr = E_MD_NOSOURCE;
	MDSSIZE	dwBytes	= 0;
	LPVOID	pData	= NULL;

	KS_CHECK_BOOL(pPicStream);
	KS_CHECK_BOOL(media.pSource);

	dwBytes = _ioGetOffset(pPicStream);
	if (dwBytes & 3)	// ֻ��Ϊ�� 4bytes ����
	{
		DWORD dwAdjust = 0;
		pPicStream->Write(&dwAdjust, ~dwBytes & 3, NULL);
	}

	hr = media.pSource->Lock(&pData, &dwBytes);
	KS_CHECK(hr);

	switch (media.Compression)
	{
	case FILE_COMPRESSION_WINLZA:	{
		HGBL hGbl = NULL;
		try
		{
			hr = E_UNEXPECTED;
			hr = zlibCompress(pData, dwBytes, &hGbl);
			//ASSERT(hr == S_OK);
		}
		catch(...)
		{
			REPORT("ѹ��ͼ������ʧ��!");
		}
		if (hGbl != NULL)
		{
			ASSERT(hr == S_OK);
			media.mediaOffset = _ioGetOffset(pPicStream);
			media.mediaSize   = GlobalSize(hGbl);
			pPicStream->Write(&media, sizeof(WPSMediaDataHeader), NULL);
			pPicStream->Write(&dwBytes, sizeof(ULONG), NULL);	
			pData = GlobalLock(hGbl);
			pPicStream->Write(pData, media.mediaSize, NULL);
			GlobalUnlock(hGbl);
			GlobalFree(hGbl);
			break;					}
		}
		// ѹ��ʧ�ܣ��Ͳ�����ѹ����, ��������ͬ��...
		media.Compression = FILE_COMPRESSION_NONE;

	case FILE_COMPRESSION_NONE:
		media.mediaOffset = _ioGetOffset(pPicStream);
		media.mediaSize   = dwBytes;
		pPicStream->Write(&media, sizeof(WPSMediaDataHeader), NULL);
		pPicStream->Write(pData, dwBytes, NULL);
		break;
	}
	
KS_EXIT:
	if (pData)
		media.pSource->Unlock();
	return hr;*/
	ASSERT(0);
	return S_OK;
}

inline STDMETHODIMP ReadMediaData(IStream* pPicStream, WPSMediaDataParam& media)
{
	HGBL hGbl  = NULL;
	HRESULT	hr	  = E_MD_NOSOURCE;
	BYTE* pData	  = NULL;
	
	media.pSource = NULL;
	
	KS_CHECK_BOOL(pPicStream);

	hr = _ioSeekFile(pPicStream, media.mediaOffset, SEEK_SET);
	KS_CHECK(hr);

	hr = pPicStream->Read(&media, sizeof(WPSMediaDataHeader), NULL);
	KS_CHECK(hr);
	
	switch (media.Compression)
	{
	case FILE_COMPRESSION_NONE:
		hGbl = XGlobalAlloc(GHND, media.mediaSize);
		KS_CHECK_BOOLEX(hGbl != NULL, hr = E_OUTOFMEMORY);
		
		LPVOID pBuf;
		pBuf = XGlobalLock(hGbl);
		pPicStream->Read(pBuf, media.mediaSize, NULL);
		XGlobalUnlock(hGbl);
		break;

	case FILE_COMPRESSION_WINLZA:
		try
		{
			ULONG cbOrgSize = 0;

			pData = new BYTE[media.mediaSize];
			KS_CHECK_BOOLEX(pData != NULL, hr = E_OUTOFMEMORY);
		
			pPicStream->Read(&cbOrgSize, sizeof(cbOrgSize), NULL);
			KS_CHECK_BOOLEX(cbOrgSize, hr = E_MD_NOSOURCE);

			hr = pPicStream->Read(pData, media.mediaSize, NULL);
			KS_CHECK(hr);

			hr = zlibDecompress(pData, media.mediaSize, cbOrgSize, &hGbl);
			KS_CHECK(hr);
		}
		catch(...)
		{
			return E_UNEXPECTED;
		}
		break;

	default:
		REPORT_ONCE("Unknown Compression Method!!!");
		return E_UNEXPECTED;
	}
	hr = CreateMDSFromAttachHGbl(hGbl, &media.pSource);
	
KS_EXIT:
	if (pData)
		delete[] pData;
	return hr;
}

// -------------------------------------------------------------------------

STDMETHODIMP Serialize_Read_02(CWpsImage* pThis, KSArchive& ar)
{
	HRESULT hr;
	_KWPSRecordHeader hdr;
	KWPSMainReader wr;
	WPSImageData img;
	
	wr.Attach(&ar);

	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSImageData, hr = E_UNEXPECTED);

	ZeroMemory(&img, sizeof(img));
	wr.Read(&img, sizeof(img));

	ASSERT(img.cchMediaName < _MAX_PATH);

	img.fRatio = -1;//<whui@kingsoft.net ������ֵ�������ˣ�>
	img.nPosition = -1;

	pThis->m_ImgPara.nDrawMode	= img.nRotateMode;
	pThis->m_ImgPara.nPositionNoUse  = img.nPosition;
	pThis->m_ImgPara.bRatioNoUse		= img.fRatio;
	pThis->m_ImgPara.nSetSize	= img.nSetSize;
	pThis->m_ImgPara.ptTopLeft.x = img.xLeft;
	pThis->m_ImgPara.ptTopLeft.y = img.yTop;
	pThis->m_nDrawWidth			 = img.cxDrawWidth;
	pThis->m_nDrawHeight		 = img.cyDrawHeight;
	
	pThis->m_colorTran = img.crTransColor;
	pThis->m_ImgColor.nBrightness = img.nBrightness;
	pThis->m_ImgColor.nContrast = img.nContrast;
	pThis->m_ImgColor.bGrayScale = img.fGrayScale;
	pThis->m_ImgColor.bMono = img.fMono;
	
	pThis->m_ImgCrop.uCropShape = img.nCropShape;
	pThis->m_ImgCrop.nNum = img.nEdgeNumber;
	pThis->m_ImgCrop.rcCrop = img.rcCrop;
	pThis->m_ImgCrop.nScale = img.nCropScale;
	
	pThis->m_bSaveInFile = img.fSaveInFile;

	//img.mediaNameFlags = 0;
	//img.cchMediaName	= wcslen(FileName);
	if (pThis->m_pSource)
	{
		pThis->m_pSource->Release();
		pThis->m_pSource = NULL;
	}
	if (img.mediaOffset != (ULONG)-1)
	{
		WPSMediaDataParam media;
		media.mediaOffset = img.mediaOffset;
		ReadMediaData(_QueryPicStream(ar), media);
		pThis->m_srcCategory = media.Category;
		pThis->m_pSource	 = media.pSource;
		//media.Compression;
	}
	if (img.cchMediaName < _MAX_PATH - 1)
	{
		WCHAR FileName[_MAX_PATH];
		wr.Read(FileName, img.cchMediaName*sizeof(WCHAR));
		FileName[img.cchMediaName] = 0;
		wcstombs(pThis->m_szFileName, FileName, _MAX_PATH);
	}

	// {{ ---> ֻҪ������һ�䣬�����Ժ������¼�Ϳ�����չ�ˡ�
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());
	return S_OK;

KS_EXIT:
	return WPSIOThrowError(hr);
}

STDMETHODIMP Serialize_Write_02(CWpsImage* pThis, KSArchive& ar)
{
	// 1) дͼ������
	WPSMediaDataParam media;
	media.mediaOffset = (ULONG)-1;

	if (pThis->m_bSaveInFile && pThis->m_pSource)
	{
		media.pSource		= pThis->m_pSource;
		media.Category		= pThis->m_srcCategory;
		media.Compression	= FILE_COMPRESSION_WINLZA;
			// (media.Category == FILE_AUTODETECT ? FILE_COMPRESSION_NONE : FILE_COMPRESSION_WINLZA);
		WriteMediaData(_NeedPicStream(ar), media);
	}

	// 2) ���ͼ���������
	WCHAR FileName[_MAX_PATH];
	mbstowcs(FileName, pThis->m_szFileName, _MAX_PATH);
	ASSERT(sizeof(WCHAR) == 2);	// {{ ---> Linux 4bytes wchar_t��������Ҫ�޸�!
	
	WPSImageData img;
	img.mediaOffset	= media.mediaOffset;
	img.mediaNameFlags = 0;
	img.cchMediaName = wcslen(FileName);
	
	img.nRotateMode	= pThis->m_ImgPara.nDrawMode;
	img.nPosition	= -1;//<whui@kingsoft.net ������ֵ�������ˣ�>
	img.fRatio		= -1;
	img.nSetSize	= pThis->m_ImgPara.nSetSize;
	img.xLeft		= pThis->m_ImgPara.ptTopLeft.x;
	img.yTop		= pThis->m_ImgPara.ptTopLeft.y;
	img.cxDrawWidth	= pThis->m_nDrawWidth;
	img.cyDrawHeight = pThis->m_nDrawHeight;
	
	img.crTransColor = pThis->m_colorTran;
	img.nBrightness	= pThis->m_ImgColor.nBrightness;
	img.nContrast	= pThis->m_ImgColor.nContrast;
	img.fGrayScale	= pThis->m_ImgColor.bGrayScale;
	img.fMono		= pThis->m_ImgColor.bMono;
	
	img.nCropShape	= pThis->m_ImgCrop.uCropShape;
	img.nEdgeNumber	= pThis->m_ImgCrop.nNum;	// ������εĽǱ���
	img.rcCrop		= pThis->m_ImgCrop.rcCrop;	// ���е���Ӿ���
	img.nCropScale	= pThis->m_ImgCrop.nScale;	// ͹���� 0-100
	
	img.fSaveInFile	= pThis->m_bSaveInFile;		// �Ƿ��ͼ�����ݱ������ļ��С�
	
	// 3) дͼ���������
	{
		UINT wSize = sizeof(img) + img.cchMediaName*sizeof(WCHAR);
		KWPSMainWriter wr;
		wr.Attach(&ar);
		wr.BeginWriteRec(TAG_WPSImageData, wSize);
			wr.Write(&img, sizeof(img));
			wr.Write(FileName, img.cchMediaName*sizeof(WCHAR));
		wr.EndWriteRec();
	}
	return S_OK;
}

STDMETHODIMP Serialize_Write_01(CWpsImage* pThis, KSArchive& ar)
{
	REPORT_ONCE("��ʱ��֧�ֱ���Ϊwps2001��ʽ - CWpsImage");
	return E_NOTIMPL;
}

STDMETHODIMP Serialize_Write_97(CWpsImage* pThis, KSArchive& ar)
{
	REPORT_ONCE("��ʱ��֧�ֱ���Ϊwps97��ʽ - CWpsImage");
	return E_NOTIMPL;
}

CWpsImage::CWpsImage()
{
/**@@todo
	m_pDocument		= NULL;
	m_pDrawObj		= NULL;
	_pMedia			= NULL;
*/
	
	*m_szFileName	= 0;
	m_srcCategory	= FILE_INVALID;
	m_pSource		= NULL;
	m_bSaveInFile	= TRUE;
		
	m_ImgPara.ptTopLeft.x	= 0;
	m_ImgPara.ptTopLeft.y	= 0;
	m_ImgPara.nDrawMode		= 0;
	m_ImgPara.bRatioNoUse	= -1;
	m_ImgPara.nPositionNoUse= -1;
	m_ImgPara.nSetSize		= 0;
	
	m_nDrawWidth	= 0;
	m_nDrawHeight	= 0;
	m_colorTran		= WPS_IMG_NO_TRANSPARENT_COLOR;	//��λΪ1��ʾ��͸��
	
	m_ImgCrop.rcCrop.SetRectEmpty();	//���п�����Ϊ��
	m_ImgCrop.uCropShape	= CROP_NONE;
	
	m_ImgColor.nBrightness	= 0;		//���ȵ���ֵΪ0
	m_ImgColor.nContrast	= 0;		//���ȵ���ֵΪ0
	m_ImgColor.bGrayScale	= FALSE;	//�Ƿ�Ҷ���ʾ
	m_ImgColor.bMono		= FALSE;	//�Ƿ�ڰ���ʾ
	
	m_bDrawFinished	= TRUE;		//�Ƿ��굱ǰ����֡
	m_bNotScreen	= FALSE;		//�Ƿ�����Ļ����ʾ
}

void CWpsImage::Clear()
{
	/*@@todo
	if (_pMedia)
	{
		delete _pMedia;
		_pMedia = NULL;
	}*/
	if (m_pSource)
	{
		m_pSource->Release();
		m_pSource = NULL;
		*m_szFileName = 0;
	}
}

inline
STDMETHODIMP_(HGBL) CreateHGblFromArchive(KSArchive& ar, DWORD dwBytes)
{
	LPVOID pData;
	HGBL hGbl = XGlobalAlloc(GHND, dwBytes);
	if (hGbl)
	{
		pData = XGlobalLock(hGbl);
		ar.Read(pData, dwBytes);
		XGlobalUnlock(hGbl);
	}
	else
	{
		AfxThrowMemoryException();
	}
	return hGbl;
}

BOOL CWpsImage::Attach(HGBL hGbl, UINT Category)
{
	if (m_pSource != NULL)
		Clear();
	
	// {{ �Ͱ汾��wps office Ϊ����ʾͼƬ�������ļ�������������ļ�ʵ���ϲ�����
	m_srcCategory = Category;
	_tcscpy(m_szFileName, _T("Picture"));
	return CreateMDSFromAttachHGbl(hGbl, &m_pSource) == S_OK;
}

BOOL CWpsImage::CreateImage(LPCTSTR szFile)
{
	if (m_pSource != NULL)
		Clear();
	
	m_srcCategory = FILE_AUTODETECT;
	_tcscpy(m_szFileName, szFile);
	return CreateMDSFromFile(szFile, &m_pSource) == S_OK;
}

void CWpsImage::ReadWmfFile(KSArchive& ar)
{
	TRACEA("Enter CWpsImage::ReadWmfFile(ar) ....\n");

	WORD 	wWM;
	HGBL hGbl;

	//m_bWmfFile = TRUE;
	m_bSaveInFile = FALSE;
	
	ar >> wWM;
	if (wWM == 0x4143)
	{
		m_bSaveInFile = TRUE;
		
		DWORD dwBytes = 0;
		ar >> dwBytes;
		hGbl = CreateHGblFromArchive(ar, dwBytes);
		if (hGbl)
			Attach(hGbl, FILE_AUTODETECT);
	}
}

void CWpsImage::ReadDibFile(KSArchive& ar)
{
	TRACEA("Enter CWpsImage::ReadDibFile(ar) ....\n");

	WORD 	wWM;
	HGBL hGbl;
	
	//m_bWmfFile = FALSE;
	m_bSaveInFile = FALSE;

	ar >> wWM;
	if (wWM == 0x4142)
	{
		m_bSaveInFile = TRUE;

		DWORD dwBytes = 0;
		ar >> dwBytes;
		hGbl = CreateHGblFromArchive(ar, dwBytes);
		if (hGbl)
			Attach(hGbl, FILE_AUTODETECT);
	}
}

void CWpsImage::ReadAnimateFile(KSArchive& ar)
{
	TRACEA("Enter CWpsImage::ReadAnimateFile(ar) ...\n");

	UINT  j, iCurrFrame = 0;
	DWORD nTotalDIBNum = 0;
	DWORD m_dwImgWidth = 0, m_dwImgHeight = 0;
	BYTE* pv;
	
	DWORD	 dwBytes;
	BYTE*	 pHeader;
	HGBL* hFrames;
	HGBL	 hFrame;
	
	DWORD dwFrameOffset;
	DWORD dwBytesWPSDIBAnimation;
	HGBL	 hWPSDIBAnimation;
	WPSDibAnimationHeader* wdaHeader;
	WPSDibAnimationFrame*  wdaFrames;
	BYTE* pWPSDIBFrame;
	
	m_bSaveInFile = TRUE;
	m_srcCategory = FILE_DIBANIMATION;
	
	// wps2001-Animation��ʽ
	// int	nTotalDIBNum;	// ����֡����
	// int  m_nDibNumber;	// ��ǰ����֡
	// int  m_OrgXArray[nTotalDIBNum];
	// int	m_OrgYArray[nTotalDIBNum];
	// byte m_DisposalArray[nTotalDIBNum];
	// int	m_DelayTimeArray[nTotalDIBNum];
	// CWpsDib m_AnimateDIBArray[nTotalDIBNum];
	// DWORD   m_dwImgWidth;
	// DWORD   m_dwImgHeight;

	ar >> nTotalDIBNum;
	if (nTotalDIBNum > 0)
	{
		dwBytes = 4 + 13*nTotalDIBNum;
		pHeader = new BYTE[dwBytes + (sizeof(HGBL)+1)*nTotalDIBNum];
		hFrames = (HGBL*)(pHeader + dwBytes + nTotalDIBNum);
		ar.Read(pHeader, dwBytes);
		
		dwBytesWPSDIBAnimation =
		dwFrameOffset = sizeof(WPSDibAnimationHeader) + sizeof(WPSDibAnimationFrame)*nTotalDIBNum;
		for (iCurrFrame = 0; iCurrFrame < nTotalDIBNum; ++iCurrFrame)
		{
			dwBytes = 0;
			ar >> dwBytes;
			hFrame = CreateHGblFromArchive(ar, dwBytes);
			if (hFrame == NULL)
				goto lzExit;
			hFrames[iCurrFrame] = hFrame;
			// ע�⣺GlobalSize(hFrame) >= dwBytes;
			dwBytesWPSDIBAnimation += XGlobalSize(hFrame);
		}
		ar >> m_dwImgWidth;
		ar >> m_dwImgHeight;
		
		hWPSDIBAnimation = XGlobalAlloc(GHND, dwBytesWPSDIBAnimation);
		if (hWPSDIBAnimation == NULL)
		{
			REPORT("����: ����WPS2001-DIBAnimation - GlobalAllocʧ��");
			goto lzExit;
		}
		wdaHeader = (WPSDibAnimationHeader*)XGlobalLock(hWPSDIBAnimation);
		wdaFrames = (WPSDibAnimationFrame*)(wdaHeader+1);
		pWPSDIBFrame = (BYTE*)wdaHeader + dwFrameOffset;
		
		pv = pHeader;
		wdaHeader->dwTag		= TAG_WPSDibAnimation;
		wdaHeader->nTotalDIBNum	= nTotalDIBNum;
		wdaHeader->iCurrDibNumber = TokenVal(pv, DWORD);
		wdaHeader->dwImgWidth	= m_dwImgWidth;
		wdaHeader->dwImgHeight	= m_dwImgHeight;
		
		for (j = 0; j < nTotalDIBNum; ++j)
			wdaFrames[j].orgX = TokenVal(pv, DWORD);
		for (j = 0; j < nTotalDIBNum; ++j)
			wdaFrames[j].orgY = TokenVal(pv, DWORD);
		for (j = 0; j < nTotalDIBNum; ++j)
			wdaFrames[j].disposal = TokenVal(pv, BYTE);
		for (j = 0; j < nTotalDIBNum; ++j)
			wdaFrames[j].delayTime = TokenVal(pv, DWORD);
		for (j = 0; j < nTotalDIBNum; ++j)
		{
			hFrame = hFrames[j];
			dwBytes = XGlobalSize(hFrame);
			CopyMemory(pWPSDIBFrame, XGlobalLock(hFrame), dwBytes);
			XGlobalUnlock(hFrame);
			
			pWPSDIBFrame += dwBytes;
			dwFrameOffset += dwBytes;
			wdaFrames[j].bmOffsetNext = dwFrameOffset;
		}
		XGlobalUnlock(hWPSDIBAnimation);
		Attach(hWPSDIBAnimation, FILE_DIBANIMATION);

lzExit:
		for (j = 0; j < iCurrFrame; ++j)
		{
			XGlobalFree(hFrames[j]);
		}
		delete pHeader;
	}
}

HRESULT CWpsImage::Serialize_Read_01(KSArchive& ar)
{
	BOOL	bNotScreen = FALSE;
	WORD 	wWM = 0;
	CString szImgName(m_szFileName);
	
	if(!g_fCompoundFile)
	{
		struct tagImgParaOld{
			CPoint 		ptTopLeft; 	//����ڿ�����Ͻǵ�����
			UINT 		nDrawMode;	//��ת��
			UINT		nSetSize;	//0 ����ԭͼ��ߴ� 1 ��ԭͼ��ߴ� 2 ָ����С------|
			//											  |>>>�ּ�Ϊ 0 �����С(����) 1 ԭͼ���� 2 ԭͼ�ߴ�
			BOOL		bRatio;		//0 ������ԭͼ����߱� 1 ����ԭͼ����߱�	------|	  �μ�SetImgSizeType()
			UINT		nPosition;	//��Կ��λ�� 0 ��2 ����(ԭΪ����) 	1��3 ƽ�� 
		} ImgParaOld;
		
		ar.Read(&ImgParaOld, sizeof(ImgPara));
		ar.Read(&m_ImgCrop, sizeof(ImgCrop));//���п�
		ar.Read(&m_ImgColor, sizeof(ImgColor));//ɫ��
		
		ar >> m_colorTran;//͸��ɫ
		
		ar >> bNotScreen;//����ʾ
		//m_bNotScreen = FALSE; // ͼ����ʾ���ۺ�����...�����ƣ����Բ�������	11/24/98--yxm
		
		if (ImgParaOld.nSetSize == 2)
		{
			CSize draw;
			ar >> draw;
			m_nDrawWidth = draw.cx;
			m_nDrawHeight= draw.cy;
		}
		ar >> wWM >>szImgName;
		lstrcpy(m_szFileName, (const char*)szImgName);
		
		m_bSaveInFile = TRUE;
		switch (wWM)
		{
		case 0x4D58: //WMF�����ļ���
			ReadWmfFile(ar);
			break;
			
		case 0x4D42: //BMP�����ļ���
			ReadDibFile(ar);
			break;
			
		case 0x4D48: //���DIB�����ļ���
			ReadAnimateFile(ar);
			break;
			
		case 0x4D56: //WMF�������ļ���
		case (WORD)0x4D40: //BMP�������ļ���
			m_bSaveInFile = FALSE;
			VERIFY(CreateImage(szImgName));
			break;
		}
		// 2002��ǰ��ƽ�̷�ʽ������ͬ������Ҫ��һ��
		// 2002��ͼ����䷽ʽ��ȫ����nSetSize������
		
		// S, R, P
		// 0, 0, 0	-- ����ͼƬ��򣨲�����
		// 0, 1, 0	-- ����ͼƬ���ֱ�����ֻ��ͼƬ��֧��
		// 1, 0, 3	-- ����ͼƬԭͼƽ��
		// 0, 0, 2	-- ҳ��ͼƬ���������
		// 1, 0, 1	-- ҳ��ͼƬԭͼƽ��
		// 1, 1, 0	-- �������ͼƬԭͼ
		// 0, 0, 0	-- ���������򣨲�����
		
		// <whui@kingsoft.net 2002��ͼ��������ȫ����nSetSize�����ƣ�>
		// 0 �����С(����), 1 ԭͼ����, 2 ԭͼ�ߴ�, 3 �����ݺ�ȣ�4 ƽ��
		memset(&m_ImgPara, sizeof(m_ImgPara), 0);
		m_ImgPara.ptTopLeft = ImgParaOld.ptTopLeft;
		m_ImgPara.nDrawMode = ImgParaOld.nDrawMode;
		m_ImgPara.bRatioNoUse = -1;
		m_ImgPara.nPositionNoUse = -1;
		if (ImgParaOld.nSetSize == 0 && ImgParaOld.bRatio == 0) //�����С(����)
		{
			m_ImgPara.nSetSize = IMG_SIZE_TYPE_FILL;
		}
		else if (ImgParaOld.nSetSize == 0 && ImgParaOld.bRatio == 1) //ԭͼ����
		{
			// ע�⣺CFrameImg����֧��IMG_SIZE_TYPE_ORIGN���ԣ�
			// ����CFrameImg�����Ҫ��IMG_SIZE_TYPE_ORIGN���Ի�ΪIMG_SIZE_TYPE_SCALE
			m_ImgPara.nSetSize = IMG_SIZE_TYPE_SCALE;
		}
		else if (ImgParaOld.nSetSize == 1 && ImgParaOld.bRatio == 0) //ƽ��
		{
			m_ImgPara.nSetSize = IMG_SIZE_TYPE_TITLE;
		}
		else if (ImgParaOld.nSetSize == 1 && ImgParaOld.bRatio == 1) //ԭͼ
		{
			m_ImgPara.nSetSize = IMG_SIZE_TYPE_ORIGN;
		}
		return S_OK;
	}
	return E_FAIL;
}

inline HRESULT CWpsImage::ReadStream_01(KSArchive &ar)
{
	//��Ϊ�������а���һ�������Ծ�������
	if(!g_fCompoundFile)
	{
		return Serialize_Read_01(ar);
	}
	return E_FAIL;
}

inline HRESULT CWpsImage::ReadStream_02(KSArchive &ar)
{
	if(g_fCompoundFile)
	{
		::Serialize_Read_02(this, ar);
		return S_OK;
	}
	return E_FAIL;
}

inline HRESULT CWpsImage::ReadStream(KSArchive &ar)
{
	if(ar.IsLoading())
	{
		if(g_fCompoundFile)
		{
			return ReadStream_02(ar);
		}
		else
		{
			return ReadStream_01(ar);
		}
		return S_OK;
	}
	return E_FAIL;
}

inline HRESULT CWpsImage::WriteStream_01(KSArchive &ar)
{
	if(!g_fCompoundFile)
	{
		::Serialize_Write_01(this, ar);
		return S_OK;
	}
	return E_FAIL;
}

inline HRESULT CWpsImage::WriteStream_02(KSArchive &ar)
{
	if(g_fCompoundFile)
	{
		::Serialize_Write_02(this, ar);
		return S_OK;
	}
	return E_FAIL;
}

inline HRESULT CWpsImage::WriteStream(KSArchive &ar)
{
	if (ar.IsStoring())
	{
		if (g_fCompoundFile)
			return WriteStream_02(ar);
		else
			return WriteStream_01(ar);
	}
	return E_FAIL;
}

/*************************************************************************
	���ܣ�	WPS97 file support
*************************************************************************/
void CWpsImage::Serialize_97(KSArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		::Serialize_Write_97(this, ar);
	}
	else
	{
		WORD wSetSize;
		__int16 wTemp;
		struct tagImgParaOld{
			CPoint 		ptTopLeft; 	//����ڿ�����Ͻǵ�����
			UINT 		nDrawMode;	//��ת��
			UINT		nSetSize;	//0 �Զ� 1 ��ԭͼ��ߴ� 2 ��ָ���ߴ�	------|
			//											  |>>>�ּ�Ϊ 0 �����С(����) 1 ԭͼ���� 2 ԭͼ�ߴ�
			BOOL		bRatio;		//���������� 	0 �������� 1 ͼ����߱�	------|	  �μ�SetImgSizeType()
			UINT		nPosition;	//��Կ��λ��  0 ����	1 ƽ�� 2 ����(ԭΪ����)
		} ImgParaOld;
		ar >> wTemp; ImgParaOld.ptTopLeft.x = wTemp;
		ar >> wTemp; ImgParaOld.ptTopLeft.y = wTemp;
		ar >> wTemp; ImgParaOld.nDrawMode = wTemp;
		ar >> wSetSize; ImgParaOld.nSetSize = wSetSize;
		ar >> wTemp; ImgParaOld.bRatio = wTemp;
		ar >> wTemp; ImgParaOld.nPosition = wTemp;

		// 2002��ǰ��ƽ�̷�ʽ������ͬ������Ҫ��һ��
		// 2002��ͼ����䷽ʽ��ȫ����nSetSize������

		// <whui@kingsoft.net 2002��ͼ��������ȫ����nSetSize�����ƣ�>
		// 0 �����С(����), 1 ԭͼ����, 2 ԭͼ�ߴ�, 3 �����ݺ�ȣ�4 ƽ��
		memset(&m_ImgPara, sizeof(m_ImgPara), 0);
		m_ImgPara.ptTopLeft = ImgParaOld.ptTopLeft;
		m_ImgPara.nDrawMode = ImgParaOld.nDrawMode;
		m_ImgPara.bRatioNoUse = -1;
		m_ImgPara.nPositionNoUse = -1;

		if (wSetSize == 0)	//wps97'�Զ�
		{
			SetImgSizeType(IMG_SIZE_TYPE_SCALE);
		}

		if (wSetSize == 1)	//wps97'ԭͼ�ߴ�
		{
			if (ImgParaOld.nPosition != 1)	//���л��Զ���ʱ
				SetImgSizeType(IMG_SIZE_TYPE_FILL);		//wps97'ԭͼ�ߴ�->wps98'�����С
			else
				SetImgSizeType(IMG_SIZE_TYPE_TITLE);	//����ƽ��
		}

		if (wSetSize == 2)	//wps97'�Զ���ߴ�
		{	
			ar >> wTemp; m_nDrawWidth = wTemp;
			ar >> wTemp; m_nDrawHeight = wTemp;
			// ע�⣺CFrameImg����֧��IMG_SIZE_TYPE_ORIGN���ԣ�
			// ����CFrameImg�����Ҫ��IMG_SIZE_TYPE_ORIGN���Ի�ΪIMG_SIZE_TYPE_SCALE
			SetImgSizeType(IMG_SIZE_TYPE_ORIGN);
			SetTopLeft(0, 0, FALSE);
		}
		
		WORD wWM;
		CString szImgName(m_szFileName);
		ar >> wWM >> szImgName;
		lstrcpy(m_szFileName, (const char*)szImgName);

		switch(wWM)
		{
		case 0x4D58: // WMF�����ļ���
			ReadWmfFile(ar);
			break;
			
		case 0x4D42: //BMP�����ļ���
			ReadDibFile(ar);
			break;
			
		case 0x4D56: // WMF�������ļ���
		case 0x4D40: // BMP�������ļ���
			m_bSaveInFile = FALSE;
			VERIFY(CreateImage(szImgName));
			break;
		}
	}
}

void CWpsImage::Serialize_98(KSArchive& ar)
{
	CWpsImage::Serialize_01(ar);
}

void CWpsImage::Serialize_01(KSArchive& ar)
{
	if(ar.IsStoring())
	{
		if(FAILED(WriteStream(ar)))
		{
			TRACEA("CWpsImage::Serialize_01 WriteStream Failed\r\n");
		}
	}
	else
	{
		if(FAILED(ReadStream(ar)))
		{
			TRACEA("CWpsImage::Serialize_01 ReadStream Failed\r\n");
		}
	}
}

// -------------------------------------------------------------------------
