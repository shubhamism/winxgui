/* -------------------------------------------------------------------------
//	�ļ���		��	zlib/decompress.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-29 17:36:16
//	��������	��	
//
// -----------------------------------------------------------------------*/
#include "stdafx.h"

#ifndef _ZLIB_H
#include "zlib/zlib.h"
#endif

// -------------------------------------------------------------------------

STDMETHODIMP zlibDecompress(LPCVOID pSrc, UINT cbSize, UINT cbOrgSize, HGBL* phGbl)
{
	HRESULT hr;
	HGBL hGbl = NULL;
	Bytef* pDest;
	uLongf cbDecodeSize = cbOrgSize;
	
	ASSERT(Z_OK == S_OK && sizeof(UINT) >= sizeof(uLongf));
	
	hGbl = XGlobalAlloc(GHND, cbOrgSize);
	if (hGbl == NULL)
		return E_OUTOFMEMORY;
	
	ASSERT(cbOrgSize == XGlobalSize(hGbl));
	try
	{
		pDest = (Bytef*)XGlobalLock(hGbl);
		hr = uncompress(pDest, (uLongf*)&cbDecodeSize, (const Bytef*)pSrc, cbSize, 0);
		XGlobalUnlock(hGbl);
		
		ASSERT(hr == Z_OK);
		if (cbDecodeSize !=	cbOrgSize)
		{
			hr = E_FAIL;
			goto lzExit;
		}
	}
	catch (...)
	{
		REPORT( __X("��ѹʧ��") );
		hr = E_UNEXPECTED;
	}
	
	if (hr == Z_OK)	// if success!!
	{
		*phGbl = hGbl;
		return S_OK;
	}
	
lzExit:
	XGlobalFree(hGbl);
	return hr;
}

// -------------------------------------------------------------------------
