/* -------------------------------------------------------------------------
//	�ļ���		��	comment.h
//	������		��	Tank
//	����ʱ��	��	2004-11-19 5:38:21 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/


#ifndef __COMMENT_H__
#define __COMMENT_H__

#ifndef __FRAMETEXT_H__
#include "draw/frametext.h"
#endif

#ifndef __PTOBJ_H__
#include "draw/ptobj.h"
#endif
//typedef enum enum_FINDTYPE
//{
//	enum_ForwardFind = 0,
//	enum_BackwardFind
//}FINDTYPE;
//class CFrameText;
//class CLineObj;
class KSComment : public CObject
{
protected:
	DECLARE_SERIAL(KSComment);
	KSComment();
public:
	KSComment(int nID);
	virtual ~KSComment();

protected:
	CFrameText* m_pFrameText;           // ��ע�����ֿ򲿷�ָ��	
	int m_nID;
	WORD m_wUserID;
public:
	CFrameText* GetFrameText() { return m_pFrameText; }
	void SetFrameText(CFrameText* pFrameText) { m_pFrameText = pFrameText; }
	void Serialize(KSArchive& ar);
	void SetCommentID(int nID) { m_nID = nID;}
	void GetCommentID(int& nID) { nID = m_nID; }
	void SetUserID(WORD wUserID) { m_wUserID = wUserID; }
	WORD GetUserID() { return m_wUserID; }
};


// ��ע����
class KSCommentMan : public CObject
{
public:
	KSCommentMan();
	virtual ~KSCommentMan();

protected:
	CPtrArray	m_aryComments;
	WORD m_wCurUserID;		
public:
	int  NumOfComment() { return m_aryComments.GetSize(); }
	int  AddComment(KSComment*);
	void RemoveComment(KSComment*, BOOL = TRUE);
	BOOL GetComment(int, KSComment**);                   // ͨ������ϵ�б�־��id���Ҷ���
	KSComment* GetCommentByIndex(int);
	void SetCurUserID(WORD wUserID);
	WORD GetCurUserID() const { return  m_wCurUserID; }

//#ifdef _DEBUG
//public:
//	virtual void Dump(CDumpContext& dc) const;
//	virtual void AssertValid() const;
//#endif //_DEBUG
};	
#endif //#ifndef __COMMENT_H__