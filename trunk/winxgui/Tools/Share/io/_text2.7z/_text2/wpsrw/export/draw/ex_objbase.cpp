 /* -------------------------------------------------------------------------
//	�ļ���		��	ex_objbase.cpp
//	������		��	��־��
//	����ʱ��	��	2004-10-13 13:45:00
//	��������	��	�������л��๫�����Ե�ת��
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_objbase.h"

#include "ex_shape.h"

#include "ex_ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//helper func
//
//
//

EX_SHAPE_API gConvertSolidFill(
							KDWShapeOPT& opt,
							KCOLORINDEX fillColor)
{
	opt.AddPropFix(msopt_fillType, msofillSolid);
	opt.AddPropFix(msopt_fillColor, gConvertObjColor(fillColor));
	opt.AddPropBool(msopt_fFilled, TRUE);
}

EX_SHAPE_API ConvertHatchedBrushFill(
		MsoBlipStore& blipStore,
		KDWShapeOPT& opt,
		LONG lbHatch,
		KCOLORINDEX fillColor,
		KCOLORINDEX fillBackColor)
{
	extern BYTE _g_blipHatchedBrushDIBBuffer[6][80];
	// bug 21655, ����Ϊ��ͼ������ʱ��
	static long lFillPatterns[6] = {0x00000019, 0x00000018,0x00000012, 0x00000013,
		0x00000004, 0x00000033
	};

	HRESULT hr;
	ks_stdptr<IKLockBuffer> spLockBuf;
	ASSERT(lbHatch>= 0 && lbHatch <= 6);
	hr = CreateLBFromBufferImpl(&spLockBuf,
		(const UINT8*)_g_blipHatchedBrushDIBBuffer[lbHatch] /*- sizeof(BITMAPFILEHEADER)*/,
		80 /*+ sizeof(BITMAPFILEHEADER)*/);
	ASSERT(SUCCEEDED(hr));
	KDWBlip blipFill = blipStore.NewBlip(msoblipDIB, spLockBuf);
	ASSERT(blipFill.Good());

	/*
	 *	���� msopt_fillType(384), msopt_fillBlip(390), msopt_fillColor(385)
	 *  msopt_fillBackColor(387)
	 */
	opt.AddPropFix(msopt_fillType, msofillPattern);
	opt.AddPropFix(msopt_fillPattern, lFillPatterns[lbHatch]);
	opt.AddPropFix(msopt_fillBlip, blipFill);
	opt.AddPropFix(msopt_fillColor, gConvertObjColor(fillColor));
	opt.AddPropFix(msopt_fillBackColor, gConvertObjColor(fillBackColor));
	opt.AddPropBool(msopt_fFilled, TRUE);
}

#ifdef WPP_ONLY
IColorScheme* g_pCurColorScheme = NULL;

// liupeng: �����������ʱ���������������浱ǰslide����ɫ����
// ��������wpp
EX_SHAPE_API gSetCurColorScheme(IColorScheme* pColorScheme)
{
	g_pCurColorScheme = pColorScheme;
}

IColorScheme* gGetCurColorScheme()
{
	return g_pCurColorScheme;
}

#endif

EX_SHAPE_API gConvertGradientFill(
								 KDWShapeOPT& opt,
								 int nColorDirection,
								 int nColorDistortion,
								 KCOLORINDEX fillColor,
								 KCOLORINDEX fillBackColor)
{
	INT32 fillType;
	INT32 fillAngle = 0;
	INT32 fillFocus = 0;
	INT32 fillToLeft = 0, fillToRight = 0, fillToTop = 0, fillToBottom = 0;
	INT32 fillShadeType;
	
	if(nColorDirection >= GRAD_HORIZ && nColorDirection <= GRAD_LEANDOWN)
	{
		fillType = msofillShadeScale;
		if(nColorDistortion == GRAD_LEFTTOP)//���ϵ���
		{
			fillFocus = 100;
		}
		else if(nColorDistortion == GRAD_LEFTBOTTOM)//�����µ��м�
		{
			fillFocus = nColorDirection == GRAD_HORIZ ? 50 : -50;//wps��bug����Ϊ��һ��
		}
		else if(nColorDistortion == GRAD_RIGHTTOP)//���µ���
		{
			fillFocus = 0;
		}
		else if(nColorDistortion == GRAD_RIGHTBOTTOM)//���м䵽����
		{
			fillFocus = nColorDirection == GRAD_HORIZ ? -50 : 50;//wps��bug����Ϊ��һ��
		}
		else
		{
			ASSERT(FALSE);
		}
		//
		if(nColorDirection == GRAD_HORIZ)//ˮƽ����
		{
		}
		else if(nColorDirection == GRAD_VERT)//��ֱ����
		{
			fillAngle = 0xffa60000;
		}
		else if(nColorDirection == GRAD_LEANUP)//��б����(������ƫ������)
		{
			fillAngle = 0xff790000;
		}
		else if(nColorDirection == GRAD_LEANDOWN)//��б����(������ƫ������)
		{
			fillAngle = 0xffd30000;
			// liupeng: ppt�е�б���µ�focus������Щ��ͬ�����������������⴦��
			if (fillFocus == 0)
				fillFocus = 100;
			else if (fillFocus == 100)
				fillFocus = 0;
		}
	}
	else if(nColorDirection == GRAD_CORNER)//�ӽǶȽ���
	{
		fillType = msofillShadeCenter;
		fillFocus = 100;
		if(nColorDistortion == GRAD_LEFTTOP)//���ϵ���
		{
		}
		else if(nColorDistortion == GRAD_LEFTBOTTOM)//�����µ��м�
		{
			fillToTop = 0x00010000;
			fillToBottom = 0x00010000;
		}
		else if(nColorDistortion == GRAD_RIGHTTOP)//���µ���
		{
			fillToLeft = 0x00010000;
			fillToRight = 0x00010000;
		}
		else if(nColorDistortion == GRAD_RIGHTBOTTOM)//���м䵽����
		{
			fillToTop = 0x00010000;
			fillToBottom = 0x00010000;
			fillToLeft = 0x00010000;
			fillToRight = 0x00010000;
		}
		else
		{
			ASSERT(FALSE);
		}
	}
	else if(nColorDirection == GRAD_CENTER)//�����Ľ���
	{
		fillType = msofillShadeShape;
		fillToTop = 0x8000;
		fillToBottom = 0x8000;
		fillToLeft = 0x8000;
		fillToRight = 0x8000;
		
		if(nColorDistortion == GRAD_LEFTTOP || nColorDistortion == GRAD_LEFTBOTTOM)//���ϵ���
		{
			fillFocus = 0;
		}
		else if(nColorDistortion == GRAD_RIGHTTOP || nColorDistortion == GRAD_RIGHTBOTTOM)//���µ���
		{
			fillFocus = 100;
		}
		else
		{
			ASSERT(FALSE);
		}
	}
	else
	{
		ASSERT(FALSE);
	}
	
	fillShadeType = msoshadeDefault | msoshadeOneColor;
	
	opt.AddPropFix(msopt_fillType, fillType);
	opt.AddPropFix(msopt_fillAngle, fillAngle);
	opt.AddPropFix(msopt_fillColor, gConvertObjColor(fillColor));
#ifdef WPP_ONLY
	if (g_pCurColorScheme)
	{
		// liupeng: CalcSecondColorForOneShade��fillBackColorת����
		// COLORREF, ��������ֽ�Ӧ�����
		opt.AddPropFix(msopt_fillBackColor, 
			gConvertObjColor(KColorModel::CalcSecondColorForOneShade(
			fillColor, 
			fillBackColor, 
			g_pCurColorScheme) & 0x00ffffff));
	}
	else
	{
		opt.AddPropFix(msopt_fillBackColor, gConvertObjColor(fillBackColor));
	}
	
#else
	opt.AddPropFix(msopt_fillBackColor, gConvertObjColor(fillBackColor));
#endif
	opt.AddPropFix(msopt_fillFocus, fillFocus);
	opt.AddPropFix(msopt_fillToTop, fillToTop);
	opt.AddPropFix(msopt_fillToBottom, fillToBottom);
	opt.AddPropFix(msopt_fillToLeft, fillToLeft);
	opt.AddPropFix(msopt_fillToRight, fillToRight);
	//opt.AddPropFix(msopt_fillShadeType, fillShadeType);//wps�в�����¼�ǵ�ɫ��仹��˫ɫ���
	opt.AddPropBool(msopt_fFilled, TRUE);
}

EX_SHAPE_API gConvertImage(
						  MsoBlipStore& blipStore,
						  MsoShapeOPT& opt,
						  CWpsImage* pImg,
						  BOOL fFrameImage,
						  IN MsoBlip* pExistBlip /*= NULL*/,//�����ǰת����pImg,�Ͳ���Ҫÿ�ζ������µ�blip��,����ǳ��˷�
						  OUT MsoBlip* pNewBlip /*= NULL*/
						  )
{
	ASSERT(pImg);
	SIZE imgSize;
	KDWBlip blip;
	if(pExistBlip && pExistBlip->Good())
	{
		blip = *pExistBlip;
		imgSize.cx = pImg->m_nDrawWidth;
		imgSize.cy = pImg->m_nDrawHeight;
	}
	else
	{
		blip = gAddWpsImage2BlipStore(blipStore, pImg, &imgSize);
	}
	ASSERT(blip.Good());
	if (blip.Good())
	{
		if(pNewBlip)
		{
			*pNewBlip = blip;
		}

		if(fFrameImage)//ͼƬ��
		{
			opt.AddPropFix(msopt_pib, blip);
			/*
			*	wps��"����" �� "ƽ��" ת��Ϊwordʱȥ��"�����ݺ��",�����Ķ�Ҫ"�����ݺ��". msopt_fLockAspectRatio(120)
			*  wps�� "ƽ��"��word���޷���ʾ
			*/
			BOOL fLockAspectRatio = !(pImg->m_ImgPara.nSetSize == IMG_SIZE_TYPE_FILL ||
				pImg->m_ImgPara.nSetSize == IMG_SIZE_TYPE_TITLE);
			opt.ForceAddPropBool(msopt_fLockAspectRatio, fLockAspectRatio);
			opt.AddPropFix(msopt_pictureSizeMode, pImg->m_ImgPara.nSetSize);
			
			// liupeng: ���ü�Ϊ����βü���Բ�βü�ʱ����ppt�Ĳü��кܴ�ͬ
			// ��������ȥ����
			/*
			*	����
			msopt_cropFromTop(256)
			msopt_cropFromBottom(257)
			msopt_cropFromLeft(258)
			msopt_cropFromRight(259)
			*/
			INT32 ncropFromTop = 0, ncropFromBottom = 0, ncropFromLeft = 0, ncropFromRight = 0;
			//wps"�����ݺ��",ת��Ϊwordʱ��Ҫ���м���
			if(pImg->m_ImgPara.nSetSize == IMG_SIZE_TYPE_LOCK_VERT_HORZ)
			{
				if((double)imgSize.cx / imgSize.cy < (double)pImg->m_nDrawWidth / pImg->m_nDrawHeight)
				{
					//�ײ�������
					ncropFromBottom += 0x10000 * 
						(1 - (double)pImg->m_nDrawHeight / (pImg->m_nDrawWidth * imgSize.cy / imgSize.cx));
				}
				else if((double)imgSize.cx / imgSize.cy > (double)pImg->m_nDrawWidth / pImg->m_nDrawHeight)
				{
					//�Ҳ�������
					ncropFromRight += 0x10000 * 
						(1 - (double)pImg->m_nDrawWidth / (pImg->m_nDrawHeight * imgSize.cx / imgSize.cy));
				}
				opt.AddPropFix(msopt_cropFromTop, ncropFromTop);
				opt.AddPropFix(msopt_cropFromBottom, ncropFromBottom);
				opt.AddPropFix(msopt_cropFromLeft, ncropFromLeft);
				opt.AddPropFix(msopt_cropFromRight, ncropFromRight);
			}
			
			
			/*
			* �Աȶ�pictureContrast(264)
			* wps�ĶԱȶȷ�Χ��-100��100��0Ϊȱʡֵ��word�ĶԱȶȷ�Χ��0%-100%��50%Ϊȱʡֵ
			*!!!��֪�����㹫ʽ
			*@@todo:��ô�Ѱٷֱ�ת��Ϊword�е�ֵ,δ�ҵ����㹫ʽ
			* �۲�word�Ľ����25% 0x8000; 50% 0x10000; 75% 0x20000; 100% 0x7fffffff
			*/
			int nWpsContrast = pImg->m_ImgColor.nContrast;
			nWpsContrast += 100;
			
			nWpsContrast /= 2;
			int nWordContrast = 0x7fffffff * nWpsContrast / 100;
			//context.m_opt.AddPropFix(msopt_pictureContrast, 127 << 16/*nWordContrast*/);
			
			/*
			*	���� ��pictureBrightness(265)
			*  wps�����ȷ�Χ��-100��100��0Ϊȱʡֵ��word�����ȷ�Χ��0%-100%��50%Ϊȱʡֵ
			*/
			int nWpsBrightness = pImg->m_ImgColor.nBrightness;
			nWpsBrightness += 100;
			nWpsBrightness /= 2;
			int nWordBrightness = 1 + 655 * (nWpsBrightness - 50);
			if(nWordBrightness != 1)
			{
				opt.AddPropFix(msopt_pictureBrightness, nWordBrightness);
			}
			
			/*
			*	�Ƿ�Ҷ�pictureGray(317)
			*/
			if(pImg->m_ImgColor.bGrayScale)
			{
				opt.AddPropBool(msopt_pictureGray, TRUE);
			}
			
			/*
			*	�ڰ���ʾpictureBiLevel(318)
			*/
			if(pImg->m_ImgColor.bMono)
			{
				opt.AddPropBool(msopt_pictureGray, TRUE);
				opt.AddPropBool(msopt_pictureBiLevel, TRUE);
			}
			
			/*
			*͸��ɫ msopt_pictureTransparent(263)
			*
			*/
			if(pImg->m_colorTran != WPS_IMG_NO_TRANSPARENT_COLOR)
			{
				opt.AddPropFix(msopt_pictureTransparent, pImg->m_colorTran);
			}
		}
		else//��ͼ���
		{
			opt.AddPropFix(msopt_fillBlip, blip);
			opt.AddPropBool(msopt_fFilled, TRUE);
			if(pImg->m_ImgPara.nSetSize == IMG_SIZE_TYPE_TITLE)
			{
				opt.AddPropFix(msopt_fillType, msofillTexture);
			}
			else
			{
				opt.AddPropFix(msopt_fillType, msofillPicture);
			}
//			if(pImg->m_ImgPara.nSetSize == IMG_SIZE_TYPE_LOCK_VERT_HORZ ||
//				pImg->m_ImgPara.nSetSize == IMG_SIZE_TYPE_ORIGN)
//			{
//				opt.AddPropFix(msopt_fillDztype, msodztypeFixedAspectEnlarge);
//				opt.AddPropFix(msopt_fillOriginX, 0xffff8001);
//				opt.AddPropFix(msopt_fillOriginY, 0xffff8001);
//				opt.AddPropFix(msopt_fillShapeOriginX, 0xffff8001);
//				opt.AddPropFix(msopt_fillShapeOriginY, 0xffff8001);
//			}
		}
	}

}
EX_SHAPE_API gConvertImage(
						  KWpsExport& docu,
						  KDWShapeOPT& opt,
						  CWpsImage* pImg,
						  BOOL fFrameImage)
{
	gConvertImage(docu.GetBlipStore(), opt, pImg, fFrameImage);
}
EX_SHAPE_API gCovertBackground(MsoShape& bgShape, MsoBlipStore& blipStore,
						CSlideBackground* psbg, CWpsImage* pImg,
						  IN MsoBlip* pExistBlip /*= NULL*/,//�����ǰת����pImg,�Ͳ���Ҫÿ�ζ������µ�blip��,����ǳ��˷�
						  OUT MsoBlip* pNewBlip /*= NULL*/
	)	
{
	if(psbg)
	{
		KDWShapeOPT opt;
		switch(psbg->m_nFillType)
		{
		case enBG_SOLIDFILL:
			gConvertSolidFill(opt, psbg->m_clrSolid);
			break;
		case enBG_SHADEDFILL:
			gConvertGradientFill(opt, psbg->m_ShadeCtrl.shadeDir, psbg->m_ShadeCtrl.shadeStyle,
				psbg->m_ShadeCtrl.shadeColor[0], psbg->m_ShadeCtrl.shadeColor[1]);
			break;
		case enBG_PATTERNEDFILL:
		case enBG_PICTUREFILL:
		case enBG_TEXTUREDFILL:
			gConvertImage(blipStore, opt, pImg, FALSE, pExistBlip, pNewBlip);
			break;
		}
		//	opt.ForceAddPropBool(msopt_fFilled, TRUE);
		//	opt.ForceAddPropBool(msopt_fLine, FALSE);
		bgShape.SetShapeType(msosptRectangle);
		bgShape.SetProperties(opt);
	}
}

//�������ñ�������
EX_SHAPE_API gSetBRCEX(
				COLORREF color,//
				int nWidth,//�߿� 0.1mm
				int nStyle,//����
				OUT KDWBrc& brc,
				OUT KDWBrc* pbrcRB/* = NULL*/,
				UINT dptSpace/* = 0*/,
				BOOL bPageBorder /*= FALSE*/
				)
{
	if(nWidth == -1)//wps������.����Ϊ:����WPS��������\WPSģ��\ҵ���\���ʵ�.wpt
	{
		nWidth = 0;
	}
	float fWidth = nWidth;
	BRCTYPE brcType;
	BOOL fNeedAdjustWidth = FALSE;
	switch(nStyle)
	{
	default:
		brcType = mso_brcSingle;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_NULL://����
		brcType = mso_brcNone;
		break;
	case PS_SOLID:
		brcType =  mso_brcSingle;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_DASH:
		brcType = mso_brcDashLarge;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_DOT:
		brcType = mso_brcDot;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_DASHDOT:
		brcType = mso_brcDotDash;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_DASHDOTDOT:
		brcType = mso_brcDotDotDash;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_INSIDEFRAME:
		brcType = mso_brcSingle;
		fNeedAdjustWidth = TRUE;
		break;
	case PS_DOUBLETHIN:
		brcType = mso_brcDouble;
		fWidth /= 2;
		break;
	case PS_DOUBLETHICK:
		brcType = mso_brcDouble;
		fWidth /= 2;
		break;
	case PS_THINTHICKTHIN:
		brcType = mso_brcThinThickThinSmall;
		break;
	case PS_THICKTHIN:
		brcType = mso_brcThinThickSmall;
		break;
	case PS_THINTHICK:
		brcType = mso_brcThickThinSmall;
		break;
	}

	if (brcType == mso_brcSingle && nWidth == 0)
		fWidth = 1.0;

	//�����߿�
	if(fNeedAdjustWidth)
	{
		if(fWidth >= 4 && fWidth <= 5.3)
			fWidth = 5.3f;
	}
	if(brcType != mso_brcNone)
	{
		//���ݹ۲��ۺϱȽ�,ҳ��߿�1/2.5 pt�����ȽϺ���,�����
		brc.put_Style(bPageBorder ? fWidth * 72 * 2.5 / 254 : fWidth * 72 * 8 / 254,
			brcType, dptSpace * 72 / 254);
		brc.put_Color(color);
	}
	else
	{
		brc.put_Delete();
	}
	if(pbrcRB)
	{
		*pbrcRB = brc;
		if(pbrcRB->brcType == mso_brcThinThickSmall)
			pbrcRB->brcType = mso_brcThickThinSmall;
		else if(pbrcRB->brcType == mso_brcThickThinSmall)
			pbrcRB->brcType = mso_brcThinThickSmall;
	}
}

EX_SHAPE_API gSetSHDEX(
					BOOL fHaveBackColor,
					KCOLORINDEX fillBackColor,
					BOOL fHaveForeColor,
					KCOLORINDEX fillForeColor,
					LONG lbHatch,
					OUT KDWShd& shdex)
{
	if(fHaveBackColor)
	{
		shdex.put_BackColor(fillBackColor);
		shdex.put_Pattern(mso_patAutomatic);
	}
	if(fHaveForeColor)
	{
		shdex.put_ForeColor(fillForeColor);
		switch(lbHatch)
		{
		case HS_HORIZONTAL:
			shdex.put_Pattern(mso_patHorizontal);
			break;
		case HS_VERTICAL:
			shdex.put_Pattern(mso_patVertical);
			break;
		case HS_FDIAGONAL:
			shdex.put_Pattern(mso_patForwardDiagonal);
			break;
		case HS_BDIAGONAL:
			shdex.put_Pattern(mso_patBackwardDiagonal);
			break;
		case HS_CROSS:
			shdex.put_Pattern(mso_patCross);
			break;
		case HS_DIAGCROSS:
			shdex.put_Pattern(mso_patDiagonalCross);
			break;
		}
	}
}


// -------------------------------------------------------------------------
//
//CWPSObj_Export
//
EX_SHAPE_API CWPSObj_Export::ConvertShape(CShape_Context& context)
{
}

// -------------------------------------------------------------------------
//
//CTFPBase_Export
//

EX_SHAPE_API CTFPBase_Export::ConvertFill(CShape_Context& context)
{
	if(m_nBkMode == TRANSPARENT)//͸��
	{
		if(m_logbrush.lbStyle == BS_HATCHED)//word�²��ܱ��ֳ�wps��ֻ�����Ʋ�����ɫ��Ч��
		{
#if defined(SUPPORT_MSOSYSCOLOR)
			ConvertHatchedBrushFill(context.GetBlipStore(), context.m_opt,
				m_logbrush.lbHatch, m_logbrush.lbColor, 
				MSOSYSCOLOR(msosyscolorWindow));//ʹ��ϵͳ����ɫ
#else
			//liupeng: ��ʾ�������͸���Ļ�����Ӧ���ñ���ɫ
#ifdef WPP_ONLY
			ConvertHatchedBrushFill(context.GetBlipStore(), context.m_opt,
				m_logbrush.lbHatch, m_logbrush.lbColor, 
				0xf8000000);
#else
			ConvertHatchedBrushFill(context.GetBlipStore(), context.m_opt,
				m_logbrush.lbHatch, m_logbrush.lbColor, 
				GetSysColor(COLOR_WINDOW));
#endif
#endif
			context.m_opt.AddPropFix(msopt_fillBackOpacity, 0);

		}
		else
		{
			context.m_opt.AddPropBool(msopt_fFilled, FALSE);
		}
	}
	else if(m_nBkMode == OPAQUE)//��͸��
	{
		if(m_logbrush.lbStyle == BS_HATCHED)
		{
			ConvertHatchedBrushFill(context.GetBlipStore(), context.m_opt,
				m_logbrush.lbHatch, m_logbrush.lbColor, m_bkColor);
		}
		else
		{
			gConvertSolidFill(context.m_opt, m_logbrush.lbColor);
		}
		context.m_opt.AddPropFix(msopt_fillOpacity, (0xffff * (100 - m_nTransparence) / 100));
		
	}
	else if(m_nBkMode == GRADIENT)//�������
	{
		gConvertGradientFill(context.m_opt, m_nColorDirection, m_nColorDistortion, 
			m_bkColor, m_logbrush.lbColor);
	}
	else if(m_nBkMode == INVERT)//����,word���ܱ���
	{
		//lijun ���ӱ������ķ���ģʽ����
		context.m_opt.ForceAddPropFix(ksextopt_BkMode, msoINVERT);
	}
	else
	{
		ASSERT(FALSE);
	}
}

EX_SHAPE_API CTFPBase_Export::ConvertShape(CShape_Context& context)
{
	CALL_BASE_CONVERT();
	if((context.m_dwFlag & WPSRW_NOCONVERTFILL) == 0)
		ConvertFill(context);
}

// -------------------------------------------------------------------------
//
//CFPBase_Export
//
EX_SHAPE_API CFPBase_Export::ConvertShape(CShape_Context& context)
{
	CALL_BASE_CONVERT();
	/*
	 *msopt_lineColor(448)
	 *
	 */
	context.m_opt.ForceAddPropFix(msopt_lineColor, gConvertObjColor(m_LPenColor));
	/*
	 *msopt_lineDashing(462) & msopt_lineStyle(461)
	 *word�а���������ʵ�ֿ���,��wps�����һ��,��CFPBase::m_uLPenStyle������
	 *
0 PS_SOLID(��ʵ��)               MSOLINEDASHING::msolineSolid?               
1 PS_DASH(����)                                  msolineDashSys           
2 PS_DOT(����)                                   msolineDotSys            
3 PS_DASHDOT(�㻮��)                             msolineDashDotSys        
4 PS_DASHDOTDOT(˫�㻮��)                        msolineDashDotDotSys     
5 PS_NULL(����)                                 (�޶�Ӧ)                 
6 PS_INSIDEFRAME(ʵ��)             MSOLINESTYLE::msolineSimple?            
7 PS_DOUBLETHIN(ϸ˫��)                          msolineDouble
8 PS_DOUBLETHICK(��˫��)                         (�޶�Ӧ)
9 PS_THICKTHIN(��������)                         msolineThickThin
10 PS_THINTHICK(��������)                        msolineThinThick
11 PS_THINTHICKTHIN(��������)                    msolineTriple
     */

	//��ʵ
	int lineDasing = msolineSolid;
	if(m_uLPenStyle <= PS_DASHDOTDOT)
	{
		lineDasing = m_uLPenStyle;
	}
	if(lineDasing != msolineSolid)
	{
		context.m_opt.AddPropFix(msopt_lineDashing, lineDasing);
	}
	//����
	int lineStyle = msolineSimple;
	if(m_uLPenStyle >= PS_NULL)
	{
		switch(m_uLPenStyle)
		{
		default:
			//lijun ���ӿ�������
			//context.m_opt.ForceAddPropFix(ksextopt_lineStyle2, msolineNull);
			break;
		case PS_NULL:			
			//lijun ��������ж���Ŀ�������ȫ��ת������������ɫ
			//context.m_opt.ForceAddPropBool(msopt_fLine, FALSE);
			break;
		case PS_DOUBLETHIN:		
			lineStyle = msolineDouble;
			break;		
		case PS_DOUBLETHICK:
			lineStyle = msolineThickThin;
			//lijun ���Ӵ�˫������
			context.m_opt.ForceAddPropFix(ksextopt_lineStyle2, msolineThickThick);
			break;
		case PS_THICKTHIN:
			lineStyle = msolineThickThin;
			break;
		case PS_THINTHICK:
			lineStyle = msolineThinThick;
			break;
		case PS_THINTHICKTHIN:
			lineStyle = msolineTriple;
			break;
		}
	}
	if(lineStyle != msolineSimple)
	{
		context.m_opt.AddPropFix(msopt_lineStyle, lineStyle);
	}
	context.m_opt.ForceAddPropBool(msopt_fLine, m_uLPenStyle != PS_NULL);

	/*
	 * �߿� msopt_lineWidth(459)
	 * m_uLPenSize
	 * ����������,WPS�����õ��߿��ǹ̶���,�ҽ�С,ת��Ϊword������������
	 */
	int lineWidth = m_uLPenSize * 3600;
	if(lineWidth)
	{
		context.m_opt.AddPropFix(msopt_lineWidth, lineWidth);
	}

	/*
	 *��Ӱ	msopt_shadowOffsetX(517),msopt_shadowOffsetY(518)
	 * msopt_shadowColor(513), msopt_shadowOpacity(516)
	 */
	//20041227 royhoo ������Ӱת���㷨�����⣬�����������Ӱ�޷�ת����ȥ
//	if(m_shadowPnt.x && m_shadowPnt.y)//����Ӱ
	if(m_shadowPnt.x || m_shadowPnt.y)//����Ӱ
	{
		context.m_opt.AddPropBool(msopt_fShadow, TRUE);
		context.m_opt.AddPropFix(msopt_shadowOffsetX, 3600 * m_shadowPnt.x);
		context.m_opt.AddPropFix(msopt_shadowOffsetY, 3600 * m_shadowPnt.y);
		context.m_opt.AddPropFix(msopt_shadowColor, gConvertObjColor(m_shadowColor));
		if(m_shadowStyle == SW_FOG)
			context.m_opt.AddPropFix(msopt_shadowOpacity, 0x8000);
	}
	/*
	 *	�Ƿ��ӡ msopt_fPrint(959)
	 */
	if(m_bNoPrint)
	{
		context.m_opt.AddPropBool(msopt_fPrint, FALSE);
	}
	if (GetObjDispStyle())
		context.m_opt.AddPropBool(msopt_fBehindDocument, GetObjDispStyle());
	/*
	 *	�������� msopt_fLockAdjustHandles
	 */
//	if(m_bLock)
//	{
//		context.m_opt.AddPropBool(msopt_fLockVertices, TRUE);
//	}
	

}

// -------------------------------------------------------------------------
//
//CPTObj
//
EX_SHAPE_API CPTObj_Export::ConvertShape(CShape_Context& context)
{
	CALL_BASE_CONVERT();	

	/*
	 *	��ת�Ƕ� msopt_Rotation(4)
	 *  
	 */
	INT32 nAngle = m_theta / 10;
	ASSERT(nAngle > -360 && nAngle < 360);
	if (nAngle)
	{
		if(nAngle < 0)
			nAngle = -nAngle;
		else
			nAngle = 360 - nAngle;
		context.m_opt.AddPropFix(msopt_Rotation, nAngle << 16);
	}
	/*
	 * ��ͷ��״msopt_lineStartArrowhead(464) & msopt_lineEndArrowhead(465)
	 * ����    msopt_lineStartArrowWidth(466) & msopt_lineEndArrowWidth(468)
	 * ����    msopt_lineStartArrowLength(467) & msopt_lineStartArrowLength(469)
	 *
	 * word�������Ƿ����,wps������m_nEndShape[2]��
	 */
	int rglineArrowhead[2];
	int rglineArrowWidth[2];
	int rglineArrowLength[2];
	for(int i = 0; i < 2; i++)
	{
		rglineArrowhead[i] = msolineNoEnd;
		rglineArrowWidth[i] = msolineMediumWidthArrow;
		rglineArrowLength[i] = msolineMediumLenArrow;
		int endShape = m_nEndShape[i];
//	enum { es_null = -1, es_none,
//		   sa_1, sa_2, sa_3, na_1, na_2, na_3, 
//		   sc_1, sc_2, sc_3, nc_1, nc_2, nc_3,
//		   sr_1, sr_2, sr_3, nr_1, nr_2, nr_3, ib_1, ib_2, ib_3
//	};									//	�˵�����
		if(endShape >= sa_1 && endShape <= sa_3)//�����ͷ
		{
			rglineArrowhead[i] = msolineArrowEnd;
			if(endShape == sa_2)
			{
				rglineArrowLength[i] = msolineShortArrow;//�̵�
			}
			if(endShape == sa_3)
			{
				rglineArrowWidth[i] = msolineNarrowArrow;//�ݵ�
			}
		}
		else if(endShape >= na_1 && endShape <= na_3)//���ż�ͷ
		{
			rglineArrowhead[i] = msolineArrowOpenEnd;
			if(endShape == na_2)
			{
				rglineArrowLength[i] = msolineShortArrow;//�̵�
			}
			if(endShape == na_3)
			{
				rglineArrowWidth[i] = msolineNarrowArrow;//�ݵ�
			}
		}
		else if(endShape >= sc_1 && endShape <= sc_3)//��Բʵ��
		{
			rglineArrowhead[i] = msolineArrowOvalEnd;
			rglineArrowWidth[i] = msolineNarrowArrow + endShape - sc_1;//��С����
			rglineArrowLength[i] = msolineShortArrow + endShape - sc_1;
		}
		else if(endShape >= nc_1 && endShape <= nc_3)//��Բ����,word���޶�Ӧ,ת������Բʵ��
		{
			rglineArrowhead[i] = msolineArrowOvalEnd;
			rglineArrowWidth[i] = msolineNarrowArrow + endShape - nc_1;//��С����
			rglineArrowLength[i] = msolineShortArrow + endShape - nc_1;
		}
		else if(endShape >= sr_1 && endShape <= sr_3)//����ʵ��,word���޶�Ӧ,ת��������
		{
			rglineArrowhead[i] = msolineArrowDiamondEnd;
			rglineArrowWidth[i] = msolineNarrowArrow + endShape - sr_1;//��С����
			rglineArrowLength[i] = msolineShortArrow + endShape - sr_1;
		}
		else if(endShape >= nr_1 && endShape <= nr_3)//���ο���,word���޶�Ӧ,ת��������
		{
			rglineArrowhead[i] = msolineArrowDiamondEnd;
			rglineArrowWidth[i] = msolineNarrowArrow + endShape - nr_1;//��С����
			rglineArrowLength[i] = msolineShortArrow + endShape - nr_1;
		}
		else if(endShape >= ib_1 && endShape <= ib_3)//����,word���޶�Ӧ,ת��������
		{
			rglineArrowhead[i] = msolineArrowDiamondEnd;
			rglineArrowWidth[i] = msolineNarrowArrow + endShape - ib_1;//���ݵ���
			rglineArrowLength[i] = msolineShortArrow;//�̵�,��������һ��
		}
	}
	//��״
	if(rglineArrowhead[0] != msolineNoEnd)
	{
		context.m_opt.AddPropFix(msopt_lineStartArrowhead, rglineArrowhead[0]);
	}
	if(rglineArrowhead[1] != msolineNoEnd)
	{
		context.m_opt.AddPropFix(msopt_lineEndArrowhead, rglineArrowhead[1]);
	}
	//����
	if(rglineArrowWidth[0] != msolineMediumWidthArrow)
	{
		context.m_opt.AddPropFix(msopt_lineStartArrowWidth, rglineArrowWidth[0]);
	}
	if(rglineArrowWidth[1] != msolineMediumWidthArrow)
	{
		context.m_opt.AddPropFix(msopt_lineEndArrowWidth, rglineArrowWidth[1]);
	}
	//����
	if(rglineArrowLength[0] != msolineMediumLenArrow)
	{
		context.m_opt.AddPropFix(msopt_lineStartArrowLength, rglineArrowLength[0]);
	}
	if(rglineArrowLength[1] != msolineMediumLenArrow)
	{
		context.m_opt.AddPropFix(msopt_lineEndArrowLength, rglineArrowLength[1]);
	}

}

// -------------------------------------------------------------------------
//
//CFrameObj_Export
//
EX_SHAPE_API CFrameObj_Export::ConvertShape(CShape_Context& context)
{
	if(m_pImg)
		context.m_dwFlag |= WPSRW_NOCONVERTFILL;//��ͼƬ,��ת�����
	CALL_BASE_CONVERT();

#ifdef WPP_ONLY
	if (context.GetPlaceHolderID() > 0 && CheckObjType() == FRAMEImg)
	{
		// liupeng: �յİ�ʽ����
		if (m_pImg)
		{
			if (!m_pImg->m_pSource)
				return;
		}
	}
#endif
	/*
	 *�ⲿ�߾�
	 * msopt_dxWrapDistLeft(900),msopt_dyWrapDistTop(901),
	 * msopt_dxWrapDistRight(902),msopt_dyWrapDistBottom(903)
	 *	int			m_mgOutsideType;//	�������������
	 *	CRect 		m_MarginOutside;//	��������ճߴ�
	 */
	context.m_opt.AddPropFix(msopt_dxWrapDistLeft, 3600 * m_MarginOutside.left);
	context.m_opt.AddPropFix(msopt_dyWrapDistTop, 3600 * m_MarginOutside.top);
	context.m_opt.AddPropFix(msopt_dxWrapDistRight, 3600 * m_MarginOutside.right);
	context.m_opt.AddPropFix(msopt_dyWrapDistBottom, 3600 * m_MarginOutside.bottom);
	
	if (m_pImg)
	{
		::gConvertImage(context.GetBlipStore(), context.m_opt, m_pImg, context.m_dwFlag & WPSRW_FRAMEIMAGE);
		/*
		#define		NORMAL	 	0
		#define		VERTFLIP 	1
		#define		HORZFLIP	2
		#define		VERTHORZ    3
		#define		ROTATE90    4	��ת90
		#define		LEFTFLIP    5	ˮƽ��ת����ת90
		#define		RROTATE90   6	��ת90
		#define		RIGHTFLIP   7	ˮƽ��ת����ת90
		
		*/
		//lijun ת��wps��ͼƬ��ľ�����ת
		if (context.m_dwFlag & WPSRW_FRAMEIMAGE)
		{
			int nAngle = 90;
			switch(m_pImg->m_ImgPara.nDrawMode)
			{
			case 0:
				break;
			case 1:				  
				context.m_shape.SetFlipV(TRUE);
				break;				  
			case 2:
				context.m_shape.SetFlipH(TRUE);
				break;
			case 3:
				context.m_shape.SetFlipV(TRUE);
				context.m_shape.SetFlipH(TRUE);
				break;
			case 4:
				nAngle = 360 - nAngle;
				context.m_opt.AddPropFix(msopt_Rotation, nAngle << 16);
				break;
			case 5:
				context.m_shape.SetFlipV(TRUE);
				nAngle = 360 - nAngle;
				context.m_opt.AddPropFix(msopt_Rotation, nAngle << 16);
				break;
			case 6:
				context.m_opt.AddPropFix(msopt_Rotation, nAngle << 16);
				break;
			case 7:
				context.m_shape.SetFlipV(TRUE);					
				context.m_opt.AddPropFix(msopt_Rotation, nAngle << 16);
				break;
			default:
				break;
			}
		}
	}
}


//
//
BYTE _g_blipHatchedBrushDIBBuffer[6][80] = 
{
	//HS_HORIZONTAL
	{
		0x28, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
		0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00,
		0x89, 0x0B, 0x00, 0x00, 0x89, 0x0B, 0x00, 0x00,
		0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00,
		
		0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
		0xFF, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00,
		0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0xFF, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00,
		0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	},
	//HS_VERTICAL
	{
		0x28, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
		0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00,
		0x89, 0x0B, 0x00, 0x00, 0x89, 0x0B, 0x00, 0x00,
		0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00,
		
		0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x77, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00,
		0x77, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00,
		0x77, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00,
		0x77, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00,
	},
	//HS_FDIAGONAL
	{
		0x28, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
		0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00,
		0x89, 0x0B, 0x00, 0x00, 0x89, 0x0B, 0x00, 0x00,
		0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00,
		
		0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
		0xEE, 0x00, 0x00, 0x00, 0xDD, 0x00, 0x00, 0x00,
		0xBB, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00,
		0xEE, 0x00, 0x00, 0x00, 0xDD, 0x00, 0x00, 0x00,
		0xBB, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00,
	},
	//HS_BDIAGONAL
	{
		0x28, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
		0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00,
		0x89, 0x0B, 0x00, 0x00, 0x89, 0x0B, 0x00, 0x00,
		0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00,
		
		0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x77, 0x00, 0x00, 0x00, 0xBB, 0x00, 0x00, 0x00,
		0xDD, 0x00, 0x00, 0x00, 0xEE, 0x00, 0x00, 0x00,
		0x77, 0x00, 0x00, 0x00, 0xBB, 0x00, 0x00, 0x00,
		0xDD, 0x00, 0x00, 0x00, 0xEE, 0x00, 0x00, 0x00,
	},
	//HS_CROSS
	{
		0x28, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
		0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00,
		0x89, 0x0B, 0x00, 0x00, 0x89, 0x0B, 0x00, 0x00,
		0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00,
		
		0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x7F, 0x00, 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00,
		0x7F, 0x00, 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00,
		0x7F, 0x00, 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00,
		0x7F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	},
	//HS_DIAGCROSS
	{
		0x28, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
		0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00,
		0x89, 0x0B, 0x00, 0x00, 0x89, 0x0B, 0x00, 0x00,
		0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00,

		0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,
		0xFE, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00,
		0xBB, 0x00, 0x00, 0x00, 0xD7, 0x00, 0x00, 0x00,
		0xEF, 0x00, 0x00, 0x00, 0xD7, 0x00, 0x00, 0x00,
		0xBB, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00,
	}
};

//LPCWSTR