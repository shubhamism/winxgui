/* -------------------------------------------------------------------------
//	�ļ���		��	ptpoly.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-25 12:09:31
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ptobj.h"
#include "al_beziercurve.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CPolyObj, CPTObj, 0xA0 | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------
// ---> �Ӷ����б����㺬�п��Ƶ�ĵ����飬�����ȷ�����㹻���ڴ��
HRESULT CalcFromNoCtlPointArray(CPoint* pSrc, int nCount)
{
	if (!pSrc)
		return E_INVALIDARG;
	if (!::AfxIsValidAddress(pSrc, sizeof(CPoint) * (3 * nCount - 2)))
	{
		ASSERT(!"���ȷ���ó�ʼ�ڴ�");
		return E_OUTOFMEMORY;
	}
	
	long ret = al_calcbezier2((pt*)pSrc, nCount);	// �����������ߵĿ��Ƶ�
	
	return S_OK;
}

// -------------------------------------------------------------------------
// ---> ��һ��List���������ĵ����ݿ�
HRESULT MakePointArray(const KPointList* pList, CPoint* pArray, ULONG uCount)
{
	if (!::AfxIsValidAddress(pArray, sizeof(CPoint) * uCount))
	{
		ASSERT(!"���ȷ���ó�ʼ�ڴ�");
		return E_OUTOFMEMORY;
	}
	if (!pList)
		return E_INVALIDARG;
	
	int nCount = pList->GetCount();
	ASSERT(nCount == uCount);
	
	POSITION pos = pList->GetHeadPosition();
	
	for (int i = 0; i < uCount && i < nCount; i ++)
		pArray[i] = pList->GetNext(pos);
	
	return S_OK;
}

// -------------------------------------------------------------------------
// ---> ��ȡһ�����������Ƶ�ĵ�List�����ڴ�Ϊ�Ͱ汾�ļ�
HRESULT MakeNoCtlPointArray(const KPointList* pSrcPoint, 
							const KFlagList* pSrcFlag, 
							KPointList* pDstList)
{
	if (!pSrcPoint || !pSrcFlag || !pDstList)
		return E_INVALIDARG;
	
	int nPtCount = pSrcPoint->GetCount();
	
	if (pSrcFlag->GetCount() != nPtCount)
	{
		ASSERT(!"�������б�Ӧ�ú�����ͬ������Ԫ��");
		return E_FAIL;
	}
	
	pDstList->RemoveAll();
	if (nPtCount)
		pDstList->AddTail(pSrcPoint->GetHead());
	
	for (int nIdx = 1; nIdx < nPtCount; nIdx ++)
	{
		if (pSrcFlag->GetAt(pSrcFlag->FindIndex(nIdx)) == PT_BEZIERTO)
		{
			if (nIdx + 2 < nPtCount)
				nIdx += 2;
			else
			{
				ASSERT(!"�����ƺ�����(BEZIERTOӦ��������һ���)");
				break;
			}
		}
		pDstList->AddTail(pSrcPoint->GetAt(pSrcPoint->FindIndex(nIdx)));
	}
	
	return S_OK;
}

// -------------------------------------------------------------------------
// ---> ���޿��Ƶ������ת��Ϊ�����Ƶ�����ݣ����ڶ��Ͱ汾�ļ�����������
HRESULT MakeFromNoCtlPointArray(const KPointList* pSrcList,
								KPointList* pDestPointList,
								KFlagList* pDestFlagList)
{
	if (!pSrcList || !pDestPointList)
		return E_INVALIDARG;
	
	int nCount = pSrcList->GetCount(), i;
	BYTE byFlag = 0;
	if (0 == nCount)
		return S_OK;
	
	CPoint* pPointArray = NULL;
	try
	{
		pPointArray = new CPoint[3 * nCount - 2];
		::memset(pPointArray, 0, sizeof(CPoint) * (3 * nCount - 2));
	}
	catch(...)
	{
		ASSERT(!"�����ڴ����(MakeFromNoCtlPointArray)");
		return E_OUTOFMEMORY;
	}
	
	HRESULT hr = MakePointArray(pSrcList, pPointArray, nCount);
	if (FAILED(hr))
		goto lzExit;
	
	pDestPointList->RemoveAll();
	pDestFlagList->RemoveAll();
	
	if (nCount <= 2)	// ��������Թ������߾͵�������
	{
		for (i = 0; i < nCount; i ++)
		{
			pDestPointList->AddTail(pPointArray[i]);
			
			if (0 == i)
				byFlag = PT_MOVETO;
			else
				byFlag = PT_LINETO;
			
			pDestFlagList->AddTail(byFlag);
		}
	}
	else
	{
		hr = CalcFromNoCtlPointArray(pPointArray, nCount);
		if (FAILED(hr))
			goto lzExit;
		
		for (i = 0; i < 3 * nCount - 2; i ++)
		{
			pDestPointList->AddTail(pPointArray[i]);
			
			if (0 == i)
				byFlag = PT_MOVETO;
			//			else if (3 * nCount - 3 == i)
			//				byFlag = m_nEndStyle == 1 ? PT_BEZIERTO | PT_CLOSEFIGURE : PT_BEZIERTO;
			else
				byFlag = PT_BEZIERTO;
			
			pDestFlagList->AddTail(byFlag);
		}
	}
lzExit:
	if (pPointArray)
		delete[] pPointArray;
	return S_OK;
}

// -------------------------------------------------------------------------

void CPolyObj::Serialize_97(KSArchive& ar)
{
	CPTObj::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		WORD    wTemp;
		__int16 nTemp;
		ar >> wTemp;	int nNum = wTemp;
		CPoint pnt;
		BYTE byFlag = 0;
		for (WORD i=0; i < nNum; i++)
		{
			ar >> nTemp;	pnt.x = nTemp;
			ar >> nTemp;	pnt.y = nTemp;
			m_PointList.AddTail(pnt);

			if (0 == i)
				byFlag = PT_MOVETO;
			else
				byFlag = PT_LINETO;

			m_FlagsList.AddTail(byFlag);
		}
		m_nPolyobjShape = polyLine;
	}
	CWPSObj::SerializeObjType(ar);
}

void CPolyObj::Serialize_98(KSArchive& ar)
{
	CPTObj::Serialize_98(ar);

	if (ar.IsStoring())
	{
		ar << m_nPolyobjShape;
		ar << m_PointList.GetCount();
		POSITION pos = m_PointList.GetHeadPosition();
		CPoint point;
		while (pos != NULL)
		{
			point = m_PointList.GetNext(pos);
			ar << point;
		}
	}
	else
	{
		ar >> m_nPolyobjShape;
		int nNum;
		ar >> nNum;
		CPoint pnt;
		BYTE byFlag = 0;
		for (WORD i = 0; i < nNum; i ++)
		{
			ar >> pnt;
			m_PointList.AddTail(pnt);

			if (0 == i)
				byFlag = PT_MOVETO;
			else
				byFlag = PT_LINETO;

			m_FlagsList.AddTail(byFlag);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

HRESULT MakeNoCtlPointArray(const KPointList* pSrcPoint, 
							const KFlagList* pSrcFlag, 
							KPointList* pDstList);
HRESULT MakeFromNoCtlPointArray(const KPointList* pSrcList,
								KPointList* pDestPointList,
								KFlagList* pDestFlagList);

void CPolyObj::Serialize_01(KSArchive& ar)
{
	if (g_fCompoundFile)	// �ļ����°汾
	{
		Serialize_02(ar);
		return;
	}

	CPTObj::Serialize_01(ar);
	if (ar.IsStoring())	// �ɰ汾����������ȫ���������ߣ����뿼��Flag
	{
		KPointList list;
		KPointList* pList = &m_PointList;
		if (m_nPolyobjShape == bezierLine)
		{
			::MakeNoCtlPointArray(&m_PointList, &m_FlagsList, &list);	// ����һ���������Ƶ�ĵ��б�
			pList = &list;
		}
		if (pList)
		{
			ar << m_nPolyobjShape;
			ar << pList->GetCount();

			POSITION pos = pList->GetHeadPosition();
			CPoint point;
			while (pos != NULL)
				ar << pList->GetNext(pos);;
		}
		else
		{
			ASSERT(!"�洢�������ݳ���(pList == NULL)");
		}
	}
	else
	{
		int nNum = 0, i = 0;
		CPoint* point = NULL;
		CPoint pnt;
		BYTE byFlag = 0;

		ar >> m_nPolyobjShape;
		ar >> nNum;
		for (i = 0; i < nNum; i ++)
		{
			ar >> pnt;
			m_PointList.AddTail(pnt);
		}
		if (bezierLine == m_nPolyobjShape && nNum < 100)
			::MakeFromNoCtlPointArray(&m_PointList, &m_PointList, &m_FlagsList);
		else// if (polyLine == m_nPolyobjShape)
		{
			m_nPolyobjShape = polyLine;
			byFlag = PT_MOVETO;
			m_FlagsList.AddTail(byFlag);

			for (i = 0; i < m_PointList.GetCount() - 1; i ++)
			{
				byFlag = PT_LINETO;
				m_FlagsList.AddTail(byFlag);
			}
		}
	}

	CWPSObj::SerializeObjType(ar);
}

// �жϸ�ͼ���Ƿ��жϿ�
BOOL HasMultiplePoly(const KFlagList* pList);
BOOL IsBlend(const KFlagList* pList);	// ����ǻ�������߲���������
// -------------------------------------------------------------------------
// ��02�����޸������ߵĴ��̸�ʽ��ʹ֮����PolyDraw��Ҫ�ĸ�ʽ
void CPolyObj::Serialize_02(CArchive& ar)	
{
	CPTObj::Serialize_01(ar);
	
	if (ar.IsStoring())
	{
		ar << m_nPolyobjShape;
		int nCount = m_PointList.GetCount();
		ar << nCount;
		POSITION pos = m_PointList.GetHeadPosition();
		CPoint point;
		BYTE byFlag = 0;
		while (pos != NULL)
		{
			point = m_PointList.GetNext(pos);
			ar << point;
		}

		int nFlagCount = 0;
		pos = m_FlagsList.GetHeadPosition();
		while (nFlagCount != nCount)
		{
			if (pos)
				byFlag = m_FlagsList.GetNext(pos);
			else
				byFlag = PT_LINETO;
			ar << byFlag;
			nFlagCount++;
		}
	}
	else
	{
		int nNum = 0, i = 0;

		ar >> m_nPolyobjShape;
		ar >> nNum;

		CPoint pt;
		for (i = 0; i < nNum; i ++)
		{
			ar >> pt;
			m_PointList.AddTail(pt);
		}
		BYTE byFlag = 0;
		for (i = 0; i < nNum; i ++)
		{
			ar >> byFlag;
			m_FlagsList.AddTail(byFlag);
		}
		
		//m_bCanBeEdit = !HasMultiplePoly(&m_FlagsList) && !IsBlend(&m_FlagsList);
	}

	CWPSObj::SerializeObjType(ar);
}
