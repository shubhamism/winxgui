/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wppdoc.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 15:49:48
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_WPPDOC_H__
#define __EX_WPPDOC_H__

//class CWPPDocContext;
//class CWPPDocExport;
//class CWPPSlideBaseContext;
//class CWPPSlideBaseExport;
//class CWPPMasterContext;
//class CWPPMasterExport;
//class CWPPSlideContext;
//class CWPPSlideExport;

#include <pres/wppdoc.h>
#include <pres/wppslide.h>
#include <pres/wppframe.h>
#include <core/style_text.h>
#include <core/stylesheet_text.h>
#include <export/export.h>
#include <core/ctrlcodetool.h>
#include <core/autonum_atom.h>

#ifndef __KFC_IO_ARCHIVE_H__
#include "kfc/io/archive.h"
#endif

#ifndef __KSO_IO_CONTENTHANDLER_H__
#include <kso/io/contenthandler.h>
#endif

#ifndef __KSO_IO_SCHEMA_H__
#include <kso/io/schema.h>
#endif

#ifndef __KSO_IO_V6_STD_SCHEMA_OFFICE_H__
#include "kso/io/v6/std/schema_office.h"
#endif


#ifndef __KFC_COMPRESSION_ZLIB_H__
#include <kfc/compression/zlib.h>
#endif

#ifndef __KFC_ALLOCATER_KERNDATA_H__
#include "kfc/allocater/kerndata.h"
#endif

//
#ifndef __IOACCEPTOR_H__
#include "ioacceptor/ioacceptor.h"
#endif

#ifndef __IOHEADER_IOHEADER_H__
#include "ioheader/ioheader.h"
#endif

#ifndef __MSO_IO_BASIC_LOCKBUFFER_H__
#include "mso/io/basic/lockbuffer.h"
#endif

#ifndef __MSO_IO_BASIC_AUTOFREE_H__
#include "mso/io/basic/autofree.h"
#endif

#ifndef __STL_ALGORITHM_H__
#include <stl/algorithm.h>
#endif

#ifndef __STL_HASH_SET_H__
#include <stl/hash_set.h>
#endif

#ifndef __MSO_IO_POWERPOINT_WRITER_H__
#include "mso/io/powerpoint/writer.h"
#endif

#ifndef __PPTFMT_PPTHELP_H__
#include "pptfmt/ppthelp.h"
#endif

#ifndef __STL_LIST_H__
#include <stl/list.h>
#endif

/*
 *	document
 */
class KPPTFontCollectionEx : public KPPTFontCollection
{
public:
	//����-1��ʾ������
	int GetFontIndex(LPCTSTR pszFontName) const
	{
		USES_CONVERSION;
		for(int i = 0; i < m_FontEntitys.size(); i++)
		{
			if(_tcsicmp(W2CT(m_FontEntitys[i]->lfFaceName), pszFontName) == 0)
				return i;
		}
		return -1;
	}
	int GetFontConnectionSize() const
	{
		return m_FontEntitys.size();
	}
};
class KPPTClientTextBoxEx : public KPPTClientTextBox
{
public:
	int GetNumFmtsSize() const
	{
		return m_NumFmts.size();
	}
	void AddNumTypeNoToCf(int nLast, int iNo)
	{
		for(int i = m_TextList.size() - 1; nLast > 0; i--, nLast--)
		{
			m_TextList[i].pStyle->SetNumTypeNo(iNo);
		}
	}
};
class KWpsExport;
class CWPPSlideExport;
class KPPTSlide;
class CShape_Context;

class StyleAttrCacheItem
{
public:
	StyleAttrCacheItem(){}
	~StyleAttrCacheItem(){}
	PPT_TextType	textType;
	int				nLevel;
	CObList			m_List;
	int				m_nPlaceHolderID;
};

class CWPPDocContext
{
public:
	KWpsExport m_wpsExport;//Ϊ����ʹ��wps��ת�����롣��������������
	KPPTDocument& m_pptDocument;
	MsoAutoFreeAlloc& m_autoAlloc;
	CWPPDoc& m_wppDocument;//ǰ��ü�const...
	//��¼�Թ�sildes����
	KPPTSlide* m_pPptMainMaster;
	KPPTSlide* m_pPptTitleMaster;

	typedef struct {
		INT			nSoundID;
		ks_string   strFile;
		INT			nRefID;
		int			nBuildid;
	}SoundItem;

	typedef struct {
		INT					nSlideID;
		KPPTExHyperlink*	pHyper;
	}DelayHyper;
	typedef vector<DelayHyper> DelayHyperColl;
	typedef vector<SoundItem> SoundCollect;
	typedef SoundCollect::iterator SoundIt;
	typedef map<CWPPSlideExport*, KPPTSlide*> SlideMap;
	typedef SlideMap::iterator		SlideMapIt;
	typedef list<StyleAttrCacheItem*>	StyleSheetAttrCache;

	StyleSheetAttrCache			m_AttrCache;

	SoundCollect	m_Sounds;
	INT				m_nLastSoundRef;
	DelayHyperColl	m_DelayHypers;
	SlideMap		m_SlideMap;

	typedef map<CWpsImage*, MsoBlip> ImgBlipMap;
	ImgBlipMap m_ImgBlipMap;

public:
	CWPPDocContext(KPPTDocument& pptDocument, MsoAutoFreeAlloc& autoAlloc, CWPPDoc& pWppDocument) :
		m_wpsExport(NULL),
		m_pptDocument(pptDocument), m_autoAlloc(autoAlloc), m_wppDocument(pWppDocument),
		m_pPptMainMaster(NULL), m_pPptTitleMaster(NULL),m_nLastSoundRef(1)
	{
	}
	~CWPPDocContext();
	
	KWpsExport& GetWpsExport()
	{
		return m_wpsExport;
	}
	KPPTDocument& GetPptDocument()
	{
		return m_pptDocument;
	}
	MsoAutoFreeAlloc& GetAutoFreeAlloc()
	{
		return m_autoAlloc;
	}
	CWPPDoc& GetWppDocument()
	{
		return m_wppDocument;
	}
	void SetPptMaster(KPPTSlide* pValue, BOOL fMainMaster)
	{
		KPPTSlide*& pBeSet = fMainMaster ? m_pPptMainMaster : m_pPptTitleMaster;
		ASSERT(pBeSet == NULL);
		pBeSet = pValue;
	}
	KPPTSlide* GetPptMaster(BOOL fMainMaster)
	{
		KPPTSlide* pRet = fMainMaster ? m_pPptMainMaster : m_pPptTitleMaster;
		ASSERT(pRet);
		return pRet;
	}
	STDMETHODIMP AddFont(OUT UINT16& fontIndex, LPCTSTR pszFontName, UINT8 lfCharSet = 0);
	STDMETHODIMP AddSound(IN INT nSoundid, IN BSTR strFileName, OUT INT& nRefid);
	STDMETHODIMP AddHyperLink(OUT UINT& nLinkID,
								IN CString* strFriendlyName = NULL, 
								IN CString* strLocation = NULL, 
								IN CString* strSubAddress = NULL);
	STDMETHODIMP AddHyperLinkDelay(OUT UINT& nLinkID, INT nSlideID);
	STDMETHODIMP FinishDelayHypers();
	STDMETHODIMP RegisterSlideMap(CWPPSlideExport*, KPPTSlide*);
	BOOL GetBlipFromImg(CWpsImage& img, OUT MsoBlip& blip);
	void StoreBlip(CWpsImage& img, MsoBlip blip);

	StyleAttrCacheItem*		FindStyleAttrCacheItem(PPT_TextType textType,
		int nLevel, CShape_Context* shapeCtx);

	STDMETHODIMP	BeforeExportStyle(PPT_TextType textType,
		int nLevel, CObList* pList);

	StyleAttrCacheItem* GetStyleAttrItem(PPT_TextType textType,
		int nLevel);
};
class CWPPDocExport : public CWPPDoc
{
public:
	STDMETHODIMP Export(CWPPDocContext& docuCtx) const;
	STDMETHODIMP ExportGlobal(CWPPDocContext& docuCtx) const;
	STDMETHODIMP ExportFooter(CWPPDocContext& docuCtx) const;
	STDMETHODIMP ExportMasters(CWPPDocContext& docuCtx) const;
	STDMETHODIMP ExportSlides(CWPPDocContext& docuCtx) const;
	STDMETHODIMP ExportNamedShows(CWPPDocContext& docuCtx) const;
};

/*
 * slidebase	
 */
class CWPPSlideBaseContext
{
public:
	CWPPDocContext& m_docuCtx;
	KPPTSlide* m_pPptSlide;
	PSR_SlideType m_pptSlideType;
	PSR_SSlideLayoutAtom m_layout;

public:
	CWPPSlideBaseContext(CWPPDocContext& docuCtx, PSR_SlideType pptSlideType) :
		m_docuCtx(docuCtx), m_pPptSlide(NULL), m_pptSlideType(pptSlideType)
	{
		memset(&m_layout, 0, sizeof(m_layout));
	}
	CWPPDocContext& GetDocuCtx()
	{
		return m_docuCtx;
	}
	KPPTDocument& GetPptDocument()
	{
		return m_docuCtx.GetPptDocument();
	}
	CWPPDoc& GetWppDocument()
	{
		return m_docuCtx.GetWppDocument();
	}
	void SetPptSlide(KPPTSlide* pPptSlide)
	{
		ASSERT(m_pPptSlide == NULL);
		m_pPptSlide = pPptSlide;
	}
	KPPTSlide* GetPptSlide() const
	{
		ASSERT(m_pPptSlide);
		return m_pPptSlide;
	}
	PSR_SlideType GetSlideType() const
	{
		return m_pptSlideType;
	}
	PSR_SSlideLayoutAtom& GetLayout()
	{
		return m_layout;
	}
	//
	MsoBlipStore& GetBlipStore()
	{
		return GetPptDocument().GetDrawingGroup()->GetBlipStore();
	}
	MsoShape AddShape(const RECT& rc, BOOL fGroupShape = FALSE);
	UINT8 FindPlaceHolderID(CWPSObj& wpsObj, const CObList& oblist);
};
class CWPPSlideBaseExport : public CWPPSlideBase
{
public:
	STDMETHODIMP Export(CWPPSlideBaseContext& slideBaseCtx) const;
	STDMETHODIMP ExportBackground(CWPPSlideBaseContext& slideBaseCtx) const;

};
/*
 *	slidemaster
 */
class CWPPMasterContext : public CWPPSlideBaseContext
{
public:
public:
	CWPPMasterContext(CWPPDocContext& docuCtx, PSR_SlideType pptSlideType) : 
		CWPPSlideBaseContext(docuCtx, pptSlideType), m_pExParaAtom(NULL)
	{
	}
	~CWPPMasterContext()
	{
		if (m_pExParaAtom)
		{
			delete m_pExParaAtom;
			m_pExParaAtom = NULL;
		}
	}

	typedef map<int, PSR_ExtendedParagraphMasterAtom*> MapPHToExParaAtom;
	MapPHToExParaAtom	m_PhToExParaAtom;
	PSR_ExtendedParagraphMasterAtom* GetExParaAtom(INT nPlaceholderID)
	{
		if (m_PhToExParaAtom.find(nPlaceholderID) == m_PhToExParaAtom.end())
		{
			PSR_ExtendedParagraphMasterAtom* pAtom = new PSR_ExtendedParagraphMasterAtom;
			memset(pAtom, 0, sizeof(PSR_ExtendedParagraphMasterAtom));
			m_pPptSlide->AddExParagraphMasterAtom(nPlaceholderID, pAtom);
			m_PhToExParaAtom[nPlaceholderID] = pAtom;
		}
		return m_PhToExParaAtom[nPlaceholderID];
	}

private:
	PSR_ExtendedParagraphMasterAtom* m_pExParaAtom;
};
class CWPPMasterExport : public CWPPMaster
{
public:
	STDMETHODIMP Export(CWPPMasterContext& masterCtx);
	//��ɫ������
	STDMETHODIMP ExportColorScheme(CWPPMasterContext& masterCtx);
	//styles
	STDMETHODIMP ExportStyles(CWPPMasterContext& masterCtx);
	//
	STDMETHODIMP ExportObjects(CWPPMasterContext& masterCtx);
	//
	STDMETHODIMP ExportFooter(CWPPMasterContext& masterCtx);
	//
	STDMETHODIMP ExportTransition(CWPPMasterContext& slideCtx);
};

/*
 * slide
 */
class CWPPSlideContext : public CWPPSlideBaseContext
{
public:

public:
	CWPPSlideContext(CWPPDocContext& docuCtx, PSR_SlideType pptSlideType) : 
		CWPPSlideBaseContext(docuCtx, pptSlideType)
	{
	}
};
class CWPPSlideExport : public CWPPSlide
{
public:
	STDMETHODIMP Export(CWPPSlideContext& slideCtx);
	STDMETHODIMP ExportObjects(CWPPSlideContext& slideCtx);
	STDMETHODIMP ExportTransition(CWPPSlideContext& slideCtx);
	STDMETHODIMP ExportNote(CWPPSlideContext& slideCtx);
};


//global helper func
STDMETHODIMP gExport_WppObjects(CObList& ObjList, CObList& placeHolderList,
					CWPPSlideBaseContext& slideBaseCtx, CIndexObList* pShowOrder = NULL);
class CShape_Context;
#define WPPCONVERT_SPECIAL_VALIGN   0x0001 //�����valign����
STDMETHODIMP gExport_WppText(CShape_Context& shapeCtx, const CTextPool& textPool, CWPSObj& wpsObj, 
							 DWORD dwFlag = 0//WPPCONVERT_SPECIAL_VALIGN
							 );
//
STDMETHODIMP gExport_Layout(CWPPSlideBaseContext& slideBaseCtx, UINT layoutID);
//pf
STDMETHODIMP gExport_TxPFStyle(KPPTTxPFStyle& pptPfStyle,
								CWPPDocContext& docuCtx,
							   const CObList& wppPfList,
							   const CObList* pWppCfList = NULL,
							   KPPTTextRuler* pPptTextRuler = NULL,
							   int nLevelInRuler = 0,
							   KPPTClientTextBox* pPptClientTextBox = NULL,//for �Զ����
							   OUT int* pNumTypeNo = NULL,
							   PSR_NumberingFormat** ppFormat = NULL
							   );
STDMETHODIMP gExport_TxPFStyle(KPPTTxPFStyle& pptPfStyle,
							   CWPPDocContext& docuCtx,
							   const CStyle_Text& wppStyleText,
							   const CStyleSheet_Text& wppStyleSheet,
							   PSR_NumberingFormat** ppFormat = NULL
							   );
STDMETHODIMP gExport_DefaultTxPFStyle(KPPTTxPFStyle& pptPfStyle, int level);

//cf
STDMETHODIMP gExport_TxCFStyle(KPPTTxCFStyle& pptCfStyle,
							   CWPPDocContext& docuCtx,
							   const CObList& wppCfList
							   );
STDMETHODIMP gExport_TxCFStyle(KPPTTxCFStyle& pptCfStyle,
							   CWPPDocContext& docuCtx,
							   const CStyle_Text& wppStyleText,
							   const CStyleSheet_Text& wppStyleSheet
							   );
STDMETHODIMP gExport_DefaultTxCFStyle(KPPTTxCFStyle& pptCfStyle, int level);
//
enum __StyleType{__ST_Null, __ST_5Level, __ST_Single};
void gExport_GetStyleLevel(const CString& wppStyleName,
						   OUT PPT_TextType& pptTextType,
						   OUT __StyleType& styleType,
						   OUT int& npptLevel);
//
STDMETHODIMP gExport_FontSize(OUT UINT16& fontSize, const CCtrlCode_Size* pWppSizeCode,
					  const CObList* pWppCfList = NULL);

enum __ParaMarginType{__PMT_Line, __PMT_Before, __PMT_After, __PMT_FirstIndent, __PMT_LeftIndent};
STDMETHODIMP gExport_ParaMargin(INT16& pptValue, const UNIT_VALUE& wppValue, __ParaMarginType pmt,
								const CObList* pWppCfList = NULL);

STDMETHODIMP gExport_LeftIndent(OUT UINT16& leftIndent, const CCtrlCode_ParaIndent* pWppParaIndentCode,
					  const CObList* pWppPfList = NULL, const CObList* pWppCfList = NULL);

PPT_NumeringType gExport_NumberingType(LPCTEXTWORD lpszFormat);


HRESULT ExportShapeAction(CWPSObj* pObj, CWPPDocContext* context,
						  KPPTClientData* client, BOOL bIsPlaceHolder = FALSE,
						  KPPTClientTextBox* pBox = NULL, INT nTextStart = -1,
						  INT nTextEnd = -1);
HRESULT ExportAnimate(CWPSObj* pObj, CWPPDocContext* context,
					  KPPTClientData* client, int nOrder = 0);

#include <export/draw/ex_shape.h>

#endif /* __EX_WPPDOC_H__ */
