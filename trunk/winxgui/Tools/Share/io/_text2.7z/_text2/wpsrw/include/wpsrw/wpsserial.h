/* -------------------------------------------------------------------------
//	�ļ���		��	wpsrw/wpsserial.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 11:09:15
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPSRW_WPSSERIAL_H__
#define __WPSRW_WPSSERIAL_H__

extern const TCHAR g_szWPSMainStream[];
extern const TCHAR g_szWPPMainStream[];

// ------------------------------------------------------------------------
// class KOleStreamFile

#define RUNTIME_CLASS_WPS2002File	RUNTIME_CLASS(KOleStreamFile)

class KOleStreamFile : public COleStreamFile
{
	DECLARE_DYNAMIC(KOleStreamFile)
public:
	KOleStreamFile() : _fCompoundFile(TRUE) {}
	
public:
	BOOL _fCompoundFile;
};

inline
STDMETHODIMP_(BOOL) _IsCompoundFile(CFile* pFile)
{
	if (pFile->GetRuntimeClass() != RUNTIME_CLASS_WPS2002File)
	{
		return FALSE;
	}
	return ((KOleStreamFile*)pFile)->_fCompoundFile;
}

inline
STDMETHODIMP_(BOOL) _IsCompoundFile(CArchive& ar)
{
	return _IsCompoundFile(ar.GetFile());
}

// wps2002-io-bugfix, ���жϸ���ȫ������ʹ��ȫ�ֱ���...
#define g_fCompoundFile	_IsCompoundFile(ar)

// -------------------------------------------------------------------------
// class KWPS2002File

class KWPS2002File : public KOleStreamFile
{
public:
	typedef KOleStreamFile Base;
	
	KWPS2002File(LPCTSTR pszStreamName)
		: m_pszStreamName(pszStreamName), 
		m_pRootStg(NULL),
		m_pPicStream(NULL),
		m_pObjStream(NULL),
		m_pMainStream(NULL)
	{}
	virtual ~KWPS2002File();
	
	virtual BOOL Open(LPCTSTR lpszFileName, UINT nOpenFlags, CFileException* pError);
	virtual BOOL Open(IStorage* pStg);
	virtual void Close();
	
#ifdef _DEBUG
	virtual CString GetFileName() const
		{ REPORT("call GetFileName"); return Base::GetFileName(); }
	virtual CString GetFileTitle() const
		{ REPORT("call GetFileTitle"); return Base::GetFileTitle();	}
	virtual CString GetFilePath() const
		{ /*REPORT("call GetFilePath");*/ return Base::GetFilePath(); }
#endif
	
protected:
	IStorage* m_pRootStg;
	IStream*  m_pPicStream;
	IStream*  m_pObjStream;
	IStream*  m_pMainStream;
	LPCTSTR	  m_pszStreamName;
};

// ------------------------------------------------------------------------

class KMemFile : public KOleStreamFile
{
public:
	KMemFile(CFile* pFile, DWORD dwSize);
	KMemFile(BOOL fCompoundFile, HGBL hGbl = NULL);
	~KMemFile();

	STDMETHODIMP_(HGBL) Detach();
};

// -------------------------------------------------------------------------
// helper - global function

STDMETHODIMP_(BOOL) _IsWPSFile(LPCTSTR pszFile, LPCTSTR pszStreamName);

STDMETHODIMP_(IStorage*) _QueryStorage(class CFile* pFile);

STDMETHODIMP_(IStream*) _QueryPicStream(class CArchive& ar);
STDMETHODIMP_(IStream*) _NeedPicStream(class CArchive& ar);

STDMETHODIMP_(IStream*) _QueryTextStream(class CArchive& ar);
STDMETHODIMP_(IStream*) _NeedTextStream(class CArchive& ar);

STDMETHODIMP_(IStream*) _QueryObjStream(class CArchive& ar);
STDMETHODIMP_(IStream*) _NeedObjStream(class CArchive& ar);

inline BOOL IsWPS2002File(LPCTSTR pszFile)	{ return _IsWPSFile(pszFile, g_szWPSMainStream); }
inline BOOL IsWPP2002File(LPCTSTR pszFile)	{ return _IsWPSFile(pszFile, g_szWPPMainStream); }

// -------------------------------------------------------------------------
// ����֮LCID,��ͬ�����԰汾��ע������в�ͬ�ļ�ֵ

#define defCHINESESIM_VERSION			((DWORD)(2052))
#define defMENGWEN_VERSION				((DWORD)(1104))
#define defINVALID_VERSION				((DWORD)(0xFFFFFFFF))
inline BOOL IsMengWen_Version(DWORD dwVerTest)
{
	return ((BOOL)(defMENGWEN_VERSION == dwVerTest));
}

// -------------------------------------------------------------------------

#endif /* __WPSRW_WPSSERIAL_H__ */
