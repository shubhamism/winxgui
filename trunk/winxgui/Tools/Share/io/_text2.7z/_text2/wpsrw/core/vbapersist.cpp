// -------------------------------------------------------------------------
//	VBAPersist.cpp
//		LvGh(lvguihua@kingsoft.net)
//		2002-5-19 13:35:07
// 
// -------------------------------------------------------------------------
// ------------------------------>>>VBA ����<<<-----------------------------
//     �洢����Apc�洢�������ڴ洢ǰ����zlib�������ѹ����Ȼ��洢Ϊһ������
// ������Script�����Ӷ���ETͳһ��
// -------------------------------------------------------------------------
#include "stdafx.h"

#include "wpsrw/io/zip.h"

// -------------------------------------------------------------------------
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
#define L_STGNAME_APC L"Apc"
#define L_VBA_SCRIPT L"Script"

#define VBAKEY 0x00414256

#pragma pack(1)
typedef struct
{
	enum
	{
		vfhCompressed = 0x1,//ѹ������
	};
	
	DWORD dwKey;	//VBA	0x00414256
	WORD wMinorVer;
	WORD wMajorVer;
	DWORD cbBeforeCompress;////ѹ����ǰ�Ĵ�С
	DWORD cbAfterCompress;//ѹ���Ժ�Ĵ�С
	DWORD dwOptions;//������Ϣ
}KWPSVbaFileHeader;
#pragma pack()

// Save : m_lpRootStg --->
// Load : ---> m_lpRootStg
STDMETHODIMP gSaveVBA(IStorage* pStgRoot, IStorage* pStgFileExt);
STDMETHODIMP gLoadVBA(IStorage* pStgFileExt, IStorage** ppDest);
STDMETHODIMP gGetApcMem(IStorage* pStgRoot, HGBL* phMem);
// ����һ������ָ���ڴ�����ݵ�Storage
HRESULT gCreateStgOnBuf(void* pVBuffer, int nBufLen, IStorage** ppStg)
{
	HRESULT hr = S_OK;
	if (!pVBuffer || !ppStg)
		return E_INVALIDARG;

	HGBL hDest = XGlobalAlloc(GMEM_NODISCARD | GMEM_MOVEABLE, nBufLen);
	ASSERT(hDest);

	PBYTE pWriteBuf = (PBYTE)XGlobalLock(hDest);
	ASSERT(pWriteBuf);

	memcpy(pWriteBuf, pVBuffer, nBufLen);

	XGlobalUnlock(hDest);

	ILockBytes* pILockDestBuf = NULL;

	hr = XCreateILockBytesOnHGlobal(hDest, TRUE, &pILockDestBuf);
	ASSERT(SUCCEEDED(hr) && pILockDestBuf);

    hr = ::StgOpenStorageOnILockBytes(pILockDestBuf, 
									 NULL,
									 STGM_READ | STGM_SHARE_EXCLUSIVE,
									 NULL,
									 0,
									 ppStg);
	ASSERT(SUCCEEDED(hr) && *ppStg);

	if(pILockDestBuf)
	{
		pILockDestBuf->Release();
		pILockDestBuf = NULL;
	}
	return hr;
}

STDMETHODIMP gPersistVBA(IStorage* pStgRoot, IStorage* pStgFileExt, BOOL fSave)
{
	if (!pStgRoot || !pStgFileExt)
		return E_INVALIDARG;

	try
	{
		if (fSave)
			return gSaveVBA(pStgRoot, pStgFileExt);		
		//else
		//	return gLoadVBA(pStgRoot, pStgFileExt);
	}
	catch(...)
	{
		ASSERT(0);
	}
	return E_FAIL;
}

// -------------------------------------------------------------------------
// ���̲���
// 1. ��ȡApc�Ӵ洢���ڴ�
// 2. ѹ��
// 3. д���ļ�
// -------------------------------------------------------------------------
STDMETHODIMP gSaveVBA(IStorage* pStgRoot, IStorage* pStgFileExt)
{
	if (!pStgRoot || !pStgFileExt)
		return E_INVALIDARG;

	HRESULT hr = E_FAIL;
	CComPtr<IStream> ptrVBA = NULL;
	BYTE* pTemp = NULL;
	BYTE* pBuf = NULL;
	
	HGBL hMem = NULL;
	if (FAILED(hr = gGetApcMem(pStgRoot, &hMem)))
	{
		ASSERT(FALSE);
		return hr;
	}
	if (S_FALSE == hr)	// ���ĵ�δ����VBA����
		return S_FALSE;
	
	// -------------------------------------------------------------------------

	if (FAILED(hr = pStgFileExt->CreateStream(L_VBA_SCRIPT, 
												STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE,
												0, 0,
												&ptrVBA)))
	{
		ASSERT(0);
		return hr;
	}

	KWPSVbaFileHeader vfh;
	ZeroMemory(&vfh, sizeof(KWPSVbaFileHeader));
	
	vfh.dwKey = VBAKEY;
	vfh.wMajorVer = 1;
	vfh.wMinorVer = 1;
	vfh.cbBeforeCompress = XGlobalSize(hMem);

	pBuf = (BYTE*)XGlobalLock(hMem);

	HGBL hZip = NULL;
	if (S_OK != zlibCompress(pBuf, vfh.cbBeforeCompress, &hZip))
	{
		ASSERT (FALSE);
		vfh.cbAfterCompress = vfh.cbBeforeCompress;	// ѹ��ʧ����д��δѹ������
	}
	else
	{
		vfh.dwOptions = KWPSVbaFileHeader::vfhCompressed;
		pBuf = (BYTE*)XGlobalLock(hZip);
		vfh.cbAfterCompress = XGlobalSize(hZip);
	}

	ptrVBA->Write(&vfh, sizeof (vfh), NULL);
	ptrVBA->Write(pBuf, vfh.cbAfterCompress, NULL);

	XGlobalUnlock(hMem);
	XGlobalFree(hMem);
	
	if (hZip)
	{
		XGlobalUnlock(hZip);
		XGlobalFree(hZip);
	}

	return S_OK;
}

// -------------------------------------------------------------------------
// ���̲���
// 1. ��ȡVBA����
// 2. ��ѹ��
// 3. �����Ӵ洢
// 4. �����Ӵ洢
// -------------------------------------------------------------------------
STDMETHODIMP gLoadVBA(IStorage* pStgFileExt, IStorage** ppDest)
{
	if (!pStgFileExt || ppDest == NULL)
		return E_INVALIDARG;

	HRESULT hr = E_FAIL;
	CComPtr<ILockBytes> spLockBytes;
	BYTE* pBuf = NULL;
	HGBL hMem = NULL;
	KWPSVbaFileHeader vfh;
	CComPtr<IStream> spVBA;

	ZeroMemory(&vfh, sizeof(KWPSVbaFileHeader));

	{
		hr = pStgFileExt->OpenStream(L_VBA_SCRIPT,
								0, 
								STGM_READ | STGM_SHARE_EXCLUSIVE,
								0, 
								&spVBA);
	}
	if (FAILED(hr))	
		return S_FALSE;	// ��Ϊû�б���VBA��Ϣ
	
	hr = spVBA->Read(&vfh, sizeof (vfh), NULL);
	if (FAILED(hr))
	{
		ASSERT(0);
		return hr;
	}
	if (vfh.cbBeforeCompress == 0)
		return S_FALSE;

	ASSERT(vfh.dwKey == VBAKEY);

	if (vfh.dwOptions & KWPSVbaFileHeader::vfhCompressed)
	{
		BYTE* pTemp = new BYTE[vfh.cbAfterCompress];

		hr = spVBA->Read(pTemp, vfh.cbAfterCompress, NULL);
		hr = zlibDecompress(pTemp, vfh.cbAfterCompress, 
									vfh.cbBeforeCompress, &hMem);

		delete[] pTemp;

		pBuf = (BYTE*)XGlobalLock(hMem);
	}
	else
	{
		pBuf = new BYTE[vfh.cbBeforeCompress];

		ASSERT(vfh.cbAfterCompress == vfh.cbBeforeCompress);
		hr = spVBA->Read(pBuf, vfh.cbAfterCompress, NULL);
	}

	hr = ::gCreateStgOnBuf(pBuf, vfh.cbBeforeCompress, ppDest);

	// -------------------------------------------------------------------------
	if (hMem)	// δ��new�������ڴ��pBuf
	{
		XGlobalUnlock(hMem);
		XGlobalFree(hMem);
	}
	else if (pBuf)
	{
		delete[] pBuf;
	}

	return hr;
}

// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
// -------------------------------------------------------------<LvGh>------
// �ṹ���洢��ص�ȫ�ֺ������������л��洢VBA��Ӧ��Storage����ȡ��IStorage
//��Ӧ��ʵ���ڴ�顣
// -------------------------------------------------------------------------
// Technology Notes:
//
//     ��������Ҫ��ȡһ������ILockBytes��Storage��Ӧ���ڴ��ʱ����Ҫʹ��API
// GetHGlobalFromILockBytes���ڵ��øú���֮ǰһ��Ҫ�ȶ�IStorage����Release��
// ����ȡ�����ڴ�齫�ǲ������ģ�����������ΪIStorage���������һ����������
// �Ļ�������ֻ��Release��ʱ��Ż�������������д����Ӧ��LockBytes�С�
//
//										---	LvGh(lvguihua@kingsoft.net)
//											    2002-3-16 20:22:51
// -------------------------------------------------------------------------
HGBL gGetHGblFromStg(IStorage* pIStgSrc)
{
	ILockBytes* pILockBytes = NULL;
	IStorage* pCopyStg = NULL;

	XCreateILockBytesOnHGlobal(NULL, FALSE, &pILockBytes);

	::StgCreateDocfileOnILockBytes(pILockBytes, 
									STGM_CREATE | STGM_READWRITE | STGM_DIRECT | STGM_SHARE_EXCLUSIVE,
									0,
									&pCopyStg);

	pIStgSrc->CopyTo(0, NULL, NULL, pCopyStg);
	if(pCopyStg)
	{
		pCopyStg->Release();
		pCopyStg = NULL;
	}

	HGBL hDest = NULL;
	XGetHGlobalFromILockBytes(pILockBytes, &hDest);

	if (pILockBytes)
	{
		pILockBytes->Release();
		pILockBytes = NULL;
	}

	return hDest;
}

STDMETHODIMP gGetApcMem(IStorage* pStgRoot, HGBL* hMem)
{
	CComPtr<IStorage> spRootStgCpy;
	CComPtr<IStorage> spApcStg;
	HRESULT hr = ::StgCreateDocfile(NULL, 
									STGM_DELETEONRELEASE | STGM_READWRITE | STGM_TRANSACTED |
									STGM_SHARE_EXCLUSIVE | STGM_CREATE,
									0, 
									&spRootStgCpy);
	ASSERT(SUCCEEDED(hr));

	pStgRoot->CopyTo(0, NULL, NULL, spRootStgCpy);
	if (FAILED(hr))
	{
		ASSERT(0);
		return hr;
	}
	
	// ֻ��洢Apc�Ӵ洢
	hr = spRootStgCpy->OpenStorage(L_STGNAME_APC,
								NULL,
								STGM_READ | STGM_SHARE_EXCLUSIVE,
								NULL,
								NULL,
								&spApcStg);
	if (FAILED(hr))	// ���û��apc�Ӵ洢����Ȼ�Ͳ��ô���
		return S_FALSE;

	*hMem = ::gGetHGblFromStg(spApcStg);

	return S_OK;
}

// -------------------------------------------------------------------------
