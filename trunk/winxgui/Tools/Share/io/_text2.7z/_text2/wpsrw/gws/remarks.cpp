/* -------------------------------------------------------------------------
//	�ļ���		��	remarks.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 20:24:23
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "remarks.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

CRemarks::~CRemarks()
{
	int nCount = GetSize();
	for (int i = 0; i < nCount; i++)
	{
		delete GetAt(i);
	}
}

#ifndef _WPSREADER
BOOL CRemarks::SaveToFile(CArchive& ar)
{
	BOOL bRet = TRUE;

	try
	{
		int nCount = GetSize();
		CRemark* pRemark;
		CString strRemark;
		CString strUserName;
		int nLen;
		ar.Write(&nCount, sizeof(int));
		time_t t;
		int nLevel;
		for (int i = 0; i < nCount; i++)
		{
			pRemark = GetAt(i);
			//userName
			strUserName = pRemark->GetUserName();
			nLen = strUserName.GetLength();
			ar.Write(&nLen, sizeof(int));
			ar.Write(strUserName, nLen);
			//time
			t = pRemark->GetTime().GetTime();
			ar.Write(&t, sizeof(time_t));
			//nLevel;
			nLevel = pRemark->GetLevel();
			ar.Write(&nLevel, sizeof(int));
			//text
			strRemark = pRemark->GetRemark();
			nLen = strRemark.GetLength();
			ar.Write(&nLen, sizeof(int));
			ar.Write(strRemark, nLen);
		}
	}
	catch(...)
	{
		ar.Abort(); 
		bRet = FALSE;
	}
	return bRet;
}
#endif

BOOL CRemarks::LoadFromFile(CArchive& ar)
{
	BOOL bRet = TRUE;
	char* pszRemark = NULL;
	char* pszUserName = NULL;

	try
	{
		int nCount;
		CRemark* pRemark;
		CString strRemark;
		int nLen;
		ar.Read(&nCount, sizeof(int));
		time_t t;
		int nLevel;
		for (int i = 0; i < nCount; i++)
		{
			pRemark = new CRemark;

			//username
			ar.Read(&nLen, sizeof(int));
			pszUserName = new char[nLen + 1];
			memset(pszUserName, 0, nLen + 1);
			ar.Read(pszUserName, nLen);
			pRemark->SetUserName(CString(pszUserName));
			delete [] pszUserName;
			pszUserName = NULL;

			//time
			ar.Read(&t, sizeof(time_t));
			pRemark->SetTime(t);
			//level
			ar.Read(&nLevel, sizeof(int));
			pRemark->SetLevel(nLevel);

			//remark
			ar.Read(&nLen, sizeof(int));
			pszRemark = new char[nLen + 1];
			memset(pszRemark, 0, nLen + 1);
			ar.Read(pszRemark, nLen);
			pRemark->SetRemark(pszRemark);
			pRemark->SetCanModify(FALSE);
			delete [] pszRemark;
			pszRemark = NULL;

			Add(pRemark);
		}
	}
	catch(...)
	{
		ar.Abort(); 
		bRet = FALSE;
	}
	if (pszRemark)
		delete [] pszRemark;
	if (pszUserName)
		delete [] pszUserName;

	return bRet;
}

// -------------------------------------------------------------------------
