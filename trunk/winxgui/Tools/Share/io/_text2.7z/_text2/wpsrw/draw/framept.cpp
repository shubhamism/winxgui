/* -------------------------------------------------------------------------
//	�ļ���		��	framept.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-3 16:37:37
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "frameobj.h"
#include <chart/chart.h>
#include <chart/polyline.h>
#include <core/wpsdoc.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(CFramePT, CFrameObj, 0xA0 | VERSIONABLE_SCHEMA )

void CFramePT::DeleteContent()
{
	CFrameObj::DeleteImgContent();
	while ( !m_ptobjList.IsEmpty() )
		delete m_ptobjList.RemoveHead();
}

void CFramePT::Serialize_97(KSArchive& ar)
{          
	CFrameObj::Serialize_97(ar);

	m_ptobjList.Serialize(ar);
	
	if (!ar.IsStoring())
	{
		DiaToRectPoly(m_ptobjList, (CWpsDoc*)ar.m_pDocument);
	}
	
	CWPSObj::SerializeObjType(ar);
}

void CFramePT::Serialize_98( KSArchive& ar )
{
	CFrameObj::Serialize_98(ar);

	m_ptobjList.Serialize(ar);
	
	//	���ڶ����ƴ�ӹ�ϵ
	if (!ar.IsStoring())
	{
		/*@@todo - ��ɾ����
		if (ar.m_pDocument)
		{
			DWORD dwCnt = m_pDocument->GetObjIDCount();
			ResumeObjConnect( &m_ptobjList, dwCnt );
			m_pDocument->SetObjIDCount( dwCnt );
		}
		else*/
		// ��������е�ƴ�ӹ�ϵ���ؽ������ƴ�ӹ�ϵ
		{
			DWORD dwCnt = 1;
			ResumeObjConnect( &m_ptobjList, dwCnt );
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFramePT::Serialize_01(KSArchive& ar)
{
	CFrameObj::Serialize_01(ar);

	m_ptobjList.Serialize(ar);
/*	for (POSITION pos = m_ptobjList.GetHeadPosition(); pos; )
	{
		CTFPBase* pWpsObj = (CTFPBase*)m_ptobjList.GetNext(pos);
		if (pWpsObj->IsKindOf(RUNTIME_CLASS(CPolyLine)))
			pWpsObj->m_nBkMode = TRANSPARENT;
	}
*/
	//	���ڶ����ƴ�ӹ�ϵ
	if (!ar.IsStoring())
	{
		/*@@todo - ��ɾ����
		if (m_pDocument)
		{
			DWORD dwCnt = m_pDocument->GetObjIDCount();
			ResumeObjConnect( &m_ptobjList, dwCnt );
			m_pDocument->SetObjIDCount( dwCnt );
		}
		else*/
		// ��������е�ƴ�ӹ�ϵ���ؽ������ƴ�ӹ�ϵ
		{
			DWORD dwCnt = 1;
			ResumeObjConnect( &m_ptobjList, dwCnt );
		}
	}
	CWPSObj::SerializeObjType(ar);
}

// -------------------------------------------------------------------------
