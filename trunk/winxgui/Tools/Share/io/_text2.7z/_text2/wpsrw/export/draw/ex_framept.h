////////////////////////////////////////////////
// File : ex_framept.h
//
// Function : 
//
// Creater : �
//
// CreateTime : 2005-1-10 16:41:31
//
// Comments: ...
////////////////////////////////////////////////
#ifndef __EX_FRAMEPT_H__
#define __EX_FRAMEPT_H__

#ifndef __EX_SHAPE_H__
#include "ex_shape.h"
#endif

#ifndef __FRAMEOLE_H__
#include <draw/frameobj.h>
#endif

// -------------------------------------------------------------------------

class CFramePT_Export : public CFramePT
{
	//���಻�ܶ����Ա�������麯����
public:
	EX_SHAPE_API ConvertShape(CShape_Context& context);
protected:
	EX_SHAPE_API ConvertFrame(CShape_Context& context);
	EX_SHAPE_API ConvertSubshape(CShape_Context& context);
//	KDWBlip GetObjectPresImage(CShape_Context& context, IStorage* pStgObj, DVASPECT aspect);
};

ShapeExportClassDecl(FRAMEPT, CFramePT_Export, CFrameObj_Export);

// -------------------------------------------------------------------------

#endif /* __EX_FRAMEPT_H__ */
