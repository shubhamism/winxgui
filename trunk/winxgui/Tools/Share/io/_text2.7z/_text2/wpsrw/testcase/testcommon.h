/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 20:46:31
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(LPCWSTR) _XGetModuleNameWpsRW()
{
#if defined(WPP_ONLY)
	return __X("wpprw.dll");
#else
	return __X("wpsrw.dll");
#endif
}

#undef _XGetModuleName
#define _XGetModuleName	_XGetModuleNameWpsRW

// -------------------------------------------------------------------------

#include <cppunit/cppunit.h>

interface IKFilterEventNotify;

STDAPI WpsInitialize();
STDAPI WpsExport(IN LPCWSTR szWpsFile, IN IStorage* pWordRootStg);
STDAPI WpsConvert(IN LPCWSTR szWpsFile, IN LPCWSTR szDocFile);
STDAPI WpsConvertEx(IN LPCWSTR szWpsFile, IN LPCWSTR szDocFile, IN IKFilterEventNotify*);

STDAPI WppInitialize();
STDAPI WppExport(IN LPCWSTR szWppFile, IN IStorage* pPPTRootStg);
STDAPI WppConvert(IN LPCWSTR szWppFile, IN LPCWSTR szPPTFile);

// -------------------------------------------------------------------------

inline
STDMETHODIMP CreateDocfile(
						   IN LPCWSTR szFile,
						   OUT IStorage** ppRootStg)
{
	WCHAR szDocFile[_MAX_PATH];
	return StgCreateDocfile(
		GetSystemIniPath(szDocFile, szFile),
		STGM_G_CREATE,
		0,
		ppRootStg);
}

// -------------------------------------------------------------------------

inline
STDMETHODIMP testConvert2(LPCWSTR szWpsFile, LPCWSTR szDocFile)
{
	ks_stdptr<IStorage> spStg; 
	
	HRESULT hr = CreateDocfile(szDocFile, &spStg);
	ASSERT_OK(hr);

	if (FAILED(hr))
		return hr;

	WCHAR szSrcFile[_MAX_PATH];
	return WpsExport(
		GetSystemIniPath(szSrcFile, szWpsFile), spStg);
}

// -------------------------------------------------------------------------

inline
STDMETHODIMP testConvert(LPCWSTR szWpsFile, LPCWSTR szDocFile)
{
	WCHAR szSrcFile[_MAX_PATH];
	WCHAR szDestFile[_MAX_PATH];
	return WpsConvert(
		GetSystemIniPath(szSrcFile, szWpsFile),
		GetSystemIniPath(szDestFile, szDocFile));
}

#include "kso/io/v6/filter/plugin.h"

class KPasswordNotifyImpl : public IKFilterEventNotify
{
	LPCWSTR m_szPassword;
public:
	KPasswordNotifyImpl(LPCWSTR szPassword)
	{
		m_szPassword = szPassword;
	}

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void **ppvObject)
	{
		return E_NOTIMPL;
	}
		
	ULONG STDMETHODCALLTYPE AddRef( void)
	{
		return E_NOTIMPL;
	}
    
    ULONG STDMETHODCALLTYPE Release( void)
	{
		return E_NOTIMPL;
	}

	STDMETHODIMP OnNotify(
		IN UINT EventCode,
		IN UINT wParam,
		IN OUT LPVARIANT pVariant)
	{
		if (EventCode == FILTEREVENT_NEED_PASSWORD) 
		{
			pVariant->vt = VT_BSTR;
			pVariant->bstrVal = ks_wstring(m_szPassword).AllocBSTR();
			return S_OK;
		}
		return E_FAIL;
	}
};


inline 
STDMETHODIMP testConvertPassword(LPCWSTR szWpsFile, LPCWSTR szDocFile, LPCWSTR szPassword)
{
	WCHAR szSrcFile[_MAX_PATH];
	WCHAR szDestFile[_MAX_PATH];
	KPasswordNotifyImpl psNotify(szPassword);
	return WpsConvertEx(
		GetSystemIniPath(szSrcFile, szWpsFile),
		GetSystemIniPath(szDestFile, szDocFile),
		&psNotify);
}

inline
STDMETHODIMP testConvertWpp(LPCWSTR szWppFile, LPCWSTR szPPTFile)
{
	WCHAR szSrcFile[_MAX_PATH];
	WCHAR szDestFile[_MAX_PATH];
	return WppConvert(
		GetSystemIniPath(szSrcFile, szWppFile),
		GetSystemIniPath(szDestFile, szPPTFile));
}

// -------------------------------------------------------------------------

#define testWpsPath(from)													\
		L"../testcase/wpsrw/" L ## from

#define testWppPath(from)													\
		L"../testcase/wpprw/" L ## from

#define testWps2DocFile(from, to)											\
	testConvert(															\
		L"../testcase/wpsrw/" L ## from,									\
		L"../testcase/output/" L ## to )

#define testWps2DocFileEx(from, to, ps)										\
	testConvertPassword(													\
		L"../testcase/wpsrw/" L ## from,									\
		L"../testcase/output/" L ## to,										\
		ps)


#define testWpp2PPTFile(from, to)											\
	testConvertWpp(															\
		L"../testcase/wpprw/" L ## from,									\
		L"../testcase/output/" L ## to )

// -------------------------------------------------------------------------

#endif /* __TESTCOMMON_H__ */
