
////////////////////////////////////////////////////////////////
// file name	:			autonum_cchelper.h
// function		:			helper of autonumber ctrlcode
////////////////////////////////////////////////////////////////

#ifndef __AUTONUM_CCHELPER_H
#define __AUTONUM_CCHELPER_H

#include "autonum_dataptr.h"
#include "autonum_group.h"

/////////////////////////////////////////////////////////////
////
struct tagAUTONUMPARAREF
{
	KAutoNumGroupSPtr	m_AuoNumGroupSPtr;
	int					m_nLevel;
public:
	tagAUTONUMPARAREF() : m_AuoNumGroupSPtr(NULL), m_nLevel(0)
	{
	}
	tagAUTONUMPARAREF(const tagAUTONUMPARAREF& data)
	{
		m_AuoNumGroupSPtr	= data.m_AuoNumGroupSPtr;
		m_nLevel			= data.m_nLevel;
	}
	tagAUTONUMPARAREF(KAutoNumGroupSPtr GroupPtr, int nLevel)
		: m_AuoNumGroupSPtr(GroupPtr), 	m_nLevel(nLevel)
	{
	}
	~tagAUTONUMPARAREF()
	{
	}
	const tagAUTONUMPARAREF& operator=(const tagAUTONUMPARAREF& data)
	{
		if (&data != this)
		{
			m_AuoNumGroupSPtr	= data.m_AuoNumGroupSPtr;
			m_nLevel			= data.m_nLevel;
		}
		return *this;
	}
	BOOL IsValidRefData() const
	{
		BOOL bRet	= TRUE;
		if (!ISVALIDAUTONUMLEVEL(m_nLevel) || !m_AuoNumGroupSPtr)
			bRet	= FALSE;
		return bRet;
	}
};

typedef tagAUTONUMPARAREF		AUTONUMPARAREF;
typedef tagAUTONUMPARAREF*		PAUTONUMPARAREF;

BOOL operator==(const tagAUTONUMPARAREF& data0, const tagAUTONUMPARAREF& data1);
BOOL operator!=(const tagAUTONUMPARAREF& data0, const tagAUTONUMPARAREF& data1);

#endif // __AUTONUM_CCHELPER_H
