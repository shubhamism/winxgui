/* -------------------------------------------------------------------------
//	�ļ���		��	colormodel.cpp
//	������		��	������
//	����ʱ��	��	2002-5-3 13:33:18
//	��������	��
//
//-----------------------------------------------------------------------*/

#include "stdafx.h"
#include <export/ks_colormodel.h>
#include <export/ks_colormodel_impl.h>


///////////////////////////////////////////////////////////////////////////////
//KColorModel Impl
LONG KColorModel::GetFlagIndex(const KCOLORINDEX& indexColor)
{
	LONG index;
	index = (LONG) ((BYTE)((indexColor >> 24) & 0xff));

	return index;
}

LONG KColorModel::GetColorIndex(const KCOLORINDEX& indexColor)
{
	LONG nColorIndex = (LONG)(indexColor & 0x00ffffff);

	return nColorIndex;
}

BOOL KColorModel::SetFlagIndex(KCOLORINDEX& indexColor, const LONG nFlagIndex)
{
	indexColor = ( ((nFlagIndex & 0xff) << 24) | (indexColor & 0x00ffffff) );

	return TRUE;
}

BOOL KColorModel::SetColorIndex(KCOLORINDEX& indexColor, const LONG nColorIndex)
{
	indexColor = ( (indexColor & 0xff000000) | (nColorIndex & 0x00ffffff) );

	return TRUE;
}

BOOL KColorModel::CreateKCOLORINDEX(KCOLORINDEX& indexColor,
						const LONG nFlagIndex, const LONG nColorIndex)
{
	SetFlagIndex(indexColor, nFlagIndex);
	SetColorIndex(indexColor, nColorIndex);

	return TRUE;
}

LONG KColorModel::R(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	LONG r, g, b;

	GetRGB(indexColor, pICS, r, g, b);

	return r;
}

LONG KColorModel::G(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	LONG r, g, b;

	GetRGB(indexColor, pICS, r, g, b);

	return g;
}

LONG KColorModel::B(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	LONG r, g, b;

	GetRGB(indexColor, pICS, r, g, b);

	return b;
}

static HRESULT gCOLORINDEX2COLORREF(const KCOLORINDEX& indexColor,
								 IColorScheme* pICS, COLORREF& color)
{
	HRESULT hr;
	LONG nColorIndex = KColorModel::GetColorIndex(indexColor);

	switch (KColorModel::GetFlagIndex(indexColor))
	{
		case 0:
		{
			color = (COLORREF)nColorIndex;
			hr = S_OK;
			break;
		}
		case ksocolorFlagSchemeIndex:
		{
			if (pICS == NULL)
			{
				hr = E_FAIL;
			}
			else
			{
				hr = pICS->GetColor(nColorIndex, color);
			}
			break;
		}
		case ksocolorFlagSysIndex:
		{
			hr = E_NOTIMPL;//KDrawing System define color...
			break;
		}
		default:
			hr = E_FAIL;
	}

	return hr;
}

BOOL KColorModel::GetRGB(const KCOLORINDEX& indexColor,
				IColorScheme* pICS, LONG& r, LONG& g, LONG& b)
{
	COLORREF color;
	HRESULT hr;

	hr = gCOLORINDEX2COLORREF(indexColor, pICS, color);
	if (S_OK != hr)
	{
		r = -1;
		g = -1;
		b = -1;
		return FALSE;
	}


	r = (BYTE)(color&0xff);
	g = (BYTE)((color >> 8) & 0xff);
	b = (BYTE)((color >> 16) & 0xff);

	return TRUE;
}

LONG KColorModel::H(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	LONG h, s, v;
	GetHSV(indexColor, pICS, h, s, v);

	return h;
}

LONG KColorModel::S(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	LONG h, s, v;
	GetHSV(indexColor, pICS, h, s, v);

	return s;
}
LONG KColorModel::V(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	LONG h, s, v;
	if (KColorModel::GetFlagIndex(indexColor) == defCOLORMODELFLAG_ONECOLORSHADE)
	{
		LONG nColorIndex = KColorModel::GetColorIndex(indexColor);

		BYTE nDelta = ((nColorIndex&0x00ff0000) >> 16);
		BYTE nLevel = ((nColorIndex&0x0000ff00) >> 8);
		switch (nLevel)
		{
		case oneColorShadeMode_Darken:
			v = ((nDelta * 127) / 255);
			break;

		case oneColorShadeMode_Lighten:
			v = 255 - ((nDelta * 127) / 255);
			break;

		default:
			v = -1;
		}
	}
	else
		GetHSV(indexColor, pICS, h, s, v);

	return v;
}

BOOL KColorModel::GetHSV(const KCOLORINDEX& indexColor,
							IColorScheme* pICS, LONG& h, LONG& s, LONG& v)
{
	COLORREF color;
	HRESULT hr;

	hr = gCOLORINDEX2COLORREF(indexColor, pICS, color);
	if (S_OK != hr)
	{
		h = -1;
		s = -1;
		v = -1;
		return FALSE;
	}

	int r, g, b;
	r = (BYTE)(color&0xff);
	g = (BYTE)((color >> 8) & 0xff);
	b = (BYTE)((color >> 16) & 0xff);

	double min,max,delta,temp;
	min = __min(r,__min(g,b));
	max = __max(r,__max(g,b));
	delta = max - min;

	v = (int)max;
	if(!delta)
	{
		h = s = 0;
	}
	else
	{
		temp = delta/max;
		s = (int)(temp*255);

		if(r == (int)max)
		{
			temp = (double)(g-b)/delta;
		}
		else
			if(g == (int)max)
			{
				temp = 2.0 + ((double)(b-r)/delta);
			}
			else
			{
				temp = 4.0 + ((double)(r-g)/delta);
			}
			temp *= 60;
			if(temp < 0)
			{
				temp+=360;
			}
			if(temp == 360)
			{
				temp = 0;
			}
			h = (int)temp;
	}

	return TRUE;
}

//judge: whether direct get color true value(COLORREF) by the KCOLORINDEX
BOOL KColorModel::CanDirectGetCOLOR(const KCOLORINDEX& indexColor)
{
	if (GetFlagIndex(indexColor) == 0)
	{
		return TRUE;
	}

	return FALSE;
}

BOOL KColorModel::RGBToColor(KCOLORINDEX& indexColor,
							const LONG r, const LONG g, const LONG b)
{
	indexColor = (KCOLORINDEX)
			((0x00 << 24) | ((b & 0xff) << 16) | ((g & 0xff) << 8) | (r & 0xff));

	return TRUE;
}

BOOL KColorModel::HSVToColor(KCOLORINDEX& indexColor,
							const LONG h, const LONG s, const LONG v)
{
	int r, g, b;

	if(!h  && !s)
	{
		r = g = b = v;
	}
	double min,max,delta,hue;

	max = v;
	delta = (max * s)/255.0;
	min = max - delta;

	hue = h;
	if(h > 300 || h <= 60)
	{
		r = (int)max;
		if(h > 300)
		{
			g = (int)min;
			hue = (hue - 360.0)/60.0;
			b = (int)((hue * delta - min) * -1);
		}
		else
		{
			b = (int)min;
			hue = hue / 60.0;
			g = (int)(hue * delta + min);
		}
	}
	else
		if(h > 60 && h < 180)
		{
			g = (int)max;
			if(h < 120)
			{
				b = (int)min;
				hue = (hue/60.0 - 2.0 ) * delta;
				r = (int)(min - hue);
			}
			else
			{
				r = (int)min;
				hue = (hue/60 - 2.0) * delta;
				b = (int)(min + hue);
			}
		}
		else
		{
			b = (int)max;
			if(h < 240)
			{
				r = (int)min;
				hue = (hue/60.0 - 4.0 ) * delta;
				g = (int)(min - hue);
			}
			else
			{
				g = (int)min;
				hue = (hue/60 - 4.0) * delta;
				r = (int)(min + hue);
			}
		}

	return RGBToColor(indexColor, r, g, b);
}

//LLG_TEMP_2002_6_13
//����ɫΪ����ֵ������֮��Ӧ����ɫ����������ʱ��ȡϵͳĬ�ϵ���ɫ����ֵ
static COLORREF _ColorModel_DefaultCS[8] =
{
	0xffffff, 0x000000, 0x808080, 0x000000, //bg, line/text, shadow, titletext
	0xffffff, 0x808080, 0x808080, 0x808080  //fill, accent, mark, hyperlink
};
COLORREF KColorModel::IndexToRef(const KCOLORINDEX& indexColor, IColorScheme* pICS)
{
	COLORREF color = 0x000000;
	HRESULT hr = ::gCOLORINDEX2COLORREF(indexColor, pICS, color);
	if (hr == S_OK)
		return color;

	LONG nColorIndex = KColorModel::GetColorIndex(indexColor);
	LONG nFlag = KColorModel::GetFlagIndex(indexColor);
	switch (nFlag)
	{
		case ksocolorFlagSchemeIndex:
		{
			if (nColorIndex >= 0 && nColorIndex < 8)
				color = _ColorModel_DefaultCS[nColorIndex];

			break;
		}
		case ksocolorFlagSysIndex: //��ɫ���䣬����Ϊ��ɫ��
		{
			color = 0xffffff;
			break;
		}
	}

	return color;
}

KCOLORINDEX KColorModel::RefToIndex(const COLORREF& color)
{
	return ((KCOLORINDEX)color);
}
#ifndef RGB_MAX
	#define RGB_MAX 0xFF
#endif // RGB_MAX
#ifndef RGB_MIN
	#define RGB_MIN	0x00
#endif //RGB_MIN

COLORREF KColorModel::CalcSecondColorForOneShade(const KCOLORINDEX& indexFirst,
												 const KCOLORINDEX& indexSecond,
												 IColorScheme* pICS)
{
	COLORREF clrSecond = KColorModel::IndexToRef(indexSecond, pICS);
	if (KColorModel::GetFlagIndex(indexSecond) !=
										defCOLORMODELFLAG_ONECOLORSHADE)
	{
		return clrSecond;
	}

	LONG rgbFirst_r,	rgbFirst_g,		rgbFirst_b;
	LONG rgbSecond_r,	rgbSecond_g,	rgbSecond_b;

	rgbFirst_r = KColorModel::R(indexFirst, pICS);
	rgbFirst_g = KColorModel::G(indexFirst, pICS);
	rgbFirst_b = KColorModel::B(indexFirst, pICS);

	//-----�������ֵ���� start-----
	int nLevel	= (indexSecond & 0x0000ff00) >> 8;	// ������ʽ��������Ŀǰû����������Ҫȷ��
	int nOffset	= (indexSecond & 0x00ff0000) >> 16;	// ƫ���������ֵ���м�
	int nReserve= (indexSecond & 0x000000ff);			// ����ֵ������Ҫ�о�
	//if (nReserve != 0)
	//	return clrSecond;
	// һ�����⣬��׼������240(0xf0)����������ʹ�ã�����Ҫ�о���Ŀǰ����
	switch (nLevel)
	{
	case 1:	// Darken(p)		c:= c * p /255
		rgbSecond_r = rgbFirst_r * nOffset / RGB_MAX;
		rgbSecond_g = rgbFirst_g * nOffset / RGB_MAX;
		rgbSecond_b = rgbFirst_b * nOffset / RGB_MAX;
		break;
	case 2:	// Lighten(p)		c:= 255 - (255 -c) * p /255
		rgbSecond_r = RGB_MAX - (RGB_MAX - rgbFirst_r) * nOffset / RGB_MAX;
		rgbSecond_g = RGB_MAX - (RGB_MAX - rgbFirst_g) * nOffset / RGB_MAX;
		rgbSecond_b = RGB_MAX - (RGB_MAX - rgbFirst_b) * nOffset / RGB_MAX;
	break;
	case 3:	// Add(p)			c:= c + p
		rgbSecond_r = rgbFirst_r + nOffset;
		rgbSecond_g = rgbFirst_g + nOffset;
		rgbSecond_b = rgbFirst_b + nOffset;
	break;
	case 4:	// Subtract(p)		c:= c - p
		rgbSecond_r = rgbFirst_r - nOffset;
		rgbSecond_g = rgbFirst_g - nOffset;
		rgbSecond_b = rgbFirst_b - nOffset;
	break;
	case 5:	// ReverseSub(p)	c:= p - c
		rgbSecond_r = nOffset - rgbFirst_r;
		rgbSecond_g = nOffset - rgbFirst_g;
		rgbSecond_b = nOffset - rgbFirst_b;
	break;
	case 6:	// BlackWhite(p)	c:= c < p ? 0 : 255
		rgbSecond_r = (rgbFirst_r < nOffset) ? RGB_MIN : RGB_MAX;
		rgbSecond_g = (rgbFirst_g < nOffset) ? RGB_MIN : RGB_MAX;
		rgbSecond_b = (rgbFirst_b < nOffset) ? RGB_MIN : RGB_MAX;
	break;
	default:
		ASSERT(FALSE);
	break;
	}

	rgbSecond_r = (rgbSecond_r < RGB_MIN) ? RGB_MIN : rgbSecond_r;
	rgbSecond_g = (rgbSecond_g < RGB_MIN) ? RGB_MIN : rgbSecond_g;
	rgbSecond_b = (rgbSecond_b < RGB_MIN) ? RGB_MIN : rgbSecond_b;

	rgbSecond_r = (rgbSecond_r > RGB_MAX) ? RGB_MAX : rgbSecond_r;
	rgbSecond_g = (rgbSecond_g > RGB_MAX) ? RGB_MAX : rgbSecond_g;
	rgbSecond_b = (rgbSecond_b > RGB_MAX) ? RGB_MAX : rgbSecond_b;

	KCOLORINDEX indexColor;
	KColorModel::RGBToColor(indexColor, rgbSecond_r, rgbSecond_g, rgbSecond_b);
	clrSecond = KColorModel::IndexToRef(indexColor, pICS);

	return clrSecond;
}

KCOLORINDEX KColorModel::CreateSecondColorForOneShade(LONG nLightValue)
{
	KCOLORINDEX indexColor;
	LONG nFlagIndex = defCOLORMODELFLAG_ONECOLORSHADE;
	LONG nColorIndex = 0;

	BYTE nLevel;
	BYTE nDelta;
	if (nLightValue < 128)
	{
		nLevel = (BYTE)oneColorShadeMode_Darken; //��ͷ�ļ�˵��
		nDelta = (BYTE)((nLightValue * 255)/ 127);
	}
	else
	{
		nLevel = (BYTE)oneColorShadeMode_Lighten;
		nDelta = (BYTE)(((255 - nLightValue) * 255) / 127);
	}

	nColorIndex = (nDelta << 16) + (nLevel << 8) + 0x00;//ƫ����+��ʽ+�����λ����
	CreateKCOLORINDEX(indexColor, nFlagIndex, nColorIndex);

	return indexColor;
}
///////////////////////////////////////////////////////////////////////////////
//KColorScheme Impl:
KColorScheme::KColorScheme()
{
  //for Interfce
	m_nRef = 0;

	m_nColorCount = 0;
	m_pColors = NULL;
}

KColorScheme::~KColorScheme()
{
	if (m_pColors)
	{
		delete []m_pColors;
		m_pColors = NULL;
	}
}

/////////////////////////////////////////////////
HRESULT KColorScheme::QueryInterface(const IID& iid, void** ppv)
{
	return E_NOTIMPL;
}
ULONG KColorScheme::AddRef()
{
	m_nRef++;
	return m_nRef;
}

ULONG KColorScheme::Release()
{
	m_nRef--;
	if (m_nRef == 0)
	{
		delete this;
		return 0;
	}
	return m_nRef;
}

/////////////////////////////////////////////////
STDMETHODIMP KColorScheme::CreateCS(LONG nCount)
{
	if (m_pColors)
	{
   	delete []m_pColors;
   	m_pColors = NULL;
	}

	m_pColors = new COLORREF[nCount];
	if (m_pColors == NULL)
	{
		m_nColorCount = 0;
		return S_FALSE;
	}
	m_nColorCount = nCount;

	//init color value
	int i = 0;
	for (i = 0; i < nCount; i ++)
	{
		m_pColors[i] = 0x00000000;
	}

	return S_OK;
}

STDMETHODIMP KColorScheme::GetColorCount(LONG& nCount)
{
	nCount = m_nColorCount;
	if (m_pColors == NULL)
		return S_FALSE;

	return S_OK;
}

STDMETHODIMP KColorScheme::GetColor(const LONG index, COLORREF& color)
{
	if (index < 0 || index > m_nColorCount || m_pColors == NULL)
		return S_FALSE;

	color = m_pColors[index];

	return S_OK;
}

STDMETHODIMP KColorScheme::SetColor(const LONG index, const COLORREF& color)
{
	if (index < 0 || index > m_nColorCount || m_pColors == NULL)
		return S_FALSE;

	m_pColors[index] = color;

	return S_OK;
}

STDMETHODIMP KColorScheme::SetColors(IColorScheme* pICSSrc,
								LONG nToStart /*= 0*/, LONG nToCount/* = -1*/)
{
	if (pICSSrc == NULL)
		return S_FALSE;

	LONG nCopyCount;
	if (nToCount < 0)
		pICSSrc->GetColorCount(nCopyCount);
	else
		nCopyCount = nToCount;

   nCopyCount = min(nCopyCount, (m_nColorCount - nToStart));
	nCopyCount = max(nCopyCount, 0);

	COLORREF color;

	int i = 0;
	for (i = 0; i < nCopyCount; i ++)
	{
		pICSSrc->GetColor(i, color);

		m_pColors[i + nToStart] = color;
	}

	return S_OK;
}

STDMETHODIMP KColorScheme::GetColors(COLORREF* pColors,
													const LONG nColorCount)
{
	if (pColors == NULL || nColorCount <= 0)
	{
		return E_FAIL;
	}

	int nCopyCount = min(nColorCount, m_nColorCount);
	int i = 0;
	for (i = 0; i < nCopyCount; i ++)
	{
		pColors[i] = m_pColors[i];
	}

	return S_OK;
}

STDMETHODIMP KColorScheme::SetColors(const COLORREF* pColors,
													const LONG nColorCount)
{
	int nCopyCount = min(nColorCount, m_nColorCount);
	int i = 0;
	for (i = 0; i < nCopyCount; i ++)
	{
		m_pColors[i] = pColors[i];
	}

	return S_OK;
}

STDMETHODIMP KColorScheme::Clone(IColorScheme** ppICSDest)
{
	if (ppICSDest == NULL)
	{
		return S_FALSE;
	}

	KColorScheme* pClone = new KColorScheme;

	pClone->CreateCS(m_nColorCount);
   pClone->SetColors((IColorScheme*)this);

	(*ppICSDest) = (IColorScheme*)pClone;
	(*ppICSDest)->AddRef();

	return S_OK;
}

// == ->S_OK, != ->S_FALSE
STDMETHODIMP KColorScheme::Compare(IColorScheme* pICSSrc)
{
	if (pICSSrc == NULL)
		return S_FALSE;

	LONG nCount;
	pICSSrc->GetColorCount(nCount);
	if (nCount != m_nColorCount)
		return S_FALSE;

	COLORREF color;

	int i = 0;
	for (i = 0; i < m_nColorCount; i ++)
	{
		pICSSrc->GetColor(i, color);
		if (m_pColors[i] != color)
		{
			return S_FALSE;
		}
	}

	return S_OK;
}


///////////////////////////////////////////////////////////////////////////////
HRESULT gCoCreateColorScheme(LONG nColorCount, IColorScheme** ppICS)
{
	if (nColorCount <= 0 || ppICS == NULL)
	{
		return S_FALSE;
	}

	KColorScheme* pCS = NULL;
	pCS = new KColorScheme;
	if (pCS->CreateCS(nColorCount) == S_FALSE)
	{
		delete pCS;
		pCS = NULL;

		return S_FALSE;
	}

	(*ppICS) = pCS;
	(*ppICS)->AddRef();

	return S_OK;
}
