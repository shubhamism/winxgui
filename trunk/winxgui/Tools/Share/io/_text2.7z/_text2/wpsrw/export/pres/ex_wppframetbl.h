/* -------------------------------------------------------------------------
//	�ļ���		��	ex_wppframetbl.h
//	������		��	liupeng
//	����ʱ��	��	2004-11-23 15:54:41
//	��������	��	
//
// -----------------------------------------------------------------------*/

#ifndef __EX_FRAMETBL_H__
#define __EX_FRAMETBL_H__

#ifndef __EX_WPSDOC_H__
#include "../core/ex_wpsdoc.h"
#endif

#ifndef __EX_SHAPE_H__
#include "../draw/ex_shape.h"
#endif

#ifndef __FRAMETBL_H
#include "table/frametbl.h"
#endif

#ifndef __TABLEOBJ_H
#include "table/tableobj.h"
#endif

// -------------------------------------------------------------------------

struct _CellInfo
{
	KDWCellPr cp;
	int height;//һ���еĵ�Ԫ��߶�����ͬ��
	CTableElement* pEle;
};

struct TableData;
struct BorderSegment
{
public:
	BorderSegment(UINT rStart, UINT cStart, UINT rSpan, UINT cSpan);

	HRESULT SetAttrs();// KROAttributes* pAttrs, MsoDrawBlipHandlerContext& blipStore);
	HRESULT SetAttrs(COLORREF color,//
				int nWidth,//�߿� 0.1mm
				int nStyle//����
				);
	HRESULT ConvertToShape(TableData* pTable);

	UINT m_rowStart;
	UINT m_colStart;
	UINT m_rowSpan;
	UINT m_colSpan;
	MsoShapeOPT m_opt;
};

struct TableCell
{
	// KPPTClientTextBox m_txt;
public:
	TableCell(UINT rStart, UINT cStart, UINT rSpan, UINT cSpan);
	~TableCell();
	HRESULT SetAttrs(CTableElement* pEle, CWPSObj& obj);
	HRESULT ConvertToShape(TableData* pTable);
	HRESULT ConvertDiagBorders(TableData* pTable);
	void SetAlloc(MsoAutoFreeAlloc* pAlloc)
	{
		ASSERT(pAlloc);
		m_pAlloc = pAlloc;
	}
	
	HRESULT InfuseText(CTableElement* pEle, CWPSObj& obj);

	HRESULT InfuseShapeFillProp(CTableElement* pEle, MsoShapeOPT& opt);

	void SetExtraAttrs();
	void ConvertDiagBorder(MsoShapeOPT& opt, TableData* pTable, bool isDiagUp);
	UINT m_rowStart;
	UINT m_colStart;
	UINT m_rowSpan;
	UINT m_colSpan;

	CShape_Context* m_pContent;
	// MsoShapeOPT m_opt;
	MsoShapeOPT* m_pDiagDownOpt;
	MsoShapeOPT* m_pDiagUpOpt;

	MsoAutoFreeAlloc* m_pAlloc;
	CTableElement* m_pEle;		// for fill
};

struct TableData
{
	MsoShape m_parentShape;
	~TableData();
	void SetSize(UINT rowCount, UINT colCount)
	{
		m_rowCount = rowCount;
		m_colCount = colCount;
		m_horiPos.resize(m_rowCount + 1);
		m_vertPos.resize(m_colCount + 1);
	}
	void SetHoriBorderPos(UINT index, int pos)
	{
		ASSERT(pos >= 0);
		m_horiPos[index] = pos;
	}
	
	void SetVertBorderPos(UINT index, int pos)
	{
		ASSERT(pos >= 0);
		m_vertPos[index] = pos;
	}
	BorderSegment* AddHoriSegment(UINT rowIdx, 
						UINT colStart, UINT colSpan)
	{
		std::vector<BorderSegment*>::iterator it = m_horiSegments.begin();
		for (; it != m_horiSegments.end(); it++)
		{
			BorderSegment* pSeg = (BorderSegment*)(*it);
			if (pSeg->m_rowStart == rowIdx)
			{
				if ((pSeg->m_colStart <= colStart) &&
					(pSeg->m_colStart + pSeg->m_colSpan) > colStart)
					return NULL;
				if ((colStart <= pSeg->m_colStart) &&
					(colStart + colSpan) > pSeg->m_colStart)
					return NULL;
			}
		}
		m_horiSegments.push_back(
			new BorderSegment(rowIdx, colStart, 0, colSpan));
		return m_horiSegments.back();
	}

	BorderSegment* AddVertSegment(UINT colIdx,
						UINT rowStart, UINT rowSpan)
	{
		std::vector<BorderSegment*>::iterator it = m_vertSegments.begin();
		for (; it != m_vertSegments.end(); it++)
		{
			BorderSegment* pSeg = (BorderSegment*)(*it);
			if (pSeg->m_colStart == colIdx)
			{
				if ((pSeg->m_rowStart <= rowStart) &&
					(pSeg->m_rowStart + pSeg->m_rowSpan) > rowStart)
					return NULL;
				if ((rowStart <= pSeg->m_rowStart) &&
					(rowStart + rowSpan) > pSeg->m_rowStart)
					return NULL;
			}
		}
		m_vertSegments.push_back(
			new BorderSegment(rowStart, colIdx, rowSpan, 0));
		return m_vertSegments.back();
	}

	TableCell* AddCell(UINT rowStart, UINT colStart, UINT rowSpan, UINT colSpan)
	{
		ASSERT(rowStart >= 0 && rowStart < m_rowCount);
		ASSERT(colStart >= 0 && colStart < m_colCount);
		ASSERT(rowStart + rowSpan <= m_rowCount);
		ASSERT(colStart + colSpan <= m_colCount);
		m_cells.push_back(new TableCell(
			rowStart, colStart, rowSpan, colSpan));
		return m_cells.back();
	}
	void ConvertToShapes();
	void GenChildAnchor(MsoShape& shape, UINT rs, UINT cs, UINT re, UINT ce);

private:
	UINT m_rowCount;
	UINT m_colCount;
	std::vector<int> m_horiPos;
	std::vector<int> m_vertPos;
	std::vector<BorderSegment*> m_horiSegments;
	std::vector<BorderSegment*> m_vertSegments;
	std::vector<TableCell*> m_cells;
};


class CWPPFrameTable_Export : public CFrameTable
{
	//���಻�ܶ����Ա�������麯����
public:
	EX_SHAPE_API ConvertShape(CShape_Context& context);
	EX_SHAPE_API GetTablePosAndPr(CShape_Context& context, OUT KDWTablePos& tblPos, OUT KDWRowTablePr& tblPr);
	EX_SHAPE_API GetCellPr(CTableElement* pEle, OUT KDWCellPr& cellPr);
	EX_SHAPE_API ConvertTable(OUT _CellInfo*& pcp, CShape_Context& context, TableData* pTable);
	EX_SHAPE_API SetPapxAndChpx(CShape_Context& context, CTableElement* pEle,
								OUT KDWPropBuffer& papx, OUT KDWPropBuffer& chpx);
	BOOL AllocaDiagonal(CTableElement* pEle, OUT std::vector<KDWDiagonal>& vecDiagonal);
	EX_SHAPE_API AddContent(KDWDocument& docu, KSTextString& kstr, KDWPropBuffer& papxE, KDWPropBuffer& chpxE); 

private:
	void FixTextStyles(CObList& attrList, CObArray& styleList);
};

ShapeExportClassDecl(FRAMETable, CWPPFrameTable_Export, CFrameObj_Export);

ShapeExportClassDecl(FRMTableBody, CWPPFrameTable_Export, CFrameObj_Export);

// -------------------------------------------------------------------------
#endif /* __EX_FRAMEOLE_H__ */











































