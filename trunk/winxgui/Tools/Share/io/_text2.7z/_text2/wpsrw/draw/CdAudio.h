//////////////////////////////////////////////////////////////////////////
// CCdAudio header file
//
// This class encapsulates the MCI API for the CD-Audio device
//
// Copyright (C) 1997, 1998 Giancarlo Iovino (giancarlo@saria.com)
// All rights reserved. May not be sold for profit.
//
// This software is provided 'as it is' without implicit or explicit
// warranty.
//
// This code was develeped for MFC Programmer's Sourcebook
// (http://www.codeguru.com)
//

#if !defined(AFX_MCI_H_0S1R45G3534_142DS_215344_123444DGG3451_INCLUDED_)
#define AFX_MCI_H_0S1R45G3534_142DS_215344_123444DGG3451_INCLUDED_

#include "mci.h"

//////////////////////////////////////////////////////////////////////////
// CCdAudio
//

class CCdAudio : public CMciDevice {
DECLARE_SERIAL(CCdAudio);			//  �������������,�ɴ���.
public:
	CCdAudio();
	virtual ~CCdAudio();
#ifndef	_WPSREADER
#endif
	// Specific time formats	
	static const DWORD s_FormatMilliseconds;
	static const DWORD s_FormatMSF;
	static const DWORD s_FormatTMSF;

	// Specific status
	static const DWORD s_StatusCurrentTrack;
	static const DWORD s_StatusLength;
	static const DWORD s_StatusPosition;
	static const DWORD s_StatusStart;
	static const DWORD s_TrackTypeAudio;
	static const DWORD s_TrackTypeOther;	
	
	// Specific info
	static const DWORD s_InfoProduct;
	static const DWORD s_InfoMediaIdentity;
	static const DWORD s_InfoMediaUPC;	
	
	// Open	
	
	// Playback/Stop/Pause

	//�̳�mcidevice�����⺯��.
	virtual int	 CheckObjType();
	//virtual BOOL mciStop();
	virtual void Serialize_01 (KSArchive& ar);//����.
	virtual void Serialize_98 (KSArchive& ar);//����.
	
	// Open/Close CD door

	//CD INFO	ADD BY WY;
	/*// Seek	
	//��������.
	DWORD Seek(DWORD dwTo, BOOL bAsync = FALSE);
	DWORD SeekToStart(BOOL bAsync = FALSE);
	DWORD SeekToEnd(BOOL bAsync = FALSE);*/

	// Device status important items
	
	// Track info		
	
	// Get/Set the time format

protected:

	//DWORD Seek(DWORD dwTo, DWORD dwFlags, BOOL bAsync);

	//PresMciPara	m_MciPara;		//�豸��Ϣ.
	bmPresBgMusicPara m_MciPara;
};

#endif // !defined(AFX_MCI_H_0S1R45G3534_142DS_215344_123444DGG3451_INCLUDED_)