/* -------------------------------------------------------------------------
//	�ļ���		��	comment.h
//	������		��	Tank
//	����ʱ��	��	2004-11-19 5:38:21 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#include "stdafx.h"
#include "comment.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL(KSComment, CObject, 0xA0 | VERSIONABLE_SCHEMA)

KSComment::KSComment()
{
	m_wUserID = 0;
}


KSComment::KSComment(int nID)
{
	ASSERT(nID >= 1);
	m_nID = nID;
	m_wUserID = 0;
}


KSComment::~KSComment()
{
	if (m_pFrameText)
	{
		delete m_pFrameText;
		m_pFrameText = NULL;
	}	
}


void KSComment::Serialize(KSArchive & ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_nID;
		ar << m_wUserID;	
	}
	else
	{
		ar >> m_nID;
		ar >> m_wUserID;
	}	
}

//
////=======================================================
//// ����	: CTextTool::IsMovingOnESC
//// ����	: 
//// ���� : BOOL 
//// ��ע	:
////=======================================================
//BOOL CTextTool::IsMovingOnESC(LPTEXTWORD pszESC, CPoint* ppoint/*=0*/)
//{
//	CSentence* pSen = s_CaretPos.GetSentence();
//	if (!pSen)
//		{ ASSERT(FALSE); return FALSE; }
//	ASSERT_VALID (pSen);
//	if (ppoint && !IsInRegion(m_pView, ppoint, &s_CaretPos))
//		return FALSE;
//
//	const TEXTWORD* pwFrom;
//	const TEXTWORD* pwTo;
//	pSen->GetBufRange(&pwFrom, &pwTo);
//	ASSERT(pwFrom != NULL && pwTo != NULL);
//	ASSERT(pwTo >= pwFrom);
//	// Backward MAXESCSEQLEN length
//	LPCTEXTWORD pwChar = pwFrom + s_CaretPos.mbOffset;
//	LPCTEXTWORD pwCurChar = pwChar;
//	pwFrom = (s_CaretPos.mbOffset > MAXESCSEQLEN)? pwChar - MAXESCSEQLEN: pwFrom;
//	ASSERT(pwChar >= pwFrom);
//
//	int nESCSize;
//	for (NULL ;pwChar >= pwFrom; pwChar--)
//	{
//		if (*pwChar == ESC_LEADER && *(pwChar + 1) <= INS_END && *(pwChar + 1) >= INS_BEGIN &&
//			(nESCSize = GetEscSeqLength(pwChar)) > 1 && pwChar + nESCSize >= pwCurChar)
//		{	// �ҵ���������
//			memcpy(pszESC, pwChar, sizeof(TEXTWORD) * nESCSize);
//			return TRUE;
//		}
//	}
//	return FALSE;
//}
//
//
////=======================================================
//// ����	: CTextTool::IsMovingOnCommentLeft
//// ����	: ����Ƿ�����ע��������
//// ���� : BOOL 
//// ��ע	:
////=======================================================
//BOOL CTextTool::IsMovingOnCommentLeft(LPTEXTWORD pszESC)
//{
//	ASSERT(AfxIsValidAddress(pszESC, sizeof(pszESC)));
//
//	CSentence* pSen = s_CaretPos.GetSentence();
//	if (!pSen)
//		{ ASSERT(FALSE); return FALSE; }
//	ASSERT_VALID (pSen);
//
//	const TEXTWORD* pwFrom;
//	const TEXTWORD* pwTo;
//	pSen->GetBufRange(&pwFrom, &pwTo);
//	ASSERT(pwFrom != NULL && pwTo != NULL);
//	ASSERT(pwTo >= pwFrom);	
//	LPCTEXTWORD pwChar = pwFrom + s_CaretPos.mbOffset;
//	ASSERT((pwChar >= pwFrom) && (pwChar <= pwTo));
//	if (*pwChar == VK_ESCAPE && (*(pwChar +1) == INS_COMMENT))
//	{
//		memcpy(pszESC, pwChar, sizeof(TEXTWORD) *3);
//		return TRUE;
//	}
//	return FALSE;	
//}
//
//
////=======================================================
//// ����	: CTextTool::ShowCommentTips
//// ����	: 
//// ���� : void 
//// ��ע	:
////=======================================================
//void CTextTool::ShowCommentTips(LPCTEXTWORD pszESC)
//{
//	if (!m_pView)
//		{ ASSERT(FALSE); return; }
//	ASSERT_VALID(m_pView);
//
//	int nID = pszESC[2];
//	ASSERT(nID >= 1);
//	
//	CWpsDoc* pDoc = m_pView->GetDocument();	ASSERT_VALID(pDoc);
//	KSCommentMan* pMan = pDoc->GetCommentMan();	ASSERT(pMan);
//	KSComment* pComment = NULL;
//	pMan->GetComment(nID, &pComment);	ASSERT_VALID(pComment);
//	CFrameText* pFrame = pComment->GetFrameText();	ASSERT_VALID(pFrame);
//
//	CString str;
//	pFrame->GetTextString(&str);
//
//	if (str.IsEmpty())
//		return;
//	m_pView->EnableWpsToolTips(str);
//}





/////////////////////////////////////////////////////////////////////////////////////////
// ��ע����
KSCommentMan::KSCommentMan()
{
	ASSERT_VALID(this);
	m_wCurUserID = 0;
}


KSCommentMan::~KSCommentMan()
{
	for (int i = 0; i < m_aryComments.GetSize(); i++)
	{
		KSComment* pComment = (KSComment*)m_aryComments.GetAt(i); ASSERT_VALID(pComment);
		RemoveComment(pComment);
	}
}


//=======================================================
// ����	: KSCommentMan::AddComment
// ����	: ����ע���������ע��������
// ���� : int ��ǰ��ע�����id
// ����	: KSComment*
// ��ע	:
//=======================================================
int KSCommentMan::AddComment(KSComment* pComment)
{
	ASSERT_VALID(pComment);
	int nIndex = m_aryComments.Add(pComment);
	ASSERT(nIndex >= 0);
	return nIndex + 1;
}

//=======================================================
// ����	: KSCommentMan::RemoveComment
// ����	: 
// ���� : void 
// ����	: KSComment*
//		  bDelIt				�Ƿ����ɾ��֮
// ��ע	:
//=======================================================
void KSCommentMan::RemoveComment(KSComment* pComment, BOOL bDelIt/*=TRUE*/)
{
	ASSERT_VALID(pComment);

	int nSize = NumOfComment();
	ASSERT(nSize >= 1);

	KSComment* pCM = NULL;
	int nIndex;
	for (int i = 0; i < nSize; i++)
	{
		pCM = (KSComment*)m_aryComments.GetAt(i);
		ASSERT(pCM);
		if (pComment == pCM)
		{
			nIndex = i;
			break;
		}
	}
	ASSERT(nIndex >= 0 && nIndex < nSize);
	m_aryComments.RemoveAt(nIndex);
	if (bDelIt)
		delete pCM;
}

//=======================================================
// ����	: KSComment::FindComment
// ����	: 
// ���� : KSComment* 
// ����	: nID,��עid
// ��ע	:
//=======================================================
BOOL KSCommentMan::GetComment(int nID, KSComment** ppComment)
{
	ASSERT(ppComment != NULL);
	int nSize = NumOfComment();
	for (int i = 0; i < nSize; i++)
	{
		KSComment* pCM = (KSComment*)m_aryComments.GetAt(i); ASSERT_VALID(pCM);
		int nCMID;
		pCM->GetCommentID(nCMID);
		if (nID == nCMID)
		{
			*ppComment = pCM;
			return TRUE;
		}
	}
	return FALSE;
}


//=======================================================
// ����	: KSCommentMan::GetCommentByIndex
// ����	: 
// ���� : KSComment* ����
// ����	: int nIndex
// ��ע	:
//=======================================================
KSComment* KSCommentMan::GetCommentByIndex(int nIndex)
{
	ASSERT(nIndex >= 0 && nIndex < NumOfComment());
	KSComment* pCM = (KSComment*)m_aryComments.GetAt(nIndex);	ASSERT_VALID(pCM);
	return pCM;
}


//=======================================================
// ����	: CWpsDoc::SaveComment
// ����	: 
// ���� : BOOL 
// ��ע	: ȷ���ɹ�!
//=======================================================
//BOOL CWpsDoc::SaveCommentMan()
//{
//	ASSERT_VALID(this);
//
//	KMemFile memfile(TRUE);
//	KSArchive saveArchive(&memfile, 
//						  KSArchive::store |
//						  KSArchive::bNoFlushOnDelete);
//	saveArchive.m_pDocument = this;
//	saveArchive.m_bForceFlat = FALSE;
//
//	COLEData* pOleData;	
//	if (SUCCEEDED(CreateStorage("CommentMan", &pOleData)) ||
//	   (pOleData = OpenStorage("CommentMan", STGM_READWRITE)) != NULL)
//	{
//		int nSize = m_CommentMan.NumOfComment();
//		WORD wCurUserID = m_CommentMan.GetCurUserID();
//		pOleData->Write("CommentNum", &nSize, sizeof(int));
//		pOleData->Write("CurUserID", &wCurUserID, sizeof(WORD));
//		for( int i = 0; i < nSize; i++)
//		{
//			KSComment* pComment = m_CommentMan.GetCommentByIndex(i);
//			CFrameText* pFrame = pComment->GetFrameText(); ASSERT_VALID(pFrame);
//			CLineObj* pLine = pFrame->GetLineObj(); ASSERT_VALID(pLine);
//
//			try
//			{
//				saveArchive << pFrame;
//				saveArchive << pLine;
//				saveArchive << pComment;
//			}
//			catch(...)
//			{
//				REPORT("�쳣");
//			}
//		}				
//		saveArchive.Close();
//
//		HGLOBAL hGbl = memfile.Detach();
//		UINT nBuffSize = GlobalSize(hGbl);
//		pOleData->Write("CMFrame_BuffSize", &nBuffSize, sizeof(UINT));
//		pOleData->Write("CMFrame", GlobalLock(hGbl), nBuffSize);
//		GlobalUnlock(hGbl);
//		GlobalFree(hGbl);
//	}
//	else 
//	{
//		ASSERT(FALSE);
//		return FALSE;
//	}
//	return TRUE;
//}


//=======================================================
// ����	: CWpsDoc::LoadCommentMan
// ����	: 
// ���� : BOLL 
// ��ע	:
//=======================================================
//class _CWpsDoc : public CWpsDoc
//{
//public:
//	STDMETHODIMP_(BOOL) LoadCommentMan(BOOL fCompound);
//};
//
//STDMETHODIMP_(BOOL) _CWpsDoc::LoadCommentMan(BOOL fCompound)
//{
//	ASSERT_VALID(this);
//	int nSize;
//	WORD wCurUserID;
//	COLEData* pOleData = OpenStorage("CommentMan", STGM_READWRITE);
//	if (pOleData)
//	{		
//		UINT nBuffSize;
//		pOleData->Read("CommentNum", &nSize, sizeof(int));
//
//		// ���û����ע,�򷵻�!		 ���ڶ����ļ�Readme.wps, ����wCurUserID�����һ����Чֵ! amend by wdb	2001-6-11
//		if (nSize == 0)
//			return TRUE;
//		pOleData->Read("CurUserID", &wCurUserID, sizeof(WORD));
//		pOleData->Read("CMFrame_BuffSize", &nBuffSize, sizeof(UINT));
//		m_CommentMan.SetCurUserID(wCurUserID);
//		
//		HGLOBAL hGbl = GlobalAlloc(GHND, nBuffSize + 1024);
//		pOleData->Read("CMFrame", GlobalLock(hGbl), nBuffSize + 1024);
//		GlobalUnlock(hGbl);
//		
//		KMemFile memfile(fCompound, hGbl);
//		KSArchive loadArchive(&memfile, 
//						  KSArchive::load | 
//						  KSArchive::bNoFlushOnDelete);
//		loadArchive.m_pDocument = this;
//		loadArchive.m_bForceFlat = FALSE;
//
//		CFrameText* pFrame;
//		CLineObj* pLine;
//		for (int i = 0; i < nSize; i++)
//		{
//			KSComment* pComment = NULL;
//			loadArchive >> pFrame;
//			loadArchive >> pLine;
//			loadArchive >> pComment;
//
//			ASSERT_VALID(pFrame);
//			ASSERT(pFrame->GetFrameID() == 2);
//			ASSERT_VALID(pLine);
//			ASSERT_VALID(pComment);
//
//			m_CommentMan.AddComment(pComment);
//			pLine->m_bCM = TRUE;		// ����ȷ������ע��!
//			pComment->SetFrameText(pFrame);
//			pFrame->SetLineObj(pLine);
//			pFrame->SetCommentFrame(TRUE);
//
//			pLine = NULL;
//			pFrame = NULL;
//		}
//		loadArchive.Close();
//		return TRUE;
//	}
//	return TRUE;
//}
//
//STDMETHODIMP_(BOOL) LoadCommentMan(CWpsDoc* pThis, BOOL fCompound)
//{
//	return ((_CWpsDoc*)pThis)->LoadCommentMan(fCompound);
//}

//=======================================================
// ����	: KSCommentMan::SetCurUserID
// ����	: 
// ���� : void 
// ����	: WORD wUserID
// ��ע	:
//=======================================================
void KSCommentMan::SetCurUserID(WORD wUserID)
{
	m_wCurUserID = wUserID; 
}
