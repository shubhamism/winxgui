// Midi.h: interface for the CMidiWav class.
// CMidiWav class:MIDI��Wav�����в���.	
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MIDI_H__132468A0_3CEB_11D2_BBE7_5254ABDD5D68__INCLUDED_)
#define AFX_MIDI_H__132468A0_3CEB_11D2_BBE7_5254ABDD5D68__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//#include "KMMedia.h"
#include "Mci.h"


class CMidiWav : public CMciDevice  
{
DECLARE_SERIAL(CMidiWav);			//  �������������
public:
	CMidiWav ();
	CMidiWav (const CWpsDoc* pDoc, const CRect& rc);
	~CMidiWav();
	// Specific info
	static const DWORD s_InfoProduct;
	static const DWORD s_InfoMediaIdentity;
	static const DWORD s_InfoMediaUPC;	
	
	virtual int	 CheckObjType();
	//�̳�mcidevice�����⺯��.
	virtual void Serialize_98 (KSArchive& ar);//����.
	virtual void Serialize_01(KSArchive&);
protected:
	//BOOL    m_bMidi;
	int		m_nSoundType; //�������ͣ�Midi��Wav��MP3
	PresMciPara	m_MciPara;		//�豸��Ϣ.
	int m_nMediaPlayerID; //������ID(current only for mp3)
};

#endif // !defined(AFX_MIDI_H__132468A0_3CEB_11D2_BBE7_5254ABDD5D68__INCLUDED_)
