//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainOption.h
//	FileAuthor		:	wdb
//	FileCreateDate	:	2000-6-26 9:51:28
//	FileDescription	:	
//
//////////////////////////////////////////////////////////////////////////////////////


// KSDomainOption.h: interface for the KSDomainOption class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __KSDMAINOPTION_H
#define __KSDMAINOPTION_H

#include "Ptobj.h"

class KSDomainOption : public CRectObj  
{
protected:
	DECLARE_SERIAL(KSDomainOption);
	KSDomainOption();
	
private:
	BOOL m_bSelect;
	BOOL m_bDrawFlag;
	BOOL m_bBackGround;
	BOOL m_bGroup;
	//	BOOL m_bEnableField; // û�б��棬������ֻ����ReadOnly ״̬�´β���Ч	
	
public:
	KSDomainOption(const CWpsDoc* pDoc, const CRect& rect);
	//	class copy:
public:
	KSDomainOption(const KSDomainOption* obj);
	//  class destruct:
public:	
	virtual ~KSDomainOption();
	
public:
	virtual void Serialize_01( KSArchive& ar );
};

#endif // !defined(AFX_KSDOMAINOPTION_H__25D06D2C_A6CE_4697_856F_7E421BB7D776__INCLUDED_)
