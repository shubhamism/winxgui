/* -------------------------------------------------------------------------
//	�ļ���		��	wpsapp.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 15:00:23
//	��������	��
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <gdiplus.h>
#include "wpsapp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////////////
// Function Name: GetSysCodePage
// Function		:
// Entry		:
// Return		: UINT
// Remark		: return 0 if Chinese (PRC, Singapore)
//				  return 2 if Chinese (Taiwan; Hong Kong SAR, PRC)
///////////////////////////////////////////////////////////////////////////
inline UINT GetSysCodePage()
{
	switch (GetOEMCP())
	{
	case 936:
		return 0;
	case 950:
		return 2;
//	case 18030:
//		return 1;
	}
	return 0;
}

// -------------------------------------------------------------------------

BOOL InitLangCodePages()
{
/*@@todo
	FillCharLangTbl();
	g_bWin9xOrWinNT = ::GetVersion() >= 0x80000000;
	return ::EnumSystemLocales(EnumLocalesProc, LCID_SUPPORTED); */
	return TRUE;
}

// -------------------------------------------------------------------------

KSGlobalVI KSGlobalVIMan(NULL, 0);//@@todo (&ScriptSheet, 0);

BOOL CWinwpsApp::InitializeCodePageVI()
{
	//@@todo
	//VERIFY(KSGlobalVIMan.Initialize());

	UINT nSysCodePage = GetSysCodePage();

	KXCodePageVI* pCPVI;
	{
		int nRet = InitDll_CPGBK(
			&KSGlobalVIMan,
			&pCPVI,
			g_dwLanguageVersion);
		switch (nRet)
		{
		case 1:
			if (!pCPVI)
			{
				ASSERT(FALSE);
				return FALSE;
			}
			break;
		default:
			ASSERT(0);
			return FALSE;
		}
	}

	ASSERT(pCPVI);
	g_lpKXCodePageVI = pCPVI;
	//@@todo
	//m_hCodePageDll = hInst;

	::InitLangCodePages();	//��ʼ�������Ի���
	return TRUE;
}

BOOL CWinwpsApp::UnInitializeCodePageVI()
{
	/*@@todo
	VERIFY(KSGlobalVIMan.UnInitialize());
	if (m_hCodePageDll)
		FreeLibrary(m_hCodePageDll);
	if (m_hCodePageShareDll)
		FreeLibrary(m_hCodePageShareDll); */
	return TRUE;
}

// -------------------------------------------------------------------------

using namespace Gdiplus;

ULONG_PTR gdiplusToken;

DWORD glCodePage;
CPrinter* g_pPrinter;

BOOL CWinwpsApp::InitInstance()
{
	GdiplusStartupInput gdiplusStartupInput;
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

	glCodePage = GetOEMCP();

	g_pPrinter = &m_printer;
	if (!g_pPrinter->InitClass())
	{
		return FALSE;
	}
	return InitializeCodePageVI();
}

BOOL CWinwpsApp::ExitInstance()
{
	GdiplusShutdown(gdiplusToken);

	return UnInitializeCodePageVI();
}

// -------------------------------------------------------------------------

UINT g_nRef = 0;
CWinwpsApp theApp;

#if defined(WPS_ONLY)
	EXPORTAPI WpsInitialize()
#elif defined(WPP_ONLY)
	EXPORTAPI WppInitialize()
#endif
	{
		if (++g_nRef == 1)
		{
#if defined(WPS_ONLY)
			afxCurrentAppName = "wpsrw";
#elif defined(WPP_ONLY)
			afxCurrentAppName = "wpprw";
#endif
			return theApp.InitInstance() ? S_OK : E_FAIL;
		}
		else
			return S_OK;
	}

#if defined(WPS_ONLY)
	EXPORTAPI_(void) WpsTerminate()
#elif defined(WPP_ONLY)
	EXPORTAPI_(void) WppTerminate()
#endif
	{
		if (--g_nRef == 0)
			theApp.ExitInstance();
	}

// -------------------------------------------------------------------------
