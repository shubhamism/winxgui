/* -------------------------------------------------------------------------
//	�ļ���		��	testpres.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 15:57:19
//	��������	��
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if defined(WPP_ONLY)
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP SDDoConvert2(
						 IN LPCWSTR szFile,
						 IN SD_FILEINFO_ARG fiArg,
						 IN LPVOID pParam)
{
	WCHAR szDestFile[_MAX_PATH];
	
	LPCWSTR szDot = wcsrchr(szFile, '.');
	if (szDot == NULL || wcsicmp(szDot, __X(".dps")) != 0)
		return S_OK;

	USES_CONVERSION;
	LPCWSTR szFileName = wcsrchr(szFile, '/') + 1;
	printf("\nprocessing %s ...", W2A(szFileName));
	
	memcpy(
		szDestFile,
		szFile,
		(szDot - szFile)*sizeof(WCHAR));
	
	wcscpy(
		szDestFile + (szDot - szFile),
		__X(".ppt"));
	
	HRESULT hr = WppConvert(
		szFile,
		szDestFile);
	
	ASSERT_OK(hr);	
	return S_OK;
}

class TestPresentation : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestPresentation);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
		//testWpp2PPTFile("test1.dps", "_test1_.ppt");
		const WCHAR szDir[] = testWppPath("dps\\tmp2");//\\ҳüҳ��");//\\ĸ���ı�");

		WCHAR szSrcDir[_MAX_PATH];		
		_XScanDirectory(
			GetSystemIniPath(szSrcDir, szDir),
			SDDoConvert2,
			0, //���Ҫ������Ŀ¼���ã�SD_SCAN_SUBDIR
			0);


	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestPresentation);

static HRESULT g_hr = WppInitialize();

// -------------------------------------------------------------------------
#endif
