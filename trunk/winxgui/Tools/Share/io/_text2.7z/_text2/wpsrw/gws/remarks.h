/* -------------------------------------------------------------------------
//	�ļ���		��	remarks.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 20:24:11
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __REMARKS_H__
#define __REMARKS_H__

// -------------------------------------------------------------------------

class CRemark  
{
public:
	CRemark();
	
	virtual ~CRemark();
private:
	CString m_strUserName;
	CString m_strRemark;
	BYTE* m_lpbyImage;
	
	BOOL m_bCanModify;
	CTime m_dtTime;
	
	int m_nLevel;
	
public:
	CString GetRemark() { return m_strRemark; };
	void SetRemark(LPCTSTR lpszUserIC) { m_strRemark = lpszUserIC; };
	
	CString GetUserName() { return m_strUserName; };
	void SetUserName(const CString& strUserName) { m_strUserName = strUserName; };
	
	int GetLevel() { return m_nLevel; };
	void SetLevel(int nLevel) { m_nLevel = nLevel; };
	
	void SetTime(const CTime& dtTime) { m_dtTime = dtTime; };
	CTime GetTime() { return m_dtTime; };
	
	void SetCanModify(BOOL bCanModify) { m_bCanModify = bCanModify; };
	
#if !defined _GWS && !defined _WPSREADER
	BOOL GetCanModify() { return m_bCanModify; };
#endif	// #if !defined _GWS && !defined _WPSREADER
};

inline CRemark::CRemark()
{
	m_lpbyImage = NULL;
	m_nLevel = 0;
}

inline CRemark::~CRemark()
{
	if (m_lpbyImage)
		delete [] m_lpbyImage;
}

// -------------------------------------------------------------------------

class CRemarks : public CPtrArray
{
public:
	virtual ~CRemarks();
	
public:
#if !defined _GWS && !defined _WPSREADER
	void AddRemark(CRemark* pRemark) {	Add(pRemark); };
#endif	// #if !defined _GWS && !defined _WPSREADER
	
	CRemark* GetAt(int nIndex) { return (CRemark *) CPtrArray::GetAt(nIndex); };
	
	BOOL SaveToFile(CArchive& ar);
	BOOL LoadFromFile(CArchive& ar);
};

// -------------------------------------------------------------------------

#endif /* __REMARKS_H__ */
