/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_abgroupinfoman.cpp
//	������		��	����
//	����ʱ��	��	2004-10-27 11:12:04 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <stl/list.h>

#ifndef __TEXTPOOL_H__
#include "textpool.h"
#endif

#ifndef __AUTONUM_ATOM_H
#include "autonum_atom.h"
#endif

#ifndef __AUTONUM_DATAPTR_H__
#include "autonum_dataptr.h"
#endif

#ifndef __AUTONUM_IOADAPTER_H__
#include "autonum_ioadapter.h"
#endif

#include "autonum_abgroupinfoman.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

KABGroupInfoMan* CTextPool::GetABGroupInfoMan(BOOL bCur/* = TRUE*/)
{

	if (!bCur && !m_pKABGroupInfoMan)
		m_pKABGroupInfoMan = new KABGroupInfoMan();
	return m_pKABGroupInfoMan;
}

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(KABGroupInfoMan, CObject, VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

KABGroupInfoMan::KABGroupInfoMan()
 : m_nLengthPerLevel(defKTABLENGTH)
{
}

KABGroupInfoMan::~KABGroupInfoMan()
{
	ReleaseAll();
}

void KABGroupInfoMan::ReleaseAll()
{
	std::list<void*>::iterator itr;
	KAutoNumAtomPtr* pAtomPtr	= NULL;
	for (itr = m_listAtom.begin(); itr != m_listAtom.end(); itr++)
	{
		pAtomPtr	= (KAutoNumAtomPtr*)*itr;
		ASSERT(pAtomPtr);
		if (pAtomPtr)
		{
			pAtomPtr->Retire(FALSE);
			pAtomPtr->Release();
		}
	}
	m_listAtom.clear();

	KAutoNumGroupPtr* pGroupPtr	= NULL;
	for (itr = m_listGroup.begin(); itr != m_listGroup.end(); itr++)
	{
		pGroupPtr	= (KAutoNumGroupPtr*)*itr;
		ASSERT(pGroupPtr);
		if (pGroupPtr)
		{
			pGroupPtr->Retire(FALSE);
			pGroupPtr->Release();
		}
	}
	m_listGroup.clear();
}

KAutoNumAtomSPtr 
KABGroupInfoMan::AddAtom(tagAUTONUMATOM* pAtom, BOOL bAllocMem)
{
	ASSERT(pAtom);
	KAutoNumAtomSPtr data;
	if (pAtom)
	{
		tagAUTONUMATOM* pData		= NULL;
		KAutoNumAtomPtr* pTemPtr	= NULL;
		_KAtomContainer::iterator itr;
		for (itr = m_listAtom.begin(); itr != m_listAtom.end(); itr++)
		{
			pTemPtr	= (KAutoNumAtomPtr*)(*itr); ASSERT(pTemPtr);
			if (!pTemPtr)
			{
				ASSERT(0);
				m_listAtom.erase(itr);
				continue;
			}
			pData	= *pTemPtr; ASSERT(pData);
			if (pData && (*pData == *pAtom))
			{
				data	= pTemPtr;
				break;
			}
		}
		if (itr == m_listAtom.end())
		{	// ��ͼ��pAtomPtr����list
			if (bAllocMem)
			{
				tagAUTONUMATOM* pTemp	= new tagAUTONUMATOM;
				*pTemp					= *pAtom;
				pAtom					= pTemp;
			}
			KAutoNumAtomPtr* pAtomPtr	= new KAutoNumAtomPtr(pAtom, &m_listAtom);
			m_listAtom.push_back(pAtomPtr);
			data	= pAtomPtr;
		}
	}
	return data;
}

KAutoNumGroupSPtr 
KABGroupInfoMan::AddGroup(tagAUTONUMGROUP* pGroup, BOOL bAllocMem)
{
	ASSERT(pGroup);
	KAutoNumGroupSPtr data;
	if (pGroup)
	{
		if (bAllocMem)
		{
			tagAUTONUMGROUP* pTemp	= new tagAUTONUMGROUP;
			*pTemp					= *pGroup;
			pGroup					= pTemp;
		}
		if (pGroup)
		{
#ifdef _DEBUG
			// ÿ��tagAUTONUMGROUP����ֻ�ܼ���һ��,tagAUTONUMGROUP��������
			KAutoNumGroupPtr* pTemPtr	= NULL;
			_KAtomContainer::iterator itr;
			tagAUTONUMGROUP* pTemp		= NULL;
			for (itr = m_listGroup.begin(); itr != m_listGroup.end(); itr++)
			{
				pTemPtr	= (KAutoNumGroupPtr*)(*itr); ASSERT(pTemPtr);
				if (pTemPtr)
				{
					pTemp	= *pTemPtr; ASSERT(pTemp);
					if (pTemp == pGroup)
					{
						ASSERT(0);
						::MessageBox(NULL, "һ���Զ����group����ֻ�ܼ��뵽������һ��!", "���ش���", MB_OK);
						break;
					}
				}
			}
#endif // _DEBUG

			KAutoNumGroupPtr* pGroupPtr	= new KAutoNumGroupPtr(pGroup, &m_listGroup);
			m_listGroup.push_back(pGroupPtr);
			data	= pGroupPtr;
		}
	}
	return data;
}

BOOL __IsOldGroupInfoValid(int nType, int nStyle, int nLevel, int nStartNumber)
{
	if (nType != defTYPE_AUTONUMBER && nType != defTYPE_BULLET)
		return FALSE;
	if (nStyle < AN_MINSTYLE || nStyle > AN_MAXSTYLE)
		return FALSE;
	if (nLevel < defMINLEVEL || nLevel > defMAXLEVEL)
		return FALSE;
	if (nType == defTYPE_AUTONUMBER)
	{
		if (nStartNumber < defKSTARTNUMBERMIN ||
			nStartNumber > defKSTARTNUMBERMAX)
			return FALSE;
	}

	return TRUE;
}

KAutoNumIOAdapter* KABGroupInfoMan::s_pIOAdapter	= NULL;
KAutoNumIOAdapter* KABGroupInfoMan::SelectIOAdapter(KAutoNumIOAdapter* pNew)
{
	KAutoNumIOAdapter* pOld	= s_pIOAdapter;
	s_pIOAdapter			= pNew;
	return pOld;
}

void KABGroupInfoMan::Serialize(KSArchive& ar)
{	// ����copy/pasteһ�����ֿ�ʱ���ߵ��������
	ASSERT(g_wVersion == VER_WINWPS01);
	if (g_wVersion != VER_WINWPS01)
		return;

	// {{ wps2002-io-autonum, old version serialize, by tsingbo
	if (ar.IsStoring())
	{
		ASSERT(FALSE);		//@@ todo
/*
		ASSERT(g_fCopyPasteProc);
		ASSERT(s_pIOAdapter);
		if (s_pIOAdapter)
		{
			s_pIOAdapter->Clear();
			int nAtomSize	= GetAtomSize();
			ar << nAtomSize;

			KAutoNumAtomSPtr spAtom(NULL);
			int nIndex	= 0;

			const AUTONUMATOM* pAtom	= NULL;
			AUTONUMATOM AtomTem;
			AUTONUMATOM_FORIO AtomIO;
			ATOMPOS posAtom				= GetFirstAtomPos();
			ATOMPOS posAtomEnd			= GetEndAtomPos();
			for (nIndex	= 0; posAtom != posAtomEnd; nIndex++)
			{
				spAtom = GetNextAtom(posAtom);
				pAtom	= GetAtom_FromAtomSPtr(spAtom); ASSERT(pAtom);
				if (!pAtom)
				{
					pAtom	= &AtomTem;
				}
				AtomIO	= *pAtom;
				//ar.Write(&AtomIO, sizeof(AtomIO));
				ar << AtomIO;
				VERIFY(SUCCEEDED(s_pIOAdapter->AddAtomSPtrKey(spAtom, nIndex)));
			}

			int nGroupSize	= GetGroupSize();
			ar << nGroupSize;

			int nLevelCount				= AUTONUMGROUP::GetLevelCount();
			int* pGroupIDs				= new int[nLevelCount];

			GROUPPOS posGroup			= GetFirstGroupPos();
			GROUPPOS posGroupEnd		= GetEndGroupPos();
			KAutoNumAtomSPtr spAtomTem(NULL);
			KAutoNumGroupSPtr spGroup(NULL);
			int nLevelIndex				= 0;
			for (nIndex	= 0; posGroup != posGroupEnd; nIndex++)
			{
				spGroup = GetNextGroup(posGroup);
				ASSERT(spGroup);
				if (!spGroup)
				{
					::memset(pGroupIDs, 0, sizeof(int) * nLevelCount);
				}
				else
				{
					for (nLevelIndex = 0; nLevelIndex < nLevelCount; nLevelIndex++)
					{
						spAtomTem	= GetAtomSPtr_FromGroupSPtr(spGroup, nLevelIndex);
						s_pIOAdapter->GetAtomIDValue(spAtomTem, pGroupIDs[nLevelIndex]);
					}
				}
				ar << nLevelCount;
				ar.Write(pGroupIDs, sizeof(int) * nLevelCount);
				VERIFY(SUCCEEDED(s_pIOAdapter->AddGroupSPtrKey(spGroup, nIndex)));
			}

			if (pGroupIDs)
			{
				delete[] pGroupIDs;
				pGroupIDs	= NULL;
			}
		}
*/
	}
	else
	{
		int nAtomSize	= 0;
		int nGroupSize	= 0;
		int nIndex		= 0;
		if (!g_fCompoundFile)
		{
			/***************************************************************************/
			//	Purpose	: If not copy paste operate used the old?
			//	History	:
			//			Cony.Zhou 1.0 15-5-2003			
			/***************************************************************************/			
		//	if(!g_fCopyPasteProc)
			{
				ASSERT(s_pIOAdapter);
				if (s_pIOAdapter)
					s_pIOAdapter->Clear();
				int nType			= 0;
				int nStyle			= 0;
				int nLevel			= 0;
				int nStartNumber	= 0;
				
				ar >> nGroupSize;
				
				KAutoNumAtomSPtr spAtom;
				KAutoNumGroupSPtr spGroup;
				AUTONUMATOM AtomData;
				AUTONUMGROUP GroupData;
				int nLevelCount	= AUTONUMGROUP::GetLevelCount();
				int nLevelIndex	= 0;
				for (nIndex = 0; nIndex < nGroupSize; nIndex++)
				{
					ar >> nType;
					ar >> nStyle;
					ar >> nLevel;
					ar >> nStartNumber;
					if (FALSE == __IsOldGroupInfoValid(nType, nStyle, nLevel, nStartNumber))
					{
						ASSERT(0);
						nType			= defTYPE_AUTONUMBER;
						nStyle			= 1;
						nLevel			= 0;
						nStartNumber	= 1;
					}
					VERIFY(g_MakeupAutoNumAtomFromOldInfo(&AtomData, nType, nStyle, nStartNumber, nLevel, TRUE));
					
					// ���ɶ�Ӧ��group,����ӳ����ϵ������,������pool���¶��е�����
					spAtom	= AddAtom(&AtomData, TRUE); ASSERT(spAtom);
					for (nLevelIndex = 0; nLevelIndex < nLevelCount; nLevelIndex++)
					{
						VERIFY(SUCCEEDED(GroupData.ChangeSpecialLevelData(nLevelIndex, spAtom)));
					}
					spGroup	= AddGroup(&GroupData, TRUE); ASSERT(spGroup);
					if (s_pIOAdapter)
					{
						VERIFY(SUCCEEDED(s_pIOAdapter->AddGroupIDKey(nIndex, spGroup)));
					}
					// �Ѷ�Ӧ��nLevel��������,������pool�ϵ��ε�����������
					if (s_pIOAdapter)
					{
						VERIFY(SUCCEEDED(s_pIOAdapter->AddOldGroupIDKey(nIndex, nLevel)));
					}
				}
			}
/*
			else
			{
				ASSERT(FALSE);
				if (s_pIOAdapter)
				{
					ar >> nAtomSize;

					AUTONUMATOM_FORIO AtomIO;
					AUTONUMATOM AtomData;
					KAutoNumAtomSPtr spAtom;
					for (nIndex = 0; nIndex < nAtomSize; nIndex++)
					{
						//ar.Read(&AtomIO, sizeof(AtomIO));
						ar >> AtomIO;
						AtomData	= AtomIO;
						spAtom	= AddAtom(&AtomData, TRUE); ASSERT(spAtom);
						VERIFY(SUCCEEDED(s_pIOAdapter->AddAtomIDKey(nIndex, spAtom)));
					}
					
					ar >> nGroupSize;
					
					AUTONUMGROUP GroupData;
					KAutoNumGroupSPtr spGroup;
					int nLevelCount		= AUTONUMGROUP::GetLevelCount();
					int nReadLevelCount	= 0;
					int* pGroupIDs		= new int[nLevelCount];
					int nLevelIndex		= 0;
					for (nIndex = 0; nIndex < nGroupSize; nIndex++)
					{
						ar >> nReadLevelCount; ASSERT(nReadLevelCount == nLevelCount);
						ar.Read(pGroupIDs, sizeof(int) * nLevelCount);
						nReadLevelCount	= min(nReadLevelCount, nLevelCount);
						for (nLevelIndex = 0; nLevelIndex < nReadLevelCount; nLevelIndex++)
						{
							s_pIOAdapter->GetAtomSPtrValue(pGroupIDs[nLevelIndex], spAtom);
							GroupData.ChangeSpecialLevelData(nLevelIndex, spAtom);
						}
						for (; nLevelIndex < nLevelCount; nLevelIndex++)
						{
							GroupData.ChangeSpecialLevelData(nLevelIndex, spAtom);
						}
						spGroup	= AddGroup(&GroupData, TRUE); ASSERT(spGroup);
						VERIFY(SUCCEEDED(s_pIOAdapter->AddGroupIDKey(nIndex, spGroup)));
					}
					if (pGroupIDs)
					{
						delete[] pGroupIDs;
						pGroupIDs	= NULL;
					}
				}
			}
*/
		}
		else
		{
			ASSERT(FALSE);
/*
			ASSERT(g_fCopyPasteProc);
			ASSERT(s_pIOAdapter);
			if (s_pIOAdapter)
			{
				ar >> nAtomSize;

				AUTONUMATOM_FORIO AtomIO;
				AUTONUMATOM AtomData;
				KAutoNumAtomSPtr spAtom;
				for (nIndex = 0; nIndex < nAtomSize; nIndex++)
				{
					//ar.Read(&AtomIO, sizeof(AtomIO));
					ar >> AtomIO;
					AtomData	= AtomIO;
					spAtom	= AddAtom(&AtomData, TRUE); ASSERT(spAtom);
					VERIFY(SUCCEEDED(s_pIOAdapter->AddAtomIDKey(nIndex, spAtom)));
				}

				ar >> nGroupSize;

				AUTONUMGROUP GroupData;
				KAutoNumGroupSPtr spGroup;
				int nLevelCount		= AUTONUMGROUP::GetLevelCount();
				int nReadLevelCount	= 0;
				int* pGroupIDs		= new int[nLevelCount];
				int nLevelIndex		= 0;
				for (nIndex = 0; nIndex < nGroupSize; nIndex++)
				{
					ar >> nReadLevelCount; ASSERT(nReadLevelCount == nLevelCount);
					ar.Read(pGroupIDs, sizeof(int) * nLevelCount);
					nReadLevelCount	= min(nReadLevelCount, nLevelCount);
					for (nLevelIndex = 0; nLevelIndex < nReadLevelCount; nLevelIndex++)
					{
						s_pIOAdapter->GetAtomSPtrValue(pGroupIDs[nLevelIndex], spAtom);
						GroupData.ChangeSpecialLevelData(nLevelIndex, spAtom);
					}
					for (; nLevelIndex < nLevelCount; nLevelIndex++)
					{
						GroupData.ChangeSpecialLevelData(nLevelIndex, spAtom);
					}
					spGroup	= AddGroup(&GroupData, TRUE); ASSERT(spGroup);
					VERIFY(SUCCEEDED(s_pIOAdapter->AddGroupIDKey(nIndex, spGroup)));
				}
				if (pGroupIDs)
				{
					delete[] pGroupIDs;
					pGroupIDs	= NULL;
				}
			}
*/
		}
	}
}

// -------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
// ���ܣ�				��patch2ǰ�ı����Ϣ����һ���°��ŵ�atom�ڴ��ʽ
// ˵����				nOldAutoNumLevelδʹ��,����Ӧ���°�Ķ���������
/////////////////////////////////////////////////////////////////////////////
BOOL g_MakeupAutoNumAtomFromOldInfo(AUTONUMATOM* pAtom, 
									int nOldAutoNumType, 
									int nOldAutoNumStyle, 
									int nOldAutoNumStartNum, 
									int nOldAutoNumLevel, 
									BOOL bUseFirSenAttrib/*=TRUE*/)
{
	ASSERT(pAtom);
	if (!pAtom)
		return FALSE;

#ifdef WPP_ONLY
	pAtom->lAutoNumAlignHorz				= enumAutoNumHorzposLeft2Indent | enumAutoNumHorzposMid2Text;
#else
	pAtom->lAutoNumAlignHorz				= enumAutoNumHorzposLeft2Indent | enumAutoNumHorzposLeft2Text;
#endif //WPP_ONLY

	pAtom->lAutoNumAlignVert				= enumAutoNumVertpos2LineMid;
	pAtom->lAutoNumNormalTextToFirstIndent	= defKTABLENGTH;
	pAtom->lAutoNumMinDistanceToNormalText	= 0;

	pAtom->lAutoNumStep						= 1;

	if (bUseFirSenAttrib)
		pAtom->lAutoNumCharAttribFlag	= enumAutoNumShowUseFirSenAttrAll;
	else
		pAtom->lAutoNumCharAttribFlag	= enumAutoNumShowUseOwnAttrib;

	static LPCWSTR s_wcsBullet[] = 
	{
		L"��",	L"��",	L"��",	L"��",
		L"��",	L"��",	L"��"
	};

	/*
	static WCHAR s_wcsFormatBullet[] = L"&[B]";
	static LPCWSTR s_wcsFormat[] =
	{
		L"&[B]��",	L"��&[B]��",	L"&[B]��",	L"&[B])",
		L"(&[B])",	L"&[B].",	L"&[B]."
	};
	*/
	static WCHAR s_wcsFormatBullet[2]	= { L'\xffff' };
	const WCHAR wToken					= L'0';
	static LPCWSTR s_wcsFormat[]	=
	{
		L"\xffff��",	L"��\xffff��",	L"\xffff.",	L"\xffff)",
		L"(\xffff)",	L"\xffff.",	L"\xffff."
	};

	static WCHAR s_wcsDBNum0[] = L"0";			// Gen
	static WCHAR s_wcsDBNum1[] = L"[DBNum1]0";	// ����Сд
	static WCHAR s_wcsAsciiUpr[] = L"[DBNum6]0";
	static WCHAR s_wcsAsciiLwr[] = L"[DBNum7]0";
	static LPCWSTR s_wcsContent[] =
	{
		s_wcsDBNum1,	s_wcsDBNum1,	s_wcsDBNum0,	s_wcsDBNum0,
		s_wcsDBNum0,	s_wcsAsciiUpr,	s_wcsAsciiLwr
	};

	// make up atomdata
	switch (nOldAutoNumType)
	{
	case defTYPE_BULLET:
		pAtom->lAutoNumType	= enumAutoNumTypeBulletChar;
	#ifdef WPP_ONLY
		pAtom->lAutoNumCharShowScale	= 37; //37%,2002��01��������
	#else
		pAtom->lAutoNumCharShowScale	= 83; //83%,2002��01��������
	#endif //WPP_ONLY
		break;
	case defTYPE_AUTONUMBER:
		pAtom->lAutoNumType				= enumAutoNumTypeNumbered;
		pAtom->lAutoNumCharShowScale	= 100;
		break;
	case defTYPE_UNKNOWN:
	default:
		ASSERT(0);
		pAtom->lAutoNumType				= enumAutoNumTypeUnknown;
		pAtom->lAutoNumCharShowScale	= 100;
		//break;
		return FALSE;
	}
	ASSERT(0 <= nOldAutoNumStyle && BMPBUTTONNUMBER > nOldAutoNumStyle);
	if (0 >= nOldAutoNumStyle || (BMPBUTTONNUMBER - 1) < nOldAutoNumStyle)
	{
		// ɾ���
		pAtom->lAutoNumType	= enumAutoNumTypeUnknown;
		return FALSE;
	}
	pAtom->lAutoNumStartAt	= nOldAutoNumStartNum;
	::memset(pAtom->twAutoNumFormat,	0, sizeof(TEXTWORD) * defMAXAUTONUMFORMATLEN);
	::memset(pAtom->twAutoNumContent,	0, sizeof(TEXTWORD) * defMAXAUTONUMCONTENTLEN);
	if (defTYPE_AUTONUMBER == nOldAutoNumType)
	{	//�Զ����
		KSTextString strFormat(s_wcsFormat[nOldAutoNumStyle - 1]);
		int nStrSize	= strFormat.GetTextSize();
		nStrSize		= min(nStrSize, defMAXAUTONUMFORMATLEN);
		::memcpy(pAtom->twAutoNumFormat, strFormat.GetData(), sizeof(TEXTWORD) * nStrSize);

		KSTextString Tem(s_wcsContent[nOldAutoNumStyle - 1]);
		::memcpy(pAtom->twAutoNumContent, Tem.GetData(), sizeof(TEXTWORD) * Tem.GetTextSize());
	}
	else
	{	//��Ŀ����
		KSTextString strFormat(s_wcsFormatBullet);
		int nStrSize	= strFormat.GetTextSize();
		nStrSize		= min(nStrSize, defMAXAUTONUMFORMATLEN);
		::memcpy(pAtom->twAutoNumFormat, strFormat.GetData(), sizeof(TEXTWORD) * nStrSize);

		KSTextString Tem(s_wcsBullet[nOldAutoNumStyle - 1]);
		::memcpy(pAtom->twAutoNumContent, Tem.GetData(), sizeof(TEXTWORD) * Tem.GetTextSize());
	}

	return TRUE;
}

BOOL g_MakeupOldInfoFromAutoNumAtom(const AUTONUMATOM* pAtom, 
									int& nOldAutoNumType, 
									int& nOldAutoNumStyle, 
									int& nOldAutoNumStartNum, 
									int& nOldAutoNumLevel)
{
	static LPCWSTR s_wcsBullet[] = 
	{
		L"��",	L"��",	L"��",	L"��",
		L"��",	L"��",	L"��"
	};

	static WCHAR s_wcsDBNum0[] = L"0";			// Gen
	static WCHAR s_wcsDBNum1[] = L"[DBNum1]0";	// ����Сд
	static WCHAR s_wcsAsciiUpr[] = L"[DBNum6]0";
	static WCHAR s_wcsAsciiLwr[] = L"[DBNum7]0";
	static LPCWSTR s_wcsContent[] =
	{
		s_wcsDBNum1,	s_wcsDBNum1,	s_wcsDBNum0,	s_wcsDBNum0,
		s_wcsDBNum0,	s_wcsAsciiUpr,	s_wcsAsciiLwr
	};
	static WCHAR s_wcsFrontSmallBrachet	= L'(';
	static WCHAR s_wcsBackSmallBrachet	= L')';
	static WCHAR s_wcsFrontBigBrachet	= L'��';
	WCHAR wcsFrontChar					= L'\0';
	WCHAR wcsBackChar					= L'\0';
	BOOL bGetNumberFormat				= FALSE;

	BOOL bRet			= TRUE;
	nOldAutoNumStyle	= 1;
	int nIndex			= 0;
	WCHAR wcContent[defMAXAUTONUMCONTENTLEN + 1];
	::memset(wcContent, 0, sizeof(wcContent[0]) * (defMAXAUTONUMCONTENTLEN + 1));
	TEXTWORD twChar		= 0;
	for (nIndex = 0; nIndex < defMAXAUTONUMCONTENTLEN; nIndex++)
	{
		twChar				= pAtom->twAutoNumContent[nIndex];
		wcContent[nIndex]	= twChar & 0xFFFF;
		if (!wcContent[nIndex])
			break;
	}
	switch (pAtom->lAutoNumType)
	{
	case enumAutoNumTypeBulletPic:
		nOldAutoNumStyle	= 1;
		nOldAutoNumType		= defTYPE_BULLET;
		break;
	case enumAutoNumTypeBulletChar:
		nOldAutoNumType	= defTYPE_BULLET;
		for (nIndex = 0; nIndex < sizeof(s_wcsBullet) / sizeof(s_wcsBullet[0]); nIndex++)
		{
			if (!::wcscmp(wcContent, s_wcsBullet[nIndex]))
			{
				nOldAutoNumStyle	= nIndex + 1;
				break;
			}
		}
		break;
	case enumAutoNumTypeNumbered:
		nOldAutoNumType	= defTYPE_AUTONUMBER;
		for (nIndex = 0; nIndex < sizeof(s_wcsContent) / sizeof(s_wcsContent[0]); nIndex++)
		{
			if (!nIndex)
				wcsFrontChar	= wcContent[nIndex];
			if (bGetNumberFormat)
			{
				wcsBackChar	= wcContent[nIndex];
				switch (nOldAutoNumStyle)
				{
				case 1:			// һ`
					if (s_wcsFrontBigBrachet == wcsFrontChar)
						++nOldAutoNumStyle;
					break;
				case 2:			// ��һ��
					break;
				case 3:			// 1.
					if (s_wcsFrontSmallBrachet == wcsFrontChar)
						++nOldAutoNumStyle;
					if (s_wcsBackSmallBrachet == wcsBackChar)
						++nOldAutoNumStyle;
					break;
				case 4:			// 1)
					break;
				case 5:			// (1)
					break;
				case 6:			// A.
					break;
				case 7:			// a.
					break;
				default:
					break;
				}
				break;
			}
			if (!::wcscmp(wcContent, s_wcsContent[nIndex]))
			{
				nOldAutoNumStyle	= nIndex + 1;
				bGetNumberFormat	= TRUE;
			}
		}
		break;
	case enumAutoNumTypeUnknown:
	default:
		ASSERT(0);
		nOldAutoNumType	= defTYPE_UNKNOWN;
		bRet			= FALSE;
		break;
	}
	if (nOldAutoNumStyle <= 0 || 
		nOldAutoNumStyle > 7)
	{
		ASSERT(0);
		nOldAutoNumStyle	= 1;
	}
	nOldAutoNumStartNum	= pAtom->lAutoNumStartAt;
	nOldAutoNumLevel	= 0;

	return bRet;
}
