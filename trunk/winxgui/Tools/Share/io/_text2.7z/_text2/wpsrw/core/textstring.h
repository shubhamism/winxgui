/* -------------------------------------------------------------------------
//	�ļ���		��	textstring.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 17:10:41
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXTSTRING_H__
#define __TEXTSTRING_H__

// -------------------------------------------------------------------------

#define DEFAULT_TEXTSTRING_BUFFERSIZE			128
#define FREEMEMSPACE							10

typedef struct tagKSTEXTSTRINGDATA
{
	TEXTWORD	twBufSize;							// ���ֻ��������ڴ��С
	LPTEXTWORD	lptwData;							// ָ�򻺳����ڴ�ָ��
	LPTEXTWORD	lptwTextBufOrg;						// ָ�򻺳��������ֵĿ�ʼָ��
	LPTEXTWORD	lptwTextBufEnd;						// ָ�򻺳��������ֵ�ĩβָ��
	
	void Reset()
	{
		lptwData = lptwTextBufOrg = lptwTextBufEnd = NULL;
		twBufSize = 0;
	}

}KSTextStringData, *LPKSTextStringData;

// -------------------------------------------------------------------------
// class KSWPSTextString

int KCP_StringToTextWord(LPTEXTWORD lptw, LPCWSTR lpsz, int=-1);

#define KSWPSTextString KSTextString 

class KSTextString
{
private:
	KSTextStringData m_tsData;
	
	void TextStringCat(LPTEXTWORD ptw, int nCount);
	void AllocBuffer(int nSize);
	void Init(int nBuffersize)
	{
		memset(&m_tsData, 0, sizeof(KSTextStringData));
		AllocBuffer(nBuffersize);
		if (!m_tsData.lptwData)
		{
			m_tsData.Reset();
			return;
		}
		*m_tsData.lptwTextBufOrg = 0;
	}
	void UnInit()
	{
		if (m_tsData.lptwData)
			delete []m_tsData.lptwData;
		m_tsData.Reset();
	}
	
public:
	KSTextString()
	{
		Init(DEFAULT_TEXTSTRING_BUFFERSIZE);
	}
	~KSTextString()
	{
		UnInit();
	}
	KSTextString(LPCSTR lpsz)						// from an ANSI string (converts to TCHAR)
	{
		Init(DEFAULT_TEXTSTRING_BUFFERSIZE);
		*this += lpsz;
	}
	KSTextString(LPCWSTR lpsz)						// from an ANSI string (converts to TCHAR)
	{
		Init(DEFAULT_TEXTSTRING_BUFFERSIZE);
		*this += lpsz;
	}
	KSTextString(LPTEXTWORD pWord, int nLength, int nBegin = 0)
	{
		Init(DEFAULT_TEXTSTRING_BUFFERSIZE);
		Insert(0, pWord + nBegin, nLength);
	}
	KSTextString(const KSTextString& stringSrc)
	{
		Init(DEFAULT_TEXTSTRING_BUFFERSIZE);
		*this = stringSrc;
	}


	int CatCopy(LPTEXTWORD ptw, int nCount)
	{
		TextStringCat(ptw, nCount);
		return GetTextSize();
	}
	
	TEXTWORD operator[](int nIndex) const // return single character at zero-based index
	{
		ASSERT(nIndex >= 0 && nIndex < GetTextSize());
		return *(m_tsData.lptwTextBufOrg + nIndex);
	}
	
	TEXTWORD GetBufSize() const { return m_tsData.twBufSize; } // ��������С
	int GetTextSize() const	{ return m_tsData.lptwTextBufEnd - m_tsData.lptwTextBufOrg; } // ���ݴ�С
	LPTEXTWORD GetData() { return m_tsData.lptwTextBufOrg; }
	LPCTEXTWORD GetData() const { return m_tsData.lptwTextBufOrg; }
	LPTEXTWORD GetBuffer(int nSize);
	
	int Insert(int nIndex, LPCTEXTWORD ptw, int nSize);
	int Insert(int nIndex, LPCSTR pstr, int=-1);	// insert substring at zero-based index; concatenates if index is past end of string
	int Delete(int nIndex, int nCount = 1);// delete nCount characters starting at zero-based index
	
	BOOL IsEmpty() const
	{
		return m_tsData.lptwTextBufOrg == m_tsData.lptwTextBufEnd;
	}
	void Empty()									// clear contents to empty
		{ m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufOrg = m_tsData.lptwData; }
	void Clear() // clear contents to empty
	{
		m_tsData.lptwTextBufEnd = m_tsData.lptwTextBufOrg = m_tsData.lptwData;
	}
	
	UINT Read(KSArchive& ar, WORD wSize); // ����һ��WORD�ַ���
	void GBKToUnicode();
	
	// overloaded assignment
	operator LPCTEXTWORD() const
		{ return m_tsData.lptwTextBufOrg; }
	
	const KSTextString& operator=(const KSTextString& stringSrc);		// ref-counted copy from another KSTextString
	const KSTextString& operator=(WCHAR ch);							// set string content to single character
	const KSTextString& operator=(LPCWSTR lpsz);						// copy string content from ANSI string (converts to TCHAR)
	const KSTextString& operator=(LPCSTR lpsz);							// copy string content from ANSI string (converts to TCHAR)
	
	friend KSArchive& operator<<(KSArchive& ar, const KSWPSTextString& data);
	friend KSArchive& operator>>(KSArchive& ar, KSWPSTextString& data);
	
	const KSTextString& operator+=(TEXTWORD wd)
	{
		TextStringCat(&wd, 1);
		return *this;
	}	
	const KSTextString& operator+=(LPCWSTR lpsz)						// concatenate a UNICODE character after converting it to TCHAR
	{
		ASSERT(lpsz == NULL || AfxIsValidString(lpsz));
		if (!lpsz)
			return *this;
//	#pragma prompt("no this way!")
		int nLength = wcslen(lpsz);
		if (nLength <= 0)
			return *this;
		LPTEXTWORD tw = new TEXTWORD[nLength]; ASSERT(tw);
		int nSize = KCP_StringToTextWord(tw, lpsz);
		TextStringCat(tw, nSize);
		delete []tw;

		return *this;
	}

	const KSTextString& operator+=(LPCSTR lpsz);						// concatenate a UNICODE character after converting it to TCHAR
	const KSTextString& operator+=(const KSTextString& string);			// concatenate from another KSTextString

	friend KSTextString AFXAPI operator+(const KSTextString& string1, const KSTextString& string2);
	
	void ConCatCopy(LPTEXTWORD, int, LPTEXTWORD, int);
	void AssignCopy(LPTEXTWORD, int);

	int Find(LPCSTR lpszSub, int nStart = 0) const;
	
	// simple sub-string extraction
	KSTextString Mid(int nFirst, int nCount) const;	// return nCount characters starting at zero-based nFirst
	KSTextString Mid(int nFirst) const;				// return all characters starting at zero-based nFirst
	KSTextString Left(int nCount) const;			// return first nCount characters in string
	KSTextString Right(int nCount) const;			// return nCount characters from end of string
};

// -------------------------------------------------------------------------

typedef int (CALLBACK* SPECIALCALLPROCESS)(int&, LPCTEXTWORD);

int KCP_WordToTextWord(LPTEXTWORD lptw, LPWORD lpw, int nLength);
int KCP_TextWordToString(LPTSTR lpsz, int nBufSize, LPCTEXTWORD lptw, int nLength,
						 TEXTWORD twSpWord, SPECIALCALLPROCESS pCall);
						 
inline void TextStringToString(CString& str, LPCTEXTWORD lptw, int nLen)
{
	LPTSTR lpstr = str.GetBuffer(nLen * sizeof(TEXTWORD) + 1); 
	KCP_TextWordToString(lpstr, nLen * sizeof(TEXTWORD) + 1, lptw, nLen, 0, NULL);
	str.ReleaseBuffer();
}

inline void TextStringToString(CString& str, KSTextString& tstr)
{
	int nLen = tstr.GetTextSize();
	LPCTEXTWORD lptw = tstr.GetData();
	LPTSTR lpstr = str.GetBuffer(nLen * sizeof(TEXTWORD) + 1); 
	KCP_TextWordToString(lpstr, nLen * sizeof(TEXTWORD) + 1, lptw, nLen, 0, NULL);
	str.ReleaseBuffer();
}

// -------------------------------------------------------------------------
//ģ��BOOL SBCSToDBCS (LPCTSTR lpSrc, LPWORD lpDest);
//	����ֵ�������ַ�����

#define	FIRSTCHAR		0X20		// ASCII���е�һ���ɴ�ӡ�ַ�
#define	LASTCHAR		0X7F		// ASCII�������һ���ɴ�ӡ�ַ�
#define	LASTCHAREX		0XFF		// ASCII�������һ���ɴ�ӡ�ַ�

inline int MStringToDMString(CString& str)
{
	LPCTSTR lpSrc = str;
	CString strD;
	BYTE byChar;
	while ((byChar = *lpSrc++) != 0)
	{
		if (byChar > LASTCHAR)	// �����ַ�
		{
			strD += byChar;
			byChar = *lpSrc++;
			if (byChar == 0x0A)	//	���� >80 �����ַ�
			{
				strD += (char)0;
			}
			else if (byChar == 0)
			{ 	
				strD += (char)0;
				ASSERT(FALSE);
				break; 
			}
			else
				strD += byChar;
		}
		else if (byChar != '\n')// �����ַ�
		{	
			strD += byChar;
			strD += (char)0;
		}
	}
	int nCnt = strD.GetLength();
	str = strD;
	return nCnt;
}

// -------------------------------------------------------------------------
//������������ʵ����һ�ֺܲ��õ����ݴ��̷������� WPS2001 ���԰��ѳ�
//Ϊ�˱����ļ������ԣ�ֻ��������(wxb)

#define DEFAULT_TEXT_FLAG	((TEXTWORD)(0x39FE39FE))

inline void MakeTextStringWithBOOL(KSTextString& strText, BOOL bValue)
{
	if (bValue)
		strText += DEFAULT_TEXT_FLAG;
}

inline BOOL ParseTextStringWithBOOL(KSTextString& strText)
{
	BOOL bResult = FALSE;
	int nLen = strText.GetTextSize();
	if (nLen > 0 && DEFAULT_TEXT_FLAG == strText[nLen - 1])
	{
		bResult = TRUE;
		strText.Delete(nLen - 1);
	}
	return bResult;
}

// -------------------------------------------------------------------------
// class KSTextStringList

class KSTextStringList
{
public:
	KSTextStringList();
	~KSTextStringList();

protected:
	struct KSNode
	{
		KSNode* pNext;
		KSNode* pPrev;
		KSTextString textstring;
	};

	KSNode* m_pNodeHead;
	KSNode* m_pNodeTail;
	int m_nCount;

	// node operation
	KSNode* NewNode(KSNode*, KSNode*);
	void FreeNode(KSNode*);

public:
	void RemoveAll();
	void Serialize(KSArchive&);

public:
	// Attributes (head and tail)
	int GetCount() const { return m_nCount; }
	BOOL IsEmpty() const { return m_nCount == 0; }

	// peek at head or tail
	KSTextString& GetHead() { return m_pNodeHead->textstring; }
	KSTextString GetHead() const { return m_pNodeHead->textstring; }
	KSTextString& GetTail() { return m_pNodeTail->textstring; }
	KSTextString GetTail() const { return m_pNodeTail->textstring; }
	// Operations
	KSTextString RemoveHead();
	KSTextString RemoveTail();

	// add before head or after tail
	POSITION AddHead(KSTextString& newElement);
	POSITION AddTail(KSTextString& newElement);

	// add another list of elements before head or after tail
	void AddHead(KSTextStringList* pNewList);
	void AddTail(KSTextStringList* pNewList);

	// iteration
	POSITION GetHeadPosition() const { return (POSITION)m_pNodeHead; }
	POSITION GetTailPosition() const { return (POSITION)m_pNodeTail; }
	KSTextString  GetNext(POSITION& rPosition) const; // return *Position++
	KSTextString  GetPrev(POSITION& rPosition) const; // return *Position--

	// getting/modifying an element at a given position
//	KSTextString& GetAt(POSITION position);
	KSTextString GetAt(POSITION) const;
	void SetAt(POSITION, KSTextString&);
//	void SetAt(POSITION pos, const CString& newElement);

	void RemoveAt(POSITION);

	// inserting before or after a given position
	POSITION InsertBefore(POSITION position, KSTextString& newElement);
	POSITION InsertAfter(POSITION position, KSTextString& newElement);


	// helper functions (note: O(n) speed)
	POSITION Find(KSTextString&, POSITION = NULL) const;
						// defaults to starting at the HEAD
						// return NULL if not found
	POSITION FindIndex(int nIndex) const;				// get the 'nIndex'th element (may return NULL)
};

// -------------------------------------------------------------------------

#endif /* __TEXTSTRING_H__ */
