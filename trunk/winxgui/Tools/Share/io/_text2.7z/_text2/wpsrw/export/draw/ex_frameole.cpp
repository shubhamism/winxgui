/* -------------------------------------------------------------------------
//	�ļ���		��	ex_frameole.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-25 10:59:54
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_frameole.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

KDWBlip CFrameOLE_Export::GetObjectPresImage(CShape_Context& context, IStorage* pStgObj,
											 DVASPECT aspect)
{
	ASSERT(pStgObj);
	HRESULT hr;
	KDWBlip blip;
	ks_stdptr<IPersistStorage> spPstStgPres;
	hr = CreateDataCache(NULL, CLSID_NULL, __uuidof(spPstStgPres), (void**)&spPstStgPres);
	ASSERT(SUCCEEDED(hr));
	hr = spPstStgPres->Load(pStgObj);
	ASSERT(SUCCEEDED(hr));
	ks_stdptr<IDataObject> spDataObj;
	hr = spPstStgPres->QueryInterface(__uuidof(spDataObj), (void**)&spDataObj);
	ASSERT(SUCCEEDED(hr));
	FORMATETC fmtetc = {CF_METAFILEPICT, NULL, aspect, -1, TYMED_MFPICT};
	STGMEDIUM stgmed;
	hr = spDataObj->GetData(&fmtetc, &stgmed);
	if(SUCCEEDED(hr))
	{
		METAFILEPICT* metapic = (METAFILEPICT*)_GlobalLock(stgmed.hMetaFilePict);
		size_t cbBits = GetMetaFileBitsEx(metapic->hMF, 0 , NULL);
		BYTE* pBits = new BYTE[cbBits];
		GetMetaFileBitsEx(metapic->hMF, cbBits , pBits);
		blip = context.GetBlipStore().NewBlip(pBits, cbBits, msoblipWMF);
		delete []pBits;
		_GlobalUnlock(stgmed.hMetaFilePict);
		ReleaseStgMedium(&stgmed);
	}
	else//ʧ��,����bitmap
	{
		fmtetc.cfFormat = CF_BITMAP;
		fmtetc.tymed = TYMED_GDI;
		hr = spDataObj->GetData(&fmtetc, &stgmed);
		if(SUCCEEDED(hr))
		{
			
			ks_stdptr<IKsoLockBuffer> spLB;
			hr = gDIBFromDDB(stgmed.hBitmap, &spLB);
			if(SUCCEEDED(hr))
			{
				blip = context.GetBlipStore().NewBlip(msoblipDIB, spLB);
			}
			ReleaseStgMedium(&stgmed);
		}
	}
	if(FAILED(hr))
	{
		blip = context.GetBlipStore().NewBlip();
	}
	return blip;
}


EX_SHAPE_API CFrameOLE_Export::ConvertShape(CShape_Context& context)
{
	ASSERT(m_pClientItem);
	HRESULT hr;
#ifndef WPP_ONLY
	KDWShape oleShape;
	if (!m_pClientItem)
	{
		if (oleShape.Good())
		{
			oleShape.SetProperties(context.m_opt);
			oleShape.SetUDefProperties(context.m_optUDef);
		}
		return;
	}
#else
	MsoShape& oleShape = context.m_shape;
	if (!m_pClientItem)
		return;
#endif
	//
	ks_stdptr<IStorage> spStgObj;
	m_pClientItem->GetStorage(&spStgObj);
	ASSERT(spStgObj);
	
	//��FrameObj�п��ܻ�תͼƬ
	if(context.m_opt.FindProp(msopt_fillBlip) == -1)
	{
		if (spStgObj)
		{
			KDWBlip blip = GetObjectPresImage(context, spStgObj, m_pClientItem->GetDrawAspect());
			if(blip.Good())
			{
#ifndef WPP_ONLY	// wps����ΪͼƬ����ת��, ��wpp����Ϊ����ͼ��
					// ͼƬ�����ͼƬ��msopt_pib
				context.m_opt.AddPropFix(msopt_pib, blip);
#else
				context.m_opt.AddPropFix(msopt_fillBlip, blip);
#endif
				context.m_opt.ForceAddPropBool(msopt_fFilled, TRUE);
				context.m_opt.AddPropFix(msopt_fillType, msofillPicture);
			}
		}
		else
		{
#ifndef WPP_ONLY
				context.m_opt.AddPropFix(msopt_pib, 0);
#else
				context.m_opt.AddPropFix(msopt_fillBlip, 0);
#endif
			context.m_opt.ForceAddPropBool(msopt_fFilled, TRUE);
			context.m_opt.AddPropFix(msopt_fillType, msofillPicture);
		}
	}

	hr = E_FAIL;
	LPOLESTR progid = NULL;
	if(m_pClientItem->m_lpObject)//ʲôbCreated,�ǳ����
	{
		//�õ�progid
		CLSID clsid;
		m_pClientItem->GetClassID(&clsid);
		hr = ProgIDFromCLSID(clsid, &progid);
		if (FAILED(hr))
			hr = StringFromCLSID(clsid, &progid);
	}
	else if (spStgObj)
	{
		STATSTG stat;
		spStgObj->Stat(&stat, STATFLAG_NONAME);
		hr = ProgIDFromCLSID(stat.clsid, &progid);
		if (FAILED(hr))
			hr = StringFromCLSID(stat.clsid, &progid);
	}

	if(hr == S_OK)
	{
#ifndef WPP_ONLY
		CRect rc = GetMrect();
		OLE_OBJTYPE objType = OT_UNKNOWN;
		if (m_pClientItem->m_lpObject)
			objType = m_pClientItem->GetType();
		else
			objType = OT_EMBEDDED;

		if(objType == OT_LINK)
		{
			KDWOleShape theoleShape;
			ks_stdptr<IOleLink> spOleLink;
			hr = m_pClientItem->m_lpObject->QueryInterface(__uuidof(spOleLink), (void**)&spOleLink);
			ASSERT(SUCCEEDED(hr));
			LPOLESTR pwszDisName;
			hr = spOleLink->GetSourceDisplayName(&pwszDisName);
			ASSERT(SUCCEEDED(hr));
			if(context.IsInlineShape())
			{
				theoleShape = context.m_export.AddOleLink(
					WpsShapeToTwip(rc.Width()),
					WpsShapeToTwip(rc.Height()),
					progid, pwszDisName);
			}
			else
			{
				KDWShapeAnchor anchor;
				context.GetAnchorInfo(this, rc, anchor);
				theoleShape = context.m_export.AddOleLink(
					anchor,
					progid, pwszDisName);
			}
			CoTaskMemFree(pwszDisName);
			theoleShape.Persist(spStgObj);
			oleShape = theoleShape;
		}
		else if(objType == OT_EMBEDDED)
		{
			KDWOleShape theoleShape;
			if(context.IsInlineShape())
			{
				theoleShape = context.m_export.AddOleEmbed(
					WpsShapeToTwip(rc.Width()),
					WpsShapeToTwip(rc.Height()),
					progid);
			}
			else
			{
				KDWShapeAnchor anchor;
				context.GetAnchorInfo(this, rc, anchor);
				theoleShape = context.m_export.AddOleEmbed(
					anchor,
					progid);
			}
			theoleShape.Persist(spStgObj);
			oleShape = theoleShape;
		}
		else//OT_STATIC
		{
			if(context.IsInlineShape())
			{
				oleShape = context.m_export.AddInlineShape(
					WpsShapeToTwip(rc.Width()),
					WpsShapeToTwip(rc.Height()),
					FALSE);
			}
			else
			{
				KDWShapeAnchor anchor;
				context.GetAnchorInfo(this, rc, anchor);
				oleShape = context.m_export.AddShape().SetClientAnchor(anchor);
			}
			oleShape.SetShapeType(msosptRectangle);
		}
		
#else//wppת��
		PPT_TypeCode pptTypeCode = PST_UNKNOWN;
		OLE_OBJTYPE wppObjType = m_pClientItem->GetType();
		if(wppObjType == OT_LINK)
			pptTypeCode = PST_ExLink;
		else if(wppObjType == OT_EMBEDDED)
			pptTypeCode = PST_ExEmbed;
		else if(wppObjType == OT_STATIC)
		{
			oleShape.SetShapeType(msosptRectangle);
		}
		if((pptTypeCode == PST_ExLink || pptTypeCode == PST_ExEmbed) && spStgObj)
		{
			_KPPTOleObj* pPptOleObj = (_KPPTOleObj*)context.GetPptDocument().
				GetExObjList()->CreateExObj(pptTypeCode);
			pPptOleObj->m_strProgID = progid;
			pPptOleObj->m_atomExOleObj.drawAspect = DVASPECT_CONTENT;
			{
				ks_stdptr<IStorage> spStg;
				ks_stdptr<ILockBytes> spLockBytes;
				XCreateILockBytesOnHGlobal(NULL, TRUE, &spLockBytes);
				StgCreateDocfileOnILockBytes(spLockBytes,
									 STGM_DIRECT | STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE,
									 0,
									 &spStg);
				spStgObj->CopyTo(0, NULL, NULL, spStg);
				spStg->Commit(STGC_DEFAULT);
				pPptOleObj->m_atomExOleObj.objStgDataRef = 
					context.GetPptDocument().AddOleData(spLockBytes);
			}
			context.GetPptClientData().SetExObjRef(pPptOleObj->GetObjID());
		}
#endif
	}
	if(progid)
		CoTaskMemFree(progid);
#ifndef WPP_ONLY
	if (oleShape.Good())
	{
		oleShape.SetProperties(context.m_opt);
		oleShape.SetUDefProperties(context.m_optUDef);
	}
#endif
}	

// -------------------------------------------------------------------------
// $Log: ex_frameole.cpp,v $
// Revision 1.24  2005/10/08 08:39:51  liupeng
// *** empty log message ***
//
// Revision 1.23  2005/08/20 05:52:59  liupeng
// *** empty log message ***
//
// Revision 1.22  2005/08/17 11:55:07  liupeng
// *** empty log message ***
//
// Revision 1.21  2005/06/22 09:12:51  duanyuluo
// �û����ص�һ���ļ���������һ��STATIC��OLE��ԭ��û�д��������ڸĳ�ͼƬ
//
// Revision 1.20  2005/05/13 07:16:19  tanke
// *** empty log message ***
//
// Revision 1.19  2005/05/13 06:50:18  duanyuluo
// ��û��OLE���ݵ��ĵ�����
//
// Revision 1.18  2005/04/28 02:26:42  tanke
// *** empty log message ***
//
// Revision 1.17  2005/04/27 09:53:18  tanke
// *** empty log message ***
//
// Revision 1.15  2005/04/22 09:34:07  tanke
// *** empty log message ***
//
// Revision 1.14  2005/04/22 07:03:46  zhangqingyuan
// *** empty log message ***
//
// Revision 1.13  2005/04/20 06:45:58  tanke
// *** empty log message ***
//
// Revision 1.12  2005/04/14 13:29:31  tanke
// *** empty log message ***
//
// Revision 1.11  2005/04/09 08:59:07  tanke
// *** empty log message ***
//
// Revision 1.10  2005/04/05 09:06:54  tanke
// *** empty log message ***
//
// Revision 1.9  2005/04/04 07:51:49  tanke
// *** empty log message ***
//
// Revision 1.8  2005/03/30 04:07:18  tanke
// *** empty log message ***
//
// Revision 1.7  2005/01/22 02:26:39  xushiwei
// ���ǵ�win98ƽ̨��GlobalSize(HGLOBAL hGbl)����Ϊ��Ԥ�ڣ�����capacity������size����
// ����ϸ��bug������������ϸ�ڲ������𡣹ʴˣ����Ǿ���ȡ����HGLOBAL�ڴ��֧�֡�
// ������kfc���ṩ����HGLOBAL���ƹ��ܵĺ�������ϸ�ο�: <kfc/allocater/hglobal.h>
//
// Revision 1.6  2005/01/06 08:37:21  wangdong
// *** empty log message ***
//
// Revision 1.5  2004/12/17 08:58:34  xushiwei
// Ϊ֧�־ɰ汾wps��ҳ���������msopt_spPageLocation��չ����(optUDef)��
// �м������anchor����: text_anchor_page_location��
//
