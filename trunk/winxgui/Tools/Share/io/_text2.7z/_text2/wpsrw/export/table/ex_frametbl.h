/* -------------------------------------------------------------------------
//	�ļ���		��	ex_frametbl.h
//	������		��	��־��
//	����ʱ��	��	2004-11-23 15:54:41
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __EX_FRAMETBL_H__
#define __EX_FRAMETBL_H__

#ifndef __EX_WPSDOC_H__
#include "../core/ex_wpsdoc.h"
#endif

#ifndef __EX_SHAPE_H__
#include "../draw/ex_shape.h"
#endif

#ifndef __FRAMETBL_H
#include "table/frametbl.h"
#endif

#ifndef __TABLEOBJ_H
#include "table/tableobj.h"
#endif

// -------------------------------------------------------------------------
struct _CellInfo
{
	KDWCellPr cp;
	int height;//һ���еĵ�Ԫ��߶�����ͬ��
	CTableElement* pEle;
};

class CFrameTable_Export : public CFrameTable
{
	//���಻�ܶ����Ա�������麯����
public:
	EX_SHAPE_API ConvertShape(CShape_Context& context);
	EX_SHAPE_API GetTablePosAndPr(CShape_Context& context, OUT KDWTablePos& tblPos, OUT KDWRowTablePr& tblPr);
	EX_SHAPE_API GetCellPr(CTableElement* pEle, OUT KDWCellPr& cellPr);
	EX_SHAPE_API AllocCellPr(OUT _CellInfo*& pcp);
	EX_SHAPE_API SetPapxAndChpx(CShape_Context& context, CTableElement* pEle,
								OUT KDWPropBuffer& papx, OUT KDWPropBuffer& chpx);
	BOOL AllocaDiagonal(CTableElement* pEle, OUT std::vector<KDWDiagonal>& vecDiagonal, BOOL* bNeedReverse);
	EX_SHAPE_API AddContent(KDWDocument& docu, KSTextString& kstr, KDWPropBuffer& papxE, KDWPropBuffer& chpxE); 

};

ShapeExportClassDecl(FRAMETable, CFrameTable_Export, CFrameObj_Export);
ShapeExportClassDecl(FRMTableBody, CFrameTable_Export, CFrameObj_Export);

// -------------------------------------------------------------------------

#endif /* __EX_FRAMEOLE_H__ */
