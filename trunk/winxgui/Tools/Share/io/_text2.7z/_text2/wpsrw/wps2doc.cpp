// rtfshapeopt.cpp : Defines the entry point for the console application.
// $Id: wps2doc.cpp,v 1.2 2005/01/07 06:36:17 xushiwei Exp $
//

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define X_NO_AUTOINIT
#define X_NO_DEBUG_STRATEGY
#include <kfc.h>
#include <kso/io/component.h>
#include <kso/io/linklib_wpsrw.h>

int main()
{
	if (__argc < 2)
		return -1;

	LPCWSTR szSrcFile = __wargv[1];

	WCHAR szDestFile[_MAX_PATH];
	wcscpy(szDestFile, szSrcFile);
	wcscat(szDestFile, __X(".doc"));

	printf("processing %S ... ", szSrcFile);
	
	HRESULT hr = E_FAIL;
	try
	{
		hr = WpsConvert(szSrcFile, szDestFile);
	}
	catch (...)
	{
	}

	if (FAILED(hr))
		printf("failed!\n");
	else
		printf("ok!\n");

	return 0;
}

// -------------------------------------------------------------------------
//	$Log: wps2doc.cpp,v $
//	Revision 1.2  2005/01/07 06:36:17  xushiwei
//	��ɡ�
//	
