/* -------------------------------------------------------------------------
//	�ļ���		��	frametext.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-17 19:59:29
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <core/textpool.h>
#include "frametext.h"
#include "ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CFrameText, CFrameObj, 0xA0 | VERSIONABLE_SCHEMA)

/*************************************************************************
���ܣ�	���캯�� (Serializeר��)
*************************************************************************/
CFrameText::CFrameText()
{
	ClearPrivateObjs();
	m_bCommentFrame = FALSE;
	m_pLine = NULL;
	m_pnt = CPoint(0, 0);
	m_wVAlign = TAL_TOP;
	
/*@@todo
	m_rcAutoEnlarge = CRect(0,0,0,0);
	m_bEdited = FALSE;
	m_bEnbaleFrameEnlargeOnLoadFile = FALSE;
	m_pParentTableElement = NULL; */
}

CFrameText::~CFrameText()
{
	DeleteContent();
	if (IsCommentFrame() && m_pLine)
	{
		delete m_pLine;
		m_pLine = NULL;
	}
}

/*************************************************************************
���ܣ�	�ڹ���׶γ�ʼ���ڲ�����
��ڣ�	bCreatePool: �Ƿ���FrameText�ڴ���TextPool����
bFlag: �Ժη�ʽ����TextPool����
*************************************************************************/
void CFrameText::OnInitial(BOOL bCreatePool, BOOL bFlag/*=FALSE*/)
{
	// �����ڲ�ʹ�õĶ���
	TRY
	{
		if (bCreatePool)
		{
			if (bFlag)
				c_pTextPool = new CTextPool(TRUE);
			else
				c_pTextPool = new CTextPool();
		}
		//@@todo
		//c_pTextSite = new CTextSite;
	}
	CATCH_ALL(e)
	{
		TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
		if (c_pTextPool)
			delete c_pTextPool;
		//@@todo
		//if (c_pTextSite)
		//	delete c_pTextSite;
		delete this;
		AfxThrowMemoryException();
	}
	END_CATCH_ALL
	if (c_pTextPool && WPPFRAME == GetWPSObjType())
		c_pTextPool->SetABLenPerLevel(0);
}

void CFrameText::DeleteContent()
{
	if (c_pTextPool)
	{
		delete c_pTextPool; c_pTextPool = NULL;
	}
/*@@todo
	if (c_pTextSite)
	{
		delete c_pTextSite; c_pTextSite = NULL;
	}*/
}

void CFrameText::SetTextLineMode(TextLineMode lm)
{
	ASSERT_VALID(this);
	ASSERT(lm == horz || lm == vertl2r || lm == vertr2l);
	if (c_pTextPool)
	{
		ASSERT_VALID(c_pTextPool);
		c_pTextPool->SetTextLineMode(lm);
	}
	m_LineMode = lm;
}

/*************************************************************************
	���ܣ�	WPS97 file support
*************************************************************************/
void CFrameText::Serialize_97(KSArchive& ar)
{
	CFrameObj::Serialize_97(ar);
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{	// �����ڲ�ʹ�õĶ���(����throw exception)
		ClearPrivateObjs();
		OnInitial(TRUE, TRUE);

		__int16 temp;
		ar >> temp; m_mgInsideType = (CFrameObj::MrgSideType)temp;
		ar >> temp; m_MarginInside.left = temp;
		ar >> temp; m_MarginInside.top = temp;
		ar >> temp; m_MarginInside.right = temp;
		ar >> temp; m_MarginInside.bottom = temp;
		ar >> temp; m_bScriptSheet = (BOOL)temp;
		ar >> s_PrevFrame.wPageNum;
		ar >> s_PrevFrame.wFrameID;
		ar >> s_NextFrame.wPageNum;
		ar >> s_NextFrame.wFrameID;
		ar >> s_ThisFrame.wPageNum;
		ar >> s_ThisFrame.wFrameID;

		// �ж϶���������Ƿ���Ч
		if (m_bScriptSheet != TRUE && m_bScriptSheet != FALSE)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}

		TRY
		{
			c_pTextPool->_Serialize(ar);				// ��ʼ��TextPool
		}
		CATCH_ALL(e)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			DeleteContent();
			THROW_LAST();
		}
		END_CATCH_ALL
		
		ASSERT_VALID(this);
	}
	CWPSObj::SerializeObjType(ar);
}

/*************************************************************************
	���ܣ�	WPS97 file support
*************************************************************************/
void CFrameText::Serialize_98(KSArchive& ar)
{
	CFrameObj::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);

		ar << m_mgInsideType;
		ar << m_MarginInside;
		ar << m_bScriptSheet;
		ar << s_PrevFrame.wPageNum;
		ar << s_PrevFrame.wFrameID;
		ar << s_NextFrame.wPageNum;
		ar << s_NextFrame.wFrameID;
		ar << s_ThisFrame.wPageNum;
		ar << s_ThisFrame.wFrameID;

		ASSERT(c_pTextPool != NULL);
		c_pTextPool->_Serialize(ar);				// ��������
	}
	else
	{
		// �����ڲ�ʹ�õĶ���(����throw exception)
		ClearPrivateObjs();
		OnInitial(TRUE, TRUE);

		ar >> m_mgInsideType;
		ar >> m_MarginInside;
		ar >> m_bScriptSheet;
		ar >> s_PrevFrame.wPageNum;
		ar >> s_PrevFrame.wFrameID;
		ar >> s_NextFrame.wPageNum;
		ar >> s_NextFrame.wFrameID;
		ar >> s_ThisFrame.wPageNum;
		ar >> s_ThisFrame.wFrameID;

		// �ж϶���������Ƿ���Ч
		if (m_bScriptSheet != TRUE && m_bScriptSheet != FALSE)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}

		TRY
		{
			c_pTextPool->_Serialize(ar);				// ��ʼ��TextPool
		}
		CATCH_ALL(e)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			DeleteContent();
			THROW_LAST();
		}
		END_CATCH_ALL
		
		ASSERT_VALID(this);
	}
	CWPSObj::SerializeObjType(ar);
}

void CFrameText::Serialize_01(KSArchive& ar)
{
	//	��ȻĿǰ����������CFrameText::Serialize_98(ar);һ����
	//	������ֱ�ӵ�CFrameText::Serialize_98(ar);��Ϊ����Զ������
	//	�����Serialize_01(ar);
 	CFrameObj::Serialize_01(ar);
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);

		ar << m_mgInsideType;
		ar << m_MarginInside;
		ar << m_bScriptSheet;
		ar << s_PrevFrame.wPageNum;
		ar << s_PrevFrame.wFrameID;
		ar << s_NextFrame.wPageNum;
		ar << s_NextFrame.wFrameID;
		ar << s_ThisFrame.wPageNum;
		ar << s_ThisFrame.wFrameID;

		ASSERT(c_pTextPool != NULL);
		c_pTextPool->_Serialize(ar);				// ��������

		ar << m_wVAlign;
	}
	else
	{
		// �����ڲ�ʹ�õĶ���(����throw exception)
		ClearPrivateObjs();
		OnInitial(TRUE, TRUE);

		ar >> m_mgInsideType;
		ar >> m_MarginInside;
		ar >> m_bScriptSheet;
		ar >> s_PrevFrame.wPageNum;
		ar >> s_PrevFrame.wFrameID;
		ar >> s_NextFrame.wPageNum;
		ar >> s_NextFrame.wFrameID;
		ar >> s_ThisFrame.wPageNum;
		ar >> s_ThisFrame.wFrameID;

		// �ж϶���������Ƿ���Ч
		if (m_bScriptSheet != TRUE && m_bScriptSheet != FALSE)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			AfxThrowArchiveException(CArchiveException::badIndex);
		}

		TRY
		{
			c_pTextPool->_Serialize(ar);				// ��ʼ��TextPool
		}
		CATCH_ALL(e)
		{
			TRACE2("%s %u: Failed.\n", __FILE__, __LINE__);
			DeleteContent();
			THROW_LAST();
		}
		END_CATCH_ALL
		
		ASSERT_VALID(this);

		if (g_fCompoundFile)
			ar >> m_wVAlign;
	}
	CWPSObj::SerializeObjType(ar);
}

//�������ֻҪ��һ��
BOOL CFrameText::GetCalacTextString(KSTextString& strText)
{
	strText.Empty();
	ASSERT_VALID(c_pTextPool);
	for (int nPIndex = 0; nPIndex < c_pTextPool->NumOfParagraphs() && nPIndex <= 0; nPIndex++)
	{
		CParagraph* pParagraph = c_pTextPool->GetParagraph(nPIndex);
		if (pParagraph)
		{
			for (int nSIndex = 0; nSIndex < pParagraph->NumOfSentences(); nSIndex++)
			{
				CSentence* pSentence = pParagraph->GetSentence(nSIndex);
				if (pSentence)
				{
					strText += KSTextString(pSentence->GetDataPtr(), pSentence->GetTextSize());
				}
			}
		}
	}
	return TRUE;
}
// -------------------------------------------------------------------------
