/* -------------------------------------------------------------------------
//	�ļ���		��	sprm.h
//	������		��	���
//	����ʱ��	��	2002-5-27 16:31:01
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __SPRM_H__
#define __SPRM_H__

#define IO_MAKE_SPRM(sgc, isprm, spra)		(((spra) << 14) | ((sgc) << 8) | (isprm))
#define IO_SPRM_SGC(sprm)					(((sprm) >> 8) & 0x1f)
#define IO_SPRM_ISRPM(sprm)					((sprm) & 0xff)
#define IO_SPRM_SPRA(sprm)					((WORD)(sprm) >> 14)

// ȥ�����Ȳ��֣�spra����sprm���롣
#define IO_SPRM_CODE(sprm)					((sprm) & 0x3FFF)
#define IO_MAKE_SPRM_CODE(sgc, isprm, spra)	(((sgc) << 8) | (isprm))

enum KSO_IO_SPRM_SGC	// ��Docһ��
{
	_io_sprm_sgc_none		= 0,
	_io_sprm_sgc_pap		= 1,
	_io_sprm_sgc_chp		= 2,
	_io_sprm_sgc_pic		= 3,
	_io_sprm_sgc_sep		= 4,
	_io_sprm_sgc_tap		= 5,
	_io_sprm_sgc_cc			= 6,			// Common Codes
};

enum KSO_IO_SPRM_SPRA
{
	_io_spra_2bytes			= 0,
	_io_spra_4bytes			= 1,
	_io_spra_8bytes			= 2,
	_io_spra_nbytes			= 3,
	_io_spra_word			= _io_spra_2bytes,
	_io_spra_dword			= _io_spra_4bytes,
	_io_spra_qword			= _io_spra_8bytes,
	_io_spra_variant		= _io_spra_nbytes
};

// ==========================================================================

enum KSO_IO_SPRM_CTRLCODE
{
	// Common Properties
	sprm_cc_ForeColor	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  1, _io_spra_dword),

	// Character Properties
	sprm_ch_CharSet		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 1, _io_spra_word),
	sprm_ch_FontNameDef	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 2, _io_spra_variant),
	sprm_ch_FontNameFE	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 3, _io_spra_variant),

	sprm_ch_FontSize	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 5, _io_spra_variant),
	sprm_ch_FontWeight	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 6, _io_spra_word),
	sprm_ch_FontItalic	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 7, _io_spra_word),
	sprm_ch_ActFontSize	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 8, _io_spra_variant),

	sprm_ch_UpperLine	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 9, _io_spra_variant),
	sprm_ch_UnderLine	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 10, _io_spra_variant),
	sprm_ch_StrikeOut	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 11, _io_spra_variant),
	sprm_ch_Stress		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 12, _io_spra_variant),

	sprm_ch_SSS			=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 13, _io_spra_variant),
	sprm_ch_AspectX		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 14, _io_spra_word),
	sprm_ch_Tracking	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 15, _io_spra_variant),
	sprm_ch_HSS			=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 16, _io_spra_variant),

	sprm_ch_Visible		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 17, _io_spra_word),
	sprm_ch_Revise		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 18, _io_spra_variant),
	sprm_ch_Border		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 19, _io_spra_variant),
	sprm_ch_Fill		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 20, _io_spra_variant),

	sprm_ch_HyperLink	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 21, _io_spra_variant),
	sprm_ch_BookMark	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_chp, 22, _io_spra_variant),

	sprm_pa_LeftIndent	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 1, _io_spra_variant),
	sprm_pa_FirstIndent	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 2, _io_spra_variant),
	sprm_pa_RightIndent	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 3, _io_spra_variant),

	sprm_pa_HorzAlign	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 5, _io_spra_word),
	sprm_pa_VertAlign	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 6, _io_spra_word),

	sprm_pa_LineHeight	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 9, _io_spra_variant),
	sprm_pa_ParaMargin	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 10, _io_spra_variant),
	sprm_pa_PostPMargin	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 11, _io_spra_variant),

	sprm_pa_TabStops	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 13, _io_spra_variant),
	sprm_pa_AutoNumber	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 14, _io_spra_variant),
	sprm_pa_Border		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 15, _io_spra_variant),
	sprm_pa_AutoNumberLevel	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_pap, 16, _io_spra_variant),

	// UNIT_VALUE
	sprm_uval_Unit		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x10, _io_spra_word),
	sprm_uval_Value		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x11, _io_spra_dword),

	// LINE
	sprm_line_Style		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x18, _io_spra_word),
	// ������ɫ��Ϊcc_ForeColor

	// FILL / RECT
	sprm_cc_PenStyle	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x20, _io_spra_dword),
	sprm_cc_BrushStyle	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x21, _io_spra_dword),
	// ǰ��ɫ��Ϊcc_ForeColor
	sprm_cc_PenWidth	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x22, _io_spra_word),
	sprm_brc_Distance	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x23, _io_spra_dword),

	// HYPERLINK	���ǰ�CtrlCode���������ģ���˶���ķǳ���Ť����������Ҳֻ�������� :-)
	sprm_hyper_Style	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x28, _io_spra_word),
	sprm_hyper_URL		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x29, _io_spra_variant),
	sprm_hyper_Bookmark	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x2A, _io_spra_variant),

	// BOOKMARK	���ǰ�CtrlCode���������ģ���˶���ķǳ���Ť����������Ҳֻ�������� :-)
	sprm_bmark_ID		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x2B, _io_spra_dword),
	sprm_bmark_IsBlock	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x2C, _io_spra_word),
	sprm_bmark_Bookmark	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,  0x2D, _io_spra_variant),

	// HSS	���ǰ�CtrlCode���������ģ���˶���ķǳ���Ť����������Ҳֻ�������� :-)
	sprm_hss_Style		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x30, _io_spra_word),
	sprm_hss_Depth		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x31, _io_spra_word),
	sprm_hss_Degree		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x32, _io_spra_word),
	// ��ʼ��ɫ���� cc_ForeColor
	sprm_hss_EndColor	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x33, _io_spra_dword),
	sprm_hss_Para		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x34, _io_spra_dword),
	
	// COMPLEX RECT		Ŀǰ���ڶ���߿�
	sprm_brc_Flag		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x38, _io_spra_dword),
	sprm_brc_Left		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x39, _io_spra_variant),
	sprm_brc_Top		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x3A, _io_spra_variant),
	sprm_brc_Right		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x3B, _io_spra_variant),
	sprm_brc_Bottom		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x3C, _io_spra_variant),

	// REVISE_DATA		�޶�
	sprm_rev_Count		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x40, _io_spra_dword),
	sprm_rev_Item		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x41, _io_spra_variant),
	sprm_rvi_Type		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x42, _io_spra_word),
	sprm_rvi_UserID		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x43, _io_spra_word),
	sprm_rvi_Time		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x44, _io_spra_variant),

	// SUPERSUBSCRIPT	���±�
	sprm_sss_Style		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x48, _io_spra_word),
	sprm_sss_RelHeight	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x49, _io_spra_word),
	sprm_sss_RelShift	=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x4A, _io_spra_word),

	// TABITEM			�Ʊ�λ
	sprm_tab_Count		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x50, _io_spra_dword),
	sprm_tab_Item		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x51, _io_spra_variant),
	sprm_tbi_Pos		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x52, _io_spra_dword),
	sprm_tbi_Char		=	IO_MAKE_SPRM_CODE(_io_sprm_sgc_cc,	0x53, _io_spra_word),
};

class IAppendBuffer
{
public:
	virtual HRESULT Add(LPCVOID pData, UINT cb) = 0;
};

namespace	sprmCtrlAid
{
	const int	cw_WordSprm		= 2,
				cw_DWordSprm	= 3,
				cw_StructHeader	= 2;

	inline int cw_StringSprm(LPCTSTR lpsz)
	{
		return cw_StructHeader + 1 + ((strlen(lpsz) + 1) >> 1);
	}

	inline int cw_BlockSprm(int cb)
	{
		return (cb + 1) >> 1;
	}

	WORD	ReadSprmWordValue(WORD sprm, LPCVOID pData);
	DWORD	ReadSprmDWordValue(WORD sprm, LPCVOID pData);

	void	SaveSprmWordValue(IAppendBuffer* pBuf, WORD sprm, WORD wData);
	void	SaveSprmDWordValue(IAppendBuffer* pBuf, WORD sprm, DWORD wData);
	void	SaveSprmStructHeader(IAppendBuffer* pBuf, WORD sprm, int cwData);

	LPCVOID	MoveOverSprm(WORD sprm, LPCVOID pData);

	int		LoadSprmStringValue(WORD sprm, LPCVOID pData, LPSTR lpTag, int cbTag);	// MBCS �汾
	void	SaveSprmStringValue(IAppendBuffer* pBuf, WORD sprm, LPSTR lpsz);		// MBCS �汾

	int		LoadSprmBinaryValue(WORD sprm, LPCVOID pData, LPVOID lpTag, int cbTag);
	void	SaveSprmBinaryValue(IAppendBuffer* pBuf, WORD sprm, LPCVOID lpBuf, int cb);

	class	KNestedSprmList
	{
	protected:
		PWORD	m_pStart, m_pEnd, m_pCur;	// m_pEnd��������ĵ�һ���֣�m_pEnd-1���������ڵ����һ����
	public:
		KNestedSprmList(): m_pStart(NULL), m_pCur(NULL), m_pEnd(NULL) {}
	public:
		HRESULT	Start(WORD sprm, WORD* pData);
		HRESULT Start(WORD* pData, int cw);
		HRESULT	MoveFirst();
		HRESULT	Next(WORD& sprm, WORD*& pData);
		bool	EndOfList() const;
		// [Modified] mgy	2002-11-7 19:10
		// ��������������������ʵ���Զ���ŵ�Level��������⣬�ǲ����Ѷ�Ϊ֮
		PWORD GetpCur() const{return m_pCur;}
		void  SetpCur(PWORD pCur){ m_pCur = pCur;} 
		// [End modify]
	};
}

#endif /* __SPRM_H__ */
