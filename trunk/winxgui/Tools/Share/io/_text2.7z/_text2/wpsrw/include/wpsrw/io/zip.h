/* -------------------------------------------------------------------------
//	�ļ���		��	io/zip.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-29 17:34:34
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IO_ZIP_H__
#define __IO_ZIP_H__

#ifndef S_ZIP_NONEED_COMPRESSION
#define S_ZIP_NONEED_COMPRESSION	0x80
#endif

STDMETHODIMP zlibCompress(LPCVOID pSrc, UINT cbSize, HGBL* phGbl);
STDMETHODIMP zlibDecompress(LPCVOID pSrc, UINT cbSize, UINT cbOrgSize, HGBL* phGbl);

// -------------------------------------------------------------------------

#if !defined(__Disable_AutoLink_ZLib)
#define __Disable_AutoLink_ZLib

#if defined(_DEBUG)
#	pragma comment(lib, "zlibD")
#else
#	pragma comment(lib, "zlib")
#endif

#endif

// -------------------------------------------------------------------------

#endif /* __IO_ZIP_H__ */
