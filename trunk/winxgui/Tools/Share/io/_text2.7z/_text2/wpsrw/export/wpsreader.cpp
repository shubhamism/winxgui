/* -------------------------------------------------------------------------
//	�ļ���		��	wpsreader.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 16:22:05
//	��������	��
//	$Id: wpsreader.cpp,v 1.18 2006/11/10 03:32:26 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <l10n.h>
#include <core/wpsdoc.h>
#include <export/export.h>
#include <kso/io/contentsource.h>
#include <kso/io/fmtcheck.h>
#include <kso/io/component.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// link docreader

#ifdef _DEBUG
#pragma linklib("docreadermd")
#else
#pragma linklib("docreadermd")
#endif

STDAPI _dr_Initialize();
STDAPI _dr_Terminate();
STDAPI _dr_CreateSourceEx(IStorage* pDocStg, IKContentSource** ppContentSource);
STDAPI _dr_CreateSource3Ex(IStorage* pDocStg, IKContentSource** ppContentSource,IKFilterEventNotify* );

// -------------------------------------------------------------------------

class KWpsReader :
	public IKContentSource,
	public IKFilterMediaInit
{
private:
	IKContentSource* m_pSrc;
	IKFilterEventNotify* m_pNotify;

public:
	KWpsReader() : m_pSrc(NULL), m_pNotify(NULL)
	{
	}
	~KWpsReader()
	{
		KS_RELEASE(m_pSrc);
		KS_RELEASE(m_pNotify);
	}

	void SetNotify(IKFilterEventNotify* pNotify)
	{
		m_pNotify = pNotify;
		if (m_pNotify)
			m_pNotify->AddRef();
	}

public:
	// IKFilterMediaInit

	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		if (m_pSrc != NULL)
			return E_ACCESSDENIED;

		HRESULT hr = S_OK;
		ks_stdptr<ILockBytes> spLB;
		switch(pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			hr = XCreateILockBytesOnHGlobal(NULL, TRUE, &spLB);
			KS_CHECK(hr);
			{
				ks_stdptr<IStorage> spStg;
				hr = StgCreateDocfileOnILockBytes(
					spLB, STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 0, &spStg);
				KS_CHECK(hr);

				hr = WpsExportDoc(pMedium->lpszFileName, m_pNotify, spStg);
				KS_CHECK(hr);

				hr = _dr_CreateSource3Ex(spStg, &m_pSrc, m_pNotify);
//				hr = _dr_CreateSourceEx(spStg, &m_pSrc);
				KS_CHECK(hr);
			}
			return S_OK;
		case FILTER_TYMED_ISTORAGE:
			hr = XCreateILockBytesOnHGlobal(NULL, TRUE, &spLB);
			KS_CHECK(hr);
			{
				ks_stdptr<IStorage> spStg;
				hr = StgCreateDocfileOnILockBytes(
					spLB, STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 0, &spStg);
				KS_CHECK(hr);

				hr = WpsExportDoc(pMedium->pstg, m_pNotify, spStg);
				KS_CHECK(hr);

				hr = _dr_CreateSource3Ex(spStg, &m_pSrc, m_pNotify);
//				hr = _dr_CreateSourceEx(spStg, &m_pSrc);
				KS_CHECK(hr);
			}
			break;
		default:
			return E_INVALIDARG;
		}
KS_EXIT:
		return hr;
	}

public:
	// IKContentSource

	/*
	@fn Transfer
	@brief
		��������Դ���������ݣ���һ�����ݽ�����(IKContentHandler)�С�
	@arg [in] pHandler
		�ṩ�����ݽ�������ָ�롣���ڽ��ܴ�������ݡ�
	@return
		���ܵķ���ֵ�У�
		@val S_OK
			����ɹ���
		@val E_ACCESSDENIED
			����û��׼���á�
		@val �κ���������ֵ
			�κ���IKContentHandler���صĴ���ֵ��
	*/
	STDMETHODIMP Transfer(
		IN IKContentHandler* pAcc)
	{
		if (m_pSrc == NULL)
			return E_ACCESSDENIED;

		return m_pSrc->Transfer(pAcc);
	}

	/*
	@fn Close
	@brief
		�رո�����Դ���˺��������Transfer������E_ACCESSDENIED��
	*/
	STDMETHODIMP Close()
	{
		if (m_pSrc)
		{
			m_pSrc->Release();
			m_pSrc = NULL;
		}
		return S_OK;
	}

	BEGIN_QUERYINTERFACE(IKContentSource)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_CLASS(KWpsReader)
	DECLARE_COUNT(KWpsReader)
};

// -------------------------------------------------------------------------

int WPS_IdentifyFileType(LPCTSTR lpszFileName, LPTSTR lParam);

inline
STDMETHODIMP FormatCorrectWPS(IStorage* pStg)
{
	const WCHAR WPSDoc[] = { 'W', 'P', 'S', 'D', 'o', 'c', '\0' };
	IStream* pStrm = NULL;
	HRESULT hr = pStg->OpenStream(WPSDoc, 0, STGM_G_READ, 0, &pStrm);
	if (pStrm)
		pStrm->Release();
	return hr;
}

inline
STDMETHODIMP FormatCorrectWPS(IStream* pStrm)
{
	ASSERT(0);
	return E_NOTIMPL;
}

inline
STDMETHODIMP FormatCorrectWPS(LPCWSTR File)
{
	USES_CONVERSION;
	CWpsDoc::FileType fileType;
	fileType = (CWpsDoc::FileType)WPS_IdentifyFileType(W2A(File), NULL);
	if (
		fileType == CWpsDoc::wpsfile ||
		fileType == CWpsDoc::wptfile ||
		fileType == CWpsDoc::wpstextfile
		)
	{
		return S_OK;
	}
	else
	{
		return E_UNEXPECTED;
	}
}

/*
inline
STDMETHODIMP FormatCorrectWPS(LPCWSTR File)
{
	HRESULT hr = StgIsStorageFile(File);
	if (hr == S_OK)
	{
		IStorage* pStg = NULL;
		hr = StgOpenStorage(File, NULL, STGM_READ|STGM_TRANSACTED, 0, 0, &pStg);
		CHECK(hr);

		hr = FormatCorrectWPS(pStg);
		pStg->Release();
	}
	else
	{
		IStream* pStrm = NULL;
		hr = CreateStreamOnFile(File, STGM_READ|STGM_SHARE_EXCLUSIVE, &pStrm);
		CHECK(hr);

		hr = FormatCorrectWPS(pStrm);
		pStrm->Release();
	}
KS_EXIT:
	return hr;
} */

// -------------------------------------------------------------------------

EXPORTAPI filterpluginInitialize(IN void* pReserved)
{
	WpsInitialize();
	return _dr_Initialize();
}

EXPORTAPI filterpluginTerminate()
{
	WpsTerminate();
	return _dr_Terminate();
}

EXPORTAPI filterpluginRegister(IN IKFilterPluginRegister* pReg)
{
	return pReg->Register(
		_IoFormat_WPS,
		_IoName_WPS,
		FILTER_IMPORT,
		FILTER_TYMED_FILE,
		_IoExt_WPS,
		_KsoFileFormatDesc_WPSFile_Files
		);
	pReg->Register(
		_IoFormat_WPS,
		_IoName_WPS,
		FILTER_IMPORT,
		FILTER_TYMED_ISTORAGE,
		_IoExt_WPS,
		_KsoFileFormatDesc_WPSFile_Files
		);
	return S_OK;
}

EXPORTAPI filterpluginFormatCorrect(IN LPCFILTERMEDIUM pMedium, IN long lFormat)
{
	switch (lFormat)
	{
	case _IoFormat_WPS:
		{
			switch (pMedium->tymed)
			{
			case FILTER_TYMED_FILE:
				return FormatCorrectWPS(pMedium->lpszFileName);
			case FILTER_TYMED_ISTORAGE:
				return FormatCorrectWPS(pMedium->pstg);
			default:
				return E_UNEXPECTED;
			}
		}
	default:
		return E_UNEXPECTED;
	}
}

EXPORTAPI filterpluginImportCreate(
	IN long lFormat, IN IKFilterEventNotify* pNotify, OUT IKFilterMediaInit** ppv)
{
	if (pNotify)
	{
		UINT nPostFlag = wpspostio_update_field | wpspostio_correct_shape;
		pNotify->OnNotify(FILTEREVENT_POST_WORK, nPostFlag, NULL);
	}
	if (lFormat == _IoFormat_WPS)
	{
		KWpsReader* pRead = new KCountObject<KWpsReader>;
		pRead->SetNotify(pNotify);
		*ppv = pRead;
		return S_OK;
	}
	return E_UNEXPECTED;
}

// -------------------------------------------------------------------------
// $Log: wpsreader.cpp,v $
// Revision 1.18  2006/11/10 03:32:26  wangdong
// ��ɾ���̸�ʽ�������ַ�����
//
// Revision 1.17  2005/10/24 01:33:52  zhuyie
// �ϲ�������ش��룬�����ϰ汾�Ĺ����ļ���
//
// Revision 1.16  2005/08/15 16:19:57  wpsbuilder
// *** empty log message ***
//
// Revision 1.15  2005/04/05 14:07:36  shaogaoyang
// *** empty log message ***
//
// Revision 1.14  2005/04/05 05:11:04  wangdong
// �޸���wpsrw��FormatCorrect������ʶ��DOS WPS��ʽ��
//
