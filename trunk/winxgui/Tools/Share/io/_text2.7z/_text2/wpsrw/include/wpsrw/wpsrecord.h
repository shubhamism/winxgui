/* -------------------------------------------------------------------------
//	�ļ���		��	wpsrw/wpsrecord.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-21 15:15:34
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPSRW_WPSRECORD_H__
#define __WPSRW_WPSRECORD_H__

#ifndef __IO_FILEADPT_H__
#include "io/fileadpt.h"
#endif

#ifndef __IO_MFC_FILEADPT_H__
#include "io/mfc/fileadpt.h"
#endif

#ifndef __IO_RECORD_H__
#include "io/record.h"
#endif

#ifndef __IO_WPSRECORD_H__
#include "io/wpsrecord.h"
#endif

// ------------------------------------------------------------------------
/*
error 0101: ���ļ�ͷʱ��
error 0102: ��CWpsDoc���ݶ���
error 0103: ��CWpsDoc��TextPoolʱ��
error 0104: ��CWPSPageʱ��
error 0200: pasteʱ���Զ�������ݳ���
*/
inline void ReportWPSSaveLoadException(UINT uErrorCode)
{
	AfxThrowArchiveException(uErrorCode);
}

inline STDMETHODIMP WPSIOThrowError(HRESULT hr)
{
	REPORT("WPSIO - Throw Error");
	AfxThrowArchiveException(CArchiveException::badIndex);
	return hr;
}

// ------------------------------------------------------------------------

#define WPS_INVALIDOFF	((ULONG)-1)

typedef KWPSRecordWriter<CArchive*> KWPSMainWriter;
typedef KWPSRecordReader<CArchive*> KWPSMainReader;
typedef KRecordHeader _KWPSRecordHeader;

STDMETHODIMP_(IStream*) SwitchSubdoc(CArchive& ar, IStream* pNewdoc);

#define _WPSWriteRecord(wr, wTag, lp, wSize)	WriteRecord(wr, wTag, lp, wSize, WPS_RECTAG_SPEC)
#define _WPSWriteRecordEx(wr, wTag, lp, wSize)	WriteWPSRecordEx(wr, wTag, lp, wSize)

// ------------------------------------------------------------------------
// ��д�̶����ȼ�¼�ĸ���������

template <UINT wTag, class DataType>
STDMETHODIMP_(void) _WriteWPSRecord(CArchive& ar, const DataType& rec)
{
	KWPSMainWriter wr;
	wr.Attach(&ar);
	_WPSWriteRecord(wr, wTag, &rec, sizeof(rec));
}

template <UINT wTag, class DataType>
STDMETHODIMP ReadWPSRecord(CArchive& ar, DataType& rec)
{
	HRESULT hr;
	_KWPSRecordHeader hdr;
	KWPSMainReader wr;
	wr.Attach(&ar);
	
	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == wTag, hr = E_UNEXPECTED);

	wr.Read(&rec, sizeof(rec));
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());
	return S_OK;

KS_EXIT:
	return WPSIOThrowError(hr);
}

template <UINT wTag, class DataType>
STDMETHODIMP _ReadWPSRecord(CArchive& ar, DataType& rec)
{
	ZeroMemory(&rec, sizeof(rec));
	return ReadWPSRecord<wTag>(ar, rec);
}

#define __WPSWriteRecord(ar, wTag, rec)		_WriteWPSRecord<wTag>(ar, rec)
#define __WPSReadRecord(ar, wTag, rec)		_ReadWPSRecord<wTag>(ar, rec)

// -------------------------------------------------------------------------

#endif /* __WPSRW_WPSRECORD_H__ */
