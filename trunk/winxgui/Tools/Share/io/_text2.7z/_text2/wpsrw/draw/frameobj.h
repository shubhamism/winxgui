/* -------------------------------------------------------------------------
//	�ļ���		��	frameobj.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 18:46:59
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __FRAMEOBJ_H__
#define __FRAMEOBJ_H__

#ifndef __FPBASE_H__
#include "fpbase.h"
#endif

// -------------------------------------------------------------------------

class CWpsImage;
class CWpsView;
class CFrameObj : public CFPBase
{
private:
public:
	CWpsImage* m_pImg;	 // ���ڵ�ͼƬ
	CSize      m_extent; // current extent is tracked separate from scaled position
	int  		m_nfrmShape;
	CPoint 		m_roundness;	//	Բ�ǵ�
	WrapMode	m_wrapMode;		//	��������:
	int			m_mgOutsideType;//	�������������
	CRect 		m_MarginOutside;//	��������ճߴ�
	
	STDMETHODIMP Serialize_Write_02(KSArchive& ar);
	STDMETHODIMP Serialize_Read_02(KSArchive& ar);
	
public:
	DECLARE_SERIAL(CFrameObj);			//  �������������

	CFrameObj()
	{
		m_pImg = NULL;
	}
	CFrameObj(const CFrameObj* obj);
	CFrameObj(const CWpsDoc* pDoc, const CRect& frmrect);
	~CFrameObj();
	
	CWpsImage* GetImage() { return m_pImg; }
	void SetImage(CWpsImage* pImg) // ע��ú�����ɾ��ԭ��ͼƬ
	{
		ASSERT(m_pImg == NULL);
		m_pImg = pImg;
	}
	
	virtual int	 CheckObjType() { return FRAMEObj; }
	virtual void Serialize_97( KSArchive& ar );
	virtual void Serialize_98( KSArchive& ar );
	virtual void Serialize_01(KSArchive&);

	virtual void DeleteImgContent( CWpsView* =NULL );
	virtual void SetFrmShape( int nfrmShape = FS_RECT, CWpsView* =NULL );

	/////////////////////////////////////////////////////
	////���´����Draw�й�
	virtual int	 GetFrmShape() { return m_nfrmShape; }
	virtual CPoint GetFrmRoundPoint() { return m_roundness; }
};

// -------------------------------------------------------------------------

class CFramePT : public CFrameObj
{
protected:
	//	���ڶ�������:
	CObList		m_ptobjList;
	
public:
	DECLARE_SERIAL(CFramePT);
	CFramePT()
	{
	}
	virtual ~CFramePT()
	{
		ASSERT( this );
		DeleteContent();
	}	
	
	void DeleteContent();
	
	virtual int	 CheckObjType() { return FRAMEPT; }//yangchao
	virtual void Serialize_97( KSArchive& ar );
	virtual void Serialize_98( KSArchive& ar );
	virtual void Serialize_01(KSArchive&);	
};
	
// -------------------------------------------------------------------------

#endif /* __FRAMEOBJ_H__ */
