//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainComboBox.h
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-5-28 15:41:30
//	FileDescription	:	
//
//////////////////////////////////////////////////////////////////////////////////////


// KSDomainComboBox.h: interface for the KSDomainComboBox class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __KSDOMAINCOMBOBOX_H
#define __KSDOMAINCOMBOBOX_H

#include "Ptobj.h"

class KSDomainComboBox : public CLtxtObj  
{
	
protected:
	DECLARE_SERIAL(KSDomainComboBox);
	KSDomainComboBox();
	
public:
	KSDomainComboBox(const CWpsDoc* pDoc, const CRect& position, int nShape);
	virtual ~KSDomainComboBox();
	//	class copy
	KSDomainComboBox( const KSDomainComboBox* obj );
	
public:
	//	CStringArray  ar_String;	//	save ListBox String
	CStringArray  m_strArray;	//	save ListBox String
	CString       m_sItem;		//	save  ListBox һ��
	int nCount;
	//	BOOL m_bEnableField;		// û�б��棬������ֻ����ReadOnly ״̬�´β���Ч
	
private:
	BOOL  m_bSelect;	//	KsDomainComboBox �Ƿ�ѡ��
	BOOL  m_bBackGround;
	
public:
	virtual void Serialize_01(KSArchive& ar);
};
#endif // !defined(AFX_KSDOMAINCOMBOBOX_H__9CA02CA3_33BF_11D4_A00C_5254AB1993A3__INCLUDED_)
