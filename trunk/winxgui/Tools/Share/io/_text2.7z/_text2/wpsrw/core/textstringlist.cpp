/* -------------------------------------------------------------------------
//	�ļ���		��	textstringlist.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-3 17:58:49
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "textstring.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
KSTextStringList::KSTextStringList()
{
	m_pNodeHead = m_pNodeTail = NULL;
	m_nCount = 0;
}

KSTextStringList::~KSTextStringList()
{
	RemoveAll();
}

KSTextStringList::KSNode* KSTextStringList::NewNode(KSTextStringList::KSNode* preNode,
													KSTextStringList::KSNode* nextNode)
{
	KSNode* pNode = new KSNode;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
	pNode->pPrev = preNode;											// �ڴ˲�����飬��Ϊ����Ϊ null
	pNode->pNext = nextNode;
	return pNode;
}

void KSTextStringList::FreeNode(KSNode* pNode)
{
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
	if (pNode)
		delete pNode;
}

void KSTextStringList::RemoveAll()
{
	KSNode* pNode = m_pNodeHead;
	KSNode* pNodeTemp;
	while (pNode)
	{
		pNodeTemp = pNode->pNext;
		FreeNode(pNode);
		pNode = pNodeTemp;
	}
	m_pNodeHead = m_pNodeTail = NULL;
	m_nCount = 0;
}

KSTextString KSTextStringList::RemoveHead()
{
	KSTextString strtemp;
	if (!m_pNodeHead)
		return strtemp;

	KSNode* pNode = m_pNodeHead;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
	strtemp = pNode->textstring;

	ASSERT(pNode->pPrev == NULL);
	pNode->pNext->pPrev = NULL;
	m_pNodeHead = m_pNodeHead->pNext;
	m_nCount--;

	FreeNode(pNode);
	return strtemp;
}

KSTextString KSTextStringList::RemoveTail()
{
	KSTextString strtemp;
	if (!m_pNodeTail)
		return strtemp;

	KSNode* pNode = m_pNodeTail;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
	strtemp = pNode->textstring;

	ASSERT(pNode->pNext == NULL);
	pNode->pPrev->pNext = NULL;
	m_pNodeTail = m_pNodeTail->pPrev;
	m_nCount--;

	FreeNode(pNode);
	return strtemp;
}

void KSTextStringList::RemoveAt(POSITION position)
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
	pNode->pNext->pPrev = pNode->pPrev;
	pNode->pPrev->pNext = pNode->pNext;
	if (pNode == m_pNodeHead)
		m_pNodeHead = pNode->pNext;
	if (pNode == m_pNodeTail)
		m_pNodeTail = pNode->pPrev;
	m_nCount--;
	FreeNode(pNode);
}

POSITION KSTextStringList::AddHead(KSTextString& newElement)
{
	KSNode* pNode = m_pNodeHead;
	KSNode* pNewNode;
	if (m_pNodeHead)
	{
		ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
		ASSERT(pNode->pPrev == NULL);

		pNewNode = NewNode(NULL, pNode);
		pNode->pPrev = pNewNode;
	}
	else
	{
		ASSERT(m_pNodeTail == NULL);
		pNewNode = NewNode(NULL, NULL);
		m_pNodeTail = pNewNode;
	}
	m_pNodeHead = pNewNode;
	m_nCount++;
	pNewNode->textstring = newElement;

	return (POSITION)pNewNode;
}

POSITION KSTextStringList::AddTail(KSTextString& newElement)
{
	KSNode* pNode = m_pNodeTail;
	KSNode* pNewNode;
	if (m_pNodeTail)
	{
		ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
		ASSERT(pNode->pNext == NULL);

		pNewNode = NewNode(pNode, NULL);
		pNode->pNext = pNewNode;
	}
	else
	{
		ASSERT(m_pNodeHead == NULL);
		pNewNode = NewNode(NULL, NULL);
		m_pNodeHead = pNewNode;
	}
	m_pNodeTail = pNewNode;
	m_nCount++;
	pNewNode->textstring = newElement;

	return (POSITION)pNewNode;
}

void KSTextStringList::AddHead(KSTextStringList* pNewList)
{
	ASSERT(pNewList != NULL);
	// add a list of same elements to head (maintain order)
	POSITION pos = pNewList->GetTailPosition();
	while (pos != NULL)
		AddHead(pNewList->GetPrev(pos));
}

void KSTextStringList::AddTail(KSTextStringList* pNewList)
{
	ASSERT(pNewList != NULL);
	// add a list of same elements
	POSITION pos = pNewList->GetHeadPosition();
	while (pos != NULL)
		AddTail(pNewList->GetNext(pos));
}

KSTextString KSTextStringList::GetNext(POSITION& position) const
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));

	position = (POSITION)pNode->pNext;

	return pNode->textstring;
}

KSTextString KSTextStringList::GetPrev(POSITION& position) const
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));

	position = (POSITION)pNode->pPrev;

	return pNode->textstring;
}

KSTextString KSTextStringList::GetAt(POSITION position) const
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));

	return pNode->textstring;
}

void KSTextStringList::SetAt(POSITION position, KSTextString& newElement)
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
	pNode->textstring = newElement;
}

POSITION KSTextStringList::InsertBefore(POSITION position, KSTextString& newElement)
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));

	KSNode* pNewNode = NewNode(pNode->pPrev, pNode);
	ASSERT(AfxIsMemoryBlock(pNewNode, sizeof(KSNode)));
	pNewNode->textstring = newElement;

	if (pNode->pPrev)
		pNode->pPrev->pNext = pNewNode;
	if (pNode == m_pNodeHead)
		m_pNodeHead = pNewNode;

	m_nCount++;
	return (POSITION)pNewNode;
}

POSITION KSTextStringList::InsertAfter(POSITION position, KSTextString& newElement)
{
	KSNode* pNode = (KSNode*)position;
	ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));

	KSNode* pNewNode = NewNode(pNode, pNode->pNext);
	ASSERT(AfxIsMemoryBlock(pNewNode, sizeof(KSNode)));
	pNewNode->textstring = newElement;

	if (pNode->pNext)
		pNode->pNext->pPrev = pNewNode;
	if (pNode == m_pNodeTail)
		m_pNodeTail = pNewNode;

	m_nCount++;
	return (POSITION)pNewNode;
}

/*@@todo
POSITION KSTextStringList::Find(KSTextString& searchValue, POSITION startAfter) const
{
	KSNode* pNode;
	if (startAfter == NULL)
		pNode = m_pNodeHead;									// start at head
	else
	{
		pNode = (KSNode*)startAfter;
		ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
		pNode = pNode->pNext;									// start after the one specified
	}

	for (NULL; pNode; pNode = pNode->pNext)
	{
		if (pNode->textstring == searchValue)
			return (POSITION)pNode;
	}
	return NULL;
}*/

POSITION KSTextStringList::FindIndex(int nIndex) const
{
	if (nIndex >= m_nCount || nIndex < 0)
		return NULL;											// went too far

	KSNode* pNode = m_pNodeHead;
	while (nIndex--)
	{
		ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
		pNode = pNode->pNext;
	}
	return (POSITION)pNode;
}

void KSTextStringList::Serialize(KSArchive& ar)
{
	if (ar.IsStoring())
	{
		ar.WriteCount(m_nCount);
		for (KSNode* pNode = m_pNodeHead; pNode; pNode = pNode->pNext)
		{
			ASSERT(AfxIsMemoryBlock(pNode, sizeof(KSNode)));
			ar << pNode->textstring;
		}
	}
	else
	{
		DWORD nNewCount = ar.ReadCount();
		KSTextString newData;
		while (nNewCount--)
		{
			ar >> newData;
			AddTail(newData);
		}
	}
}

// End of file =======================================================
