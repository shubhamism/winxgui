/* -------------------------------------------------------------------------
//	�ļ���		��	bookmark.h
//	������		��	����
//	����ʱ��	��	2004-10-15 5:38:21 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __BOOKMARK_H__
#define __BOOKMARK_H__

#ifndef __CTRLCODE_H__
#include "ctrlcode.h"
#endif

#define		INVALID_BOOKMARKID	-1

// -------------------------------------------------------------------------
class CParagraph;
class CBookMark
{
public:
	CBookMark(int, BOOL, LPCTSTR, CParagraph*);
	virtual ~CBookMark() { NULL; }

protected:
	int		m_nBookMarkID;						// bookmark ID
	BOOL	m_bIsBlock;							// �Ƿ��ǳɿ�
	TCHAR	m_szBookMark[SIZE_BOOKMARK];		// ָ�� bookmark �ַ���
	CParagraph* m_pParagraph;					// ָ��� bookmark ��ʼ�����ڶεĶ�ָ��

public:
	void SerializeEx(CFile&, BOOL);

	int GetBookMarkID() const { return m_nBookMarkID; }
	BOOL IsBlockMark() const { return m_bIsBlock; }
	LPCTSTR GetBookMarkMsg() const { return m_szBookMark; }
//	void SetBookMarkMsg(LPTSTR);
	CParagraph* GetParagraph() const { return m_pParagraph; }
//	void SetParagraph(CParagraph* pPara) { m_pParagraph = pPara; }
};

// -------------------------------------------------------------------------
class CTextPool;
class CBookMarkMan
{
public:
	CBookMarkMan();
	virtual ~CBookMarkMan();

protected:
	CPtrArray	m_aryBookMarks;

public:
	void SerializeEx (CTextPool*, CFile&, BOOL);
	int NumOfBookMarks() const { return m_aryBookMarks.GetSize(); }
	CBookMark* GetBookMark(int) const;
	const CBookMark* GetBookMarkFromID(int) const;
};

// -------------------------------------------------------------------------

#endif /* __BOOKMARK_H__ */
