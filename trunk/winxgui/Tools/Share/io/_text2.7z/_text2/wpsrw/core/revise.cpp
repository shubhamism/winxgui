/* -------------------------------------------------------------------------
//	�ļ���		��	revise.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 20:35:46
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "revise.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

IMPLEMENT_SERIAL(CUser, CObject, VERSIONABLE_SCHEMA | 0)

void CUser::Serialize(CArchive& ar)
{
#ifndef _WPSREADER
	if (ar.IsStoring ())
	{
		ar << m_wUserID;
		ar << m_strUserName;
		ar << m_strUserAddress;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_wUserID;
		ar >> m_strUserName;
		ar >> m_strUserAddress;
	}
}

// -------------------------------------------------------------------------
