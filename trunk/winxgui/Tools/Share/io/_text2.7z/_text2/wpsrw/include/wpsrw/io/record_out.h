/* -------------------------------------------------------------------------
//	�ļ���		��	io/record_out.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-16 2:29:50
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IO_RECORD_OUT_H__
#define __IO_RECORD_OUT_H__

#ifndef __IO_RECORD_SHARE_H__
#include "record_share.h"
#endif

#ifndef __IO_FILEADPT_H__
#include "fileadpt.h"
#endif

#if !defined(REPORT_ONCE)
#define REPORT_ONCE(s)		ASSERT(0)
#endif

// =========================================================================

template <class File>
class KRecordWriterBasic
{
public:
	KRecordWriterBasic()
	{
		m_wRestSize = 0;
	}
	STDMETHODIMP_(void) Attach(File pFile)
	{
		m_pFile = pFile;
	}
	STDMETHODIMP_(UINT) Write(LPCVOID lpData, UINT nCount)
	{
		if (nCount > m_wRestSize)
		{
			REPORT_ONCE("����: KRecordWriter::EndWriteRec() - �ֽڳ�����\n");
			nCount = m_wRestSize;
		}
		nCount = _ioWriteFile(m_pFile, lpData, nCount);
		m_wRestSize -= nCount;
		return nCount;
	}
	STDMETHODIMP EndWriteRec()
	{
		BYTE* pBuf;
		if (m_wRestSize)
		{
			REPORT_ONCE("����: KRecordWriter::EndWriteRec() - ��ʣ���ֽ�û��д��\n");
			pBuf = new BYTE[m_wRestSize];
			ZeroMemory(pBuf, m_wRestSize);
			_ioWriteFile(m_pFile, pBuf, m_wRestSize);
			delete[] pBuf;
			m_wRestSize =  0;
		}
		return S_OK;
	}
	
protected:
	File m_pFile;
	UINT m_wRestSize;
};

// =========================================================================

template <class File>
class KWPSRecordWriter : public KRecordWriterBasic<File>
{
public:
	STDMETHODIMP BeginWriteRec(UINT wTag, UINT wSize, DWORD dwReserved = WPS_RECTAG_SPEC)
	{
		ASSERT(wTag <= 0xffff && wSize <= 0xffff);
		KWPSRecordHeader hdr = { (WORD)wTag, (WORD)wSize, dwReserved };
		m_wRestSize = hdr.wSize;
		_ioWriteFile(m_pFile, &hdr, sizeof(hdr));
		return S_OK;
	}
};

template <class File>
class KExcelRecordWriter : public KRecordWriterBasic<File>
{
public:
	STDMETHODIMP BeginWriteRec(UINT wTag, UINT wSize, DWORD dwReserved = 0)
	{
		ASSERT(wTag <= 0xffff && wSize <= 0xffff);
		KExcelRecordHeader hdr = { (WORD)wTag, (WORD)wSize };
		m_wRestSize = hdr.wSize;
		_ioWriteFile(m_pFile, &hdr, sizeof(hdr));
		return S_OK;
	}
};

// =========================================================================

template <class File>
class KETRecordWriter : public KRecordWriterBasic<File>
{
public:
	STDMETHODIMP BeginWriteRec(UINT wTag, UINT wSize, DWORD dwReserved = 0)
	{
		ASSERT(wTag < 0x8000); // ���λ������
		m_wRestSize = wSize;
		if (wSize < (WORD)(-1))
		{
			_KETRecordHeader hdrRec;
			hdrRec.wTag	 = (WORD)dwTag;
			hdrRec.wSize = (WORD)wSize;
			_ioWriteFile(m_pFile, &hdrRec, sizeof(hdrRec));
		}
		else
		{
			_KETRecordHeaderEx hdrRec;
			hdrRec.wTag		 = (WORD)(dwTag | 0x8000);
			hdrRec.wReserved = 0;
			hdrRec.dwRecSize = wSize;
			_ioWriteFile(m_pFile, &hdrRec, sizeof(hdrRec));
		}
		return S_OK;
	}
};

// =========================================================================

template <class Writer>
STDMETHODIMP_(void) WriteRecord(Writer& wr, UINT wTag, LPCVOID lp, UINT wSize, DWORD dwRes)
{
	wr.BeginWriteRec(wTag, wSize, dwRes);
	wr.Write(lp, wSize);
	wr.EndWriteRec();
}

template <class Writer>
STDMETHODIMP_(void) WriteWPSRecordEx(Writer& wr, UINT wTag, LPCVOID lp, UINT wSize)
{
	while (wSize >= WPSRecordSizeMax)
	{
		wr.BeginWriteRec(wTag, WPSRecordSizeMax, WPS_RECTAG_SPEC);
		wr.Write(lp, WPSRecordSizeMax);
		wr.EndWriteRec();
		wSize -= WPSRecordSizeMax;
		((BYTE*&)lp) += WPSRecordSizeMax;
	}
	wr.BeginWriteRec(wTag, wSize, WPS_RECTAG_SPEC);
	wr.Write(lp, wSize);
	wr.EndWriteRec();
}

// =========================================================================

#endif /* __IO_RECORD_OUT_H__ */
