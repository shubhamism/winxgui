/* -------------------------------------------------------------------------
//	�ļ���		��	ex_chart.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-3 18:14:47
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_chart.h"
#include "../export_tools.h"
#include "../ks_colormodel.h"

#include "../export/draw/ex_ptobj.h"
#include "../export/draw/ex_frametext.h"
#include "../export/draw/ex_frameimg.h"
#include "../export/draw/ex_frameole.h"
#include "../export/draw/ex_wpsgroup.h"
#include "../export/draw/ex_objtext.h"
#include "../export/draw/ex_frameole.h"
#include "../export/draw/ex_framept.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

EX_SHAPE_API CFrameChart_Export::CreateChartSubObj(CWPSObj* pWpsObj, CShape_Context& context)
{
	CDC dc;
	dc.Attach(::CreateEnhMetaFile(NULL, NULL, NULL, NULL));
	dc.m_hAttribDC = dc.m_hDC;
	pWpsObj->DrawShape(&dc, NULL);
#ifndef WPP_ONLY
	CShape_Context subshape(context.GetWpsExport());
#else
	CShape_Context subshape(context.GetSlideBaseCtx());
#endif
	CRect rc = pWpsObj->GetMrect();
	CRectObj_Export* pExpClass = reinterpret_cast<CRectObj_Export*>(pWpsObj);
	ASSERT(pExpClass);
	pExpClass->GetShapeRect(subshape, rc);
#ifndef WPP_ONLY
	subshape.m_shape = context.m_shape.NewShape()
		.SetChildAnchor(
			WpsShapeToTwip(rc.left),
			WpsShapeToTwip(rc.top),
			WpsShapeToTwip(rc.right),
			WpsShapeToTwip(rc.bottom));
#else
	subshape.m_shape = context.m_shape.NewShape()
		.SetChildAnchor(
			WpsShapeToPptUnit(rc.left),
			WpsShapeToPptUnit(rc.top),
			WpsShapeToPptUnit(rc.right),
			WpsShapeToPptUnit(rc.bottom));
#endif

	Convert_EMF_To_ImgShape(::CloseEnhMetaFile(dc.Detach()), msosptPictureFrame, subshape);
	subshape.m_shape.SetProperties(subshape.m_opt);
//	subshape.m_shape.SetUDefProperties(subshape.m_optUDef);
}

EX_SHAPE_API CFrameChart_Export::ConvertFrame(CShape_Context& context)
{
	/*
	 *	�߿���״
	 */
	CRect rct = GetMrect();
	ASSERT(rct.right - rct.left > 0);
	ASSERT(rct.bottom - rct.top > 0);

#ifndef WPP_ONLY
	CShape_Context thisshape(context.GetWpsExport());
	thisshape.m_shape = context.m_shape.NewShape()
		.SetChildAnchor(
			WpsShapeToTwip(0),
			WpsShapeToTwip(0),
			WpsShapeToTwip(rct.right - rct.left),
			WpsShapeToTwip(rct.bottom - rct.top));
#else
	CShape_Context thisshape(context.GetSlideBaseCtx());
	thisshape.m_shape = context.m_shape.NewShape()
		.SetChildAnchor(
			WpsShapeToPptUnit(0),
			WpsShapeToPptUnit(0),
			WpsShapeToPptUnit(rct.right - rct.left),
			WpsShapeToPptUnit(rct.bottom - rct.top));
#endif

	(ShapeExportBaseTypeCast(FRAMEChart,this))->ConvertShape(thisshape);
	if(m_nfrmShape == FS_ROUNDRECT)//Բ�Ǿ���
	{
		thisshape.m_shape.SetShapeType(msosptRoundRectangle);
		CRect rct = GetMrect();
		thisshape.m_opt.ForceAddPropFix(msopt_adjustValue , CONVGUNITX(m_roundness.x));
		thisshape.m_opt.ForceAddPropFix(msopt_adjustValueY, CONVGUNITY(m_roundness.y));
	}
	else//����
	{
		thisshape.m_shape.SetShapeType(msosptRectangle);
	}

	thisshape.m_shape.SetProperties(thisshape.m_opt);
	thisshape.m_shape.SetUDefProperties(thisshape.m_optUDef);
}

EX_SHAPE_API CFrameChart_Export::ConvertShape(CShape_Context& context)
{
	ConvertFrame(context);
	for (POSITION pos = m_ptobjList.GetHeadPosition(); pos; )
	{
		CWPSObj* pWpsObj = (CWPSObj*)m_ptobjList.GetNext(pos);
		ASSERT(pWpsObj->IsKindOf(RUNTIME_CLASS(CWPSObj)));

		BOOL fGroup = IsGroupObject(pWpsObj);
		CRect rc = pWpsObj->GetMrect();

#ifndef WPP_ONLY
		CShape_Context subshape(context.GetWpsExport());
#else
		CShape_Context subshape(context.GetSlideBaseCtx());
#endif


		switch (pWpsObj->CheckObjType())
		{
		case LTXTObj:
		case LTXTSizeComment:
			{
				CLtxtObj_Export* pExpClass = reinterpret_cast<CLtxtObj_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case MultitextRect:
			{
				CRotateText_Export* pExpClass = reinterpret_cast<CRotateText_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case FRAMEOLE:
		//	{
		//				ConvertShape(pWpsObj);//ole�����Լ���ת��
		//				return;
		//			}
			break;
		case LINEObj:
		//case LINECycle:
			{
				CLineObj_Export* pExpClass = reinterpret_cast<CLineObj_Export*>(pWpsObj);
				ASSERT(pExpClass);
				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case RECTObj:
		case RECTRound:
		case RECTEllipse:
		case RECTDiamond:
		case RECTCube:
		case RECTCylinder:
		case RECTPieColumn:
			{
				if (pWpsObj->IsKindOf(RUNTIME_CLASS(CChartAxes)) ||
					pWpsObj->IsKindOf(RUNTIME_CLASS(CHistogram)) ||
					pWpsObj->IsKindOf(RUNTIME_CLASS(CCakeBox))	 ||
					pWpsObj->IsKindOf(RUNTIME_CLASS(CCake))	    )
				{
					CreateChartSubObj(pWpsObj, context);
					continue;
				}
				else
				{
					CRectObj_Export* pExpClass = reinterpret_cast<CRectObj_Export*>(pWpsObj);
					ASSERT(pExpClass);
					pExpClass->GetShapeRect(subshape, rc);
				}
			}
			break;
		case POLYObj:
			{
				if (pWpsObj->IsKindOf(RUNTIME_CLASS(CPolyLine)))
				{
					CreateChartSubObj(pWpsObj, context);
					continue;
				}
//				CPolyObj_Export* pExpClass = reinterpret_cast<CPolyObj_Export*>(pWpsObj);
//				ASSERT(pExpClass);
//				pExpClass->GetShapeRect(subshape, rc);
			}
			break;
		case CURVEObj:
//			{
//				CCurveObj_Export* pExpClass = reinterpret_cast<CCurveObj_Export*>(pWpsObj);
//				ASSERT(pExpClass);
//				pExpClass->GetShapeRect(subshape, rc);
//			}
			break;
		}
#ifndef WPP_ONLY
		subshape.m_shape = context.m_shape.NewShape(fGroup)
			.SetChildAnchor(
				WpsShapeToTwip(rc.left),
				WpsShapeToTwip(rc.top),
				WpsShapeToTwip(rc.right),
				WpsShapeToTwip(rc.bottom));
#else
		subshape.m_shape = context.m_shape.NewShape(fGroup)
			.SetChildAnchor(
				WpsShapeToPptUnit(rc.left),
				WpsShapeToPptUnit(rc.top),
				WpsShapeToPptUnit(rc.right),
				WpsShapeToPptUnit(rc.bottom));
#endif

		subshape.ConvertShape(pWpsObj);
		subshape.m_shape.SetProperties(subshape.m_opt);
		subshape.m_shape.SetUDefProperties(subshape.m_optUDef);
	}
}

CPen* CFPBase::SelectPenObject(CDC* pDC, IColorScheme* pICS, int& nPenW, BOOL IsNullPen)
{
	if (IsNullPen)
		return (CPen*)pDC->SelectStockObject(NULL_PEN);
	static UINT		lpenS = 0;
	static UINT		lpenW = 0;	//	�߼���λ(0.1mm)
	static COLORREF	lpenC = (COLORREF)-1;
	static CPen 	pen;
	COLORREF clrLPenColor = KColorModel::IndexToRef(m_LPenColor, pICS);
	if (lpenS != m_uLPenStyle || lpenW != m_uLPenSize || lpenC != clrLPenColor)
	{	lpenS = m_uLPenStyle;
		lpenW = m_uLPenSize;
		lpenC = clrLPenColor;
		LOGPEN	devPen;
		devPen.lopnStyle = (lpenS >= PS_DOUBLETHIN)? PS_INSIDEFRAME : lpenS;
		if (lpenS > PS_SOLID && lpenS < PS_INSIDEFRAME)
			lpenW = 0;
		else
			lpenW = lpenW;
		devPen.lopnWidth.x  = lpenW;
		devPen.lopnColor = lpenC;
		pen.DeleteObject();				// !!!
		if (!pen.CreatePenIndirect(&devPen))	//�����ܴ�����ѡ��ձ�
			return (CPen*)pDC->SelectStockObject(NULL_PEN);
	}
	nPenW = lpenW;
	return pDC->SelectObject(&pen);
}

LOGBRUSH KLOGBRUSH2LOGBRUSH(KLOGBRUSH brush, IColorScheme* pICS)
{
	LOGBRUSH newBrush;
	newBrush.lbHatch = brush.lbHatch;
	newBrush.lbStyle = brush.lbStyle;
	newBrush.lbColor = KColorModel::IndexToRef(brush.lbColor, pICS);

	return newBrush;
}

CBrush* CTFPBase::SetBrushBkModeBkColor(CDC* pDC, IColorScheme* pICS)
{
	if (m_nBkMode == TRANSPARENT && m_logbrush.lbStyle != BS_HATCHED)
		return (CBrush*)pDC->SelectStockObject(NULL_BRUSH);

	static LOGBRUSH devBrush = {(UINT)-1,(COLORREF)-1,(LONG)-1};
	LOGBRUSH logBrush = KLOGBRUSH2LOGBRUSH(m_logbrush, pICS);
	//LLG_MODIFY_2002_5_25 ����ڶ���ɫ����(��ΪWPS�ĵڶ�����ɫ�����ɫ��ͬһ����!)
	logBrush.lbColor = KColorModel::CalcSecondColorForOneShade(GetBkColor(),
														GetFillColor(), pICS);
	static CBrush brush;
	if ( devBrush.lbStyle != logBrush.lbStyle
		||devBrush.lbColor != logBrush.lbColor
		||devBrush.lbHatch != logBrush.lbHatch)
	{	devBrush = logBrush;
		brush.DeleteObject();							// !!!
		if (!brush.CreateBrushIndirect(&devBrush))	//�����ܴ�����ѡ���ˢ
			return (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	}

//////   Modified By flush, 2001-12-28	
	if (NULL == brush.m_hObject)
	{
		brush.Attach(::GetStockObject(NULL_BRUSH));
	}
/////////////////////
	if (m_nBkMode == OPAQUE || m_nBkMode == INVERT)  	//	���ǻ򷴰�
	{	if (logBrush.lbStyle == BS_HATCHED)
		{	
			pDC->SetBkMode(OPAQUE);					//	set BkMode
			pDC->SetBkColor(KColorModel::IndexToRef(m_bkColor, pICS));//	��Ӱ�߼�϶ɫ
		}
	}
	else												//	͸��
	{
		if (m_nBkMode == GRADIENT)
		{
			pDC->SetBkMode(OPAQUE);
			return (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
		}
		if (logBrush.lbStyle == BS_HATCHED)
			pDC->SetBkMode(TRANSPARENT);				//	set BkMode
		else
			return (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	}
	brush.UnrealizeObject();
	CPoint pntOrg = pDC->GetViewportOrg();
	pDC->SetBrushOrg (pntOrg.x % 8, pntOrg.y % 8);
	return pDC->SelectObject(&brush);
}

// 	nHszLog ��λ 0.01mm
int GetCurFontDevHeight(const int nHszLog)
{
	int nFontH = (nHszLog+5)/10; 	//��λ 0.1mm
	CPoint lfWH(nFontH, nFontH);
	return MAX(3, lfWH.y);	//Ϊ��RichWin��'@'�߼����� ExtTextOut() ������
}

//����x��̶������ַ����ĳ���,�豸��λ����
int CChartAxes::GetMaxXStrLen(CDC* pDC)
{
	ASSERT(!m_XScaleList.IsEmpty());
	CFont* pOldFont = NULL;
	CFont font;
	m_XLogFont.lfHeight = -GetCurFontDevHeight(m_lXStrFontH);
	if (font.CreateFontIndirect(&m_XLogFont))
		pOldFont = pDC->SelectObject(&font);

	int nW = 0;
	KSTextString str;
	POSITION pos;
	for (pos = m_XScaleList.GetHeadPosition(); pos != NULL;)  
	{
		str = m_XScaleList.GetNext(pos);
		nW = MAX(nW, str.GetTextSize());
	}
	TEXTMETRIC tm;
	pDC->GetTextMetrics((LPTEXTMETRIC)&tm); //��Ϊ��ǰӳ�䷽ʽΪMM_TEXT,���Է���ֵʵ�������豸��λ����
	nW *= tm.tmAveCharWidth;

	if (pOldFont)
		pDC->SelectObject(pOldFont);
	font.DeleteObject();
	return nW;
}

//����y��̶������ַ����ĳ���,�豸��λ����
int CChartAxes::GetMaxYStrLen(CDC* pDC)
{
	ASSERT(!m_YScaleList.IsEmpty());
	CFont* pOldFont = NULL;
	CFont font;
	m_YLogFont.lfHeight = -GetCurFontDevHeight(m_lYStrFontH);
	if (font.CreateFontIndirect(&m_YLogFont))
		pOldFont = pDC->SelectObject(&font);

	int nW = 0;
	KSTextString str;
	POSITION pos;
	for (pos = m_YScaleList.GetHeadPosition(); pos != NULL;)  
	{
		str = m_YScaleList.GetNext(pos);
		nW = MAX(nW, str.GetTextSize());
	}
	TEXTMETRIC tm;
	pDC->GetTextMetrics((LPTEXTMETRIC)&tm); //��Ϊ��ǰӳ�䷽ʽΪMM_TEXT,���Է���ֵʵ�������豸��λ����
	nW *= tm.tmAveCharWidth;
	
	if (pOldFont)	
		pDC->SelectObject(pOldFont);
	font.DeleteObject();
	return nW;
}

//����x��̶��ַ����ĸ߶�,�豸��λ����
int CChartAxes::GetMaxXStrHeight(CDC* pDC)
{
	ASSERT(!m_XScaleList.IsEmpty());
	CFont* pOldFont = NULL;
	CFont font;
	m_XLogFont.lfHeight = -GetCurFontDevHeight(m_lXStrFontH);
	if (font.CreateFontIndirect(&m_XLogFont))
		pOldFont = pDC->SelectObject(&font);

	int nH =0;
	TEXTMETRIC tm;
	pDC->GetTextMetrics((LPTEXTMETRIC)&tm); //��Ϊ��ǰӳ�䷽ʽΪMM_TEXT,���Է���ֵʵ�������豸��λ����
	nH = tm.tmHeight + tm.tmExternalLeading;
	
	if (pOldFont)
		pDC->SelectObject(pOldFont);
	font.DeleteObject();
	return nH;
}

//����y��̶��ַ����ĸ߶�,�豸��λ����
int CChartAxes::GetMaxYStrHeight(CDC* pDC)
{
	ASSERT(!m_YScaleList.IsEmpty());
	CFont* pOldFont = NULL;
	CFont font;
	m_YLogFont.lfHeight = -GetCurFontDevHeight(m_lYStrFontH);
	if (font.CreateFontIndirect(&m_YLogFont))
		pOldFont = pDC->SelectObject(&font);

	int nH =0;
	TEXTMETRIC tm;
	pDC->GetTextMetrics((LPTEXTMETRIC)&tm); //��Ϊ��ǰӳ�䷽ʽΪMM_TEXT,���Է���ֵʵ�������豸��λ����
	nH = tm.tmHeight + tm.tmExternalLeading;
	
	if (pOldFont)
		pDC->SelectObject(pOldFont);
	font.DeleteObject();
	return nH;
}

//��ȡ���Ŀ̶��ַ����Ŀ���,�߶�,�߼���λ0.1mm
void CChartAxes::GetMaxStrLen(CDC* pDC)
{
	if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
	{
		m_strSize.cx = GetMaxXStrLen(pDC);
		m_strSize.cy = GetMaxYStrHeight(pDC);
	}
	else if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
	{
		m_strSize.cx = GetMaxYStrLen(pDC);
		m_strSize.cy = GetMaxXStrHeight(pDC);
	}
	CPoint pt(m_strSize.cx, m_strSize.cy);
//	pView->ClientToDoc(pt);
	m_strSize.cx = pt.x;
	m_strSize.cy = pt.y;
}

//��ȡֻ����������Ķ���ľ���,rect�ǰ����̶����ֵĶ���ľ���
void CChartAxes::GetAxesRect(CDC* pDC, CRect rect)
{
	ASSERT(!m_YScaleList.IsEmpty());
	ASSERT(!m_XScaleList.IsEmpty());
	m_AxesRect = rect;
	int nVLine = m_YScaleList.GetCount();	//ˮƽ�������ߵ�����		   
	int nHLine = m_XScaleList.GetCount();//��ֱ�������ߵ�����
	ASSERT(m_AxesRect.Width() > m_strSize.cx+SCALE_BLANK);
	//�˴�һ��Ҫ��pView->GetDC(),���򷵻ص�m_strSize���ܲ�ͬ
	//GetMaxStrLen(pView, pView->GetDC());	//��ȡ���Ŀ̶��ַ������߼���λ����,�߶�m_strSize
	//�����԰�ʱΪ�����������С���InitialData
	//��ʱpView,pDC��Ϊ��,Ҳ����������̶��ַ���ռ�ռ�
//	if (pDC)					
//		GetMaxStrLen(pDC);	//��ȡ���Ŀ̶��ַ������߼���λ����,�߶�m_strSize
	int l =	m_strSize.cx + SCALE_BLANK;
	int b = m_strSize.cy + SCALE_BLANK;
	//if (m_AxesRect.Width() > l)
		m_AxesRect.left += l;
	//if (m_AxesRect.Height() > b)
		m_AxesRect.bottom -= b;
}

/*�����������x�������ϵĿ̶�
	rect:		Ϊ�����̶����ֵľ���,�߼�����
	lOrg:		x�����������rect.top��ƫ��ֵ
	nScalePos:	x���ϵĿ̶��ߵ�λ��
*/		
void CChartAxes::DrawAxes(CDC* pDC, IColorScheme* pICS,
							CRect rect, long lOrg, int nScalePos/*0*/)
{
	ASSERT(!m_XScaleList.IsEmpty());
	ASSERT(!m_YScaleList.IsEmpty());
///	CDashLine* pDashLine = NULL;
	if (m_uLPenStyle > PS_SOLID && m_uLPenStyle < PS_NULL)
		m_uLPenStyle = PS_INSIDEFRAME;
/*	{//������
		UINT lpenW;
		CPoint penW;
		//��ʿ�
		lpenW = GetLPenSize();
		penW.x = penW.y = lpenW;
		pDashLine = new CDashLine(*pDC, penW.x);
	}
*/
	int nScaleLen = 15;	//�̶ȳ���
	CRect axesRect = rect;
	//pDC->Rectangle(rect);

	//����������
	CPoint pnt[4];
	UINT xNum, yNum;  
	if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
	{
		xNum = m_XScaleList.GetCount();	//x��̶��ߵĸ���,�������������ݵĸ���
		yNum = m_YScaleList.GetCount() - 1;	//x��̶��ߵĸ���,�������������ݵĸ���
		pnt[0] = axesRect.TopLeft();
		pnt[1].x = axesRect.left;
		pnt[1].y = axesRect.bottom;
		pnt[2].x = axesRect.left;
		pnt[2].y = axesRect.bottom - lOrg;
		pnt[3].x = axesRect.right;
		pnt[3].y = axesRect.bottom - lOrg;
	} 
	else if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
	{
		yNum = m_XScaleList.GetCount();//x��̶��ߵĸ���,�������������ݵĸ���
		xNum = m_YScaleList.GetCount()-1;//x��̶��ߵĸ���,�������������ݵĸ���
		pnt[0].x = axesRect.left + lOrg;
		pnt[0].y = axesRect.top;
		pnt[1].x = axesRect.left + lOrg;
		pnt[1].y = axesRect.bottom;
		pnt[2].x = axesRect.left;
		pnt[2].y = axesRect.bottom;
		pnt[3].x = axesRect.right;
		pnt[3].y = axesRect.bottom;
	}
	
	UINT i = 0;
	CPoint tempPnt[4];
	DWORD wflag = m_wflag;
	//������������������
	if ((wflag&YGRID) == YGRID || (wflag&XGRID) == XGRID)
	{
		tempPnt[0] = axesRect.TopLeft();
		tempPnt[1].x = axesRect.right;
		tempPnt[1].y = axesRect.top;
		tempPnt[2] = axesRect.BottomRight();
		tempPnt[3].x = axesRect.left;
		tempPnt[3].y = axesRect.bottom;
	//	for (i = 0; i < 4; i++)
	//		pView->DocToClient(tempPnt[i]); 
//		if (pDashLine)
//		{//������
//			pDashLine->Polygon(tempPnt, 4);
//		}
//		else
			pDC->Polygon(tempPnt, 4);
	}
	CRect rc;
	rc.left = tempPnt[0].x;
	rc.top = tempPnt[0].y;
	rc.right = tempPnt[2].x;
	rc.bottom = tempPnt[2].y;
//	if(pView)
//	{
//		COLORREF cl = RGB(255,255,255);
//		/***************************************************************************/
//		//	Note : Cony.Zhou Modify here.If WPP document use default color white
//		/***************************************************************************/		
//		if(pView->GetDocument()->QueryWPPDocType() == FALSE)
//		{
//			cl = GetFillColor();
//			pDC->FillRect(&rc,&CBrush(cl));
//		}
//	}
	//����������
/*	for (i = 0; i < 4; i++)
	{
		tempPnt[i] = pnt[i];
		pView->DocToClient(tempPnt[i]); 
	}
*/
//	if (pDashLine)
//	{//������
//		pDashLine->BeenLine(tempPnt[1], tempPnt[0]);
//		pDashLine->BeenLine(tempPnt[2], tempPnt[3]);
//	}
//	else
	{
		pDC->MoveTo(tempPnt[1]);
		pDC->LineTo(tempPnt[0]);
		pDC->MoveTo(tempPnt[2]);
		pDC->LineTo(tempPnt[3]);
	}

	//����̶ȼ��
	long xStep = axesRect.Width() / xNum;
	long yStep = axesRect.Height() / yNum;
	
	//�ڴ˴��ɼ����������ͷ�Ļ���

	//����x���ϵĿ̶���
	CPoint scalePnt1;
	CPoint scalePnt2;
	switch(nScalePos)
	{
		case nothing:
			{
				scalePnt1 = pnt[2];
				scalePnt2 = pnt[2];
			}
			break;
		case above:	 //�̶���x���Ϸ�
			{
				scalePnt1 = pnt[2];
				scalePnt2 = pnt[2];
				scalePnt2.y = pnt[2].y-nScaleLen;
			}
			break;
		case under:	//�̶���x���·�
			{
				scalePnt1 = pnt[2];
				scalePnt2 = pnt[2];
				scalePnt2.y = pnt[2].y+nScaleLen;
			}
			break;
		case bothSide:	//�̶���x������
			{
				scalePnt1 = pnt[2];
				scalePnt1.y = pnt[2].y-nScaleLen;
				scalePnt2 = pnt[2];
				scalePnt2.y = pnt[2].y+nScaleLen;
			}
		break;
	}
	for (i=0; i < xNum; i++)	//���ƿ̶�   
	{
		if (i == xNum-1)	 //�����������һ���̶���ʱ�����
		{
			scalePnt1.x = axesRect.right;
			scalePnt2.x = axesRect.right;
		}
		else
		{
			scalePnt1.x = (long)(scalePnt1.x +  xStep);  //�̶ȼ��ΪxStep
			scalePnt2.x = (long)(scalePnt2.x +  xStep);
		}
		tempPnt[0]	= scalePnt1;
		tempPnt[1]	= scalePnt2;
	//	pView->DocToClient(tempPnt[0]); 
	//	pView->DocToClient(tempPnt[1]); 
//		if (pDashLine)
//		{//������
//			pDashLine->BeenLine(tempPnt[0], tempPnt[1]);
//		}
//		else
		{
			pDC->MoveTo(tempPnt[0]);
			pDC->LineTo(tempPnt[1]);
		}
	}

	//����y���ϵĿ̶���
	switch(nScalePos)
	{
		case nothing:
			{
				scalePnt1 = pnt[1];
				scalePnt2 = pnt[1];
			}
			break;
		case above:	 //�̶���y���ҷ�
			{
				scalePnt1 = pnt[1];
				scalePnt2 = pnt[1];
				scalePnt2.x = pnt[1].x+nScaleLen;
			}
			break;
		case under:	//�̶���y����
			{
				scalePnt1 = pnt[1];
				scalePnt2 = pnt[1];
				scalePnt2.x = pnt[1].x-nScaleLen;
			}
			break;
		case bothSide:	//�̶���y������
			{
				scalePnt1 = pnt[1];
				scalePnt1.x = pnt[1].x+nScaleLen;
				scalePnt2 = pnt[1];
				scalePnt2.x = pnt[1].x-nScaleLen;
			}
			break;
	}
	for (i=0; i < yNum; i++)	//���ƿ̶�   
	{
		if (i == yNum - 1)	 //�����������һ���̶���ʱ�����
		{
			scalePnt1.y = axesRect.top;
			scalePnt2.y = axesRect.top;
		}
		else
		{
			scalePnt1.y = (long)(scalePnt1.y -  yStep);  //�̶ȼ��ΪyStep
			scalePnt2.y = (long)(scalePnt2.y -  yStep);
		}
		tempPnt[0]	= scalePnt1;
		tempPnt[1]	= scalePnt2;
	//	pView->DocToClient(tempPnt[0]); 
	//	pView->DocToClient(tempPnt[1]);
//		if (pDashLine)
//		{//������
//			pDashLine->BeenLine(tempPnt[0], tempPnt[1]);
//		}
//		else
		{
			pDC->MoveTo(tempPnt[0]);
			pDC->LineTo(tempPnt[1]);
		}
	}
//	if (pDashLine)
//		delete pDashLine;
}

BOOL XGetTextExtentPoint32W( HDC hdc,           // handle to DC 
							BSTR lpwString,  // text string
							int cbString,      // characters in string
							LPSIZE lpSize  )
{
	int nLen = 0;
	if(lpwString)
	{
		if(sizeof(TCHAR) == 1)
		{
			LPTSTR pStr = NULL;
			nLen = WideCharToMultiByte(
										CP_ACP,
										WC_COMPOSITECHECK,
										lpwString,
										cbString,
										NULL,
										0,
										NULL,
										NULL);
			if(nLen)
			{
				pStr = new TCHAR[nLen+4];
				if(pStr)
				{
					if(WideCharToMultiByte(
										CP_ACP,
										WC_COMPOSITECHECK,
										lpwString,
										cbString,
										pStr,
										nLen,
										NULL,
										NULL))
					{
						nLen = ::GetTextExtentPoint32(hdc,pStr,nLen,lpSize);
						delete pStr;
						return TRUE;
					}
				}
			}

		}
		else
		{
			return ::GetTextExtentPoint32W(hdc,lpwString,cbString,lpSize);
		}
	}
	return FALSE;	
}

BOOL GetKSTextExtentPoint32(HDC hdc, LPCTEXTWORD pText, int nHesdStrLen, LPSIZE psz)
{
#pragma prompt("rewrite for gb18030")
	return ::GetTextExtentPoint32(hdc, (LPCTSTR)pText, nHesdStrLen, psz);
}

BOOL KSTextExtTextOut(  HDC hdc,			// handle to DC
				  int X,					// x-coordinate of reference point
				  int Y,					// y-coordinate of reference point
				  UINT fuOptions,			// text-output options
				  CONST RECT *lprc,			// optional dimensions
				  LPCTEXTWORD lpszString,	// string
				  UINT nCount)				// number of characters in string
{
	ASSERT(hdc != NULL);
	CString strOut;
	TextStringToString(strOut, lpszString, nCount);
	return ::ExtTextOut(hdc, X, Y, fuOptions, lprc, strOut, strOut.GetLength(), NULL);
}
void CChartAxes::DrawGridAndText(CDC* pDC, IColorScheme* pICS,
								 CRect rect, long lOrg,  DWORD wflag)
{
	CRect axesRect = rect;
	int nHLine, nVLine, nVOff, nHOff; 
	//add by wym for draw dashline
//	CDashLine* pDashLine = NULL;
	if (m_uLPenStyle > PS_SOLID && m_uLPenStyle < PS_NULL)
		m_uLPenStyle = PS_INSIDEFRAME;
//	{//������
//		UINT lpenW;
//		CPoint penW;
//		//��ʿ�
//		lpenW = GetLPenSize();
//		penW.x = penW.y = lpenW;
//		pView->DocToClient(penW);
//		pDashLine = new CDashLine(*pDC, penW.x);
//	}
	///////////////////
	if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
	{
		nHLine = m_YScaleList.GetCount();	//ˮƽ�������ߵ�����		   
		nVLine = m_XScaleList.GetCount();//��ֱ�������ߵ�����
		if (nHLine == 1)
			nVOff = axesRect.Height(); //ˮƽ�������ߵļ��
		else 
			nVOff = axesRect.Height() / (nHLine - 1);
		nHOff = axesRect.Width() / nVLine;	//��ֱ�������ߵļ��
		nVLine += 1;
	}
	else  if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
	{
		nHLine = m_XScaleList.GetCount();	//ˮƽ�������ߵ�����		   
		nVLine = m_YScaleList.GetCount();//��ֱ�������ߵ�����
		nVOff = axesRect.Height() / nHLine;
		nHOff = axesRect.Width() / (nVLine - 1);	//��ֱ�������ߵļ��
		nHLine += 1;
	}
	if (nVOff <= 0)
		nVOff = 1;
	if (nHOff <= 0)
		nHOff = 1;
	ASSERT(nVOff > 0 && nHOff > 0);
	
	KSTextString kstr;
	int nOldTextAlign = pDC->GetTextAlign(); //����ɵ����ֶ��뷽ʽ
	int nStrLen = 0; //�ַ����ĳ���
	LPSIZE lpStrSize = new CSize(0,0); //�ַ����Ŀ���
	CRect strRect(0, 0, 0, 0);
	
	//����ˮƽ�������ߺ�y��̶�����
	CPoint pt1, pt2, pt3;
	CPoint YScalePnt;  //��һ��ˮƽ�������ߵ����
	CPoint YTextPnt; //��һ��ˮƽ�������ߵĿ̶��������
	
	CFont devFont;
	CFont* pOldFont = NULL;
	m_YLogFont.lfHeight = -GetCurFontDevHeight(m_lYStrFontH);
	if (devFont.CreateFontIndirect(&m_YLogFont))
		pOldFont = pDC->SelectObject(&devFont);
#ifndef _WPSREADER
	//else						
	//	AfxMessageBox("���崴��ʧ��");//IDS_MSGBOX_CREATEFONTFAIL);
#endif
	
	pDC->SetTextAlign(TA_CENTER | TA_TOP); //�������x���ж���,y�����϶���

	CSize YOffSiz(0, nVOff); //ˮƽ�������ߵļ��
	CSize YScaleSiz(axesRect.Width(), 0); //ˮƽ�������ߵĳ���
	if ((wflag&YTEXTMID) == YTEXTMID)  //��һ��ˮƽ�������ߵĿ̶��������,�����������̶�֮�����
	{
		YScalePnt = CPoint(axesRect.left, axesRect.bottom);  
		YTextPnt = CPoint(axesRect.left - SCALE_BLANK, axesRect.bottom - m_strSize.cy / 2 - nVOff / 2);
	}
	else //(wflag&YTEXTUNDER)  == YTEXTUNDER	//��һ��ˮƽ�������ߵĿ̶��������,�ڿ̶�֮�����
	{
		YScalePnt = CPoint(axesRect.left, axesRect.bottom);  
	///	YTextPnt = CPoint(axesRect.left - SCALE_BLANK, axesRect.bottom - m_strSize.cy/2);
		YTextPnt = CPoint(axesRect.left - SCALE_BLANK, axesRect.bottom);///sjz
	}
	POSITION pos;
	if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
		pos = m_YScaleList.GetHeadPosition();
	else if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
		pos = m_XScaleList.GetHeadPosition();
	ASSERT(pos!=NULL);
	for (int i=0; i < nHLine; i++)
	{
		//����y��ˮƽ��������
		if ((wflag&YGRID) == YGRID)
		{
			if (i == nHLine - 1)  //Ϊ�˱���y������
			{
				pt1 = axesRect.TopLeft();
				pt2 = axesRect.TopLeft() + YScaleSiz;
			}
			else
			{
				pt1 = YScalePnt;
				pt2 = YScalePnt + YScaleSiz;
			}
//			pView->DocToClient(pt1);
//			pView->DocToClient(pt2);
			//add by wym for draw dashline
//			if (pDashLine)
//			{////������
//				pDashLine->BeenLine(pt1, pt2);
//			}
//			else
			{
				pDC->MoveTo(pt1);
				pDC->LineTo(pt2);	
			}
			YScalePnt -= YOffSiz;
		}
	}
	
	COLORREF oldTxtClr = RGB(0,0,0);
	//COLORREF clrText;
	//���ƿ̶�����
	while (pos)
	{	
		if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
			kstr = m_YScaleList.GetNext(pos);
		else if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
			kstr = m_XScaleList.GetNext(pos);
		pt3 = YTextPnt;
//		pView->DocToClient(pt3);
		//pDC->TextOut(pt3.x, pt3.y, kstr);
		nStrLen = kstr.GetTextSize();
		::GetKSTextExtentPoint32(pDC->m_hDC, (LPCTEXTWORD)kstr, nStrLen, lpStrSize); 
		strRect = CRect(pt3, CSize(lpStrSize->cx, lpStrSize->cy));
		strRect.OffsetRect(-lpStrSize->cx, 0 );
		ASSERT(abs(m_YLogFont.lfEscapement) <= 900);
		if (m_YLogFont.lfEscapement > 0)
			strRect.OffsetRect((int)(-lpStrSize->cy/2*sin(m_YLogFont.lfEscapement*PI/1800)), 
								(int)(lpStrSize->cy/2*sin(m_YLogFont.lfEscapement*PI/1800)));	
		else if (m_YLogFont.lfEscapement < 0)
			strRect.OffsetRect((int)(-lpStrSize->cy/2*sin(m_YLogFont.lfEscapement*PI/1800)), 
								(int)(-lpStrSize->cy/2*sin(m_YLogFont.lfEscapement*PI/1800)));
		
		//LLG_MODIFY_2001_3_24: ��ʾ�ĵ�����ɫֻ������ɫ����������һ������...
//		if (!pDC->IsPrinting() && m_YstrClr == RGB(0,0,0) && 
//				pView->GetDocument()->QueryWPPDocType() == FALSE)//WPP_CODE
//		{
//			clrText = gsGetPreferredTextColor();
//			oldTxtClr = pDC->SetTextColor(clrText);
//		}
//		else
			oldTxtClr = pDC->SetTextColor(KColorModel::IndexToRef(m_YstrClr, pICS));	//������ɫ
		// we should convert multibyte text to singlebyte text because all text is english or number
		::KSTextExtTextOut(pDC->GetSafeHdc(), (strRect.left + strRect.right) / 2, strRect.top, 0, strRect,
						kstr, nStrLen);
		pDC->SetTextColor(oldTxtClr);	
		YTextPnt -=	YOffSiz;
	}
		
	pDC->SelectObject(pOldFont);
	devFont.DeleteObject();
	m_XLogFont.lfHeight = -GetCurFontDevHeight(m_lXStrFontH);
	if (devFont.CreateFontIndirect(&m_XLogFont))
		pOldFont = pDC->SelectObject(&devFont);
#ifndef _WPSREADER
	//else
	//	AfxMessageBox("���崴��ʧ��");//IDS_MSGBOX_CREATEFONTFAIL);
#endif
	
	//���ƴ�ֱ�������ߺ�x��̶�����
	CPoint XTextPnt;
	CPoint XScalePnt(axesRect.left, axesRect.bottom);  //��һ����ֱ�������ߵ����
	if ((wflag&XTEXTMID) == XTEXTMID)  //��һ����ֱ�������ߵĿ̶��������,�����������̶�֮�����
	{
		XTextPnt.x = axesRect.left + nHOff / 2;
		XTextPnt.y = axesRect.bottom + SCALE_BLANK;
	}
	else //(wflag&XTEXTUNDER)  == XTEXTUNDER	//��һ����ֱ�������ߵĿ̶��������,�ڿ̶�֮�����
	{
		XTextPnt.x = axesRect.left;
		XTextPnt.y = axesRect.bottom + SCALE_BLANK;
	}
	CSize XOffSiz(nHOff,0); //��ֱ�������ߵļ��
	CSize XScaleSiz(0, axesRect.Height()); //��ֱ�������ߵĳ���
	if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
		pos = m_XScaleList.GetHeadPosition();
	else if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
		pos = m_YScaleList.GetHeadPosition();
	ASSERT(pos!=NULL);
	for (int i=0; i < nVLine; i++)
	{
		//����x�ᴹֱ��������
		if ((wflag&XGRID) == XGRID)
		{
			if (i == nVLine - 1)  //Ϊ�˱���x������
			{
				pt1 = axesRect.BottomRight();
				pt2 = axesRect.BottomRight() - XScaleSiz;
			}
			else
			{
				pt1 = XScalePnt;
				pt2 = XScalePnt - XScaleSiz;
			}
//			pView->DocToClient(pt1);
//			pView->DocToClient(pt2);
			//add by wym for draw dashline
//			if (pDashLine)
//			{////������
//				pDashLine->BeenLine(pt1, pt2);
//			}
//			else
			{
				pDC->MoveTo(pt1);
				pDC->LineTo(pt2);	
			}
			XScalePnt += XOffSiz;
		}
	}
	//���ƿ̶�����
	while (pos)
	{
		if (m_nAxesType == Vertical || m_nAxesType == Vertical3D)
			kstr = m_XScaleList.GetNext(pos);
		else if (m_nAxesType == Horizontal || m_nAxesType == Horizontal3D)
			kstr = m_YScaleList.GetNext(pos);
		pt3 = XTextPnt;
// 		pView->DocToClient(pt3);
		//pDC->TextOut(pt3.x, pt3.y, kstr);
		nStrLen = kstr.GetTextSize();
		::GetKSTextExtentPoint32(pDC->m_hDC, (LPCTEXTWORD)kstr, nStrLen, lpStrSize); 
		strRect = CRect(pt3, CSize(lpStrSize->cx, lpStrSize->cy));
		strRect.OffsetRect(-lpStrSize->cx / 2, 0);
		ASSERT(abs(m_XLogFont.lfEscapement) <= 900);
		if (m_XLogFont.lfEscapement > 0)
			strRect.OffsetRect((int)(-lpStrSize->cy / 2 * sin(m_XLogFont.lfEscapement * PI / 1800)),
							(int)(lpStrSize->cx / 2 * sin(m_XLogFont.lfEscapement * PI/1800)));	
		else if (m_XLogFont.lfEscapement < 0)
			strRect.OffsetRect((int)(-lpStrSize->cy / 2 * sin(m_XLogFont.lfEscapement * PI / 1800)),
							(int)(-lpStrSize->cx / 2 * sin(m_XLogFont.lfEscapement * PI / 1800)));	
		//LLG_MODIFY_2001_3_24: ��ʾ�ĵ�����ɫֻ������ɫ����������һ������...
//		if (!pDC->IsPrinting() && m_XstrClr == RGB(0,0,0) &&
//				pView->GetDocument()->QueryWPPDocType() == FALSE)//WPP_CODE
//		{
//			clrText = gsGetPreferredTextColor();
//			oldTxtClr = pDC->SetTextColor(clrText);
//		}
//		else
			oldTxtClr = pDC->SetTextColor(KColorModel::IndexToRef(m_XstrClr, pICS));	//������ɫ
		// we should convert multibyte text to singlebyte text because all text is english or number
		::KSTextExtTextOut(pDC->GetSafeHdc(), (strRect.left+strRect.right)/2, strRect.top, 0, strRect,
						kstr, nStrLen);
		pDC->SetTextColor(oldTxtClr);	
		XTextPnt +=	XOffSiz;
	}

	pDC->SetTextAlign(nOldTextAlign);
	delete lpStrSize;
	if (pOldFont != NULL)
		pDC->SelectObject(pOldFont);
	devFont.DeleteObject();
//	if (pDashLine)
//		delete pDashLine;
}

void CChartAxes::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	CRect rct = m_rect;
	pDC->LPtoDP(&rct);
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formFrac ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

	DrawPosition( pDC, rct );
	
	//	set pen
	int penW = 0;
	CPen* pOldPen = SelectPenObject(pDC, pICS, penW, FALSE);
	CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
	int nOldBkMode = pDC->GetBkMode();
	COLORREF oldBkClr = pDC->GetBkColor();
	
	GetAxesRect(pDC, m_rect);
	DrawAxes(pDC, pICS, m_AxesRect, m_lOrg, m_nScalePos);//�������������

	pDC->SetBkMode(nOldBkMode);
	pDC->SetBkColor(oldBkClr);
	
	nOldBkMode = pDC->SetBkMode(TRANSPARENT);
	oldBkClr = pDC->SetBkColor(GetBkColor());
	DWORD wflag = m_wflag; 
	DrawGridAndText(pDC, pICS, m_AxesRect, m_lOrg, wflag);//��������Ϳ̶�����
	pDC->SetBkMode(nOldBkMode);
	pDC->SetBkColor(oldBkClr);

	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);

	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
}

static BOOL nClipMode=-100;
void WPSSelectClipRgnEx(const HDC hdc, const HRGN hrgn)
{
	if (hrgn==NULL && nClipMode!=RGN_COPY && nClipMode!=-100)
		return;
	//nClipMode���ڣ�100��ԭ����Ĭ�Ϸ�ʽ��
	if (nClipMode==-100)
		::SelectClipRgn(hdc,hrgn);
	else 
		::ExtSelectClipRgn(hdc,hrgn,nClipMode);
}
//	���ν���ɫ
BOOL WPSSelectClipRectRgn(CDC* pDC, CRect rct, CPoint rPnt, int nType)
{
	ASSERT_VALID (pDC);
	
	//ASSERT (pDC->GetMapMode()==MM_TEXT || pDC->GetMapMode()==MM_ANISOTROPIC);
	//INT nMode = pDC->GetMapMode();
	//if ((nMode != MM_TEXT) && (nMode != MM_ANISOTROPIC))// wdb[bug id 2284] for ͼ�ķ��ſ�
	//	return FALSE;

	//LLG_MODIFY_2002_6_21
	//MM_ISOTROPIC && MM_ANISOTROPICӳ��ģʽ�µĲü��������
	//������ģʽ�£���֧��ֱ�ӵĲü���ѡ��������ΪMM_TEXTģʽ
	//��Ϊ���ü�����֧���߼�����~~
	BOOL bSaveData = FALSE;
	int nSaveMapMode;
	CSize szSaveWinEx;
	CSize szSaveViewEx;
	CPoint ptSaveViewOrg;
	if (pDC->GetMapMode() == MM_ISOTROPIC || pDC->GetMapMode() == MM_ANISOTROPIC)
	{
		nSaveMapMode = pDC->GetMapMode();
		szSaveWinEx = pDC->GetWindowExt();
		szSaveViewEx = pDC->GetViewportExt();
		ptSaveViewOrg = pDC->GetViewportOrg();

		bSaveData = TRUE;

		pDC->LPtoDP(&rct);
		rct -= ptSaveViewOrg; //��ȥ��ƫ�㣬��Ϊ������ټ���(ͨ���㷨)

		pDC->LPtoDP(&rPnt);
		rPnt -= ptSaveViewOrg;

		pDC->SetMapMode(MM_TEXT);
	}
/*
	//LLG_MODIFY_2002_6_21
	//��ӡԤ����λ����Ľ������
	//MSDN: Q128334
	//http://support.microsoft.com/default.aspx?scid=kb;EN-US;q128334
	if (pDC->IsKindOf(RUNTIME_CLASS(CPreviewDC)))
	{
        CPreviewDC *pPrevDC = (CPreviewDC *)pDC;
        pPrevDC->PrinterDPtoScreenDP(&rct.TopLeft());
        pPrevDC->PrinterDPtoScreenDP(&rct.BottomRight()); 
		// Now offset the result by the viewport origin of the print preview window...
		CPoint ptOrg;
		::GetViewportOrgEx(pDC->m_hDC,&ptOrg);
        rct += ptOrg;

		pPrevDC->PrinterDPtoScreenDP(&rPnt);
	}
    else
*/	{
		POINT ptVPOrg = pDC->GetViewportOrg();
		rct.OffsetRect(ptVPOrg.x, ptVPOrg.y);	// תΪ�ͻ�������
	}

	CRgn rgnClip;
	BOOL bOK = FALSE;
	if (nType == CRectObj::ellipse)
		bOK = rgnClip.CreateEllipticRgnIndirect(rct);
	else if (nType == CRectObj::roundRectangle)
		bOK = rgnClip.CreateRoundRectRgn(rct.left, rct.top, rct.right, rct.bottom, rPnt.x, rPnt.y);
	else	//if (nType == rectangle)
		bOK = rgnClip.CreateRectRgnIndirect(rct);
	
	if (bOK == TRUE)
	{
		if (pDC->IsPrinting()) //��ӡʱ����ҳȡ��ó��ü���
			::ExtSelectClipRgn(pDC->GetSafeHdc(), (HRGN)rgnClip, RGN_AND);		
		else
			//pDC->SelectClipRgn(&rgnClip);
			WPSSelectClipRgnEx(pDC->GetSafeHdc(),(HRGN)rgnClip);
	}

	//���ݻָ�...
	if (bSaveData == TRUE)
	{
		pDC->SetMapMode(nSaveMapMode);
		pDC->SetWindowExt(szSaveWinEx);
		pDC->SetViewportExt(szSaveViewEx);
		pDC->SetViewportOrg(ptSaveViewOrg);
	}

	return bOK;
}

void CHistogram::RectangleDraw(CDC* pDC, IColorScheme* pICS, CRect& rct, int nType)
{
/*	if (GetBkMode() == GRADIENT && nType == CFPBase::IsRegular)
	{
		BOOL bOK = FALSE;
		//if (pDC->IsPrinting() == FALSE)
		{
			rct.bottom --;
			rct.right --;

			COLORREF clrBk = KColorModel::IndexToRef(GetBkColor(), pICS);
			//LLG_MODIFY_2002_5_25 ����ڶ���ɫ����(��ΪWPS�ĵڶ�����ɫ�����ɫ��ͬһ����!)
			COLORREF clrFill = KColorModel::CalcSecondColorForOneShade(GetBkColor(),
																GetFillColor(), pICS);
			bOK = ::GradientDrawRect(pDC, rct, CPoint(0, 0), CRectObj::rectangle, clrBk, clrFill,
									GetColorDirection(), GetColorDistortion(), m_nTransparence);
			if (bOK)
			{
				//	����
				CBrush* pOldB = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
				pDC->Rectangle(rct);	//device coordinate
				pDC->SelectObject(pOldB);
			}
		}
		if (!bOK)
		{
			ASSERT(GetBkMode() == GRADIENT);
			SetBkMode(OPAQUE);
			KCOLORINDEX indexOldColor = GetFillColor();
			SetFillColor(GetBkColor());
			CBrush* pOldB = SetBrushBkModeBkColor(pDC, pICS);

			pDC->Rectangle(rct);

			pDC->SelectObject(pOldB);
			SetFillColor(indexOldColor);
			SetBkMode(GRADIENT);		
		}
	}
	else	// wdb[bug id 2248]
*/	{
		if (nType != CFPBase::IsRegular) // ����Ƥ����ʱ��û�����ɫ��
		{
			pDC->Rectangle(rct);
			return;
		}

		if (m_nBkMode == TRANSPARENT)
		{				
			CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);			
			pDC->Rectangle(rct);
			pDC->SelectObject(pOldBrush);
		}
		else
		{
		/*	if (::FillDrawRect(this, pDC, pICS, rct, CPoint(0, 0), CRectObj::rectangle))
			{
			//	::FillDrawRect(this, pDC, pICS, rct, CPoint(0, 0), CRectObj::rectangle);
				CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
				pDC->Rectangle(rct);	//device coordinate
				pDC->SelectObject(pOldBrush);
			}
			else
		*/	{
				CBrush* pOldB = SetBrushBkModeBkColor(pDC, pICS);
				pDC->Rectangle(rct);
				pDC->SelectObject(pOldB);
			}
		}
	}
}

int AdjustAngle( int theta, BOOL* pbIsRegular=NULL);

//	��õ�ǰ����ת��ĵ�
void GetRotatePoint( CPoint* point, const CPoint& center, const int theta);

void CRectObj::PolygonDrawInside(CDC* pDC, IColorScheme* pICS,
								 CPoint* pnt, int num, int nType)
{
/*	if (GetBkMode() == GRADIENT && nType == CFPBase::IsRegular)
	{
		#pragma prompt ("���󽥱�ɫ")
		BOOL bOK = FALSE;
		//if (pDC->IsPrinting() == FALSE)
		{
			COLORREF clrBk = KColorModel::IndexToRef(GetBkColor(), pICS);
			//LLG_MODIFY_2002_5_25 ����ڶ���ɫ����(��ΪWPS�ĵڶ�����ɫ�����ɫ��ͬһ����!)
			COLORREF clrFill = KColorModel::CalcSecondColorForOneShade(GetBkColor(),
																GetFillColor(), pICS);
			bOK =	::GradientDrawPolygon(pDC, pnt, num, clrBk, clrFill, 
										  GetColorDirection(),
										  GetColorDistortion(), 
										  m_nTransparence);
		}
		if (!bOK)
		{
			ASSERT(GetBkMode() == GRADIENT);
			SetBkMode(OPAQUE);
			KCOLORINDEX indexOldColor = GetFillColor();
			SetFillColor(GetBkColor());
			CBrush* pOldB = SetBrushBkModeBkColor(pDC, pICS);
			//	�������
			CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
			pDC->Polygon(pnt, num);
			pDC->SelectObject(pOldPen);

			pDC->SelectObject(pOldB);
			SetFillColor(indexOldColor);
			SetBkMode(GRADIENT);
		}
	}
	else	// wdb[bug id 2284]
*/	{	
		//	�������
		if (nType != CFPBase::IsRegular) // ����Ƥ����ʱ��û�����ɫ��
		{
			CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
			pDC->Polygon(pnt, num);
			pDC->SelectObject(pOldPen);
			return;
		}

		if (m_nBkMode == TRANSPARENT)
		{				
			CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
			CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
			pDC->Polygon(pnt, num);
			pDC->SelectObject(pOldBrush);
			pDC->SelectObject(pOldPen);
		}
		else
		{
		/*	if (FillDrawPolygon(this, pDC, pICS, pnt, num))
			{
				// FillDrawPolygon(this, pDC, pICS, pnt, num);
				CBrush* pOldB = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
				CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
				pDC->Polygon(pnt, num);	//	pDC->PolyBezier(pnt, num);
				pDC->SelectObject(pOldB);
				pDC->SelectObject(pOldPen);
			}
			else	//clip failed
		*/	{
				CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
				pDC->Polygon(pnt, num);
				pDC->SelectObject(pOldBrush);
			}
		}
	}
}

void CRectObj::PolygonDraw(CDC* pDC, IColorScheme* pICS, CPoint* pnt, int num, int nType)
{
/*	if (GetBkMode() == GRADIENT && nType == CFPBase::IsRegular)
	{
		BOOL bOK = FALSE;
		//if (pDC->IsPrinting() == FALSE)
		{
			COLORREF clrBk = KColorModel::IndexToRef(GetBkColor(), pICS);
			//LLG_MODIFY_2002_5_25 ����ڶ���ɫ����(��ΪWPS�ĵڶ�����ɫ�����ɫ��ͬһ����!)
			COLORREF clrFill = KColorModel::CalcSecondColorForOneShade(GetBkColor(),
																GetFillColor(), pICS);
			bOK = ::GradientDrawPolygon(pDC, pnt, num, clrBk, clrFill,
											GetColorDirection(),
											GetColorDistortion(),
											m_nTransparence);
			if (bOK)
			{
				//	������
				CBrush* pOldB = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
				pDC->Polygon(pnt, num);
				pDC->SelectObject(pOldB);
			}
		}
		if (!bOK)
		{
			ASSERT(GetBkMode() == GRADIENT);
			SetBkMode(OPAQUE);
			KCOLORINDEX indexOldColor = GetFillColor();
			SetFillColor(GetBkColor());
			CBrush* pOldB = SetBrushBkModeBkColor(pDC, pICS);

			pDC->Polygon(pnt, num);	//	pDC->PolyBezier(pnt, num);
			
			pDC->SelectObject(pOldB);
			SetFillColor(indexOldColor);
			SetBkMode(GRADIENT);
		}
	}
	else	// wdb[bug id 2284]
*/	{
		if (nType != CFPBase::IsRegular) // ����Ƥ����ʱ��û�����ɫ��
		{			
			pDC->Polygon(pnt, num);	//	pDC->PolyBezier(pnt, num);
			return;
		}

		if (m_nBkMode == TRANSPARENT)
		{				
			CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
			pDC->Polygon(pnt, num);	//	pDC->PolyBezier(pnt, num);
			pDC->SelectObject(pOldBrush);
		}
		else
		{
		/*	if (FillDrawPolygon(this, pDC, pICS, pnt, num))
			{
			//	FillDrawPolygon(this, pDC, pICS, pnt, num);
				CBrush* pOldB = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
				pDC->Polygon(pnt, num);	//	pDC->PolyBezier(pnt, num);
				pDC->SelectObject(pOldB);
			}
			else
		*/	{
				CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
				pDC->Polygon(pnt, num);
				pDC->SelectObject(pOldBrush);
			}
		}
	}
		
}

//	pnt is in device coords
void CRectObj::DrawPolygon(CDC* pDC, IColorScheme* pICS,
				 CPoint* pnt, UINT uCount, int nType, int nStep/*=3*/)
{
	switch (nType)
	{
	case CFPBase::IsRegular:
		if (GetBkMode() == INVERT)
		{	CRgn rgn;
			if (rgn.CreatePolygonRgn(pnt, uCount, ALTERNATE))
				pDC->InvertRgn(&rgn);	
		}
		else
		{
			if (GetEndStyle() == CFPBase::ES_Open)
			{
				//	����
				PolygonDrawInside(pDC, pICS, pnt, uCount, nType);
				//	����
				pDC->Polyline(pnt, uCount);			//��Ե
			}
			else
			{
				//�����޸�ΪS2�ļ�ת��  (���� ��)
#ifdef _WPS_S2
				if (CWpsDoc::s_bWps2S2)
					g_S2Tool.S2_Polygon(pDC, uCount, pnt);
				else
#endif //_WPS_S2
					PolygonDraw(pDC, pICS, pnt, uCount, nType);
			}
		}
		//	pDC->Polygon(pnt, uCount);
		/*��·�����
		{	pDC->BeginPath();
			pDC->MoveTo(pnt[0]);
			for (int i =1; i<uCount; i++)
				pDC->LineTo(pnt[i]);
			pDC->LineTo(pnt[0]);
			pDC->EndPath();
			pDC->SelectStockObject(GRAY_BRUSH);
			pDC->FillPath();
		}
		*/
		break;
/*	case CFPBase::IsRubberBand:
		if (GetBkMode() == INVERT)
		{	CRgn rgn;
			if (rgn.CreatePolygonRgn(pnt, uCount, ALTERNATE))
				pDC->InvertRgn(&rgn);	
		}
		else
			PolyBlt(pDC, pnt, uCount, TRUE, DSTINVERT, nStep);
		break;
	case CFPBase::IsPureShadow:
		if (GetBkMode() == TRANSPARENT)
		{	if (GetEndStyle() == CFPBase::ES_Open)
			{	CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
				pDC->Polygon(pnt, uCount);           //����
				pDC->SelectObject(pOldPen);
				pDC->Polyline(pnt, uCount);			//��Ե
			}
			else
				pDC->Polygon(pnt, uCount);
			//	pDC->PolyBezier(pnt, uCount);
		}	
		else
		{
			COLORREF clrShadow = KColorModel::IndexToRef(GetShadowColor(), pICS);
			::DrawPurePolygon(pDC, pnt, uCount, clrShadow);
		}
		break;
	case CFPBase::IsFogShadow:
		if (GetBkMode() == TRANSPARENT)
		{	if (GetEndStyle() == CFPBase::ES_Open)
			{	CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
				pDC->Polygon(pnt, uCount);           //����
				pDC->SelectObject(pOldPen);
				pDC->Polyline(pnt, uCount);			//��Ե
			}
			else
				pDC->Polygon(pnt, uCount);
			//	pDC->PolyBezier(pnt, uCount);
		}	
		else
		{
			COLORREF clrShadow = KColorModel::IndexToRef(GetShadowColor(), pICS);
			::DrawFogPolygon(pDC, pnt, uCount, clrShadow);
			//	��������ĺ��������ٶȼ��������Ƕ������һ��������
			//	DrawFogPolygon_Frame(pDC, pnt, uCount, clrShadow);
		}
		break;
*/	}
}

// return p[4] of RectPoints is in logical coordinates
//	��ö���RECT��ת��ĸ�����
RectPoints GetRotateRectPoints( const CRect& rect,
								const CPoint& center,
								const int theta, BOOL* pbIsRegular /*=NULL*/);

void CHistogram::DrawRectangle(CDC* pDC, IColorScheme* pICS,
							 const CRect& rect, 
							  const CPoint& center,	int theta, int nType)
{
	CRect rct = rect;
	RectPoints rp;
    CPoint pnt[4];
//	UINT lpenW;
	CPoint penW;
//	BOOL bDashLine = FALSE;
	if(m_uLPenStyle > PS_SOLID && m_uLPenStyle < PS_NULL)
		m_uLPenStyle = PS_INSIDEFRAME;
/*
	{//������
		//��ʿ�
		lpenW = GetLPenSize();
		penW.x = penW.y = lpenW;
		if (pView)
			pView->DocToClient(penW);
		bDashLine = TRUE;
	}
*/
	if (abs(theta) < 5)	//	��thetaС��Լ���ʱ
	{	if (nType != IsRubberBand && theta != 0)
			m_theta = 0;//SetObjTheta(0);     //	�Զ�����
		if (nType != IsFogShadow)
		{
		//	if (pView)
		//		pView->DocToClient(rct);
			if (GetBkMode() == INVERT)
			{	CRgn rgn;
				if (rgn.CreateRectRgnIndirect(rct))
					pDC->InvertRgn(&rgn);	
			//	���㷨��HP�������ֻ�Ժ��֡�ͼ����Ч������ĳЩӢ��������Ч
			}
			else
			{
				//changed by wym for drawing dash line 02/02/1999
			//	if (bDashLine && nType != IsRubberBand)
			//	{	//	������
			//		RectangleDrawInside(pDC, pICS, rct, nType);
			//		DrawDashRectangle(pDC, penW.x, rct, GetLPenColor());
			//	}
			//	else
				{
					//�����޸�ΪWPS->S2ת�� (���� ��)
#ifdef _WPS_S2
					if (CWpsDoc::s_bWps2S2)
						g_S2Tool.S2_Rectangle(pDC, rct);
					else
#endif 
						RectangleDraw(pDC, pICS, rct, nType);
				}
			}
			return;
		}
		pnt[0].x = rect.left;
		pnt[0].y = rect.top;
		pnt[1].x = rect.right;
		pnt[1].y = rect.top;
		pnt[2].x = rect.right;
		pnt[2].y = rect.bottom;
		pnt[3].x = rect.left;
		pnt[3].y = rect.bottom;
	}
    else
    {	if ((GetBkMode() == OPAQUE || GetBkMode() == GRADIENT) &&
			(nType ==IsPureShadow || nType ==IsFogShadow))
		{	//	���ڽ�Ҫ��FillRgnȥ��������Ӱ������Ҫ�Ŵ���ߵİ����λ
			int penW = GetLPenSize();
			rct.InflateRect(penW/2, penW/2);
		}
		rp = GetRotateRectPoints(rct, center, theta, NULL);
		for (int i=0; i<4; i++)
			pnt[i] = rp.p[i];
	}
//	if (pView)
//	{
//		for (UINT i=0; i<4; i++)
//			pView->DocToClient(pnt[i]);		//	ת���ɿͻ���
//	}
//	if (bDashLine && nType != IsRubberBand)
//	{
//		CDashLine dashline(*pDC,penW.x);
//		DrawDashPolygon(&dashline, pDC, pICS, pnt, 4, nType);
//	}
//	else
		DrawPolygon(pDC, pICS, pnt, 4, nType, 3);
}

//����һ��RGBֵ,������ɫ����ٷ�֮nAdd
COLORREF AddRGB(COLORREF clr, int nAdd)
{
	WORD tmp;
	BYTE r = GetRValue(clr);
	BYTE g = GetGValue(clr);
	BYTE b = GetBValue(clr);
	if(r == g && g == b)	//�ǻҶ�,��ڰ�ɫ
	{
		tmp =	(WORD)(r + 255.0 * nAdd / 100);
		if(tmp>255)
			r = 255;
		else
			r = (BYTE)tmp; 
		tmp =	(WORD)(g + 255.0 * nAdd / 100);
		if(tmp>255)
			g = 255;
		else
			g = (BYTE)tmp; 
		tmp =	(WORD)(b + 255.0 * nAdd / 100);
		if(tmp>255)
			b = 255;
		else
			b = (BYTE)tmp; 
	}
	else 
	{
	   if(r==g)
	   {
		   switch(r)
		   {
			case 0:		b = 192; break;
			case 128:	b = 192; break;
			case 255:	b = 192; break;
		   }
	   }
	   else if(r==b)
	   {
		   switch(b)
		   {
			case 0:		g = 192; break;
			case 128:	g = 192; break;
			case 255:	g = 192; break;
		   }
	   }
	   else if(g==b)
	   {
		   switch(g)
		   {
			case 0:		r = 192; break;
			case 128:	r = 192; break;
			case 255:	r = 192; break;
		   }
	   }
	}
	COLORREF newClr(RGB(r,g,b));
	return 	newClr;
}

/*	nScale Ϊ�϶��㵽���ζ������Ͻǵľ�������εĸߵı�ֵ
	aspect ȡֵΪ1-4,��Ӧ���������ļ��ֲ�ͬ����ͼ 
	color	���1-4����ɵ������ɫ
	nType	���ݸ�DrawPolygon()�Ĳ���
*/
void CHistogram::DrawCube( CDC* pDC, IColorScheme* pICS, 
							CRect logRect, CPoint center, int theta, 
							int nScale, int aspect, int nType)
{
	BOOL bDashLine = FALSE;
	CPoint penW;
	int lpW = GetLPenSize();
//	CDashLine* pDashLine = NULL;
	if(m_uLPenStyle > PS_SOLID && m_uLPenStyle < PS_NULL && nType != IsRubberBand)
		m_uLPenStyle = PS_INSIDEFRAME;
/*	{//������
		bDashLine = TRUE;
		//��ʿ�
		penW.x = penW.y = lpW;
		if (pView)
			pView->DocToClient(penW);
		pDashLine = new CDashLine(*pDC,penW.x);
	}
*/	CPoint pnt[7];		
	CSize rectSize(logRect.Width(), logRect.Height());
	if (nScale == 0 || nScale == 100)
	{
		RectPoints rp = GetRotateRectPoints(logRect, center, theta, NULL);
		CPoint pt[4];
		for(int i = 0; i<4; i++)
		{
			pt[i] = rp.p[i];  //תΪ�豸����
		//	if (pView)
		//		pView->DocToClient(pt[i]);
		}
		if(nScale == 0)
		{
		//	if (pDashLine && nType != IsRubberBand)
		//		DrawDashPolygon(pDashLine, pDC, pICS, pt, 4, nType);
		//	else
				DrawPolygon(pDC, pICS, pt, 4, nType, 3);	//����1-4������ɵ���
		}
		else //nScale == 100
		{
			if (aspect ==1 || aspect == 3)
			{
				pt[0] = pt[3];
			//	if (pDashLine && nType != IsRubberBand)
			//		DrawDashPolyLine(pDashLine, pDC, pICS, pt, 2, nType);
			//	else
					pDC->Polyline(pt,2);
			}
			if (aspect ==2 || aspect == 4)
			{
				pt[1] = pt[2];
			//	if (pDashLine && nType != IsRubberBand)
			//		DrawDashPolyLine(pDashLine, pDC, pICS, pt, 2, nType);
			//	else
					pDC->Polyline(pt,2);
			}
		}
	//	if (pDashLine)
	//		delete pDashLine;
		return;
	}
	
	long lOff = MIN(rectSize.cy, rectSize.cx) * nScale / 100;
	switch(aspect)
	{
	case 1:
	default:
		{
			//1,5,7,3,2Ϊ����
			pnt[0].x = logRect.left; 
			pnt[0].y = logRect.top + lOff;
			pnt[4].x = logRect.left + lOff;
			pnt[4].y = logRect.top;
			pnt[6].x = logRect.right;
			pnt[6].y = logRect.bottom - lOff;
			pnt[2].x = logRect.right - lOff;
			pnt[2].y = logRect.bottom;
			pnt[1].x = logRect.right - lOff;
			pnt[1].y = pnt[0].y;
			//4,6Ϊ����
			pnt[3].x = logRect.left;
			pnt[3].y = logRect.bottom;
			pnt[5].x = logRect.right;
			pnt[5].y = logRect.top;
		}
		break; 
	case 2:
		{
			//1,5,7,3,2Ϊ����
			pnt[0].x = logRect.right; 
			pnt[0].y = logRect.top + lOff;
			pnt[4].x = logRect.right - lOff;
			pnt[4].y = logRect.top;
			pnt[6].x = logRect.left;
			pnt[6].y = logRect.bottom - lOff;
			pnt[2].x = logRect.left + lOff;
			pnt[2].y = logRect.bottom;
			pnt[1].x = logRect.left + lOff;
			pnt[1].y = pnt[0].y;
			//4,6Ϊ����
			pnt[3].x = logRect.right;
			pnt[3].y = logRect.bottom;
			pnt[5].x = logRect.left;
			pnt[5].y = logRect.top;
		}
		break; 
	case 3:
		{
			//1,5,7,3,2Ϊ����
			pnt[0].x = logRect.right; 
			pnt[0].y = logRect.bottom - lOff;
			pnt[4].x = logRect.right - lOff;
			pnt[4].y = logRect.bottom;
			pnt[6].x = logRect.left;
			pnt[6].y = logRect.top + lOff;
			pnt[2].x = logRect.left + lOff;
			pnt[2].y = logRect.top;
			pnt[1].x = logRect.left + lOff;
			pnt[1].y = pnt[0].y;
			//4,6Ϊ����
			pnt[3].x = logRect.right;
			pnt[3].y = logRect.top;
			pnt[5].x = logRect.left;
			pnt[5].y = logRect.bottom;
		}
		break; 
	case 4:
		{
			//1,5,7,3,2Ϊ����
			pnt[0].x = logRect.left; 
			pnt[0].y = logRect.bottom - lOff;
			pnt[4].x = logRect.left + lOff;
			pnt[4].y = logRect.bottom;
			pnt[6].x = logRect.right;
			pnt[6].y = logRect.top + lOff;
			pnt[2].x = logRect.right - lOff;
			pnt[2].y = logRect.top;
			pnt[1].x = logRect.right - lOff;
			pnt[1].y = pnt[0].y;
			//4,6Ϊ����
			pnt[3].x = logRect.left;
			pnt[3].y = logRect.top;
			pnt[5].x = logRect.right;
			pnt[5].y = logRect.bottom;
		}
		break; 
	}
	for(int i = 0; i<7; i++)
	{
		if(theta != 0)
			::GetRotatePoint(pnt+i, center, theta);   //��ת������
	//	if(pView)
	//		pView->DocToClient(pnt[i]);  //תΪ�豸����
	}
	
	CBrush newDevBrush;
	CBrush* pOldBrush = NULL;
	LOGBRUSH newLogBrush = KLOGBRUSH2LOGBRUSH(GetFillLogBrush(), pICS);	//ȡ��ǰ�߼�ˢ
	if(newLogBrush.lbColor != RGB(255,255,255)) 
		newLogBrush.lbColor = AddRGB(newLogBrush.lbColor, 30); //��ɫ����ٷ�֮30
	if(newLogBrush.lbHatch%2 == 0)	//ƥ�����
		newLogBrush.lbHatch += 1;
	else
		newLogBrush.lbHatch -= 1;
	if (newDevBrush.CreateBrushIndirect(&newLogBrush))
		pOldBrush = pDC->SelectObject(&newDevBrush);
	
	CPoint tempPnt[4];
//	if (pDashLine && nType != IsRubberBand)
//		DrawDashPolygon(pDashLine, pDC, pICS, pnt, 4, nType);
//	else
		DrawPolygon(pDC, pICS, pnt, 4, nType, 3);	//����1-4������ɵ���
	tempPnt[0] = pnt[0];
	tempPnt[1] = pnt[1];
	tempPnt[2] = pnt[5];
	tempPnt[3] = pnt[4];
	if(pOldBrush)
		pDC->SelectObject(pOldBrush);
//	if (pDashLine && nType != IsRubberBand)
//		DrawDashPolygon(pDashLine, pDC, pICS, tempPnt, 4, nType);
//	else
		DrawPolygon(pDC, pICS, tempPnt, 4, nType, 3);	//����1,2,6,5������ɵ���
	tempPnt[0] = pnt[1];
	tempPnt[1] = pnt[2];
	tempPnt[2] = pnt[6];
	tempPnt[3] = pnt[5];
//	if (pDashLine && nType != IsRubberBand)
//		DrawDashPolygon(pDashLine, pDC, pICS, tempPnt, 4, nType);
//	else
		DrawPolygon(pDC, pICS, tempPnt, 4, nType, 3);	//����2,3,7,6������ɵ���
//	if (pDashLine)
//		delete pDashLine;
}

int s_nPoints = 0;
static int s_nAllocPoints = 0;
CPoint* ellipsePnt = NULL;
static double A, B, C, D;		//	��¼��Բ��ת��ķ��̵Ĳ���
static double Ca, Sa;			//	cos(alpha), sin(alpha), alpha ����Բת��
static double s_a, s_b;			//	�����̰���ֵ
static BOOL s_bAdjust;			//	�����ұ߽�

void GetRotatedFunction( const CRect& rect, int alpha )
{
	s_a = s_b = 0;
	A = B = C = D = 0;
	if ( ellipsePnt )
		delete ellipsePnt;
	ellipsePnt = NULL;
	s_nPoints = 0;
	s_nAllocPoints = 0;

	CPoint pntAB;
	pntAB.x = rect.Width()/2;
	pntAB.y = rect.Height()/2;
//	if ( pView )
//		pView->DocToClient( pntAB );

	s_a = MAX( 1, pntAB.x );	//aΪ��Բ�볤����豸���곤��
	s_b = MAX( 1, pntAB.y );	//bΪ��Բ�������豸���곤��
		
	double alp = alpha*PI/1800;
	Ca = cos(alp);
	Sa = sin(alp);

	double SS = Sa*Sa;
	double CC = Ca*Ca;
	double k = s_b/s_a;
	A = CC*k + SS/k;
	B = SS*k + CC/k;
	C = Sa*Ca*(k-1/k);
	D = -s_a*s_b;
	s_bAdjust = ( alpha == 0 );
}

long D2I( double t )
{
	return (long)( t+((t<0)?-1:1)*0.5 );
}
void GetStartPnt( CPoint& p1 )
{
	double p1x, p1y;
	p1x =  sqrt( -D*B );	//p1x>0 always!!
	p1y = -C*p1x/B;
	p1.x = D2I( p1x );
	p1.y = D2I( p1y );
}	

// point is in device coordinates
//s_nPoints�����Բ�Ǿ��ε�ʵ�ʵĵ���,s_nAllocPoints��Ϊ10��������
static void AddPoint(const CPoint& point)
{
	if (s_nPoints == s_nAllocPoints)
	{	CPoint* newPoints = CPTObj::NewPoints(s_nAllocPoints + 10);
		if ( newPoints == NULL )
			return;
		if (ellipsePnt != NULL)
		{	memcpy(newPoints, ellipsePnt, sizeof(CPoint) * s_nAllocPoints);
			delete ellipsePnt;
		}
		ellipsePnt = newPoints;
		s_nAllocPoints += 10;
	}
	if (s_nPoints == 0 || ellipsePnt[s_nPoints - 1] != point)
		ellipsePnt[s_nPoints++] = point;
}

//	���� I ���ĵ�
void CalcRegion1Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
    d = (2*C-A)*p.x+(2*B-C)*p.y+0.25*A+B-C;
    cc1 = -C+3*B;			ca1 = C+C;		cb1 = B+B;    	
    cc2 = 2*A+3*B-5*C;		ca2 = 2*(C-A);	cb2 = -2*(C-B);  
	while ( (double)((A-C)*p.x+(C-B)*p.y) > 0.0 )
	{	if ( d<0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.x--;
		}
		p.y++;
		AddPoint(p);
	}
}

//	���� II ���ĵ�
void CalcRegion2Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
	d = (C-2*A)*p.x+(B-2*C)*p.y+A+0.25*B-C;
    ca1 = -A-A;				cb1 = -C-C;			cc1 = -C+3*A;
	cc2 = 3*A+2*B-5*C;      ca2 = 2*(C-A);    	cb2 = -2*(C-B);
	while ( (double)(A*p.x+C*p.y) > 0.0 )
	{	if ( d>=0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.y++;
		}
		p.x--;
		AddPoint( p );
	}
}

//	���� III ���ĵ�
void CalcRegion3Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
	d = -(C+2*A)*p.x-(B+2*C)*p.y+A+0.25*B+C;
    cc1 = C+3*A;			ca1 = -A-A;    		cb1 = -C-C;
    cc2 = 3*A+2*B+5*C;		ca2 = -2*(C+A);		cb2 = -2*(C+B);
	while ( (double)((A+C)*p.x+(B+C)*p.y) > 0.0 )
	{	if ( d<0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.y--;
		}
		p.x--;
		AddPoint( p );
	}
}

//	���� IV ���ĵ�
void CalcRegion4Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
    d = -(2*C+A)*p.x-(2*B+C)*p.y+0.25*A+B+C;
    cc1 = C+3*B;			ca1 = -C-C;    		cb1 = -B-B;    
    cc2 = 2*A+3*B+5*C;		ca2 = -2*(C+A);    	cb2 = -2*(C+B);
	while ( (double)(B*p.y+C*p.x) > 0.0 )
	{	if ( d>=0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.x--;
		}
		p.y--;
		AddPoint( p );
	}
}

//	���� V ���ĵ�
void CalcRegion5Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
    d = (-2*C+A)*p.x+(-2*B+C)*p.y+0.25*A+B-C;
    cc1 = -C+3*B;			ca1 = C+C;		cb1 = B+B;    	
    cc2 = 2*A+3*B-5*C;		ca2 = 2*(C-A);	cb2 = -2*(C-B);  
	while ( (double)((-A+C)*p.x+(-C+B)*p.y) > 0.0 )
	{	if ( d<0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.x++;
		}
		p.y--;
		AddPoint( p );
	}
}

//	���� VI ���ĵ�
void CalcRegion6Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
	d = (-C+2*A)*p.x+(-B+2*C)*p.y+A+0.25*B-C;
    ca1 = -A-A;				cb1 = -C-C;			cc1 = -C+3*A;
	cc2 = 3*A+2*B-5*C;      ca2 = 2*(C-A);    	cb2 = -2*(C-B);
	while ( (double)(-A*p.x-C*p.y) > 0.0 )
	{	if ( d>=0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.y--;
		}
		p.x++;
		AddPoint( p );
	}
}

//	���� VII ���ĵ�
void CalcRegion7Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
	d = (C+2*A)*p.x+(B+2*C)*p.y+A+0.25*B+C;
    cc1 = C+3*A;			ca1 = -A-A;    		cb1 = -C-C;
    cc2 = 3*A+2*B+5*C;		ca2 = -2*(C+A);		cb2 = -2*(C+B);
	while ( (double)((A+C)*p.x+(B+C)*p.y) <= 0.0 )
	{	if ( d<0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.y++;
		}
		p.x++;
		if ( s_bAdjust )
			p.x = MIN( p.x, (int)s_a );
		AddPoint( p );
	}
}

//	���� VIII ���ĵ�
void CalcRegion8Point( CPoint& p )
{
	double ca1, cb1, cc1;
	double ca2, cb2, cc2;
	double d;
    d = (2*C+A)*p.x + (2*B+C)*p.y + 0.25*A+B+C;
    cc1 = C+3*B;			ca1 = -C-C;    		cb1 = -B-B;    
    cc2 = 2*A+3*B+5*C;		ca2 = -2*(C+A);    	cb2 = -2*(C+B);
	while ( (double)(B*p.y+C*p.x) <= 0.0 )
	{	if ( d>=0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.x++;
			if ( s_bAdjust )
				p.x = MIN( p.x, (int)s_a );
		}
		p.y++;
		AddPoint( p );
	}
}

//����ڶ������ת����cnt������Բ������
CPoint CalcCenter( const CRect& rct, const CPoint& cnt )
{
	CPoint rctcnt = rct.CenterPoint();
	CPoint Ecnt = rctcnt;

	double dx, dy;
	dx =  Ecnt.x - cnt.x;
	dy = -Ecnt.y + cnt.y;
	Ecnt.x = cnt.x + D2I(dx*Ca - dy*Sa);
	Ecnt.y = cnt.y - D2I(dx*Sa + dy*Ca);
	
//	if ( pView )
//		pView->DocToClient( Ecnt );
	return Ecnt;
}

//	�ߵ� y ��, ƽ��
void OffsetPoint( const CRect& rct, const CPoint& cnt )
{
	CPoint Ecnt = ::CalcCenter( rct, cnt ); 	//����ڶ������ת����cnt������Բ������(�豸����)
	//	��ʼƽ�Ƽ���
	for ( int i=0; i<s_nPoints; i++ )
	{	//	�ߵ�, ƽ��
		ellipsePnt[i].x += Ecnt.x;
		ellipsePnt[i].y  = Ecnt.y - ellipsePnt[i].y;
	}
}
void DrawRotateEllipse( CHistogram* pObj, CDC* pDC, IColorScheme* pICS,
							const CRect& rect, 
							const CPoint& center, int alpha, int nType)
{
//	BOOL bDashLine = FALSE;
	int nLPs = pObj->GetLPenStyle();
	int nPW;
	CPoint penW;
	CRect rc = rect;
	if( nLPs > PS_SOLID && nLPs < PS_NULL )
	{
//		bDashLine = TRUE;
		nPW = pObj->GetLPenSize();
		penW.x = penW.y = nPW;
	//	if ( pView )
	//		pView -> DocToClient(penW);
		//rc.InflateRect(penW.x/2,penW.x/2);
	}
	//	����Բ��ת��ķ��̵Ĳ���
	GetRotatedFunction( rc, alpha );

	//	��ɨ��ת������ʼ��
	CPoint pS;
	::GetStartPnt( pS );
	
	CPoint p = pS;
    CalcRegion1Point( p );		//	���� I ���ĵ�
    CalcRegion2Point( p );		//	���� II ���ĵ�
    CalcRegion3Point( p );		//	���� III ���ĵ�
    CalcRegion4Point( p );		//	���� IV ���ĵ�
//	CalcRegion5Point( p );		//	���� I' ���ĵ�
//  CalcRegion6Point( p );		//	���� II' ���ĵ�
//	CalcRegion7Point( p );		//	���� III' ���ĵ�
//  CalcRegion8Point( p );		//	���� IV' ���ĵ�
//	�������ԳƷ��ȼ�
	//	�� V, VI, VII, VIII ���ĵ�(�������ĶԳƷ�)
	int num = s_nPoints;
	for ( int i=0; i<num; i++ )		//	don't use i<s_nPoints; !!
	{	p.x = -ellipsePnt[i].x;
		p.y = -ellipsePnt[i].y;
		AddPoint( p );
	}
	//	�ߵ� y ��, ƽ��
	::OffsetPoint( rc, center );
	//	������Բ
	if ( pObj->GetBkMode() == INVERT )
	{	CRgn rgn;
		if ( rgn.CreatePolygonRgn(ellipsePnt, s_nPoints, ALTERNATE) )
			pDC->InvertRgn( &rgn );	
	}
//	else if (bDashLine && nType != CFPBase::IsRubberBand)
//	{
//		CDashLine dashline(*pDC,penW.x);
//		pObj->DrawDashPolygon(&dashline, pDC, pICS, ellipsePnt,s_nPoints, nType);
//	}
	else
		pObj->DrawPolygon( pDC, pICS, ellipsePnt, s_nPoints, nType, 0 );
	delete ellipsePnt;
	ellipsePnt = NULL;
	s_nPoints = 0;
	s_nAllocPoints = 0;
}

//���ص�pntΪ�Ը���Բ������Ϊ����ԭ���alpha����Ӧ���豸�����
void AngleToPoint( int alpha, CPoint& pnt )
{
	//	��֪ alpha	�������
	double alp = alpha*PI/1800;
	double tht = atan2( s_a*sin(alp), s_b*cos(alp) );
	//	��֪ tht �������ڵ�
	double x, y;
	x = s_a*cos(tht);	 //aΪ��Բ�볤����豸���곤��
	y = s_b*sin(tht);	 //bΪ��Բ�������豸���곤��
	//	������ת alpha ��
	pnt.x = D2I( x*Ca - y*Sa );
	pnt.y = D2I( x*Sa + y*Ca );
}

int JudgeRegion( CPoint& pnt )
{
	LONG	Fx, Fy;
	Fx = D2I(A*pnt.x + C*pnt.y);		
	Fy = D2I(C*pnt.x + B*pnt.y);
	if ( Fy >= 0 )
	{	if ( Fx >= 0 )
			return (Fx >= Fy)? 1: 2;
		return (Fy >=-Fx)? 3: 4;
	}
	else
	{	if ( -Fx >= 0 )
			return (-Fx >=-Fy)? 5: 6;
		return (-Fy >= Fx)? 7: 8;
	}
}

//	���� I ���ĵ�
void CalcRegion1Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
    d = (2*C-A)*p.x+(2*B-C)*p.y+0.25*A+B-C;
    cc1 = -C+3*B;			ca1 = C+C;		cb1 = B+B;    	
    cc2 = 2*A+3*B-5*C;		ca2 = 2*(C-A);	cb2 = -2*(C-B);  
	while ( (double)((A-C)*p.x+(C-B)*p.y) > 0.0 )
	{   if ( d<0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.x--;
		}
		p.y++;
		if ( p.y >= pntE.y )
			return;
		AddPoint( p );
	}
}

//	���� II ���ĵ�
void CalcRegion2Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
	d = (C-2*A)*p.x+(B-2*C)*p.y+A+0.25*B-C;
    ca1 = -A-A;				cb1 = -C-C;			cc1 = -C+3*A;
	cc2 = 3*A+2*B-5*C;      ca2 = 2*(C-A);    	cb2 = -2*(C-B);
	while ( (double)(A*p.x+C*p.y) > 0.0 )
	{	if ( d>=0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.y++;
		}
		p.x--;
		if ( p.x <= pntE.x )
			return;
		AddPoint( p );
	}
}

//	���� III ���ĵ�
void CalcRegion3Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
	d = -(C+2*A)*p.x-(B+2*C)*p.y+A+0.25*B+C;
    cc1 = C+3*A;			ca1 = -A-A;    		cb1 = -C-C;
    cc2 = 3*A+2*B+5*C;		ca2 = -2*(C+A);		cb2 = -2*(C+B);
	while ( (double)((A+C)*p.x+(B+C)*p.y) > 0.0 )
	{	if ( d<0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.y--;
		}
		p.x--;
		if ( p.x <= pntE.x )
			return;
		AddPoint( p );
	}
}

//	���� IV ���ĵ�
void CalcRegion4Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
    d = -(2*C+A)*p.x-(2*B+C)*p.y+0.25*A+B+C;
    cc1 = C+3*B;			ca1 = -C-C;    		cb1 = -B-B;    
    cc2 = 2*A+3*B+5*C;		ca2 = -2*(C+A);    	cb2 = -2*(C+B);
	while ( (double)(B*p.y+C*p.x) > 0.0 )
	{	if ( d>=0 )
			d += ca1*p.x + cb1*p.y + cc1;
		else
		{	d += ca2*p.x + cb2*p.y + cc2;
			p.x--;
		}
		p.y--;
		if ( p.y <= pntE.y )
			return;
		AddPoint( p );
	}
}

//	���� I' ���ĵ�
void CalcRegion5Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
    d = (-2*C+A)*p.x+(-2*B+C)*p.y+0.25*A+B-C;
    cc1 = -C+3*B;			ca1 = C+C;		cb1 = B+B;    	
    cc2 = 2*A+3*B-5*C;		ca2 = 2*(C-A);	cb2 = -2*(C-B);  
	while ( (double)((-A+C)*p.x+(-C+B)*p.y) > 0.0 )
	{	if ( d<0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.x++;
		}
		p.y--;
		if ( p.y <= pntE.y )
			return;
		AddPoint( p );
	}
}

//	���� II' ���ĵ�
void CalcRegion6Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
	d = (-C+2*A)*p.x+(-B+2*C)*p.y+A+0.25*B-C;
    ca1 = -A-A;				cb1 = -C-C;			cc1 = -C+3*A;
	cc2 = 3*A+2*B-5*C;      ca2 = 2*(C-A);    	cb2 = -2*(C-B);
	while ( (double)(-A*p.x-C*p.y) > 0.0 )
	{	if ( d>=0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.y--;
		}
		p.x++;
		if ( p.x >= pntE.x )
			return;
		AddPoint( p );
	}
}

//	���� III' ���ĵ�
void CalcRegion7Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
	d = (C+2*A)*p.x+(B+2*C)*p.y+A+0.25*B+C;
    cc1 = C+3*A;			ca1 = -A-A;    		cb1 = -C-C;
    cc2 = 3*A+2*B+5*C;		ca2 = -2*(C+A);		cb2 = -2*(C+B);
	while ( (double)((A+C)*p.x+(B+C)*p.y) < 0.0 )
	{	if ( d<0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.y++;
		}
		p.x++;
		if ( p.x >= pntE.x )
			return;
		AddPoint( p );
	}
}

//	���� IV' ���ĵ�
void CalcRegion8Point( CPoint& p, const CPoint& pntE )
{
    double ca1, cb1, cc1;
    double ca2, cb2, cc2;
    double d;
    d = (2*C+A)*p.x + (2*B+C)*p.y + 0.25*A+B+C;
    cc1 = C+3*B;			ca1 = -C-C;    		cb1 = -B-B;    
    cc2 = 2*A+3*B+5*C;		ca2 = -2*(C+A);    	cb2 = -2*(C+B);
	while ( (double)(B*p.y+C*p.x) <= 0.0 )
	{	if ( d>=0 )
			d += -ca1*p.x - cb1*p.y + cc1;
		else
		{	d += -ca2*p.x - cb2*p.y + cc2;
			p.x++;
			if ( s_bAdjust )
				p.x = MIN( p.x, (int)s_a );
		}
		p.y++;
		if ( p.y >= pntE.y )
			return;
		AddPoint( p );
	}
}

void CalcRegion_Point( int& nRS, CPoint& p )
{
	switch ( nRS )	{
	case 1:
	    CalcRegion1Point( p );		//	���� I ���ĵ�
	    break;
	case 2:
	    CalcRegion2Point( p );		//	���� II ���ĵ�
	    break;
	case 3:
    	CalcRegion3Point( p );		//	���� III ���ĵ�
	    break;
	case 4:
	    CalcRegion4Point( p );		//	���� IV ���ĵ�
	    break;
	case 5:
	    CalcRegion5Point( p );		//	���� I' ���ĵ�
	    break;
	case 6:
	    CalcRegion6Point( p );		//	���� II' ���ĵ�
	    break;
	case 7:
    	CalcRegion7Point( p );		//	���� III' ���ĵ�
	    break;
	case 8:
	    CalcRegion8Point( p );		//	���� IV' ���ĵ�
	    break;
	}
}

void CalcRegion_Point( int& nRS, CPoint& p, const CPoint& pntE )
{
	switch ( nRS )	{
	case 1:
	    CalcRegion1Point( p, pntE );		//	���� I ���ĵ�
	    break;
	case 2:
	    CalcRegion2Point( p, pntE );		//	���� II ���ĵ�
	    break;
	case 3:
    	CalcRegion3Point( p, pntE );		//	���� III ���ĵ�
	    break;
	case 4:
	    CalcRegion4Point( p, pntE );		//	���� IV ���ĵ�
	    break;
	case 5:
	    CalcRegion5Point( p, pntE );		//	���� I' ���ĵ�
	    break;
	case 6:
	    CalcRegion6Point( p, pntE );		//	���� II' ���ĵ�
	    break;
	case 7:
    	CalcRegion7Point( p, pntE );		//	���� III' ���ĵ�
	    break;
	case 8:
	    CalcRegion8Point( p, pntE );		//	���� IV' ���ĵ�
	    break;
	}
}

void CalcArcPnt( const CRect& logRect, int alphaS, int alphaE, 
				 const CPoint& center, int alpha )
{
	//	����Բ��ת��ķ��̣�����������������
	GetRotatedFunction( logRect, alpha );
    CPoint pntS, pntE;
    //	��ʼĩ�����Ӧ���ϵĵ�
	AngleToPoint( alphaS, pntS ); //pntSΪ�Ը���Բ������Ϊ����ԭ���alphaS����Ӧ���豸�����
	AngleToPoint( alphaE, pntE );
	AddPoint( pntS );//	��ʼ��
	//	�б�ʼĩ�����ڵ�ɨ��ת������
	int nRS = JudgeRegion( pntS );
	int nRE = JudgeRegion( pntE );
	int delta;
	if ( alphaS < alphaE )
		delta = alphaE - alphaS;
	else
		delta = alphaE - alphaS + 3600;	
	CPoint p = pntS;
	if ( nRS > nRE || (nRS == nRE && delta > 1800) )
	{	int nRT = nRE;
		nRT = 8;
		while ( nRS <= nRT )
		{	CalcRegion_Point( nRS, p );
			nRS ++;
		}
		nRS = 1;
	}
	if ( nRS <= nRE )
	{	while ( nRS < nRE )
		{	CalcRegion_Point( nRS, p );
			nRS ++;
		}
		if ( nRS == nRE )
		    CalcRegion_Point( nRE, p, pntE );
	}
	AddPoint( pntE );	//	��ֹ��,�������еĵ㶼���뵽��ellipsePnt[s_nPoints]������,����豸����
	//	�ߵ� y ��, ƽ��
	::OffsetPoint( logRect, center );
}

/*������ת����Բ������ɵ�
	logRect				 ��Բ�����߼����ο�
	alphaS,alphaE		 ��Բ�Ļ���ʼĩ��,0.01��Ϊ��λ
	pEllipsePnt			 ���ص�ָ����Բ������ɵ��ָ��
	center				 �������ת����,�߼�����
	alpha				 �������ת�Ƕ�
	logOff				 ��Բ������ɵ��ƫ��ֵ
	ptList				 ���ص���Բ������ɵ��ָ������
*/
void CalcArcPnt(const CRect& logRect, int alphaS, int alphaE, 
					const CPoint& center, int alpha, CSize logOff, CObList& ptList)
{
	ptList.RemoveAll();

	CRect rect = logRect;
	rect.OffsetRect(logOff);

	::CalcArcPnt( rect, alphaS, alphaE, center, alpha );
	
	//�������ݵ���뵽ָ��������
	//CPoint* pPnt = new CPoint[s_nPoints];
	//memcpy(pPnt, ellipsePnt, s_nPoints*sizeof(CPoint));
	CPoint* pPnt = NULL;
	for(int i = 0; i < s_nPoints; i++)
	{
		pPnt = new CPoint(0,0);
		*pPnt = ellipsePnt[i];
		ptList.AddTail((CObject*)pPnt);
	}
	
	delete ellipsePnt; ellipsePnt = NULL;
	s_nPoints = 0;
	s_nAllocPoints = 0;
}

void DrawRotateCylinder( CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
					const CRect& logRect, long loffset,
					int alphaS, int alphaE, const CPoint& center, int alpha, int nType)
{
	CPoint offPnt(0, loffset);
//	if (pView)
//		pView->DocToClient(offPnt);

	CPoint* pPnt = NULL;
	POSITION pos;
	int nNum = 0;
	CObList ptList1, ptList2; //�豸����������
	CalcArcPnt(logRect, alphaS, alphaE, center, alpha, CSize(0,0), ptList1);
	if (alpha != 0)
	{
		CalcArcPnt(logRect, alphaS, alphaE, center, alpha, CSize(0,loffset), ptList2);
		pos  = ptList2.GetTailPosition();
		while(pos)
		{
			ptList1.AddTail(ptList2.GetPrev(pos));
		}
		nNum = ptList1.GetCount();
		pPnt = new CPoint[nNum];
		pos  = ptList1.GetHeadPosition();
		for (int i = 0; i < nNum; i++)
			pPnt[i] = *(CPoint*)ptList1.GetNext(pos);
	}
	else
	{
		nNum = ptList1.GetCount() * 2;
		pPnt = new CPoint[nNum];
		pos  = ptList1.GetHeadPosition();
		for (int i = 0; i < nNum/2; i++)
		{
			pPnt[i] = *(CPoint*)ptList1.GetNext(pos);
			pPnt[nNum-1-i] = pPnt[i] + CSize(0, offPnt.y);
		}
	}

	// wdb[bug id 3119]
	if ( pObj->GetBkMode() == INVERT )
	{			
	//	CRgn rgn;
	//	if ( rgn.CreatePolygonRgn(pPnt, nNum, ALTERNATE) )
	//		pDC->InvertRgn( &rgn );
		pObj->SetFillColor(RGB(0,0,0));
		
	}
	//Add by wym for drawline 02/05/1999
	int nLPs;
	//nPW;
	nLPs = pObj->GetLPenStyle();
/*	if ( nLPs > PS_SOLID && nLPs < PS_NULL && nType != CFPBase::IsRubberBand)
	{
		nPW = pObj->GetLPenSize();
		CPoint p(nPW,nPW);
	//	if ( pView )
	//		pView->DocToClient(p);
	//	CDashLine dashline(*pDC,p.x);
		pObj->DrawDashPolygon(&dashline, pDC, pICS, pPnt, nNum, nType);
	}
	else	
*/		pObj->DrawPolygon(pDC, pICS, pPnt, nNum, nType, 0 );
	
	delete[] pPnt;
	while(!ptList1.IsEmpty())
		delete (CPoint*)ptList1.RemoveHead();
}

//nScale Ϊ�϶����y��������Ͻǵ�y�ľ�������ζ���֮һ�ߵı�ֵ
void CHistogram::DrawCylinder(CDC* pDC, IColorScheme* pICS,
							CRect logRect,
							CPoint center, int theta,int nScale, int nType)
{
	CSize ellipseSiz(logRect.Width(), logRect.Height()*nScale/100);
	CRect ellipseRct(logRect.TopLeft(), ellipseSiz);
	::DrawRotateEllipse(this, pDC, pICS, ellipseRct, center, theta, nType);
	CRect cylinderRct(&logRect);
	cylinderRct.top += ellipseSiz.cy / 2;
	long loffset = cylinderRct.Height() - ellipseRct.Height() / 2;
	CBrush* pOldBrush = (CBrush*)pDC->GetCurrentBrush();
	HBRUSH hObj = (HBRUSH)GetStockObject(NULL_BRUSH);
	if(pOldBrush->m_hObject != hObj || nType != IsRubberBand)
	{
		CBrush newDevBrush;
		CBrush* pOldBrush = NULL;
		LOGBRUSH newLogBrush = KLOGBRUSH2LOGBRUSH(GetFillLogBrush(), pICS);	//ȡ��ǰ�߼�ˢ
		if(newLogBrush.lbColor != RGB(255,255,255)) 
			newLogBrush.lbColor = AddRGB(newLogBrush.lbColor, 30); //��ɫ����ٷ�֮30
		if(newLogBrush.lbHatch%2 == 0)	//ƥ�����
			newLogBrush.lbHatch += 1;
		else
			newLogBrush.lbHatch -= 1;
		if (newDevBrush.CreateBrushIndirect(&newLogBrush))
			pOldBrush = pDC->SelectObject(&newDevBrush);
		::DrawRotateCylinder(this, pDC, pICS, ellipseRct, loffset,
						1800, 3600, center, theta, nType);
		if(pOldBrush)
			pDC->SelectObject(pOldBrush);
		newDevBrush.DeleteObject();
	}
	else 
		::DrawRotateCylinder(this, pDC, pICS, ellipseRct, loffset,
						1800, 3600, center, theta, nType);
}

void CHistogram::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	CRect rct = m_rect;
	pDC->LPtoDP(&rct);
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formFrac ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

	DrawPosition( pDC, rct );
	
	ASSERT_VALID(this);
	ASSERT_VALID(pDC);
	
	int penW = 0;
	CPen* pOldPen = SelectPenObject(pDC, pICS, penW, FALSE);
	CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
	int nOldBkMode = pDC->GetBkMode();
	COLORREF clrOldBk = pDC->GetBkColor();
	
	ASSERT(!m_RectList.IsEmpty());
	POSITION pos = m_RectList.GetHeadPosition();
	CRect rect;
	int nCount = m_RectList.GetCount();
	CPoint* pnt = new CPoint[nCount];
	int nScale = 0;
	for (int i = 0; i < nCount; i++)
	{
		rect = *(CRect*)m_RectList.GetNext(pos);
		if (rect.Height() == 0)
			nScale = 0;
		else
			nScale = (10 * 100 + rect.Height() / 2 - 1) / rect.Height(); 	//1mm����Ϊ�����rect�ߵı�ֵ
		switch(m_nHistogramShap)
		{
			case retangle:
			case retangleH:
				DrawRectangle(pDC, pICS, rect, m_center, m_theta, IsRegular);
				break;
			case cube:
			case cubeH:
				{
					if (rect.top > rect.bottom)
					{
						rect.NormalizeRect();
						DrawCube(pDC, pICS, rect, m_center, m_theta, 20, 3, IsRegular);
					}
					else 
						DrawCube(pDC, pICS, rect, m_center, m_theta, 20, 0, IsRegular);
				}
				break;
			case cylinder:
			case cylinderH:
			if (m_nHistogramShap < retangleH)
				DrawCylinder(pDC, pICS, rect, m_center, m_theta, nScale, IsRegular);	//Բ����
			else
			{
				CRect rct(rect.left, rect.top-rect.Width(),
						rect.left+rect.Height(), rect.top);
				rct.OffsetRect(2, 0);
				if (rct.Height() == 0)
					nScale = 0;
				else
					nScale = (10 * 100 + rct.Height() / 2 - 1) / rct.Height(); 	//1mm����Ϊ��ֵ
				CPoint center(rct.left, rct.bottom);
				//��ת�Ժ�ƽ��
				DrawCylinder(pDC, pICS, rct, center, -900, nScale, IsRegular);	//Բ����
			}
			break;
		}
		pnt[i] = rect.TopLeft();
	}
	
	pDC->SetBkMode(nOldBkMode);		//	set BkMode
	pDC->SetBkColor(clrOldBk);		//	set BkColor
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);

	delete pnt;

	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
}

CPoint GetArcStartPnt(const CRect& rect, int thta)
{
	double mA = (double)thta*PI/1800;
	double dx, dy;
	dx = rect.Width()/2;
	dy = rect.Height()/2;
	CPoint rctO = rect.CenterPoint();
	CPoint start;
	double A = atan2( dx*sin(mA), dy*cos(mA) );//change to theta angle
	start.x = rctO.x + D2I(dx*cos(A));
	start.y = rctO.y - D2I(dy*sin(A));

	return start;
}

//���������ͼ����ʱ����,����������ڵ��ı��ζ���
void DrawSPolygon(CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
													CPoint* pPnt, int nType)
{
	CPoint* pnt = new CPoint[4];
	if(nType == 1/*IsRubberBand*/)
	{
		for(int i = 0; i<4; i++) 
		{
			pnt[i] = pPnt[i];
		//	if(pView)
		//		pView->DocToClient(pnt[i]);
		}
		pObj->DrawPolygon( pDC, pICS, pnt, 4, nType, 0 );
	}
	else 
	{
		CBrush* pOldBrush = NULL;
	//	if (nType == CFPBase::IsRegular)
	/*	{
			CBrush newDevBrush;
			LOGBRUSH newLogBrush = pObj->GetFillLogBrush();	//ȡ��ǰ�߼�ˢ
			newLogBrush.lbColor = AddRGB(newLogBrush.lbColor, 30); //��ɫ����ٷ�֮30
			newLogBrush.lbHatch = 3;
			if ( newDevBrush.CreateBrushIndirect( &newLogBrush ))
				pOldBrush = pDC->SelectObject(&newDevBrush);
		}*/
		for(int i = 0; i<4; i++) 
		{
			pnt[i] = pPnt[i];
		//	if(pView) 
		//		pView->DocToClient(pnt[i]);
		}
		//Add by wym for draw dashline
		int nPenStyle = pObj->GetLPenStyle();
/*		if(nPenStyle > PS_SOLID && nPenStyle < PS_NULL && nType != CFPBase::IsRubberBand)
		{	//draw dashline
			int nPenW = pObj->GetLPenSize();
			CPoint penW(nPenW,nPenW);
		//	if ( pView )
		//		pView->DocToClient(penW);
			CDashLine dashline(*pDC,penW.x);
			pObj->DrawDashPolygon(&dashline, pDC, pICS, pnt, 4, nType);
		}
		else*/
			pObj->DrawPolygon( pDC, pICS, pnt, 4, nType, 0 );
		if (pOldBrush)
			pDC->SelectObject(pOldBrush);
	}
	delete pnt;
}

//���������ͼ����ʱ����,�����յ����ڵ��ı��ζ���
void DrawEPolygon(CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
												CPoint* pPnt, int nType)
{
	CPoint* pnt = new CPoint[4];
	if (nType == 1/*IsRubberBand*/)
	{
		for(int i = 0; i<4; i++) 
		{
			pnt[i] = pPnt[i];
		//	if(pView)
		//		pView->DocToClient(pnt[i]);
		}
		pObj->DrawPolygon( pDC, pICS, pnt, 4, nType, 0 );
	}
	else 
	{
		CBrush* pOldBrush = NULL;
	//	if (nType == CFPBase::IsRegular)
	/*	{
			CBrush newDevBrush;
			LOGBRUSH newLogBrush = pObj->GetFillLogBrush();	//ȡ��ǰ�߼�ˢ
			newLogBrush.lbColor = AddRGB(newLogBrush.lbColor, 30); //��ɫ����ٷ�֮30
			newLogBrush.lbHatch = 2;
			if ( newDevBrush.CreateBrushIndirect( &newLogBrush ))
				pOldBrush = pDC->SelectObject(&newDevBrush);
		}*/
		for(int i = 0; i<4; i++) 
		{
			pnt[i] = pPnt[i];
		//	if(pView) 
		//		pView->DocToClient(pnt[i]);
		}
		//Add by wym for draw dashline
		int nPenStyle = pObj->GetLPenStyle();
/*		if (nPenStyle > PS_SOLID && nPenStyle < PS_NULL && nType != CFPBase::IsRubberBand)
		{	//draw dashline
			int nPenW = pObj->GetLPenSize();
			CPoint penW(nPenW,nPenW);
		//	if ( pView )
		//		pView->DocToClient(penW);
		//	CDashLine dashline(*pDC,penW.x);
			pObj->DrawDashPolygon(&dashline, pDC, pICS, pnt, 4, nType);
		}
		else*/
			pObj->DrawPolygon( pDC, pICS, pnt, 4, nType, 0 );
		if (pOldBrush)
			pDC->SelectObject(pOldBrush);
	}
	delete pnt;
}

/*���Ʒ���ת��Բ�����°벿��
rect	Ϊ��һ����Բ��������Բ����Ӿ���,�߼�����
	loffset	Ϊδ��תǰ��������Բ���ľ���,�߼�����
	alphaS, alphaE	��Բ������ʼ�Ǻ���ֹ��,��0.1��Ϊ��λ
	center	�����������ת����,�߼�����
	alpha	�������ת�Ƕ�
	nType	���ݸ�DrawPolygon�����Ĳ���
*/
/*
void DrawRotateCylinder( CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
					const CRect& logRect, long loffset,
					int alphaS, int alphaE, const CPoint& center, int alpha, int nType)
{
	CPoint offPnt(0, loffset);
//	if (pView)
//		pView->DocToClient(offPnt);

	CPoint* pPnt = NULL;
	POSITION pos;
	int nNum = 0;
	CObList ptList1, ptList2; //�豸����������
	CalcArcPnt(logRect, alphaS, alphaE, center, alpha, CSize(0,0), ptList1);
	if (alpha != 0)
	{
		CalcArcPnt(logRect, alphaS, alphaE, center, alpha, CSize(0,loffset), ptList2);
		pos  = ptList2.GetTailPosition();
		while(pos)
		{
			ptList1.AddTail(ptList2.GetPrev(pos));
		}
		nNum = ptList1.GetCount();
		pPnt = new CPoint[nNum];
		pos  = ptList1.GetHeadPosition();
		for (int i = 0; i < nNum; i++)
			pPnt[i] = *(CPoint*)ptList1.GetNext(pos);
	}
	else
	{
		nNum = ptList1.GetCount() * 2;
		pPnt = new CPoint[nNum];
		pos  = ptList1.GetHeadPosition();
		for (int i = 0; i < nNum/2; i++)
		{
			pPnt[i] = *(CPoint*)ptList1.GetNext(pos);
			pPnt[nNum-1-i] = pPnt[i] + CSize(0, offPnt.y);
		}
	}

	// wdb[bug id 3119]
	if ( pObj->GetBkMode() == INVERT )
	{			
	//	CRgn rgn;
	//	if ( rgn.CreatePolygonRgn(pPnt, nNum, ALTERNATE) )
	//		pDC->InvertRgn( &rgn );
		pObj->SetFillColor(RGB(0,0,0));
		
	}
	//Add by wym for drawline 02/05/1999
	int nLPs,nPW;
	nLPs = pObj->GetLPenStyle();
	if ( nLPs > PS_SOLID && nLPs < PS_NULL && nType != CFPBase::IsRubberBand)
	{
		nPW = pObj->GetLPenSize();
		CPoint p(nPW,nPW);
//		if ( pView )
//			pView->DocToClient(p);
		CDashLine dashline(*pDC,p.x);
		pObj->DrawDashPolygon(&dashline, pDC, pICS, pPnt, nNum, nType);
	}
	else	
		pObj->DrawPolygon( pDC, pICS, pPnt, nNum, nType, 0 );
	
	delete[] pPnt;
	while(!ptList1.IsEmpty())
		delete (CPoint*)ptList1.RemoveHead();
}
*/
//���������ͼ����ʱ����,����������ڵ����ζ���
void DrawSCylinder(CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
					CRect logRect, long loffset,
					int alphaS, int alphaE, const CPoint& center, int alpha, int nType)
{
	//CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
	::DrawRotateCylinder(pObj, pDC, pICS, logRect, loffset, alphaS, alphaE, center, 0, nType);
	//pDC->SelectObject(pOldPen);
	/*
	CPoint offPnt(0, loffset);
	if(pView) pView->DocToClient( offPnt );
	if(pView) pView->DocToClient( logRect );

	CPoint start = ::GetArcStartPnt(logRect, alphaS);	//�������Ӧ�ĵ�,device coordinate
	//CPoint end   = ::GetArcEndPnt(logRect, alphaS, alphaE-alphaS);	//�ս�����Ӧ�ĵ�
	CPoint end   = ::GetArcStartPnt(logRect, alphaE);	//�ս�����Ӧ�ĵ�
	CPoint start1(start.x, start.y+offPnt.y);
	CPoint end1(end.x, end.y+offPnt.y); 
	logRect.OffsetRect(0, offPnt.y);
	
	int penW = pObj->GetLPenSize();
	logRect.InflateRect( 0, penW/2 );
	CSize siz(0,penW/2);
	if(start1.y == end1.y)
	   end1.y -= 1;	  //Ϊ�˴�����start1.y == end1.yʱArc()�Ļ��Ʋ���ȷ
	pDC->Arc( &logRect, start1, end1);
	pDC->MoveTo(start1);
	pDC->LineTo(start);
	pDC->MoveTo(end1);
	pDC->LineTo(end);
	*/
}

//���������ͼ����ʱ����,�����յ����ڵ����ζ���
void DrawECylinder(CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
					CRect logRect, long loffset,
					int alphaS, int alphaE, const CPoint& center, int alpha, int nType)
{
	//CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
	::DrawRotateCylinder(pObj, pDC, pICS, logRect, loffset, alphaS, alphaE, center, 0, nType);
	//pDC->SelectObject(pOldPen);
	/*
	CPoint offPnt(0, loffset);
	if(pView) pView->DocToClient( offPnt );
	if(pView) pView->DocToClient( logRect );
	
	CPoint start = ::GetArcStartPnt(logRect, alphaS);	//�������Ӧ�ĵ�,logical coordinate
	CPoint end   = ::GetArcEndPnt(logRect, alphaS, alphaE-alphaS);	//�ս�����Ӧ�ĵ�
	CPoint start1(start.x, start.y+offPnt.y);
	CPoint end1(end.x, end.y+offPnt.y); 
	logRect.OffsetRect(0, offPnt.y);
	
	int penW = pObj->GetLPenSize();
	logRect.InflateRect( 0, penW/2 );
	if(start1.y == end1.y)
	   end1.y += 1;	//Ϊ�˴�����start1.y == end1.yʱArc()�Ļ��Ʋ���ȷ
	pDC->Arc( &logRect, start1, end1 );
	pDC->MoveTo(start1);
	pDC->LineTo(start);
	pDC->MoveTo(end1);
	pDC->LineTo(end);
	*/
}

void DrawRotateArcChordPie( CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
					const CRect& logRect,
					int alphaS, int alphaE, const CPoint& center, int alpha, COLORREF clr,
					int nType, int nShap, int nPntstyle )
{
	::CalcArcPnt( logRect, alphaS, alphaE, center, alpha );
	
	CPoint p1 = ellipsePnt[0];
	CPoint p2 = ellipsePnt[s_nPoints-1];
	//Add for draw dashline by wym 02/03/1999
	CPoint p;
	int nLPs;//,nPW;
	nLPs = pObj->GetLPenStyle();
//	BOOL bDashLine = FALSE;
/*	CDashLine* pDashLine = NULL;
	if ( nLPs > PS_SOLID && nLPs < PS_NULL )
	{
		bDashLine = TRUE;
		nPW = pObj->GetLPenSize();
		p.x = p.y = nPW;
//		if ( pView )
//			pView -> DocToClient(p);
		pDashLine = new CDashLine(*pDC,p.x);
	}*/
	/////////////
	switch ( nShap )
	{
	case 0:	  //is pie
		AddPoint( CalcCenter( logRect, center ) );
		if ( pObj->GetBkMode() == INVERT )
		{	CRgn rgn;
			if ( rgn.CreatePolygonRgn(ellipsePnt, s_nPoints, ALTERNATE) )
				pDC->InvertRgn( &rgn );	
			break;
		}
		if (nPntstyle ==  1)   //ES_Close == 1
		{
		//	if ( bDashLine && nType != CFPBase::IsRubberBand)
		//		pObj->DrawDashPolygon(pDashLine, pDC, pICS, ellipsePnt, s_nPoints, nType);
		//	else
				pObj->DrawPolygon( pDC, pICS, ellipsePnt, s_nPoints, nType, 0 );
		}
		else
		{
		//	if (bDashLine && nType != CFPBase::IsRubberBand)
		//		pObj->DrawDashPolyLine(pDashLine, pDC, pICS, ellipsePnt, s_nPoints, nType);
		//	else
			{
				//	����
				pObj->PolygonDrawInside(pDC, pICS, ellipsePnt, s_nPoints, nType);
				//	����
				pDC->Polyline( ellipsePnt, s_nPoints-1 );
			}
		}
		break;
	case 1:	//is chord
		if ( pObj->GetBkMode() == INVERT )
		{	CRgn rgn;
			if ( rgn.CreatePolygonRgn(ellipsePnt, s_nPoints, ALTERNATE) )
				pDC->InvertRgn( &rgn );	
			break;
		}
		if ( nPntstyle ==  1)	 // ES_Close == 1
		{
		//	if ( bDashLine && nType != CFPBase::IsRubberBand)
		//		pObj->DrawDashPolygon(pDashLine, pDC, pICS, ellipsePnt,s_nPoints, nType);
		//	else
				pObj->DrawPolygon( pDC, pICS, ellipsePnt, s_nPoints, nType, 0 );
		}
		else
		{
		//	if ( bDashLine && nType != CFPBase::IsRubberBand)
		//		pObj->DrawDashPolyLine(pDashLine, pDC, pICS, ellipsePnt,s_nPoints, nType);
		//	else
			{
				pObj->PolygonDrawInside(pDC, pICS, ellipsePnt,s_nPoints, nType);
				pDC->Polyline( ellipsePnt, s_nPoints );
			}
		}
		break;
	}
	delete ellipsePnt;
//	if(pDashLine)
//		delete pDashLine;
	ellipsePnt = NULL;
	s_nPoints = 0;
	s_nAllocPoints = 0;
	//	���˵�
	CRect rc = logRect;
//	if(pView)
//		pView->DocToClient( rc );
//	((CRectObj*)pObj)->DrawArcEnd( pDC, pICS, clr, p1, p2, rc, alphaS, alphaE-alphaS, alpha );
}

//���������ͼ����
void DrawPieColumn(CRectObj* pObj, CDC* pDC, IColorScheme* pICS,
				   const CRect& logRect, long loffset,
					int alphaS, int alphaE, const CPoint& center, int alpha, int nType)
{
	int angle; 	//��ʼ�Ǻ���ֹ��֮�����еĽǶ�
	alphaS += alpha;
	alphaE += alpha;
	while(alphaS < 0)
		alphaS += 3600;
	while(alphaS > 3600)
		alphaS -= 3600;	
	while(alphaE < 0)
		alphaE += 3600;
	while(alphaE > 3600)
		alphaE -= 3600;	
	if(alphaS < alphaE)
		angle = alphaE - alphaS;
	else
		angle = alphaE - alphaS + 3600;	
	CPoint start = ::GetArcStartPnt(logRect, alphaS);	//�������Ӧ�ĵ�,logical coordinate
	//CPoint end   = ::GetArcEndPnt(logRect, alphaS, alphaE-alphaS);	//�ս�����Ӧ�ĵ�
	CPoint end   = ::GetArcStartPnt(logRect, alphaE);	//�ս�����Ӧ�ĵ�
	CPoint mid = logRect.CenterPoint();
	CSize siz(0, loffset);
	
	CPoint SpolyPnt[4];	//��������ı��ε��ĸ���ɵ�����
	SpolyPnt[0] = start ;
	SpolyPnt[1] = start + siz;
	SpolyPnt[2] = mid + siz;
	SpolyPnt[3] = mid;

	CPoint EpolyPnt[4];	//�յ������ı��ε��ĸ���ɵ�����
	EpolyPnt[0] = end;
	EpolyPnt[1]	= end + siz;
	EpolyPnt[2]	= mid + siz;
	EpolyPnt[3]	= mid;
	
	if(alphaS < alphaE) 
	{
		if(alphaS <= 900 && alphaE <= 900) //�ڵ�һ����
		{
			DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
		}
		else if(alphaS >= 900 && alphaS <=1800 && alphaE >= 900 && alphaE <= 1800) //�ڵڶ�����
		{
			DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
		}
		else if(alphaS >= 1800 && alphaS <=2700 && alphaE >= 1800 && alphaE <= 2700) //�ڵ�������
		{
			if(alphaE != 2700)
				DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, alphaE, center, 0, nType);
		}
		else if(alphaS >= 2700 && alphaS <=3600 && alphaE >= 2700 && alphaE <= 3600)	//�ڵ�������
		{
			if(alphaS != 2700)
				DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, alphaE, center, 0, nType);
		}
	}
	if(alphaS > alphaE) 
	{
		if(alphaS <= 900 && alphaE <= 900) //�ڵ�һ����
		{
			DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, 1800, 3600, center, 0, nType);
		}
		else if(alphaS >= 900 && alphaS <=1800 && alphaE >= 900 && alphaE <= 1800) //�ڵڶ�����
		{
			DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, 1800, 3600, center, 0, nType);
		}
		else if(alphaS >= 1800 && alphaS <=2700 && alphaE >= 1800 && alphaE <= 2700) //�ڵ�������
		{
			DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, 3600, center, 0, nType);
			if(alphaE != 1800)
				::DrawECylinder(pObj, pDC, pICS,
							logRect, loffset, 1800, alphaE, center, 0, nType);
		}
		else if(alphaS >= 2700 && alphaS <=3600 && alphaE >= 2700 && alphaE <= 3600)	//�ڵ�������
		{
			
			DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			if(alphaS != 3600)
				::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, 3600, center, 0, nType);
			::DrawECylinder(pObj, pDC, pICS, 
							logRect, loffset, 1800, alphaE, center, 0, nType);
		}
	}

	//if( angle>900 && angle<=1800) //���ǶȵĿ��>90,<=180��
	//{
		if( alphaS < 900 && alphaE >= 900 && alphaE < 1800) 
		{
			DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
		}
		else if(alphaS >= 900 && alphaS <=1800 && alphaE >= 1800 && alphaE <= 2700) //������x��������ཻ
		{
			if(alphaE != 2700)
				DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			if(1800 != alphaE)
				::DrawECylinder(pObj, pDC, pICS, 
						logRect, loffset, 1800, alphaE, center, 0, nType);
		}
		else if(alphaS >= 1800 && alphaS <=2700 && alphaE >= 2700 && alphaE <= 3600)
		{
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, alphaE, center, 0, nType);
		}
		else if(alphaS >= 2700 && alphaS <=3600 && alphaE >= 0 && alphaE <= 900) //������x���Ұ����ཻ
		{
			if(alphaS != 2700)
				DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			if(alphaS != 3600)
				::DrawSCylinder(pObj, pDC, pICS,
								logRect, loffset, alphaS, 3600, center, 0, nType);
		}
	//}

	//if( angle>1800 && angle<=2700) //���ǶȵĿ��>180,<=270��
	//{
		if(alphaS <= 900 && alphaE >= 1800 && alphaE <= 2700) 	//������x��������ཻ
		{
			DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			if(alphaE != 2700)
				DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			if(1800 != alphaE)
				::DrawECylinder(pObj, pDC, pICS,
						logRect, loffset, 1800, alphaE, center, 0, nType);
		}
		else if(alphaS >= 900 && alphaS <=1800 && alphaE >= 2700 && alphaE <= 3600) //������x��������ཻ
		{
			::DrawECylinder(pObj, pDC, pICS,
						logRect, loffset, 1800, alphaE, center, 0, nType);
		}
		else if(alphaS >= 1800 && alphaS <=2700 && alphaE >= 0 && alphaE <= 900) //������x���Ұ����ཻ
		{
			::DrawSCylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, 3600, center, 0, nType);
		}
		else if(alphaS >= 2700 && alphaS <=3600 && alphaE > 900 && alphaE <= 1800) //������x���Ұ����ཻ
		{
			if(alphaS != 2700)
				DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			if(3600 != alphaS)
				::DrawSCylinder(pObj, pDC, pICS,
						logRect, loffset, alphaS, 3600, center, 0, nType);
		}
	//}

	//if( angle>2700 && angle<=3600) //���ǶȵĿ��>270,<=360��
	//{
		if( alphaS <=900 && alphaE >= 2700 && alphaE <= 3600) //������x��������ཻ
		{
		   	DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			if(1800 != alphaE)
				::DrawECylinder(pObj, pDC, pICS,
							logRect, loffset, 1800, alphaE, center, 0, nType);
		}
		else if(alphaS >= 900 && alphaS <=1800 && alphaE >= 0 && alphaE <= 900) //����������x���ཻ
		{
		   ::DrawECylinder(pObj, pDC, pICS,
							logRect, loffset, 1800, 3600, center, 0, nType);
		}
		else if(alphaS >= 1800 && alphaS <=2700 && alphaE >= 900 && alphaE <= 1800)	//������x���Ұ����ཻ
		{
		   DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
		   ::DrawECylinder(pObj, pDC, pICS,
							logRect, loffset, alphaS, 3600, center, 0, nType);
		}
		else if(alphaS >= 2700 && alphaS <=3600 && alphaE > 1800 && alphaE <= 2700) //����������x���ཻ
		{
			if(alphaS != 2700)
			  DrawSPolygon(pObj, pDC, pICS, SpolyPnt, nType);
			if(alphaE != 2700)
			  DrawEPolygon(pObj, pDC, pICS, EpolyPnt, nType);
			if(3600 != alphaS)
				::DrawSCylinder(pObj, pDC, pICS,
								logRect, loffset, alphaS, 3600, center, 0, nType);
			if(1800 != alphaE)
				::DrawECylinder(pObj, pDC, pICS,
							logRect, loffset, 1800, alphaE, center, 0, nType);
		}
	//}
	//���Ż���Pie����,�Ա��ס���ر�
	CRect rect = logRect; 
	int penW = pObj->GetLPenSize();
	rect.InflateRect( 0, penW/2 );
	COLORREF clrLPen = KColorModel::IndexToRef(pObj->GetLPenColor(), pICS);
//	::DrawArcChordPie( pObj, pDC, pView, rect, 0, alphaS, alphaE-alphaS, 0/*Pie*/,1/*ES_Close*/);
	::DrawRotateArcChordPie( pObj, pDC, pICS, rect, alphaS, alphaE, center, 0, 
							clrLPen, nType, 0/*Pie*/, 1/*ES_Close*/);
}

CPoint GetArcEndPnt(const CRect& rect, int thta, int thtb)
{
	double mA = (double)thta*PI/1800;
	double mB = (double)thtb*PI/1800;
	double dx, dy;
	dx = rect.Width()/2;
	dy = rect.Height()/2;
	CPoint rctO = rect.CenterPoint();
	CPoint end;
	double B = atan2( dx*sin(mB+mA), dy*cos(mB+mA) );//change to theta angle
	end.x = rctO.x + D2I(dx*cos(B));
	end.y = rctO.y - D2I(dy*sin(B));

	return end;
}

/*  nStartTht	������ʼ��, nEndTht	ĩ������֮��ĽǶ���0.1��Ϊ��λ
	nShap		���Ƶ���״0 is pie, 1 is chord
	nPntstyle 		�˵�ķ��0 is open, 1 is close, 2 is none
*/
void DrawArcChordPie( CFPBase* pObj, CDC* pDC, IColorScheme* pICS,
					 CRect& logRect, COLORREF endClr, 
					 int nStartTht, int nEndTht, int nShap, int nPntstyle )
{
	CPoint start = ::GetArcStartPnt(logRect, nStartTht);
	CPoint end   = ::GetArcEndPnt(logRect, nStartTht, nEndTht);
//	if ( pView ) pView->DocToClient( start );
//	if ( pView ) pView->DocToClient( end );
	CRect rect = logRect;
//	if ( pView ) pView->DocToClient( rect );
	switch (nShap)
	{
	case 0:  //is pie
		if ( nPntstyle == 1 )	 //ES_Close == 1
			pDC->Pie( rect, start, end );
		else
		{	CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
			pDC->Pie( rect, start, end );
			pDC->SelectObject(pOldPen);
			pDC->Arc( rect, start, end );
		}
		break;
	case 1:	//is chord
		if ( nPntstyle == 1 )	 //ES_Close == 1
			pDC->Chord( rect, start, end );
		else
		{	CPen* pOldPen = (CPen*)pDC->SelectStockObject(NULL_PEN);
			pDC->Chord( rect, start, end );
			pDC->SelectObject(pOldPen);
			pDC->Arc( rect, start, end );
		}
		break;
	}
//	//	���˵�
//	((CRectObj*)pObj)->DrawArcEnd( pDC, pView, pICS, endClr, start, end, rect,
//			 nStartTht, nEndTht, ((CPTObj*)pObj)->m_theta );
}

void CCake::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	CRect rct = m_rect;
	pDC->LPtoDP(&rct);
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formFrac ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);
	
	DrawPosition( pDC, rct );

	ASSERT_VALID(this);
	ASSERT_VALID(pDC);
	
	//if(!m_bNeedDraw)
	//	return ;
	//	set pen
	int penW = 0;
	CPen* pOldPen = SelectPenObject(pDC, pICS, penW, FALSE);
	
	//	set brush
	int nOldBkMode = pDC->GetBkMode();
	COLORREF clrOldBk = pDC->GetBkColor();
	CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);
	
	CPoint pntSource;
	CRect ellipseRct;
	switch(m_nCakeShap)
	{
		case CRectObj::pieColumn:
			{
					CSize ellipseSiz(m_rect.Width(), m_rect.Height()*m_nScale/100);
					ellipseRct = CRect(m_rect.TopLeft(), ellipseSiz);
					CRect cylinderRct(&m_rect);
					cylinderRct.top += ellipseSiz.cy / 2;
					long loffset = cylinderRct.Height() - ellipseRct.Height() / 2;
					::DrawPieColumn(this, pDC, pICS, ellipseRct, loffset, m_CakeDataST.alphaS, 
						m_CakeDataST.alphaE, m_center, 0, IsRegular);
			}
			break;
		case CRectObj::ellipse:
			{
					//Add by wym for draw dashline 02/26/1999
			/*		if (m_uLPenStyle > PS_SOLID && m_uLPenStyle < PS_NULL)
					{//������
						CRect lrct = m_rect;
						//��ʿ�
						int A = m_roundness.x;
						int B = m_roundness.y + A;				
						lrct.DeflateRect(penW,penW);
						COLORREF clrPen = KColorModel::IndexToRef(GetLPenColor(), pICS);
						DrawRotateArcChordPie(this, pDC, pICS, 
							lrct, A, B, m_center, m_theta, clrPen, IsRegular, m_nellipseArcType, m_nEndStyle);
					}
					else*/
						::DrawArcChordPie(this, pDC, pICS, m_rect, RGB(0,0,0), m_CakeDataST.alphaS,
								m_CakeDataST.alphaE - m_CakeDataST.alphaS, 0, 1);
			}
			break;				   
	}
	
	pDC->SetBkMode(nOldBkMode);		//	set BkMode
	pDC->SetBkColor(clrOldBk);		//	set BkColor
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);

	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
}

/*	����: �������߶�����������ϵ�������ʶ
	bDraw			�Ƿ����
	nHandleStyle	������ʶ����״,��Ϊ������, Բ��, ������, ����
	clr				������ʶ����ɫ
	uWidth			uWidth*2+1Ϊ������ʶ�������θ߶�,�߼�����0.1mm
*/
void CPolyLine::DrawHandle(CDC* pDC, BOOL bDraw, int nHandleStyle,
						   COLORREF clr, USHORT uWidth)
{
	if (!bDraw)
		return;
	
	POSITION pos = m_PointList.GetHeadPosition(); 
	CPoint tempPnt(uWidth, 0);
	
	UINT num = m_PointList.GetCount();
    CPoint* polypointArray = new CPoint[num]; //NewPoints(num + 1);
	for (UINT i = 0; i < num; i++)
	{
		polypointArray[i] = m_PointList.GetNext(pos);
		//����������ʶ��rect
		CRect handleRect(polypointArray[i].x - tempPnt.x, polypointArray[i].y - tempPnt.x,
						polypointArray[i].x + tempPnt.x, polypointArray[i].y + tempPnt.x);
		switch(nHandleStyle)
		{
			case rectangle:
				//	pDC->Rectangle(&handleRect);
				{
					CPoint pnt[4];
					pnt[0].x = handleRect.left;
					pnt[0].y = handleRect.top;
					pnt[1].x = handleRect.right;
					pnt[1].y = handleRect.top;
					pnt[2].x = handleRect.right;
					pnt[2].y = handleRect.bottom;
					pnt[3].x = handleRect.left;
					pnt[3].y = handleRect.bottom;
					pDC->Polygon(pnt, 4);
				}
				break;
			case ellipse:
				pDC->Ellipse(&handleRect);
				break;
			case triangle:
				{
					CPoint pnt[3];
					pnt[0].x = (handleRect.left + handleRect.right) / 2;
					pnt[0].y = handleRect.top;
					pnt[1] = handleRect.BottomRight();
					pnt[2].x = handleRect.left;
					pnt[2].y = handleRect.bottom;
					pDC->Polygon(pnt, 3);
				}
				break;
			case diamond:
				{
					CPoint pnt[4];
					pnt[0].x = (handleRect.left + handleRect.right)/2;
					pnt[0].y = handleRect.top;
					pnt[1].x = handleRect.right;
					pnt[1].y = (handleRect.top + handleRect.bottom)/2;
					pnt[2].x = pnt[0].x;
					pnt[2].y = handleRect.bottom;
					pnt[3].x = handleRect.left;
					pnt[3].y = pnt[1].y;
					pDC->Polygon(pnt, 4);
				}
				break;
		}
	}
	delete[] polypointArray;
}

void CPolyLine::DrawShape(CDC* pDC, IColorScheme* pICS)
{
	CRect rct = m_rect;
	pDC->LPtoDP(&rct);
	rct.OffsetRect(-pDC->GetViewportOrg());
	//	ԭ�������� formFrac ���Ͻ�
	pDC->OffsetViewportOrg(rct.left, rct.top);

//	rct.InflateRect(CSize(m_uWidth, m_uWidth));
	DrawPosition( pDC, rct );

	ASSERT_VALID(this);	
	ASSERT(m_nPolyobjShape == polyLine);
	
	int nOldBkMode = pDC->GetBkMode();
	COLORREF clrOldBk = pDC->GetBkColor();
	int penW = 0;
	CPen* pOldPen = SelectPenObject(pDC, pICS, penW, FALSE);
	CBrush* pOldBrush = SetBrushBkModeBkColor(pDC, pICS);

	UINT num = m_PointList.GetCount();
    CPoint* polypointArray = new CPoint[num]; //NewPoints(num + 1);
    ASSERT(polypointArray != NULL);			 

	POSITION pos = m_PointList.GetHeadPosition();
	for (UINT i = 0; i < num; i ++)
		polypointArray[i] = m_PointList.GetNext(pos);
	
	//���ƶ���
/*	if (m_uLPenStyle > PS_SOLID && m_uLPenStyle < PS_NULL)
	{
		CDashLine dashline(*pDC, penW);
		dashline.PolyLine(polypointArray, num);
	}
	else
*/
		pDC->Polyline(polypointArray, num); 
	pDC->SelectObject(pOldPen);
	
	//����Handle��
	UINT nOldPenSize = m_uLPenSize;
	m_uLPenSize = 2;
	pOldPen = SelectPenObject(pDC, pICS, penW, FALSE);
	COLORREF clrFill = KColorModel::CalcSecondColorForOneShade(GetBkColor(), 
														GetFillColor(), pICS);
	DrawHandle(pDC, m_bDraw, m_nHandleStyle, clrFill, m_uWidth);

	m_uLPenSize = nOldPenSize;
    delete[] polypointArray;

	pDC->SetBkMode(nOldBkMode);		//	set BkMode
	pDC->SetBkColor(clrOldBk);		//	set BkColor
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);

	//	��ԭԭ��
	pDC->OffsetViewportOrg(-rct.left, -rct.top);
}

// -------------------------------------------------------------------------
