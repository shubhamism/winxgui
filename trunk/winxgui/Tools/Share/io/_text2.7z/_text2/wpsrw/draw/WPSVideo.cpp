
/*************************************************************************
	�ļ���:	WPSVideo.CPP  --  Implementation for CWPSVideo

	˵��:	��������Ϊ WINWPS ���̵�һ����, ʵ��CWPSVideo�࣬�Ա���WPS�ļ�
			�в�����Ƶ����(AVI��)

	���:	����

	����:	1998�� 7��10��
*************************************************************************/

#include "stdafx.h"

#ifndef _INC_VFW
#include "vfw.h"
#endif

//#include "ResID_String.h"
//#include "ResID_Cursor.h"
//#include "ResID_Cmd.h"

class CWPSDoc;
class CWPSView;

#include "WPSObj.h"
//#include "PageOP.h"
#include "WndCtrl.h"
#include "WPSVideo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define		ID_MCI_SCALE_ORIGINAL				32924
#define		ID_MCI_SCALE_HALF					32925
#define		ID_MCI_SCALE_DOUBBLE				32926
#define		ID_MCI_SCALE_USERDEFINED			32927

void MakeRelaPath (const CString&, const CString&, CString*);
void MakeAbsoPath (const CString&, const CString&, CString*);

#ifndef _WPSREADER
LPCTSTR LoadWPSString(UINT uID);
int GetModulePath (LPSTR, int);
extern BOOL g_bWin9xOrWinNT;
///***********************************************************************
//	���ܣ�	�򿪶Ի������û�ѡȡAVI�ļ�
//	���ڣ�	���ɹ�ȷ��AVI�ļ�����������TRUE���ļ�����·������szPathName��
//			����������FALSE
//***********************************************************************/
//BOOL GetVideoClip (CString& szPathName)
//{
//	// ��ס�ϴ�ѡͼ���Ŀ¼
//	static TCHAR szDir[MAX_PATH] =_T("");
//	if (::lstrlen(szDir)==0)	// ȱʡȡ��������Ŀ¼
//		::GetModulePath (szDir, MAX_PATH);
//
//	CFileDialog dlg (TRUE);
//	OPENFILENAME* pOFN = &(dlg.m_ofn);
////	pOFN->lpstrFilter = "������Ƶ�����ļ�\0*.avi;*.mpg;*.flc\0AVI�ļ�\0*.avi\0MPG�ļ�\0*.mpg\0FLC�ļ�\0*.flc\0\0";
//	CString str1, str2;
//	str1.LoadString(IDS_AVI_TYPE);
//	//str2.LoadString(IDS_INSERTAVI);
//
//	LPTSTR lpsz = str1.GetBuffer(0);
//	while ((lpsz = strchr(lpsz, (TCHAR)'|')) != NULL)
//		*lpsz++ = '\0';
//
//	pOFN->lpstrFilter = (LPCTSTR)str1;
//	//pOFN->lpstrTitle = (LPCTSTR)str2;
//	
//	pOFN->lpstrInitialDir = szDir;
//	pOFN->lpstrDefExt = _T("AVI");
//	pOFN->Flags |=  OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST |
//					OFN_HIDEREADONLY;
//	pOFN->lStructSize = g_bWin9xOrWinNT ? 76 : 88;
//	BOOL bEC = FALSE;
//	if (dlg.DoModal()==IDOK)
//	{	szPathName = dlg.GetPathName();
//		bEC = TRUE;
//
//		// ��¼�µ�ͼ��Ŀ¼
//		LPTSTR pszFile = pOFN->lpstrFile;
//		if (pszFile && ::lstrlen(pszFile))
//		{	::lstrcpy (szDir, pszFile);
//			CString str(szDir);
//			int n = str.ReverseFind ('\\')+1;
//			szDir[n] = 0;	// ��ȡĿ¼����Ҫ�ļ���
//		}
//	}
//	else
//		bEC = FALSE;
//	return bEC;
//}
#endif
//
///***********************************************************************
//	���ܣ�	��Ӧ�û����������Ƶ�����ļ�
//***********************************************************************/
//#ifndef _WPSREADER
//void CWpsView::OnInsertVideoClip()
//{
//	iWPS_READONLYPROCESS(;)
//
//	CString sz;
//	if (::GetVideoClip(sz))
//	{	// ȷ������λ��
//		CRect rc;
//		CWPSObj* pObj = GetCurObj();
//		if (!pObj)
//			rc.SetRectEmpty();
//		else if (pObj!=(CWPSObj*)(GetCurPage()->GetFrameText()))
//		{	ASSERT_VALID(pObj);
//			rc = pObj->m_rect;
//			rc.OffsetRect(10,10);
//		}
//		else
//		{	CRect rect(GetInitialPosition(), CSize(0,0));
//			rc = rect;
//		}
//
//		// ���ɶ���
//		CloseAllObjsForCreatePTObj();
//		CWPSVideo* pCtrl;
//		TRY
//		{	pCtrl = new CWPSVideo (GetDocument(), rc);
//			pCtrl->InitClass (this, sz);
//		}
//		CATCH_ALL(e)
//		{	ASSERT (FALSE);
//			return;
//		}
//		END_CATCH_ALL
//
//		AddObj (pCtrl);
//		SetSelectedObj (pCtrl, FALSE);
//		OnUpdate(NULL, NULL, m_pCurPage);
//	}
//}
//#endif	// #ifndef _WPSREADER
//
//#ifndef _GWSREADER
//LRESULT CWpsView::OnMCIWndMNotifyMode (WPARAM wParam, LPARAM lParam)
//{
//	HWND wndMCI = (HWND)wParam;
//	LONG lMode = (LONG)lParam;
//	if (lParam==MCI_MODE_STOP)	// ����STOP��ʵ����������
//	{	CWPSVideo* pObj = (CWPSVideo*)GetWindowLong (wndMCI, GWL_USERDATA);
//		if (pObj)
//		{	ASSERT_KINDOF (CWPSVideo, pObj);
//			ASSERT_VALID (pObj);
//
//			if (pObj->QueryNonStopPlay())
//				MCIWndPlay (wndMCI);
//			else
//				MCIWndStop (wndMCI);
//			return 1L;
//		}
//	}
//	return DefWindowProc (MCIWNDM_NOTIFYMODE, wParam, lParam);
//}
//#endif	// #ifndef _GWSREADER
//
//#ifndef _GWSREADER
//void CWpsView::OnMCIWndPlayOrStop()
//{
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//		pObj->TogglePlayAndStop();
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _GWSREADER
//
//#ifndef _GWSREADER
//void CWpsView::OnMCIWndSeekToBegin()
//{
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//		pObj->SeekToBegin();
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _GWSREADER
//
//#ifndef _GWSREADER
//void CWpsView::OnMCIWndSeekToEnd()
//{
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//		pObj->SeekToEnd();
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _GWSREADER
//
//#ifndef _GWSREADER
//void CWpsView::OnMCIWndToggleNonStopPlay()
//{
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//		pObj->ToggleNonStopPlay();
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _GWSREADER
//
//#ifndef _WPSREADER
//void CWpsView::OnMCIWndChangeScale (UINT uID)
//{
//	ASSERT (uID>=ID_MCI_SCALE_FIRST && uID<=ID_MCI_SCALE_LAST);
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//		pObj->ChangeScale (uID, this);
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _WPSREADER
//
//#ifndef _GWSREADER
//void CWpsView::OnUpdateMCIWndToggleNonStopPlay(CCmdUI* pCmdUI)
//{
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//		pCmdUI->SetCheck (pObj->QueryNonStopPlay());
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _GWSREADER
//
//#ifndef _GWSREADER
//LPCTSTR LoadWPSString(UINT uID);
//void CWpsView::OnUpdateMCIWndPlayOrStop(CCmdUI* pCmdUI)
//{
//	CWPSVideo* pObj = (CWPSVideo*)GetCurObj();
//	if (pObj && pObj->GetWPSObjType()==WPSMCIVideo)
//	{	ASSERT_VALID (pObj);
//
//		TCHAR szPlay[80];
//		TCHAR szStop[80];
//		strcpy(szPlay, LoadWPSString(IDS_PLAY));
//		strcpy(szStop, LoadWPSString(IDS_STOP));
//
//		LPCTSTR lpsz = pObj->IsPlaying() ? szStop : szPlay;
//		pCmdUI->SetText (lpsz);
//	}
//#ifdef _DEBUG
//	else
//		ASSERT(FALSE);
//#endif
//}
//#endif	// #ifndef _GWSREADER


/////////////////////////////////////////////////////////////////////////////
// CWPSVideo

//IMPLEMENT_SERIAL(CWPSVideo, CWPSWndCtrl, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CWPSVideo, CWPSWndCtrl, 0xA0 | VERSIONABLE_SCHEMA)

#ifdef _DEBUG
void CWPSVideo::Dump(CDumpContext& dc) const
{
	CFPBase::Dump( dc);
	dc << "\nI'm a CWPSVideo object.\n";
	dc << m_szFile; dc << "\n";
}

void CWPSVideo::AssertValid() const
{
	CWPSWndCtrl::AssertValid();

	if (m_hWnd)
		ASSERT (m_nAviWidth>0 && m_nAviHeight>0);

	ASSERT (m_uScale==ID_MCI_SCALE_ORIGINAL ||
			m_uScale==ID_MCI_SCALE_HALF ||
			m_uScale==ID_MCI_SCALE_DOUBBLE ||
			m_uScale==ID_MCI_SCALE_USERDEFINED);
	ASSERT (m_wrapMode==wm_around || m_wrapMode==wm_onlargerside ||
			m_wrapMode==wm_left   || m_wrapMode==wm_right ||
			m_wrapMode==wm_notonside || m_wrapMode==wm_nowrap);
	ASSERT (m_mgOutsideType==None ||
			m_mgOutsideType==All ||
			m_mgOutsideType==LeftRight ||
			m_mgOutsideType==TopBottom ||
			m_mgOutsideType==Left ||
			m_mgOutsideType==Right ||
			m_mgOutsideType==Top ||
			m_mgOutsideType==Bottom);
}
#endif //_DEBUG

CWPSVideo::CWPSVideo()
			: CWPSWndCtrl()
{
	m_bNonStop = FALSE;
	m_nAviWidth = m_nAviHeight = 0;
	m_uScale = ID_MCI_SCALE_ORIGINAL;
	m_szFile[0] = 0;
	m_bFileExist = TRUE;
	m_mgOutsideType = All;
	SetWrapMode (wm_onlargerside);
}

#ifndef _WPSREADER
CWPSVideo::CWPSVideo (const CWpsDoc* pDoc, const CRect& rc)
			: CWPSWndCtrl (pDoc, rc)
{
	m_bNonStop = FALSE;
	m_nAviWidth = m_nAviHeight = 0;
	m_uScale = ID_MCI_SCALE_ORIGINAL;
	m_szFile[0] = 0;
	m_bFileExist = TRUE;
	m_mgOutsideType = All;

	SetWPSObjType (WPSMCIVideo);
//	SetLPenStyle (PS_NULL);		// �ޱ߿�
	SetLPenSize (21);
	SetLPenColor (RGB(128,128,128));
	SetWrapMode (wm_onlargerside);
	SetMrgSize (All, &m_MarginOutside, 50);
}
#endif	// #ifndef _WPSREADER

//royho 20041213 ����������ͬCWPSWndCtrl����
#ifndef _WPSREADER
CWPSVideo::CWPSVideo (const CWPSVideo* pObj)
{
	ASSERT_VALID (this);
	ASSERT_VALID (pObj);
//	CopyObj (pObj);
}
#endif	// #ifndef _WPSREADER

CWPSVideo::~CWPSVideo()
{
}

//#ifndef _WPSREADER
//void CWPSVideo::CopyObj (const CWPSObj* pObj, BOOL bCopyContent /*= TRUE*/)
//{
//	ASSERT_VALID (pObj);
//	//	���ƻ�������
//	CWPSWndCtrl::CopyObj (pObj, bCopyContent);
//
//	//	���Ʊ�������
//	ASSERT_KINDOF (CWPSVideo, pObj);
//	CWPSVideo* pWCObj = (CWPSVideo*)pObj;
//	m_bNonStop = pWCObj->m_bNonStop;
//	m_uScale = pWCObj->m_uScale;
//	m_nAviWidth = pWCObj->m_nAviWidth;
//	m_nAviHeight = pWCObj->m_nAviHeight;
//	lstrcpy (m_szFile, pWCObj->m_szFile);
//}
//#endif	// #ifndef _WPSREADER

#ifndef _WPSREADER
//DEL CWPSObj* CWPSVideo::Clone()
//DEL {	ASSERT_VALID(this);
//DEL 	ASSERT_VALID (m_pDocument);
//DEL 	CWPSVideo* pClone;
//DEL 	TRY
//DEL 	{	pClone = new CWPSVideo(m_pDocument,m_rect);
//DEL 	}
//DEL 	CATCH_ALL(e)
//DEL 	{	TRACE2 ("%s %u: Failed.\n", __FILE__, __LINE__);
//DEL 		return NULL;
//DEL 	}
//DEL 	END_CATCH_ALL
//DEL 	pClone->CopyObj (this);
//DEL 	return pClone;
//DEL }
#endif	// #ifndef _WPSREADER

#ifndef _WPSREADER
//DEL BOOL CWPSVideo::InitClass (CWpsView* pView, LPCTSTR lpszFile)
//DEL {
//DEL 	ASSERT (::lstrlen(lpszFile)<sizeof(m_szFile));
//DEL 	::lstrcpy (m_szFile, lpszFile);
//DEL 	return InitClass (pView);
//DEL }
#endif	// #ifndef _WPSREADER

//#ifndef _WPSREADER
//DEL BOOL CWPSVideo::InitClass (CWpsView* pView)
//DEL {
//DEL 	ASSERT_VALID (pView);
//DEL 	if (pView->GetCurPage()==NULL ||	// ������view�������׶�...
//DEL 		!m_bFileExist)	// ���ļ�������
//DEL 		return FALSE;
//DEL 
//DEL 	// ȷ���ļ�����
//DEL 	WIN32_FIND_DATA wfd;
//DEL 	HANDLE hFF = ::FindFirstFile (m_szFile, &wfd);
//DEL 	if (hFF==INVALID_HANDLE_VALUE)
//DEL 	{	CString szMsg;
//DEL 		AfxFormatString1 (szMsg, IDS_FILE_NOT_FOUND, m_szFile);
//DEL 		AfxMessageBox (szMsg, MB_OK | MB_ICONINFORMATION);
//DEL 		m_bFileExist = FALSE;
//DEL 		return FALSE;
//DEL 	}
//DEL 	else
//DEL 		VERIFY (::FindClose(hFF));
//DEL 
//DEL 
//DEL 	// ��������
//DEL 	m_hWnd = ::MCIWndCreate(
//DEL 		pView->m_hWnd,
//DEL 		AfxGetInstanceHandle(),
//DEL 		WS_CHILD |
//DEL 			MCIWNDF_NOMENU |
//DEL 			MCIWNDF_NOPLAYBAR|
//DEL 			MCIWNDF_NOTIFYALL,
//DEL 		m_szFile);
//DEL 	//	"ActiveMovie");
//DEL 	//	"d:/vcsheet/test.mpg");
//DEL 	if (!m_hWnd)
//DEL 		{ ASSERT(FALSE); return FALSE; }
//DEL //	VERIFY (MCIWndOpen(m_hWnd,m_szFile,0)==0);
//DEL 	SetWindowText (m_hWnd, m_szFile);	// ������SPY++�����ָ�MCI����
//DEL 
//DEL 	// ȷ�����ڳߴ�
//DEL 	CRect rcWnd; ::GetWindowRect (m_hWnd, &rcWnd);
//DEL 	rcWnd.OffsetRect (-rcWnd.left, -rcWnd.top);
//DEL 	m_nAviWidth = rcWnd.right;
//DEL 	m_nAviHeight = rcWnd.bottom;
//DEL 
//DEL 	// ���ݱ������ڴ��ڴ�С
//DEL 	AdjustWndSizeByScale (pView);
//DEL 	::ShowWindow (m_hWnd, SW_SHOWNOACTIVATE);
//DEL 	
//DEL 	VERIFY (DoSubClass());
//DEL 	return TRUE;
//DEL }
//#endif	// #ifndef _WPSREADER

//DEL CRect CWPSVideo::GetObjMidBox()
//DEL {	CRect rc = m_rect;
//DEL 	int penW = GetLPenSize();
//DEL 	rc.InflateRect( penW, penW);
//DEL 	return rc;
//DEL }

//DEL CRect CWPSVideo::GetObjMaxBox()
//DEL {
//DEL 	CRect rc = GetObjMidBox();
//DEL 
//DEL 	// �ټ�����Ӱ
//DEL #pragma WPS_MSG ("Not finished.")
//DEL 
//DEL 	// �ⲿ����
//DEL 	rc.left -= m_MarginOutside.left;
//DEL 	rc.top -= m_MarginOutside.top;
//DEL 	rc.right += m_MarginOutside.right;
//DEL 	rc.bottom += m_MarginOutside.bottom;
//DEL 
//DEL 	return rc;
//DEL }

//void CWPSVideo::Draw (CDC* pDC, CWpsView* pView, IColorScheme* pICS, int nFlag/*=DS_ONTEXT*/)
//{
//	CWPSWndCtrl::Draw (pDC, pView, pICS, nFlag);
//
//	DrawBorder (pDC, pView, pICS);
//
///*
//	CRect rc = m_rect;
//	pView->DocToClient (rc);
//
//	pDC->OffsetViewportOrg (rc.left, rc.top);
//	CRect rect = rc; rect.OffsetRect (-rect.left, -rect.top);
//	pDC->Rectangle (&rect);
//	pDC->OffsetViewportOrg (-rc.left, -rc.top);
//*/
//}

//DEL void CWPSVideo::DrawBorder (CDC* pDC, CWpsView* pView, IColorScheme* pICS)
//DEL {
//DEL 	COLORREF clr = KColorModel::IndexToRef(GetLPenColor(), pICS);
//DEL 
//DEL 	CPoint pt;
//DEL 	pt.x = GetLPenSize();
//DEL 	pView->DocToClient (pt);
//DEL //	pt.x &= 0xFFFFFFFE;		// ʹ��Ϊż��
//DEL 	const int cb = pt.x / 3;
//DEL 
//DEL 	CRect rc = m_rect;
//DEL 	pView->DocToClient (rc);
//DEL 
//DEL 	int i;
//DEL 	for (i=0; i<cb; i++)
//DEL 	{
//DEL 		pDC->Draw3dRect (&rc, ::GetSysColor(COLOR_3DSHADOW),
//DEL 							  ::GetSysColor(COLOR_3DHILIGHT));
//DEL 		rc.InflateRect (1,1);
//DEL 	}
//DEL 	for (i=0; i<cb; i++)
//DEL 	{
//DEL 		pDC->Draw3dRect (&rc, ::GetSysColor(COLOR_3DFACE),
//DEL 							  ::GetSysColor(COLOR_3DFACE));
//DEL 		rc.InflateRect (1,1);
//DEL 	}
//DEL 	for (i=1; i<cb; i++)
//DEL 	{
//DEL 		pDC->Draw3dRect (&rc, ::GetSysColor(COLOR_3DHILIGHT),
//DEL 							  ::GetSysColor(COLOR_3DSHADOW));
//DEL 		rc.InflateRect (1,1);
//DEL 	}
//DEL 	pDC->Draw3dRect (&rc, ::GetSysColor(COLOR_3DSHADOW),
//DEL 						  ::GetSysColor(COLOR_3DSHADOW));
//DEL 
//DEL }

//DEL BOOL CWPSVideo::IsPlaying() const
//DEL {	ASSERT_VALID (this);
//DEL 	TCHAR szBuf[16];
//DEL 	DWORD dwMode = MCIWndGetMode (m_hWnd, szBuf, sizeof(szBuf));
//DEL 	return (dwMode==MCI_MODE_PLAY);
//DEL }

//DEL void CWPSVideo::TogglePlayAndStop() const
//DEL {	ASSERT_VALID (this);
//DEL 	if (IsPlaying())
//DEL 		MCIWndPause (m_hWnd);
//DEL 	else
//DEL 		MCIWndPlay (m_hWnd);
//DEL }

//DEL void CWPSVideo::SeekToBegin() const
//DEL {	ASSERT_VALID (this);
//DEL 	BOOL bPlaying = IsPlaying();
//DEL 	MCIWndStop (m_hWnd);
//DEL 	VERIFY (MCIWndSeek(m_hWnd,MCIWND_START)==0);
//DEL 	if (bPlaying)
//DEL 		MCIWndPlay (m_hWnd);
//DEL }

//DEL void CWPSVideo::SeekToEnd() const
//DEL {	ASSERT_VALID (this);
//DEL 	MCIWndStop (m_hWnd);
//DEL 	VERIFY (MCIWndSeek(m_hWnd,MCIWND_END)==0);
//DEL }

//DEL void CWPSVideo::ToggleNonStopPlay()
//DEL {	ASSERT_VALID (this);
//DEL 	m_bNonStop = m_bNonStop ? FALSE : TRUE;
//DEL }

#ifndef _WPSREADER
//DEL void CWPSVideo::ChangeScale (UINT uScale, CWpsView* pView)
//DEL {	ASSERT_VALID (this);
//DEL 	ASSERT (uScale>=ID_MCI_SCALE_FIRST && uScale<=ID_MCI_SCALE_LAST);
//DEL 	ASSERT_VALID (pView);
//DEL 
//DEL 	if (m_uScale!=uScale)
//DEL 	{	m_uScale = uScale;
//DEL 		AdjustWndSizeByScale (pView);
//DEL 	}
//DEL }
#endif	// #ifndef _WPSREADER

#ifndef _WPSREADER
//DEL void CWPSVideo::SizeTo (const CRect& rc, CWpsView* pView)
//DEL {	ASSERT_VALID (this);
//DEL 	m_uScale = ID_MCI_SCALE_USERDEFINED;
//DEL 	CWPSWndCtrl::SizeTo (rc, pView);
//DEL }
#endif	// #ifndef _WPSREADER

#ifndef _WPSREADER
//DEL void CWPSVideo::AdjustWndSizeByScale (CWpsView* pView)
//DEL {
//DEL 	CRect rcWnd;
//DEL 	if (::GetWindowRect(m_hWnd, &rcWnd)==FALSE)
//DEL 		{ ASSERT(FALSE); return; }
//DEL 
//DEL 	rcWnd.OffsetRect (-rcWnd.left, -rcWnd.top);
//DEL 	rcWnd.right = ::MulDiv (254, m_nAviWidth, 96);
//DEL 	rcWnd.bottom = ::MulDiv (254, m_nAviHeight, 96);
//DEL 	if (m_uScale==ID_MCI_SCALE_ORIGINAL)
//DEL 		NULL;
//DEL 	else if (m_uScale==ID_MCI_SCALE_HALF)
//DEL 	{	rcWnd.right /= 2;
//DEL 		rcWnd.bottom /= 2;
//DEL 	}
//DEL 	else if (m_uScale==ID_MCI_SCALE_DOUBBLE)
//DEL 	{	rcWnd.right *= 2;
//DEL 		rcWnd.bottom *= 2;
//DEL 	}
//DEL #ifdef _DEBUG
//DEL 	else
//DEL 		{ ASSERT(FALSE); return; }
//DEL #endif
//DEL 
//DEL 	rcWnd.OffsetRect (m_rect.left, m_rect.top);
//DEL 	InvalObj (pView, FALSE);
//DEL 	MoveTo (rcWnd, pView);
//DEL }
#endif	// #ifndef _WPSREADER

void CWPSVideo::Serialize_98 (KSArchive& ar)
{
	CWPSWndCtrl::Serialize_98 (ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);
		ar << m_bNonStop;
		ar << m_uScale;
		ar << (DWORD)0;		// 8�ֽڻ���
		ar << (DWORD)0;

		// ���ļ����ɾ���·��תΪ���·��
		CString sz;
		CFile* pFile = ar.GetFile();
		if (pFile)
		{	CString szDoc = pFile->GetFilePath();
			if (szDoc.IsEmpty()==FALSE)
			{	CString szFile(m_szFile);
				::MakeRelaPath (szDoc, szFile, &sz);
			}
		}
		else
			sz = m_szFile;
		
		// �������·����ע�⣺δ���ַ�����β��NULL�ַ�
		WORD wSize = sz.GetLength();	// ��λ���ֽ�
		ar << wSize;
		ar.Write ((const void*)(LPCTSTR)sz, wSize);

	//	WORD wSize = (lstrlen(m_szFile)+1)*sizeof(TCHAR);
	//	ar << wSize;
	//	ar.Write (m_szFile, wSize);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		DWORD dw;
		ar >> m_bNonStop;
		ar >> m_uScale;
		ar >> dw;		// 8�ֽڻ���
		ar >> dw;

		WORD wSize;
		ar >> wSize; ASSERT (wSize<sizeof(m_szFile));
		ar.Read (m_szFile, wSize);
		m_szFile[wSize] = 0;

		// ���ļ��������·��תΪ����·��
		CFile* pFile = ar.GetFile();
		if (pFile)
		{	CString szDoc = pFile->GetFilePath();
			if (szDoc.IsEmpty()==FALSE)
			{	CString szFile(m_szFile);
				CString sz;
				::MakeAbsoPath (szDoc, szFile, &sz);
				::lstrcpy (m_szFile, sz);
			}
		}

		// �ж϶���������Ƿ���Ч
		if (m_uScale!=ID_MCI_SCALE_ORIGINAL &&
			m_uScale!=ID_MCI_SCALE_HALF &&
			m_uScale!=ID_MCI_SCALE_DOUBBLE &&
			m_uScale!=ID_MCI_SCALE_USERDEFINED)
		{	ASSERT (FALSE);
			AfxThrowArchiveException (CArchiveException::badIndex);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CWPSVideo::Serialize_01(KSArchive& ar)
{
	CWPSWndCtrl::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ASSERT_VALID(this);
		ar << m_bNonStop;
		ar << m_uScale;
		ar << (DWORD)0;		// 8�ֽڻ���
		ar << (DWORD)0;

		// ���ļ����ɾ���·��תΪ���·��
		CString sz;
		CFile* pFile = ar.GetFile();
		if (pFile)
		{	CString szDoc = pFile->GetFilePath();
			if (szDoc.IsEmpty()==FALSE)
			{	CString szFile(m_szFile);
				::MakeRelaPath (szDoc, szFile, &sz);
			}
		}
		else
			sz = m_szFile;
		
		// �������·����ע�⣺δ���ַ�����β��NULL�ַ�
		WORD wSize = sz.GetLength();	// ��λ���ֽ�
		ar << wSize;
		ar.Write ((const void*)(LPCTSTR)sz, wSize);

	//	WORD wSize = (lstrlen(m_szFile)+1)*sizeof(TCHAR);
	//	ar << wSize;
	//	ar.Write (m_szFile, wSize);
	}
	else
#endif	// #ifndef _WPSREADER
	{
		DWORD dw;
		ar >> m_bNonStop;
		ar >> m_uScale;
		ar >> dw;		// 8�ֽڻ���
		ar >> dw;

		WORD wSize;
		ar >> wSize; ASSERT (wSize<sizeof(m_szFile));
		ar.Read (m_szFile, wSize);
		m_szFile[wSize] = 0;

		// ���ļ��������·��תΪ����·��
		CFile* pFile = ar.GetFile();
		if (pFile)
		{	CString szDoc = pFile->GetFilePath();
			if (szDoc.IsEmpty()==FALSE)
			{	CString szFile(m_szFile);
				CString sz;
				::MakeAbsoPath (szDoc, szFile, &sz);
				::lstrcpy (m_szFile, sz);
			}
		}

		// �ж϶���������Ƿ���Ч
		if (m_uScale!=ID_MCI_SCALE_ORIGINAL &&
			m_uScale!=ID_MCI_SCALE_HALF &&
			m_uScale!=ID_MCI_SCALE_DOUBBLE &&
			m_uScale!=ID_MCI_SCALE_USERDEFINED)
		{	ASSERT (FALSE);
			AfxThrowArchiveException (CArchiveException::badIndex);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

//#ifndef _WPSREADER
//DEL void CWPSVideo::SetMrgOutsideType (const int i)
//DEL {
//DEL 	ASSERT (i==None || i==All || i==LeftRight || i==TopBottom ||
//DEL 			i==Left || i==Right || i==Top || i==Bottom);
//DEL 	m_mgOutsideType = (MrgSideType)i;
//DEL }
//#endif	// #ifndef _WPSREADER

/*********************************************************************
	˵����	����������CFrameObj::SetMrgSize()
*********************************************************************/
#ifndef _WPSREADER
void CWPSVideo::SetMrgSize (MrgSideType mgType, CRect* mgRect, const int mgSize)
{
	switch ( mgType)
	{
	case None:      
		mgRect->left   = 0;
		mgRect->right  = 0;
		mgRect->top    = 0;
		mgRect->bottom = 0;
		break;
	case All:      
		mgRect->left   = mgSize;
		mgRect->right  = mgSize;
		mgRect->top    = mgSize;
		mgRect->bottom = mgSize;
		break;
	case LeftRight:
		mgRect->left   = mgSize;
		mgRect->right  = mgSize;
		break;
	case TopBottom:
		mgRect->top    = mgSize;
		mgRect->bottom = mgSize;
		break;
	case Left:
		mgRect->left   = mgSize;
		break;
	case Right:
		mgRect->right  = mgSize;
		break;
	case Top:
		mgRect->top    = mgSize;
		break;
	case Bottom:
		mgRect->bottom = mgSize;
		break;
	default:
		ASSERT(FALSE);
		break;
	}
}
#endif	// #ifndef _WPSREADER

//DEL int  CWPSVideo::GetMrgSize (MrgSideType mgType, CRect& mgRect)
//DEL {
//DEL 	ASSERT_VALID (this);
//DEL 	switch ( mgType)
//DEL 	{
//DEL 	case None:      	return -1;
//DEL 	case All:      
//DEL 	case LeftRight:
//DEL 	case Left:      	return mgRect.left;
//DEL 	case Right:     	return mgRect.right;
//DEL 	case TopBottom:
//DEL 	case Top:       	return mgRect.top;
//DEL 	case Bottom:    	return mgRect.bottom;
//DEL 	}          
//DEL 	return -1;
//DEL }

//DEL CRect* CWPSVideo::GetMarginOutside()
//DEL {
//DEL 	ASSERT_VALID (this);
//DEL 	return &m_MarginOutside;
//DEL }

//DEL BOOL CWPSVideo::OnMouseMove (CWpsView* pView, UINT, CPoint&)
//DEL {
//DEL 	ASSERT_VALID (this);
//DEL 	ASSERT_VALID (pView);
//DEL 	::SetCursor (AfxGetApp()->LoadCursor(IDC_FINGER));
//DEL 	pView->EnableWpsToolTips (m_szFile);
//DEL 	return TRUE;
//DEL }

//DEL BOOL CWPSVideo::OnLButtonDown (CWpsView* pView, UINT, CPoint&)
//DEL {
//DEL #ifndef _GWSREADER
//DEL 	ASSERT_VALID (this);
//DEL 	ASSERT_VALID (pView);
//DEL 
//DEL 	// ����ʾ�����ʾģʽ�£����������Ĵ���������ͬ
//DEL 	if (pView->IsInPresentationMode())
//DEL 	{	// ����ʾģʽ�£������������������ţ�Ȼ���ڿ�ʼ/��ͣ���л�
//DEL 		if (pView->GetCurObj()!=this || pView->IsObjActivated()==FALSE)
//DEL 			pView->ActivateObj(this);
//DEL 		else
//DEL 			TogglePlayAndStop();
//DEL 	}
//DEL 	else	// �ڷ���ʾģʽ�£������������ڿ�ʼ/��ͣ���л�
//DEL 	{	if (pView->GetCurObj()==this && pView->IsObjActivated())
//DEL 			TogglePlayAndStop();
//DEL 	}
//DEL 	::SetCursor (AfxGetApp()->LoadCursor(IDC_FINGER));
//DEL #endif	// #ifndef _GWSREADER
//DEL 	return TRUE;
//DEL }

//DEL BOOL CWPSVideo::OnLButtonDblClk (CWpsView* pView, UINT uFlags, CPoint& pt)
//DEL {
//DEL #ifndef _GWSREADER
//DEL 	ASSERT_VALID (this);
//DEL 	ASSERT_VALID (pView);
//DEL 	ASSERT (pView->GetCurObj()==this);
//DEL 
//DEL 	if (!pView->IsInPresentationMode() && !pView->IsObjActivated())
//DEL 		pView->ActivateObj(this);
//DEL 	::SetCursor (AfxGetApp()->LoadCursor(IDC_FINGER));
//DEL #endif	// #ifndef _GWSREADER
//DEL 	return TRUE;
//DEL }

//DEL void CWPSVideo::Activate (CWpsView*, CWPSObj*)
//DEL {
//DEL 	if (!IsPlaying())
//DEL 		MCIWndPlay (m_hWnd);
//DEL //		TogglePlayAndStop();
//DEL }

//DEL void CWPSVideo::Deactivate (CWpsView* pView, CWPSObj*)
//DEL {
//DEL 	if (pView->GetCurPage())
//DEL 	{	pView->SetObjbEdit (FALSE);
//DEL 		if (IsPlaying())
//DEL 			MCIWndStop (m_hWnd);
//DEL 		MCIWndSeek (m_hWnd, MCIWND_START);
//DEL 	}
//DEL }

//#ifndef _WPSREADER
//DEL void CWPSVideo::OpenObjDlg (CWpsView* pView)
//DEL {
//DEL 	if (!m_hWnd)
//DEL 		{ ASSERT(FALSE); return; }
//DEL 
//DEL 	MCIWndStop (m_hWnd);
//DEL 	CString sz;
//DEL 	if (::GetVideoClip(sz))
//DEL 	{	// ��������
//DEL 		CObList selList(1);
//DEL 		pView->GetSafeSelList (selList);
//DEL 		pView->UndoSetup_ChangeObjAttrib (&selList);
//DEL 		
//DEL 		// ��������
//DEL 		DeleteContent();
//DEL 		InitClass (pView, sz);
//DEL 	}
//DEL }
//#endif	// #ifndef _WPSREADER

//BEGIN_MESSAGE_MAP(CWPSVideo, CWnd)
//	//{{AFX_MSG_MAP(CWPSVideo)
//		// NOTE - the ClassWizard will add and remove mapping macros here.
//	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWPSVideo message handlers
