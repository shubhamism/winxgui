/* -------------------------------------------------------------------------
//	�ļ���		��	wppcommon.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-28 15:39:37
//	��������	��
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "wppcommon.h"
#include <export/ks_colormodel.h>
#include <draw/wpsimg.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//--------------------��ɫ����(��ɫ����)�ַ������� start--------------------
static KCOLORINDEX CALC_COLORSCHEME_VALUE(DWORD nCS)
{
	KCOLORINDEX indexColor;
	KColorModel::CreateKCOLORINDEX(indexColor, ksocolorFlagSchemeIndex, nCS);
	return indexColor;
}

const KCOLORINDEX enCSBg_Value = CALC_COLORSCHEME_VALUE(enCSBg);
const KCOLORINDEX enCSLine_Value = CALC_COLORSCHEME_VALUE(enCSLine);
const KCOLORINDEX enCSText_Value = CALC_COLORSCHEME_VALUE(enCSText);
const KCOLORINDEX enCSShadow_Value = CALC_COLORSCHEME_VALUE(enCSShadow);
const KCOLORINDEX enCSTitletext_Value = CALC_COLORSCHEME_VALUE(enCSTitletext);
const KCOLORINDEX enCSFill_Value = CALC_COLORSCHEME_VALUE(enCSFill);
const KCOLORINDEX enCSAccent_Value = CALC_COLORSCHEME_VALUE(enCSAccent);
const KCOLORINDEX enCSMark_Value = CALC_COLORSCHEME_VALUE(enCSMark);
const KCOLORINDEX enCSHyperLink_Value = CALC_COLORSCHEME_VALUE(enCSHyperLink);


// -------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
//ͼ�����ݴ洢��
IMPLEMENT_SERIAL(KCWPPImgPackage, CObject, 0xDB)
KCWPPImgPackage::KCWPPImgPackage()
{
	m_nImgId = -1;	//-1Ϊ��Чֵ
	m_pImg   = NULL;
}
KCWPPImgPackage::~KCWPPImgPackage()
{
	if (m_pImg != NULL)
	{
		ReleaseWpsImage(m_pImg);
		m_pImg = NULL;
	}
}
void KCWPPImgPackage::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_nImgId;
		ar << m_pImg;
	}
	else
	{
		ar >> m_nImgId;
		ar >> m_pImg;
		//��2002֮ǰ�İ汾ֻ�в���һ�֣������ֲ�������Ҵ��ʽ�����������һ�� wanli 2002��6��5��
		if (m_pImg && m_pImg->GetImgSizeType() == IMG_SIZE_TYPE_SCALE)
		{
			m_pImg->SetImgSizeType(IMG_SIZE_TYPE_FILL);
		}
	}
}
