//////////////////////////////////////////////////////////////////////////
// Mci.h : header file
//
// This header file provides generic support for mci devices
//
// Copyright (C) 1997, 1998 Giancarlo Iovino (giancarlo@saria.com)
// All rights reserved. May not be sold for profit.
//
// This software is provided 'as it is' without implicit or explicit
// warranty.
//
// This code was develeped for MFC Programmer's Sourcebook
// (http://www.codeguru.com)
//

#if !defined(AFX_MCI_H_098R22G3234_23453_235124_123A44HQ13451_INCLUDED_)
#define AFX_MCI_H_098R22G3234_23453_235124_123A44HQ13451_INCLUDED_

#ifndef _INC_MMSYSTEM
#include <mmsystem.h>
#endif // _INC_MMSYSTEM

#ifndef __WPSOBJ_H
#include "WPSObj.h"
#endif	// __WPSOBJ_H

// ��ʾ͸��16ɫλͼ����,cpp��wpsctl.cpp.
void ShowTransparentBMP(HDC hdc, HBITMAP hBMPOriginal, COLORREF oldBkColor,
		int nDestPosX, int nDestPosY, int nSrcPosX, int nSrcPosY,
		int nBMPWidth, int nBMPHeight,int nDestwidth=0,int nDestheight=0);


//mci(CD,MIDI,WAVE)�����Ϣ.(��stdafx.h�е�bgmusicpara�ṹ��ͬ.!!)
typedef struct tagPresMciPara
{	
	TCHAR	strCDID[16];			//CD�ļ�����.
	int		nBeginTrack;			//��ʼ�ŵ�.
	int		nEndTrack;				//�����ŵ�.
	int		nBeginMinute;			//��ʼ����.
	int		nBeginSecond;			//��ʼ����.
	int		nEndMinute;				//��������.
	int		nEndSecond;				//��������.
	BOOL	bCDLoop;				//�Ƿ�ѭ������CD.
	TCHAR	strMidiName[MAX_PATH];	//MIDI�ļ���.
	BOOL	bMidiLoop;				//�Ƿ�ѭ������MIDI.
	TCHAR	strWavName[MAX_PATH];	//wav�ļ���.
	BOOL	bWavLoop;				//�Ƿ�ѭ������wav.
	TCHAR	strMP3Name[MAX_PATH];	//MP3�ļ���.
	BOOL	bMP3Loop;				//�Ƿ�ѭ������MP3.
}PresMciPara;




class CMsf {
public:
	CMsf() {
		m_dwMsf = 0;
	}

	CMsf(DWORD dwMsf) {		
		m_dwMsf = dwMsf;
	}

	CMsf(BYTE minute, BYTE second, BYTE frame) {		
		m_dwMsf = MCI_MAKE_MSF(minute, second, frame);
	}
	
	operator DWORD() const {return m_dwMsf;}
	
	BYTE GetMinute() const { return MCI_MSF_MINUTE(m_dwMsf); }
	BYTE GetSecond() const { return MCI_MSF_SECOND(m_dwMsf); }
	BYTE GetFrame() const { return MCI_MSF_FRAME(m_dwMsf); }

protected:
	DWORD m_dwMsf;
};

class CTmsf {
public:
	CTmsf() {
		m_dwTmsf = 0;
	}

	CTmsf(DWORD dwTmsf) {		
		m_dwTmsf = dwTmsf;
	}

	CTmsf(BYTE track, BYTE minute, BYTE second, BYTE frame) {		
		m_dwTmsf = MCI_MAKE_TMSF(track, minute, second, frame);
	}
	
	operator DWORD() const {return m_dwTmsf;}

	BYTE GetTrack() const { return MCI_TMSF_TRACK(m_dwTmsf); }
	BYTE GetMinute() const { return MCI_TMSF_MINUTE(m_dwTmsf); }
	BYTE GetSecond() const { return MCI_TMSF_SECOND(m_dwTmsf); }
	BYTE GetFrame() const { return MCI_TMSF_FRAME(m_dwTmsf); }

protected:
	DWORD m_dwTmsf;
};

//////////////////////////////////////////////////////////////////////////
// The CMciDevice class is the base class for all MCI devices
//
#ifndef __FPBASE_H__
#include "fpbase.h"
#endif

class CMciDevice : public CFPBase {
DECLARE_SERIAL(CMciDevice);			//  �������������
public:	
	// Common modes
	static const DWORD s_ModeNotReady;
	static const DWORD s_ModePause;
	static const DWORD s_ModePlay;
	static const DWORD s_ModeStop;
	static const DWORD s_ModeOpen;
	static const DWORD s_ModeRecord;
	static const DWORD s_ModeSeek;
	// Common status items
	static const DWORD s_StatusReady;
	static const DWORD s_StatusMediaPresent;
	static const DWORD s_StatusMode;
	static const DWORD s_StatusNumberOfTracks;
	// Common capabilites
	static const DWORD s_GetdevcapsCanEject;
	static const DWORD s_GetdevcapsCanPlay;
	static const DWORD s_GetdevcapsCanRecord;
	static const DWORD s_GetdevcapsCanSave;
	static const DWORD s_GetdevcapsCompound;
	static const DWORD s_GetdevcapsDeviceType;	
	static const DWORD s_GetdevcapsHasAudio;
	static const DWORD s_GetdevcapsHasVideo;
	static const DWORD s_GetdevcapsUsesFiles;
	
	// Device Info
	static const DWORD s_InfoProduct;
	//ADD BY WY,����CD�ı�ʶ.
	static const DWORD s_InfoMediaIdentity;

	// Device types
	static const DWORD s_DevtypeAnimation;
	static const DWORD s_DevtypeCdaudio;
	static const DWORD s_DevtypeDat;
	static const DWORD s_DevtypeDigitalvideo;
	static const DWORD s_DevtypeOther;
	static const DWORD s_DevtypeOverlay;
	static const DWORD s_DevtypeScanner;
	static const DWORD s_DevtypeSequencer;
	static const DWORD s_DevtypeVcr;
	static const DWORD s_DevtypeVideodisc;
	static const DWORD s_DevtypeWaveaudio;

	
	//�̳�CFPBase.
#ifndef	_WPSREADER
//	virtual void CopyObj (const CWPSObj*, BOOL = TRUE);
#endif
	virtual void Serialize_98 (KSArchive& ar);//����.
	virtual void Serialize_01(KSArchive&);

	//�̳�cwpsobj.

#ifdef _DEBUG
	virtual void Dump(CDumpContext&) const;
	virtual void AssertValid () const;
#endif //_DEBUG

	// Construction/Destruction
	CMciDevice();
	~CMciDevice();

// Data members
protected:
	MCIDEVICEID	m_wDeviceID;					// The device ID
	HWND		m_hMainWnd;						// The callback window handle

	BOOL		m_bPlay;						//�Ƿ��ڲ���.
	BOOL		m_bOpen;						//�Ƿ񱻴�.
	BOOL		m_bPause;						//�Ƿ���ͣ.

private:
	MCIERROR	m_dwLastError;					// The last error code
	BOOL		m_bReportErrors;				// Report MCI errors?	
};

#endif // !defined(AFX_MCI_H_098R22G3234_23453_235124_123A44HQ13451_INCLUDED_)
