/* -------------------------------------------------------------------------
//	�ļ���		��	wpsrw/wpsobjtool.h
//	������		��	������
//	����ʱ��	��	2005-2-23 17:48:30
//	��������	��	
//
//	$Id: wpsobjtool.h,v 1.1 2005/02/23 10:05:49 duanyuluo Exp $
// -----------------------------------------------------------------------*/
#ifndef __WPSRW_WPSOBJTOOL_H__
#define __WPSRW_WPSOBJTOOL_H__


// -------------------------------------------------------------------------
//	����ǰ��ת����תǰ�ĵ�
inline
CPoint GetNoRotatePoint(const CPoint& point,
					  const CPoint& center,
					  const int theta)
{
	double dx, dy;
	dx =  point.x - center.x;
	dy = -point.y + center.y;
	double tht = theta*PI/1800;
	double cost = cos( -tht);
	double sint = sin( -tht);

	CPoint ptReturn;
	ptReturn.x = center.x + (int)(dx*cost - dy*sint);
	ptReturn.y = center.y - (int)(dx*sint + dy*cost);
	return ptReturn;
}

inline 
CPoint __GetRectangleCenterPoint(const CRect& rc)
{
	return CPoint((rc.left + rc.right) / 2, (rc.top + rc.bottom) / 2);
}

inline
CRect GetShapeNonRotateRect(CWPSObj* pWpsObj)
{
	CRect rc = pWpsObj->GetMrect();
	CRect rcNonRotate(rc);
	
	int nObjType = pWpsObj->CheckObjType();
	switch (nObjType)
	{
	case LTXTObj:
	case LTXTSizeComment:
		{
			// dyl:todo
		}
		break;
	case MultitextRect:
		{
			// dyl:todo
		}
		break;
	case FRAMEOLE:
		{
			// dyl:todo
		}
		break;
	case LINEObj:
		{
			// dyl:todo
		}
		break;
	case RECTObj:
	case RECTRound:
	case RECTEllipse:
	case RECTDiamond:
	case RECTCube:
	case RECTCylinder:
	case RECTPieColumn:
		{
			CRectObj* pRectObj = reinterpret_cast<CRectObj*>(pWpsObj);
			CPoint ptRotateCenter = __GetRectangleCenterPoint(rc);
			CPoint ptNonRotateCenter = GetNoRotatePoint(ptRotateCenter,
				pRectObj->GetObjThetaCenter(), -pRectObj->GetObjTheta());
			
			CPoint ptOffset = ptNonRotateCenter - ptRotateCenter;
			
			rcNonRotate.OffsetRect(ptOffset);
		}
		break;
	case POLYObj:
		break;
	case CURVEObj:
		break;
	case RECTPoly:
		{
			// dyl:todo
		}
		break;
	}
	return rcNonRotate;
}

// -------------------------------------------------------------------------
//	$Log: wpsobjtool.h,v $
//	Revision 1.1  2005/02/23 10:05:49  duanyuluo
//	*** empty log message ***
//	

#endif /* __WPSRW_WPSOBJTOOL_H__ */
