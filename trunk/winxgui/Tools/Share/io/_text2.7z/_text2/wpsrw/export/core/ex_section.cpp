/* -------------------------------------------------------------------------
//	�ļ���		��	ex_section.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 16:21:12
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_wpsdoc.h"
#include "../draw/ex_shape.h"//for WpsShapeToTwip
#include "../draw/frametext.h"
#include "../draw/ex_frametext.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP CSectionInfo_Export::Convert(KWpsExport& export, KDWPropBuffer& sepx) const
{
	KDWDocProperties& docpro = export.GetDop();
	/*ֽ�ű߾�*/
	//ҳ��߾�
	INT32 dxaLeft = m_crcOddMargin.left, dxaRight = m_crcOddMargin.right,
		dxaTop = m_crcOddMargin.top, dxaBottom = m_crcOddMargin.bottom;
	if(m_nPaperOrient == DMORIENT_LANDSCAPE)//ֽ�ŷ���Ӱ��ҳ��߾�
	{
		INT32 tmp = dxaLeft;
		dxaLeft = dxaBottom;
		dxaBottom = dxaRight;
		dxaRight = dxaTop;
		dxaTop = tmp;
	}
	if(m_bStartFromLeft)//��ҳΪ��ҳ��Ӱ��ҳ��߾�
	{
		INT32 tmp = dxaLeft;
		dxaLeft = dxaRight;
		dxaRight = tmp;
	}
	dxaLeft = WpsShapeToTwip(dxaLeft);
	dxaRight = WpsShapeToTwip(dxaRight);
	dxaTop = WpsShapeToTwip(dxaTop);
	dxaBottom = WpsShapeToTwip(dxaBottom);
	sepx.AddPropFix(sprmSDxaLeft, dxaLeft);
	sepx.AddPropFix(sprmSDxaRight, dxaRight);
	sepx.AddPropFix(sprmSDyaTop, dxaTop);
	sepx.AddPropFix(sprmSDyaBottom, dxaBottom);
	//ҳ��ѡ��
	if(m_bSymmetric)//�Գ�ҳ�߾�
	{
		if(export.m_iSection == 0)//ֻ���ǵ�һ�ڵ�
		{
			docpro.dop.fMirrorMargins = 1;
		}
		//wps��չָ��
		UINT8 value[2];
		value[0] = kscodeSMirrorMargins;
		value[1] = TRUE;
		sepx.AddPropVar(sprmSKSCodeExt, value, sizeof(value));
	}

	/*ֽ������*/
	//ֽ�Ŵ�С �� ����
	sepx.AddPropFix(sprmSDmPaperReq, m_nPaperType);
	sepx.AddPropFix(sprmSBOrientation, m_nPaperOrient);
	INT32 cxPage, cyPage;
	if(m_nPaperOrient == DMORIENT_PORTRAIT)
	{
		cxPage = WpsShapeToTwip(m_cszPageSize.cx);
		cyPage = WpsShapeToTwip(m_cszPageSize.cy);
	}
	else
	{
		cxPage = WpsShapeToTwip(m_cszPageSize.cy);
		cyPage = WpsShapeToTwip(m_cszPageSize.cx);
	}
	sepx.AddPropFix(sprmSXaPage, cxPage);
	sepx.AddPropFix(sprmSYaPage, cyPage);
	export.m_nPageCoreWidth = cxPage - dxaLeft - dxaRight;

	//��ֽ�趨
	if(m_bScriptSheet)
	{
		ConvertScriptSheet(export, sepx, CSize(cxPage, cyPage), 
			CRect(dxaLeft, dxaTop, dxaRight, dxaBottom));
	}
	/*����*/
	//������
	sepx.AddPropFix(sprmSCcolumns, m_nColumns - 1);
	//�����(wps����඼������ͬ��)
	sepx.AddPropFix(sprmSDxaColumns, WpsShapeToTwip(m_nColumnGap));
	//������(word��ֻ�������Ƿ��зָ���,������������,������ɫ)
	if(m_nColLineStyle != PS_NULL)
	{
		sepx.AddPropFix(sprmSLBetween, 1);
	}
	//���ַ���(wps�еĴ���������word��û��)
	if(m_TextLineMode == vertr2l || m_TextLineMode == vertl2r)
	{
		sepx.AddPropFix(sprmSTextFlow, 1);
	}
	//��ʼҳ��
	if(m_nPageNumOrg != -1)
	{
		//lijun Ҫ����ҳ�����¿�ʼ����������,�Ǻ�
		sepx.AddPropFix(sprmSPgnStart, m_nPageNumOrg);		
		sepx.AddPropFix(sprmSFPgnRestart, 1);
	}	
	/*ҳüҳ��*/
	sepx.AddPropFix(sprmSDyaHdrTop, WpsShapeToTwip(m_nHeaderToTop));
	sepx.AddPropFix(sprmSDyaHdrBottom, WpsShapeToTwip(m_nFooterToBottom));
	//����ҳ��ͬ(ǿ����Ϊ��ͬ)
//	if(m_bMultiHeader || m_bMultiFooter)
	{
		if(export.m_iSection == 0)//ֻ���ǵ�һ�ڵ�
		{
			docpro.dop.fFacingPages = 1;
		}
		//wps��չָ��
		UINT8 value[2];
		value[0] = kscodeSFacingPages;
		value[1] = TRUE;
		sepx.AddPropVar(sprmSKSCodeExt, value, sizeof(value));
	}
	//��עβע
	CFootnoteMan *pFootnote = ((CWpsDoc *)export.m_pDoc)->GetFootnoteMan();
	sepx.AddPropFix(sprmSFNNumStart, pFootnote->m_nFNStartID);	
	if (pFootnote->m_wFNMode == 3)	
		sepx.AddPropFix(sprmSFNRestart, 2);		
	switch(pFootnote->m_FNFormat)
	{
	case 0:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcDbChar);
		break;
	case 1:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcChnDbNum1);
		break;
	case 2:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcChnDbNum2);
		break;
	case 3:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcLCRoman);
		break;
	case 4:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcUCRoman);
		break;
	case 5:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcOrdinal);
		break;
	case 6:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcSbChar);
		break;
	case 7:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcLCLetter);
		break;
	case 8:
		sepx.AddPropFix(sprmSFNNumFmt, mso_nfcUCLetter);
		break;
	default:
		ASSERT(FALSE);
		break;
	}	

	sepx.AddPropFix(sprmSENStart, pFootnote->m_nENStartID);
	if (pFootnote->m_wENMode == 3)	
		sepx.AddPropFix(sprmSENRestart, 2);	
	switch(pFootnote->m_ENFormat)
	{
	case 0:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcDbChar);
		break;
	case 1:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcChnDbNum1);
		break;
	case 2:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcChnDbNum2);
		break;
	case 3:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcLCRoman);
		break;
	case 4:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcUCRoman);
		break;
	case 5:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcOrdinal);
		break;
	case 6:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcSbChar);
		break;
	case 7:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcLCLetter);
		break;
	case 8:
		sepx.AddPropFix(sprmSENNumFmt, mso_nfcUCLetter);
		break;
	default:
		ASSERT(FALSE);
		break;
	}	
	//wps��"��ҳ����ʾҳü/ҳ��"��word��ͬ,word����"��ҳ��ͬ",����������ҳüҳ��
	//���߻������޶�Ӧ...
	if(m_bNoHeaderAtStart && m_bNoFooterAtStart)
	{
		sepx.AddPropFix(sprmSFTitlePage, 1);
	}
	
	/*ҳ��߿�*/
	ConvertPageBorder(sepx);

	return S_OK;
}


STDMETHODIMP CSectionInfo_Export::ConvertPageBorder(KDWPropBuffer& sepx) const
{
	if(m_nRectRange != PR_NULL)
	{
		KDWBrc brcLT, brcRB;
		BRC bLT, bRB;
		gSetBRCEX(m_PageRect.dwColor, m_PageRect.nWidth * 10,//��Ȼ�Ǻ��ף�����
			m_PageRect.nStyle, brcLT, &brcRB, m_PageRect.nDistance, TRUE);
		bLT = brcLT.get_Brc();
		bRB = brcRB.get_Brc();
		//
		sepx.AddPropFix(sprmSBrcTop, (UINT32&)bLT);
		sepx.AddPropVar(sprmSBrcExTop, &brcLT, sizeof(brcLT));
		//
		sepx.AddPropFix(sprmSBrcLeft, (UINT32&)bLT);
		sepx.AddPropVar(sprmSBrcExLeft, &brcLT, sizeof(brcLT));
		//
		sepx.AddPropFix(sprmSBrcRight, (UINT32&)bRB);
		sepx.AddPropVar(sprmSBrcExRight, &brcRB, sizeof(brcRB));
		//
		sepx.AddPropFix(sprmSBrcBottom, (UINT32&)bRB);
		sepx.AddPropVar(sprmSBrcExBottom, &brcRB, sizeof(brcRB));
		
		//
		SpgbProp pgbProp = {0};
		if(m_nRectRange == PR_EXCEPTFIRST)
			pgbProp.applyTo = mso_pgbExpFirst;
		else
			pgbProp.applyTo = mso_pgbSection;
		pgbProp.pageDepth = mso_pgbFront;
		pgbProp.offsetFrom = mso_pgbFromText;
		sepx.AddPropFix(sprmSPgbProp, (UINT32&)pgbProp);
	}

	return S_OK;
}

STDMETHODIMP CSectionInfo_Export::AddHeaderFooter(KWpsExport& export, 
							 HEADERFOOTER_TYPE headerfooterType,
							 CFrameText* pFrameText) const
{
	export.m_WhatHeaderInExportedAllPageObjs = headerfooterType;
	if(pFrameText)
	{
		KDWPropBuffer papx;
		papx.AddIstd(0);

		union
		{
			LSPD lspd;
			INT32 val;
		};
		lspd.fMultLinespace = 0;
		lspd.dyaLine = 1;
		papx.AddPropFix(sprmPDyaLine,val);

		export.NewParagraph(&papx);
		export.NewNullChpxSpan();

//		export.m_npfea = KWpsExport::_NPFEA_NOTNEED;
		CWPSObj* pObj = (CWPSObj*)pFrameText;

		// Modify by dyl
		// ����ҳü�ı����ʵ�ʸ߶���ȡ�����Եģ������Ҫ�ڵ���֮ǰ��
		// �������������ҳü�߶����õ��ı�����
		CRect rcHdFtSize = pObj->GetMrect();
		int nHdFtHeight = 0;
		if (headerfooterType == DW_EVEN_HEADER || 
			headerfooterType == DW_ODD_HEADER ||
			headerfooterType == DW_FIRST_HEADER)
		{
			ASSERT(m_crcOddMargin.top - m_nHeaderToTop >= m_nHeaderHeight);
			nHdFtHeight = m_crcOddMargin.top - m_nHeaderToTop;
		}
		else
		{
			ASSERT(m_crcOddMargin.bottom - m_nFooterToBottom >= m_nFooterHeight);
			nHdFtHeight = m_crcOddMargin.bottom - m_nFooterToBottom;
		}
		rcHdFtSize.bottom = rcHdFtSize.top + nHdFtHeight;
		pObj->SetMrect(rcHdFtSize);

		// Note by dyl
		// ��ΪWPS��V6��ҳü�߶ȵĴ�������ͬ����Ҫ��V6�з�һ��Ƕ����ı���
		// ��ʵ�ֺ�WPS���ݵ�Ч��
		CShape_Context ShapeContext(export);
		ShapeContext.m_optUDef.AddPropBool(msopt_fInlineShape, TRUE);
		ShapeContext.Export(pObj);

		//��ҳü��ת������ҳ/��żҳ�����
		export.ExportAllPageObjs();

		export.AddContent(0x0d);

/*
		//lijun ת��ҳü�ı���ɫ
		CTextPool_Export *pTextPool_ex = ((CTextPool_Export*)pFrameText->c_pTextPool);			
		int nCount = pTextPool_ex->NumOfParagraphs();		
		for (int i = 0; i < nCount; ++i)
		{
			CParagraph_Export* pPara = (CParagraph_Export*)pTextPool_ex->GetParagraph(i);
			ASSERT(pPara);

			::memset(&pPara->m_shdEx, 0, sizeof(BKColor));
			
			if (pFrameText->m_nBkMode == OPAQUE)
				pPara->m_fBKColor = TRUE; 
			pPara->m_shdEx.crBack = pFrameText->m_logbrush.lbColor;
			if(pFrameText->m_nBkMode == OPAQUE && pFrameText->m_logbrush.lbStyle == BS_HATCHED)
			{
				
				pPara->m_shdEx.crBack = pFrameText->m_bkColor;
			}
			if (pFrameText->m_logbrush.lbStyle == BS_HATCHED)
			{
				pPara->m_shdEx.crFore = pFrameText->m_logbrush.lbColor;
				switch(pFrameText->m_logbrush.lbHatch)
				{
				case HS_HORIZONTAL:
					pPara->m_shdEx.ipat = mso_patHorizontal;
					break;
				case HS_VERTICAL:
					pPara->m_shdEx.ipat = mso_patVertical;
					break;
				case HS_FDIAGONAL:
					pPara->m_shdEx.ipat = mso_patForwardDiagonal;
					break;
				case HS_BDIAGONAL:
					pPara->m_shdEx.ipat = mso_patBackwardDiagonal;
					break;
				case HS_CROSS:
					pPara->m_shdEx.ipat = mso_patCross;
					break;
				case HS_DIAGCROSS:
					pPara->m_shdEx.ipat = mso_patDiagonalCross;
					break;
				}
			}
			
			CParagraph_Content *pParaConatent = new CParagraph_Content();
			pParaConatent->SetExport((KWpsExport *)&export);
			pParaConatent->SetParagraph(pPara);			

			pPara->Export((CParagraph_Content &)*pParaConatent);	

			delete pParaConatent;
		}
		*/
	}
	else
	{
		export.m_npfea = KWpsExport::_NPFEA_NEED;
		export.ExportAllPageObjs();
	}
	return S_OK;
}

STDMETHODIMP CSectionInfo_Export::AddHeaderFooter(KWpsExport& export) const
{
	const int rgType[] = {DW_EVEN_HEADER, DW_ODD_HEADER, DW_EVEN_FOOTER, DW_ODD_FOOTER};
	CFrameText* prgFrameText[4] = {0};
	int rgID[] = {m_nHeaderEvenID, m_nHeaderOddID, m_nFooterEvenID, m_nFooterOddID};
	if(rgID[0] == -1/*û��ż��ҳü*/ && !m_bMultiHeader/*��żҳҳü��ͬ*/)
	{
		rgID[0] = m_nHeaderOddID;//������ҳü
	}
	if(rgID[1] == -1/*û������ҳü*/ && !m_bMultiHeader/*��żҳҳü��ͬ*/)
	{
		rgID[1] = m_nHeaderEvenID;//��ż��ҳü
	}
	if(rgID[2] == -1/*û��ż��ҳ��*/ && !m_bMultiFooter/*��żҳҳ����ͬ*/)
	{
		rgID[2] = m_nFooterOddID;//������ҳ��
	}
	if(rgID[3] == -1/*û������ҳ��*/ && !m_bMultiFooter/*��żҳҳ����ͬ*/)
	{
		rgID[3] = m_nFooterEvenID;//��ż��ҳ��
	}
	for(int i = 0; i < countof(rgType); i++)
	{
		if(rgID[i] != -1)
		{
			prgFrameText[i] = m_pParent->GetFrameTextByID(rgID[i]);
			ASSERT(prgFrameText[i]);
		}
		if(!prgFrameText[i] && rgID[i] == -1 && export.m_iSection == 0)//��һ�ڿ�����Ĭ��ҳüҳ��
		{
			switch(i)
			{
			case 0:
				prgFrameText[i] = m_bMultiHeader ? m_pParent->GetDefaultHeaderEven() : m_pParent->GetDefaultHeaderOdd();
				break;
			case 1:
				prgFrameText[i] = m_pParent->GetDefaultHeaderOdd();
				break;
			case 2:
				prgFrameText[i] = m_bMultiFooter ? m_pParent->GetDefaultFooterEven() : m_pParent->GetDefaultFooterOdd();
				break;
			case 3:
				prgFrameText[i] = m_pParent->GetDefaultFooterOdd();
				break;
			}
		}
		if (prgFrameText[i])
		{
			export.EnterHeaderFooter((HEADERFOOTER_TYPE)rgType[i]);//ż��ҳü
			AddHeaderFooter(export, (HEADERFOOTER_TYPE)rgType[i], prgFrameText[i]);
			export.LeaveHeaderFooter();
		}
		if (m_bMultiHeader == FALSE && (i == 0 || i == 2))
			(export.GetAutoNumExport())->m_AutonumGroupMap.clear();
	}

//	export.EnterHeaderFooter(DW_EVEN_HEADER);//ż��ҳü
//	AddHeaderFooter(export, DW_EVEN_HEADER, m_pParent->GetDefaultHeaderEven(), m_nHeaderEvenID);
//	export.LeaveHeaderFooter();
//
//	export.EnterHeaderFooter(DW_ODD_HEADER);//����ҳü
//	AddHeaderFooter(export, DW_ODD_HEADER, m_pParent->GetDefaultHeaderOdd(), m_nHeaderOddID);
//	export.LeaveHeaderFooter();
//
//	export.EnterHeaderFooter(DW_EVEN_FOOTER);//ż��ҳ��
//	AddHeaderFooter(export, DW_EVEN_FOOTER, m_pParent->GetDefaultFooterEven(), m_nFooterEvenID);
//	export.LeaveHeaderFooter();
//
//	export.EnterHeaderFooter(DW_ODD_FOOTER);//����ҳ��
//	AddHeaderFooter(export, DW_ODD_FOOTER, m_pParent->GetDefaultFooterOdd(), m_nFooterOddID);
//	export.LeaveHeaderFooter();

	return S_OK;	
}

STDMETHODIMP CSectionInfo_Export::AddBackground(KWpsExport& export) const
{
	CSlideBackground* psbg = ((CSectionInfo*)this)->GetPageBackGround();
	gCovertBackground(export.GetBackground(), export.GetBlipStore(), psbg, 
		m_pBkGndImg ? m_pBkGndImg->m_pImg : NULL);
	return S_OK;
//	CSlideBackground* psbg = ((CSectionInfo*)this)->GetPageBackGround();
//	if(psbg)
//	{
//		//wps��ÿ�������Լ��ı���,��word�������ĵ�һ������,ֻ�ý�wps�µ�һ�ڵı�����Ϊת��Դ
//		KDWShape bgShape = export.GetBackground();
//		KDWShapeOPT opt;
//		switch(psbg->m_nFillType)
//		{
//		case enBG_SOLIDFILL:
//			gConvertSolidFill(opt, psbg->m_clrSolid);
//			break;
//		case enBG_SHADEDFILL:
//			gConvertGradientFill(opt, psbg->m_ShadeCtrl.shadeDir, psbg->m_ShadeCtrl.shadeStyle,
//				psbg->m_ShadeCtrl.shadeColor[0], psbg->m_ShadeCtrl.shadeColor[1]);
//			break;
//		case enBG_PATTERNEDFILL:
//		case enBG_PICTUREFILL:
//			ASSERT(m_pBkGndImg && m_pBkGndImg->m_pImg);
//			gConvertImage(export, opt, m_pBkGndImg->m_pImg, FALSE);
//			break;
//		}
//		//	opt.ForceAddPropBool(msopt_fFilled, TRUE);
//		//	opt.ForceAddPropBool(msopt_fLine, FALSE);
//		bgShape.SetShapeType(msosptRectangle);
//		bgShape.SetProperties(opt);
//	}
//	return S_OK;
}

STDMETHODIMP CSectionInfo_Export::ConvertScriptSheet(KWpsExport& export,
		KDWPropBuffer& sepx, SIZE pageSize, RECT pageMargin) const
{
	export.m_bScriptSheet = TRUE;
	CWpsDoc* pDoc = (CWpsDoc*)export.m_pDoc;
	INT32 cxCore, cyCore;
	cxCore = pageSize.cx - pageMargin.left - pageMargin.right;
	cyCore = pageSize.cy - pageMargin.top - pageMargin.bottom;
	INT32 CharSpace, LinePitch;
	CharSpace = cxCore / m_nScriptSheetColumns - 210;//��׼5�������ֿ�210twip
	if(CharSpace < 0)
		CharSpace = 0;
	CharSpace = CharSpace * 1024 / 5;
	LinePitch = cyCore / m_nScriptSheetRows;
	//
	sepx.AddPropFix(sprmSClm, mso_gmLineAndCharGrid);
	sepx.AddPropFix(sprmSDxtCharSpace, CharSpace);
	sepx.AddPropFix(sprmSDyaLinePitch, LinePitch);

	return S_OK;
}



// -------------------------------------------------------------------------
