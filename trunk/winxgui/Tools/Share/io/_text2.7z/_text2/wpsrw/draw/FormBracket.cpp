/*************************************************************************
�ļ���: FormBracket.cpp
˵��:		���ļ�����WPS��ʽ�༭����
�ָ�����:	��ѧ��
����:		�Ὥ 1998�� 8��10��
************************************************************************/
#include "stdafx.h"
#include "math.h" 

#ifndef _WPSREADER
//#include "ResID_BMP.h"
//#include "ResID_Dlg.h"
//#include "ResID_Ctrls.h"
//#include "ResID_String.h"
//#include "TipsDlg.h"
#endif

#ifndef __WPSOBJ_H
#include "wpsobj.h"
#endif

#if !defined(AFX_KSTEXTSTRING_H_INCLUDED_)
//#include "KSTextString.h"
#endif

#ifndef __FORMULAE_H
#include "formulae.h"
#endif

#ifndef __FORMCELL_H
#include "formcell.h"
#endif

#ifndef __WPSVIEW_H
//#include "wpsview.h"
#endif

#ifndef __FRAMEOBJ_H
#include "frameobj.h"
#endif

#ifndef __WPSDOC_H
//#include "wpsdoc.h"
#endif

#ifndef __PAGEOP_H
//#include "pageop.h"
#endif

#ifndef __FORMABC_H
#include "formabc.h"
#endif

#ifndef __OBJTOOL_H
//#include "objtool.h"
#endif
//#include "MainFrm.h"
#include "FormBracket.h"

#ifndef _WPSREADER
//#include "FormBracketDlg.h"
#endif

extern int GetFS(int ndx);
extern void DrawHalftoneRect(CDC* pDC, CRect& rc);
extern void ChangeFS(int nFS[4], int nCharMrg);
extern void RefreshFS();
extern void SaveFS();
extern int nTempFS[4];

/*-----------------------------
���´�������"����ʽ"�� 
------------------------------*/
//IMPLEMENT_SERIAL(CFormEquation, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CFormEquation, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CFormEquation::CFormEquation()
{                      
}

CFormEquation::~CFormEquation()
{
	ASSERT(this);
	DeleteContent();
}

void CFormEquation::DeleteContent()
{
	for (int i = 0; i < m_objArray.GetSize(); i++)	//	ע��m_objArray�ڶ�̬�仯
		delete m_objArray[i];
	m_objArray.RemoveAll();
}      



//	nR, nC��ʾ��������кţ���1��ʼ




void CFormEquation::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CFormEquation::Serialize_98(KSArchive& ar)
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar.Write(&m_nR, sizeof(int));
		ar.Write(&m_nC, sizeof(int));
		ar.Write(&m_nHAlign, sizeof(int));
		ar.Write(&m_nVAlign, sizeof(int));
		ar.Write(&m_nBracket, sizeof(int));
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar.Read(&m_nR, sizeof(int));
		ar.Read(&m_nC, sizeof(int));
		ar.Read(&m_nHAlign, sizeof(int));
		ar.Read(&m_nVAlign, sizeof(int));
		ar.Read(&m_nBracket, sizeof(int));
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n = 0; n < m_nR*m_nC; n++)
		{
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj(this);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CFormEquation::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar.Write(&m_nR, sizeof(int));
		ar.Write(&m_nC, sizeof(int));
		ar.Write(&m_nHAlign, sizeof(int));
		ar.Write(&m_nVAlign, sizeof(int));
		ar.Write(&m_nBracket, sizeof(int));
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar.Read(&m_nR, sizeof(int));
		ar.Read(&m_nC, sizeof(int));
		ar.Read(&m_nHAlign, sizeof(int));
		ar.Read(&m_nVAlign, sizeof(int));
		ar.Read(&m_nBracket, sizeof(int));
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n = 0; n < m_nR*m_nC; n++)
		{
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj(this);
		}
	}
	CWPSObj::SerializeObjType(ar);
}




/*-----------------------------
���´�������"ԭ�ӽṹͼ"�� 
------------------------------*/
//IMPLEMENT_SERIAL(CAtomConstruMap, CFormCell, 98 | VERSIONABLE_SCHEMA | 0x0100)
IMPLEMENT_SERIAL(CAtomConstruMap, CFormCell, 0xA0 | VERSIONABLE_SCHEMA | 0x0100)

CAtomConstruMap::CAtomConstruMap()
{                      
}

CAtomConstruMap::~CAtomConstruMap()
{
	ASSERT(this);
	DeleteContent();
}

void CAtomConstruMap::DeleteContent()
{
	for (int i = 0; i < m_objArray.GetSize(); i++)	//	ע��m_objArray�ڶ�̬�仯
		delete m_objArray[i];
	m_objArray.RemoveAll();
}      



//	nR, nC��ʾ��������кţ���1��ʼ


#ifndef _WPSREADER
//	�������캯��


#endif
/*void CAtomConstruMap::OpenObjDlg(CWpsView* pView)//�����ԶԻ���
{
	CAtomConMapDlg Dlg;
	Dlg.m_MapLayer=m_nLayerNum;
	Dlg.m_MapAngle = m_nWrapAngle;
	if (Dlg.DoModal()==IDOK)
	{
		m_nWrapAngle = Dlg.m_MapAngle;
	}

}//�������Ƶ�FormView.cpp
*/
void CAtomConstruMap::Serialize_97(KSArchive& ar)
{
	ASSERT(FALSE);
}     

void CAtomConstruMap::Serialize_98(KSArchive& ar)
{
	CFormCell::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nLayerNum;
		ar << m_nWrapAngle;
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_nLayerNum;
	    ar >> m_nWrapAngle;
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n = 0; n < m_nLayerNum; n++)
		{	
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj(this);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

void CAtomConstruMap::Serialize_01(KSArchive& ar)
{
	CFormCell::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nLayerNum;
		ar << m_nWrapAngle;
		m_objArray.Serialize(ar);
	}
	else
#endif	// #ifndef _WPSREADER
	{	
		ar >> m_nLayerNum;
	    ar >> m_nWrapAngle;
		m_objArray.Serialize(ar);
		CWPSObj* pObj;
		for (int n = 0; n < m_nLayerNum; n++)
		{	
			pObj = (CWPSObj*)m_objArray[n];
			pObj->SetMstObj(this);
		}
	}
	CWPSObj::SerializeObjType(ar);
}

