/* -------------------------------------------------------------------------
//	�ļ���		��	io/mfc/fileadpt.h
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-18 10:28:30
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __IO_MFC_FILEADPT_H__
#define __IO_MFC_FILEADPT_H__

#if defined(__Disable_All_MFC_File_Adapter)
#define __Disable_CFile_Adapter
#define __Disable_CArchive_Adapter
#endif

// =========================================================================

#if !defined(__Disable_CFile_Adapter)

inline STDMETHODIMP _ioSeekFile(CFile* pFile, FILEOFF lOff, int from)
{
	try
	{
		pFile->Seek(lOff, from);
		return S_OK;
	}
	catch(...)
	{
		return E_FAIL;
	}
};

inline STDMETHODIMP_(UINT) _ioReadFile(CFile* pFile, LPVOID pData, UINT nMax)
{
	return pFile->Read(pData, nMax);
}

inline STDMETHODIMP_(UINT) _ioWriteFile(CFile* pFile, LPCVOID pData, UINT nMax)
{
	pFile->Write(pData, nMax);
	return nMax;
}

inline STDMETHODIMP_(FILEOFF) _ioGetOffset(CFile* pFile)
{
	return pFile->GetPosition();
}

inline STDMETHODIMP_(void) _ioFlush(CFile* pFile)
{
	pFile->Flush();
}

#endif // !defined(__Disable_CFile_Adapter)

// =========================================================================

#if !defined(__Disable_CArchive_Adapter)

inline
STDMETHODIMP _ioSeekFile(CArchive* pFile, FILEOFF lOff, int from)
{
	ASSERT(lOff >= 0 && from == SEEK_CUR);	// ֻ֧��������!
	if (lOff > 0)
	{
		BYTE* pBuf = new BYTE[lOff];
		pFile->Read(pBuf, lOff);
		delete[] pBuf;
	}
	return S_OK;
}

inline STDMETHODIMP_(UINT) _ioReadFile(CArchive* pFile, LPVOID pData, UINT nMax)
{
	return pFile->Read(pData, nMax);
}

inline STDMETHODIMP_(UINT) _ioWriteFile(CArchive* pFile, LPCVOID pData, UINT nMax)
{
	pFile->Write(pData, nMax);
	return nMax;
}

/*******
inline STDMETHODIMP_(FILEOFF) _ioGetOffset(CArchive* pFile)
{
	REPORT_ONCE("NotImpl");
}
******/

inline STDMETHODIMP_(void) _ioFlush(CArchive* pFile)
{
	pFile->Flush();
}

#endif // !defined(__Disable_CArchive_Adapter)

// =========================================================================

#endif /* __IO_MFC_FILEADPT_H__ */
