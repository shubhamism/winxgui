//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainCheckBox.cpp
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-5-24 9:32:17
//	FileDescription	:	
//
//////////////////////////////////////////////////////////////////////////////////////


// KSDomainCheckBox.cpp: implementation of the KSDomainCheckBox class.
///////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "KSDomainCheckBox.h"

#ifndef __WPSOBJ_H
	#include "Wpsobj.h"
#endif
#ifndef __PTOBJ_H
	#include "Ptobj.h"
#endif



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(KSDomainCheckBox,CRectObj,0xA0 | VERSIONABLE_SCHEMA)

KSDomainCheckBox::KSDomainCheckBox()
{
}

KSDomainCheckBox::~KSDomainCheckBox()
{
	ASSERT_VALID(this);
}

/*
KSDomainCheckBox::KSDomainCheckBox(const CWpsDoc* pDoc, const CRect& rect)
									:CRectObj(pDoc,rect,NULL)
{
	m_bSelect = FALSE;	
	m_bDrawFlag = FALSE;
	m_bBackGround = FALSE;
}
*/


KSDomainCheckBox::KSDomainCheckBox(const KSDomainCheckBox* obj)
{
	ASSERT_VALID(obj);
//	CopyObj(obj,TRUE);
	m_bSelect = FALSE;
	m_bDrawFlag = FALSE;
	m_bBackGround = FALSE;
}


void KSDomainCheckBox::Serialize_01(KSArchive& ar)
 {
	 CRectObj::Serialize_01(ar);

	 if (ar.IsStoring())
	 {
		 ar << m_bSelect;
		 ar << m_bDrawFlag;
		 ar << m_bBackGround;
	 }

	 else
	 {
		 ar >> m_bSelect;
	     ar >> m_bDrawFlag;
		 ar >> m_bBackGround;
	 }

	 CWPSObj::SerializeObjType(ar);
}