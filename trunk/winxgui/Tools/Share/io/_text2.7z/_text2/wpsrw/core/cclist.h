/* -------------------------------------------------------------------------
//	�ļ���		��	cclist.h
//	������		��	���
//	����ʱ��	��	2002-5-27 16:43:09
//	��������	��	
//
//-----------------------------------------------------------------------*/
#ifndef __CCLIST_H__
#define __CCLIST_H__

#include "ctrlcode.h"

struct _CoSaveArg
{
	KSArchive*	pAr;
};

typedef CCtrlCode* (*fpConcreate)(WORD sprm, WORD* pData, UINT cw);
typedef HRESULT (CCtrlCode::*fpSave)(IAppendBuffer*, _CoSaveArg* pArg);

CCtrlCode* CoCreate_CtrlCode(WORD sprm, WORD* pData, UINT cw, sprmCtrlAid::KNestedSprmList&	nest);
HRESULT CoSave_CtrlCode(CCtrlCode* pcc, IAppendBuffer* pBuf, _CoSaveArg* pArg);

#endif /* __CCLIST_H__ */
