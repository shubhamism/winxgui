/** @file wppfileiden.cpp
 *  @brief
 *
 *  shaogaoyang@kingsoft.net, 05 Apr 2005
 *  Time-stamp: <2005-04-05 17:38:30 shaogaoyang>
 */

#include "stdafx.h"

#if defined(WPP_ONLY)

#include <pres/wppdoc.h>

// -------------------------------------------------------------------------

#define defWPPHEADSIZE		1024

int WPP_IdentifyFileType(LPCTSTR lpszFileName, LPTSTR lParam)
{
	ASSERT(lParam == NULL);

	// {{ ---> wps2002-io-extension, old version IdentifyFiltType, by tsingbo
	if (IsWPP2002File(lpszFileName))
	{
		return CWPPDoc::enWPP_WPPFile;
	}

	CFile file;
	CFileException e;
	if (!file.Open(lpszFileName, CFile::modeRead|CFile::shareDenyNone, &e))
	{
		return CWPPDoc::enWPP_UnknownFile;//enWPP_ErrorFile;
	}

	TCHAR g_szWPPHead[defWPPHEADSIZE + 1];
	int nReadSize = file.Read(g_szWPPHead, defWPPHEADSIZE);
	file.Close();
	if (!nReadSize)
		return CWPPDoc::enWPP_UnknownFile;

	//Kingsoftϵ���ļ������ж� -- start
	WPPFILEHEADER* pWPPHdr;
	if (nReadSize >= sizeof (WPPFILEHEADER) * sizeof(TCHAR))
	{
		// �����Ƿ�ΪWPSϵͳ�ļ�(WPP��WPS2001ϵͳ���ļ�����������"WPS"��ͷ)
		WORD wVer = *(WORD*)g_szWPPHead;
		if (memcmp((LPCTSTR)g_szWPPHead + 2, "WPS", 3) == 0)
		{
			//WPP�ļ����� -- start
			if (wVer >= VER_WINWPS_WPP00 && wVer <= VER_WINWPS_WPPLATEST)
			{
				pWPPHdr = (WPPFILEHEADER*)g_szWPPHead; // WPP�ļ�ͷ
				if (pWPPHdr->wfhTemplateInfo)
				{
					return CWPPDoc::enWPP_DPTFile;	//ģ���ļ�
				}
				else if (pWPPHdr->wfhAutoSaveInfo)
				{
					return CWPPDoc::enWPP_DASFile;	//�Զ������ļ�
				}
				else if (pWPPHdr->wfhVersion < VER_WINWPS_WPPLATEST)
				{
					return CWPPDoc::enWPP_WPPFile;//enWPP_OldWPPFile;
				}
				else
				{
					return CWPPDoc::enWPP_WPPFile; //���°汾���ļ�
				}
			}
			//WPP�ļ����� -- end
		}
	}
	//Kingsoftϵ���ļ������ж� -- end
	return CWPPDoc::enWPP_UnknownFile; //WPP_IdentifyFileType_ByExt(lpszFileName);
}

#endif // WPP_ONLY

