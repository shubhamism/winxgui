/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_dataptr.h
//	������		��	����
//	����ʱ��	��	2004-10-26 3:28:24 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __AUTONUM_DATAPTR_H__
#define __AUTONUM_DATAPTR_H__

// -------------------------------------------------------------------------

template<class strDATA, class KContainer>
class _KAutoNumDataPtr
{
private:
	strDATA*				m_pData;
	KContainer*				m_pDataContainer;

	// constructor/deconstructor
public:
	_KAutoNumDataPtr()
					:m_uRef(1),
					m_pData(NULL), 
					m_pDataContainer(NULL)
	{
	}

	_KAutoNumDataPtr(strDATA* pData, 
					KContainer* pContainer)
					: m_uRef(1), 
					m_pData(pData), 
					m_pDataContainer(pContainer)
	{
		// pData's memory must be alloced by "new"
		ASSERT(m_pData);
	}
	~_KAutoNumDataPtr()
	{
		if (m_pDataContainer)
		{
			m_pDataContainer->remove(this);
		}
		if (m_pData)
			delete m_pData;
	}
public:
/*	//@@ appendix
	BOOL Attach(strDATA* pData, KContainer* pContainer)
	{
		if (!m_pData && !m_pDataContainer)
		{
			m_pData				= pData;
			m_pDataContainer	= pContainer;
			return TRUE;
		}
		return FALSE;
	}
*/	//@@ appendix
	void Retire(BOOL bRemove = TRUE)
	{
		ASSERT(m_pData);
		if (m_pDataContainer && bRemove)
			m_pDataContainer->remove(this);
		m_pDataContainer	= NULL;
	}

/*	//@@ appendix
private:
	// disable!!!
	_KAutoNumDataPtr(const _KAutoNumDataPtr& p)
	{
		ASSERT(0);
	}
	const _KAutoNumDataPtr& operator=(const _KAutoNumDataPtr& p)
	{
		ASSERT(0);
	}
	BOOL operator==(const _KAutoNumDataPtr& p)
	{
		ASSERT(0);
	}
*/	//@@ appendix

public:
	operator strDATA*()
	{
		return m_pData;
	}
	KContainer* GetContainer()
	{
		return m_pDataContainer;
	}
 	operator int() const
 	{
		return (int)((void*)(m_pData))
 	}
	BOOL operator !() const
	{
		return (m_pData == NULL || m_pDataContainer == NULL);
	}

	// ref count
private:
	ULONG	m_uRef;
public:
	#ifdef _DEBUG
		ULONG GetRefCount() const
		{ return m_uRef; }
	#endif // _DEBUG

	ULONG AddRef()
	{
		return ++m_uRef;
	}
	ULONG Release()
	{
		if (--m_uRef)
			return m_uRef;
		delete this;
		return 0;
	}
};

template<class Ptr>
class _KAutoNumSmartPtr
{
public:
	_KAutoNumSmartPtr() : m_pPtr(NULL)
	{
	}
	_KAutoNumSmartPtr(Ptr* pPtr) : m_pPtr(pPtr)
	{
		if (m_pPtr)
			m_pPtr->AddRef();
	}
	_KAutoNumSmartPtr(const _KAutoNumSmartPtr& data)
	{
		Ptr* pData	= NULL;

		//ĳЩ����³����˿�����ָ�� bug3967 [wxb 2002-11-14]
		if (NULL != *((LPDWORD)(&data)))
			pData = (Ptr*)(const_cast<_KAutoNumSmartPtr&>(data));
		m_pPtr		= pData;
		if (m_pPtr)
			m_pPtr->AddRef();
	}
	~_KAutoNumSmartPtr()
	{
		ReleaseMe();
	}
public:
	void ReleaseMe()
	{
		if (m_pPtr)
		{
			Ptr* pOld	= m_pPtr;
			m_pPtr		= NULL;
			pOld->Release();
		}
	}
	operator Ptr*()
	{
		return m_pPtr;
	}
	Ptr& operator*()
	{
		ASSERT(m_pPtr);
		return *m_pPtr;
	}
	Ptr** operator&()
	{
		ASSERT(m_pPtr);
		return &m_pPtr;
	}
	Ptr* operator->()
	{
		ASSERT(m_pPtr);
		return m_pPtr;
	}
	const _KAutoNumSmartPtr& operator=(const _KAutoNumSmartPtr& data)
	{
		Ptr* pData = NULL;

		//ĳЩ����³����˿�����ָ�� bug3967 [wxb 2002-11-14]
		if (NULL != *((LPDWORD)(&data)))
			pData	= (Ptr*)(const_cast<_KAutoNumSmartPtr&>(data));
		if (m_pPtr != pData)
		{
			Ptr* pOld	= m_pPtr;
			m_pPtr		= pData;
			if (m_pPtr != NULL)
				m_pPtr->AddRef();
			if (pOld)
				pOld->Release();
		}
		return *this;
	}
	Ptr* operator=(Ptr* pPtr)
	{
		if (m_pPtr != pPtr)
		{
			Ptr* pOld	= m_pPtr;
			m_pPtr		= pPtr;
			if (m_pPtr != NULL)
				m_pPtr->AddRef();
			if (pOld)
				pOld->Release();
		}
		return m_pPtr;
	}
	BOOL operator==(const _KAutoNumSmartPtr<Ptr>& SP)
	{
		Ptr* pData	= (Ptr*)(const_cast<_KAutoNumSmartPtr&>(SP));
		return (m_pPtr == pData);
	}
	BOOL operator!=(const _KAutoNumSmartPtr<Ptr>& SP)
	{
		// return !(*this == SP); // ע��*��������
		Ptr* pData	= (Ptr*)(const_cast<_KAutoNumSmartPtr&>(SP));
		return (m_pPtr != pData);
	}
	BOOL operator!()
	{
		return (NULL == m_pPtr) ? TRUE : FALSE;
	}
	operator int() const
	{	// ���less����,����ɸ�����map֮key�Ĳ���
		return (int)((void*)m_pPtr);
	}
private:
	Ptr*	m_pPtr;
};

#pragma warning(disable:4786)
#include <stl/list.h>

#ifndef __AUTONUM_DECLARE_H
	#include "autonum_declare.h"		// ��������
#endif // __AUTONUM_DECLARE_H

// -------------------------------------------------------------------------

/////////////////////////////////////////////////////////
//// ���¶���group��atom��һЩ����
// 1.	��KAutoNumAtomSPtrȡ��Ӧ��AUTONUMATOM*
tagAUTONUMATOM* GetAtom_FromAtomSPtr(const KAutoNumAtomSPtr& spAtom);
#define GETATOM_FROMATOMSPTR(spAtom)				const_cast<const tagAUTONUMATOM*>(GetAtom_FromAtomSPtr(spAtom))

// 2.	��KAutoNumGroupSPtrȡ��Ӧ��AUTONUMGROUP*
tagAUTONUMGROUP* GetGroup_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup);
#define GETGROUP_FROMGROUPSPTR(spGroup)				const_cast<const tagAUTONUMGROUP*>(GetGroup_FromGroupSPtr(spGroup))

// 3.	��KAutoNumGroupSPtrȡ��Ӧ��KAutoNumAtomSPtr
KAutoNumAtomSPtr GetAtomSPtr_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup, int nLevel);
#define GETATOMSPTR_FROMGROUPSPTR(spGroup, nLevel)	GetAtomSPtr_FromGroupSPtr(spGroup, nLevel)

// 4.	��KAutoNumGroupSPtrȡĳ��level��KAutoNumAtomPtr*,���Ƽ�ʹ��
KAutoNumAtomPtr* GetAtomPtr_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup, int nLevel);
#define GETATOMPTR_FROMGROUPSPTR(spGroup, nLevel)	GetAtomPtr_FromGroupSPtr(spGroup, nLevel)

// 5.	��KAutoNumGroupSPtrȡĳ��level��AUTONUMATOM*
tagAUTONUMATOM* GetAtom_FromGroupSPtr(const KAutoNumGroupSPtr& spGroup, int nLevel);
#define GETATOM_FROMGROUPSPTR(spGroup, nLevel)		const_cast<const tagAUTONUMATOM*>(GetAtom_FromGroupSPtr(spGroup, nLevel))

#endif /* __AUTONUM_DATAPTR_H__ */
