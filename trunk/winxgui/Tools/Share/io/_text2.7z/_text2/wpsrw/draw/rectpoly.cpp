// rectpoly.cpp: implementation of the CRectPoly class.
// xu add
//////////////////////////////////////////////////////////////////////

/************************************
  REVISION LOG ENTRY
  Revision By: LHY(LiHongyi) contact with me: lhy@kingsoft.net OICQ: 511345
  Revised on 2001-4-28 17:54:31
  Revised Mark: <�޸������Լ���Cursor������WinMEϵͳ�µĴ����MFC��BUG>
  Comments: ...
 ************************************/


#include "stdafx.h"

#include "ptobj.h"
#include "Rectpoly.h"
#ifndef _INC_MATH
#include "math.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//IMPLEMENT_SERIAL(CRectPoly, CPTObj, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CRectPoly, CPTObj, 0xA0 | VERSIONABLE_SCHEMA)

CRectPoly::CRectPoly()
{
}

CRectPoly::~CRectPoly()
{
}

CRectPoly::CRectPoly(const CWpsDoc* pDoc, const CRect& position)
		   : CPTObj()
{
	SetWPSObjType(RECTPoly);
	SetEndStyle(ES_Close);
	m_nScale = 100;
	m_nNum = 5;
	m_bLinkTop = 0;
	m_bLinkMid = 0;
}

void CRectPoly::Serialize_98(CArchive& ar)
{
  ASSERT_VALID(this);
	CPTObj::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nNum << m_nScale ;	 
		ar << (UINT)m_bLinkTop << (UINT)m_bLinkMid;		 
	}
	else
#endif	// #ifndef _WPSREADER
	{
		UINT temp;
		ar >> m_nNum >>m_nScale;		
 		ar >> temp;	m_bLinkTop = temp;
		ar >> temp;	m_bLinkMid = temp;
		//	����ؽڼ���
		CalcScalePoint();
	}
	CWPSObj::SerializeObjType(ar);
}

void CRectPoly::Serialize_01(KSArchive& ar)
{
	ASSERT_VALID(this);
	CPTObj::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	
		ar << m_nNum << m_nScale ;		
		ar << (UINT)m_bLinkTop << (UINT)m_bLinkMid;		 
	}
	else
#endif	// #ifndef _WPSREADER
	{
		UINT temp;
		ar >> m_nNum >>m_nScale;		
 		ar >> temp;	m_bLinkTop = temp;	
		ar >> temp;	m_bLinkMid = temp;	
		//	����ؽڼ���
		CalcScalePoint();
	}
	CWPSObj::SerializeObjType(ar);
}


void CRectPoly::CalcScalePoint()
{
	CRect rct = m_rect;
	m_centerPoint.x = (rct.left + rct.right) / 2;
	m_centerPoint.y = (rct.top + rct.bottom) / 2;

	int a,b;	//��Բ�ĳ��̰��ᡣ
	a = abs(rct.right - rct.left) / 2;
	b =	abs(rct.bottom - rct.top) / 2;
	double angle = 2 * PI / m_nNum;
	CPoint p0, p1;

	p0.x = m_centerPoint.x + (LONG)(a * cos(-PI / 2));
	p0.y = m_centerPoint.y + (LONG)(b * sin(-PI / 2));
	p1.x = m_centerPoint.x + (LONG)(a * cos(angle - PI / 2));
	p1.y = m_centerPoint.y + (LONG)(b * sin(angle - PI / 2));
	m_firstCenterPoint.x = (p0.x + p1.x) / 2;
	m_firstCenterPoint.y = (p0.y + p1.y) / 2;

	m_scalePoint.x = m_centerPoint.x + MulDiv(m_nScale, (m_firstCenterPoint.x-m_centerPoint.x), 100);
	m_scalePoint.y = m_centerPoint.y + MulDiv(m_nScale, (m_firstCenterPoint.y-m_centerPoint.y), 100);
}
