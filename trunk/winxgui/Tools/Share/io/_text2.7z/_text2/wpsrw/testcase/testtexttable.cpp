/* -------------------------------------------------------------------------
//	�ļ���		��	testtexttable.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-4 10:36:11
//	��������	��	
//
//	$Id: testtexttable.cpp,v 1.1 2005/01/04 02:42:30 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestTextTable : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestTextTable);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestTextTable);

// -------------------------------------------------------------------------
//	$Log: testtexttable.cpp,v $
//	Revision 1.1  2005/01/04 02:42:30  xushiwei
//	*** empty log message ***
//	
