/* -------------------------------------------------------------------------
//	�ļ���		��	ex_textpool.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 16:51:00
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_wpsdoc.h"
#include "ex_textesc.h"

#include "../core/style_text.h"
#include "../core/stylesheet_text.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "char_code_helper.h"

// -------------------------------------------------------------------------

STDMETHODIMP_(void) AddContent(KWpsExport& export, const KSWPSTextString& ts)
{
	TEXTWORD lastChar = 0;
	KDWTextPool& textPool = export.GetCurSubdoc()->TextPool();
	LPCTEXTWORD pData = ts.GetData();
	CEscSeq_Export seq(pData + ts.GetTextSize(), export);
	while (pData < seq.m_pDataEnd)
	{
		if (*pData == VK_ESCAPE)
		{
			lastChar = 0;
			pData = seq.SCP_Escape(pData);
			ASSERT(
				pData <= seq.m_pDataEnd);
		}
		else
		{
			//wps�¿ո����ֻ��word�µ�һ�룬����wps�µ����������ո�תΪwordһ���ո�	
			if(*pData == __X(' ') && lastChar == __X(' '))
			{
				lastChar = 0;
				pData++;
				continue;
			}
			if (*pData == 0x0d)
			{
				ASSERT(FALSE);
				pData++;
				continue;
			}

			lastChar = *pData;

			if (lastChar == 0x80)
			{
				KDWPropx* pPreChpx = export.GetCurrentChpx();

				KDWPropBuffer ChpxSymbol;
				ChpxSymbol.AddProps(pPreChpx);

				UINT ftc = export.AddFont(__X("Times New Roman"));
				INT32 oprand = (INT16)ftc + (((INT16)0x20AC) << (sizeof(INT16) * 8));
				ChpxSymbol.AddPropFix(sprmCSymbol, oprand);
				export.NewSpan(&ChpxSymbol);
				textPool.append('\x28');
				pData++;

				KDWPropBuffer ChpxContinue;
				ChpxContinue.AddProps(pPreChpx);
				export.NewSpan(&ChpxContinue);
			}
			else
				textPool.append(*pData++);
		}
	}
}
STDMETHODIMP CSentence_Export::Export(CSentence_Content& pSenContent) const
{
	KWpsExport &export = (KWpsExport &)*(pSenContent.GetExport());
	KDWPropBuffer chpx;
	CP cpBefore = export.GetFcMax();

//	bSenHasFS = FALSE;	
	//	pCurSentence = (CSentence *)this;
	
	//����ʽ��
	if (m_dwStyleID != TSID_CHAR_DEFAULT)
		// Ϊ���д�if? ��WPS2003��Ŀ��CTextTool::GetStyleAttrib()�����ڵ�if
		// ����: ��WPS2003��, �����m_dwStyleID��ֵΪTSID_CHAR_DEFAULT, ���ֵ
		//		 �ᱻ����, ת���Ӿ����ڵĶ���������õ���ʽ
	{
		UINT uStyleID = export.AddStyle_Text(m_dwStyleID, (LPCTSTR)m_strStyleName);
		chpx.AddPropFix(sprmCIstd, uStyleID);
	}
	// ��������
	pSenContent.SetSenHasFS(FALSE);
	ChpxCtrlCode_Context ctrlcode(export);
	ctrlcode.SetSenContent((CSentence_Content *)&pSenContent);

	ctrlcode.ConvertChpx(m_pAttribList, chpx);
	
	//lijun ���������������ӵ�ȱʡ����
	if (pSenContent.GetSenHasFS() == FALSE)
	{		
		CStyle_Text *styleText = NULL;
		CCtrlCode_Size *pCodesize = NULL;
		DWORD dwID = m_dwStyleID;
		CString strStyleName = m_strStyleName;
		CStyleSheet_Text* pSheet_WPS = export.m_pDoc->GetStyleSheet_Text();
		while (dwID != 0)
		{
			styleText = (CStyle_Text *)pSheet_WPS->GetStyle(dwID, strStyleName);
			if (styleText == NULL)
			{
				break;
			}
			pCodesize = (CCtrlCode_Size *)styleText->GetCtrlCode(SETFONTSIZE);
			if ( pCodesize != NULL)
			{
				pSenContent.SetSenHasFS(TRUE);
				break;
			}
			else
			{
				dwID = styleText->GetBaseStyleID();
				strStyleName = styleText->GetBaseStyleName();
			}
		}
		if (pSenContent.GetSenHasFS() == FALSE)
		{
			CParagraph *pParagraph = ((CSentence *)this)->GetCurParagraph();
			dwID = pParagraph->m_dwStyleID;
			strStyleName = pParagraph->m_strStyleName;
			while(dwID != 0)
			{			
				styleText = (CStyle_Text *)pSheet_WPS->GetStyle(dwID, strStyleName);
				if (styleText == NULL)
				{
					break;
				}
				pCodesize = (CCtrlCode_Size *)styleText->GetCtrlCode(SETFONTSIZE);
				if (pCodesize != NULL)
				{
					pSenContent.SetSenHasFS(TRUE);
					break;
				}
				else
				{
					dwID = styleText->GetBaseStyleID();
					strStyleName = styleText->GetBaseStyleName();
				}
			}
		}
		if (pSenContent.GetSenHasFS() == FALSE)
			chpx.AddPropFix(sprmCHps, 21);
	}

	// WPSû�ж�Share�ַ������������ȫ������HintΪ1
	chpx.AddPropFix(sprmCIdctHint, 1);
/*	if (m_tsBuf.GetTextSize() > 0)
	{
		LPCTEXTWORD pData = m_tsBuf.GetData();
		DWORD dwLang = GetCharLang(pData[0]);
		if (IS_CJK_LANG(dwLang))
		{
			chpx.AddPropFix(sprmCIdctHint, 1);
		}
	}
*/
	// ʱ������! ������Convert֮��, NewSpan֮ǰ����HyperlinkProcessor
	export.HyperlinkProcessor(ctrlcode.GetHotRef());
	// ��������
	export.NewSpan(&chpx);
	//�����ĵ�һ����ת��ÿҳ��ҳ�����
	export.ExportPerPageObjs();
	//��ҳü��ת������ҳ/��żҳ�����
//	export.ExportAllPageObjs();

	//
	AddContent(export, m_tsBuf);

	// ʱ������! ������AddContent֮�����BookmarkProcessor
	CP cpAfter = export.GetFcMax();
	export.BookmarkProcessor(ctrlcode.GetBookMarkID(), cpBefore, cpAfter);
	return S_OK;
}

//��ʱ�İ취:����û��context
typedef std::vector<void*> _ParaVec;
_ParaVec _g_paraVec;
void* _gGetCurrentPara()
{
	return _g_paraVec.back();
}
// -------------------------------------------------------------------------
STDMETHODIMP CParagraph_Export::Export(CParagraph_Content& pParaContent) const
{
	KWpsExport &export = (KWpsExport &)*(pParaContent.GetExport());
	KDWPropBuffer papx;
	PapxCtrlCode_Context ctrlcode(export);
	
	//lijun
	ctrlcode.SetParContent((CParagraph_Content *)&pParaContent);
//	pCurParagraph = (CParagraph *)this;
	_g_paraVec.push_back((void*)this);
	//����ʽ��
	UINT uStyleID = export.AddStyle_Text(m_dwStyleID, (LPCTSTR)m_strStyleName);

	
	//�����ԣ�
	ctrlcode.ConvertPapx(uStyleID, m_pAttribList, papx);
	//��������е�ɫ,��ת��fdsafdasfds�˵�ɫ
	if (m_fBKColor == TRUE)
	{
//		papx.AddPropFix(sprmPShd, m_shdEx);
		papx.AddPropVar(sprmPShdEx, &m_shdEx, sizeof(m_shdEx));
	}
	ExportContent(pParaContent, papx);
	//�ڶ�֮��ת���ļ���εı���
	int nInlineTable = export.m_ParaTblVec.size();
	if(nInlineTable > 0 && export.m_pTableInPara == (void*)this)
	{
		KParagraphTableVector ParaTblVec = export.m_ParaTblVec;
		export.m_ParaTblVec.clear();
		export.m_pTableInPara = NULL;
		for(int i = 0; i < nInlineTable; i++)
		{
			if(i == nInlineTable - 1)
			{
				export.m_bLastInineTable = TRUE;
			}
			else
			{
				export.m_bLastInineTable = FALSE;
			}
			CShape_Context shape(export);
			shape.m_ParagraphTableFlag = ParaTblVec[i].flag;
			shape.Export((CAnchorObj*)ParaTblVec[i].pTableObj);
		}
		if(export.m_bNewPageAfterInlineTable)
		{
			export.m_bNewPageAfterInlineTable = FALSE;
			export.NewNullPapxParagraph();
			export.NewNullChpxSpan();
			const WCHAR chPage[] = { 0x0c, 0x0d };
			export.AddContent(chPage, 2);
		}
	}
	_g_paraVec.pop_back();
	return S_OK;
}

STDMETHODIMP CParagraph_Export::ExportContent(CParagraph_Content& pParaContent, KDWPropBuffer& papx) const
{
	KWpsExport &export = (KWpsExport &)*(pParaContent.GetExport());
	INT32& snTocItemCount = export.m_nTocItemCount;
	KTocParagraph* ptp = NULL;
	BOOL fLastItem = FALSE;
	KDWPropBuffer chpx;

	//Ŀ¼��Ŀ
	if(m_lSerialID < 0)
	{
		ptp = export.GetTocParagraph(-m_lSerialID);
		ASSERT(ptp);
		//�����Ʊ�λ
		INT16 dxa = export.m_nPageCoreWidth;//8296;
		TBD tbd;
		tbd.jc = mso_tbdRightTab;
		tbd.tlc = mso_tbdDottedLeader;
		tbd.reserved = 0;
		papx.AddTabStops(1, &dxa, &tbd);
		
	}
	//Ŀ¼��Ŀ���õĶ���
	else if(m_lSerialID > 0)
	{
		//����Ŀ¼���õĶ���Ĵ�ټ���
		KTocParagraph* ptp2;
		ptp2 = export.GetTocParagraph(m_lSerialID);
		if(ptp2 && ptp2->POutLvl < 9)
		{
			papx.AddPropFix(sprmPOutLvl, ptp2->POutLvl);
		}
	}
	export.NewParagraph(&papx);

	if(ptp)
	{
		//ͷ
		if(snTocItemCount == 0)
		{
			export.NewSpan(&chpx);
			export.MarkFieldBegin(mso_fltTOC, FALSE);// ��һ��field. type = 13
			// field code
			WCHAR szMsg[] = __X(" TOC \\o \"1-3\" \\h \\z \\u ");
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
			//
			export.MarkFieldSeparator();
		}
		snTocItemCount++;
		if(snTocItemCount >= export.m_TocParaVec.size())
		{
			fLastItem = TRUE;
		}
		//��Ŀ
		export.MarkFieldBegin(mso_fltHyperlink, FALSE);// �ڶ���field. type = 88
		// field code
		{
			WCHAR szMsg[] = __X(" ");
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
		}
		{
			WCHAR szFormat[] = __X("HYPERLINK \\l \"%s\"");
			WCHAR szMsg[64];
			swprintf(szMsg, szFormat, ptp->bookmarkName);
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
		}
		{
			WCHAR szMsg[] = __X(" ");
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
		}
		{
//			WCHAR szMsg[] = __X("\x01");
//			export.NewSpan(&chpx);
//			export.AddContent(szMsg, wcslen(szMsg));
		}
		export.MarkFieldSeparator();
	}
	{
		CreateTocParagraphBookmark(export);
		int nCount = NumOfSentences();
		ASSERT(nCount > 0);
		for (int i = 0; i < nCount; ++i)
		{
			CSentence_Export* pSent = (CSentence_Export*)GetSentence(i);
			ASSERT(pSent);
			pSent->SetCurParagraph((CParagraph *)this);
			CSentence_Content *pSenContent = new CSentence_Content();
			if (pSenContent == NULL)
				return E_FAIL;
			pSenContent->SetExport((KWpsExport *)&export);
			pSenContent->SetParagraph(pParaContent.GetParagraph());
			pSenContent->SetSentence((CSentence *)pSent);
			pSent->Export((CSentence_Content &)*pSenContent);

			delete pSenContent;
		}
	}
	if(ptp)
	{
		//����Ҫ���Ʊ�λ�ˣ���Ϊ����� pSent->Export(export) �Ѿ�������
//		{
//			WCHAR szMsg[] = __X("\x09");//'\t'
//			export.NewSpan(&chpx);
//			export.AddContent(szMsg, wcslen(szMsg));
//		}
		export.MarkFieldBegin(mso_fltPageRef, FALSE);// ������field. type = 37
		{
			WCHAR szFormat[] = __X("PAGEREF %s \\h");
			WCHAR szMsg[64];
			swprintf(szMsg, szFormat, ptp->bookmarkName);
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
		}
		{
			WCHAR szMsg[] = __X("\x01");
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
		}
		export.MarkFieldSeparator();
		{
			WCHAR szMsg[] = __X("?");
			export.NewSpan(&chpx);
			export.AddContent(szMsg, wcslen(szMsg));
		}
		export.MarkFieldEnd();//end mso_fltPageRef
		export.MarkFieldEnd();//end mso_fltHyperlink
	}
	{
		// WPS�ڶ�����������ϵ��޶��Ǳ����ڶ��������
		// ������Ҫ���޶����Լӵ��س����ľ�������
		if (m_nRevCount > 0)
		{
			REVISE_DATA* pPapRev = m_pReviseData;
			ASSERT(pPapRev);

			KDWPropBuffer chpx;
			KDWPropx* pCurChpx = export.GetCurrentChpx();

			if (pCurChpx)
				chpx.AddProps(pCurChpx);

			extern UINT ExportRevisionUser(KWpsExport& export, const REVISE_DATA* pData);
			extern void AddRevisionProp(const REVISE_DATA *pData, KDWPropBuffer& papx, UINT usrid);

			UINT uUserId = ExportRevisionUser(export, pPapRev);
			AddRevisionProp(pPapRev, chpx, uUserId);

			export.NewSpan(&chpx);
		}
		switch (m_paraEndCode & 0xffff)
		{
		case newparagraph:
			{
				if(export.m_ParaTblVec.size() == 0)
				{
					export.AddContent(0x0d);
				}
				else
				{
					KDWTextPool& textPool = export.GetCurSubdoc()->TextPool();
					if(!textPool.empty() && textPool.back() != 0x0d)
					{
						export.AddContent(0x0d);
					}
				}
			}
			break;
		case newpage:
			{
				if(export.m_ParaTblVec.size() > 0)//����˶��б���,����newpage����,���ڱ���ת�����newpage
				{
					export.m_bNewPageAfterInlineTable = TRUE;
					export.AddContent(0x0d);
				}
				else
				{
					const WCHAR chPage[] = { 0x0c, 0x0d };
					export.AddContent(chPage, 2);
				}
			}
			break;
		case newcolumn:
			//ASSERT(0); //@@todo
			//lijun
			export.AddContent(0x0e);
			break;
		case newsection:
			if (export.IsLastSection())//wps���һ���ڽ�����û��newsection��־,���Բ������
			{
				export.AddContent(0x0d);
			}
			else
			{
				CWpsDoc_Export* pDoc = (CWpsDoc_Export*)export.m_pDoc;
				export.AddContent(0x0c);
				pDoc->NewSection(export);
			}
			break;
		default:
			ASSERT(FALSE);
		}
	}
	if(ptp && fLastItem)
	{
		export.MarkFieldEnd();//end 13
	}

	return S_OK;
}
STDMETHODIMP CParagraph_Export::CreateTocParagraphBookmark(KWpsExport& export) const
{
	if(m_lSerialID <= 0)
		return S_OK;
	KTocParagraph* ptp;
	ptp = export.GetTocParagraph(m_lSerialID);

	// m_lSerialIDΪ��������Ŀ¼���õĶΣ��Ҳ���ptp��������
	if(ptp)
	{
		KDWBookmarks& bookmarks = export.GetBookmarks();//��ȡ�ĵ�����ǩ��
		CP cpBefore = export.GetFcMax();
		bookmarks.NewBookmark(ptp->bookmarkName/*��ǩ��*/, cpBefore, cpBefore);//�½���ǩ��
	}
	return S_OK;
}


// ����ָ���Ľ�ע/βע
// nFNID: ��ע/βע��ID
STDMETHODIMP CParagraph_Export::Export_FN(CParagraph_Content& pParaContent, const int nFNID) const
{
	if (GetFNID() == nFNID)
		Export(pParaContent);
	return S_OK;
}

STDMETHODIMP CTextPool_Export::Export(KWpsExport& export) const
{
	int nCount = NumOfParagraphs();

	for (int i = 0; i < nCount; ++i)
	{
		CParagraph_Export* pPara = (CParagraph_Export*)GetParagraph(i);
		ASSERT(pPara);
		
		CParagraph_Content *pContent = new CParagraph_Content();
		if (pContent == NULL)
			return E_FAIL;
		pContent->SetExport((KWpsExport *)&export);
		pContent->SetParagraph(pPara);

		pPara->Export((CParagraph_Content &)*pContent);

		delete pContent;
		pContent = NULL;
	}
	return S_OK;
}

// ����ָ���Ľ�ע/βע
// nFNID: ��ע/βע��ID
STDMETHODIMP CTextPool_Export::Export_FN(KWpsExport& export, const int nFNID) const
{
	int nCount = NumOfParagraphs();
	BOOL bStart = FALSE;
	for (int i = 0; i < nCount; ++i)
	{
		CParagraph_Export* pPara = (CParagraph_Export*)GetParagraph(i);
		ASSERT(pPara);

		CParagraph_Content *pContent = new CParagraph_Content();
		if (pContent == NULL)
			return E_FAIL;
		pContent->SetExport((KWpsExport *)&export);
		pContent->SetParagraph(pPara);

		pPara->Export_FN((CParagraph_Content &)*pContent, nFNID);
		
		//lijun 
		if (bStart == TRUE && pPara->GetFNID() == -1)	//����ĳ����ע/βע�س��������		
			pPara->Export((CParagraph_Content &)*pContent);		
		if (pPara->GetFNID() == nFNID)
			bStart = TRUE;
		else if (pPara->GetFNID() != -1 && bStart == TRUE)//�˽�ע/βע�س���������Ѿ��������
			break;
		delete pContent;
		pContent = NULL;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
