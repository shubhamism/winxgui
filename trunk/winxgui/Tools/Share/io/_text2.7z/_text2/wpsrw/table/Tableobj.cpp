/* -------------------------------------------------------------------------
//	�ļ���		��	frameimg.h
//	������		��	��־��
//	����ʱ��	��	2004-11-11 14:19
//	��������	��	����ʵ�֣���WPS��ת�ƹ���
//
// -----------------------------------------------------------------------*/
/////////////////////////////////////////////////////////////////////////////
//
// tableObj.cpp - implementation for CTableRowCol & CTableElement objects
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifndef __WPSDOC_H
#include "core/wpsdoc.h"
#endif

#include "draw/frametext.h"

#ifndef __WPSOBJ_H
#include "draw/wpsobj.h"
#endif

#ifndef __FRAMEOBJ_H
#include "draw/frameobj.h"
#endif

#ifndef __FRAMETBL_H
#include "frametbl.h"
#endif

#ifndef __TABLEOBJ_H
#include "tableobj.h"
#endif

#ifndef __PTOBJ_H
#include "draw/ptobj.h"
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
//	CTableRowCol
//IMPLEMENT_SERIAL(CTableRowCol, CWPSObj, 98 | VERSIONABLE_SCHEMA)
IMPLEMENT_SERIAL(CTableRowCol, CWPSObj, 0xA0 | VERSIONABLE_SCHEMA)

CTableRowCol::CTableRowCol()
{
}

CTableRowCol::~CTableRowCol()
{
	Elem.RemoveAll();
}

CTableRowCol::CTableRowCol(const CWpsDoc* pDoc, const CRect& rect)
	: CWPSObj(pDoc, rect)
{
	SetWPSObjType( TABLEROWCOLObj);
}

void CTableRowCol::Serialize_97( KSArchive& ar)
{
	CWPSObj::Serialize_97(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
#endif	// #ifndef _WPSREADER
	{
	}
	Elem.Serialize(ar);
	CWPSObj::SerializeObjType(ar);
}

void CTableRowCol::Serialize_98( KSArchive& ar)
{
	CWPSObj::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
	}
	else
#endif	// #ifndef _WPSREADER
	{
	}
	Elem.Serialize(ar);
	CWPSObj::SerializeObjType(ar);
}

void CTableRowCol::Serialize_01( KSArchive& ar)
{
	CWPSObj::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
	}
	else
#endif	// #ifndef _WPSREADER
	{
	}
	Elem.Serialize(ar);
	CWPSObj::SerializeObjType(ar);
}

void CTableRowCol::AddElemToArray( CTableElement* pElem) //keep
{
	Elem.Add(pElem);
	UnionSize(&pElem->m_rect);
}

void CTableRowCol::InsertElemToArray( int index, CTableElement* pElem) //keep
{
	Elem.InsertAt(index, pElem, 1);
	UnionSize(&pElem->m_rect);
}

#ifndef	_WPSREADER
UINT CTableRowCol::GetLPenSize(int id)
{
	UINT uS = (UINT)-1, uT;
	CTableElement* pElem;
	for ( int n=0; n<GetElemSize(); n++)
	{  	pElem = GetElem(n);
		uT = pElem->GetLPenSize( id);
		if ( uS == -1)			uS = uT;
		else if ( uS != uT) 	return 0;
	}
	return uS;
}
#endif	//_WPSREADER

#ifndef	_WPSREADER
COLORREF CTableRowCol::GetLPenColor(int id)
{
	BOOL	bSetClr = FALSE;
	COLORREF clr, clrT;
	CTableElement* pElem;
	for ( int n=0; n<GetElemSize(); n++)
	{  	pElem = GetElem(n);
		clrT = pElem->GetLPenColor( id);
		if ( !bSetClr)	{	clr = clrT;		bSetClr = TRUE;	}
		else if ( clr != clrT)	return (COLORREF)-1;
	}
	return clr;
}
#endif	//_WPSREADER

#ifndef	_WPSREADER
extern CSize elementMinWH;	//	��������С�����С����

void CTableRowCol::UnionSize(void)
{	
	CTableElement* pElem;
	m_rect.SetRectEmpty();
	for ( int n=0; n<GetElemSize(); n++)
	{
		pElem = GetElem(n);
    	m_rect.UnionRect(&m_rect,&pElem->m_rect);
	}
}
#endif

#ifndef	_WPSREADER
void CTableRowCol::RemoveElem(CTableElement *pElem)
{
	for(int n=0;n<GetElemSize();n++)
	{
		if (pElem==GetElem(n))
		{
			RemoveAt(n,1);
			return;
		}
	}
}
#endif	//_WPSREADER

int	CTableRowCol::GetElemIndex( CTableElement* pElem)
{
	for ( int i=0; i<GetElemSize(); i++)
	{	if ( GetElem(i) == pElem)
			return i;
	}
	ASSERT( FALSE);
	return -1;
}

#ifndef	_WPSREADER
void CTableRowCol::MoveRow( int zoomH)
{
	CTableElement* pElem;
	for ( int n=0; n<GetElemSize(); n++)
	{	//	�ƶ�������Ԫ��
		pElem = (CTableElement*)Elem[n];
		pElem->m_rect.OffsetRect( 0, zoomH);
	}
	//	�ƶ�����
	UnionSize();
}
#endif	//_WPSREADER