/* -------------------------------------------------------------------------
//	�ļ���		��	ptltxt.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-25 12:34:34
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ptobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern TCHAR szDefCFontName[];
extern TCHAR szDefEFontName[];
extern char szFontSize[33][50];	 //�ֺ�����

void ReadProp(CObList* pList, KSArchive& ar);
void WriteProp(CObList* pList, KSArchive& ar);

// CLtxtObj
IMPLEMENT_SERIAL(CLtxtObj, CPTObj, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)

/**********************************************************************
���ܣ�	�ɸ������ֺ����ݣ�ת�����ֺ��ַ���
��ڣ�	fs: �����ֺ�����
���ڣ�	lpszFontSize�����ַ�������ʽ�����ֺţ���"���"��"12"
�Ƚϣ�	GetFontSize()
**********************************************************************/
extern DWORD glCodePage;
void GetFontSizeString(LPTSTR lpszFontSize, FONTSIZE& fs)
{
	ASSERT(lpszFontSize);
	*lpszFontSize = 0;
	
	WORD wSizeUnit = fs.nfsUnit;
	int  nSize = fs.nfsSize;
	if (!wSizeUnit && !nSize)
		return;
	
	if (wSizeUnit==FSU_SIZE)
	{	// ������ֺ�Ϊ��λ����ʾ...
		nSize = max (nSize,  0);
		nSize = min (nSize, 14);	// 0�ŵ�С7�Ź�14���ֺ�
		lstrcpy(lpszFontSize, szFontSize[nSize]);
	}
	else if (wSizeUnit==FSU_POUND)
	{
		// ����԰�Ϊ��λ����ʾ...
		nSize = max (nSize, FS_MINPOUND);		// ��С�ֺ�
		nSize = min (nSize, FS_MAXPOUND);		// ����ֺ�
		wsprintf (lpszFontSize, "%d", nSize);
		if (15 == nSize && 936 == glCodePage)
		{
			CString str = "С��";
			lstrcpy(lpszFontSize, str);
		}
	}
#ifdef _DEBUG
	else
		ASSERT(FALSE);
#endif
}

// -------------------------------------------------------------------------
// Ϊ�������İ���WPS OFFICE�ļ����ԣ����˸����Ӳ��õİ취����Ԫ�����ְ�ʽ����
// ���������������ɴ�ӡ�ַ�,���ڱ�Ԫ�ַ���֮��Ĭ������֮ǰ(����)
#define TBLELEM_TEXT_LINEMODE_HORZ		((TEXTWORD)(0x01))
#define TBLELEM_TEXT_LINEMODE_VERTL2R	((TEXTWORD)(0x02))
#define TBLELEM_TEXT_LINEMODE_VERTR2L	((TEXTWORD)(0x03))
void MakeTBLELEM_LineMode(KSTextString& strText, TextLineMode lm)
{
	int nLen = strText.GetTextSize();
	// ��δ���,���ǰ������ı�־
	if ((nLen > 0) && (strText[nLen - 1] >= TBLELEM_TEXT_LINEMODE_HORZ) &&
		(strText[nLen - 1] <= TBLELEM_TEXT_LINEMODE_VERTR2L))
		strText.Delete(nLen - 1);
	if (lm == horz)
		strText += TBLELEM_TEXT_LINEMODE_HORZ;
	else if (lm == vertl2r)
		strText += TBLELEM_TEXT_LINEMODE_VERTL2R;
	else
	{
		ASSERT(lm == vertr2l);
		strText += TBLELEM_TEXT_LINEMODE_VERTR2L;
	}
}

// -------------------------------------------------------------------------

TextLineMode ParseTBLELEM_LineMode(KSTextString& strText)
{
	TextLineMode lm		= horz;
	int nLen = strText.GetTextSize();
	if (nLen > 0)
	{
		TEXTWORD tw	= strText[nLen - 1];
		if (tw == TBLELEM_TEXT_LINEMODE_HORZ)
			lm	= horz;
		else if (tw == TBLELEM_TEXT_LINEMODE_VERTL2R)
			lm = vertl2r;
		else if (tw == TBLELEM_TEXT_LINEMODE_VERTR2L)
			lm = vertr2l;
		else
			return horz;

		strText.Delete(nLen - 1);
	}

	return lm;
}

// -------------------------------------------------------------------------

void CLtxtObj::Serialize_97(CArchive& ar)
{
	CPTObj::Serialize_97(ar);
	const UINT uFontNameSize	= FS_NAMESIZE_SERIALIZE;	// ������ʷԭ��������ݱ�ΪFS_NAMESIZE_SERIALIZE == 10

	if (ar.IsStoring())
	{	// Cannot saved as a WPS97 file.
		ASSERT(FALSE);
	}
	else
	{
		DWORD dwTemp;
		__int16 wTemp;

		CString strTemp;
		ar >> strTemp;

		//˫�ֽ�CString��KSTextString��ת��
		LPCTSTR lpszOld = (LPCTSTR)strTemp;
		int nStrLen;
		for (nStrLen = 0; lpszOld[nStrLen]; nStrLen += 2)
			;
		nStrLen = nStrLen / 2;//˫�ֽ��ַ���

		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		VERIFY(nStrLen == KCP_WordToTextWord(lptwBuffer,
				(LPWORD)(LPCTSTR)strTemp, nStrLen));
		m_string.Insert(0, lptwBuffer, nStrLen);
		delete lptwBuffer;
		//end ˫�ֽ�CString��KSTextString��ת��

		ar >> dwTemp;	m_stringColor = (DWORD)dwTemp;
		ar >> wTemp;	m_nAspectX = (int)wTemp;
		ar >> wTemp;	m_nCharMrg = (int)wTemp;
		ar >> wTemp;	m_nAlig    = (WORD)wTemp;

		BYTE bTemp;
		ar >> wTemp;	m_lfChn.lfHeight = wTemp;
		ar >> wTemp;	m_lfChn.lfWidth = wTemp;
		ar >> wTemp;	m_lfChn.lfEscapement = wTemp;
		ar >> wTemp;	m_lfChn.lfOrientation = wTemp;
		ar >> wTemp;	m_lfChn.lfWeight = wTemp;
		ar >> bTemp;	m_lfChn.lfItalic = bTemp;
		ar >> bTemp;	m_lfChn.lfUnderline = bTemp;
		ar >> bTemp;	m_lfChn.lfStrikeOut = bTemp;
						m_lfChn.lfStrikeOut = CC_DISABLED;	//	98����
		ar >> bTemp;	m_lfChn.lfCharSet = bTemp;
		ar >> bTemp;	m_lfChn.lfOutPrecision = bTemp;
		ar >> bTemp;	m_lfChn.lfClipPrecision = bTemp;
		ar >> bTemp;	m_lfChn.lfQuality = bTemp;
		ar >> bTemp;	m_lfChn.lfPitchAndFamily = bTemp;
		ar.Read(m_lfChn.lfFaceName, LF_FACESIZE*sizeof(char));

		ar >> wTemp;	m_lfEng.lfHeight = wTemp;
		ar >> wTemp;	m_lfEng.lfWidth = wTemp;
		ar >> wTemp;	m_lfEng.lfEscapement = wTemp;
		ar >> wTemp;	m_lfEng.lfOrientation = wTemp;
		ar >> wTemp;	m_lfEng.lfWeight = wTemp;
		ar >> bTemp;	m_lfEng.lfItalic = bTemp;
		ar >> bTemp;	m_lfEng.lfUnderline = bTemp;
		ar >> bTemp;	m_lfEng.lfStrikeOut = bTemp;
						m_lfEng.lfStrikeOut = CC_DISABLED;	//	98����
		ar >> bTemp;	m_lfEng.lfCharSet = bTemp;
		ar >> bTemp;	m_lfEng.lfOutPrecision = bTemp;
		ar >> bTemp;	m_lfEng.lfClipPrecision = bTemp;
		ar >> bTemp;	m_lfEng.lfQuality = bTemp;
		ar >> bTemp;	m_lfEng.lfPitchAndFamily = bTemp;
		ar.Read(m_lfEng.lfFaceName, LF_FACESIZE*sizeof(char));

		ar.Read(m_szFSname, uFontNameSize * sizeof(char));
		ar >> wTemp;	m_nFSsize = (int)wTemp;
		ar >> wTemp;	m_wFSunit = (WORD)wTemp;
		ar >> wTemp;	m_nFlipMode = (int)wTemp;

		ar >> wTemp;	m_ccHSS.hssFlag = (int)wTemp;
		ar >> wTemp;	m_ccHSS.hssDepth = (int)wTemp;
		ar >> wTemp;	m_ccHSS.hssDepth = (int)wTemp;
		ar >> dwTemp;	m_ccHSS.hssFromColor = (COLORREF)dwTemp;
		ar >> dwTemp;	m_ccHSS.hssToColor = (COLORREF)dwTemp;
		ar >> wTemp;	m_ccHSS.hssPara = (int)wTemp;
		//	98����
		m_nltxtobjShape = rectangle;
		// amend by wdb
	}
	CWPSObj::SerializeObjType(ar);
}

////////////////////////////////////////////////////////////////
// �޶�˵��	��	��FS_NAMESIZE�����İ��뺺�İ��в�ͬ,�����İ���
//				�ر�Ϊ���������ر���������������Ȼ�溺���ִ�,
//				ֻ���ڶ��������ת�������Ӧ�����Ĵ�.[shq Sep.12, 2001]
////////////////////////////////////////////////////////////////
extern BOOL g_MapFontSizeName(LPCSTR lpszSrc, LPSTR lpszDest, int nType);
void CLtxtObj::Serialize_98(CArchive& ar)
{
	CPTObj::Serialize_98(ar);
	const UINT uFontNameSize	= FS_NAMESIZE_SERIALIZE;	// ������ʷԭ��������ݱ�ΪFS_NAMESIZE_SERIALIZE == 10
	char szTempForFontSizeName[FS_NAMESIZE];

	if (ar.IsStoring())
	{
		ar << m_nltxtobjShape;
		if (m_nltxtobjShape == ellipseComment ||
			m_nltxtobjShape == para	|| 
			m_nltxtobjShape == trap || 
			m_nltxtobjShape == rectComment)
			ar << m_activePnt;						//��ע�����õ��Ŀ��϶���
		
		if (m_nltxtobjShape == roundRect)
			ar << m_roundnessPnt;
		if (m_nltxtobjShape == roundRectComment)
		{
			ar << m_activePnt;
		    ar << m_roundnessPnt;
		}
		CString str;
		::TextStringToString(str, m_string);
		::MStringToDMString(str);
		ar << str;
		ar << m_stringColor;
		ar << m_nAspectX;
		ar << m_nCharMrg;
		ar << m_nAlig;
		ar.Write(&m_lfChn, sizeof(LOGFONT));
		ar.Write(&m_lfEng, sizeof(LOGFONT));

		strcpy(szTempForFontSizeName, m_szFSname);
		//if (IsMengWen_Version(g_dwLanguageVersion))
		if (IsMengWen_Resource(g_dwResourceLanguage))
		{
			// ��Ȼ���뺺�Ĵ�
			g_MapFontSizeName(m_szFSname, szTempForFontSizeName, 1);
		}
	
		ar.Write(szTempForFontSizeName, uFontNameSize * sizeof(char));

		ar << m_nFSsize;
		ar << m_wFSunit;
		ar << m_nFlipMode;
		ar.Write(&m_ccHSS, sizeof(CHARFXHSS));
	}
	else
	{
		ar >> m_nltxtobjShape;
		if (m_nltxtobjShape == ellipseComment || 
			m_nltxtobjShape == para || 
			m_nltxtobjShape == trap || 
			m_nltxtobjShape == rectComment)
			ar >> m_activePnt; //��ע�����õ��Ŀ��϶���

		if (m_nltxtobjShape == roundRect)
			ar >> m_roundnessPnt;
		if (m_nltxtobjShape == roundRectComment)
		{ 
		   ar >> m_activePnt;
		   ar >> m_roundnessPnt;
		}
		CString strTemp;
		ar >> strTemp;

		//˫�ֽ�CString��KSTextString��ת��
		LPCTSTR lpszOld = (LPCTSTR)strTemp;
		int nStrLen;
		for (nStrLen = 0; lpszOld[nStrLen]; nStrLen += 2)
			;
		nStrLen = nStrLen / 2;//˫�ֽ��ַ���

		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		VERIFY(nStrLen == KCP_WordToTextWord(lptwBuffer,
				(LPWORD)(LPCTSTR)strTemp, nStrLen));
		m_string.Insert(0, lptwBuffer, nStrLen);
		delete lptwBuffer;
		//end ˫�ֽ�CString��KSTextString��ת��

		ar >> m_stringColor;
		ar >> m_nAspectX;
		ar >> m_nCharMrg;
		ar >> m_nAlig;
		ar.Read(&m_lfChn, sizeof(LOGFONT));
		ar.Read(&m_lfEng, sizeof(LOGFONT));

		//if (IsMengWen_Version(g_dwLanguageVersion))
		if (IsMengWen_Resource(g_dwResourceLanguage))
		{
			// ��ȡ���ĺ��Ĵ�תΪ���Ĵ�,ע��FS_NAMESIZE�����İ��뺺�İ��в���
			ar.Read(szTempForFontSizeName, uFontNameSize * sizeof(char));
			g_MapFontSizeName(szTempForFontSizeName, m_szFSname, 0);
		}
		else
			ar.Read(m_szFSname, uFontNameSize * sizeof(char));

		ar >> m_nFSsize;
		ar >> m_wFSunit;
		ar >> m_nFlipMode;
		ar.Read(&m_ccHSS, sizeof(CHARFXHSS));
	}
	CWPSObj::SerializeObjType(ar);
}

// -------------------------------------------------------------------------
// ��Ҫд�������У�
//		COLORREF m_stringColor;
//		int		m_nAspectX;
//		int		m_nCharMrg;
//		WORD	m_nAlig;
//		LOGFONT	m_lfChn;
//		LOGFONT	m_lfEng;
//		char  	m_szFSname[FS_NAMESIZE];	//	�ֺ���
//		int		m_nFSsize;					//  �ַ��ߴ�
//		WORD	m_wFSunit;					//  ʹ�úε�λ��ʾ�ߴ�(pound, ��, etc.)
//		CHARFXHSS m_ccHSS;
void GetFontSizeString (LPTSTR lpszFontSize, FONTSIZE& fs);
void GetFontSize(LPTSTR lpszFontSize, FONTSIZE& fs);
void GetSafeLFChn(char sz[], LPLOGFONT lplf);
void GetSafeLFEng(char sz[], LPLOGFONT lplf);

extern TCHAR szAutoFontSize[];

STDMETHODIMP CLtxtObj::Serialize_Write_02(CArchive& ar)
{
	KWPSMainWriter wr;
	wr.Attach(&ar);
	
	WPSLtxtObjData rec;
	UINT cbData = sizeof(rec) - sizeof(POINT);
	rec.nObjShape	= m_nltxtobjShape;
	rec.nFlipMode	= m_nFlipMode;
	rec.fAutoSize	= lstrcmp(m_szFSname, szAutoFontSize) == 0;
	rec.fRotateFont	= m_lfChn.lfFaceName[0] == '@';
	rec.wReserved	= 0;
	rec.fDefText	= m_bDefText;
	switch (m_nltxtobjShape)
	{
	case ellipseComment: case para: case trap: case rectComment:
		rec.ptActivePnt	= m_activePnt;
		break;
	case roundRect:
		rec.ptRoundnessPnt = m_roundnessPnt;
		break;
	case roundRectComment:
		rec.ptComment[0] = m_activePnt;
		rec.ptComment[1] = m_roundnessPnt;
		cbData = sizeof(rec);
		break;
	}
	_WPSWriteRecord(wr, TAG_WPSLtxtObjData, &rec, cbData);
	
	ar << m_string;
	return SerializeAttr_Write_02(ar);
}

STDMETHODIMP CLtxtObj::Serialize_Read_02(CArchive& ar)
{
	WPSLtxtObjData rec;
	HRESULT hr;
	hr = __WPSReadRecord(ar, TAG_WPSLtxtObjData, rec);
	if (hr == S_OK)
	{
		m_nltxtobjShape	= rec.nObjShape;
		m_nFlipMode		= rec.nFlipMode;
		m_bDefText		= rec.fDefText;
		switch (m_nltxtobjShape)
		{
		case ellipseComment: case para: case trap: case rectComment:
			m_activePnt	= rec.ptActivePnt;
			break;
		case roundRect:
			m_roundnessPnt	= rec.ptRoundnessPnt;
			break;
		case roundRectComment:
			m_activePnt	= rec.ptComment[0];
			m_roundnessPnt = rec.ptComment[1];
			break;
		}
	}
	ar >> m_string;
	SerializeAttr_Read_02(ar);
	if (rec.fAutoSize)
	{
		strcpy(m_szFSname, szAutoFontSize);
		m_bAutoFont = TRUE;		//lijun �����Զ�����
	}
	if (rec.fRotateFont)
	{
		memmove(m_lfChn.lfFaceName + 1, m_lfChn.lfFaceName, LF_FACESIZE - 1);
		m_lfChn.lfFaceName[0] = '@';
	}
	
	return S_OK;
}

void CLtxtObj::_SetDefaultValues()
{
	m_stringColor = RGB(0,0,0);
	m_nAspectX = 100;
	m_nCharMrg = 0;			//	��λ 0.1 mm
	m_nAlig = TAL_HCENTER;
	
	// ������������ȡ��LOGFONT
	LPLOGFONT lplfC = GetlfChn();
	GetSafeLFChn(szDefCFontName, lplfC);
	LPLOGFONT lplfE = GetlfEng();
	GetSafeLFEng(szDefEFontName, lplfE);
	
	SetlfChn(lplfC);	//	�߼�������
	SetlfEng(lplfE);	//	�߼�������
	
	SetFontHeight(555);
	SetFontWidth(0);
	
	lstrcpy(m_szFSname, szFontSize[6]);		//	�ֺ� ������
	m_nFSsize = 6;
	m_wFSunit = FSU_SIZE;
	
	m_lfEng.lfWeight = FW_NORMAL; 
	m_lfChn.lfWeight = FW_NORMAL;
	m_lfEng.lfItalic = CC_DISABLED;
	m_lfChn.lfItalic = CC_DISABLED;
	m_lfEng.lfStrikeOut = CC_DISABLED;
	m_lfChn.lfStrikeOut = CC_DISABLED;
	m_lfEng.lfUnderline = PS_NULL;
	m_lfChn.lfUnderline = PS_NULL;
	
	//	m_ccHSS .hssFlag = 0;//	����ġ����塢...ȱʡΪ��
	::memset(&m_ccHSS, 0, sizeof(CHARFXHSS));	
}

HRESULT CLtxtObj::SerializeAttr_Read_02(CArchive& ar)
{
	CObList			AttrList;
	POSITION		pi;
	CCtrlCode*		p;
	CCtrlCode_Size*	pccSize;
	
	tagFONTSIZE		fs;
	UNIT_VALUE		uv;
	
	_SetDefaultValues();
	ReadProp(&AttrList, ar);
	
	// Read all data and then release it
	for(pi = AttrList.GetHeadPosition(); pi != NULL; )
	{
		p = (CCtrlCode*)AttrList.GetNext(pi);
		
		switch (p->GetCodeID())
		{
		case SETENGFONT:
			strncpy(m_lfEng.lfFaceName, ((CCtrlCode_Font*)p)->GetFaceName(), LF_FACESIZE);
			m_lfEng.lfFaceName[LF_FACESIZE - 1] = 0;
			break;
		case SETCHNFONT:
			strncpy(m_lfChn.lfFaceName, ((CCtrlCode_Font*)p)->GetFaceName(), LF_FACESIZE);
			m_lfChn.lfFaceName[LF_FACESIZE - 1] = 0;
			break;
		case SETFONTSIZE:
			pccSize = (CCtrlCode_Size*)p;
			fs.nfsSize = m_nFSsize = pccSize->GetSize();
			fs.nfsUnit = m_wFSunit = pccSize->GetUnit();
			if (m_wFSunit == FSU_SIZE)
			{
				GetFontSizeString(m_szFSname, fs);
			}
			extern int CalcFontSize(WORD wUnit, int n);
			m_lfEng.lfHeight = m_lfChn.lfHeight = CalcFontSize(fs.nfsUnit, fs.nfsSize);;
			break;
		case SETACTFONTSIZE:
			pccSize = (CCtrlCode_Size*)p;
			ASSERT(pccSize->GetActualUnit() == FSU_HM);
			if (pccSize->GetActualUnit() == FSU_HM)
			{
				m_lfEng.lfHeight = m_lfChn.lfHeight = HM2LU(pccSize->GetActualSize());
			}
			break;
		case SETBOLD:
			m_lfEng.lfWeight = m_lfChn.lfWeight = ((CCtrlCode_Bold*)p)->GetWeight();
			break;
		case SETITALIC:
			m_lfEng.lfItalic = m_lfChn.lfItalic = 
				//				( ((CCtrlCode_Italic*)p)->GetDegree() != CC_DISABLED );
				((CCtrlCode_Italic*)p)->GetDegree();
			break;
		case SETCOLOR:
			m_stringColor = ((CCtrlCode_Color*)p)->GetColor();
			break;
		case SETSTRIKEOUT:
			m_lfEng.lfStrikeOut = m_lfChn.lfStrikeOut =
//				( ((CCtrlCode_StrikeOut*)p)->GetFlag() != CC_DISABLED );
				((CCtrlCode_StrikeOut*)p)->GetFlag();
			break;
		case SETUNDERLINE:
			m_lfEng.lfUnderline = m_lfChn.lfUnderline =
//				( ((CCtrlCode_UnderLine*)p)->GetType() != PS_NULL );
				((CCtrlCode_UnderLine*)p)->GetType();
			break;
		case SETASPECTX:
			m_nAspectX = ((CCtrlCode_AspectX*)p)->GetAspectX();
			break;
		case SETTRACKING:
			uv = *((CCtrlCode_Tracking*)p)->GetTracking();
			ASSERT(uv.wUnit == UNIT_METRIC);
			if (uv.wUnit == UNIT_METRIC)
			{
				m_nCharMrg = uv.nValue;
			}
			break;
		case SETHSS:
			m_ccHSS = *((CCtrlCode_HSS*)p)->GetData();
			break;
		case SETHALIGNMENT:
			m_nAlig = ((CCtrlCode_Alignment*)p)->GetAlignment();
			break;
		}
		delete p;		// assume virtual destructors
	}
	return S_OK;
}

HRESULT CLtxtObj::SerializeAttr_Write_02(CArchive& ar) const
{
	CObList	AttrList;
	
	// д������
	CCtrlCode_Font		ccFontNameDef(SETENGFONT, m_lfEng.lfFaceName);
	CCtrlCode_Font		ccFontNameFE(SETCHNFONT, m_lfChn.lfFaceName);
	
	tagFONTSIZE			fs;
	fs.nfsUnit = m_wFSunit;
	if (m_wFSunit == FSU_SIZE)
		GetFontSize((char *)m_szFSname, fs);
	else
		fs.nfsSize = m_nFSsize;
	CCtrlCode_Size		ccFontSize(&fs);
	
	fs.nfsUnit = FSU_HM;
	fs.nfsSize = LU2HM(m_lfEng.lfHeight);
	CCtrlCode_Size		ccActFontSize(SETACTFONTSIZE, &fs);
	
	CCtrlCode_Bold		ccFontWeight(m_lfEng.lfWeight);
	//	CCtrlCode_Italic	ccFontItalic(m_lfEng.lfItalic ? CC_ENABLED : CC_DISABLED);
	CCtrlCode_Italic	ccFontItalic(m_lfEng.lfItalic);
	CCtrlCode_Color		ccColor(m_stringColor);
	//	CCtrlCode_StrikeOut	ccStrikeOut(m_lfEng.lfStrikeOut ? CC_ENABLED : CC_DISABLED);
	CCtrlCode_StrikeOut	ccStrikeOut(m_lfEng.lfStrikeOut);
	tagUULINEPARA		ul;
	//	ul.uStyle = m_lfEng.lfUnderline ? PS_SOLID : PS_NULL;
	ul.uStyle = m_lfEng.lfUnderline;
	ul.cColor = AUTOUULINECOLOR;
	CCtrlCode_UnderLine	ccUnderLine(SETUNDERLINE, &ul);
	
	CCtrlCode_AspectX	ccAspectX(m_nAspectX);
	UNIT_VALUE			uv;
	uv.wUnit = UNIT_METRIC;
	uv.nValue = m_nCharMrg;
	CCtrlCode_Tracking	ccTracking(&uv);
	CCtrlCode_HSS		ccHSS((CHARFXHSS*)&m_ccHSS);
	CCtrlCode_Alignment	ccHAlignment(SETHALIGNMENT, m_nAlig);
	
	// ����CtrlCode��
	AttrList.AddTail(&ccFontNameDef);
	AttrList.AddTail(&ccFontNameFE);
	AttrList.AddTail(&ccFontSize);
	AttrList.AddTail(&ccActFontSize);
	AttrList.AddTail(&ccFontWeight);
	AttrList.AddTail(&ccFontItalic);
	AttrList.AddTail(&ccColor);
	AttrList.AddTail(&ccStrikeOut);
	AttrList.AddTail(&ccUnderLine);
	AttrList.AddTail(&ccAspectX);
	AttrList.AddTail(&ccTracking);
	AttrList.AddTail(&ccHSS);
	AttrList.AddTail(&ccHAlignment);
	
	WriteProp(&AttrList, ar);
	
	return S_OK;
}

void CLtxtObj::Serialize_01(CArchive& ar)
{
	CPTObj::Serialize_01(ar);

	const UINT uFontNameSize = FS_NAMESIZE_SERIALIZE; // ������ʷԭ��������ݱ�ΪFS_NAMESIZE_SERIALIZE == 10
	char szTempForFontSizeName[FS_NAMESIZE];

	if (ar.IsStoring())
	{
		if (g_fCompoundFile) // wps2002-io-beta2, by tsingbo
		{
			Serialize_Write_02(ar);
			return;
		}
		ar << m_nltxtobjShape;
		if (m_nltxtobjShape == ellipseComment || 
			m_nltxtobjShape == para || 
			m_nltxtobjShape == trap|| 
			m_nltxtobjShape == rectComment)
			ar << m_activePnt;							//��ע�����õ��Ŀ��϶���
		if (m_nltxtobjShape == roundRect)
			ar << m_roundnessPnt;
		if (m_nltxtobjShape == roundRectComment)
		{  
			ar << m_activePnt;
			ar << m_roundnessPnt;
		}

		//��Ĭ��������Ϣ����
		KSTextString strText = m_string;
		::MakeTextStringWithBOOL(strText, m_bDefText);
		ar << strText;

		ar << m_stringColor;
		ar << m_nAspectX;
		ar << m_nCharMrg;
		ar << m_nAlig;
		ar.Write(&m_lfChn, sizeof(LOGFONT));
		ar.Write(&m_lfEng, sizeof(LOGFONT));

		strcpy(szTempForFontSizeName, m_szFSname);
		//if (IsMengWen_Version(g_dwLanguageVersion))
		if (IsMengWen_Resource(g_dwResourceLanguage))
		{
			// ��Ȼ���뺺�Ĵ�
			g_MapFontSizeName(m_szFSname, szTempForFontSizeName, 1);
		}
		ar.Write(szTempForFontSizeName, uFontNameSize * sizeof(char));

		ar << m_nFSsize;
		ar << m_wFSunit;
		ar << m_nFlipMode;
		ar.Write(&m_ccHSS, sizeof(CHARFXHSS));
		CWPSObj::SerializeObjType(ar);
	}
	else
	{
		if (g_fWpsObjBeta2)	// wps2002-io-beta2, by tsingbo
		{
			Serialize_Read_02(ar);
			return;
		}
		ar >> m_nltxtobjShape;
		if (m_nltxtobjShape == ellipseComment || 
			m_nltxtobjShape == para	|| 
			m_nltxtobjShape == trap || 
			m_nltxtobjShape == rectComment)
			ar >> m_activePnt;						//��ע�����õ��Ŀ��϶���
		if (m_nltxtobjShape == roundRect)
			ar >> m_roundnessPnt;
		if (m_nltxtobjShape == roundRectComment)
		{  
			ar >> m_activePnt;
			ar >> m_roundnessPnt;
		}

		//��ȡĬ��������Ϣ
		ar >> m_string;
		m_bDefText = ::ParseTextStringWithBOOL(m_string);

		ar >> m_stringColor;
		ar >> m_nAspectX;
		ar >> m_nCharMrg;
		ar >> m_nAlig;
		ar.Read(&m_lfChn, sizeof(LOGFONT));
		ar.Read(&m_lfEng, sizeof(LOGFONT));

		//if (IsMengWen_Version(g_dwLanguageVersion))
		if (IsMengWen_Resource(g_dwResourceLanguage))
		{
			// ��ȡ���ĺ��Ĵ�תΪ���Ĵ�,ע��FS_NAMESIZE�����İ��뺺�İ��в���
			ar.Read(szTempForFontSizeName, uFontNameSize * sizeof(char));
			g_MapFontSizeName(szTempForFontSizeName, m_szFSname, 0);
		}
		else
			ar.Read(m_szFSname, uFontNameSize * sizeof(char));

		ar >> m_nFSsize;
		ar >> m_wFSunit;
		ar >> m_nFlipMode;
		ar.Read(&m_ccHSS, sizeof(CHARFXHSS));
		CWPSObj::SerializeObjType(ar);
	}
}

// -------------------------------------------------------------------------

void CLtxtObj::SetString(KSTextString& str, CWpsView* pView) 
{
	m_string = str;
}

// -------------------------------------------------------------------------

BOOL CLtxtObj::RefreshTextObj(CWpsView *pView, LPRECT prcNewFrame)
{
	return TRUE;
}

// -------------------------------------------------------------------------
#ifndef _WPSREADER
void CLtxtObj::SetEndShape(int id, int nEndShape)
{
	if (m_nltxtobjShape == sizeComment)
		m_nEndShape[id] = nEndShape;
	else
		CPTObj::SetEndShape(id, nEndShape);
}
#endif //_WPSREADER

CLtxtObj::CLtxtObj(const CWpsDoc* pDoc, const CRect& position, int nShape)
{

	SetWPSObjType(LTXTObj);
	m_nltxtobjShape =  nShape;	//xu add 7.15
	m_uLPenSize  = PLW_DEFSIZE;  //�߳ߴ�

	//m_pTextObjSite	= NULL;		//�Ű���Ϣָ��
	//m_nHeadPos		= -1;		//	��ǰѡ�п�����ַ�������
	//m_nTailPos		= -1;		//	��ǰ���ĩ�ַ�������
	//m_nCurPos		= 0;		//	��ǰ�ַ��� m_string ���е�������
	//m_nCurRowID		= 0;        //	��ǰ�ַ�������ʾ�� ID
	//m_nHeadRowID	= 0;		//	��ǰ�����ַ������� ID
	m_bDefText		= FALSE;
	//m_nTextWidth	= -1;
	
	if (nShape == oblique || nShape == rectangle 
		|| nShape >= 1000)
		m_uLPenStyle = PS_NULL;
	else
		m_uLPenStyle = PS_INSIDEFRAME;	//xu edit 7.16
	          
	m_stringColor = RGB(0,0,0);
	//	������
	m_nAspectX = 100;
	//	�ּ��
	m_nCharMrg = 0;			//	��λ 0.1 mm
	//	���뷽ʽ
	m_nAlig = TAL_HCENTER;
	// ������������ȡ��LOGFONT
	LPLOGFONT lplfC = GetlfChn();
	GetSafeLFChn(szDefCFontName, lplfC);
	LPLOGFONT lplfE = GetlfEng();
	GetSafeLFEng(szDefEFontName, lplfE);

	SetlfChn(lplfC);	//	�߼�������
	SetlfEng(lplfE);	//	�߼�������
	if (nShape == oblique)
		SetFontHeight(370);
	else
		SetFontHeight(555);
	SetFontWidth(0);
	if (nShape == oblique)
		lstrcpy(m_szFSname, _T("���"));//@@todo:ֻ֧�ּ������İ� szDefFontSize);		//	�ֺ� �����
	else
		lstrcpy(m_szFSname, _T("����"));//@@todo:ֻ֧�ּ������İ� szFontSize[6]);		//	�ֺ� ������
	if (nShape == oblique)
		m_nFSsize = 9;
	else
		m_nFSsize = 6;
	m_wFSunit = FSU_SIZE;

	m_lfEng.lfWeight = FW_NORMAL; 
	m_lfChn.lfWeight = FW_NORMAL;
	m_lfEng.lfItalic = CC_DISABLED;
	m_lfChn.lfItalic = CC_DISABLED;
	m_lfEng.lfStrikeOut = CC_DISABLED;
	m_lfChn.lfStrikeOut = CC_DISABLED;
	m_lfEng.lfUnderline = PS_NULL;
	m_lfChn.lfUnderline = PS_NULL;

	//	����
	m_nFlipMode = 0;
	//	m_ccHSS .hssFlag = 0;//	����ġ����塢...ȱʡΪ��
	::memset(&m_ccHSS, 0, sizeof(CHARFXHSS));
	
	int nRnd = min(60, min(position.Height()/2, position.Width()/2));
	switch(	m_nltxtobjShape)
	{	
	case  rectangle:
			m_uLPenStyle = PS_NULL;
			break;
	case  ellipseComment:
			m_activePnt.x = -100;			 //����ڶ����m_rect�����½�
			m_activePnt.y = 100;
			break;
	case   roundRect:                        //Բ�Ǿ���
			m_roundnessPnt.x = nRnd;	     //����ڶ����m_rect�����Ͻ�
			m_roundnessPnt.y = nRnd;
			break;
	case   roundRectComment:
			m_activePnt.x = -100;             //����ڶ����m_rect�����½�
			m_activePnt.y = 100;
			m_roundnessPnt.x = nRnd;		 //����ڶ����m_rect�����Ͻ�
			m_roundnessPnt.y = nRnd;
			break;
	case   rectComment:
			m_activePnt.x = -100;			  //����ڶ����m_rect�����½�
			m_activePnt.y = 100;
			break;
	case   para: 
	case   trap:
			m_activePnt.x = m_rect.Width()/4;  //����ڶ����m_rect�����Ͻ�
			m_activePnt.y = 0;
			break;
	case   sizeComment:
			SetEndShape(0, sa_1); 
			SetEndShape(1, es_null);           //��ĩ�˼�ͷʼ����Ϊ��
			SetWPSObjType(LTXTSizeComment);
			break;
	}
	m_bAutoFont = FALSE;		//lijun �����Զ�����
}

// -------------------------------------------------------------------------

