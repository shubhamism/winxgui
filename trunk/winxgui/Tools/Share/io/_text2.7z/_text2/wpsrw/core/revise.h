/* -------------------------------------------------------------------------
//	�ļ���		��	revise.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-22 20:35:07
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __REVISE_H__
#define __REVISE_H__

// -------------------------------------------------------------------------

class CUser : public CObject
{
protected:
	DECLARE_SERIAL(CUser);
	
public:
	CUser()
	{
		m_wUserID = 0;						// �û�ID
		m_strUserName = m_strUserAddress = CString("Unknown");
	}
	
protected:
	WORD		m_wUserID;			// �û�ID
	CString		m_strUserName;		// �û�����
	CString		m_strUserAddress;	// �û��ʼ���ַ
	
public:
	virtual void Serialize(CArchive&);
	const WORD GetUserID() const { return m_wUserID; }
	const CString& GetUserName() const { return m_strUserName; }
	const CString& GetUserAddress() const { return m_strUserAddress; }
#ifndef _WPSREADER
	void SetUserID(const WORD wUserID) { m_wUserID = wUserID; }
	void SetUserName(const CString& str) { m_strUserName = str; }
	void SetUserAddress(const CString& str) { m_strUserAddress = str; }
#endif	// #ifndef _WPSREADER
};

// -------------------------------------------------------------------------

#endif /* __REVISE_H__ */
