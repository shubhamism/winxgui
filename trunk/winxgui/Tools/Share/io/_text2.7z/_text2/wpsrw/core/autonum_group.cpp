/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_group.cpp
//	������		��	����
//	����ʱ��	��	2004-10-26 2:35:16 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __AUTONUM_ATOM_H
#include "autonum_atom.h"
#endif

#ifndef __AUTONUM_DATAPTR_H__
#include "autonum_dataptr.h"
#endif

#include "autonum_group.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

tagAUTONUMGROUP::tagAUTONUMGROUP()
{
}

tagAUTONUMGROUP::tagAUTONUMGROUP(const tagAUTONUMGROUP& BigGroup)
{
	int nIndex	= 0;
	int nCount	= tagAUTONUMGROUP::GetLevelCount();
	for (nIndex = 0; nIndex < nCount; nIndex++)
	{
		GroupData[nIndex]	= BigGroup.GroupData[nIndex];
	}
}

tagAUTONUMGROUP::~tagAUTONUMGROUP()
{
}

HRESULT tagAUTONUMGROUP::GetSpecialLevelData(int nLevel, KAutoNumAtomSPtr& spAtom)
{
	HRESULT hr	= E_FAIL;
	spAtom		= NULL;
	if (ISVALIDAUTONUMLEVEL(nLevel))
	{
		spAtom	= GroupData[nLevel];
		hr		= S_OK;
	}
	return hr;
}

HRESULT tagAUTONUMGROUP::ChangeSpecialLevelData(int nLevel, const KAutoNumAtomSPtr& spAtom)
{
	HRESULT hr	= E_FAIL;
	if (ISVALIDAUTONUMLEVEL(nLevel))
	{
		if (GroupData[nLevel] == spAtom)
			hr	= S_FALSE;
		else
		{
			GroupData[nLevel]	= spAtom;
			hr	= S_OK;
		}
	}
	return hr;
}

const tagAUTONUMGROUP& tagAUTONUMGROUP::operator=(const tagAUTONUMGROUP& BigGroup)
{
	int nIndex	= 0;
	int nCount	= tagAUTONUMGROUP::GetLevelCount();
	for (nIndex = 0; nIndex < nCount; nIndex++)
	{
		GroupData[nIndex]	= BigGroup.GroupData[nIndex];
	}
	return *this;
}

// -------------------------------------------------------------------------
