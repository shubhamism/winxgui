/* -------------------------------------------------------------------------
//	�ļ���		��	MediaKits/mds_hgbl.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2002-5-14 15:31:57
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "mds_lock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class KMediaDataAtHGlobal : public IKMediaDataSource
{
protected:
    HGBL	m_hGbl;
	
public:
	KMediaDataAtHGlobal() { m_hGbl = NULL; }
	~KMediaDataAtHGlobal()
	{
		//ASSERT(!IsHGblLocked(m_hGbl));
		if (m_hGbl)
		{
			XGlobalFree(m_hGbl);
			m_hGbl = NULL;
		}
	}
	STDMETHODIMP Attach(HGBL hGbl)
	{
		ASSERT(m_hGbl == NULL);
		m_hGbl = hGbl;
		return S_OK;
	}
	STDMETHODIMP ClearCache() { return S_OK; }
	STDMETHODIMP Lock(void** ppv, MDSSIZE* psize)
	{
		if (m_hGbl == NULL)
			return E_MD_NOSOURCE;
		
		*ppv = XGlobalLock(m_hGbl);
		*psize = XGlobalSize(m_hGbl);
		return S_OK;
	}
	STDMETHODIMP Unlock()
	{
		if (m_hGbl == NULL)
			return E_MD_NOSOURCE;
		
		XGlobalUnlock(m_hGbl);
		return S_OK;
	}
	DECLARE_COMCLASS(KMediaDataAtHGlobal, IKMediaDataSource)
};

// -------------------------------------------------------------------------

STDMETHODIMP CreateMDSFromAttachHGbl(HGBL hGbl, IKMediaDataSource** ppMDS)
{
	KMediaDataAtHGlobal* pMDS = new KCountObject<KMediaDataAtHGlobal>;
	HRESULT hr = pMDS->Attach(hGbl);
	if (hr != S_OK)
	{
		delete pMDS;
		pMDS = NULL;
	}
	*ppMDS = pMDS;
	return hr;
}

STDMETHODIMP CreateMDSFromFile(LPCTSTR szFile, IKMediaDataSource** ppMDS)
{
	USES_CONVERSION;
	HGBL hGbl = NULL;
	HRESULT hr = CreateHGblFromFile(&hGbl, A2W(szFile));
	if (hr != S_OK)
		return hr;
	
	return CreateMDSFromAttachHGbl(hGbl, ppMDS);
}

// -------------------------------------------------------------------------
