
#ifndef __AUTONUM_DECLARE_H
#define __AUTONUM_DECLARE_H

template<class Ptr>
class _KAutoNumSmartPtr;

struct tagAUTONUMATOM;
typedef std::list<void*>									_KAtomContainer;	// Ԫ��ΪKAutoNumAtomPtr*
typedef _KAutoNumDataPtr<tagAUTONUMATOM, _KAtomContainer>	KAutoNumAtomPtr;
typedef _KAutoNumSmartPtr<KAutoNumAtomPtr>					KAutoNumAtomSPtr;

struct tagAUTONUMGROUP;
typedef std::list<void*>									_KGroupContainer;	// Ԫ��ΪKAutoNumGroupPtr*
typedef _KAutoNumDataPtr<tagAUTONUMGROUP, _KGroupContainer>	KAutoNumGroupPtr;
typedef _KAutoNumSmartPtr<KAutoNumGroupPtr>					KAutoNumGroupSPtr;

#endif // __AUTONUM_DECLARE_H
