// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__2CBEE913_4F28_4FEC_A932_96B785D60D76__INCLUDED_)
#define AFX_STDAFX_H__2CBEE913_4F28_4FEC_A932_96B785D60D76__INCLUDED_

#include "buildcfg/wps_buildcfg.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define DW_NO_ENCRYPT
#define WPSOBJ_SUPPORT_DRAW
#pragma warning(disable: 4786)

// -------------------------------------------------------------------------
#if 0
#define WPS_ONLY
#define WPP_ONLY
#endif

#if !defined(WPS_ONLY) && !defined(WPP_ONLY)
#error "please define WPS_ONLY or WPP_ONLY at first!!!"
#endif

// -------------------------------------------------------------------------
#include <afx.h>
#include <afxole.h>
#include <afxadv.h>
#include <afxtempl.h>
#include <afxpriv.h> // use for CSharedFile
#include <objbase.h>

#undef _ATL_PACKING
// -------------------------------------------------------------------------

typedef CArchive CAfxArchive;

class CArchiveReadOnly : public CArchive
{
public:
	BOOL IsLoading() const { return TRUE; }
	BOOL IsStoring() const { return FALSE; }
};

//#define CArchive CArchiveReadOnly

// -------------------------------------------------------------------------

#include <kfc.h>
#include <stl/vector.h>
#include <atl/atlbase.h>
#include <wpsrw/common.h>

// -------------------------------------------------------------------------

#undef __int16
#define __int16	short

// -------------------------------------------------------------------------
// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__2CBEE913_4F28_4FEC_A932_96B785D60D76__INCLUDED_)
