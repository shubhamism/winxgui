/* -------------------------------------------------------------------------
//	�ļ���		��	sprm.cpp
//	������		��	���
//	����ʱ��	��	2002-5-28 17:03:00
//	��������	��	
//
//-----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ctrlcode_sprm.h"

namespace sprmCtrlAid
{
// -------------------------------------------------------------------------

void _TakeData(WORD sprm, LPCVOID pData, int& cwData, WORD*& pwData)
{
	pwData = (WORD*)pData;

	switch(IO_SPRM_SPRA(sprm))
	{
	case _io_spra_word:
		cwData = 1;
		break;
	case _io_spra_dword:
		cwData = 2;
		break;
	case _io_spra_qword:
		cwData = 4;
		break;
	case _io_spra_variant:
		cwData = *pwData++;
		break;
	default:
		ASSERT(0);
	}
}

WORD _TakeWord(int cwData, WORD* pwData)
{
	if (cwData >= 1)
		return *pwData;
	else
	{
		ASSERT(0);	// 0 �ֽڵ�sprmָ������
		return 0;
	}
}

DWORD _TakeDWord(int cwData, WORD* pwData)
{
	if (cwData >= 2)
		return *((DWORD*)pwData);
	else
		return _TakeWord(cwData, pwData);
}

WORD ReadSprmWordValue(WORD sprm, LPCVOID pData)
{
	int		cwData;
	WORD*	pwData;

	_TakeData(sprm, pData, cwData, pwData);
	return _TakeWord(cwData, pwData);
}

DWORD ReadSprmDWordValue(WORD sprm, LPCVOID pData)
{
	int		cwData;
	WORD*	pwData;

	_TakeData(sprm, pData, cwData, pwData);
	return _TakeDWord(cwData, pwData);
}

static WORD	sprmWBuf[3];

void SaveSprmWordValue(IAppendBuffer* pBuf, WORD sprm, WORD wData)
{
	sprmWBuf[0] = sprm | (WORD)(_io_spra_word << 14);
	sprmWBuf[1] = wData;
	pBuf->Add(sprmWBuf, 4);
}

void SaveSprmDWordValue(IAppendBuffer* pBuf, WORD sprm, DWORD wData)
{
	sprmWBuf[0] = sprm | (WORD)(_io_spra_dword << 14);
	sprmWBuf[1] = LOWORD(wData);
	sprmWBuf[2] = HIWORD(wData);
	pBuf->Add(sprmWBuf, 6);
}

void SaveSprmStructHeader(IAppendBuffer* pBuf, WORD sprm, int cwData)
{
	ASSERT(HIWORD(cwData) == 0);	// assume less than 65536
	sprmWBuf[0] = sprm | (WORD)(_io_spra_variant << 14);
	sprmWBuf[1] = cwData;
	pBuf->Add(sprmWBuf, 4);
}

LPCVOID MoveOverSprm(WORD sprm, LPCVOID pData)
{
	WORD* p = (WORD*)pData;
	switch(IO_SPRM_SPRA(sprm))
	{
	case _io_spra_word:
		p++;
		break;
	case _io_spra_dword:
		p += 2;
		break;
	case _io_spra_qword:
		p += 4;
		break;
	case _io_spra_variant:
		p += *p + 1;
		break;
	default:
		ASSERT(0);
	}

	return p;
}

int LoadSprmBinaryValue(WORD sprm, LPCVOID pData, LPVOID lpTag, int cbTag)
{
	int		cwData;
	WORD*	pwData;

	if (lpTag == NULL || cbTag <= 0)	// 0�ֽڶ���ʲô��
	{
		ASSERT(0);
		return -1;
	}

	_TakeData(sprm, pData, cwData, pwData);
	int		cb = cwData << 1;

	if (cb >= cbTag)
	{
		cb = cbTag;
	}
	else
	{
		ASSERT(0);	// û���㹻��ʳ��ι��Ŀ��
	}

	memcpy(lpTag, pwData, cb);
	return cb;
}

void SaveSprmBinaryValue(IAppendBuffer* pBuf, WORD sprm, LPCVOID lpBuf, int cb)
{
	int	cw;

	cw = cw_BlockSprm(cb);

	sprmWBuf[0] = sprm | (WORD)(_io_spra_variant << 14);
	sprmWBuf[1] = cw;
	pBuf->Add(&sprmWBuf, 4);
	pBuf->Add(lpBuf, cb);
	// Word Alignment
	if (cb & 1)
	{
		BYTE b = 0;
		pBuf->Add(&b, 1);
	}
}

int LoadSprmStringValue(WORD sprm, LPCVOID pData, LPSTR lpTag, int cbTag)
{
	int		cwData;
	WORD*	pwData;

	if (lpTag == NULL || cbTag <= 0)	// ����ҲӦ����һ����β0�Ŀռ�ɡ�
	{
		ASSERT(0);
		return -1;
	}

	_TakeData(sprm, pData, cwData, pwData);
	if (*pwData != 0)
	{
		ASSERT(0);	// not SBCS/MBCS string
		*lpTag = 0;
		return -1;
	}

	int ncbStr = (cwData - 1) << 1;
	if (ncbStr > cbTag - 1)
		ncbStr = cbTag - 1;
	strncpy(lpTag, (LPSTR)(pwData + 1), ncbStr);
	lpTag[ncbStr] = 0;

	return ncbStr;
}

void SaveSprmStringValue(IAppendBuffer* pBuf, WORD sprm, LPSTR lpsz)
{
	int	cw, cbstr;

	cbstr = strlen(lpsz);
	if (cbstr & 1)			// Word alignment
		cbstr++;
	cw = (cbstr >> 1) + 1;	// With an encoding prefix word

	sprmWBuf[0] = sprm | (WORD)(_io_spra_variant << 14);
	sprmWBuf[1] = cw;
	sprmWBuf[2] = 0;		// SBCS/MBCS string, dafult charset
	pBuf->Add(&sprmWBuf, 6);
	pBuf->Add(lpsz, cbstr);
}

// -------------------------------------------------------------------------

HRESULT KNestedSprmList::Start(WORD* pData, int cw)
{
	ASSERT(pData != NULL);
	if (pData == NULL)
		return E_FAIL;

	m_pCur = m_pStart = pData;
	m_pEnd = pData + cw;

	return S_OK;
}

HRESULT KNestedSprmList::Start(WORD sprm, WORD* pData)
{
	ASSERT(pData != NULL);
	if (pData == NULL)
		return E_FAIL;

	int spra = IO_SPRM_SPRA(sprm);
	m_pStart = pData;
	switch(spra)
	{
	case _io_spra_word:
		m_pEnd = m_pStart + 1;
		break;
	case _io_spra_dword:
		m_pEnd = m_pStart + 2;
		break;
	case _io_spra_qword:
		m_pEnd = m_pStart + 4;
		break;
	case _io_spra_variant:
		m_pEnd = m_pStart + *m_pStart + 1;
		m_pStart++;
		break;
	default:
		ASSERT(0);
	}
	m_pCur = m_pStart;

	return S_OK;
}

HRESULT KNestedSprmList::MoveFirst()
{
	m_pCur = m_pStart;

	return m_pCur != NULL ? S_OK : S_FALSE;
}

HRESULT KNestedSprmList::Next(WORD& sprm, WORD*& pData)
{
	if (EndOfList())
		return E_FAIL;

	sprm = *m_pCur;
	pData = m_pCur + 1;

	m_pCur = (WORD*)MoveOverSprm(sprm, pData);

	return S_OK;
}

bool KNestedSprmList::EndOfList() const
{
	return m_pCur >= m_pEnd;
}

// -------------------------------------------------------------------------
}