/* -------------------------------------------------------------------------
//	�ļ���		��	testdoswps.cpp
//	������		��	������
//	����ʱ��	��	2005-4-1 10:37:20
//	��������	��	
//
//	$Id: testdoswps.cpp,v 1.1 2005/04/05 06:42:23 duanyuluo Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestDosWps : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestDosWps);
		CPPUNIT_TEST(testBasic);
		CPPUNIT_TEST(testBigFile);
		CPPUNIT_TEST(testCryptFile);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:

	void testBasic()
	{
		testWps2DocFile("doswps/S.wps", "_doswps_S_.doc");
		testWps2DocFile("doswps/SampleV2.wps", "_doswps_Sample_.doc");
	}
	void testBigFile()
	{
		testWps2DocFile("doswps/DQ.wps", "_doswps_DQ_.doc");
	}
	void testCryptFile()
	{
		testWps2DocFileEx("doswps/S00.wps", "_doswps_S00_.doc", L"WPS");
		testWps2DocFileEx("doswps/S1.wps", "_doswps_S1_.doc", L"LINDA");
		testWps2DocFileEx("doswps/SampleV4.wps", "_doswps_SampleV4_.doc", L"11");
		testWps2DocFileEx("doswps/DQM.wps", "_doswps_DQM_.doc", L"WINWPS");
	}
};  

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestDosWps);


// -------------------------------------------------------------------------
//	$Log: testdoswps.cpp,v $
//	Revision 1.1  2005/04/05 06:42:23  duanyuluo
//	*** empty log message ***
//	
