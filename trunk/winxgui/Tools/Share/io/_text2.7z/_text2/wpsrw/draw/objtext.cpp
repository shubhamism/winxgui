/* -------------------------------------------------------------------------
//	�ļ���		��	objtext.cpp
//	������		��	��־��
//	����ʱ��	��	2004-10-25 17:50:13
//	��������	��	
//
// -----------------------------------------------------------------------*/
//////////////////////////////////////////////////////////////////////////////////////

//	FileName		:	ObjText.cpp
//	FileAuthor		:	wdb
//	FileCreateDate	:	2000-7-5 16:17:06
//	FileDescription	:	multiline character

//////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "objtext.h"

#ifndef __FPBASE_H__
#include "fpbase.h"
#endif

#ifndef __TEXTSTRING_H__
#include <core/textstring.h>
#endif

#ifndef __CTRLCODE_H__
#include <core/ctrlcode.h>
#endif


TCHAR s_lpszDefCFont[]=_T("����"); //@@todo:Ӳ���룬ֻ�����ڼ������İ�
// char szGWCFontName[] = s_lpszDefCFont;
char szGWEFontName[] = "Times New Roman";
int KCP_WordToTextWord(LPTEXTWORD lptw, LPWORD lpw, int nLength);
extern DWORD g_dwLanguageVersion;

GWATTRIBSTRUCT defGWAttrib = {
	s_lpszDefCFont, szGWEFontName,
		NULL, NULL,
		6, FSU_SIZE,
		100,
		0, UNIT_METRIC,
		0, UNIT_METRIC,
		TAL_HCENTER | TAL_VCENTER,
		FW_NORMAL,
		CC_DISABLED,
		PS_NULL,
		PS_NULL,
		CC_DISABLED,
		CC_DISABLED, 5, 315, 0,
		0,
		0, RGB(255, 255, 255)
};

// ��������ֺŶ�Ӧ�������ߴ�
void GetFontSize(LPSTR, FONTSIZE&);
int CalcFontSize(WORD, int);
void GetSafeLFChn(char[], LPLOGFONT);
void GetSafeLFEng(char[], LPLOGFONT);
int GetCurCharWidth(int, BYTE = 0);
void OnKeyDownNewBlock(CWpsView*, CWPSObj*, int, CPoint*);
BOOL IsKeyDown(int);

int MStringToDMString(CString&);
int DMStringToMString(CString&, BOOL/*=FALSE*/);

void ReadProp(CObList* pList, KSArchive& ar);

BOOL CTextObj::m_bResetCaret = TRUE;
BOOL CTextObj::s_bDelCancelList = FALSE;
CFont CTextObj::m_fontChn;
CFont CTextObj::m_fontEng;
int CTextObj::m_nEngLeading;
int CTextObj::m_nChnLeading;
// CPtrArray CTextObj::s_TextLines;

IMPLEMENT_SERIAL(CTextObj, CFPBase, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)

CTextObj::CTextObj()
{
	m_wrapMode = wm_null;		
	m_pAttribList = NULL;
	//m_pTextObjSite = NULL;
	m_nHeadPos		= -1;		//	��ǰѡ�п�����ַ�������
	m_nTailPos		= -1;		//	��ǰ���ĩ�ַ�������
	m_nCurPos		= 0;		//	��ǰ�ַ��� m_string ���е�������
	m_nCurRowID		= 0;        //	��ǰ�ַ�������ʾ�� ID
	m_nHeadRowID	= 0;		//	��ǰ�����ַ������� ID
	m_nDelta = 0;
	m_bDefText		= FALSE;
	m_nEndShape[0] = es_none;
	m_nEndShape[1] = es_none;
	if (IsMengWen_Version(g_dwLanguageVersion))
		m_LineMode = vertl2r;
	else
		m_LineMode = horz;
	
	m_bAutoSizeObj = TRUE;
	m_bEnableField = TRUE;

	m_center.x = m_center.y = 0;
	m_theta = 0;
	
	m_bGWObj = FALSE;
    m_strGWDefaultText = "Ĭ������";
    m_nGWType = -1;
}

CTextObj::CTextObj(const CWpsDoc* pDoc, const CRect& rc)
	: CFPBase(pDoc, rc)
{
	m_wrapMode = wm_null;
	//	��Ӱ���(��ɫ)
	//SetShadowStyle(SW_PURE);
	m_shadowStyle = SW_PURE; //by Frank
	m_nHeight = 0;
	m_pAttribList = NULL;
	m_center = m_rect.CenterPoint();
	m_theta = 0;
	//m_pTextObjSite = NULL;
	m_nHeadPos		= -1;		//	��ǰѡ�п�����ַ�������
	m_nTailPos		= -1;		//	��ǰ���ĩ�ַ�������
	m_nCurPos		= 0;		//	��ǰ�ַ��� m_string ���е�������
	m_nCurRowID		= 0;        //	��ǰ�ַ�������ʾ�� ID
	m_nHeadRowID	= 0;		//	��ǰ�����ַ������� ID
	m_pntCurCrt  = CPoint(0, 0);
	m_pntHeadCrt = CPoint(0, 0);
	m_pntTail[0] = CPoint(0, 0);
	m_pntTail[1] = CPoint(0, 0);
	//	�˵���
	m_nEndShape[0] = es_none;
	m_nEndShape[1] = es_none;
	m_string.Empty();
	m_bResetCaret = FALSE;
	m_nDelta = 0;
	m_bDefText		= FALSE;
	if (IsMengWen_Version(g_dwLanguageVersion))
		m_LineMode = vertl2r;
	else
		m_LineMode = horz;

	m_bAutoSizeObj = TRUE;
	m_bEnableField = TRUE;

	m_center.x = m_center.y = 0;
	m_theta = 0;
	m_bGWObj = FALSE;
    m_strGWDefaultText = "Ĭ������";
    m_nGWType = -1;
}

CTextObj::~CTextObj()
{
	ASSERT(this);
	/*
	if (m_pTextObjSite)
	{
		ASSERT_VALID(m_pTextObjSite);
		delete m_pTextObjSite;
	}
	*/
	DeleteAttribList();

/*
	if (!s_bDelCancelList)
		ClearTextLines();	// ��ձ����� s_TextLines ����ʾ�ж���*/
#ifndef _WPSREADER
	DeleteImgContent();
#endif _WPSREADER
}

// ���ܣ�ɾ����������
void CTextObj::DeleteAttribList()
{
	if (m_pAttribList)
	{
		while (!m_pAttribList->IsEmpty())
			delete m_pAttribList->RemoveHead();
		delete m_pAttribList;
		m_pAttribList = NULL;
	}
}

void CTextObj::Serialize_97(CArchive&)
{
	ASSERT(FALSE);
}

void CTextObj::Serialize_98(CArchive& ar)
{
	ASSERT_VALID(this);
	CFPBase::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_string;
		ar << m_pAttribList;
	}
	else
#endif	// _WPSREADER
	{
		CString strTemp;							// for GB18030
		ar >> strTemp;

		//˫�ֽ�CString��KSTextString��ת��
		LPCTSTR lpszOld = (LPCTSTR)strTemp;
		int nStrLen;
		for (nStrLen = 0; lpszOld[nStrLen]; nStrLen += 2);
		nStrLen = nStrLen / 2;//˫�ֽ��ַ������˵����׵�'\r'

		LPTEXTWORD lptwBuffer = new TEXTWORD[nStrLen + 1];
		VERIFY(nStrLen == KCP_WordToTextWord(lptwBuffer,
				(LPWORD)(LPCTSTR)strTemp, nStrLen));
		m_string.Insert(0, lptwBuffer, nStrLen);
		delete lptwBuffer;
		//end ˫�ֽ�CString��KSTextString��ת��

		ar >> m_pAttribList;
	}
}

#ifndef _GWSREADER
typedef void (WINAPI* CONVPROCW)(LPWORD,DWORD);
extern CONVPROCW g_lpConvProcW;		// ��������ʱ�Ƿ���Ҫת������
#endif	// #ifndef _GWSREADER

void MakeTextStringWithBOOL(KSTextString&, BOOL);
BOOL ParseTextStringWithBOOL(KSTextString&);
void MakeTBLELEM_LineMode(KSTextString&, TextLineMode);
TextLineMode ParseTBLELEM_LineMode(KSTextString&);

class _CTextObj : public CTextObj
{
public:
	STDMETHODIMP Serialize_Write_02(CArchive& ar);
	STDMETHODIMP Serialize_Read_02(CArchive& ar);
};

STDMETHODIMP TextObj_Serialize_Write_02(CObList& AttrList, CArchive& ar);
STDMETHODIMP TextObj_Serialize_Read_02(CObList& AttrList, CArchive& ar);

STDMETHODIMP _CTextObj::Serialize_Write_02(CArchive& ar)
{
	WPSTextObjData rec;
	ZeroMemory(&rec, sizeof(rec));
	rec.LineMode	= m_LineMode;
	rec.fDefText	= m_bDefText;
	rec.ptCenter	= m_center;
	rec.theta		= m_theta;
	rec.fHasAttr	= (m_pAttribList && m_pAttribList->GetCount() ? 1 : 0);
	rec.bEnableField = m_bEnableField;	// wdb[2002-9-25]
	__WPSWriteRecord(ar, TAG_WPSTextObjData, rec);
	
	ar << m_string;
	if (rec.fHasAttr)
		TextObj_Serialize_Write_02(*m_pAttribList, ar);
	return S_OK;
}

STDMETHODIMP _CTextObj::Serialize_Read_02(CArchive& ar)
{
	HRESULT hr;
	WPSTextObjData rec;
	rec.bEnableField = TRUE;
	hr = ReadWPSRecord<TAG_WPSTextObjData>(ar, rec);
	if (hr == S_OK)
	{
		m_LineMode	= (TextLineMode)rec.LineMode;
		m_bDefText	= rec.fDefText;
		m_center	= rec.ptCenter;
		m_theta		= rec.theta;
		m_bEnableField = rec.bEnableField; // wdb[2002-9-25]
	}
	ar >> m_string;
	m_pAttribList = new CObList;
	if (rec.fHasAttr == 1)
		TextObj_Serialize_Read_02(*m_pAttribList, ar);
	return S_OK;
}


#define GWOBJ_HEAD          "{_WPSGWBOBJ_}"
#define GWOBJ_VERSION       "{VERSION:"
#define GWOBJ_CUR_VERSION   "2003"
#define GWOBJ_TYPE          "{TYPE:"
#define GWOBJ_DEFTEXT       "{DEFAULTTEXT:"
void TextStringToString(CString& str, KSTextString& tstr);

void CTextObj::Serialize_01(CArchive& ar)
{
	CFPBase::Serialize_01(ar);
	if (ar.IsStoring())
	{
		// Added by Cny 2004.3.15
        // ����Ӧ�Ĺ��Ķ�������ݷŵ�Hash�������档
        //
        if (IsGWObj())
        {
            CString strData(GWOBJ_HEAD);
            strData += GWOBJ_VERSION;
            strData += GWOBJ_CUR_VERSION;
            strData += "}";
            strData += GWOBJ_TYPE;
            TCHAR buffer[100];
            itoa(GetGWObjType(), buffer, 10);

            strData += buffer;
            strData += "}";
            strData += GWOBJ_DEFTEXT;

            KSTextString strGWDefText;
            GetGWObjDefString(strGWDefText);
            CString strResult;
            TextStringToString(strResult, strGWDefText);

            int nStringLength = 0;
            nStringLength = strResult.GetLength();

            itoa(nStringLength, buffer, 10);
        
            strData += buffer;
            strData += ":";

            strData += strResult;
            strData += "}";
        
			//by Frank
            //BSTR bstrData = strData.AllocSysString();
            //m_pDocument->ShapeAttachBSTRData(GetObjID(), bstrData);
        }
        //<<-----------------------------------

        if (g_fCompoundFile) // wps2002-io-beta2, bugfix, by tsingbo
		{
			((_CTextObj*)this)->Serialize_Write_02(ar);
			return;
		}
		KSTextString strText = m_string;
		MakeTBLELEM_LineMode(strText, m_LineMode);	//��������Ϣ
		MakeTextStringWithBOOL(strText, m_bDefText);	//��Ĭ��������Ϣ����
		ar << strText;

		ar << m_pAttribList;
		ar << m_center;
		ar << m_theta;
	}
	else
	{
		if (g_fWpsObjBeta2)	// wps2002-io-beta2, bugfix, by tsingbo
		{
			((_CTextObj*)this)->Serialize_Read_02(ar);
			return;
		}
		ar >> m_string;
		m_bDefText = ::ParseTextStringWithBOOL(m_string);	//��ȡĬ��������Ϣ
		m_LineMode = ParseTBLELEM_LineMode(m_string);	//��������Ϣ
		ar >> m_pAttribList;
		ar >> m_center;
		ar >> m_theta;
	}
}

// ��������ֺŶ�Ӧ�������ߴ�
int CalcFontSize(WORD wUnit, int n)
{
	if (wUnit == FSU_POUND)
	{
		ASSERT(n >= FS_MINPOUND && n <= FS_MAXPOUND);
		n = MulDiv(n, 2540, 72);
	}
	else
	{
		extern int uFontSize [15];
		ASSERT(n >= 0 && n <= 14);
		n = uFontSize[n];
	}
	ASSERT(n > 0);
	return n;
}

IMPLEMENT_SERIAL(CRotateText, CTextObj, WPS_VERSION_SCHEMA | VERSIONABLE_SCHEMA)

CRotateText::CRotateText()
{
	m_wpsObjType = MultitextRect;
	m_uLPenSize  = PLW_DEFSIZE;  //�߳ߴ�

	m_bFirst = FALSE;
	::memset(&m_ccHSS, 0, sizeof(CHARFXHSS));
	m_nFlipMode = 0;	//	����
}

CRotateText::CRotateText(const CWpsDoc* pDoc, const CRect& rc, int nShape)
	: CTextObj(pDoc, rc)
{
	SetWPSObjType(MultitextRect);  // �������ֶ���ı�־
	m_nMultitxtShape = nShape;
	m_nTempTheta = 0;
	m_bFirst = FALSE;
	m_nFlipMode = 0;	//	����
	m_uLPenSize  = PLW_DEFSIZE;  //�߳ߴ�
	if (nShape == rectangle 
		|| nShape >= 1000)
		m_uLPenStyle = PS_NULL;
	else
		m_uLPenStyle = PS_INSIDEFRAME;	//	�������
	m_LPenColor = 0;//KColorModel::RefToIndex(RGB(0,0,0));			//	��ɫ
	m_shadowPnt = CPoint(0,0);			//	��Ӱƫ������
	m_shadowColor = RGB(192,192,192);//KColorModel::RefToIndex(RGB(192,192,192));	//	��Ӱɫ
	m_shadowStyle = CFPBase::SW_PURE;	//	��Ӱ���(��ɫ)
	m_bLock = FALSE;						//	��������

	::memset(&m_ccHSS, 0, sizeof(CHARFXHSS));

	int nRnd = min(60, min(rc.Height()/2, rc.Width()/2));

	switch(	m_nMultitxtShape)
	{	
	case  rectangle:
		SetLPenStyle(PS_NULL);
		break;
	case  ellipsecomment:
		m_activePnt.x = -100;		//����ڶ����m_rect�����½�
		m_activePnt.y = 100;
		break;
	case   roundrect:				//Բ�Ǿ���
		m_roundnessPnt.x = nRnd;	//����ڶ����m_rect�����Ͻ�
		m_roundnessPnt.y = nRnd;
		break;
	case roundrectcomment:
		m_activePnt.x = -100;		//����ڶ����m_rect�����½�
		m_activePnt.y = 100;
		m_roundnessPnt.x = nRnd;	//����ڶ����m_rect�����Ͻ�
		m_roundnessPnt.y = nRnd;
		break;
	case rectcomment:
		m_activePnt.x = -100;		//����ڶ����m_rect�����½�
		m_activePnt.y = 100;
		break;
	case sizecomment:
		SetEndShape(0, CWPSObj::sa_1); 
		SetEndShape(1, CWPSObj::sa_1);
		break;
	case para: 
	case trap:
	case trapi:
		m_activePnt.x = m_rect.Width()/4;  //����ڶ����m_rect�����Ͻ�
		m_activePnt.y = 0;
		m_nDirection = enumUP;
		break;
	case cross:
		m_activePnt.x = m_rect.Width()/3;  //����ڶ����m_rect�����Ͻ�
		m_activePnt.y = m_rect.Height()/3;
		break;
	case arrow:
		m_activePnt.x = m_rect.Width()/2;  //����ڶ����m_rect�����Ͻ�
		m_activePnt.y = m_rect.Height()/3;
		m_nDirection = enumRIGHT;
		break;
	default:
		break;
	}
}

#ifndef _WPSREADER

void CRotateText::SetEndShape(int id, int nEndShape)
{
	if (m_nMultitxtShape == sizecomment)
		m_nEndShape[id] = nEndShape;
	else
		CTextObj::SetEndShape(id, nEndShape);
}

#endif// _WPSREADER

CRotateText::~CRotateText()
{
}


void CRotateText::Serialize_97(CArchive&)
{
	ASSERT(FALSE);
}

void CRotateText::Serialize_98(CArchive& ar)
{
	ASSERT_VALID(this);
	CTextObj::Serialize_98(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_theta;
	}
	else
#endif	// _WPSREADER
	{
		ar >> m_theta;
	}
	CWPSObj::SerializeObjType(ar);
}

void CRotateText::Serialize_01(CArchive& ar)
{
	CTextObj::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << m_nTempTheta;
		ar << m_nMultitxtShape;
		if (m_nMultitxtShape == trap || 
			m_nMultitxtShape == trapi ||	///sjz 2000-11-14
			m_nMultitxtShape == para ||
			m_nMultitxtShape == ellipsecomment || 
			m_nMultitxtShape == rectcomment ||
			m_nMultitxtShape == cross ||
			m_nMultitxtShape == arrow)
			ar << m_activePnt;	//	��ע�����õ��Ŀ��϶���

		if (m_nMultitxtShape == roundrect)
			ar << m_roundnessPnt;
		if (m_nMultitxtShape == roundrectcomment)
		{ 
			ar << m_activePnt;
		    ar << m_roundnessPnt;
		}
		ar << m_nFlipMode;
		if (m_nMultitxtShape == trap ||
			m_nMultitxtShape == trapi ||///sjz 2000-11-14
			m_nMultitxtShape == para ||
			m_nMultitxtShape == arrow)
			ar << m_nDirection;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		ar >> m_nTempTheta;
		ar >> m_nMultitxtShape;
		if (m_nMultitxtShape == trap ||
			m_nMultitxtShape == trapi ||///sjz 2000-11-14
			m_nMultitxtShape == para ||
			m_nMultitxtShape == ellipsecomment ||
			m_nMultitxtShape == rectcomment ||
			m_nMultitxtShape == cross ||
			m_nMultitxtShape == arrow)
			ar >> m_activePnt;	//��ע�����õ��Ŀ��϶���

		if (m_nMultitxtShape == roundrect)
			ar >> m_roundnessPnt;

		if (m_nMultitxtShape == roundrectcomment)
		{  
		   ar >> m_activePnt;
		   ar >> m_roundnessPnt;
		}

		//���û����һ�䣬�ߴ��ע�ı�ע�߻�û�м�ͷ(wxb)
		if (sizecomment == m_nMultitxtShape)
		{
			SetEndShape(0, CWPSObj::sa_1); 
			SetEndShape(1, CWPSObj::sa_1);
		}

		ar >> m_nFlipMode;
		if (m_nMultitxtShape == trap ||
			m_nMultitxtShape == trapi ||///sjz 2000-11-14
			m_nMultitxtShape == para ||
			m_nMultitxtShape == arrow)
			ar >> m_nDirection;

		// added by duyuesheng
//		CObList attrList;
//		::ReadProp(&attrList, ar);
//		ASSERT(attrList.GetCount() == 1);
//		CObject *pObj = attrList.GetHead();
//		ASSERT(pObj);
//		ASSERT(pObj->IsKindOf(RUNTIME_CLASS(CCtrlCode_HSS)));
//		CCtrlCode_HSS *pHSS = (CCtrlCode_HSS*)pObj;
//		m_ccHSS = *pHSS->GetData();		
	}
	CWPSObj::SerializeObjType(ar);
}

#ifndef _WPSREADER
BOOL IsDefGWAttrib(CCtrlCode* pCode)
{
	//@@done:�����ᵼ�����е�ȱʡ���Ա�д�뵽WORD�У�
	//������һ��࣬�����ǵ�WORD��WPS��ȱʡֵ���ܲ���һ�£������������Ҫ����ΪFALSE
	return FALSE;
}
#endif