/* -------------------------------------------------------------------------
//	�ļ���		��	autonum_atom.cpp
//	������		��	����
//	����ʱ��	��	2004-10-28 9:28:49 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "autonum_atom.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#define		defKTABLENGTH	0x02E4		//TAB�����ȣ���λ
void tagAUTONUMATOM::Init()
{
	lAutoNumType					= enumAutoNumTypeUnknown;

	lAutoNumAlignVert				= enumAutoNumVertpos2LineMid;
	lAutoNumNormalTextToFirstIndent	= defKTABLENGTH;	// defAUTONUM_DEFALTDISTTOTEXT;
	lAutoNumMinDistanceToNormalText	= 0;

	::memcpy(&AutoNumCharAttrib, &wpsDefSenAttrib, sizeof(SENATTRIBSTRUCT));

#ifdef WPP_ONLY
	lAutoNumAlignHorz				= enumAutoNumHorzposLeft2Indent | enumAutoNumHorzposMid2Text;
	lAutoNumCharAttribFlag			= enumAutoNumShowUseFirSenAttrAll;
	lAutoNumCharShowScale			= 37; //37%
#else
	lAutoNumAlignHorz				= enumAutoNumHorzposLeft2Indent | enumAutoNumHorzposLeft2Text;
	AutoNumCharAttrib.clrText		= RGB(0, 0, 0);		// Ĭ�Ϻ���
	lAutoNumCharAttribFlag			= enumAutoNumShowUseOwnAttrib;
	lAutoNumCharShowScale			= 100;
#endif //WPP_ONLY

	::memset(twAutoNumFormat,	0, sizeof(TEXTWORD) * defMAXAUTONUMFORMATLEN);
	::memset(twAutoNumContent,	0, sizeof(TEXTWORD) * defMAXAUTONUMCONTENTLEN);
	dwAutoNumPictureBulletID		= (DWORD)-1;

	lAutoNumStartAt					= 1;
	lAutoNumStep					= 1;
	lNumberFlag						= enumAutoNumSonLevelRestart;

	AutoNumParaAttrib.wAutoNumPA_FirIndentUnit	= UNIT_METRIC;
	AutoNumParaAttrib.lAutoNumPA_FirstIndent	= 0;
	AutoNumParaAttrib.wAutoNumPA_LeftIndentUnit	= UNIT_METRIC;
	AutoNumParaAttrib.lAutoNumPA_LeftIndent		= 0;
}

// ע����ʹ�õĺ����в�����
extern int CompareDCA(const SENATTRIBSTRUCT& src,
					  const SENATTRIBSTRUCT& dest,
					  DWORD dwFilter);
BOOL operator==(const tagAUTONUMATOM& src, const tagAUTONUMATOM& data)
{
	if (&src == &data)
		return TRUE;

	if (src.lAutoNumType == enumAutoNumTypeBulletPic)
	{
		if (data.lAutoNumType					!= enumAutoNumTypeBulletPic				|| 
			src.lAutoNumAlignHorz				!= data.lAutoNumAlignHorz				|| 
			src.lAutoNumAlignVert				!= data.lAutoNumAlignVert				|| 
			src.lAutoNumNormalTextToFirstIndent	!= data.lAutoNumNormalTextToFirstIndent	|| 
			src.lAutoNumMinDistanceToNormalText	!= data.lAutoNumMinDistanceToNormalText	|| 
			src.dwAutoNumPictureBulletID		!= data.dwAutoNumPictureBulletID)
			return FALSE;
		else
			return TRUE;
	}
	else
	{
		if (src.lAutoNumCharAttribFlag != data.lAutoNumCharAttribFlag || 
			src.lAutoNumCharShowScale != data.lAutoNumCharShowScale)
			return FALSE;

		if (enumAutoNumShowUseOwnAttrib == src.lAutoNumCharAttribFlag)
		{
			if (CompareDCA(src.AutoNumCharAttrib, data.AutoNumCharAttrib,
				CAS_CFONT		| CAS_EFONT			| CAS_FONTSIZE	| 
				CAS_TEXTCOLOR	| CAS_ASPECTRATIO	| CAS_TRACK		|
				CAS_BOLD		| CAS_ITALIC		| CAS_UNDERLINE	|
				CAS_UPPERLINE	| CAS_STRIKEOUT		| CAS_STRESS	|
				CAS_SSSCRIPT	| CAS_HSS			| CAS_OUTRECT	|
				CAS_BGVEIN))
			return FALSE;
		}

		if (::memcmp(&src.AutoNumParaAttrib,&data.AutoNumParaAttrib,sizeof(AUTONUMATOM_PARAPOS)))
			return FALSE;
		if (::memcmp(src.twAutoNumFormat,	data.twAutoNumFormat,	defMAXAUTONUMFORMATLEN * sizeof(TEXTWORD)))
			return FALSE;
		if (::memcmp(src.twAutoNumContent,	data.twAutoNumContent,	defMAXAUTONUMCONTENTLEN * sizeof(TEXTWORD)))
			return FALSE;
		if (src.lAutoNumType					!= data.lAutoNumType					|| 
			src.lAutoNumAlignHorz				!= data.lAutoNumAlignHorz				|| 
			src.lAutoNumAlignVert				!= data.lAutoNumAlignVert				|| 
			src.lAutoNumNormalTextToFirstIndent	!= data.lAutoNumNormalTextToFirstIndent	|| 
			src.lAutoNumMinDistanceToNormalText	!= data.lAutoNumMinDistanceToNormalText)
			return FALSE;

		if (src.lAutoNumType == enumAutoNumTypeNumbered)
		{
			if (src.lAutoNumStartAt		!= data.lAutoNumStartAt	|| 
				src.lAutoNumStep		!= data.lAutoNumStep	|| 
				src.lNumberFlag			!= data.lNumberFlag)
				return FALSE;
		}

		return TRUE;
	}
}

BOOL operator!=(const tagAUTONUMATOM& data0, const tagAUTONUMATOM& data1)
{
	return !(data0 == data1);
}

const tagAUTONUMATOM& tagAUTONUMATOM::operator=(const tagAUTONUMATOM& data)
{
	if (&data != this)
	{
		::memcpy(this, &data, sizeof(tagAUTONUMATOM));
	}
	return *this;
}

const tagAUTONUMATOM& tagAUTONUMATOM::operator=(const tagAUTONUMATOM_FORIO& data)
{
	lAutoNumType						= data.m_lAutoNumType;
	lAutoNumAlignHorz					= data.m_lAutoNumALignHorz;
	lAutoNumAlignVert					= data.m_lAutoNumAlignVert;
	lAutoNumNormalTextToFirstIndent		= data.m_lAutoNumNormalTextToFirstIndent;
	lAutoNumMinDistanceToNormalText		= data.m_lAutoNumMinDistanceToNormalText;

	::lstrcpyn(AutoNumCharAttrib.szCFontNameH, data.m_AutoNumCharAttrib.m_szCFontNameH, LF_FACESIZE);
	::lstrcpyn(AutoNumCharAttrib.szEFontName, data.m_AutoNumCharAttrib.m_szEFontName, LF_FACESIZE);
	AutoNumCharAttrib.nFontSize			= data.m_AutoNumCharAttrib.m_nFontSize;
	AutoNumCharAttrib.wFontSizeUnit		= data.m_AutoNumCharAttrib.m_wFontSizeUnit;
	AutoNumCharAttrib.wAspectRatio		= data.m_AutoNumCharAttrib.m_wAspectRatio;
	AutoNumCharAttrib.nTrack			= data.m_AutoNumCharAttrib.m_nTrack;
	AutoNumCharAttrib.wTrackUnit		= data.m_AutoNumCharAttrib.m_wTrackUnit;
	AutoNumCharAttrib.nBold				= data.m_AutoNumCharAttrib.m_nBold;
	AutoNumCharAttrib.nItalic			= data.m_AutoNumCharAttrib.m_nItalic;
	AutoNumCharAttrib.wUnderLine		= data.m_AutoNumCharAttrib.m_wUnderLine;
	AutoNumCharAttrib.wUpperLine		= data.m_AutoNumCharAttrib.m_wUpperLine;
	AutoNumCharAttrib.nStrikeOut		= data.m_AutoNumCharAttrib.m_nStrikeOut;
	AutoNumCharAttrib.wStress			= data.m_AutoNumCharAttrib.m_wStress;
	AutoNumCharAttrib.nRelativeHeight	= data.m_AutoNumCharAttrib.m_nRelativeHeight;
	AutoNumCharAttrib.nRelativeShift	= data.m_AutoNumCharAttrib.m_nRelativeShift;
	AutoNumCharAttrib.nHSS				= data.m_AutoNumCharAttrib.m_nHSS;
	AutoNumCharAttrib.nDepth			= data.m_AutoNumCharAttrib.m_nDepth;
	AutoNumCharAttrib.nDegree			= data.m_AutoNumCharAttrib.m_nDegree;
	AutoNumCharAttrib.nShadeType		= data.m_AutoNumCharAttrib.m_nShadeType;
	AutoNumCharAttrib.clrText			= data.m_AutoNumCharAttrib.m_clrText;
	AutoNumCharAttrib.clrUnderLine		= data.m_AutoNumCharAttrib.m_clrUnderLine;
	AutoNumCharAttrib.clrUpperLine		= data.m_AutoNumCharAttrib.m_clrUpperLine;
	AutoNumCharAttrib.clrStress			= data.m_AutoNumCharAttrib.m_clrStress;
	AutoNumCharAttrib.clrTransFrom		= data.m_AutoNumCharAttrib.m_clrTransFrom;
	AutoNumCharAttrib.clrTransTo		= data.m_AutoNumCharAttrib.m_clrTransTo;
	lAutoNumCharAttribFlag				= data.m_lAutoNumCharAttribFlag;
	lAutoNumCharShowScale				= data.m_lAutoNumCharShowScale;
	::memcpy(&AutoNumCharAttrib.OUTRECTData, &data.m_AutoNumCharAttrib.m_OutRect, sizeof(OUTRECT));
	::memcpy(&AutoNumCharAttrib.BGVEINData, &data.m_AutoNumCharAttrib.m_Bgvein, sizeof(BGVEIN));
	
	::memcpy(twAutoNumFormat, data.m_twAutoNumFormat, sizeof(TEXTWORD) * defMAXAUTONUMFORMATLEN);
	::memcpy(twAutoNumContent, data.m_twAutoNumContent, sizeof(TEXTWORD) * defMAXAUTONUMCONTENTLEN);
	dwAutoNumPictureBulletID			= data.m_dwAutoNumPictureBulletID;
	lAutoNumStartAt						= data.m_lAutoNumStartAt;
	lAutoNumStep						= data.m_lAutoNumStep;
	lNumberFlag							= data.m_lNumberFlag;
	::memcpy(&AutoNumParaAttrib, &data.m_AutoNumParaAttrib, sizeof(AUTONUMATOM_PARAPOS));
	return *this;
}

// -------------------------------------------------------------------------

HRESULT g_LoadSenstruct(IStream* pStrm, SENATTRIBSTRUCT_FORIO& data)
{
	HRESULT hr	= S_OK;

	// LF_FACESIZE == 32
	hr	= pStrm->Read(data.m_szCFontNameH,	LF_FACESIZE * sizeof(data.m_szCFontNameH[0]),	NULL);
	hr	= pStrm->Read(data.m_szEFontName,	LF_FACESIZE * sizeof(data.m_szEFontName[0]),	NULL);
	hr	= pStrm->Read(&data.m_nFontSize,				sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_wFontSizeUnit,			sizeof(WORD),	NULL);
	hr	= pStrm->Read(&data.m_wAspectRatio,				sizeof(WORD),	NULL);
	hr	= pStrm->Read(&data.m_nTrack,					sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_wTrackUnit,				sizeof(WORD),	NULL);
	hr	= pStrm->Read(&data.m_nBold,					sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_nItalic,					sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_wUnderLine,				sizeof(WORD),	NULL);
	hr	= pStrm->Read(&data.m_wUpperLine,				sizeof(WORD),	NULL);
	hr	= pStrm->Read(&data.m_nStrikeOut,				sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_wStress,					sizeof(WORD),	NULL);
	hr	= pStrm->Read(&data.m_nRelativeHeight,			sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_nRelativeShift,			sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_nHSS,						sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_nDepth,					sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_nDegree,					sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_nShadeType,				sizeof(int),	NULL);
	hr	= pStrm->Read(&((DWORD)data.m_clrText),			sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&((DWORD)data.m_clrUnderLine),	sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&((DWORD)data.m_clrUpperLine),	sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&((DWORD)data.m_clrStress),		sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&((DWORD)data.m_clrTransFrom),	sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&((DWORD)data.m_clrTransTo),		sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&data.m_OutRect.dwColor,			sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&data.m_OutRect.nPenStyle,		sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_OutRect.nWidth,			sizeof(int),	NULL);
	hr	= pStrm->Read(&data.m_Bgvein.dwColor,			sizeof(DWORD),	NULL);
	hr	= pStrm->Read(&data.m_Bgvein.nBrushStyle,		sizeof(int),	NULL);

	return hr;
}

HRESULT g_LoadAutoNumAtom(IStream* pStrm, AUTONUMATOM_FORIO& data)
{
	HRESULT hr	= S_OK;

	hr	= pStrm->Read(&data.m_lAutoNumType,			sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lAutoNumALignHorz,	sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lAutoNumAlignVert,	sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lAutoNumNormalTextToFirstIndent, sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lAutoNumMinDistanceToNormalText, sizeof(LONG), NULL);

	hr	= g_LoadSenstruct(pStrm, data.m_AutoNumCharAttrib);
	hr	= pStrm->Read(&data.m_lAutoNumCharAttribFlag,	sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lAutoNumCharShowScale,	sizeof(LONG), NULL);

	int nLen	= 0;
	hr	= pStrm->Read(&nLen, sizeof(int), NULL);
	if (nLen > defMAXAUTONUMFORMATLEN)
	{
		ASSERT(0);
		::ReportWPSSaveLoadException(200);
	}
	if (nLen > 0)
		hr	= pStrm->Read(data.m_twAutoNumFormat, nLen * sizeof(TEXTWORD), NULL);
	if (nLen >= 0 && 
		nLen < defMAXAUTONUMFORMATLEN)
		data.m_twAutoNumFormat[nLen]	= 0;

	hr	= pStrm->Read(&nLen, sizeof(int), NULL);
	if (nLen > defMAXAUTONUMCONTENTLEN)
	{
		ASSERT(0);
		::ReportWPSSaveLoadException(200);
	}
	if (nLen > 0)
		hr	= pStrm->Read(data.m_twAutoNumContent, nLen * sizeof(TEXTWORD), NULL);
	if (nLen >= 0 && 
		nLen < defMAXAUTONUMCONTENTLEN)
		data.m_twAutoNumContent[nLen]	= 0;
	hr	= pStrm->Read(&data.m_dwAutoNumPictureBulletID, sizeof(DWORD), NULL);

	hr	= pStrm->Read(&data.m_lAutoNumStartAt,	sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lAutoNumStep,		sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_lNumberFlag,		sizeof(LONG), NULL);

	hr	= pStrm->Read(&data.m_AutoNumParaAttrib.lAutoNumPA_FirstIndent,		sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_AutoNumParaAttrib.lAutoNumPA_LeftIndent,		sizeof(LONG), NULL);
	hr	= pStrm->Read(&data.m_AutoNumParaAttrib.wAutoNumPA_FirIndentUnit,	sizeof(WORD), NULL);
	hr	= pStrm->Read(&data.m_AutoNumParaAttrib.wAutoNumPA_LeftIndentUnit,	sizeof(WORD), NULL);

	return hr;
}
