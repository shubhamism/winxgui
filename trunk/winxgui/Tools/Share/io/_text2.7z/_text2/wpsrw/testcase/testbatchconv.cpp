/* -------------------------------------------------------------------------
//	�ļ���		��	testbatchconv.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-28 9:44:40
//	��������	��	
//
//	$Id: testbatchconv.cpp,v 1.4 2005/01/07 09:57:44 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP SDDoConvert(
						 IN LPCWSTR szFile,
						 IN SD_FILEINFO_ARG fiArg,
						 IN LPVOID pParam)
{
	WCHAR szDestFile[_MAX_PATH];
	
	LPCWSTR szDot = wcsrchr(szFile, '.');
	if (szDot == NULL || wcsicmp(szDot, __X(".wps")) != 0)
		return S_OK;

	USES_CONVERSION;
	LPCWSTR szFileName = wcsrchr(szFile, '/') + 1;
	printf("\nprocessing %s ...", W2A(szFileName));
	
	memcpy(
		szDestFile,
		szFile,
		(szDot - szFile)*sizeof(WCHAR));
	
	wcscpy(
		szDestFile + (szDot - szFile),
		__X(".doc"));
	
	HRESULT hr = WpsConvert(
		szFile,
		szDestFile);
	
	ASSERT_OK(hr);	
	return S_OK;
}

class TestBatchConv : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestBatchConv);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
		const WCHAR szDir[] = testWpsPath("�ۺ�");///����WPS��������/wps�����ļ�/����");

		WCHAR szSrcDir[_MAX_PATH];		
		_XScanDirectory(
			GetSystemIniPath(szSrcDir, szDir),
			SDDoConvert,
			0, //���Ҫ������Ŀ¼���ã�SD_SCAN_SUBDIR
			0);
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestBatchConv);

// -------------------------------------------------------------------------
//	$Log: testbatchconv.cpp,v $
//	Revision 1.4  2005/01/07 09:57:44  wangdong
//	*** empty log message ***
//	
//	Revision 1.3  2005/01/06 08:37:21  wangdong
//	*** empty log message ***
//	
//	Revision 1.2  2004/12/29 08:33:55  wangdong
//	*** empty log message ***
//	
//	Revision 1.1  2004/12/28 02:04:33  xushiwei
//	*** empty log message ***
//	
