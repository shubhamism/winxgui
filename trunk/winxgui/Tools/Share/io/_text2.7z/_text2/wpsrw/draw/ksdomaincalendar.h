//////////////////////////////////////////////////////////////////////////////////////
//	FileName		:	KSDomainCalendar.h
//	FileAuthor		:	wdb
//	FileCreateDate	:	00-5-31 16:12:38
//	FileDescription	:	
//
//////////////////////////////////////////////////////////////////////////////////////


// KSDomainCalendar.h: interface for the KSDomainCalendar class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __KSDOMAINCALENDAR_H__
#define __KSDOMAINCALENDAR_H__


#ifndef __AFXDTCTL_H__
#include "afxdtctl.h"
#endif
#include "Ptobj.h"  
class KSDomainCalendar : public CLtxtObj  
{
	
protected:
	DECLARE_SERIAL(KSDomainCalendar);
	KSDomainCalendar();
	
public:
	KSDomainCalendar(const CWpsDoc* pDoc, const CRect& position, int nShape);
	virtual ~KSDomainCalendar();
	
	//	copy struct
	KSDomainCalendar( const KSDomainCalendar* obj );
public:
	CString   m_sSelectDate;	//	save the calendar selected date 
	int       m_nStyleIndex;	//	format index 
	int       m_nTimeIndex;		//  time index
	BOOL      m_bCheckTime;
	//	CMonthView*  m_pMonthView;//�����ؼ�amend:wdb
	CMonthCalCtrl* m_pMonthView;
	//	BOOL m_bEnableField;		// û�б��棬������ֻ����ReadOnly ״̬�´β���Ч
	/*
	public:
	void SetMonthView(CMonthView* pMonthView) {m_pMonthView = pMonthView;}
	CMonthView* GetMonthView(){return m_pMonthView;}*/
	
private:
	BOOL  m_bSelect;	//	KSDomainCalendar is selected
	BOOL  m_bBackGround; 
	
public:
	virtual void Serialize_01(KSArchive& ar);
};

#endif // !defined(AFX_KSDOMAINCALENDAR_H__BBAD09E1_3709_11D4_A00C_5254AB1993A3__INCLUDED_)
