/* -------------------------------------------------------------------------
//	�ļ���		��	wpsapp.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 15:04:57
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPSAPP_H__
#define __WPSAPP_H__

#if !defined(AFX_KXCODEPAGEVI_H_INCLUDED_)
#include <codepage/KXCodePageVI.h>
#endif

#if !defined(AFX_KXGLOBALVI_H_INCLUDED_)
#include <codepage/KXGlobalVI.h>
#endif

#ifndef __PRINTER_H__
#include "printer.h"
#endif

// -------------------------------------------------------------------------
// CodePage

class KXGlobalVI;
class KXCodePageVI;

STDAPI_(int) InitDll_CPGBK(
						   KXGlobalVI* pKXGlobalVI,
						   KXCodePageVI** ppCodePageVI, 
						   DWORD dwLanguageVersion);

// -------------------------------------------------------------------------
// class KSGlobalVI

class KSGlobalVI : public KXGlobalVI
{
public:
	KSGlobalVI(KXScriptSheet* pScriptSheet, TEXTWORD Default_Outword)
		: KXGlobalVI(pScriptSheet, Default_Outword)
	{
	}
};

// -------------------------------------------------------------------------
// class KAddInCrypt

class KAddInCrypt
{
protected:
	HINSTANCE m_hDll;
	
public:
	KAddInCrypt() : m_hDll(NULL)
	{
	}
	~KAddInCrypt()
	{
		if (m_hDll)
			FreeLibrary(m_hDll);
	}

	HINSTANCE GetAddInInstance()
	{
		return m_hDll;
	}
};

// -------------------------------------------------------------------------
// class CWinwpsApp

class CWinwpsApp
{
private:
	CPrinter m_printer;
	
	BOOL InitializeCodePageVI();
	BOOL UnInitializeCodePageVI();

public:
	KAddInCrypt m_AddInCrypt;

	BOOL InitInstance();
	BOOL ExitInstance();
};

extern CWinwpsApp theApp;

// -------------------------------------------------------------------------

#endif /* __WPSAPP_H__ */
