/*********************************************************************
 *	����:		mci.cpp,CMciDevice��.
 *
 *	����:		ʵ������MCI�豸�Ļ��ࡣ
 *
 *	������:		����
 *
 *	��������:	98/10/16
 *
 *	������:		����
 *
 *	�޶�����:	99/04/26
 *
 *	��ע:
 *	 �ο������ַ:(http://www.codeguru.com)
 *********************************************************************/
#include "stdafx.h"

//#include "ResID_Cursor.h"

#include "mci.h"
class CWpsView;
class CWpsDoc;

BOOL IsKeyDown (int vKey);				//�ж������İ���.
//////////////////////////////////////////////////////////////////////////
// CMciDevice implementation
//
// MCI_STATUS_MODE ������ֵ.
const DWORD CMciDevice::s_ModeNotReady = MCI_MODE_NOT_READY;
const DWORD CMciDevice::s_ModePause	 = MCI_MODE_PAUSE;
const DWORD CMciDevice::s_ModePlay	 = MCI_MODE_PLAY;
const DWORD CMciDevice::s_ModeStop	 = MCI_MODE_STOP;
const DWORD CMciDevice::s_ModeOpen	 = MCI_MODE_OPEN;
const DWORD CMciDevice::s_ModeRecord	 = MCI_MODE_RECORD;
const DWORD CMciDevice::s_ModeSeek	 = MCI_MODE_SEEK;

// MCI_STATUS_PARMS ������dwitem�ֶε�ֵ.
const DWORD CMciDevice::s_StatusReady			 = MCI_STATUS_READY;
const DWORD CMciDevice::s_StatusMediaPresent	 = MCI_STATUS_MEDIA_PRESENT;
const DWORD CMciDevice::s_StatusMode			 = MCI_STATUS_MODE;
const DWORD CMciDevice::s_StatusNumberOfTracks = MCI_STATUS_NUMBER_OF_TRACKS;

//MCI_GETDEVCAPS_PARMS ������dwitem�ֶε�ֵ.
const DWORD CMciDevice::s_GetdevcapsCanEject	 = MCI_GETDEVCAPS_CAN_EJECT;
const DWORD CMciDevice::s_GetdevcapsCanPlay	 = MCI_GETDEVCAPS_CAN_PLAY;
const DWORD CMciDevice::s_GetdevcapsCanRecord	 = MCI_GETDEVCAPS_CAN_RECORD;
const DWORD CMciDevice::s_GetdevcapsCanSave	 = MCI_GETDEVCAPS_CAN_SAVE;
const DWORD CMciDevice::s_GetdevcapsCompound	 = MCI_GETDEVCAPS_COMPOUND_DEVICE;
const DWORD CMciDevice::s_GetdevcapsDeviceType = MCI_GETDEVCAPS_DEVICE_TYPE;
const DWORD CMciDevice::s_GetdevcapsHasAudio	 = MCI_GETDEVCAPS_HAS_AUDIO;
const DWORD CMciDevice::s_GetdevcapsHasVideo	 = MCI_GETDEVCAPS_HAS_VIDEO;
const DWORD CMciDevice::s_GetdevcapsUsesFiles	 = MCI_GETDEVCAPS_USES_FILES;

//mci�豸����Ϣ.
const DWORD CMciDevice::s_InfoProduct = MCI_INFO_PRODUCT;
const DWORD CMciDevice::s_InfoMediaIdentity = MCI_INFO_MEDIA_IDENTITY;

//mci�ĸ�������.
const DWORD CMciDevice::s_DevtypeAnimation	= MCI_DEVTYPE_ANIMATION;
const DWORD CMciDevice::s_DevtypeCdaudio		= MCI_DEVTYPE_CD_AUDIO;		
const DWORD CMciDevice::s_DevtypeDat			= MCI_DEVTYPE_DAT;		
const DWORD CMciDevice::s_DevtypeDigitalvideo = MCI_DEVTYPE_DIGITAL_VIDEO;
const DWORD CMciDevice::s_DevtypeOther		= MCI_DEVTYPE_OTHER;
const DWORD CMciDevice::s_DevtypeOverlay		= MCI_DEVTYPE_OVERLAY;	
const DWORD CMciDevice::s_DevtypeScanner		= MCI_DEVTYPE_SCANNER;	
const DWORD CMciDevice::s_DevtypeSequencer	= MCI_DEVTYPE_SEQUENCER;
const DWORD CMciDevice::s_DevtypeVcr			= MCI_DEVTYPE_VCR;
const DWORD CMciDevice::s_DevtypeVideodisc	= MCI_DEVTYPE_VIDEODISC;
const DWORD CMciDevice::s_DevtypeWaveaudio	= MCI_DEVTYPE_WAVEFORM_AUDIO;

//IMPLEMENT_SERIAL(CMciDevice, CFPBase, 98 | VERSIONABLE_SCHEMA)//	32λ�汾�Ķ����ʶ��Ϊ 98
IMPLEMENT_SERIAL(CMciDevice, CFPBase, 0xA0 | VERSIONABLE_SCHEMA)//	32λ�汾�Ķ����ʶ��Ϊ 98

///////////////////////////////////////////////////////////
//���캯��.
CMciDevice::CMciDevice() 
{
	m_wDeviceID = NULL;
	m_hMainWnd = NULL;
	m_bReportErrors = FALSE;
//	m_bReportErrors=TRUE;
	SetWPSObjType(WPSMCIDevice);
	
	m_bOpen = FALSE;
	m_bPlay = FALSE;
	m_bPause = FALSE;
}

//��������.
CMciDevice::~CMciDevice() 
{
}

void CMciDevice::Serialize_98 (KSArchive& ar)//����.
{
	CFPBase::Serialize_98 (ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << (DWORD)0;		// 8�ֽڻ���
		ar << (DWORD)0;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		DWORD dw1, dw2;
		ar >> dw1;		// 8�ֽڻ���
		ar >> dw2;
		// �ж϶���������Ƿ���Ч
		if (dw1 || dw2)
		{
			ASSERT (FALSE);
			AfxThrowArchiveException (CArchiveException::badIndex);
		}
	}
}

void CMciDevice::Serialize_01(KSArchive& ar)//����.
{
	CFPBase::Serialize_01(ar);
#ifndef _WPSREADER
	if (ar.IsStoring())
	{
		ar << (DWORD)0;		// 8�ֽڻ���
		ar << (DWORD)0;
	}
	else
#endif	// #ifndef _WPSREADER
	{
		DWORD dw1, dw2;
		ar >> dw1;		// 8�ֽڻ���
		ar >> dw2;
		// �ж϶���������Ƿ���Ч
		if (dw1 || dw2)
		{
			ASSERT (FALSE);
			AfxThrowArchiveException (CArchiveException::badIndex);
		}
	}
}

#ifdef _DEBUG
void CMciDevice::Dump(CDumpContext& dc) const
{
	CFPBase::Dump(dc);
	dc << "\nI'm a CWPSWndCtrl object.\n";
}
void CMciDevice::AssertValid() const
{
//	CFPBase::AssertValid();

//	if (m_hWnd)
//		ASSERT (::IsWindow(m_hWnd));
}
#endif //debug
