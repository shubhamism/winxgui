/* -------------------------------------------------------------------------
//	�ļ���		��	wppslidebase.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-28 12:53:04
//	��������	��
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "wppslide.h"
#include "wppdoc.h"
#include "wppframe.h"
#include <core/ctrlcodetool.h>
#include <core/style_text.h>
#include <core/stylesheet_text.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

CWPPSlideBase::CWPPSlideBase(
							 const CWPPDoc* pDoc,
							 const CRect& pRect,
							 int nSlideNum,
							 WORD nSlideNumOrg) :
	CWPSPage((CWpsDoc*)pDoc, pRect, nSlideNum, nSlideNumOrg)
{
	InitSlide();
}

CWPPSlideBase::~CWPPSlideBase()
{
	if (m_pICS)
	{
		m_pICS->Release();
		m_pICS = NULL;
	}

	ReleaseMemBgData();
}

//--------------------��ʼ������ start--------------------

void CWPPSlideBase::InitSlide()
{
	m_bIsWPPMaster = FALSE;//Ĭ��Ϊһ����ʾҳ

	m_pICS = NULL;

	m_Background.m_nFillType = enBG_SOLIDFILL;
	m_Background.m_clrSolid = enCSBg_Value;
	m_Background.m_ShadeCtrl.shadeDir = enSHADE_DIR_H;
	m_Background.m_ShadeCtrl.shadeStyle = enGRADSTYLE_LEFTBOTTOM;
	m_Background.m_ShadeCtrl.shadeColor[0] = enCSBg_Value;
	m_Background.m_ShadeCtrl.shadeColor[1] = enCSAccent_Value;
	m_Background.m_nImgId = -1;	//��ʾû��ͼ��

	//������ʾҳID��(�Ժ�Ͳ��ܱ���)
	m_dwSlideID = m_pDocument->GetObjIDCount();

	InitMemBgData();
}

/////////////////////////////////////////////////////////////////////////////
// CWPPSlideBase serialization

//������ʾҳ�Ķ��󶯻�˳������
BOOL CWPPSlideBase::RendingShowObjOrderList()
{
	POSITION pos = NULL;
	CWPSObj* pObj = NULL;
	bmDialogPara* pPresPara = NULL;

	//��������ѱ�ɾ��...
	POSITION posRemove = NULL;
	pos = m_lstShowObjOrder.GetHeadPosition();
	while (pos)
	{
		posRemove = pos;
		pObj = (CWPSObj*)m_lstShowObjOrder.GetNext(pos);
		ASSERT(pObj);
		if (m_WPSObjectList.Find(pObj) == FALSE)
		{
			m_lstShowObjOrder.RemoveAt(posRemove);
		}
	}

	//�����ж���Ч��������δ�ڶ��������еĶ���
	pos = m_WPSObjectList.GetHeadPosition();
	while (pos)
	{
		pObj = (CWPSObj*)m_WPSObjectList.GetNext(pos);
		ASSERT(pObj);
		pPresPara = pObj->GetPresPara();
		if (pPresPara->m_showType != show_normal)
		{
			//������ʼ��...
			//����Ѷ������...
			pPresPara->m_bShown = FALSE;
			pPresPara->m_nPresTextLastShowGroupID = -1;
			pPresPara->m_bHasOverCartoonEnd = FALSE;

			if (m_lstShowObjOrder.Find(pObj) == FALSE)
			{
				m_lstShowObjOrder.AddTail(pObj);
			}
		}
	}

	return TRUE;
}

void CWPPSlideBase::Serialize(CArchive& ar)
{
	CWPSPage::Serialize(ar);

	//�汳��
	m_Background._Serialize(ar);

	//����ǰ������ʾҳ�Ķ��󶯻�˳������
	if (ar.IsStoring())
	{
		RendingShowObjOrderList();
	}
	//LLG_TEMP_SAVE_2000_5_21
	//����������ȡ������������!Ӧ�����Id...�����������е�λ��...
	//��ʵ���ǿ��Եģ�ֻ���е��˷Ѷ���...
	m_lstShowObjOrder.Serialize(ar);

	//LLG_APPLYCOLORSCHEME_
	S_ColorScheme stCS;
	if (ar.IsStoring())
	{
		if (m_pICS)
		{
			m_pICS->GetColors(stCS.colors, D_CS_COLORSUM);
		}
		//��ɫ����
		ar.Write(&stCS, sizeof(S_ColorScheme));
		//ҳ����
		ar << m_strTitleName;
		//ҳID
		ar << m_dwSlideID;

	}
	else
	{
		//��ɫ����
		ar.Read(&stCS, sizeof(S_ColorScheme));
		//ҳ����
		ar >> m_strTitleName;
		//ҳID
		ar >> m_dwSlideID;

		//LLG_APPLYCOLORSCHEME_
		::gCoCreateColorScheme(D_CS_COLORSUM, &m_pICS);
		m_pICS->SetColors(stCS.colors, D_CS_COLORSUM);

		if (g_fCompoundFile == FALSE)
		{
			FixAllColorValueToIndex(
				m_pICS,
				((CWPPDoc*)m_pDocument)->GetColorSchemeTable());
		}
	}
}

// -------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
//LLG_ADD_2002_5_18 ������ɫ
//����������ʽ��ɫ(by wxb)
BOOL gFixWPPStyleSheetForMaster(IColorScheme* pICS,
							   ColourTableEntry* pCSTable,
							   CStyleSheet_Text* pSST,
							   int nSlideBaseType)
{
	FIXCOLOR_VALUE2INDEX_BEGIN;
	KCOLORINDEX indexColor;

	CTypedPtrArray<CObArray, CStyle_Text*>	aryStyleText;
	int i = 0, len = 0;
	CStyle_Text* pStyle = NULL;
	CObList* pList = NULL;
	CCtrlCode_Color* pCode = NULL;
	CString strTemp;
	if (nSlideBaseType == enSLIDEBASE_TITLE)
	{
		for (i = 0; i < 6; i++)
		{
			switch(i)
			{
			case 0: strTemp = "WPPS_TITLE_H1"; break;
			case 1: strTemp = "WPPS_TITLE_H2"; break;
			case 2: strTemp = "WPPS_TITLE_H3"; break;
			case 3: strTemp = "WPPS_TITLE_H4"; break;
			case 4: strTemp = "WPPS_TITLE_H5"; break;
			case 5: strTemp = "WPPS_TITLE_TITLE"; break;
			}
			pStyle = (CStyle_Text*)pSST->GetStyle(TSID_USERDEFINEDPS, strTemp);
			ASSERT_VALID(pStyle);
			aryStyleText.Add(pStyle);
		}
		for (i = 0, len = pSST->NumOfStyles(); i < len; i++)
		{
			pStyle = (CStyle_Text*)pSST->GetStyleViaIndex(i);
			if (!pStyle->IsUserDefinedStyle())
				aryStyleText.Add(pStyle);
		}
	}
	else
	{
		for (i = 0; i < 6; i++)
		{
			switch(i)
			{
			case 0: strTemp = "WPPS_SLIDE_H1"; break;
			case 1: strTemp = "WPPS_SLIDE_H2"; break;
			case 2: strTemp = "WPPS_SLIDE_H3"; break;
			case 3: strTemp = "WPPS_SLIDE_H4"; break;
			case 4: strTemp = "WPPS_SLIDE_H5"; break;
			case 5: strTemp = "WPPS_SLIDE_TITLE"; break;
			}
			pStyle = (CStyle_Text*)pSST->GetStyle(TSID_USERDEFINEDPS, strTemp);
			ASSERT_VALID(pStyle);
			aryStyleText.Add(pStyle);
		}
	}

	for (i = 0, len = aryStyleText.GetSize(); i < len; i++)
	{
		pStyle = aryStyleText[i];	ASSERT_VALID(pStyle);
		pList = (CObList*)pStyle->GetCAList();ASSERT_VALID(pList);
		if (pList)
		{
			pCode = (CCtrlCode_Color*)CtrlCodeTool.FindCtrlCode(pList, SETCOLOR);
			if (pCode)
			{
				ASSERT_VALID(pCode);
				indexColor = pCode->GetColor();
				FIXCOLOR_VALUE2INDEX(indexColor);
				pCode->SetColor(indexColor);
			}
		}
	}

	FIXCOLOR_VALUE2INDEX_END;
}

//LLG_ADD_2002_5_18
//�������е���ɫֵ������ֵ
BOOL CWPPSlideBase::FixAllColorValueToIndex(IColorScheme* pICS,
												ColourTableEntry* pCSTable)
{
//	ASSERT_ONCE(0);
//	return TRUE;
//*@@todo - why?
	FIXCOLOR_VALUE2INDEX_BEGIN;

	ASSERT(pICS == m_pICS);

	//ҳ�汳����ɫˢ��
	//�̶���ɫ
	FIXCOLOR_VALUE2INDEX(m_Background.m_clrSolid);

	//����ɫ�ĵ�һ����ɫ
	FIXCOLOR_VALUE2INDEX(m_Background.m_ShadeCtrl.shadeColor[0]);

	//����ɫ�ĵڶ�����ɫ
	FIXCOLOR_VALUE2INDEX(m_Background.m_ShadeCtrl.shadeColor[1]);
	//�����ǵ�ɫ���䣬��ʱ���������һ����ɫ�����ȹ�ϵ...
	if(nPos == -1 &&
		KColorModel::GetFlagIndex(m_Background.m_ShadeCtrl.shadeColor[1])
										!= defCOLORMODELFLAG_ONECOLORSHADE)
	{
		LONG h1 = KColorModel::H(m_Background.m_ShadeCtrl.shadeColor[0], pICS);
		LONG s1 = KColorModel::S(m_Background.m_ShadeCtrl.shadeColor[0], pICS);
		//int v1 = KColorModel::V(m_Background.m_ShadeCtrl.shadeColor[0], pICS);
		LONG h2 = KColorModel::H(m_Background.m_ShadeCtrl.shadeColor[1], pICS);
		LONG s2 = KColorModel::S(m_Background.m_ShadeCtrl.shadeColor[1], pICS);
		LONG v2 = KColorModel::V(m_Background.m_ShadeCtrl.shadeColor[1], pICS);
		if (h1 == h2 && s1 == s2)
		{
			m_Background.m_ShadeCtrl.shadeColor[1] =
								KColorModel::CreateSecondColorForOneShade(v2);
		}
	}

	//���ж���...
//	POSITION pos;
//	CWPSObj* pObj;
	//@@todo - ��
	//CWPPFrame::SetBaseType(m_nSlideBaseType);
//	for( pos = m_WPSObjectList.GetHeadPosition(); pos != NULL;)//tank:ÿ������Ҫת��...̫������
//	{
//		pObj = (CWPSObj*)m_WPSObjectList.GetNext(pos);
//		ASSERT(pObj);
//		pObj->FixAllColorValueToIndex(pICS, pCSTable);
//	}

	//����ϵͳ������ʽ -- ֻ��ĸ����Ч
	if (IsWPPMaster())
	{
		//Begin BlackBay
		CStyleSheet_Text *pSST = m_pDocument->GetStyleSheet_Text();
		ASSERT_VALID(pSST);

		gFixWPPStyleSheetForMaster(pICS, pCSTable, pSST, GetSlideBaseType());
	}

	FIXCOLOR_VALUE2INDEX_END; //*/
}

// -------------------------------------------------------------------------
