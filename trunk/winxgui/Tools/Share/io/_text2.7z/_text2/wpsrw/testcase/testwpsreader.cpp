/* -------------------------------------------------------------------------
//	�ļ���		��	testwpsreader.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-20 19:46:38
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if defined(X_TEST_WPSREADER)

#include "testcommon.h"
#include <l10n.h>
#include <kso/io/contentsource.h>
#include <kso/io/component.h>
#include <kso/io/linklib_xmlwriter.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDAPI filterpluginInitialize(IN void* pReserved);
STDAPI filterpluginTerminate();
STDAPI filterpluginFormatCorrect(IN LPCFILTERMEDIUM pMedium, IN long lFormat);
STDAPI filterpluginImportCreate(IN long lFormat, IN IKFilterEventNotify* pNotify, OUT IKFilterMediaInit** ppv);

// -------------------------------------------------------------------------

class TestWpsReader : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestWpsReader);
		CPPUNIT_TEST(testFormatCorrect);
		CPPUNIT_TEST(testImport);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testFormatCorrect()
	{
		HRESULT hr;
		WCHAR szWpsFile[_MAX_PATH];
		FILTERMEDIUM fm;
		fm.tymed = FILTER_TYMED_FILE;
		fm.lpszFileName = (LPWSTR)GetSystemIniPath(
			szWpsFile, __X("testcase/wpsrw/core/a.wps"));
		hr = filterpluginFormatCorrect(&fm, _IoFormat_WPS);
		ASSERT_OK(hr);

		fm.lpszFileName = (LPWSTR)GetSystemIniPath(
			szWpsFile, __X("testcase/wpsrw/core/2000/a.wps"));
		hr = filterpluginFormatCorrect(&fm, _IoFormat_WPS);
		ASSERT_OK(hr);
	}

	void testImport()
	{
		filterpluginInitialize(NULL);

		ks_stdptr<IKFilterMediaInit> spInit;
		HRESULT hr = filterpluginImportCreate(_IoFormat_WPS, NULL, &spInit);
		KS_CHECK(hr);
		{
			WCHAR szWpsFile[_MAX_PATH];
			WCHAR szXmlFile[_MAX_PATH];
			hr = _kso_FileMediaInit(
				spInit,
				GetSystemIniPath(szWpsFile, __X("testcase/wpsrw/core/a.wps")),
				STGM_READ|STGM_TRANSACTED);
			KS_CHECK(hr);

			ks_stdptr<IKContentSource> spSrc;
			hr = spInit->QI(IKContentSource, &spSrc);
			KS_CHECK(hr);

			ks_stdptr<IKContentHandler> spAcc;
			hr = _kso_CreateXmlWriter(kso_xmlWordProcess, &spAcc);
			KS_CHECK(hr);

			hr = _kso_FileMediaInit(
				spAcc,
				GetSystemIniPath(szXmlFile, __X("testcase/output/_toxml_.xml")),
				STGM_G_CREATE);
			KS_CHECK(hr);
				
			hr = spSrc->Transfer(spAcc);
			KS_CHECK(hr);
		}
KS_EXIT:
		filterpluginTerminate();
		return;
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestWpsReader);

// -------------------------------------------------------------------------
#endif
