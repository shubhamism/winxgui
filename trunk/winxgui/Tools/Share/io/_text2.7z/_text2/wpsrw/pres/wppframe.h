/* -------------------------------------------------------------------------
//	�ļ���		��	wppframe.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-28 14:38:25
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __WPPFRAME_H__
#define __WPPFRAME_H__

#include "wppcommon.h"
#include "wppdoc.h"
#include "wppslide.h"
#ifndef __FRAMETEXT_H__
#include <draw/frametext.h>
#endif
#include <core/textpool.h>
#include <core/autonum_atom.h>
// -------------------------------------------------------------------------
// class CWPPFrame

class CWPPFrame : public CFrameText
{
private:
	BOOL m_bIsTitleFrame;
	
public:
	DECLARE_SERIAL(CWPPFrame);
	DECLARE_COUNT(CWPPFrame);

	CWPPFrame() {}
	//~CPPFrame(); -- no need
	
	virtual int	 CheckObjType() { return WPPFRAME; }
	virtual void Serialize_97(CArchive& ar);
	virtual void Serialize_98(CArchive& ar);
	virtual void Serialize_01(CArchive& ar);
	//
	BOOL InitStyle(int nSlideBaseType, BOOL bMultLevel);
	BOOL ProcessStyleForHoliness(int, BOOL);

};	

// -------------------------------------------------------------------------

#endif /* __WPPFRAME_H__ */
