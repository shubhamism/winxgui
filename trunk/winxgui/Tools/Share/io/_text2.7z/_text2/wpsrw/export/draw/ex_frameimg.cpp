/* -------------------------------------------------------------------------
//	�ļ���		��	ex_frameimg.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-25 14:48:00
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "ex_frameimg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

EX_SHAPE_API CFrameImage_Export::ConvertShape(CShape_Context& context)
{
	context.m_dwFlag |= WPSRW_FRAMEIMAGE;
	((CFrameObj_Export*)this)->ConvertShape(context);
#ifdef WPP_ONLY
	if (context.GetPlaceHolderID() > 0)
	{
		// liupeng: �յİ�ʽ����
		if (this->m_pImg)
		{
			if (!this->m_pImg->m_pSource)
			{
				context.m_shape.SetShapeType(msosptRectangle);		
				return;
			}
		}
		context.m_shape.SetShapeType(msosptPictureFrame);
	}
	else
		context.m_shape.SetShapeType(msosptPictureFrame);
#else
	context.m_shape.SetShapeType(msosptPictureFrame);
#endif

			/*
			 *	ͼƬ�Ƿ�ƽ��
			 * ����ͼƬ�Ƿ�ƽ�̵�ָ��
			 *	msopt_pictureTile = msopt_ksextBase + 10, //BOOL  FALSE  ͼƬ�Ƿ�ƽ��
			 * @@todo ��¼ƽ��ǰλ�� ?? CRect		m_regRect;
			 */
//			if(m_bTiled)
//			{
//				context.m_opt.AddPropFix(msopt_pictureArrangeMode, mso_arrangeTile);
//			}

}

// -------------------------------------------------------------------------
