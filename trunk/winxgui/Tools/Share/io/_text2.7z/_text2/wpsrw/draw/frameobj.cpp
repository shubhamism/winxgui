/* -------------------------------------------------------------------------
//	�ļ���		��	frameobj.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-18 18:47:12
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "frameobj.h"
#include "wpsimg.h"
#include <core/wpsdoc.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CFrameObj, CFPBase, 0xA0 | VERSIONABLE_SCHEMA)

// -------------------------------------------------------------------------

CFrameObj::CFrameObj(const CWpsDoc* pDoc, const CRect& frmrect)
	: CFPBase(pDoc, frmrect)
{
	//	���������
	SetWPSObjType(FRAMEObj);

	//	��߾�
	//	m_mgOutsideType = All;
	//	SetMrgSize((MrgSideType)m_mgOutsideType, &m_MarginOutside, 30);
	m_mgOutsideType = pDoc->m_DefProp.m_mgOutsideType;
	m_MarginOutside = pDoc->m_DefProp.m_MarginOutside;
	
	//	ֱ�ǿ�����
	//	m_nfrmShape = FS_RECT;
	//	m_roundness.x = 0;
	//	m_roundness.y = 0;
	m_nfrmShape = pDoc->m_DefProp.m_nfrmShape;
	m_roundness = pDoc->m_DefProp.m_roundness;
	
	//	��Ӱ���
	if (m_nBkMode == OPAQUE)
		m_shadowStyle = SW_FOG;		//	��ɫ
	else
		m_shadowStyle = SW_PURE;		//	��ɫ
	//	��Ӱɫ
	m_shadowColor = RGB(160, 160, 164);	//	�л�ɫ��
	//	ע����RGB(128,128,128)����͸��Ӱ��ʱϵͳ���в������֡���֪�ι�
	//	���ŷ�ʽ
	m_wrapMode = (CWPSObj::WrapMode)pDoc->m_DefProp.m_wrapMode;
	//	m_wrapMode = wm_onlargerside;
	//	���ڵ�ͼ
	m_pImg = NULL;
	m_extent = CSize(0, 0);
}

CFrameObj::~CFrameObj()
{
	ASSERT(this);
	DeleteImgContent();
}

//---------------------------------------------------------------------------
//	���ܣ�ɾ����������ͼ
//---------------------------------------------------------------------------
void CFrameObj::DeleteImgContent(CWpsView* /*=NULL*/)
{
	if (m_pImg)
		ReleaseWpsImage(m_pImg);
	m_pImg = NULL;
	m_extent = CSize(0, 0);
}

void CFrameObj::Serialize_97(KSArchive& ar)
{
	CFPBase::Serialize_97(ar);
	if (ar.IsStoring())
		ASSERT(FALSE);// Cannot saved as a WPS97 file.
	else
	{
		SHORT wTemp;
		ar >> wTemp;	m_nfrmShape = (int)wTemp;
		ar >> wTemp;	m_roundness.x = wTemp;
		ar >> wTemp;	m_roundness.y = wTemp;
		ar >> wTemp;	m_wrapMode = (CFrameObj::WrapMode)wTemp;
		ar >> wTemp; 	m_mgOutsideType = (CFrameObj::MrgSideType)wTemp;
		ar >> wTemp;	m_MarginOutside.left   = wTemp;
		ar >> wTemp;	m_MarginOutside.top    = wTemp;
		ar >> wTemp;	m_MarginOutside.right  = wTemp;
		ar >> wTemp;	m_MarginOutside.bottom = wTemp;
		ar >> wTemp;	m_extent.cx = wTemp;
		ar >> wTemp;	m_extent.cy = wTemp;
		ar >> m_pImg;
		if (m_pImg)
			SetImage(m_pImg);
	}                
}

void CFrameObj::Serialize_98(KSArchive& ar)
{
	CFPBase::Serialize_98(ar);
	if (ar.IsStoring())
	{
		ar << m_nfrmShape;
		ar << m_roundness;
		ar << m_wrapMode;
		ar << m_mgOutsideType;
		ar << m_MarginOutside;
		ar << m_extent;
		ar << m_pImg;
	}
	else
	{
		int nTemp;
		ar >> m_nfrmShape;
		ar >> m_roundness;
		ar >> nTemp;	m_wrapMode = (CFrameObj::WrapMode)nTemp;
		ar >> nTemp; 	m_mgOutsideType = (CFrameObj::MrgSideType)nTemp;
		ar >> m_MarginOutside;
		ar >> m_extent;
		ar >> m_pImg;
		if (m_pImg)
			SetImage(m_pImg);
	}                
}

STDMETHODIMP CFrameObj::Serialize_Write_02(KSArchive& ar)
{
	WPSFrameObjData rec;
	KWPSMainWriter wr;
	wr.Attach(&ar);

	rec.nFrameShape		= m_nfrmShape;
	rec.roundness		= m_roundness;
	rec.wrapMode		= m_wrapMode;
	rec.mgOutsideType	= m_mgOutsideType;
	rec.MarginOutside	= m_MarginOutside;
	rec.extent			= m_extent;
	rec.fHasImg			= (m_pImg ? 1 : 0);

	_WPSWriteRecord(wr, TAG_WPSFrameObjData, &rec, sizeof(rec));
	if (m_pImg)
		m_pImg->Serialize(ar);

	return S_OK;
}

STDMETHODIMP CFrameObj::Serialize_Read_02(KSArchive& ar)
{
	HRESULT hr;
	_KWPSRecordHeader hdr;
	WPSFrameObjData rec;
	KWPSMainReader wr;
	wr.Attach(&ar);

	hr = wr.NextRec(&hdr);
	KS_CHECK(hr);
	KS_CHECK_BOOLEX(hdr.wTag == TAG_WPSFrameObjData, hr = E_UNEXPECTED);

	ZeroMemory(&rec, sizeof(rec));
	wr.Read(&rec, sizeof(rec));
	if (wr.GetRestSize())
		wr.Skip(wr.GetRestSize());

	m_nfrmShape		= rec.nFrameShape;
	m_roundness		= rec.roundness;
	m_wrapMode		= (WrapMode)rec.wrapMode;
	m_mgOutsideType	= rec.mgOutsideType;
	m_MarginOutside	= rec.MarginOutside;
	m_extent		= rec.extent;

	if (rec.fHasImg == 1)
	{
		m_pImg = CreateWpsImage();
		m_pImg->Serialize(ar);
		SetImgFrame(m_pImg, this);
	}
	return S_OK;

KS_EXIT:
	return WPSIOThrowError(hr);
}

void CFrameObj::Serialize_01(KSArchive& ar)
{
	CFPBase::Serialize_01(ar);
	if (ar.IsStoring())
	{
		if (g_fCompoundFile) // wps2002-io-frameobj, by tsingbo
			Serialize_Write_02(ar);
		else
		{
			ar << m_nfrmShape;
			ar << m_roundness;
			ar << m_wrapMode;
			ar << m_mgOutsideType;
			ar << m_MarginOutside;
			ar << m_extent;
			ar << m_pImg;
		}
	}
	else
	{
		if (g_fCompoundFile) // wps2002-io-frameobj, by tsingbo
			Serialize_Read_02(ar);
		else
		{
			int nTemp;
			ar >> m_nfrmShape;
			ar >> m_roundness;
			ar >> nTemp;	m_wrapMode = (CFrameObj::WrapMode)nTemp;
			ar >> nTemp; 	m_mgOutsideType = (CFrameObj::MrgSideType)nTemp;
			ar >> m_MarginOutside;
			ar >> m_extent;
			ar >> m_pImg;
		}

		if (m_pImg)
			SetImgFrame(m_pImg, this);
		
		//LLG_MODIFY_2002_5_19
		//WPP����û���������ԡ��ڴ˷�ֹ��WPS���Ƶ�WPP�Ķ��󣬻��д�����
		CWpsDoc* pDocument = (CWpsDoc*)ar.m_pDocument;
		ASSERT(pDocument);
		if (pDocument->QueryWPPDocType())
		{
			m_wrapMode = wm_nowrap;
		}
	}
}

// -------------------------------------------------------------------------

void CFrameObj::SetFrmShape(int nfrmShape, CWpsView* pView/*=NULL*/)
{
	if (nfrmShape != FS_RECT && nfrmShape != FS_ROUNDRECT)
		SetShadowStyle(SW_PURE, pView);
	m_nfrmShape = nfrmShape; 
}

