/* -------------------------------------------------------------------------
//	�ļ���		��	ex_style.cpp
//	������		��	����
//	����ʱ��	��	2004-10-25 9:28:17 AM
//	��������	��	
//	$Id: ex_style.cpp,v 1.12 2005/06/21 06:06:13 duanyuluo Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <core/style_text.h>
#include <core/stylesheet_text.h>
#include "ex_wpsdoc.h"
#include "ex_style.h"
#include "stl/algorithm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

// ��WPS�ڲ��������ʽIDӳ���Word����Ӧ��ID
static UINT StyleIDMapper(DWORD dwID)
{
	static UINT uStyleIDMapper[] = {
						// 0x0 �� 0x1F������
		stiNil,			//#define	TSID_NULL			0x00
		stiNil,			//#define	TSID_UNDETERMINED	0x01
		stiUser,		//#define	TSID_USERDEFINEDPS	0x02	// �û��Զ������ʽ
		stiUser,		//#define	TSID_USERDEFINEDCS	0x03	// �û��Զ�������ʽ
		stiNil,			//								0x04
		stiNil,			//								0x05
		stiNil,			//								0x06
		stiNil,			//								0x07
		stiNil,			//								0x08
		stiNil,			//								0x09
		stiNil,			//								0x0A
		stiNil,			//								0x0B
		stiNil,			//								0x0C
		stiNil,			//								0x0D
		stiNil,			//								0x0E
		stiNil,			//								0x0F
		stiNil,			//								0x10
		stiNil,			//								0x11
		stiNil,			//								0x12
		stiNil,			//								0x13
		stiNil,			//								0x14
		stiNil,			//								0x15
		stiNil,			//								0x16
		stiNil,			//								0x17
		stiNil,			//								0x18
		stiNil,			//								0x19
		stiNil,			//								0x1A
		stiNil,			//								0x1B
		stiNil,			//								0x1C
		stiNil,			//								0x1D
		stiNil,			//								0x1E
		stiNil,			//								0x1F

						// 0x20 ~ 0x2F: Ŀ¼
		stiToc1,		//#define	TSID_TOC_0			0x20
		stiToc2,		//#define	TSID_TOC_1			0x21
		stiToc3,		//#define	TSID_TOC_2			0x22
		stiToc4,		//#define	TSID_TOC_3			0x23
		stiToc5,		//#define	TSID_TOC_4			0x24
		stiToc6,		//#define	TSID_TOC_5			0x25
		stiToc7,		//#define	TSID_TOC_6			0x26
		stiToc8,		//#define	TSID_TOC_7			0x27
		stiToc9,		//#define	TSID_TOC_8			0x28
		stiUser,		//#define	TSID_TOC_9			0x29
		stiUser,		//#define	TSID_TOC_A			0x2A
		stiUser,		//#define	TSID_TOC_B			0x2B
		stiUser,		//#define	TSID_TOC_C			0x2C
		stiUser,		//#define	TSID_TOC_D			0x2D
		stiUser,		//#define	TSID_TOC_E			0x2E
		stiUser,		//#define	TSID_TOC_F			0x2F

						// 0x30 ~ 0x3F: ���±���
		stiTitle,		//#define	TSID_TITLE_0		0x30
		stiUser,		//#define	TSID_TITLE_1		0x31
		stiUser,		//#define	TSID_TITLE_2		0x32
		stiUser,		//#define	TSID_TITLE_3		0x33
		stiUser,		//#define	TSID_TITLE_4		0x34
		stiUser,		//#define	TSID_TITLE_5		0x35
		stiUser,		//#define	TSID_TITLE_6		0x36
		stiUser,		//#define	TSID_TITLE_7		0x37
		stiUser,		//#define	TSID_TITLE_8		0x38
		stiUser,		//#define	TSID_TITLE_9		0x39
		stiUser,		//#define	TSID_TITLE_A		0x3A
		stiUser,		//#define	TSID_TITLE_B		0x3B
		stiUser,		//#define	TSID_TITLE_C		0x3C
		stiUser,		//#define	TSID_TITLE_D		0x3D
		stiUser,		//#define	TSID_TITLE_E		0x3E
		stiUser,		//#define	TSID_TITLE_F		0x3F

						// 0x30 ~ 0x3F: �½ڱ���
		stiLev1,		//#define	TSID_HEADER_0		0x40
		stiLev2,		//#define	TSID_HEADER_1		0x41
		stiLev3,		//#define	TSID_HEADER_2		0x42
		stiLev4,		//#define	TSID_HEADER_3		0x43
		stiLev5,		//#define	TSID_HEADER_4		0x44
		stiLev6,		//#define	TSID_HEADER_5		0x45
		stiLev7,		//#define	TSID_HEADER_6		0x46
		stiLev8,		//#define	TSID_HEADER_7		0x47
		stiLev9,		//#define	TSID_HEADER_8		0x48
		stiUser,		//#define	TSID_HEADER_9		0x49
		stiUser,		//#define	TSID_HEADER_A		0x4A
		stiUser,		//#define	TSID_HEADER_B		0x4B
		stiUser,		//#define	TSID_HEADER_C		0x4C
		stiUser,		//#define	TSID_HEADER_D		0x4D
		stiUser,		//#define	TSID_HEADER_E		0x4E
		stiUser,		//#define	TSID_HEADER_F		0x4F

						// 0x40 ~ 0x4F: ����
		stiNormal,		//#define	TSID_TEXT_0			0x50
		stiBodyText,	//#define	TSID_TEXT_1			0x51
		stiBodyText2,	//#define	TSID_TEXT_2			0x52
		stiBodyText3,	//#define	TSID_TEXT_3			0x53
		stiUser,		//#define	TSID_TEXT_4			0x54
		stiUser,		//#define	TSID_TEXT_5			0x55
		stiUser,		//#define	TSID_TEXT_6			0x56
		stiUser,		//#define	TSID_TEXT_7			0x57
		stiUser,		//#define	TSID_TEXT_8			0x58
		stiUser,		//#define	TSID_TEXT_9			0x59
		stiUser,		//#define	TSID_TEXT_A			0x5A
		stiUser,		//#define	TSID_TEXT_B			0x5B
		stiUser,		//#define	TSID_TEXT_C			0x5C
		stiUser,		//#define	TSID_TEXT_D			0x5D
		stiUser,		//#define	TSID_TEXT_E			0x5E
		stiUser,		//#define	TSID_TEXT_F			0x5F

						// 0x60 ~ 0x6F: Ŀ¼����
		stiUser,		//#define	TSID_TOCTITLE_0		0x60
		stiUser,		//#define	TSID_TOCTITLE_1		0x61
		stiUser,		//#define	TSID_TOCTITLE_2		0x62
		stiUser,		//#define	TSID_TOCTITLE_3		0x63
		stiUser,		//#define	TSID_TOCTITLE_4		0x64
		stiUser,		//#define	TSID_TOCTITLE_5		0x65
		stiUser,		//#define	TSID_TOCTITLE_6		0x66
		stiUser,		//#define	TSID_TOCTITLE_7		0x67
		stiUser,		//#define	TSID_TOCTITLE_8		0x68
		stiUser,		//#define	TSID_TOCTITLE_9		0x69
		stiUser,		//#define	TSID_TOCTITLE_A		0x6A
		stiUser,		//#define	TSID_TOCTITLE_B		0x6B
		stiUser,		//#define	TSID_TOCTITLE_C		0x6C
		stiUser,		//#define	TSID_TOCTITLE_D		0x6D
		stiUser,		//#define	TSID_TOCTITLE_E		0x6E
		stiUser,		//#define	TSID_TOCTITLE_F		0x6F
	};
	UINT uID;
	if (dwID < sizeof(uStyleIDMapper)/sizeof(uStyleIDMapper[0]))
	{
		uID = uStyleIDMapper[dwID];
		//ASSERT(uID != stiNil);
	}
	else if (dwID == TSID_CHAR_DEFAULT)
	{
		uID = stiNormalChar;
	}
	else
		uID = stiUser;
	return uID;
}

// -------------------------------------------------------------------------

BOOL CStyle_Export::Init(STYLEEXPORTCONTEXT* pSEC, KWpsExport* pExport, DWORD dwID,
				LPCTSTR lpszName, KDWStyle* pStyle_Word)
{
	pSEC->pExport = pExport;
	pSEC->pStyle_Word = pStyle_Word;
	pSEC->dwID = dwID;
	pSEC->lpszName = lpszName;

	CStyleSheet_Text* pSheet_WPS = pExport->m_pDoc->GetStyleSheet_Text();
	pSEC->pStyle_WPS = pSheet_WPS->GetStyle(dwID, lpszName);
	if (pSEC->pStyle_WPS == NULL)
		return FALSE;
	return TRUE;
}

STYLE_SGC CStyle_Export::GetStyleType(const STYLEEXPORTCONTEXT& sec)
{
	ASSERT(sec.pStyle_WPS != NULL);
	UINT uType  = sec.pStyle_WPS->GetStyleType();
	STYLE_SGC theSGC;
	if (uType == TSID_PARASTYLE)
		theSGC = mso_sgcParagraph;
	else if (uType == TSID_CHARSTYLE)
		theSGC = mso_sgcCharacter;
	else
	{
		ASSERT(FALSE);
		theSGC = mso_sgcNull;
	}
	return theSGC;
}

// ����Word��ʽ.
// ˵��: �����Ǵ���, ʵ���Ե�������δexport
BOOL CStyle_Export::CreateWordStyle(const STYLEEXPORTCONTEXT& sec)
{
	// ��ȡ����һ��Word��ʽ����ĸ�������
	// ����3: ��ʽ����(����ʽ? ����ʽ? ect.)
	STYLE_SGC theSGC = GetStyleType(sec);

	// ����1: ��ʽID
	UINT uStyleID = StyleIDMapper(sec.dwID);
	if(uStyleID == stiNil)
	{
		if(theSGC == mso_sgcParagraph)
			uStyleID = stiNormal;
		else
			uStyleID = stiNormalChar;
	}

	// ����2: ��ʽ��
	ASSERT(sec.pStyle_WPS != NULL);
	LPCTSTR lpszName = sec.pStyle_WPS->GetStyleName();
	ks_wstring strStyleName(lpszName);


	// �����뱸, ��ʼ����
	KDWStyleSheet& theSheet = sec.pExport->GetStyleSheet();
	theSheet.NewStyle(uStyleID, strStyleName, theSGC, sec.pStyle_Word);

	return TRUE;
}

BOOL CStyle_Export::Convert_BaseStyle(const STYLEEXPORTCONTEXT& sec)
{
	DWORD dwBaseStyleID = sec.pStyle_WPS->GetBaseStyleID();
	if (dwBaseStyleID != TSID_NULL)		// Ĭ��ֵΪstiNil, ���账��
	{
		const CString& strBaseStyleName = sec.pStyle_WPS->GetBaseStyleName();
		UINT uBaseStyleID = Convert(*(sec.pExport), dwBaseStyleID, (LPCTSTR)strBaseStyleName);
		sec.pStyle_Word->SetBaseStyle(uBaseStyleID);
	}
	return TRUE;
}

BOOL CStyle_Export::Convert_StyleFollowed(const STYLEEXPORTCONTEXT& sec)
{
	// ����StyleNext
	DWORD dwNextStyleID = sec.pStyle_WPS->GetFollowStyleID();
	if (dwNextStyleID != sec.dwID &&		// ����ʽ��Ĭ��ֵΪ����, ���账��
		dwNextStyleID != TSID_NULL)		// �ݴ�: ���Է���WPS�к���ʽ��Ȼ�����ǿ���ʽ
	{
		const CString& strNextStyleName = sec.pStyle_WPS->GetFollowStyleName();
		UINT uNextStyleID = Convert(*(sec.pExport), dwNextStyleID, (LPCTSTR)strNextStyleName);
		sec.pStyle_Word->SetNextStyle(uNextStyleID);
	}
	return TRUE;
}

BOOL CStyle_Export::Convert_CharAttribs(const STYLEEXPORTCONTEXT& sec)
{
	const CObList* pCAList = sec.pStyle_WPS->GetCAList();
	if (pCAList)
	{
		KDWPropBuffer chp;
		ChpxCtrlCode_Context ctrlcode(*sec.pExport);
		ctrlcode.ConvertChpx(pCAList, chp);
		sec.pStyle_Word->SetSprmList(mso_sgcCharacter, &chp);
	}
	return TRUE;
}

// -------------------------------------------------------------------------
// @@note:
//	���������Ȼ�����Ͻ���С��Χ��ʹ�ðɡ�
//	��Ҫʵ�������Ĺ��ܣ�
//		����1. �޸�KDWPropBuffer���ڲ�ʵ�֣����ȡ
//		����2. �ɲο�docreader��KSprmList��ʵ�֡�
//
static inline
STDMETHODIMP_(BOOL) __WPSRW_HasSprm(
	IN LPCVOID pBuffer,
	IN UINT cbLen, 
	IN UINT16 sprmOp)
{
	if (
		cbLen == 0 ||
		pBuffer == NULL
		)
	{
		return FALSE;
	}

	typedef const UINT16* const_iterator;
	const_iterator itEnd = (UINT16*)pBuffer + cbLen;
	return std::find(
		(const_iterator)pBuffer, (const_iterator)itEnd, sprmOp) != itEnd;
}

// -------------------------------------------------------------------------
BOOL CStyle_Export::Convert_ParaAttribs(const STYLEEXPORTCONTEXT& sec)
{
	if (GetStyleType(sec) != mso_sgcCharacter)
	{
		const CObList* pPAList = sec.pStyle_WPS->GetPAList();
		if (pPAList)
		{
			KDWPropBuffer pap;
			PapxCtrlCode_Context ctrlcode(*sec.pExport);

			UINT uStyleID = sec.pStyle_Word->GetIndex();
			ctrlcode.ConvertPapx(uStyleID, pPAList, pap);
			
			// Word��Normal��ʽ�У����п��Ƶ�ȱʡֵ���棬WPSû��������ܣ���������
			if (uStyleID == stiNormal)
			{{
				if (!__WPSRW_HasSprm(pap.Data(), pap.Size(), sprmPFWidowControl))
					pap.AddPropFix(sprmPFWidowControl, 0);
				
				if (!__WPSRW_HasSprm(pap.Data(), pap.Size(), sprmPDxaLeft1) &&
					!__WPSRW_HasSprm(pap.Data(), pap.Size(), sprmPDxaLeft1Rel))
				{
					UINT nIndent = wpsDefParaAttrib.nFirstIndent;
					if (wpsDefParaAttrib.wFirstIndentUnit == UNIT_GRID ||
						wpsDefParaAttrib.wFirstIndentUnit == UNIT_PERCENT)
					{
						pap.AddPropFix(sprmPDxaLeft1, 10.5 * nIndent);
						pap.AddPropFix(sprmPDxaLeft1Rel, nIndent * 100);
						pap.AddPropFix(sprmPDxaLeft1Ex, 10.5 * nIndent);
					}
					else
					{
						pap.AddPropFix(sprmPDxaLeft1, lm2twip(nIndent));
						pap.AddPropFix(sprmPDxaLeft1Ex, lm2twip(nIndent));
					}
				}	
			}} // end of normal style

			sec.pStyle_Word->SetSprmList(mso_sgcParagraph, &pap);
		}
	}
	return TRUE;
}

STDMETHODIMP_(UINT) CStyle_Export::ConvertDefaultTable(KWpsExport& export)
{
	KDWStyle theStyle;
	KDWStyleSheet& theSheet = export.GetStyleSheet();
	theSheet.NewStyle(stiUser, ks_wstring(__X("WPS Plain")), mso_sgcParagraph, &theStyle);
	theStyle.SetSprmList(mso_sgcParagraph, _DW_NullPapx());
	theStyle.SetSprmList(mso_sgcCharacter, _DW_NullChpx());
	return theStyle.GetIndex();
}

STDMETHODIMP_(UINT) CStyle_Export::Convert(KWpsExport& export, DWORD dwID, ks_string strStyleName)
{
	UINT& uID = (dwID==TSID_USERDEFINEDPS || dwID==TSID_USERDEFINEDCS) ?
				m_TextStyleNameMap[strStyleName] :
				m_TextStyleIDMap[dwID];
	if (uID == 0)
	{
		STYLEEXPORTCONTEXT sec;
		KDWStyle theStyle;
		if (!Init(&sec, &export, dwID, strStyleName, &theStyle))
		{
			//�ڳ�ʼ����ʽʧ��ʱ������Ĭ����ʽ
			if (dwID == TSID_USERDEFINEDPS)//����ʽ
				return 0;
			else if(dwID == TSID_USERDEFINEDCS)//����ʽ
				return stiNil;
			
			REPORT_ONCE(__X("//Ϊʲô���ᷢ����"));
			return stiNil;
		}
		CreateWordStyle(sec);
		Convert_BaseStyle(sec);		// �ݹ�
		Convert_StyleFollowed(sec);	// �ݹ�
#pragma prompt("ע��: δ�ӱ����ĵݹ����")

		Convert_CharAttribs(sec);
		Convert_ParaAttribs(sec);

		uID = theStyle.GetIndex();
		++uID;
	}
	return uID - 1;
}

// -------------------------------------------------------------------------
// $Log: ex_style.cpp,v $
// Revision 1.12  2005/06/21 06:06:13  duanyuluo
// ��ȡwpsʱ����Ϊwps�Ŀո���ȱ�v6ҪСһ�������ֻת�˿ո��һ�룬����û�д��������⣬wps����ͨ��Ԫ��Ķ������ǿյģ�����Ӧ����������ʽ��
//
// Revision 1.11  2005/02/22 07:02:53  wangdong
// ����˶�KDWPropBuffer.IsPropExsit��������
//
