// htmlcmp.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <_backward/windev/common.h>
#include <_backward/windev/editctrls.h>
#include <direct.h>

#define IDVIEW                          3

HINSTANCE hInst; 

LONG RegisterToolPath(std::string path, std::string subkeyname, std::string valuename)
{
	//��HKEY_CURRENT_USER/Software
	HKEY software; LONG res;
	res = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_ALL_ACCESS, &software);
	if(	res != ERROR_SUCCESS )
		return res;
	//����rtfreform�Ӽ�
	HKEY toolkey; DWORD dwDisposition;
	res = RegCreateKeyEx(software, subkeyname.c_str(), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &toolkey, &dwDisposition);
	if( res != ERROR_SUCCESS )
		return res;
	//����ֵ
	res = RegSetValueEx(toolkey, valuename.c_str(), 0, REG_SZ, (CONST BYTE *)(path.c_str()), path.size());
	RegCloseKey(toolkey);
	RegCloseKey(software);
	return res;
}

LONG GetToolPath(CHAR* path, std::string subkeyname, std::string valuename, LPDWORD cbData, LPDWORD type)
{	
	LONG res;
	HKEY software;
	res = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_ALL_ACCESS, &software);
	if( res != ERROR_SUCCESS )	
		return res;

	HKEY toolkey;
	res = RegOpenKeyEx(software, subkeyname.c_str(), 0, KEY_ALL_ACCESS, &toolkey);
	if( res != ERROR_SUCCESS)
	{
		RegCloseKey(software);
		return res;
	}

	res = RegQueryValueEx(toolkey, valuename.c_str(), NULL, type, (LPBYTE)path, cbData);
	RegCloseKey(toolkey);
	RegCloseKey(software);
	return res;
}

LONG RegisterCompareToolPath(std::string path)
{	
	return RegisterToolPath(path, "htmlcmp", "compare tool");
}

LONG RegisterEditToolPath(std::string path)
{	
	return RegisterToolPath(path, "htmlcmp", "edit tool");
}

LONG GetCompareToolPath(CHAR* path, LPDWORD cbData, LPDWORD type)
{
	return GetToolPath(path, "htmlcmp", "compare tool", cbData, type);
}

LONG GetEditToolPath(CHAR* path, LPDWORD cbData, LPDWORD type)
{
	return GetToolPath(path, "htmlcmp", "edit tool", cbData, type);
}

LONG GetToolPath(CHAR* path, LPDWORD cbData, LPDWORD type)
{	
	LONG res;
	HKEY software;
	res = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_ALL_ACCESS, &software);
	if( res != ERROR_SUCCESS )	
		return res;

	HKEY htmlcmp;
	res = RegOpenKeyEx(software, "htmlcmp", 0, KEY_ALL_ACCESS, &htmlcmp);
	if( res != ERROR_SUCCESS)
	{
		RegCloseKey(software);
		return res;
	}

	res = RegQueryValueEx(htmlcmp, "compare tool", NULL, type, (LPBYTE)path, cbData);
	RegCloseKey(htmlcmp);
	RegCloseKey(software);
	return res;
}

BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static char sourceFile[MAX_PATH];
	static char szExeFile[MAX_PATH];
	static char backupfile[MAX_PATH];
	static char newestFile[MAX_PATH];
	static char tmpPath[MAX_PATH];
	static char toolFile[MAX_PATH];
	static char toolPath[MAX_PATH];
	static KEditCtrl kedit;
	HRESULT hr;
	char* pcmd;
	switch(uMsg)
	{
	case WM_INITDIALOG:
		pcmd = (char*)(lParam);
		GetTempPath(MAX_PATH,tmpPath);
		strcat(tmpPath,"\\HtmlCmpTempDir");
		_mkdir(tmpPath);
		GetTempFileName(tmpPath,"hmcmp",0,backupfile);
		GetTempFileName(tmpPath,"hmcmp",0,newestFile);
		DealFileName(pcmd);
		strcpy(szExeFile,pcmd);
		if(szExeFile[0]=='\0')
			EnableWindow(GetDlgItem(hDlg,IDEDIT),FALSE);		
		kedit = GetDlgItem(hDlg,IDC_EDIT);
		kedit.SetText("������Դ�ļ���");
		sourceFile[0]='\0';
		SendMessage(GetDlgItem(hDlg,IDC_OPEN),BM_SETIMAGE,IMAGE_ICON,
			(LPARAM)LoadImage(hInst,MAKEINTRESOURCE(IDI_OPEN),IMAGE_ICON,0,0,LR_DEFAULTSIZE));
		SendMessage(GetDlgItem(hDlg,IDC_EXEOPEN),BM_SETIMAGE,IMAGE_ICON,
			(LPARAM)LoadImage(hInst,MAKEINTRESOURCE(IDI_EDIT),IMAGE_ICON,0,0,LR_DEFAULTSIZE));
		SendMessage(GetDlgItem(hDlg,IDC_FLUSH),BM_SETIMAGE,IMAGE_ICON,
			(LPARAM)LoadImage(hInst,MAKEINTRESOURCE(IDI_REFLUSH),IMAGE_ICON,0,0,LR_DEFAULTSIZE));
		EnableWindow(GetDlgItem(hDlg,IDC_FLUSH),FALSE);
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			DeleteFile(newestFile);
			DeleteFile(backupfile);
			EndDialog(hDlg,0);
			break;
		case IDC_OPEN:
			hr = GetOpenFileA(hDlg,sourceFile,MAX_PATH,"*.*\0*.*\0\0");
			if(SUCCEEDED(hr))			
			{
				kedit.SetText(sourceFile);				
			}
			break;
		case IDC_CMPTOOL:
			hr = GetOpenFileA(hDlg, toolFile, MAX_PATH, "�ȽϹ���(*.exe)\0*.exe\0\0");
			if(SUCCEEDED(hr))
				RegisterCompareToolPath(toolFile);
			break;
		case IDVIEW:
			{					
				DWORD cbData, type;
				GetCompareToolPath(toolPath, &cbData, &type);
				std::string cmd;
				strcat(toolPath, " ");
				cmd = toolPath;
				CopyFileA(sourceFile,newestFile,FALSE);
				cmd.append(1,'\"');
				cmd.append(backupfile);
				cmd.append("\" ");
				cmd.append(1,'\"');
				cmd.append(newestFile);
				cmd.append(1,'\"');
				char* pCmd = strdup(cmd.c_str());
				ExecCommand(pCmd);
				free(pCmd);
			}
			break;
		case IDEDIT:
			GetWindowText((HWND)kedit,sourceFile,MAX_PATH);
			if(IsFileExist(sourceFile))
			{				
				std::string cmd(szExeFile);
				cmd.append(" \"");
				cmd.append(sourceFile);
				cmd.append(1,'\"');
				char* pCmd = strdup(cmd.c_str());
				ExecCommand(pCmd);
				free(pCmd);
				EnableWindow(GetDlgItem(hDlg,IDC_FLUSH),TRUE);
				CopyFileA(sourceFile,backupfile,FALSE);
				CopyFileA(sourceFile,newestFile,FALSE);				
			}
			break;
		case IDC_FLUSH:
			CopyFileA(newestFile,backupfile,FALSE);
			SendMessage(hDlg,WM_COMMAND,MAKEWPARAM(IDVIEW,0),0);
			break;
		}
		return TRUE;		
	}
	return FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,           
					 int       nCmdShow)
{	
	hInst = hInstance;
	static char toolFile[MAX_PATH] = "";
	HRESULT hr;
	do
	{
		hr = GetOpenFileA(NULL, toolFile, MAX_PATH, "�༭�ļ�����(*.exe)\0*.exe\0\0");
	}while(FAILED(hr));
	RegisterEditToolPath(toolFile);
	static char cmpTool[MAX_PATH] = "";	
	DWORD cbGet, getType;
	if(GetCompareToolPath(cmpTool, &cbGet, &getType) != ERROR_SUCCESS)
	{
		do
		{
			hr = GetOpenFileA(NULL, cmpTool, MAX_PATH, "�Ƚ��ļ�����(*.exe)\0*.exe\0\0");
		}while(FAILED(hr));
	}	
	RegisterCompareToolPath(cmpTool);
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG),NULL,DlgProc,LPARAM(toolFile));
	return 0;
}




