//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by htmlcmp.rc
//
#define IDC_FLUSH                       4
#define IDC_CMPTOOL                     5
#define IDD_DIALOG                      101
#define IDI_OPEN                        105
#define IDI_EDIT                        106
#define IDI_REFLUSH                     107
#define IDC_EDIT                        1000
#define IDC_EXEOPEN                     1005
#define IDEDIT                          1005
#define IDC_OPEN                        1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
