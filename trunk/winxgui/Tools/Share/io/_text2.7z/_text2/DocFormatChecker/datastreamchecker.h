// -------------------------------------------------------------------------
//	�ļ���		��	datastreamchecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __DATASTREAMCHECKER_H__
#define __DATASTREAMCHECKER_H__
#include "docchecktemplate.h"

class KDataStreamChecker : public KDocCheckTemplate
{
public:
	KDataStreamChecker(IStorage* pDocStorage);
	virtual ~KDataStreamChecker();
private:
	virtual HRESULT CheckSelf();
private:
	IStorage* m_pDocStorage;
	IStream* m_pDataStream;
};

#endif //__DATASTREAMCHECKER_H__