// tablestreamchecker.cpp for KTableStreamChecker
//----------------------------------------------------------
#include "stdafx.h"
#include "tablestreamchecker.h"
#include "chpchecker.h"
#include "shtchecker.h"
#include "ffnchecker.h"

const WCHAR g_szTableStrmName[2][8]	= { L"0Table", L"1Table" };

KTableStreamChecker::KTableStreamChecker(IStorage* pDocStorage, IStream* pMainStream, LARGE_INTEGER nSeekPos, UINT16 fWhichTable, BOOL fEncrypted) 
                                    : m_pDocStorage(pDocStorage),
                                      m_pMainStream(pMainStream),
									  m_fWhichTable(fWhichTable),
									  m_pFclcb(NULL),
									  m_fEncrypted(fEncrypted),
									  m_pTableStream(NULL)
{
	m_dlibMove = nSeekPos;
	ASSERT(m_pDocStorage);
	m_pDocStorage->AddRef();
	ASSERT(m_pMainStream);
	m_pMainStream->AddRef();
}

KTableStreamChecker::~KTableStreamChecker()
{
	DELETECHECKERLIST(m_SubCheckers);
	RELEASE(m_pTableStream);
	RELEASE(m_pMainStream);
	RELEASE(m_pDocStorage);
	if(m_pFclcb)
		delete[] m_pFclcb;
}

HRESULT KTableStreamChecker::CheckSelf()
{
	HRESULT hr = E_FAIL;
	WORD cntw;
	
	//��λ���洢FCBLCB��λ��
	m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);
	
	m_pMainStream->Read(&cntw, sizeof(cntw), &m_cbRead);
	ASSERT(m_cbRead == sizeof(cntw));
	
	//��ȡFCLCB
	if(!m_fEncrypted)
	{
		m_pFclcb = new FCLCB[cntw];
		m_pMainStream->Read(m_pFclcb, cntw * sizeof(FCLCB), &m_cbRead);
		ASSERT(m_cbRead == cntw * sizeof(FCLCB));
	}
	
	//���Դ�TableStream��
	hr = m_pDocStorage->OpenStream(
		g_szTableStrmName[m_fWhichTable],
		NULL,
		STGM_SHARE_EXCLUSIVE|STGM_READ,
		0,
		&m_pTableStream);

	if(FAILED(hr))
	{
		TRACE("Can not Open table stream!\n");
		return E_OPENTABLESTREAMFAIL;
	}
	ASSERT(m_pTableStream);
	return hr;
}

void KTableStreamChecker::InitSubItem()
{
	if(m_fEncrypted)
		return;
	IKDocFormatChecker* pSubChecker = new KCHPChecker(m_pMainStream, m_pTableStream, m_pFclcb + PlcfbteChpx);
	m_SubCheckers.push_back(pSubChecker);
	//PAP�ļ�鰴�����ڵ�������CHPû��ʲô�������Ҳ��KCHPChecker��ʵ��
	pSubChecker = new KCHPChecker(m_pMainStream, m_pTableStream, m_pFclcb + PlcfbtePapx);
	m_SubCheckers.push_back(pSubChecker);

	pSubChecker = new KSHTChecker(m_pTableStream, m_pFclcb + Stshf);
	m_SubCheckers.push_back(pSubChecker);

	pSubChecker = new KFFNChecker(m_pTableStream, m_pFclcb + Sttbfffn);
	m_SubCheckers.push_back(pSubChecker);

	
}

									 