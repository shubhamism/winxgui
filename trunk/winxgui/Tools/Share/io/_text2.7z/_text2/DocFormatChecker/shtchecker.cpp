//---------------------------------------------------------
// shtchecker.cpp for KSHTChecker
#include "stdafx.h"
#include "shtchecker.h"

KSHTChecker::KSHTChecker(IStream* pTableStream, const FCLCB* pStshf)
					: m_pTableStream(pTableStream),
					  m_pStshf(pStshf),
					  m_pStshi(NULL)
{
	ASSERT(m_pTableStream);
	m_pTableStream->AddRef();
}
KSHTChecker::~KSHTChecker()
{
	RELEASE(m_pTableStream);
}

HRESULT KSHTChecker::CheckSelf()
{
	HRESULT hr = E_FAIL;
	ULISet32(m_dlibMove, m_pStshf->fc);
	m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);
	ASSERT(m_pStshf->fc == m_dlibMove.LowPart);

	BYTE* pSTDbasebuf = NULL;
	BASE_STD10* pSTDbase = NULL;
    USHORT cntw = 0;
	int index = 0;
	
	hr = m_pTableStream->Read(&cntw, sizeof(USHORT), &m_cbRead);
	if(FAILED(hr))
	{
		TRACE("Can not read style sheet!\n");
		hr = W_SHTREADFAILED;
		goto KS_EXIT;
	}
	m_pStshi = (STSHI*)malloc(cntw * sizeof(BYTE));
	hr = m_pTableStream->Read(m_pStshi, sizeof(BYTE) * cntw, &m_cbRead);
	if(FAILED(hr))
	{
		TRACE("Can not read style sheet!\n");
		hr = W_SHTREADFAILED;
		goto KS_EXIT;
	}
	pSTDbasebuf = (BYTE*)malloc(m_pStshi->cbSTDBaseInFile * sizeof(BYTE));
	
	while(index < m_pStshi->cstd)
	{
        m_pTableStream->Read(&cntw, sizeof(USHORT), &m_cbRead);
		if(cntw != 0)
		{
			m_pTableStream->Read(pSTDbasebuf, m_pStshi->cbSTDBaseInFile, &m_cbRead);
			pSTDbase = (BASE_STD10*)pSTDbasebuf;
            if(cntw != pSTDbase->bchUpe)
			{
				hr = W_STYLEINCOMPLET;
				TRACE("Style is incomplete!\n");
				ASSERT(FALSE);
				goto KS_EXIT;
			}
			if(cntw % 2)
			{
				hr = W_STDNOTONEVENBOUND;
				TRACE("STD is not begin on even bound!\n");
				ASSERT(FALSE);
				goto KS_EXIT;
			}
			ULISet32(m_dlibMove, cntw - m_pStshi->cbSTDBaseInFile);
			m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);
		}
		index++;
	}

	ULISet32(m_dlibMove, 0);
	m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);

	if((m_dlibMove.LowPart - m_pStshf->fc) != m_pStshf->lcb)
	{
		hr = W_STYLESHEETINCOMPLET;
		TRACE("Style Sheet is incomplete!\n");
		ASSERT(FALSE);
		goto KS_EXIT;
	}

KS_EXIT:
	if(m_pStshi)
		free(m_pStshi);
	if(pSTDbase)
		free(pSTDbasebuf);
	return hr;
	
}