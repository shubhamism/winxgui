// ------------------------------------------------------------------
// datastreamchecker.cpp for KDataStreamChecker

#include "stdafx.h"
#include "datastreamchecker.h"

const WCHAR g_szDataStrmName[]		= L"Data";

KDataStreamChecker::KDataStreamChecker(IStorage* pDocStorage)
									: m_pDocStorage(pDocStorage),
									  m_pDataStream(NULL)
{
	ASSERT(m_pDocStorage);
	m_pDocStorage->AddRef();
}

KDataStreamChecker::~KDataStreamChecker()
{
	RELEASE(m_pDataStream);
	RELEASE(m_pDocStorage);
}

HRESULT KDataStreamChecker::CheckSelf()
{
	HRESULT hr = m_pDocStorage->OpenStream(
							g_szDataStrmName, 
							NULL,
							STGM_SHARE_EXCLUSIVE|STGM_READ,
							0,
							&m_pDataStream);
	//������
    if(FAILED(hr))
	{
        TRACE("Can not Open DataStream, result is %08x\n", hr);
		return W_INVALIDDATASTREAM;
	}
	//�ټ���һ���������������ݵ��ж�
	LARGE_INTEGER dlibEndPos;
	ULISet32(dlibEndPos, 0);
	m_pDataStream->Seek(dlibEndPos, STREAM_SEEK_END, (ULARGE_INTEGER*)&dlibEndPos);
	ULISet32(m_dlibMove, 0);
	m_pDataStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);

	BYTE buf[100];
	BOOL ret = FALSE;
	int i = 0;
	while(m_dlibMove.HighPart <= dlibEndPos.HighPart 
		&& m_dlibMove.LowPart < dlibEndPos.LowPart - 100)
	{
		m_pDataStream->Read(buf, 100, &m_cbRead);
		for(i = 0; i < 100; i++)
		{
			if(buf[i])
			{
				ret = TRUE;
				break;
			}
		}

		if(ret)
			break;
	}

	if(!ret)
	{
		ULISet32(m_dlibMove, 0);
		m_pDataStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);

		ASSERT(m_dlibMove.HighPart <= dlibEndPos.HighPart 
			&& (dlibEndPos.LowPart - m_dlibMove.LowPart) < 100);

		int nLen = dlibEndPos.LowPart - m_dlibMove.LowPart;
		m_pDataStream->Read(buf, nLen, &m_cbRead);
		for(i = 0; i < nLen; i++)
		{
			if(buf[i])
			{
				ret = TRUE;
				break;
			}
		}
	}

	if(!ret)
	{
		TRACE("Data content is incomplete!\n");
		ASSERT(FALSE);
		hr = W_DATACONTENTINCOMPLETE;
	}

	return hr;
}