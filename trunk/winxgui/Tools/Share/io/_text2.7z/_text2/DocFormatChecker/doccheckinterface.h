// -------------------------------------------------------------------------
//	�ļ���		��	doccheckinterface.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __DOCCHECKINTERFACE_H__
#define __DOCCHECKINTERFACE_H__
#include "stdafx.h"
#include <list>
#include <algorithm>


interface IKDocFormatChecker
{
	virtual HRESULT __stdcall CheckDocFormat() = 0;
	virtual ~IKDocFormatChecker() {};
};



typedef list<IKDocFormatChecker*> SubCheckerList;
typedef list<IKDocFormatChecker*>::iterator SubCheckerListIter;

inline void DeleteSubChecker(IKDocFormatChecker* pChecker)
{
	delete pChecker;
}

#define DELETECHECKERLIST( list )                             \
{                                                             \
	for_each(list.begin(), list.end(), DeleteSubChecker);     \
	list.clear();                                             \
}

#endif //__DOCFORMATCHECKER_H__