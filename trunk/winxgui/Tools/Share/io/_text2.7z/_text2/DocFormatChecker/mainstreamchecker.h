// -------------------------------------------------------------------------
//	�ļ���		��	MainStreamChecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __MAINSTREAMCHECKER_H__
#define __MAINSTREAMCHECKER_H__

#include "docchecktemplate.h"

class KMainStreamChecker : public KDocCheckWithlistTemp  
{
public:
	KMainStreamChecker(IStorage* pDocStorage);
	virtual ~KMainStreamChecker();
private:
	virtual HRESULT CheckSelf();
	void InitSubItem();
	HRESULT CheckFibLong();

private:
	IStorage* m_pDocStorage;
	IStream* m_pMainStream;
	IStream* m_pTableStream;
	
	FIB_HEADER m_hdrFIB;

	LARGE_INTEGER m_tablepos;
};

#endif // MAINSTREAMCHECKER
