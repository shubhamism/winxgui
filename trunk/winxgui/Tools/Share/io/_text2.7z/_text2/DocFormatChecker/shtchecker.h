// -------------------------------------------------------------------------
//	�ļ���		��	shtchecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __SHTCHECKER_H__
#define __SHTCHECKER_H__
#include "docchecktemplate.h"

class KSHTChecker : public KDocCheckTemplate
{
public:
	KSHTChecker(IStream* pTableStream, const FCLCB* pStshf);
	virtual ~KSHTChecker();
private:
	virtual HRESULT CheckSelf();
private:
	IStream* m_pTableStream;
	const FCLCB* m_pStshf; 
	STSHI*  m_pStshi;
};

#endif //__SHTCHECKER_H__