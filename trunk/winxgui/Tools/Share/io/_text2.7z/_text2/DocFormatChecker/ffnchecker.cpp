//-----------------------------------------------------
// ffnchecker.cpp for KFFNChecker

#include "stdafx.h"
#include "ffnchecker.h"

KFFNChecker::KFFNChecker(IStream* pTableStream, const FCLCB* psttbfffn)
					: m_pTableStream(pTableStream),
					  m_psttbfffn(psttbfffn)
{
	ASSERT(m_pTableStream);
	m_pTableStream->AddRef();
}
KFFNChecker::~KFFNChecker()
{
	RELEASE(m_pTableStream);
}

HRESULT KFFNChecker::CheckSelf()
{
	ULISet32(m_dlibMove, m_psttbfffn->fc);
	m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);
	
	USHORT cntw = 0;
	m_pTableStream->Read(&cntw, sizeof(USHORT), &m_cbRead);
	int index = 0;
	ULISet32(m_dlibMove, sizeof(USHORT));
	//doc�ĵ���ͷ��λ����
	m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove); //cbExtra
	const int nffnslen = cntw;
	while(index < nffnslen)
	{
		m_pTableStream->Read(&cntw, sizeof(UCHAR), &m_cbRead); //cbFFn
		ULISet32(m_dlibMove, cntw);
		m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);
		index++;
	}

	ULISet32(m_dlibMove, 0);
	m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);

	if(m_dlibMove.LowPart - m_psttbfffn->fc != m_psttbfffn->lcb)
	{
		TRACE("Sttbfffn is incomplete!\n");
		ASSERT(FALSE);
		return W_FFNINCOMPLET;
	}

	return S_OK;
}