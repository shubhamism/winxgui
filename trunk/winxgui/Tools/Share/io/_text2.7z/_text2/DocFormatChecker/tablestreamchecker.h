// -------------------------------------------------------------------------
//	�ļ���		��	tablestreamchecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __TABLESTREAMCHECKER_H__
#define __TABLESTREAMCHECKER_H__

#include "docchecktemplate.h"

class KTableStreamChecker : public KDocCheckWithlistTemp 
{
public:
	KTableStreamChecker(IStorage* pDocStorage, IStream* pMainStream, LARGE_INTEGER nSeekPos, UINT16 fWhichTable, BOOL fEncrypted);
	virtual ~KTableStreamChecker();
private:
	virtual HRESULT CheckSelf();
	void InitSubItem();
private:
	IStorage* m_pDocStorage;
	IStream* m_pMainStream;
	IStream* m_pTableStream;
	FCLCB* m_pFclcb;
	UINT16 m_fWhichTable;
	BOOL m_fEncrypted;
};

#endif
