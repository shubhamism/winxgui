//-------------------------------------------------------------------------
// chpchecker.cpp for KCHPChecker

#include "stdafx.h"
#include "chpchecker.h"

const USHORT FKP_BYTES = 512;

KCHPChecker::KCHPChecker(IStream* pMainStream, IStream* pTableStream, const FCLCB* pPlcfbteChpx)
						: m_pMainStream(pMainStream),
						  m_pTableStream(pTableStream),
						  m_pPlcfbteChpx(pPlcfbteChpx)
{
	ASSERT(m_pMainStream);
	m_pMainStream->AddRef();
	ASSERT(m_pTableStream);
	m_pTableStream->AddRef();
}

KCHPChecker::~KCHPChecker()
{
	RELEASE(m_pTableStream);
	RELEASE(m_pMainStream);
}

HRESULT KCHPChecker::CheckSelf()
{
	HRESULT hr = E_FAIL;
    
	UINT n = (m_pPlcfbteChpx->lcb - 4) / 8;
	if(n == 0)
	{
		TRACE("Character properties are not stored!\n");
		ASSERT(FALSE);
		return W_CHPNOTEXIST;
	}
	if((n * 8 + 4) != m_pPlcfbteChpx->lcb)
	{
		TRACE("Character proterties are incomplete!\n");
		ASSERT(FALSE);
	}

	ULISet32(m_dlibMove, m_pPlcfbteChpx->fc);
	m_pTableStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);
	FC* pl = (FC*)new BYTE[m_pPlcfbteChpx->lcb];
	hr = m_pTableStream->Read(pl, m_pPlcfbteChpx->lcb, &m_cbRead);
	ASSERT(m_cbRead == m_pPlcfbteChpx->lcb);

	if(FAILED(hr))
	{
		TRACE("Can not read plctbteChpx!\n");
	}
	else
	{
		UINT iFKP;
		UINT nValidRange;
		FC fc;
		UCHAR crun; 
		for(int i = 0; i < n; i++)
		{
			iFKP = pl[n + i + 1];
			nValidRange = pl[i+1];
			
			ULISet32(m_dlibMove, iFKP * FKP_BYTES + (FKP_BYTES - 1));
			m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);
			m_pMainStream->Read(&crun, sizeof(UCHAR), &m_cbRead);
			
			ULISet32(m_dlibMove, iFKP * FKP_BYTES + (crun * sizeof(FC)));
			m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_SET, (ULARGE_INTEGER*)&m_dlibMove);
			m_pMainStream->Read(&fc, sizeof(FC), &m_cbRead);
			if(nValidRange != fc)
			{
				TRACE("CHP FKP is incomplete!\n");
				hr = W_CHPFKPINCOMPLET;
				break;
			}
			//�ͼ�鵽�˰ɣ��Ҿ��������¼��ÿһ��sprm����û�ж�����壬�����˷ѿռ��ʱ��		
		}
	}
	//ULONG 
	delete[] pl;
	
	return hr;
}