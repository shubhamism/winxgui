// MainStreamChecker.cpp: implementation of the KMainStreamChecker class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "mainstreamchecker.h"
//sub checkers below
#include "textcontentchecker.h"    
#include "tablestreamchecker.h"



const WCHAR g_szDocStrmName[]		= L"WordDocument";


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

KMainStreamChecker::KMainStreamChecker(IStorage* pDocStorage) : m_pDocStorage(pDocStorage),
																m_pMainStream(NULL),
																m_pTableStream(NULL)
{
	ASSERT(pDocStorage);
	pDocStorage->AddRef();
}


KMainStreamChecker::~KMainStreamChecker()
{
	DELETECHECKERLIST(m_SubCheckers);
	RELEASE(m_pDocStorage);
	RELEASE(m_pMainStream);
	RELEASE(m_pTableStream);
}

HRESULT KMainStreamChecker::CheckSelf()
{
	HRESULT hr = E_FAIL;
	WORD cntw;
	
	hr = m_pDocStorage->OpenStream(
		g_szDocStrmName, 
		NULL,
		STGM_SHARE_EXCLUSIVE|STGM_READ,
		0,
		&m_pMainStream);

	//������
    if(FAILED(hr))
	{
        TRACE("Can not Open MainStream, result is %08x\n", hr);
		return E_MAINSTREAMOPENFAIL;
	}
    ASSERT(m_pMainStream);
	
	//��ȡFIB
	hr = m_pMainStream->Read(&m_hdrFIB, sizeof(m_hdrFIB), &m_cbRead);
	if(FAILED(hr))
	{
		TRACE("Can not Read Fib, result is %x\n", hr);	
		return E_READFIBFAIL;
	}
	
	//���FIB�ɹ��������ˣ����µ�Read�����ݲ����з���ֵ�����

	//��ȡWordArray����
	m_pMainStream->Read(&cntw, sizeof(cntw), &m_cbRead);
	ASSERT(m_cbRead == sizeof(cntw));
	ULISet32(m_dlibMove, cntw * sizeof(WORD));
	//����WordArray
	m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);

	//��ע��ú����ĵ���λ��
    hr = CheckFibLong();
	if(FAILED(hr))
		return hr;
	
	ULISet32(m_dlibMove, 0);
	m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);
    ULISet32(m_tablepos, m_dlibMove.LowPart);

	return hr;
}

void KMainStreamChecker::InitSubItem()
{
	
    IKDocFormatChecker* pSubChecker = new KTextContnentChecker(m_pMainStream, m_hdrFIB.fcMin, m_hdrFIB.fcMac, m_hdrFIB.fEncrypted);
	m_SubCheckers.push_back(pSubChecker);

	pSubChecker = new KTableStreamChecker(m_pDocStorage, m_pMainStream, m_tablepos, m_hdrFIB.fWhichTblStm, m_hdrFIB.fEncrypted);
	m_SubCheckers.push_back(pSubChecker);	
}

HRESULT KMainStreamChecker::CheckFibLong()
{
	WORD cntw;
	HRESULT hr = S_OK;
	//��ȡLongArray����
	m_pMainStream->Read(&cntw, sizeof(cntw), &m_cbRead);
	ASSERT(m_cbRead == sizeof(cntw));
	if(m_hdrFIB.fEncrypted) 
	{
		ULISet32(m_dlibMove, cntw * sizeof(LONG));
		//����LongArray
		m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&m_dlibMove);
	}
	else
	{
		LONG* plFibLong = (LONG*)malloc(cntw * sizeof(LONG));
		m_pMainStream->Read(plFibLong, cntw * sizeof(LONG), &m_cbRead);

		//���ĵ�����fcMacӦ�õ��ڱ���ʽ�ұ߸���ĺͣ����ǲ���������
		//ֻ�÷ſ������ˡ�
		LONG lTextLen = m_hdrFIB.fcMin +
						plFibLong[ccpText] +
						plFibLong[ccpFtn] +
						plFibLong[ccpHdd] +
						plFibLong[ccpMcr] +
						plFibLong[ccpAtn] +
						plFibLong[ccpEdn] +
						plFibLong[ccpTxbx] +
						plFibLong[ccpHdrTxbx] + 1;
		if(m_hdrFIB.fcMac < lTextLen)
		{
			TRACE("Fib.fcMac is not right!\n ");
			hr = W_INVALIDTEXTLEN;
		}
		free(plFibLong);
	}
	
	return hr;
}
