// -------------------------------------------------------------------------
//	�ļ���		��	textcontentchecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __TEXTCONTENTCHECKER_H__
#define __TEXTCONTENTCHECKER_H__

#include "docchecktemplate.h"


class KTextContnentChecker : public KDocCheckTemplate
{
public:
	KTextContnentChecker(IStream* pMainStream, FC nFcMin, FC nFcMax, BOOL fEncrypted);
	virtual ~KTextContnentChecker();
private:
	virtual HRESULT CheckSelf();
private:
	IStream* m_pMainStream;
	FC m_nFcMin, m_nFcMax;
	BOOL m_fEncrypted;
};

#endif //__TEXTCONTENTCHECKER_H__