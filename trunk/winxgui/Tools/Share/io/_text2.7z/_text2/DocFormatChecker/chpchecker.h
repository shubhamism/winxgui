// -------------------------------------------------------------------------
//	�ļ���		��	chpchecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __CHPCHECKER_H__
#define __CHPCHECKER_H__
#include "docchecktemplate.h"

class KCHPChecker : public KDocCheckTemplate
{
public:
	KCHPChecker(IStream* pMainStream, IStream* pTableStream, const FCLCB* pPlcfbteChpx);
	virtual ~KCHPChecker();
private:
	virtual HRESULT CheckSelf();
private:
	IStream* m_pMainStream;
	IStream* m_pTableStream;
	const FCLCB* m_pPlcfbteChpx; 
};

#endif //__CHPCHECKER_H__