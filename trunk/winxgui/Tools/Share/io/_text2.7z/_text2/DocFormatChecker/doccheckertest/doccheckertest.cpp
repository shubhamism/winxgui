// doccheckertest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <kfc.h>
#include "winerror.h"
extern "C" HRESULT CheckDocFormat(LPCWSTR);

void CheckDoc(LPCWSTR szFileName)
{
	DWORD dwStart = GetTickCount();
	
	//KDocStorageChecker checker(szFileName);
	HRESULT hr = CheckDocFormat(szFileName);

	printf("Checking file, Please wait...\n");

	INT nLen =WideCharToMultiByte(CP_ACP, 0, szFileName, 
		wcslen(szFileName),
		NULL, 0, 0, NULL);
	char* strFileName = (char*)malloc(nLen * 2);
	WideCharToMultiByte(CP_ACP, 0, szFileName,
		nLen, strFileName, nLen*2, 0, NULL);

	printf("File name is %s\n", strFileName);
	
	free(strFileName);
	hr = 0x81041000;

	if(FAILED(hr))
	{
		if((WORD)(hr >> 16) == 0x8004) //FACILITY_ITF
		{
			WORD dwErrorCode = hr & 0x0000FFFF;
			switch(dwErrorCode >> 12)
			{
			case 1:
				printf("�ļ�����ʧ�ܣ��ĵ�����!\n");
				break;
			case 2:
				printf("һ���Ծ���!\n");
				break;
			case 4:
				printf("�ļ����ݱ��治����!\n");
				break;
			default:
				break;
			}

		}
	}

	if(FAILED(hr))
		printf("Check failed!\n");
	else
		printf("Check successed!\n");
	
	printf("Time used : %d ms\n", GetTickCount() - dwStart);	
}

int main()
{
	HANDLE result;
	SEARCHREC rec;
	WCHAR szFileName[100];

	if (__argc < 2)
		return -1;
	
	LPCWSTR szSrcFile = __wargv[1];

	WCHAR szTestFile[MAX_PATH];
	wcscpy(szTestFile, szSrcFile);
	wcscat(szTestFile, L"\\*.wps");
	result = FindFirst(szTestFile, 71, &rec);
	if(result)
	{
		do {
			memset(szFileName, 0, 200);
			wcscpy(szFileName, szSrcFile);
			wcscat(szFileName, L"\\");
			wcscat(szFileName, rec.szFileName);
			CheckDoc(szFileName);
			
		} while(FindNext(result, &rec));
	}

	wcscpy(szTestFile, szSrcFile);
	wcscat(szTestFile, L"\\*.doc");
	result = FindFirst(szTestFile, 71, &rec);
	if(result)
	{
		do {
			memset(szFileName, 0, 200);
			wcscpy(szFileName, szSrcFile);
			wcscat(szFileName, L"\\");
			wcscat(szFileName, rec.szFileName);
			CheckDoc(szFileName);
			
		} while(FindNext(result, &rec));
	}
	//LPCWSTR newFileName = L"C:\\Documents and Settings\\Administrator\\����\\test.wps";
    //CheckDocFormat(newFileName);
	
	return 0;
}

