//---------------------------------------------------------
// textcontentchecker.cpp for KTextContentChecker

#include "stdafx.h"
#include "textcontentchecker.h"

KTextContnentChecker::KTextContnentChecker(IStream* pMainStream, FC nFcMin, FC nFcMac, BOOL fEncrypted) 
                                   : m_pMainStream(pMainStream),
								     m_nFcMin(nFcMin),
									 m_nFcMax(nFcMac - 1),
									 m_fEncrypted(fEncrypted)

{
	ASSERT(m_pMainStream);
	m_pMainStream->AddRef();
}
KTextContnentChecker::~KTextContnentChecker()
{
	RELEASE(m_pMainStream);
}

HRESULT KTextContnentChecker::CheckSelf()
{
	HRESULT hr = E_FAIL;
	BYTE buf[100];
	BOOL ret = FALSE;
	if(m_nFcMin % 512 != 0)
	{
		TRACE("FcMin position not right!\n");
		return W_INVALIDFIBMIN;
	}

	if(m_nFcMax > m_nFcMin)
	{
		ULISet32(m_dlibMove, m_nFcMin);
		m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_SET , (ULARGE_INTEGER*)&m_dlibMove);
        int i = 0;
		int j = 0;
		for(; i < (m_nFcMax - m_nFcMin) / 100; i++)
		{
			m_pMainStream->Read(buf, 100, &m_cbRead);
			for(j = 0; j<100; j++)
			{
				if(buf[j])
				{
					ret = TRUE;
					break;
				}	
			}
			if(ret)
				break;
		}
		if(!ret)
		{
			m_pMainStream->Read(buf, m_nFcMax - m_nFcMin - (100 * i), &m_cbRead);
			for(j = 0; j < m_nFcMax - m_nFcMin - (100 * i); j++)
			{
				if(buf[j])
				{
					ret = TRUE;
					break;
				}
			}
		}
		if(!ret)
			TRACE("Text Content is all zero!\n");
		else if(!m_fEncrypted)
		{
			ULISet32(m_dlibMove, m_nFcMax - 1);
			m_pMainStream->Seek(m_dlibMove, STREAM_SEEK_SET , (ULARGE_INTEGER*)&m_dlibMove);
			m_pMainStream->Read(buf, 2, &m_cbRead);

			//�ĵ��Ͻ���˵��������0x0d00��β�ģ����Ƿ������ĵ���0x0d��β������������������ֽ��ж�

			if(buf[0] != 0xD)
			{
				if(buf[1] != 0xD)
				{
					TRACE("Text end is not by 0xd!\n");
					ret = FALSE;
				}
			}
		}
	}
	else
	{
		TRACE("FcMax position not right!\n");
		ret = FALSE;
	}

	if(!ret)
		return W_TEXTCONTENTINCOMPLETE;
	else
		return S_OK;
	
}
