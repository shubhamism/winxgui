// -------------------------------------------------------------------------
//	�ļ���		��	docstoragechecker.h
//	������		��	zyf
//	����ʱ��	��	2005-12-15 11:57:41
//	��������	��	
//
// -------------------------------------------------------------------------

#ifndef __DOCSTORAGECHECKER_H__
#define __DOCSTORAGECHECKER_H__

#include "docchecktemplate.h"

EXTERN_C HRESULT CheckDocFormat(LPCWSTR szFileName);

class KDocStorageChecker : public KDocCheckTemplate
{
public:
	KDocStorageChecker(LPCWSTR strwFileName);
	virtual ~KDocStorageChecker();
private:
	virtual HRESULT CheckSelf();
	virtual HRESULT CheckSubItem();
	void InitSubItem();	
private:
	IKDocFormatChecker* m_pMainStreamChecker;
	LPWSTR m_strwFileName;
	IStorage* m_pDocStorage;
};



#endif //__DOCSTORAGECHECKER_H__