//docstoragechecker.cpp
#include "stdafx.h"

#include "docstoragechecker.h"
#include "mainstreamchecker.h"

HRESULT CheckDocFormat(LPCWSTR szFileName)
{
	KDocStorageChecker checker(szFileName);
	return checker.CheckDocFormat();
}

KDocStorageChecker::KDocStorageChecker(LPCWSTR strwFileName) : m_pDocStorage(NULL),
															   m_pMainStreamChecker(NULL)
                                                    
{
	ASSERT(strwFileName);
	m_strwFileName = (WCHAR*)malloc(sizeof(WCHAR) * (wcslen(strwFileName)+1));
	wcscpy(m_strwFileName, strwFileName);
}

KDocStorageChecker::~KDocStorageChecker()
{
	delete m_pMainStreamChecker;
	free(m_strwFileName);
	RELEASE(m_pDocStorage);
}

void KDocStorageChecker::InitSubItem()
{
	m_pMainStreamChecker = new KMainStreamChecker(m_pDocStorage);
}

HRESULT KDocStorageChecker::CheckSelf()
{
	HRESULT hr = E_FAIL;
	ASSERT(m_strwFileName);

	INT nLen =WideCharToMultiByte(CP_ACP, 0, m_strwFileName, 
		wcslen(m_strwFileName),
		NULL, 0, 0, NULL);
	char* strFileName = (char*)malloc(nLen * 2);
	WideCharToMultiByte(CP_ACP, 0, m_strwFileName,
		nLen, strFileName, nLen*2, 0, NULL);
    TRACE("Checking : %s\n Please wait...\n", strFileName);
	
	free(strFileName);

	hr = StgOpenStorage(m_strwFileName, NULL, STGM_READ | STGM_TRANSACTED , NULL, NULL, &m_pDocStorage);
	if(FAILED(hr))
	{
		TRACE("Can not Open Storage!\n");	
		TRACE("Open result is %p\n", E_STORAGEDAMAGE);
		return E_STORAGEDAMAGE;
	}
	ASSERT(m_pDocStorage);
	InitSubItem();
	return hr;
}


HRESULT KDocStorageChecker::CheckSubItem()
{
	ASSERT(m_pMainStreamChecker);
	return m_pMainStreamChecker->CheckDocFormat();
}
