/* -------------------------------------------------------------------------
//	�ļ���		��	html2dochandler.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-26 16:25:56
//	��������	��	
//
//	$Id: html2dochandler.cpp,v 1.22 2006/10/12 01:12:26 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "factory.h"
#include "html2dochandler.h"
#include "handledom.h"
#include "htm/htm2utf8encode.h"
#include "serve.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Html2DocHandler::Html2DocHandler(const char* szDoc)
{
	USES_CONVERSION;
	m_factory = new BaseFactory();
	m_factory->SetRootHandler(this);
	m_doc.NewDocument(A2W(szDoc));	
	fClosed = false;
}

STDMETHODIMP Html2DocHandler::Close()
{	
	if(!fClosed)
	{
		fClosed = true;
		m_doc.Close();
		BaseHtmlHandler::Close();
	}
	return S_OK;
}

STDMETHODIMP_(HandlerType) Html2DocHandler::GetHandlerType()
{
	return ht_html2dochandler;
}

Html2DocHandler::~Html2DocHandler()
{
	Close();
}

STDMETHODIMP Html2Doc(int argc, char** argv)
{
	const char* htmFile = argv[argc-1];
	char docFile[MAX_PATH] = "";
	strcpy(docFile, htmFile);
	char* pExt = strrchr(docFile, '.');
	if(pExt)
		strcpy(pExt, ".doc");
	else
		strcat(docFile, ".doc");
	Html2DocHandler handler(docFile);
	HGLOBAL hgbl = NULL; ULONG cbUtf8;
	ks_wstring srcfile=htmFile;
	HRESULT hr = Htm2Utf8Encode(srcfile.c_str(), STGM_READ|STGM_SHARE_DENY_NONE, &hgbl, &cbUtf8, NULL);
	if(FAILED(hr))
	{
		GlobalFree(hgbl);
		return E_FAIL;
	}
	ks_stdptr<IStream> utf8strm;
	CreateStreamOnHGlobal(hgbl, FALSE, &utf8strm);	
	handler.Handle(utf8strm);
	handler.Close();
	GlobalFree(hgbl);
	return S_OK;
}