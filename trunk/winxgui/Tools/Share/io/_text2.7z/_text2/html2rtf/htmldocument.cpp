/* -------------------------------------------------------------------------
//	�ļ���		��	htmldocument.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-8 11:10:08
//	��������	��	
//
//	$Id: htmldocument.cpp,v 1.4 2006/07/26 07:46:22 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htmldocument.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP HtmlDocument::AddText(const char* buf, long len)
{
	if(len <= 0)
		return E_FAIL;	
	ks_wstring wstr;
	wstr.assign(cp_utf8, buf, len);
	NewNullPapxParagraph();
	NewNullChpxSpan();
	AddContent(wstr.c_str(), wstr.size());
	return S_OK;
}
