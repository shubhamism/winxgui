/* -------------------------------------------------------------------------
//	�ļ���		��	p.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-29 9:29:24
//	��������	��	
//
//	$Id: p.cpp,v 1.7 2006/07/24 01:28:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <html2dochandler.h>
#include <htmldocument.h>
#include "p.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(Bool) PHandler::IsSame(Node* node)
{
	if(!node)
		return no;
	const char* name = node->getName();
	if(!name)
		return no;
	if(!stricmp(name, "p"))
		return yes;
	return no;
}

STDMETHODIMP PHandler::Text(Node* node)
{
	HandlerType ht = m_handler->GetHandlerType();
	switch(ht)
	{
	case ht_html2dochandler:
		{
			Html2DocHandler* handler = (Html2DocHandler*)m_handler;
			const char* buf = handler->GetLexer()->getNodeBuff(node);
			long len =  node->getTextEnd() - node->getTextStart();	
			handler->m_doc.AddText(buf, len);
			return S_OK;
		}
	}
	return E_FAIL;
}
