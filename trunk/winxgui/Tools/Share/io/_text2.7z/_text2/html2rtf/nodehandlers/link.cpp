/* -------------------------------------------------------------------------
//	�ļ���		��	link.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-26 16:07:34
//	��������	��	
//
//	$Id: link.cpp,v 1.1 2006/07/27 03:41:46 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attr2name.h"
#include "link.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP linkHandler::Start(Node* node)
{
	AttVal* att = NULL;
	for(att = node->getAttrList(); att != NULL; att = att->getNextAttVal())
	{
		const char* name = att->getAttribute();
		const char* value = att->getValue();
		int id = _GetAttrId(name);
	}
	return S_OK;
}
