/* -------------------------------------------------------------------------
//	�ļ���		��	basenodehandler.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-26 18:07:50
//	��������	��	
//
//	$Id: basenodehandler.cpp,v 1.1 2006/07/27 03:41:46 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htmlhandler.h"
#include "html2dochandler.h"
#include "nodehandler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BaseNodeHandler::BaseNodeHandler()
{
	m_handler = NULL;
}

STDMETHODIMP_(HtmlHandler*) BaseNodeHandler::SetRootHandler(HtmlHandler* handler)
{
	HtmlHandler* old = m_handler;
	if(!handler)
		return old;
	m_handler = handler;
	return old;
}

STDMETHODIMP BaseNodeHandler::Start(Node* node)
{
	return S_OK;
}

STDMETHODIMP BaseNodeHandler::End(Node* node)
{
	return S_OK;
}

STDMETHODIMP BaseNodeHandler::Text(Node* node)
{
	HandlerType ht = m_handler->GetHandlerType();
	switch(ht)
	{
	case ht_html2dochandler:
		{
			Html2DocHandler* handler = (Html2DocHandler*)m_handler;
			const char* buf = handler->GetLexer()->getNodeBuff(node);
			long len =  node->getTextEnd() - node->getTextStart();	
			handler->m_doc.AddText(buf, len);
			return S_OK;
		}
	}
	return S_OK;
}

STDMETHODIMP_(Bool) BaseNodeHandler::IsSame(Node* node)
{		
	return yes;
}