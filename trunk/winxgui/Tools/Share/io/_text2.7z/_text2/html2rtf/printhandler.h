/* -------------------------------------------------------------------------
//	�ļ���		��	printhandler.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-6-27 13:02:16
//	��������	��	
//
//	$Id: printhandler.h,v 1.6 2006/07/26 07:46:22 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PRINTHANDLER_H__
#define __PRINTHANDLER_H__
#include <htmlhandler.h>
class HandleDOM;
class PrintEventHandler : public BaseHtmlHandler
{
private:
	STDMETHODIMP _Init(HandleDOM* dom);
	STDMETHODIMP _HandleDocTypeTag(Node*);
	STDMETHODIMP _HandleCommentTag(Node*);
	STDMETHODIMP _HandleProcInsTag(Node*);
	STDMETHODIMP _HandleTextNode(Node*);
	STDMETHODIMP _HandleStartTag(Node*);
	STDMETHODIMP _HandleEndTag(Node*);
	STDMETHODIMP _HandleStartEndTag(Node*);
	STDMETHODIMP _HandleCDATATag(Node*);
	STDMETHODIMP _HandleSectionTag(Node*);
	STDMETHODIMP _HandleAspTag(Node*);
	STDMETHODIMP _HandleJsteTag(Node*);
	STDMETHODIMP _HandlePhpTag(Node*);
	STDMETHODIMP _HandleXmlDecl(Node*);
public:
	PrintEventHandler(const char* logfile);
	~PrintEventHandler();
private:
	void _fpus(const char* s)
	{
		if(!s)
			return;
		fputs(s, m_f);
	}
	void _fputc(int ch, int cch = 1)
	{
		while(cch)
		{
			fputc(ch, m_f);
			--cch;
		}
	}
private:
	FILE* m_f;	
	int m_indent;	
};

// -------------------------------------------------------------------------
//	$Log: printhandler.h,v $
//	Revision 1.6  2006/07/26 07:46:22  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.5  2006/07/24 01:28:06  xulingjiao
//	�����е�htm�ļ�ת����utf-8����
//	
//	Revision 1.4  2006/06/27 09:13:09  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.3  2006/06/27 06:28:52  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/06/27 06:07:52  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.1  2006/06/27 04:53:13  xulingjiao
//	��ӡ�¼�
//	

#endif /* __PRINTHANDLER_H__ */
