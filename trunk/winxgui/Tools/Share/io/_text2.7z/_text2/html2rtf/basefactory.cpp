/* -------------------------------------------------------------------------
//	�ļ���		��	basefactory.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-20 18:41:45
//	��������	��	
//
//	$Id: basefactory.cpp,v 1.3 2006/10/09 04:11:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#include "stdafx.h"
#include "elem2name.h"
#include "nodehandlers/meta.h"
#include "nodehandlers/p.h"
#include "nodehandlers/link.h"
#include "nodehandlers/a.h"
#include "nodehandlers/acronym.h"
#include "nodehandlers/address.h"
#include "nodehandlers/b.h"
#include "nodehandlers/base.h"
#include "nodehandlers/big.h"
#include "nodehandlers/blockquote.h"
#include "nodehandlers/body.h"
#include "nodehandlers/br.h"
#include "nodehandlers/caption.h"
#include "nodehandlers/center.h"
#include "nodehandlers/cite.h"
#include "nodehandlers/code.h"
#include "nodehandlers/col.h"
#include "nodehandlers/colgroup.h"
#include "nodehandlers/dd.h"
#include "nodehandlers/del.h"
#include "nodehandlers/dfn.h"
#include "nodehandlers/div.h"
#include "factory.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BaseFactory::BaseFactory()
{
	m_handler = NULL;
}

#define NewNodeHandler(nameHandler, root)\
{\
	NodeHandler* handler = NULL;\
	handler = new nameHandler();\
	handler->SetRootHandler(root);\
	return handler;\
}
	

// �⺯�����Ը�д�ɸ����ٵ�
STDMETHODIMP_(NodeHandler*) BaseFactory::GetHandler(Node* node)
{
	const char* name = node->getName();
	if(!name)
	{
		ASSERT_ONCE(0);
		return NULL;
	}
	int id = _GetElementId(name);	
	switch(id)
	{
	case elem_meta:
		NewNodeHandler(metaHandler, m_handler);
		break;
	case elem_p:
		NewNodeHandler(PHandler, m_handler);
		break;
	case elem_link:
		NewNodeHandler(linkHandler, m_handler);
		break;
	case elem_a:
		NewNodeHandler(aHandler, m_handler);
		break;
	case elem_acronym:
		NewNodeHandler(acronymHandler, m_handler);
		break;
	case elem_address:
		NewNodeHandler(addressHandler, m_handler);
		break;
	case elem_b:
		NewNodeHandler(bHandler, m_handler);
		break;
	case elem_base:
		NewNodeHandler(baseHandler, m_handler);
		break;
	case elem_big:
		NewNodeHandler(bigHandler, m_handler);
		break;
	case elem_blockquote:
		NewNodeHandler(blockquoteHandler, m_handler);
		break;
	case elem_body:
		NewNodeHandler(bodyHandler, m_handler);
		break;
	case elem_br:
		NewNodeHandler(brHandler, m_handler);
		break;
	case elem_caption:
		NewNodeHandler(captionHandler, m_handler);
		break;
	case elem_center:
		NewNodeHandler(centerHandler, m_handler);
		break;
	case elem_cite:
		NewNodeHandler(citeHandler, m_handler);
		break;
	case elem_code:
		NewNodeHandler(codeHandler, m_handler);
		break;
	case elem_col:
		NewNodeHandler(colHandler, m_handler);
		break;
	case elem_colgroup:
		NewNodeHandler(colgroupHandler, m_handler);
		break;
	case elem_dd:
		NewNodeHandler(ddHandler, m_handler);
		break;
	case elem_del:
		NewNodeHandler(delHandler, m_handler);
		break;
	case elem_dfn:
		NewNodeHandler(dfnHandler, m_handler);
		break;
	case elem_div:
		NewNodeHandler(divHandler, m_handler);
		break;
	default:
		ASSERT_ONCE(0);
		return NULL;
	}
	ASSERT_ONCE(0);
	return NULL;
}

STDMETHODIMP_(HtmlHandler*) BaseFactory::SetRootHandler(HtmlHandler* handler)
{
	HtmlHandler* old = m_handler;
	if(!handler)
		return old;
	m_handler = handler;
	return old;
}