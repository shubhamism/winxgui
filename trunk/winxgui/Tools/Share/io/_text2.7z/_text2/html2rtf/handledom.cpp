/* -------------------------------------------------------------------------
//	�ļ���		��	handledom.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-27 10:25:30
//	��������	��	
//
//	$Id: handledom.cpp,v 1.16 2006/08/15 04:45:10 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <htmlhandler.h>
#include <handledom.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HandleDOM::HandleDOM(IStream* htmStream) : m_lexer(NULL), m_strm(NULL), m_control(0)
{	
	KS_ASSIGN(m_strm, htmStream);	
	m_lexer = CreateLexer(m_strm, UTF8);
}

STDMETHODIMP HandleDOM::SetControlState(CONTROL_STATE state)
{
	m_control |= state;
	return S_OK;
}

HandleDOM::HandleDOM(LPCWSTR htmFile) : m_lexer(NULL), m_strm(NULL), m_control(0)
{		
	HRESULT hr = CreateStreamOnFile(htmFile, STGM_READ|STGM_SHARE_DENY_NONE, &m_strm);
	if(SUCCEEDED(hr))
		m_lexer = CreateLexer(m_strm, UTF8);
}

HandleDOM::~HandleDOM()
{
	KS_RELEASE(m_strm);
	delete m_lexer;
}

STDMETHODIMP_(Lexer*) HandleDOM::GetLexer()
{
	return m_lexer;
}

STDMETHODIMP HandleDOM::Handle(HtmlHandler* handler)
{
	Node* document = m_lexer->GetRootNode();
	_Dispatch(document, handler);
	return S_OK;
}

STDMETHODIMP HandleDOM::_Dispatch(Node* node, HtmlHandler* handler)
{		
	if(node == NULL)
		return E_FAIL;
	if(m_control & stop_handle)
		return E_FAIL;
	Node* content = NULL;
	if(  node->getType() == Node::TextNode || 
		 (node->getType() == Node::CDATATag && EscapeCdata)	  )
	{
		handler->_HandleTextNode(node);
	}
	else if (node->getType() == Node::CommentTag)
	{
		handler->_HandleCommentTag(node);
	}	
	else if (node->getType() == Node::DocTypeTag)
	{
		handler->_HandleDocTypeTag(node);
	}
	else if (node->getType() == Node::ProcInsTag)
	{
		handler->_HandleProcInsTag(node);
	}
	else if (node->getType() == Node::XmlDecl)
	{
		handler->_HandleXmlDecl(node);
	}
	else if (node->getType() == Node::CDATATag)
	{
		handler->_HandleCDATATag(node);
	}
	else if (node->getType() == Node::SectionTag)
	{
		handler->_HandleSectionTag(node);
	}
	else if (node->getType() == Node::AspTag)
	{
		handler->_HandleAspTag(node);
	}
	else if (node->getType() == Node::JsteTag)
	{
		handler->_HandleJsteTag(node);
	}
	else if (node->getType() == Node::PhpTag)
	{
		handler->_HandlePhpTag(node);
	}
	else if (node->getType() == Node::RootNode)
	{
		handler->_Init(this);
		for(content = node->getContent(); content != NULL; content = content->getNext())		
			_Dispatch(content, handler);
	}
	else
	{		
		if(node->getType() != Node::EndTag)
		{			
			handler->_HandleStartTag(node);
			for(content = node->getContent(); content != NULL; content = content->getNext())
			{
				_Dispatch(content, handler);
			}
			handler->_HandleEndTag(node);
		}
	}
	return S_OK;	
}
