/* -------------------------------------------------------------------------
//	�ļ���		��	printhandler.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-27 13:05:09
//	��������	��	
//
//	$Id: printhandler.cpp,v 1.7 2006/07/26 07:46:22 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <handledom.h>
#include "serve.h"
#include "printhandler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

PrintEventHandler::PrintEventHandler(const char* logfile)
{		
	m_indent = -1;
	m_f = fopen(logfile, "w");
}
PrintEventHandler::~PrintEventHandler()
{	
	fclose(m_f);
}
STDMETHODIMP PrintEventHandler::_Init(HandleDOM* dom)
{
	m_dom = dom;
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleDocTypeTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("DocType:");
	char* nodebuf = m_dom->GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleCommentTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("Comment:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleProcInsTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("ProcIns:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleTextNode(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("TextNode:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleStartTag(Node* node)
{
	if(!node)
		return E_FAIL;
	++m_indent;
	_fputc(' ', m_indent);
	_fpus("<");
	_fpus(node->getName());
	AttVal* att = NULL;
	for(att=node->getAttrList(); att!=NULL; att=att->getNextAttVal())
	{
		_fpus(" ");
		_fpus(att->getAttribute());
		_fpus("=\"");
		_fpus(att->getValue());
		_fpus("\" ");
	}
	_fpus(">\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleEndTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fputc(' ', m_indent);
	--m_indent;
	_fpus("</");
	_fpus(node->getName());
	_fpus(">\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleStartEndTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_HandleStartTag(node);
	_HandleEndTag(node);
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleCDATATag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("CDATA:\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleSectionTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("Section:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleAspTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("Asp:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleJsteTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("Jste:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandlePhpTag(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("Php:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}
STDMETHODIMP PrintEventHandler::_HandleXmlDecl(Node* node)
{
	if(!node)
		return E_FAIL;
	_fpus("XmlDecl:");
	char* nodebuf = GetLexer()->getNodeBuff(node);
	int buflen = node->getTextEnd() - node->getTextStart();
	fwrite(nodebuf, sizeof(char), buflen, m_f);
	_fpus("\n");
	return S_OK;
}

STDMETHODIMP PrintEvent(int argc, char** argv)
{		
	const char* htmFile = argv[argc-1];
	char logfile[MAX_PATH] = "";
	strcpy(logfile, htmFile);
	strcat(logfile, ".log.txt");
	PrintEventHandler handler(logfile);
	USES_CONVERSION;
	handler.Handle(A2W(htmFile));
	return S_OK;
}
