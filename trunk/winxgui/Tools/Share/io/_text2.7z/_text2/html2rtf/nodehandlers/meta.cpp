/* -------------------------------------------------------------------------
//	�ļ���		��	meta.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-8 9:40:04
//	��������	��	
//
//	$Id: meta.cpp,v 1.4 2006/07/26 07:46:22 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attr2name.h"
#include "html2dochandler.h"
#include "meta.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP metaHandler::Start(Node* node)
{	
	for(AttVal* att=node->getAttrList(); att!=NULL; att = att->getNextAttVal())
	{
		const char* name = att->getAttribute();
		const char* value = att->getValue();
		int id = _GetAttrId(name);
		switch(id)
		{
		case htm_attr_http_equiv:			
		case htm_attr_name:
			m_name = value;
			break;
		case htm_attr_content:
			m_value = value;
			break;
		}
	}	
	return _Convert();
}

STDMETHODIMP metaHandler::_Convert()
{	
	char* pDup = _strdup(m_value);
	char* pCharsetValue;
	if(!stricmp(m_name, "content-type"))
	{
		char* pCharset = strstr(pDup, "charset");
		if(!pCharset)
			return E_FAIL;
		pCharset+=7;
		pCharsetValue = strchr(pCharset, '=');
		if(!pCharset)
			return E_FAIL;
		pCharsetValue+=1;
	}	
	free(pDup);
	return S_OK;
}