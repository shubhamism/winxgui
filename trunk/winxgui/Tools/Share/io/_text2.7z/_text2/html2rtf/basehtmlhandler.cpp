/* -------------------------------------------------------------------------
//	�ļ���		��	basehtmlhandler.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-20 18:12:36
//	��������	��	
//
//	$Id: basehtmlhandler.cpp,v 1.4 2006/10/09 04:11:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "factory.h"
#include "html2dochandler.h"
#include "handledom.h"
#include "serve.h"
#include "htmlhandler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BaseHtmlHandler::BaseHtmlHandler() : m_dom(NULL), m_factory(NULL)
{
}

BaseHtmlHandler::~BaseHtmlHandler()
{
	Close();
}

STDMETHODIMP BaseHtmlHandler::Close()
{
	delete m_dom;
	m_dom = NULL;
	delete m_factory;
	m_factory = NULL;
	while(!m_nodehandlers.empty())
	{
		NodeHandler* node = m_nodehandlers.top();		
		m_nodehandlers.pop();
		delete node;
		node = NULL;
	}
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::Handle(IStream* strm)
{	
	delete m_dom;
	m_dom = NULL;
	m_dom = new HandleDOM(strm);
	m_dom->Handle(this);	
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::Handle(LPCWSTR htmFile)
{	
	delete m_dom;
	m_dom = NULL;
	m_dom = new HandleDOM(htmFile);
	m_dom->Handle(this);	
	return S_OK;
}

STDMETHODIMP_(HandlerType) BaseHtmlHandler::GetHandlerType()
{
	return ht_basehandler;
}

STDMETHODIMP_(Lexer*) BaseHtmlHandler::GetLexer()
{
	return m_dom->GetLexer();
}

STDMETHODIMP BaseHtmlHandler::_Init(HandleDOM* dom)
{
	m_dom = dom;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleDocTypeTag(Node* node)
{		
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleCommentTag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleProcInsTag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleTextNode(Node* node)
{
	NodeHandler* hNode = _CurrentNodeHandler(node->getParent());
	if(!hNode)
	{
		ASSERT_ONCE(0);
		return E_FAIL;
	}
	hNode->Text(node);	
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleStartTag(Node* node)
{
	NodeHandler* hNode = m_factory->GetHandler(node);
	if(!hNode)
	{
		ASSERT_ONCE(0);
		return E_FAIL;
	}
	hNode->Start(node);
	m_nodehandlers.push(hNode);
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleEndTag(Node* node)
{
	NodeHandler* hNode = _CurrentNodeHandler(node);
	if(!hNode)
	{
		ASSERT_ONCE(0);
		return E_FAIL;
	}
	hNode->End(node);
	m_nodehandlers.pop();
	delete hNode;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleStartEndTag(Node* node)
{
	HRESULT hr = _HandleStartTag(node);
	if(FAILED(hr))
	{
		ASSERT_ONCE(0);
		return hr;
	}
	hr = _HandleEndTag(node);
	if(FAILED(hr))
	{
		ASSERT_ONCE(0);
		return hr;
	}
	return hr;
}

STDMETHODIMP BaseHtmlHandler::_HandleCDATATag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleSectionTag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleAspTag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleJsteTag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandlePhpTag(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP BaseHtmlHandler::_HandleXmlDecl(Node* node)
{
	if(!node)
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP_(NodeHandler*) BaseHtmlHandler::_CurrentNodeHandler(Node* node)
{
	if(m_nodehandlers.empty())
	{
		ASSERT_ONCE(0);
		return NULL;
	}
	NodeHandler* top = m_nodehandlers.top();
	if(top && top->IsSame(node) != yes)
	{
		ASSERT_ONCE(0);
		return NULL;
	}
	return top;
}