// -------------------------------------------------------------------------
//	�ļ���		��	unicnv2.cpp
//	������		��	wanghui
//	����ʱ��	��	2003-9-24 16:32:00
//	��������	��	
//
// -------------------------------------------------------------------------

#include "doc2xml.h"
#include "conio.h"

KDynLib g_LibAcc;
KDynLib g_LibReader;

ks_wstring g_strSrcFile;
ks_wstring g_strDstFile;

KComModule _Module;

// -------------------------------------------------------------------------

#undef main
struct KFC_INIT
{
	KFC_INIT() {kfc::Initialize(NULL);}
	~KFC_INIT() {kfc::Terminate();}
};

struct LIB_INIT
{
	LIB_INIT() 
	{
		g_LibReader.Load("docreader");
		g_LibAcc.Load(__X("xmlwriter"));

		HRESULT (__stdcall *pfnInitialize)();
		g_LibReader.GetProc("_dr_Initialize", (void**)&pfnInitialize);
		pfnInitialize();

	}
	~LIB_INIT() 
	{
		HRESULT (__stdcall *pfnTerminate)();
		g_LibReader.GetProc("_dr_Terminate", (void**)&pfnTerminate);
		pfnTerminate();
	}
};

// -------------------------------------------------------------------------

int main(int argc, char* argv[])
{
	KFC_INIT kfcInit;
	LIB_INIT libInit;


	ASSERT(argc > 0);
	if (argc < 2)
	{
		printf("no enough params: unicnv2 src(.doc) [dst(.xml)]\n");
		return 0;
	}

	g_strSrcFile = argv[1];
	if (argc == 2)
	{
		g_strDstFile = g_strSrcFile;
		size_t pos = g_strDstFile.rfind('.');
		if (pos == g_strDstFile.npos
			|| wcsicmp(g_strDstFile.c_str() + pos + 1, __X("doc")) != 0)
			g_strDstFile.append(__X(".xml"));
		else
		{
			g_strDstFile.replace(pos + 1, g_strDstFile.size(), __X("xml"));
		}
	}
	else
	{
		g_strDstFile = argv[2];
		if (argc > 3)
			printf("ignore last %u params\n", argc - 3);
	}


	printf("\nbaseinfo: \n");
	printf("  src: %s\n", ks_string(g_strSrcFile.c_str()).c_str());
	printf("  dst: %s\n", ks_string(g_strDstFile.c_str()).c_str());


	HRESULT hr = E_FAIL;

	printf("\n>>> preparing ... ");

	ks_stdptr<IKContentSource> ptrSrc;
	hr = CreateSource(&ptrSrc);
	if (FAILED(hr))
	{
		printf("\n ! create source fail: %08X \n", hr);
		return 0;
	}
	ks_stdptr<IKContentHandler> ptrAcc;
	hr = CreateAcceptor(&ptrAcc);
	if (FAILED(hr))
	{
		printf("\n ! create acceptor fail: %08X \n", hr);
		return 0;
	}
	printf("OK\n");


	printf(">>> translating ... ");

	hr = DoTranslate(ptrSrc, ptrAcc);

	if (FAILED(hr))
	{
		printf("\n ! translate fail: %08X\n", hr);
		return 0;
	}

	printf("OK\n");

#ifdef _DEBUG
	printf("\ndone, Press any key to continue\n");
	getch();
#endif

	return 0;
}

// -------------------------------------------------------------------------

HRESULT CreateSource(IKContentSource** ppSrc)
{
	HRESULT (__stdcall *pfnCreateSource)(LPCWSTR, BOOL, IKContentSource**);
	g_LibReader.GetProc("_dr_CreateSource2Ex", (void**)&pfnCreateSource);

	return pfnCreateSource(g_strSrcFile, TRUE, ppSrc);
}

HRESULT CreateAcceptor(IKContentHandler** ppAcc)
{
	ks_stdptr<IKContentHandler> ptrAcc;

	HRESULT (__stdcall *pfnCreateXmlWriter)(KsoXmlStdType, IKContentHandler**);
	g_LibAcc.GetProc("_kso_CreateXmlWriter", (void**)&pfnCreateXmlWriter);
	VS(pfnCreateXmlWriter(kso_xmlWordProcess, &ptrAcc));

	ks_stdptr<IKFileMediaInit> ptrFileMediaInit;
	ptrAcc->QueryInterface(IID_IKFileMediaInit, (void**)&ptrFileMediaInit);
	VS(ptrFileMediaInit->Init(g_strDstFile, STGM_CREATE | STGM_WRITE));
	
	*ppAcc = ptrAcc.detach();
	return S_OK;
}

HRESULT DoTranslate(IKContentSource* pSrc, IKContentHandler* pAcc)
{
	pAcc->StartDocument(0);
	HRESULT hr = pSrc->Transfer(pAcc);
	pAcc->EndDocument(FALSE);

	return hr;
}

// -------------------------------------------------------------------------
