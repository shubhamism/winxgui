// -------------------------------------------------------------------------
//	�ļ���		��	unicnv4.h
//	������		��	nature(����)
//	����ʱ��	��	2004-3-21 11:03:42
//	��������	��	
//
// -------------------------------------------------------------------------
#ifndef __UNICNV4_H__
#define __UNICNV4_H__

#include "iox_kfc.h"

#include "kso/io/filterplugin.h"
#include "kso/io/contenthandler.h"
#include "kso/io/schema.h"
#include "kso/io/component.h"

#include "ioacceptor/ioacceptor.h"
#include "ioacceptor/iowrapper2.h"

// -------------------------------------------------------------------------

#define MAX_BUFFER_LEN 1000

#define SRCTYPE_DOC 		0

#define DSTTYPE_DUMMY		0
#define DSTTYPE_WPS_XML		1

// -------------------------------------------------------------------------

HRESULT CreateAcceptor(IKContentHandler** ppAcc);
HRESULT CreateSource(IKContentSource** ppSrc);
HRESULT DoTranslate(IKContentSource* pSrc, IKContentHandler* pAcc);

// -------------------------------------------------------------------------

#endif /* __UNICNV4_H__ */
