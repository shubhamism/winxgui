/* -------------------------------------------------------------------------
//	�ļ���		��	fndends.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:17:29
//	��������	��	
//
//	$Id: fndends.h,v 1.5 2006/04/10 00:55:10 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __FNDENDS_H__
#define __FNDENDS_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWTextStreamWriter;
class RtfDirectWriter;
class RtfWGlobalInfo;

class RtfWNotesWriter
{
private:
	const KDWNotes* m_data;
	KDWNotes::Enumerator m_enumer;
	RtfWTextStreamWriter* m_wrText;

public:
	RtfWNotesWriter(const KDWNotes* data);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) SetStreamWriter(RtfWTextStreamWriter* wrTextStream);
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP_(KDWRange) RefRange();	
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, BOOL fEndnote);
};
typedef RtfWNotesWriter RtfWFndsWriter, RtfWEndsWriter;
void WriteFndEndSepProp(RtfDirectWriter* ar, RtfWGlobalInfo* ginfo);
// -------------------------------------------------------------------------
//	$Log: fndends.h,v $
//	Revision 1.5  2006/04/10 00:55:10  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.4  2006/04/05 07:49:59  xulingjiao
//	�޸�BUG 24916 .
//	
//	Revision 1.3  2006/04/05 04:53:20  xulingjiao
//	��ע
//	
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:05  xulingjiao
//	*** empty log message ***
//	

#endif /* __FNDENDS_H__ */
