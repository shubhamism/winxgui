/* -------------------------------------------------------------------------
//	�ļ���		��	drawing.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:46:26
//	��������	��	
//
//	$Id: drawing.cpp,v 1.6 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "drawingprop.h"
#include "../textstream.h"
#include "drawing.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
RtfWDrawingWriter::RtfWDrawingWriter(const _KDWDrawings* p, SUBDOC_TYPE subdoc, const MsoBlipStore* blipstore)
{		
	m_subdoc = subdoc;
	m_drawing = p->_GetSubdocDrawing(subdoc);		
	m_blipstore = blipstore;
}

STDMETHODIMP_(void) RtfWDrawingWriter::SetTxtboxStreamWriter(RtfWTextStreamWriter* wrTextStream)
{
	ASSERT(wrTextStream);
	m_wrTextbox = wrTextStream;
}

STDMETHODIMP_(void) RtfWDrawingWriter::Write(RtfDirectWriter* ar, INT cp)
{
	const KDWDrawing* d = &m_drawing->drawing;

	// ����ȡ��CPλ�ô�FSPA����ȡ��drawing��λ�õ�drawing��Ϣ��
	FSPA fspa = {0};
	m_drawing->plcfspa.GetFSPA(cp, &fspa);

	// ����id��ȡshape��
	MsoShape t = d->GetRootShape().GetChildShapeByID(fspa.spid);
	ASSERT(t.Good());
	WriteShape(ar, t.Data());
}

STDMETHODIMP RtfWDrawingWriter::WriteBackground(RtfDirectWriter* ar)
{
	const KDWDrawing* d = &m_drawing->drawing;
	MsoShape background = d->GetBackground();
	if(background.Good())
	{
		ar->StartGroup(rtf_background, rtf_nilParam, TRUE);
		WriteShape(ar, background.Data());
		ar->EndGroup();
		return S_OK;
	}
	return E_FAIL;
}	
void RtfWDrawingWriter::WriteShape(RtfDirectWriter* ar, _KDWShape* p)
{
	_MsoGroupShape* g = NULL;		
	if(p->grf.fGroup)
	{
		ar->StartGroup(rtf_shpgrp);
		g = (_MsoGroupShape*)(p);			 
	}
	else
		ar->StartGroup(rtf_shp);

		ar->StartGroup(rtf_shpinst, rtf_nilParam, TRUE);
		const FSPA* fspa = GetShapeFSPA(p);
		// With the exception of \shplid, following ctrl do not apply for 
		// shapes that are within a group.
		if(!p->grf.fChild && fspa)
		{
			ar->AddAttribute(rtf_shpleft, fspa->xaLeft);
			ar->AddAttribute(rtf_shptop, fspa->yaTop);
			ar->AddAttribute(rtf_shpright, fspa->xaRight);
			ar->AddAttribute(rtf_shpbottom, fspa->yaBottom);
			ar->AddAttribute(rtf_shpfhdr, fspa->fHdr);
			ar->AddAttribute(GetFspaBxCtrl(fspa->bx));
			ar->AddAttribute(rtf_shpbxignore);
			ar->AddAttribute(GetFspaByCtrl(fspa->by));
			ar->AddAttribute(rtf_shpbyignore);
			ar->AddAttribute(rtf_shpwr, fspa->wr);
			ar->AddAttribute(rtf_shpwrk, fspa->wrk);
			ar->AddAttribute(rtf_shpfblwtxt, fspa->fBolowText);
			ar->AddAttribute(rtf_shpz, p->nZOrder);
		}
		ar->AddAttribute(rtf_shplid, p->spid);
		// write shape props
		// groupLeft
		if(p->grf.fGroup && g)
		{
			WritePropSPI4(ar, "groupLeft", g->m_spgr.rcgBounds.left);
			WritePropSPI4(ar, "groupTop", g->m_spgr.rcgBounds.top);
			WritePropSPI4(ar, "groupRight", g->m_spgr.rcgBounds.right);
			WritePropSPI4(ar, "groupBottom", g->m_spgr.rcgBounds.bottom);
		}

		// relLeft
		if(p->grf.fChild)
		{
			IORECT rc;
			memcpy(&rc, _MsoPdata(p->anchor), sizeof(IORECT));				
			WritePropSPI4(ar, "relLeft", rc.left);
			WritePropSPI4(ar, "relTop", rc.top);
			WritePropSPI4(ar, "relRight", rc.right);
			WritePropSPI4(ar, "relBottom", rc.bottom);
		}			
		// fFlipH
		WriteShapeTypeNFilp(ar, p, p->grf.fChild);
		// posh
		RtfWDrawingPropWriter wrProp(m_blipstore, p);
		wrProp.WriteShapeProp(ar, p);
		if(p->grf.fGroup && g)
		{
			for (INT i = 0; i < g->m_childs.size(); ++i)
				WriteShape(ar, g->m_childs[i]);
		}

		WriteSPTextBoxLink(ar, p);
		
		if(p->textbox)
		{			
			WriteShapeText(ar, p->textbox, m_subdoc);
		}
	ar->EndGroup();	//end rtf_shpinst group
	WriteShprslt(ar, p);
	ar->EndGroup();	//end rtf_shpgrp �� rtf_shp group		
}
void RtfWDrawingWriter::WriteShprslt(RtfDirectWriter* ar, const _KDWShape* p)
{		
	/*
	RtfWDrawingPropWriter wrProp(m_blipstore, p);
	ar->StartGroup(rtf_shprslt);
		ar->StartGroup(rtf_pict);
		// ��֪���������������ʲô��ʽ��ͼƬ, ԭ����Ϊ��λͼ, ʵ����ʲô����ʲô��ʽ.
		wrProp.WriteConvertBlip(ar, p, __X("image/bmp"), RtfAttribute(rtf_dibitmap));
		ar->EndGroup();
	ar->EndGroup();
	*/
}

void RtfWDrawingWriter::WriteSPTextBoxLink(RtfDirectWriter* ar, _KDWShape* p)
{		
	if (p->nextLinkedShape == NULL)
	{
		if (p->prevLinkedShape)
			WritePropSPI4(ar, "hspNext", p->spid);
	}
	else
	{
		_KDWShape* pnext = p->nextLinkedShape;
		WritePropSPI4(ar, "hspNext", pnext->spid);			
	}
}
void RtfWDrawingWriter::WriteShapeText(RtfDirectWriter* ar, const MsoKernData* data, SUBDOC_TYPE subdoc)
{
	const KDWTextBox* textbox = (const KDWTextBox*)data;
	INT textlen = m_drawing->textboxs.GetTextBoxLen(textbox->idTxbx);
	
	// ȥ�����ڷָ���0x0d
	textlen -= 1;

	ar->StartGroup(rtf_shptxt);	
	m_wrTextbox->Write(ar, textbox->cpStart, textlen, subdoc);
	ar->EndGroup();
}