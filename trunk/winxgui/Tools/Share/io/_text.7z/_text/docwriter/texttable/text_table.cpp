/* -------------------------------------------------------------------------
//	�ļ���		��	text_table.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-23 15:12:51
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include "text_table.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace kso_text;
// -------------------------------------------------------------------------

STDMETHODIMP KTextTableHandler::StartElement(
											 IN ELEMENTID uElementID,
											 IN KROAttributes* pAttrs)
{
	//
	// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
	// ע�⣺
	// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPr, tblPos��rowtbl_EndTable
	// ǰ��Ч�����Ҳ����޸ģ�����
	//
	KROAttributes* tblPos = NULL;
	pAttrs->GetByID(kso_schema::text_position, &tblPos);
	if (tblPos == NULL)
	{
		return m_pDocTarget->rowtbl_StartTable();
	}
	else
	{
		HRESULT hr;
		INT nValue;
		m_tblPos.Reset();
	
		// convert table position

		tblPos->GetByID(kso_schema::text_leftFromText, &m_tblPos.leftFromText);
		tblPos->GetByID(kso_schema::text_rightFromText, &m_tblPos.rightFromText);
		tblPos->GetByID(kso_schema::text_topFromText, &m_tblPos.topFromText);
		tblPos->GetByID(kso_schema::text_bottomFromText, &m_tblPos.bottomFromText);
		tblPos->GetByID(kso_schema::text_overlap, &m_tblPos.tblOverlap);

		hr = tblPos->GetByID(kso_schema::text_vertRel, &nValue);
		if (SUCCEEDED(hr))
			m_tblPos.pcVert = nValue;

		hr = tblPos->GetByID(kso_schema::text_horzRel, &nValue);
		if (SUCCEEDED(hr))
			m_tblPos.pcHorz = nValue;

		hr = tblPos->GetByID(kso_schema::text_xPos, &m_tblPos.tblpX);
		if (FAILED(hr))
		{
			enumHPOS xPosSpec;
			hr = tblPos->GetByID(kso_schema::text_xPosSpec, (INT*)&xPosSpec);
			if (SUCCEEDED(hr))
			{
				switch (xPosSpec)
				{
				case hposLeft:		m_tblPos.tblpXSpec = mso_posXSpecLeft; break;
				case hposCenter:	m_tblPos.tblpXSpec = mso_posXSpecCenter; break;
				case hposRight:		m_tblPos.tblpXSpec = mso_posXSpecRight; break;
				case hposInner:		m_tblPos.tblpXSpec = mso_posXSpecInside; break;				
				case hposOutter:	m_tblPos.tblpXSpec = mso_posXSpecOutside; break;
				default:
					ASSERT_ONCE(0);
					m_tblPos.tblpXSpec = mso_posXSpecLeft;
				}
			}
		}

		hr = tblPos->GetByID(kso_schema::text_yPos, &m_tblPos.tblpY);
		if (FAILED(hr))
		{
			enumVPOS yPosSpec;
			hr = tblPos->GetByID(kso_schema::text_yPosSpec, (INT*)&yPosSpec);
			if (SUCCEEDED(hr))
			{
				switch (yPosSpec)
				{
				case vposTop:		m_tblPos.tblpYSpec = mso_posYSpecTop; break;
				case vposCenter:	m_tblPos.tblpYSpec = mso_posYSpecCenter; break;
				case vposBottom:	m_tblPos.tblpYSpec = mso_posYSpecBottom; break;
				case vposInside:	m_tblPos.tblpYSpec = mso_posYSpecInside; break;				
				case vposOutter:	m_tblPos.tblpYSpec = mso_posYSpecOutside; break;
				default:
					ASSERT_ONCE(0);
					m_tblPos.tblpYSpec = mso_posYSpecTop;
				}
			}
		}
		return m_pDocTarget->rowtbl_StartTable(&m_tblPos);
	}
}

STDMETHODIMP KTextTableHandler::EndElement(
										   IN ELEMENTID uElementID)
{
	return m_pDocTarget->rowtbl_EndTable();
}

STDMETHODIMP KTextTableHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case kso_schema::text_row:
		m_rowElement.Init(m_pDocTarget);
		*ppHandler = &m_rowElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
