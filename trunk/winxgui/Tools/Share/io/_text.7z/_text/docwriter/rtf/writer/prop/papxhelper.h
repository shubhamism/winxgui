/* -------------------------------------------------------------------------
//	�ļ���		��	papxhelper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:25:53
//	��������	��	
//
//	$Id: papxhelper.h,v 1.7 2006/09/20 01:54:04 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PAPXHELPER_H__
#define __PAPXHELPER_H__
#include "mso/propstruct/maskparapr.h"

//typedef MaskParaPr RtfWParaPr;
struct RtfWParaPr : MaskParaPr
{
	typedef MaskParaPr BaseType;
	typedef RtfWParaPr ThisType;	
	STDMETHODIMP Sprms2ParaPr(IN const KDWSprmList* sprms, 
							  IN const RtfWParaPr* baseon,
							  IN const KDWListTable* lists)
	{
		return Sprms2MaskParaPr(sprms, this, baseon, lists);
	}
	STDMETHODIMP Sprms2ParaPr(IN const KDWPropx* prop, 
							  IN const RtfWParaPr* baseon, 
							  IN const KDWListTable* lists)
	{
		return Sprms2MaskParaPr(prop, this, baseon, lists);
	}
};

inline RtfWParaPr* GetDefaultPapx()
{
	static RtfWParaPr s_prop;
	static BOOL s_initflag = FALSE;
	if (!s_initflag)
	{
		s_prop.Reset();	
		s_initflag = TRUE;
	}
	return &s_prop;
}

#endif /* __PAPXHELPER_H__ */
