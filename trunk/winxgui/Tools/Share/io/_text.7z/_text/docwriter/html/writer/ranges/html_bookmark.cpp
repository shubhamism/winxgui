/* -------------------------------------------------------------------------
//	�ļ���		��	html_bookmark.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-4 19:03:39
//	��������	��	
//
//	$Id: html_bookmark.cpp,v 1.7 2006/07/08 00:39:35 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "html_bookmark.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) HtmlWBookmarkWriter::WriteBegin(HtmlDirectWriterA* ar, const KDWBookmarkData* t)
{
	ar->StartElement(elem_a);
	ar->AddAttribute(htm_attr_name, t->kernName);	
}
STDMETHODIMP_(void) HtmlWBookmarkWriter::WriteEnd(HtmlDirectWriterA* ar, const KDWBookmarkData* t)
{
	ar->EndElement(elem_a);
}
