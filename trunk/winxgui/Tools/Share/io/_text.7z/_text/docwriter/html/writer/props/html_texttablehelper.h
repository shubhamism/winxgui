/* -------------------------------------------------------------------------
//	�ļ���		��	html_texttablehelper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-6 10:40:43
//	��������	��	
//
//	$Id: html_texttablehelper.h,v 1.1 2006/01/09 02:25:45 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_TEXTTABLEHELPER_H__
#define __HTML_TEXTTABLEHELPER_H__
#include "rtf/writer/prop/tablehelper.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/

typedef Doc2RtfCellPr Doc2HtmlCellPr;
typedef Doc2RtfRowTablePr Doc2HtmlRowTablePr;

inline STDMETHODIMP Sprms2HtmlTablePr(IN const KDWSprmList* sprms, IN OUT Doc2HtmlRowTablePr* d)
{
	return Sprms2RtfTablePr(sprms, d);
}

inline STDMETHODIMP Sprms2HtmlTablePr(IN const KDWPropx* prop, IN OUT Doc2HtmlRowTablePr* d)
{
	KDWSprmList sprms;
	sprms.AssignTapx(prop);
	return Sprms2HtmlTablePr(&sprms, d);
}
// -------------------------------------------------------------------------
//	$Log: html_texttablehelper.h,v $
//	Revision 1.1  2006/01/09 02:25:45  xulingjiao
//	��ʼ��������
//	

#endif /* __HTML_TEXTTABLEHELPER_H__ */
