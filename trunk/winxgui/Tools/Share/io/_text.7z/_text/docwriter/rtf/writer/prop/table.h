/* -------------------------------------------------------------------------
//	�ļ���		��	table.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:01:35
//	��������	��	
//
//	$Id: table.h,v 1.2 2006/01/20 08:43:01 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TABLE_H__
#define __TABLE_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class Doc2RtfRowTablePr;
class RtfDirectWriter;
class Doc2RtfRowTablePr;
class RtfWTableWriter
{
private:
	const KDWPlcfPapx* m_papxs;
	RtfWGlobalInfo* m_ginfo;
	
public:
	RtfWTableWriter(RtfWGlobalInfo* info, const KDWPlcfPapx* papxs);
	STDMETHODIMP Write(RtfDirectWriter* ar, UINT index);
private:	
	STDMETHODIMP_(void) WriteCellSpacing(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p);
	STDMETHODIMP_(void) WriteDefCellMargin(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p);
	STDMETHODIMP_(void) WriteCells(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p);
	STDMETHODIMP_(void) WriteTTableBorders(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p);
	STDMETHODIMP_(void) WriteTablePosition(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p);
	STDMETHODIMP Write(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p);
};
// -------------------------------------------------------------------------
//	$Log: table.h,v $
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:05  xulingjiao
//	*** empty log message ***
//	

#endif /* __TABLE_H__ */
