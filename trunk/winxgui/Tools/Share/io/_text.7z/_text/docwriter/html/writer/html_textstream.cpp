/* -------------------------------------------------------------------------
//	�ļ���		��	html_textstream.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:34:30
//	��������	��	
//
//	$Id: html_textstream.cpp,v 1.24 2006/09/07 07:07:10 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "html_ranges.h"
#include "ranges/html_field.h"
#include "ranges/html_fields.h"
#include "ranges/html_bookmarks.h"
#include "props/html_chpx.h"
#include "props/html_plcfchpx.h"
#include "props/html_plcfpapx.h"
#include "draws/html_embpic.h"
#include "html_textstream.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) HtmlWTextStreamWriter::AddUtf8Char(HtmlDirectWriterA* ar, WCHAR wch)
{
	if(!m_SpecText)
		ar->AddUtf8Char(wch);
	else
	{
		switch(m_SpecText)
		{
		case FIELD_BEGIN:			
			{
				HtmlWMainFieldsWriter* fields = m_wrRanges->GetFields();
				HtmlWFieldHandler* field = NULL;
				if(fields)
					field = fields->GetField();
				if(field)				
					field->AddCodeChar(wch);
			}
			break;
		case FIELD_SEP:
			ar->AddUtf8Char(wch);			
			break;
		}
	}
}

STDMETHODIMP_(void) HtmlWTextStreamWriter::AddMultibyteChar(HtmlDirectWriterA* ar, WCHAR wch, DWORD ciACP)
{	
	if(!m_SpecText)		
		ar->AddMultibyteChar(wch, ciACP);
	else
	{
		switch(m_SpecText)
		{
		case FIELD_BEGIN:			
			{
				HtmlWMainFieldsWriter* fields = m_wrRanges->GetFields();
				HtmlWFieldHandler* field = NULL;
				if(fields)
					field = fields->GetField();
				if(field)
					field->AddCodeChar(wch);
			}
			break;
		case FIELD_SEP:
			ar->AddMultibyteChar(wch, ciACP);
			break;
		}
	}
}

STDMETHODIMP HtmlWTextStreamWriter::AddSpecChar(HtmlDirectWriterA* ar, WCHAR wch, HtmlWChpxWriter* chpInfo)
{
	BOOL fSpec =  chpInfo->GetChp().fSpec;
	if(!fSpec)
		return E_FAIL;
	switch(wch)
	{
	case FOOTNOTE_SEP:
	case FOOTNOTE_REF:
	case FOOTNOTE_CONT:
	case ANNOTATION_REF:
		break;
	case FIELD_BEGIN:
		m_SpecText = FIELD_BEGIN;
		break;
	case FIELD_SEP:
		m_SpecText = FIELD_SEP;
		break;
	case FIELD_END:
		m_SpecText = FIELD_END;
		m_SpecText = 0;
		break;
	case EMB_SHAPE:{
		HtmlWEmbpicWriter wrEmb(m_wrRanges->GetGlobalInfo());
		wrEmb.Write(chpInfo->GetPicLocation());}
		break;
	case DRAWING_OBJ:
		break;
	default:
		ASSERT_ONCE(0);
		return S_OK;
	}	
	return S_OK;
}

STDMETHODIMP_(void) HtmlWTextStreamWriter::WriteUtf8Text(const KDWTextStream* p, CP cp, INT cch, HtmlWChpxWriter* chpInfo)
{
	if (cch <= 0)
		return;
	HtmlDirectWriterA* ar = m_wrRanges->GetGlobalInfo()->ar;
	UINT32 nTableLayer = m_wrRanges->GetPapInfo().GetPap().nTableLayer;
	INT iLastFont = -1;
	for(INT i=0; i<cch; ++i)
	{
		WCHAR wch = p->GetText(cp);		
		switch(wch)
		{
		case 0x07:
		case 0x0D:		
			ar->put("&nbsp;");
			break;		
		case 0x09:			
			ar->put("&nbsp;");//@todo��������, ����֪����ô����
			break;
		case SYMBOL:
			if(chpInfo->GetChp().mask.symbol)			
				AddUtf8Char(ar, chpInfo->GetChp().symbol.oprand.xchSym);
			else
				AddUtf8Char(ar, wch);
			break;
		default:
			if(SUCCEEDED(AddSpecChar(ar, wch, chpInfo)))
			{
				++cp;
				continue;
			}
			AddUtf8Char(ar, wch);
			break;
		}
		++cp;
	}
	m_CurCp = cp;
}

STDMETHODIMP_(void) HtmlWTextStreamWriter::WriteMultibyteText(const KDWTextStream* p, CP cp, INT cch, HtmlWChpxWriter* chpInfo)
{
	if (cch <= 0)
		return;
	HtmlDirectWriterA* ar = m_wrRanges->GetGlobalInfo()->ar;
	DWORD ciACP = chpInfo->GetCharsetInfo().ciACP;
	INT iLastFont = -1;
	for(INT i=0; i<cch; ++i)
	{
		WCHAR wch = p->GetText(cp);
		TxCharClass chclass = _TxGetCharClass(wch);
		switch(wch)
		{
		case 0x07:
		case 0x0D:
			ar->put("&nbsp;");			
			break;
		case 0x09:			
			//@todo��������, ����֪����ô����
			AddMultibyteChar(ar, ' ', ciACP);
			break;
		case FOOTNOTE_SEP:
		case FOOTNOTE_REF:
		case FOOTNOTE_CONT:
		case ANNOTATION_REF:
			if(chpInfo->GetChp().fSpec);//@todo
			else			
				AddMultibyteChar(ar, wch, ciACP);			
			break;		
		case FIELD_BEGIN:
			if(chpInfo->GetChp().fSpec)
				m_SpecText = FIELD_BEGIN;			
			else
				AddMultibyteChar(ar, wch, ciACP);
			break;
		case FIELD_SEP:
			if(chpInfo->GetChp().fSpec)
				m_SpecText = FIELD_SEP;
			else
				AddMultibyteChar(ar, wch, ciACP);
			break;
		case FIELD_END:
			if(chpInfo->GetChp().fSpec)
				m_SpecText = FIELD_END;				
			else
				AddMultibyteChar(ar, wch, ciACP);
			m_SpecText = 0;
			break;
		case SYMBOL:
			if(chpInfo->GetChp().mask.symbol)
			{
				//@todo
			}
			else
				AddMultibyteChar(ar, wch, ciACP);
			break;
		case EMB_SHAPE:
			if(chpInfo->GetChp().fSpec)
			{					
				HtmlWEmbpicWriter wrEmb(m_wrRanges->GetGlobalInfo());
				wrEmb.Write(chpInfo->GetPicLocation());
			}
			else
				AddMultibyteChar(ar, wch, ciACP);
			break;
		case DRAWING_OBJ:
			if(chpInfo->GetChp().fSpec);//@todo			
			else
				AddMultibyteChar(ar, wch, ciACP);
			break;
		default:			
			switch(chclass)
			{
			case CC_FarEast:
				{	
					INT iFastEastFont = m_wrRanges->GetChpinfo().GetChp().rgftc[mso_ftcFastEast];						
					INT iftc = m_wrRanges->GetChpinfo().GetChp().iftc;
					INT iCurrentFont = m_wrRanges->GetChpinfo().GetChp().rgftc[iftc];
					CHARSETINFO chset = m_wrRanges->GetChpinfo().GetCharsetInfo(iFastEastFont);
					if(iFastEastFont != iCurrentFont && iFastEastFont != iLastFont)						
						iLastFont = iFastEastFont;
					AddMultibyteChar(ar, wch, chset.ciACP);
				}
				break;
			default:
				if(chclass != CC_NoFarEast && chclass != CC_Shared)
					AddMultibyteChar(ar, wch, ciACP);
				else
					ar->AddEntity(wch);
				break;
			}
			break;
		}
		++cp;
	}
	m_CurCp = cp;
}

HtmlWTextStreamWriter::HtmlWTextStreamWriter(
	const KDWTextStream* stream,
	HtmlWRangesWriter* wrRanges) :
	m_wrRanges(wrRanges),
	m_stream(stream), m_tables(*stream), m_SpecText(0), m_CurCp(0)
{
	ASSERT(wrRanges);
}

STDMETHODIMP_(void) HtmlWTextStreamWriter::Write()
{
	if (!m_stream)
		return;
	Write(0, m_stream->Count());
}

STDMETHODIMP_(void) HtmlWTextStreamWriter::Write(CP cp, INT cch)
{
	if (!m_stream)
		return;

	const KDWTextStream* t = m_stream;
	HtmlWRangesWriter*& wrRanges = m_wrRanges;

	KDWPlcfPapx papx = t->GetPlcfPapx();
	HtmlWPapxsWriter wrPapxs(&papx, wrRanges->GetGlobalInfo());
	wrRanges->SetPlcfPapx(&wrPapxs);

	KDWPlcfChpx chpx = t->GetPlcfChpx();
	HtmlWChpxsWriter wrChpxs(&chpx, wrRanges->GetGlobalInfo());
	wrRanges->SetPlcfChpx(&wrChpxs);

	cch = (cch >= 0) ? cch : (t->Count() - cp);
	CP m_CurCp = cp, cpEnd, cpWriteEnd = cp + cch;	

	wrRanges->Reset();

	while (m_CurCp < cpWriteEnd)
	{			
		cpEnd = wrRanges->GetCp();
		cpEnd = MIN(cpEnd, cpWriteEnd);
		if (cpEnd >= m_CurCp)
		{
			cch = cpEnd-m_CurCp;			
			if(!m_wrRanges->GetPapInfo().GetPap().fInTable)
				WriteUtf8Text(t, m_CurCp, cch, &m_wrRanges->GetChpinfo());
			if(cpEnd < cpWriteEnd)
				wrRanges->Write(m_SpecText);
			m_CurCp = cpEnd;
		}
		if (FAILED(wrRanges->Next()))
		{				
			cpEnd = cpWriteEnd;
			cch = cpEnd-m_CurCp;			
			if(!m_wrRanges->GetPapInfo().GetPap().fInTable)
				WriteUtf8Text(t, m_CurCp, cch, &m_wrRanges->GetChpinfo());
			break;
		}
	}
	wrRanges->EnsureWriteEnd();
}