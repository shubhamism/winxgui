/* -------------------------------------------------------------------------
//	�ļ���		��	office_macro_variables.cpp
//	������		��	����
//	����ʱ��	��	2006-6-20 11:33:52
//	��������	��	
//
//	$Id: office_macro_variables.cpp,v 1.1 2006/06/21 07:04:19 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_macro_variables.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KMacroVariableHander::StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs
	)
{
	ASSERT(m_pDocTarget);

	BSTR name = NULL;
	pAttrs->GetByID(kso::text_macro_variable_name, &name);

	BSTR value = NULL;
	pAttrs->GetByID(kso::text_macro_variable_value, &value);

	if (name && value)
	{
		ks_wstring strName(name, SysStringLen(name));
		ks_wstring strValue(value, SysStringLen(value));
		m_pDocTarget->AddVariable(strName, strValue);
	}

	return S_OK;
}


// -------------------------------------------------------------------------
//	$Log: office_macro_variables.cpp,v $
//	Revision 1.1  2006/06/21 07:04:19  wangdong
//	���Ӷ�Variable�Ķ�д֧�֡�
//	
