// -------------------------------------------------------------------------
//	�ļ���		��	mso/io/rtf/writer/chpxhelper.h
//	������		��	nature(liucong)
//	����ʱ��	��	2005-7-20 ���� 11:10:52
//	��������	��	
//
//	$Id: chpxhelper.h,v 1.6 2006/07/08 02:16:46 xulingjiao Exp $
// -------------------------------------------------------------------------
#ifndef __MSO_IO_RTF_WRITER_CHPXHELPER_H__
#define __MSO_IO_RTF_WRITER_CHPXHELPER_H__

#include "mso/propstruct/maskspanpr.h"

//typedef MaskSpanPr RtfWSpanPr;
struct RtfWSpanPr : MaskSpanPr
{
	typedef RtfWSpanPr ThisType;
	typedef MaskSpanPr BaseType;
	STDMETHODIMP Sprms2SpanPr(IN const KDWSprmList& sprms,
							  IN const RtfWSpanPr* baseon)
	{
		return Sprms2MaskSpanPr(sprms, this, baseon);
	}
	STDMETHODIMP Sprms2SpanPr(IN const KDWPropx* prop, 
							  IN const RtfWSpanPr* baseon)
	{
		return Sprms2MaskSpanPr(prop, this, baseon);
	}
};

inline RtfWSpanPr* GetDefaultChpx()
{
	static RtfWSpanPr s_prop;
	static BOOL s_initflag = FALSE;
	if (!s_initflag)
	{
		s_prop.Reset();
		s_initflag = TRUE;
	}
	return &s_prop;
}
#endif /* __MSO_IO_RTF_WRITER_CHPXHELPER_H__ */
