/* -------------------------------------------------------------------------
//	�ļ���		��	html_field_helper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 13:32:52
//	��������	��	
//
//	$Id: html_field_helper.h,v 1.6 2006/06/29 05:43:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_FIELD_HELPER_H__
#define __HTML_FIELD_HELPER_H__

inline STDMETHODIMP ParseHyperlinkFieldCode(const ks_wstring& m_code, ks_wstring& filename)
{	
	ks_wstring::size_type pos = 0, npos = ks_wstring::npos;
	ks_wstring::size_type lquote = npos, rquote = npos;
	ks_wstring stops = __X("\\\"");
	UINT count = 0;
	while(1)
	{
		pos = m_code.find_first_of(stops, pos);
		if(pos == ks_wstring::npos)
			break;
		switch(m_code.at(pos))
		{
		case '\\':
			switch(m_code.at(pos+1))
			{
			case 'l':
				filename.append(1, '#');
				break;
			}
			break;
		case '\"':
			++count;
			switch(count)
			{
			case 1:
				lquote = pos;
				break;
			case 2:
				rquote = pos;
				break;
			default:
				ASSERT_ONCE(0);
				return E_FAIL;				
			}
			break;
		}
		++pos;
	}
	if(lquote != npos && rquote != npos && lquote < rquote)
	{
		++lquote;
		filename.append(m_code.substr(lquote, rquote - lquote).c_str());
	}
	return S_OK;	
}
#endif /* __HTML_FIELD_HELPER_H__ */
