/* -------------------------------------------------------------------------
//	�ļ���		��	html_texttable.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-6 10:35:39
//	��������	��	
//
//	$Id: html_texttable.cpp,v 1.29 2006/09/28 06:28:36 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htm/length_unit.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "../html_textstream.h"
#include "html_papx.h"
#include "html_chpx.h"
#include "mso/io/css/convert2cssprop.h"
#include "html_texttable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define _CHECK_FAIL(ptr, ret) if(!ptr) return (ret);
UINT GetParaIstd(const KDWPropx* srcData)
{
	const BYTE* pPapxBuff = (const BYTE*)_MsoPdata(srcData);
	return *(const USHORT*)(pPapxBuff);
}

void WriteCellPading(CssPropBuffer* clPaddings, const KDWCellMargin& tcMar, const KDWCellMargin& rowMar, BOOL8 tcMarMask, CssProperty which = cssprop_none)
{
	if(tcMarMask)
		clPaddings->AddLength(which, twip_to_pt(tcMar.get_Value(0)), lu_pt, " ");
	else
		clPaddings->AddLength(which, twip_to_pt(rowMar.get_Value(0)), lu_pt, " ");
}

void WriteCellPadings(CssPropBuffer* clPaddings, const KDWCellMargin* tcMars, const KDWCellMargin* rowMars, const UINT8* tcMarsMask)
{		
	WriteCellPading(clPaddings, tcMars[mso_tcMarginTop], rowMars[mso_tcMarginTop], tcMarsMask[mso_tcMarginTop]);
	WriteCellPading(clPaddings, tcMars[mso_tcMarginRight], rowMars[mso_tcMarginRight], tcMarsMask[mso_tcMarginRight]);
	WriteCellPading(clPaddings, tcMars[mso_tcMarginBottom], rowMars[mso_tcMarginBottom], tcMarsMask[mso_tcMarginBottom]);
	WriteCellPading(clPaddings, tcMars[mso_tcMarginLeft], rowMars[mso_tcMarginLeft], tcMarsMask[mso_tcMarginLeft]);
}
STDMETHODIMP_(const KDWRowFormat*) _GetRowFormat(const KDWRowCache* row)
{
	static KDWRowFormat defRft;
	const KDWRowFormat* rFt = row->get_Format();
	if(!rFt)
		rFt = &defRft;
	return rFt;
}

STDMETHODIMP_(const KDWCellFormat*) _GetCellFormat(const KDWCellCache* cell)
{
	static KDWCellFormat defClft;
	const KDWCellFormat* cFt = cell->get_Format();
	if(!cFt)
		cFt = &defClft;
	return cFt;
}

STDMETHODIMP_(const BRCEX*) _GetBrc(KDWTableCache* tbl, INT iRow, INT iCell, INT iBrc)
{	
	const KDWRowCache* row = tbl->get_Row(iRow);
	_CHECK_FAIL(row, NULL);
	const KDWCellCache* cell = row->get_Cell(iCell);
	_CHECK_FAIL(cell, NULL);	
	const KDWRowFormat* rFt = _GetRowFormat(row);
	_CHECK_FAIL(rFt, NULL);	
	const KDWCellFormat* cFt = _GetCellFormat(cell);
	_CHECK_FAIL(cFt, NULL);
	const BRCEX* brc = &cFt->tcBorders[iBrc];
	if(!brc->brcexValue)
		brc = &rFt->tblBorders[iBrc];
	return brc;
}

STDMETHODIMP WriteTD(TableInfo* pArg = NULL)
{	
	HtmlWGlobalInfo* info = pArg->ginfo;	
	KDWTableCache* tbl = info->htmlwrStream->GetTables().TableCache(pArg->iTbl);
	_CHECK_FAIL(tbl, E_FAIL);
	const KDWRowCache* row = tbl->get_Row(pArg->iRow);
	_CHECK_FAIL(row, E_FAIL);
	const KDWCellCache* cell = row->get_Cell(pArg->iCell);	
	_CHECK_FAIL(cell, E_FAIL);
	const KDWRange* clRange = cell->get_Range();
	_CHECK_FAIL(clRange, E_FAIL);	
	const KDWRowFormat* rFt = _GetRowFormat(row);	
	const KDWCellFormat* cFt = _GetCellFormat(cell);
	CssPropBuffer clCssProp;
	if(cFt->vertMerge == mso_tcVertMerged)	
	{
		if(tbl->IsLastRowOfSpan(pArg->iRow, pArg->iCell))
			ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcBottom]), cssprop_border_bottom, "; ", &rFt->tblBorders[mso_tblBrcBottom]);
		return E_FAIL;
	}		
	clCssProp.AddLength(cssprop_width, twip_to_pt(cFt->tcWidth), lu_pt, "; ");
	CssPropBuffer clpaddings;
	WriteCellPadings(&clpaddings, cFt->tcMar, rFt->tblCellMar, cFt->m_FormatMark.tcMar);
	clCssProp.AddString(cssprop_padding, clpaddings.Data(), 0, "; ");
	if(cFt->tcFitText)	
		clCssProp.AddLength(cssprop_text_fit, 100, lu_percentage, "; ");
	//cFt->shd @todo
	//ת�߿�����
	INT rowSpan = 0;
	INT colSpan = tbl->CalcColspan(pArg->iRow, pArg->iCell);
	ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcLeft]), 
				  cssprop_border_left, "; ", &rFt->tblBorders[mso_tblBrcLeft],
				  _GetBrc(tbl, pArg->iRow, pArg->iCell-1, mso_tcBrcRight));
	ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcRight]),
				  cssprop_border_right, "; ", &rFt->tblBorders[mso_tblBrcRight]);
	switch(cFt->vertMerge)
	{	
	case mso_tcVertFirstMerge:		
		rowSpan = tbl->CalcRowspan(pArg->iRow, pArg->iCell);
		ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcTop]), 
					  cssprop_border_top, "; ", &rFt->tblBorders[mso_tblBrcTop],
					 _GetBrc(tbl, pArg->iRow-1, pArg->iCell, mso_tcBrcBottom) );
		ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcBottom]), 
					  cssprop_border_bottom, "; ", &rFt->tblBorders[mso_tblBrcBottom]);
		break;
	default:
		ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcTop]), 
					  cssprop_border_top, "; ", &rFt->tblBorders[mso_tblBrcTop],
					  _GetBrc(tbl, pArg->iRow-1, pArg->iCell, mso_tcBrcBottom) );
		if(tbl->IsLastRowOfSpan(pArg->iRow, pArg->iCell))
			ConvertBorder(&clCssProp, &(cFt->tcBorders[mso_tcBrcBottom]), cssprop_border_bottom, "; ", &rFt->tblBorders[mso_tblBrcBottom]);
		else
			clCssProp.AddString(cssprop_border_bottom, "none", 0, "; ");
		break;
	}
	info->ar->StartElement(elem_td);
	char buf[33] = "";
	INT2Str(buf, inch_to_pixel(twip_to_inch(cFt->tcWidth)));
	info->ar->AddAttribute(htm_attr_width, buf, "");
	info->ar->AddAttribute(htm_attr_valign, TcVAlign2CssVal(cFt->vertAlign), "");
	if(cFt->noWrap)	
		info->ar->AddAttribute(htm_attr_nowrap, "", "");
	if(colSpan > 1)
	{
		INT2Str(buf, colSpan);
		info->ar->AddAttribute(htm_attr_colspan, buf, "");
	}
	if(rowSpan > 1)
	{
		INT2Str(buf, rowSpan);
		info->ar->AddAttribute(htm_attr_rowspan, buf, "");
	}
	WriteStyleAttribute(info->ar, &clCssProp);

	
	KDWPlcfPapx papxs = info->htmlwrStream->GetStream()->GetPlcfPapx(*clRange);
	KDWPlcfChpx chpxs = info->htmlwrStream->GetStream()->GetPlcfChpx(*clRange);
	
	CP cp = clRange->cp;
	INT pIndex = 0, sIndex = 0, i;
	while(cp < clRange->cpNext)
	{
		// ���ݵ�ǰCP��ȡ��ǰ���������		
		pIndex = papxs.GetIndex(cp);
		// д��������
		KDWDiv pDiv = papxs.ItemAbs(pIndex);
		UINT paraIstd = GetParaIstd(papxs.SrcData(pIndex));
		HtmlWPapxWriter wrPapx(info);		
		wrPapx.SetSprms(pDiv.prop, paraIstd);
		CssPropBuffer paraCssProp;
		wrPapx.ToCss(&paraCssProp, "; ");
		cp = pDiv.cpNext;
		if(wrPapx.GetPap().nTableLayer > pArg->nTblLayer)
		{
			if(wrPapx.GetPap().nTableLayer == pArg->nTblLayer+1)
			{
				TableInfo saveInfo = *pArg;
				pArg->nTblLayer = wrPapx.GetPap().nTableLayer;
				for(i = 0; i<pArg->nTbl; ++i)
				{
					const KDWTableCache* tbl = info->htmlwrStream->GetTables().get_Table(i);
					if(tbl->get_Range() && pDiv.cp >= tbl->get_Range()->cp && pDiv.cp < tbl->get_Range()->cpNext)
					{				
						cp = tbl->get_Range()->cpNext;
						pArg->iTbl = i;
						WriteTable(pArg);
						*pArg = saveInfo;
						break;
					}
				}
			}			
			continue;
		}		
		info->ar->StartElement(elem_p);
		wrPapx.Write(&paraCssProp);
		// ���ݵ�ǰ�����CP��Χ, ��ȡ�����ڵľ���	
		CP cpSpan = pDiv.cp;		
		while(cpSpan < pDiv.cpNext)
		{
			// ���ݵ�ǰ��CP, ��ȡ��ǰ�������			
			sIndex = chpxs.GetIndex(cpSpan);
			KDWDiv sDiv = chpxs.ItemAbs(sIndex);			
			// д������			
			info->ar->StartElement(elem_span);
			HtmlWChpxWriter wrChpx(info);
			wrChpx.SetProp(chpxs.SrcData(sIndex));
			CssPropBuffer spanCssProp;
			wrChpx.ToCss(&spanCssProp, "; ");
			wrChpx.Write(&spanCssProp);
			// д���ı�
			UINT cch = sDiv.cpNext - sDiv.cp;
			if(cch == 0)
			{				
				info->ar->EndElement(elem_span);
				break;
			}
			info->htmlwrStream->WriteUtf8Text(info->htmlwrStream->GetStream(), sDiv.cp, cch, &wrChpx);
			cpSpan = sDiv.cpNext;
			info->ar->EndElement(elem_span);
		}		
		info->ar->EndElement(elem_p);
	}	
	info->ar->EndElement(elem_td);	
	return S_OK;
}

STDMETHODIMP WriteTR(TableInfo* pArg = NULL)
{	
	HtmlWGlobalInfo* info = pArg->ginfo;
	const KDWTableCache* tbl = info->htmlwrStream->GetTables().get_Table(pArg->iTbl);
	if(!tbl)
		return E_FAIL;
	const KDWRowCache* row = tbl->get_Row(pArg->iRow);
	if(!row)
		return E_FAIL;
	KDWRowFormat rowfmt;
	const KDWRowFormat* pRowFormat =  row->get_Format();
	if(!pRowFormat)
		pRowFormat = &rowfmt;
	BOOL fHead = FALSE;
	if(pRowFormat->m_FormatMark.tblHeader)
	{
		fHead = pRowFormat->tblHeader;
		if(fHead)
			info->ar->StartElement(elem_thead);			
	}
	info->ar->StartElement(elem_tr);
	CssPropBuffer cssprop;	
	if(pRowFormat->m_FormatMark.trHeight && pRowFormat->trHeight.wVal != 0)
		cssprop.AddLength(cssprop_height, twip_to_pt(abs(pRowFormat->trHeight.wVal)), lu_pt, "; ");
	if(pRowFormat->m_FormatMark.cantSplit)
	{
		if(pRowFormat->cantSplit)
			cssprop.AddString(cssprop_page_break_inside, "TableInfo", 0, "; ");
	}
	WriteStyleAttribute(info->ar, &cssprop);
	const KDWCellCache* cell = NULL;
	pArg->nCell = row->get_CellCount();		
	for(UINT i=0; i<pArg->nCell; ++i)
	{		
		pArg->iCell = i;
		WriteTD(pArg);
	}
	info->ar->EndElement(elem_tr);	
	if(fHead)
		info->ar->EndElement(elem_thead);	
	return S_OK;
}

STDMETHODIMP WriteTable(TableInfo* pArg = NULL)
{	
	HtmlWGlobalInfo* info = pArg->ginfo;	
	const KDWTableCache* tbl = info->htmlwrStream->GetTables().get_Table(pArg->iTbl);
	if(!tbl)
		return E_FAIL;
	const KDWRowCache* pRow = tbl->get_Row(0);
	if(!pRow)
		return E_FAIL;
	KDWRowFormat defRowfmt;
	const KDWRowFormat* row = pRow->get_Format();
	if(!row)
		row = &defRowfmt;
	info->ar->StartElement(elem_table);
	if(row->m_FormatMark.jc)
		info->ar->AddAttribute(htm_attr_align, sprmPJc2Cssval(row->jc), "");

	CssPropBuffer cssprop;	
	// ������Բ�֪����ʲô��˼, ���ƺ������е�
	cssprop.AddString(cssprop_border_collapse, "collapse");

	if(row->m_FormatMark.tblWidth)
	{		
		cssprop.AddLength(cssprop_width, twip_to_pt(row->tblWidth.get_Value(0)), lu_pt, "; ");
	}

	int dxaleft = 108 + row->tblInd.get_Value(0);
	if(dxaleft)
		cssprop.AddLength(cssprop_margin_left, twip_to_pt(dxaleft), lu_pt, "; ");
	
	if(tbl->get_TableFormat()->m_FormatMark.topFromText)
		cssprop.AddLength(cssprop_margin_top, twip_to_pt(tbl->get_TableFormat()->topFromText) - 2.25, lu_pt, "; ");
	if(tbl->get_TableFormat()->m_FormatMark.bottomFromText)
		cssprop.AddLength(cssprop_margin_bottom, twip_to_pt(tbl->get_TableFormat()->bottomFromText) - 2.25, lu_pt, "; ");
	if(tbl->get_TableFormat()->m_FormatMark.leftFromText)
		cssprop.AddLength(cssprop_margin_left, twip_to_pt(tbl->get_TableFormat()->leftFromText) - 2.25, lu_pt, "; ");
	if(tbl->get_TableFormat()->m_FormatMark.rightFromText)
		cssprop.AddLength(cssprop_margin_right, twip_to_pt(tbl->get_TableFormat()->rightFromText) - 2.25, lu_pt, "; ");

	WriteStyleAttribute(info->ar, &cssprop);
	
	pArg->nRow = tbl->get_RowCount();
	for(UINT i=0; i<pArg->nRow; ++i)
	{
		pArg->iRow = i;
		WriteTR(pArg);
	}
	info->ar->EndElement(elem_table);
	return S_OK;
}

HtmlWTablesWriter::HtmlWTablesWriter()
{
	m_itbl = 0;
}

STDMETHODIMP HtmlWTablesWriter::Write(HtmlWGlobalInfo* info)
{	
	KDWTablesCache* tbls = &info->htmlwrStream->GetTables();
	const KDWTableCache* tbl = NULL;
	UINT i;
	for(i=m_itbl; i<tbls->Count(); ++i)
	{		
		tbl = tbls->get_Table(i);
		if(tbl && tbl->get_PeriLayer() == 1)
		{
			m_itbl = i+1;
			break;
		}
	}
	TableInfo arg(info);
	arg.nTbl = tbls->Count();
	arg.iTbl = m_itbl - 1;
	arg.nTblLayer = 1;	
	WriteTable(&arg);	
	return S_OK;
}
