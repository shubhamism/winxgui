/* -------------------------------------------------------------------------
//	�ļ���		��	stocktrans.h
//	������		��	����
//	����ʱ��	��	2004-8-16 16:45:41
//	��������	��	
//	$Id: stocktrans.h,v 1.10 2006/07/24 06:47:06 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __ATTR_STOCKTRANS_H__
#define __ATTR_STOCKTRANS_H__

#include "attrinfo.h"
#include "attrtools.h"

// -------------------------------------------------------------------------
#define DW_TWIP2POINT(val)	((val) / 20)
#define DW_ADJUSTRGB(val)	RGB(GetBValue(val), GetGValue(val), GetRValue(val))
#define DW_PERCENT(val)		(val / 100)

// -------------------------------------------------------------------------
#define AttrTransFixDefault AttrTrans<>::AddFix
#define AttrTransPercent	AttrTrans< Div<100> >::AddFix
#define AttrTransTwip2Pt	AttrTrans< Div<20>  >::AddFix
#define AttrTransTwip2HP	AttrTrans< Div<20/2>  >::AddFix
#define AttrTransNot		AttrTrans<Not>::AddFix

#define AttrTransFixDefaultDual(__sec)		AttrTrans<DWAttrOp::Noop, __sec>::AddFix

namespace DWAttrOp
{

template<int factor, class OpType = INT32>
struct Add
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		return (OpType)Op + (OpType)factor;
	}
};

struct Not
{
	static BOOL eval(BOOL Op)
	{
		return !Op;
	}
};

template<int factor, class OpType = INT32>
struct Div
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		return (OpType)Op / (OpType)factor;
	}
};

template<int factor, class OpType = INT32>
struct Mul
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		return (OpType)Op * (OpType)factor;
	}
};

template<int factor_m, int factor_d, class OpType = INT32>
struct Mul_Div
{
	template<class ValType>
		static ValType eval(ValType Op)
	{
		return ((OpType)Op * (OpType)factor_m) / (OpType)factor_d;
	}
};

struct Color
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		return Op == 0 ? 0xff000000 : DW_ADJUSTRGB(Op);
	}
};

struct Ico
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		return Op == 0 ? 0 : MatchARGB2Ico(DW_ADJUSTRGB(Op));
	}
};

struct EAttrUnhandle
{
};

struct EAttrIgnore
{
};

template<class Exception, int factor, int value = factor>
struct _EQ
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		if (Op != factor)
			throw Exception();
		return value;
	}
};

template<class Exception, int factor, int value = factor>
struct _NE
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		if (Op == factor)
			throw Exception();
		return value;
	}
};

template<int factor, int value = factor>
struct EQ : _EQ<EAttrIgnore, factor, value>
{
};

template<int factor, int value = factor>
struct EQ2 : _EQ<EAttrUnhandle, factor, value>
{
};

template<int factor, int value = factor>
struct NE : _NE<EAttrIgnore, factor, value>
{
};

template<int factor, int value = factor>
struct NE2 : _NE<EAttrUnhandle, factor, value>
{
};

template<UINT* LinMap, UINT MapSize, UINT DefVal = 0>
struct LinEnumMap
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		if (Op < MapSize)
			return LinMap[Op];
		return DefVal;
	}
};
/* linear map */
#define LM(val) LinEnumMap<val, countof(val)>
#define LM2(val, def) LinEnumMap<val, countof(val), def>

struct Enum
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		// Not Impl Yet!
	}
};

struct INT3
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		KS_BREAKPOINT();
		return Op;
	}
};

struct Noop
{
	template<class ValType>
	static ValType eval(ValType Op)
	{
		return Op;
	}
};

}

const INT __nilsprm = 0;

template<class OpType = DWAttrOp::Noop, INT secsprm = __nilsprm>
struct AttrTrans
{
	static STDMETHODIMP AddFix(
		IN UINT16 sprmOp,
		IN KDWDocTarget* pTarget, 
		IN ATTRVALUE_PTR pAttrVal,
		IN KDWPropBuffer* pBuf)
	{
		ASSERT(pBuf);
		try{
			try{
				pBuf->ForceAddPropFix(sprmOp, OpType::eval(pAttrVal->lVal));

				if (secsprm != __nilsprm)
				{
					ASSERT(__nilsprm != sprmOp);
					pBuf->ForceAddPropFix(secsprm, OpType::eval(pAttrVal->lVal));
				}
			}
			catch (EAttrUnhandle const&) {
				return IO_S_ATTR_UNHANDLE;
			}
		}
		catch(EAttrIgnore const&)
		{
			return S_FALSE;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
#define TWOARGS(val1, val2) val1, val2
#define TRIARGS(val1, val2, val3) val1, val2, val3
#define _c_ ,

// -------------------------------------------------------------------------
//

inline
STDMETHODIMP_(void) TransTableBrcEx(
							   BRCEX& brcEx,
							   IKAttributes* pAttr)
{
	ZeroStruct(brcEx);
	
	ATTRVALUE_PTR pAttrValue(NULL);
	if (pAttr->GetIndex(kso::office_border_type, &pAttrValue) != -1)
	{
		if (pAttrValue->lVal == 0)
		{
			brcEx.brcexValue = mso_brcexDelete;
			brcEx.crFore = mso_brcexDeleteColor;
			return;
		}
		else
			brcEx.brcType = pAttrValue->lVal;
	}
	if (pAttr->GetIndex(kso::office_border_width, &pAttrValue) != -1)
		brcEx.dptLineWidth = pAttrValue->lVal * 8 / 20;
	if (pAttr->GetIndex(kso::office_border_shadow, &pAttrValue) != -1)
		brcEx.fShadow = pAttrValue->lVal;
	if (pAttr->GetIndex(kso::office_border_space, &pAttrValue) != -1)
		brcEx.dptSpace = pAttrValue->lVal / 20;
	if (pAttr->GetIndex(kso::office_border_color, &pAttrValue) != -1)
		brcEx.crFore = pAttrValue->lVal;
	brcEx.crFore = DWAttrOp::Color::eval(brcEx.crFore);
}

inline
STDMETHODIMP_(void) TransBrcEx(
							   BRCEX& brcEx,
							   IKAttributes* pAttr)
{
	ZeroStruct(brcEx);
	
	ATTRVALUE_PTR pAttrValue(NULL);
	if (pAttr->GetIndex(kso::office_border_type, &pAttrValue) != -1)
		brcEx.brcType = pAttrValue->lVal;
	if (pAttr->GetIndex(kso::office_border_width, &pAttrValue) != -1)
		brcEx.dptLineWidth = pAttrValue->lVal * 8 / 20;
	if (pAttr->GetIndex(kso::office_border_shadow, &pAttrValue) != -1)
		brcEx.fShadow = pAttrValue->lVal;
	if (pAttr->GetIndex(kso::office_border_space, &pAttrValue) != -1)
		brcEx.dptSpace = pAttrValue->lVal / 20;
	if (pAttr->GetIndex(kso::office_border_color, &pAttrValue) != -1)
		brcEx.crFore = pAttrValue->lVal;
	brcEx.crFore = DWAttrOp::Color::eval(brcEx.crFore);
}

__forceinline
STDMETHODIMP_(void) TransTableBrcEx(
							   KDWBrc& brcex,
							   KROAttributes* pAttr
							   )
{
	TransTableBrcEx( (BRCEX&)brcex.get_Value(), pAttr );
}

__forceinline
STDMETHODIMP_(void) TransBrcEx(
							   KDWBrc& brcex,
							   KROAttributes* pAttr
							   )
{
	TransBrcEx( (BRCEX&)brcex.get_Value(), pAttr );
}

// -------------------------------------------------------------------------
//
inline
STDMETHODIMP TransShdEx(
						OUT SHDEX& shdex,
						IN IKAttributes* pAttr)
{
	ATTRVALUE_PTR pAttrFlag(NULL);
	if (pAttr->GetIndex(kso::draw_fill_on, &pAttrFlag) != -1)
	{
		if (!pAttrFlag->lVal)
			return S_FALSE;
	}
	else
		return S_FALSE;
	
	if (pAttr->GetIndex(kso::draw_fill_type, &pAttrFlag) != -1)
	{
		ASSERT(pAttrFlag->lVal == __MSO_ESCHER msofillPattern);

		if (pAttrFlag->lVal != __MSO_ESCHER msofillPattern)
			return S_FALSE;
	}
	else
		return S_FALSE;
	
	ATTRVALUE_PTR pAttrVal;
	if (pAttr->GetIndex(kso::draw_pattern, &pAttrVal) == -1)
	{
		ASSERT(0);
		return S_FALSE;
	}

	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);
	
	ZeroStruct(shdex);
	
	ATTRVALUE_PTR pAttrFill(NULL);
	if (pAttr->GetIndex(kso::draw_fill_color, &pAttrFill) != -1)
		shdex.crFore = pAttrFill->lVal;
	ATTRVALUE_PTR pAttrBk(NULL);
	if (pAttr->GetIndex(kso::draw_fill_bk_color, &pAttrBk) != -1)
		shdex.crBack = pAttrBk->lVal;
	ATTRVALUE_PTR pAttrType(NULL);
	if (pAttr->GetIndex(kso::draw_pattern_type, &pAttrType) != -1)
		shdex.ipat = pAttrType->lVal;
	
	shdex.crFore = DWAttrOp::Color::eval(shdex.crFore);
	shdex.crBack = DWAttrOp::Color::eval(shdex.crBack);

	return S_OK;
}

__forceinline
STDMETHODIMP TransShdEx(
						KDWShd& shdex,
						KROAttributes* pAttr)
{
	return TransShdEx( (SHDEX&)shdex.get_Value(), pAttr );
}

// -------------------------------------------------------------------------
inline
STDMETHODIMP AttrTransRGB(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	pBuf->ForceAddPropFix(sprmOp, DWAttrOp::Color::eval(pAttrVal->lVal));
	return IO_S_ATTR_CONTINUE;
}

inline
STDMETHODIMP AttrTransIco(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	pBuf->ForceAddPropFix(sprmOp, DWAttrOp::Ico::eval(pAttrVal->lVal));
	return IO_S_ATTR_CONTINUE;
}


// -------------------------------------------------------------------------

#endif /* __STOCKTRANS_H__ */
