/* -------------------------------------------------------------------------
//	�ļ���		��	html_fields.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:11:52
//	��������	��	
//
//	$Id: html_fields.h,v 1.6 2006/06/29 05:43:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_FIELDS_H__
#define __HTML_FIELDS_H__

#include "html_field.h"

class HtmlWGlobalInfo;
class FieldHandlerFactory
{
public:
	HtmlWFieldHandler* GetFieldHandler(HtmlWGlobalInfo* info, UINT flt)
	{		
		switch(flt)
		{
		case mso_fltHyperlink:
			return new HyperlinkFieldHandler(info);
		}
		return new HtmlWFieldHandler(info);
	}
};
class HtmlWMainFieldsWriter
{
private:
	typedef std::stack<HtmlWFieldHandler*> FieldHandlerType;
	HtmlWGlobalInfo* m_ginfo;
	FieldHandlerType m_fields;
	FieldHandlerFactory m_factory;
	KDWFields::Enumerator m_enumer;
	KDWField m_field;
public:	
	~HtmlWMainFieldsWriter();	
	HtmlWMainFieldsWriter(HtmlWGlobalInfo* info);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp() const;
	STDMETHODIMP_(UINT) GetNextCp() const;	
	
	STDMETHODIMP Write();
	STDMETHODIMP_(HtmlWFieldHandler*) GetField() const;
	STDMETHODIMP Clear();
};
#endif /* __HTML_FIELDS_H__ */
