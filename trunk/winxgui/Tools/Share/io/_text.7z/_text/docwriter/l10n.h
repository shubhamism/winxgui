/* -------------------------------------------------------------------------
//	�ļ���		��	l10n.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-3-30 16:32:10
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __L10N_H__
#define __L10N_H__

#ifndef __KSO_IO_BUILTINFMT_H__
#include <kso/io/builtinfmt.h>
#endif

// -------------------------------------------------------------------------
#define _IoFormat_MSWORD8			(filterKSOXMLText | 0x01)
#define _IoFormat_MSWORD8DOT		(filterKSOXMLText | 0x02)
#define _IoFormat_WPSV6				(filterKSOXMLText | 0x03)
#define _IoFormat_WPSV6DOT			(filterKSOXMLText | 0x04)
#define _IoFormat_RTF				(filterKSOXMLText | 0x05)
#define _IoFormat_HTML				(filterKSOXMLText | 0x06)
#define _IoFormat_WPIO				(filterKSOXMLText | 0x10000UL)

// -------------------------------------------------------------------------

#endif /* __L10N_H__ */
