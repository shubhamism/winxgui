/* -------------------------------------------------------------------------
//	�ļ���		��	office_oledatas.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-26 18:24:16
//	��������	��	
//
//	$Id: office_oledatas.cpp,v 1.1 2004/11/26 10:39:38 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_oledatas.h"
#include "doctarget.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeOleDataHandler::StartElement(
						  IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	m_uStgId = (UINT)-2;
	return pAttrs->GetByID(office_oledata_id, &m_uStgId);
}

STDMETHODIMP KOfficeOleDataHandler::AddContent(IN CONTENTVALUE_PTR pContent)
{
	ASSERT(
		pContent &&
		pContent->vt == CONTENTVALUE::vtUnknown);

	if (pContent->vt == CONTENTVALUE::vtUnknown)
	{
		ks_stdptr<IStorageSave> spStgSave;
		HRESULT hr = pContent->punkVal->QI(IStorageSave, &spStgSave);
		ASSERT_OK(hr);

		if (SUCCEEDED(hr))
		{
			m_pDocTarget->UpdateOleStorage(m_uStgId, spStgSave);
			return S_OK;
		}
	}
	return E_INVALIDARG;
}

// -------------------------------------------------------------------------
//	$Log: office_oledatas.cpp,v $
//	Revision 1.1  2004/11/26 10:39:38  xushiwei
//	*** empty log message ***
//	
