/* -------------------------------------------------------------------------
//	�ļ���		��	html_document.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:28:20
//	��������	��	
//
//	$Id: html_document.cpp,v 1.17 2006/07/20 07:34:36 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "html_ranges.h"
#include "html_textstream.h"
#include "html_stylesheet.h"
#include "html_fonttbl.h"
#include "html_dop.h"
#include "props/html_plcfsepx.h"
#include "ranges/html_fields.h"
#include "ranges/html_bookmarks.h"
#include "html_document.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
STDMETHODIMP_(void) HtmlWDocumentWriter::Write(HtmlDirectWriterA* ar, KDWDocument* p)
{
	ar->SetStartHTML();
	ar->StartElement(elem_html);
	ar->StartElement(elem_head);
		ar->StartElement(elem_meta);
		ar->AddAttribute(htm_attr_http_equiv, "Content-Type", "");
		ar->AddAttribute(htm_attr_content, "text/html; charset=utf-8");
	// ��ʼ��ȫ����Ϣ
	HtmlWGlobalInfo gblInfo;	
	gblInfo.doc = p;
	gblInfo.ar = ar;

	HtmlWStyleSheet stsh(&gblInfo.doc->GetStyleSheet(), &gblInfo.doc->GetListTable());
	gblInfo.htmlstsh = &stsh;	
	// дSTYLEԪ��
	ar->StartElement(elem_style);	

	// д�����
	HtmlWFontTableWriter fTbl(&gblInfo);
	fTbl.Write();
	
	// д��ʽ��
	HtmlWStyleSheetWriter wrStyles;	
	wrStyles.Write(&gblInfo);
	KDWSections sepxs = gblInfo.doc->GetSections();
	HtmlWSepxsWriter wrSepxs(&gblInfo, &sepxs);
	wrSepxs.WriteCss();
	
	ar->EndElement(elem_style);		
	ar->EndElement(elem_head);
	ar->StartElement(elem_body);	
	// �����ĵ�����
	HtmlWDopWriter wrDop;
	wrDop.Convert2Cssprop(&gblInfo.doc->GetDop());
	ar->AddAttribute(htm_attr_style, wrDop.GetCssprop().Data());
	// ��ʼ��дHTMLʱ�õ�������
	KDWBookmarkStarts bkmkStarts;	
	if(gblInfo.doc->GetBookmarks(DW_SUBDOC_MAIN))
		gblInfo.doc->GetBookmarks(DW_SUBDOC_MAIN)->GetBookmarkStarts(&bkmkStarts);
	KDWBookmarkEnds bkmkEnds;
	if(gblInfo.doc->GetBookmarks(DW_SUBDOC_MAIN))
		gblInfo.doc->GetBookmarks(DW_SUBDOC_MAIN)->GetBookmarkEnds(&bkmkEnds);
	HtmlWBookmarkStartsWriter wrBookmkStarts(&bkmkStarts);
	HtmlWBookmarkEndsWriter wrBookmkEnds(&bkmkEnds);
	HtmlWMainFieldsWriter wrFields(&gblInfo);	
	HtmlWRangesWriter mainRange(&gblInfo);
	mainRange.SetMainFields(&wrFields);
	mainRange.SetMainBookmkStarts(&wrBookmkStarts);
	mainRange.SetMainBookmkEnds(&wrBookmkEnds);	
	mainRange.SetPlcfSepx(&wrSepxs);
	HtmlWTextStreamWriter mainStream(p->GetStream(DW_SUBDOC_MAIN), &mainRange);
	gblInfo.htmlwrStream = &mainStream;
	ar->SetStartFragment();
	mainStream.Write();
	ar->SetEndFragment();
	ar->EndElement(elem_body);
	ar->EndElement(elem_html);
	ar->SetEndHTML();
	ar->WriteHead();
}