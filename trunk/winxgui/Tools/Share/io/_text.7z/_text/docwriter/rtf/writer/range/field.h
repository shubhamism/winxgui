/* -------------------------------------------------------------------------
//	�ļ���		��	field.h
//	������		��	���὿
//	����ʱ��	��	2006-5-22 15:35:17
//	��������	��	
//
//	$Id: field.h,v 1.4 2006/08/07 01:51:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __FIELD_H__
#define __FIELD_H__
class RtfDirectWriter;
class FieldWriter
{
public:
	STDPROC	WriteBegin(RtfDirectWriter* ar) PURE;
	STDPROC	WriteSep(RtfDirectWriter* ar) PURE;
	STDPROC	WriteEnd(RtfDirectWriter* ar) PURE;
	STDPROC	EnsureWriteEnd(RtfDirectWriter* ar) PURE;	
};

class RtfWBaseFieldWriter : public FieldWriter
{
public:
	STDMETHODIMP WriteBegin(RtfDirectWriter* ar);
	STDMETHODIMP WriteSep(RtfDirectWriter* ar);
	STDMETHODIMP WriteEnd(RtfDirectWriter* ar);
	STDMETHODIMP EnsureWriteEnd(RtfDirectWriter* ar);
};

class RtfWFieldWriter : public RtfWBaseFieldWriter
{
private:	
	BOOL m_fOpen;
	KDWField* m_field;
public:
	RtfWFieldWriter(KDWField* field);
	STDMETHODIMP EnsureWriteEnd(RtfDirectWriter* ar);
	STDMETHODIMP WriteBegin(RtfDirectWriter* ar);
	STDMETHODIMP WriteSep(RtfDirectWriter* ar);
	STDMETHODIMP WriteEnd(RtfDirectWriter* ar);
};

#endif /* __FIELD_H__ */
