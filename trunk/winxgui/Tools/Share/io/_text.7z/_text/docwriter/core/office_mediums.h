/* -------------------------------------------------------------------------
//	�ļ���		��	office_mediums.h
//	������		��	����
//	����ʱ��	��	2004-8-30 14:41:17
//	��������	��	
//	$Id: office_mediums.h,v 1.3 2004/11/26 10:39:38 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_MEDIUMS_H__
#define __OFFICE_MEDIUMS_H__

#include "office_images.h"
#include "office_oledatas.h"

// -------------------------------------------------------------------------
class KOfficeMediumsHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KOfficeImagesHandler m_elementImages;
	KOfficeOleDatasHandler m_elementOleDatas;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		return S_OK;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElement, OUT IKElementHandler** ppv);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_MEDIUMS_H__ */
