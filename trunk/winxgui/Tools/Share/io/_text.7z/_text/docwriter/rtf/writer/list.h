/* -------------------------------------------------------------------------
//	�ļ���		��	list.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:03:40
//	��������	��	
//
//	$Id: list.h,v 1.2 2006/01/20 08:42:59 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __LIST_H__
#define __LIST_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWListWriter
{
private:
	enum {	LISTID_BEGIN = 258173,
			LISTTEMID_BEGIN = 3794214 };

public:
	STDMETHODIMP_(void) WriteLst(RtfDirectWriter* ar, const _DW_ListData* p, RtfWGlobalInfo* info);
	STDMETHODIMP_(void) WriteLfo(RtfDirectWriter* ar, const _DW_LFOData* p, RtfWGlobalInfo* info, INT index);
protected:
	STDMETHODIMP_(void) WriteLvl(RtfDirectWriter* ar, const _DW_ListLevel* p, RtfWGlobalInfo* info);
};
// -------------------------------------------------------------------------
//	$Log: list.h,v $
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __LIST_H__ */
