/* -------------------------------------------------------------------------
//	�ļ���		��	text_symbol.h
//	������		��	����
//	����ʱ��	��	2004-8-24 11:39:51
//	��������	��	
//	$Id: text_symbol.h,v 1.3 2004/10/06 07:12:57 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_SYMBOL_H__
#define __TEXT_SYMBOL_H__

// -------------------------------------------------------------------------
class KTextSymbolHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KDWPropBuffer* m_pPropBuf;
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget, IN KDWPropBuffer* pPropBuf)
	{
		m_pDocTarget = pDocTarget;
		m_pPropBuf = pPropBuf;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_SYMBOL_H__ */
