/* -------------------------------------------------------------------------
//	�ļ���		��	html_papx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:04:48
//	��������	��	
//
//	$Id: html_papx.cpp,v 1.15 2006/10/09 04:11:04 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "mso/io/css/parapr2cssprop.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "../html_globalinfo.h"
#include "html_papx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HtmlWPapxWriter::HtmlWPapxWriter(HtmlWGlobalInfo* info, const KDWPropx* prop) : m_ginfo(info), m_lvl(info)
{ 
	if(prop) SetProp(prop);
}

STDMETHODIMP_(void) HtmlWPapxWriter::SetProp(const KDWPropx* prop)
{		
	SetProp((const BYTE*)_MsoPdata(prop), prop->cb);
}

STDMETHODIMP_(void) HtmlWPapxWriter::SetProp(const BYTE* buff, INT cb, BOOL hasIstd)
{
	if (hasIstd)
	{
		m_istd = GetPapxIstd(buff);
		buff += sizeof(USHORT);
		if (m_istd == stiNil)
			m_istd = stiNormal;
	}
	m_sprms = KDWSprmList(buff, cb);
}

STDMETHODIMP_(void) HtmlWPapxWriter::SetSprms(const KDWSprmList& sprms, UINT istd)
{
	m_istd = (istd == stiNil ? stiNormal : istd);
	m_sprms = sprms;
}

STDMETHODIMP_(void) HtmlWPapxWriter::Write(CssPropBuffer* cssprop)
{	
	WriteClassAttribute(m_ginfo->ar, m_istd);
	WriteStyleAttribute(m_ginfo->ar, cssprop);

	if(prop.mask.ilfo && prop.mask.ilvl)
		m_lvl.Write(prop.ilfo, prop.ilvl);
	else if(baseon->mask.ilfo && baseon->mask.ilvl)
		m_lvl.Write(baseon->ilfo, baseon->ilvl);
}

STDMETHODIMP_(void) HtmlWPapxWriter::ToCss(CssPropBuffer* cssprop, LPCSTR delim)
{
	baseon = m_ginfo->htmlstsh->GetMergedPapx(GetIstd());
	prop.Reset();
	if (baseon == NULL)
		baseon = GetDefaultPapx();	
	prop.Sprms2ParaPr(&m_sprms, baseon, &m_ginfo->doc->GetListTable());
	ParaPr2Cssprop(&prop, cssprop, delim);
}

STDMETHODIMP_(void) HtmlWPapxWriter::ToCss(const HtmlWParaPr* p, CssPropBuffer* cssprop, LPCSTR delim)
{		
	ParaPr2Cssprop(p, cssprop, delim);
}

STDMETHODIMP_(UINT) HtmlWPapxWriter::GetIstd()
{
	return m_istd;
}

STDMETHODIMP_(HtmlWParaPr&) HtmlWPapxWriter::GetPap()
{
	return prop;
}