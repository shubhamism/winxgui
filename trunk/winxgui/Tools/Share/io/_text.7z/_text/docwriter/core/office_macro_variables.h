/* -------------------------------------------------------------------------
//	�ļ���		��	office_macro_variables.h
//	������		��	����
//	����ʱ��	��	2006-6-20 11:33:54
//	��������	��	
//
//	$Id: office_macro_variables.h,v 1.1 2006/06/21 07:04:19 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_MACRO_VARIABLES_H__
#define __OFFICE_MACRO_VARIABLES_H__

// -------------------------------------------------------------------------
class KMacroVariableHander : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget
		)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs
		);
};


typedef KDWCollectionHandler<KMacroVariableHander, kso::text_macro_variable> KMacroVariablesHander;
typedef KDWCollectionHandler<KMacroVariablesHander, kso::text_macro_variables> KMacroHandler;

// -------------------------------------------------------------------------
//	$Log: office_macro_variables.h,v $
//	Revision 1.1  2006/06/21 07:04:19  wangdong
//	���Ӷ�Variable�Ķ�д֧�֡�
//	

#endif /* __OFFICE_MACRO_VARIABLES_H__ */
