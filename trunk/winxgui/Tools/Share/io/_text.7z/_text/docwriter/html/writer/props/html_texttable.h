/* -------------------------------------------------------------------------
//	�ļ���		��	html_texttable.h
//	������		��	���὿
//	����ʱ��	��	2006-1-6 10:34:55
//	��������	��	
//
//	$Id: html_texttable.h,v 1.9 2006/06/29 05:43:57 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_TEXTTABLE_H__
#define __HTML_TEXTTABLE_H__

class HtmlWGlobalInfo;
struct TableInfo
{
	TableInfo(HtmlWGlobalInfo* info)
	{
		memset(this, -1, sizeof(*this));
		ginfo = info;
		nTblLayer = 1;
	}
	STDMETHODIMP_(BOOL) IsLastRow()
	{		
		return iRow == nRow-1;
	}
	STDMETHODIMP_(BOOL) IsLastCell()
	{		
		return iCell == nCell-1;
	}
	STDMETHODIMP_(BOOL) IsFistRow()
	{		
		return iRow == 0;
	}
	STDMETHODIMP_(BOOL) IsFirstCell()
	{
		return iCell == 0;
	}	
	INT iTbl, nTblLayer, nTbl;
	INT iRow, nRow;
	INT iCell, nCell, rowspan;
	HtmlWGlobalInfo* ginfo;
};

STDMETHODIMP WriteTD(TableInfo* arg);
STDMETHODIMP WriteTR(TableInfo* arg);
STDMETHODIMP WriteTable(TableInfo* arg);
class HtmlWTablesWriter
{
public:
	HtmlWTablesWriter();
	STDMETHODIMP Write(HtmlWGlobalInfo* info);
private:	
	UINT m_itbl;
};
#endif /* __HTML_TEXTTABLE_H__ */
