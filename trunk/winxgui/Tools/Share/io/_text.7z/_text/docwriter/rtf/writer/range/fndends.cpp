/* -------------------------------------------------------------------------
//	�ļ���		��	fndends.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:19:07
//	��������	��	
//
//	$Id: fndends.cpp,v 1.9 2006/07/31 06:29:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "../textstream.h"
#include "fndends.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWNotesWriter::RtfWNotesWriter(const KDWNotes* data) : m_data(data), m_wrText(NULL)
{
	Reset();
}

STDMETHODIMP_(BOOL) RtfWNotesWriter::Good() const
{
	return m_data != NULL && m_data->Count();
}
STDMETHODIMP_(void) RtfWNotesWriter::SetStreamWriter(RtfWTextStreamWriter* wrTextStream)
{
	ASSERT(wrTextStream);
	m_wrText = wrTextStream;
}
STDMETHODIMP_(void) RtfWNotesWriter::Reset()
{
	m_enumer = KDWNotes::Enumerator(m_data);
	Next();
}
STDMETHODIMP RtfWNotesWriter::Next()
{
	return m_enumer.Next();
}
STDMETHODIMP_(UINT) RtfWNotesWriter::GetCurrentCp()
{
	return m_enumer.Cp();
}
STDMETHODIMP_(UINT) RtfWNotesWriter::GetNextCp()
{
	return m_enumer.CpNext();
}
STDMETHODIMP_(KDWRange) RtfWNotesWriter::RefRange()
{
	return m_enumer.RefRange();
}
STDMETHODIMP_(void) RtfWNotesWriter::Write(RtfDirectWriter* ar, BOOL fEndnote)
{		
	SUBDOC_TYPE subdoc = DW_SUBDOC_FOOTNOTE;
	if(fEndnote)
		subdoc = DW_SUBDOC_ENDNOTE;

	ar->StartGroup(rtf_footnote);
	if(fEndnote)
		ar->AddAttribute(rtf_ftnalt);

	KDWRange rg = m_enumer.TxtRange();
	INT cch = rg.cpNext - rg.cp;	
	if(cch > 0)
		m_wrText->Write(ar, rg.cp, cch - 1, DW_SUBDOC_FOOTNOTE);	
	ar->EndGroup();
}

void WriteFndEndSepProp(RtfDirectWriter* ar, RtfWGlobalInfo* ginfo)
{
	// Ӧ�ø�����û�н�עβע��ȷ����ֵ(0-3)����͵����ֱ��д��2
	ar->AddAttribute(rtf_fet, 2);

	ULONG insrsid = ginfo->idgen.GenInsrsid();

	ar->StartGroup(rtf_ftnsep, rtf_nilParam, TRUE);
	ar->AddAttribute(rtf_pard);
	ar->AddAttribute(rtf_plain);
	//WriteDefaultPapx(ar);
		ar->StartGroup(rtf_insrsid, rtf_nilParam);
		ar->AddAttribute(rtf_chftnsep);
		ar->AddAttribute(rtf_par);
		ar->EndGroup();
	ar->EndGroup();

	ar->StartGroup(rtf_ftnsepc, rtf_nilParam, TRUE);
	ar->AddAttribute(rtf_pard);
	ar->AddAttribute(rtf_plain);
	//WriteDefaultPapx(ar);
		ar->StartGroup(rtf_insrsid, rtf_nilParam);
		ar->AddAttribute(rtf_chftnsepc);
		ar->AddAttribute(rtf_par);
		ar->EndGroup();
	ar->EndGroup();

	ar->StartGroup(rtf_aftnsep, rtf_nilParam, TRUE);
	ar->AddAttribute(rtf_pard);
	ar->AddAttribute(rtf_plain);
	//WriteDefaultPapx(ar);
		ar->StartGroup(rtf_insrsid, rtf_nilParam);
		ar->AddAttribute(rtf_chftnsep);
		ar->AddAttribute(rtf_par);
		ar->EndGroup();
	ar->EndGroup();

	ar->StartGroup(rtf_aftnsepc, rtf_nilParam, TRUE);
	ar->AddAttribute(rtf_pard);
	ar->AddAttribute(rtf_plain);
	//WriteDefaultPapx(ar);
		ar->StartGroup(rtf_insrsid, rtf_nilParam);
		ar->AddAttribute(rtf_chftnsepc);
		ar->AddAttribute(rtf_par);
		ar->EndGroup();
	ar->EndGroup();
}