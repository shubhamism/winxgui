/* -------------------------------------------------------------------------
//	�ļ���		��	text_field_code.h
//	������		��	����
//	����ʱ��	��	2004-8-23 15:42:25
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_FIELD_CODE_H__
#define __TEXT_FIELD_CODE_H__

#ifndef __TEXT_P_H__
#include "core/text_p.h"
#endif

// -------------------------------------------------------------------------

class KTextFieldCodeHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;
	BOOL m_fFirstParagraphOfCode;
	KROAttributes* m_pAttrChpx;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
	
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};	

// -------------------------------------------------------------------------

#endif /* __TEXT_FIELD_CODE_H__ */
