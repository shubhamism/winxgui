/* -------------------------------------------------------------------------
//	�ļ���		��	text_hyperlink.h
//	������		��	����
//	����ʱ��	��	2004-8-23 20:29:05
//	��������	��	
//	$Id: text_hyperlink.h,v 1.3 2004/10/06 07:12:58 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_HYPERLINK_H__
#define __TEXT_HYPERLINK_H__

// -------------------------------------------------------------------------
class KOfficeHyperlinkHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);	
};	

typedef KDWCollectionHandler<KOfficeHyperlinkHandler, office_hyperlink> KOfficeHyperlinksHandler;

// -------------------------------------------------------------------------

#endif /* __TEXT_HYPERLINK_H__ */
