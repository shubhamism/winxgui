/* -------------------------------------------------------------------------
//	�ļ���		��	text_font.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-19 20:01:40
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_FONT_H__
#define __TEXT_FONT_H__

// -------------------------------------------------------------------------
class KTextFontHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------
class KTextDefaultFontHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------
class KTextFontsHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		ASSERT(uElementID == office_fonts);
		return S_OK;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

private:
	KTextFontHandler		m_FontElement;
	KTextDefaultFontHandler m_DefaultFontElement;
};

// -------------------------------------------------------------------------

#endif /* __TEXT_FONT_H__ */
