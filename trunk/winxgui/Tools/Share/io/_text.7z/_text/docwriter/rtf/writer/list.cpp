/* -------------------------------------------------------------------------
//	�ļ���		��	list.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:04:48
//	��������	��	
//
//	$Id: list.cpp,v 1.7 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "globalinfo.h"
#include "prop/chpx.h"
#include "prop/papx.h"
#include "list.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) RtfWListWriter::WriteLst(RtfDirectWriter* ar, const _DW_ListData* p, RtfWGlobalInfo* info)
{
	ar->StartGroup(rtf_list);
		
		ar->AddAttribute(rtf_listtemplateid, p->idList + LISTTEMID_BEGIN);
		
		ASSERT(p->nLevels == 1 || p->nLevels == 9);
		if (p->nLevels == 1)
			ar->AddAttribute(rtf_listsimple);
		else
			ar->AddAttribute(rtf_listhybrid);

		for (INT i = 0; i < p->nLevels; ++i)
			WriteLvl(ar, &p->level[i], info);
		
		ar->StartGroup(rtf_listname);
			if (p->listName->Size() > 0)
				ar->AddContentWcs(p->listName->Data(), p->listName->Size());
		ar->AddContentWcs(__X(";"), 1);
		ar->EndGroup();

		ar->AddAttribute(rtf_listid, p->idList + LISTID_BEGIN);

		//listrestarthdn;
	ar->EndGroup();
}
STDMETHODIMP_(void) RtfWListWriter::WriteLfo(RtfDirectWriter* ar, const _DW_LFOData* p, RtfWGlobalInfo* info, INT index)
{
	ar->StartGroup(rtf_listoverride);
		ar->AddAttribute(rtf_listid, p->dataListOrg->idList + LISTID_BEGIN);
		if (p->dataListOverride == NULL || p->dataListOverride->nLevels == 0)
		{
			ar->AddAttribute(rtf_listoverridecount, 0);
		}
		else
		{
			ar->AddAttribute(rtf_listoverridecount, p->dataListOverride->nLevels);
			for (INT i = 0; i < p->dataListOverride->nLevels; ++i)
			{
				ar->StartGroup(rtf_lfolevel);
				
				if (p->dataListOrg->nLevels <= i ||
					p->dataListOrg->level[i].lvlf.iStartAt != p->dataListOverride->level[i].lvlf.iStartAt)
				{
					ar->AddAttribute(rtf_listoverridestartat, p->dataListOverride->level[i].lvlf.iStartAt);
				}

				ar->AddAttribute(rtf_listoverrideformat);
				WriteLvl(ar, &p->dataListOverride->level[i], info);

				ar->EndGroup();
			}
		}
		ar->AddAttribute(rtf_ls, index+1);
	ar->EndGroup();
}

STDMETHODIMP_(void) RtfWListWriter::WriteLvl(RtfDirectWriter* ar, const _DW_ListLevel* p, RtfWGlobalInfo* info)
{
	ar->StartGroup(rtf_listlevel);
	
	if (p != 0)
	{
		ar->AddAttribute(rtf_levelnfc, p->lvlf.nfc);
		ar->AddAttribute(rtf_levelnfcn, p->lvlf.nfc);
		ar->AddAttribute(rtf_leveljc, p->lvlf.jc);
		ar->AddAttribute(rtf_leveljcn, p->lvlf.jc);			
		ar->AddAttribute(rtf_levelstartat, p->lvlf.iStartAt);
		ar->AddAttribute(rtf_levelfollow, p->lvlf.ixchFollow);
		ar->AddAttribute(rtf_levelspace, p->lvlf.dxaSpace);
		ar->AddAttribute(rtf_levelindent, p->lvlf.dxaIndent);
		ar->AddAttribute(rtf_levellegal, p->lvlf.fLegal);
		ar->AddAttribute(rtf_levelnorestart, p->lvlf.fNoRestart);

		INT cch = 0;
		RtfWPapxWriter wrPapx(info);
		RtfWChpxWriter wr(info);
		
		if (p->pPapx && p->lvlf.cbGrpprlPapx)		
			wrPapx.SetProp((const BYTE*)p->pPapx, p->lvlf.cbGrpprlPapx, FALSE);		

		if (p->pXstByteswap && (cch = p->pXstByteswap[0]))
		{
			++cch;
			ar->StartGroup(rtf_leveltext);
			// ������Ŀ����
			if(p->lvlf.nfc == 23)
			{
				ar->AddContentWcs(p->pXstByteswap, 1, wr.GetCharsetInfo().ciACP);
				ar->AddUnicodeChar(p->pXstByteswap[1]);
				ar->AddContentWcs(__X(";"), 1);
			}
			// ������Ŀ���
			else
			{
				ar->AddContentWcs(p->pXstByteswap, cch, wr.GetCharsetInfo().ciACP);
				ar->AddContentWcs(__X(";"), 1);
			}			
			ar->EndGroup();
		}

		ar->StartGroup(rtf_levelnumbers);
		{			
			for (INT i = 0; i < 9 && p->lvlf.rgbxchNums[i] != 0; ++i)
				ar->AddContent((LPCSTR)(p->lvlf.rgbxchNums+i), 1);
			ar->AddContentWcs(__X(";"), 1);			
		}
		ar->EndGroup();
		
		if(p->cbChpxPicBullet)
			ar->AddAttribute(rtf_levelpicture, p->nPicIndex);
		
		if (p->pChpx && p->lvlf.cbGrpprlChpx)
		{
			KDWSprmList sprms((const BYTE*)p->pChpx, p->lvlf.cbGrpprlChpx);
			RtfWChpxWriter wrChpx(sprms, info);			
			wrChpx.Write(ar);
		}
		
		if (p->pPapx && p->lvlf.cbGrpprlPapx)
		{					
			wrPapx.WriteLevelPapx(ar);
		}
	}

	ar->EndGroup();
}