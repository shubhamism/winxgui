/* -------------------------------------------------------------------------
//	�ļ���		��	html_chpx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:47:50
//	��������	��	
//
//	$Id: html_chpx.h,v 1.15 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_CHPX_H__
#define __HTML_CHPX_H__
#include "html_chpxhelper.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class HtmlWGlobalInfo;
class CssPropBuffer;
class HtmlWChpxWriter
{
public:	
	HtmlWChpxWriter(const KDWPropx* chpx, HtmlWGlobalInfo* info, INT istdpara = stiNil);
	HtmlWChpxWriter(const void* pchpx, INT cb, HtmlWGlobalInfo* info, INT istdpara = stiNil);
	HtmlWChpxWriter(HtmlWGlobalInfo* info);
public:
	STDMETHODIMP_(void) SetProp(const KDWPropx* chpx, INT istdpara = stiNil);
	STDMETHODIMP_(void) SetProp(const void* pchpx, INT cb, INT istdpara = stiNil);	
private:	
	STDMETHODIMP_(void) ResetMember(const KDWPropx* chpx = NULL, INT istdpara = stiNil);
	STDMETHODIMP_(CHARSETINFO) GetSysCharsetInfo() const
	{
		CHARSETINFO chinfo;
		DWORD acp = GetACP();
		TranslateCharsetInfo((DWORD*)acp, &chinfo, TCI_SRCCODEPAGE);
		return chinfo;
	}
public:
	// gets	
	STDMETHODIMP_(const KDWFont&) GetFont() const;
	STDMETHODIMP_(CHARSETINFO) GetCharsetInfo(INT iFont);
	STDMETHODIMP_(CHARSETINFO) GetCharsetInfo() const;
	STDMETHODIMP_(HtmlWSpanPr&) GetChp();	
	STDMETHODIMP_(const KDWPropx*) GetPicLocation() const;	
	
public:
	// sets
	//STDMETHODIMP_(void) SetFtcHint(UINT ftcHint);	
public:
	STDMETHODIMP_(void) Write(CssPropBuffer* cssprop);
	STDMETHODIMP_(void) ToChp();	
	STDMETHODIMP_(void) ToCss(CssPropBuffer* cssprop, LPCSTR delim = DefalutDelim);
	STDMETHODIMP_(void) ToCss(const HtmlWSpanPr* p, CssPropBuffer* cssprop, LPCSTR delim = DefalutDelim);
private:
	KDWSprmList m_sprms;
	const KDWPropx* m_chpx, *m_backupchpx;
	HtmlWGlobalInfo* m_ginfo;
	INT m_istdpara, m_istd;
	HtmlWSpanPr m_prop;	
	KDWFont m_font;
};
#endif /* __HTML_CHPX_H__ */
