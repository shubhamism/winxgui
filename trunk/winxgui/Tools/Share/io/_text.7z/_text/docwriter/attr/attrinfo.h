/* -------------------------------------------------------------------------
//	�ļ���		��	attr/attrinfo.h
//	������		��	����
//	����ʱ��	��	2004-8-15 10:01:23
//	��������	��	
//	$Id: attrinfo.h,v 1.7 2005/07/18 13:20:14 zhuyie Exp $
// -----------------------------------------------------------------------*/
#ifndef __ATTR_ATTRINFO_H__
#define __ATTR_ATTRINFO_H__

#include <doctarget.h>

// -------------------------------------------------------------------------
#define DW_ATTRAPI inline STDMETHODIMP
#define DW_ATTRAPI_(type) inline STDMETHODIMP_(type)

// -------------------------------------------------------------------------
typedef STDMETHODIMP FnAttrTrans(
	IN UINT sprmOp, 
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf);

// -------------------------------------------------------------------------
struct KDWAttrsInfo;
typedef KDWAttrsInfo const KDWCAttrsInfo;
struct KDWAttrsInfo
{
	ATTRID Id;
	UINT16 sprmOp;
	FnAttrTrans* pFn;
	KDWCAttrsInfo* pItem;
	UINT uCount;
	ULONG sprmOpEx;
	FnAttrTrans* pFnEx;
	STDMETHODIMP_(KDWCAttrsInfo*) Item(
		IN ATTRID Id, IN KDWCAttrsInfo* pPreOne = NULL) const
	{
		for (int i = 0; i <	uCount; ++i)
			if (Id == pItem[i].Id)
			{
				if (pPreOne >= pItem + i)
					continue;
				return pItem + i;
			}
		return NULL;
	}
};

// -------------------------------------------------------------------------
#define ATTRINFO(_id) ((KDWCAttrsInfo*)&AInfo_##_id)
#define BEGIN_ATTR(_id)	\
	static KDWAttrsInfo __AInfoSub_##_id[] = {
#define SIM_ATTR(_id, _sprm, _fn)	\
	{ _id, _sprm, (FnAttrTrans*)_fn, 0, 0, 0, 0 },
#define SIM_ATTREX(_id, _sprm, _fn, _sprmEx, _fnEx)	\
	{ _id, _sprm, (FnAttrTrans*)_fn, 0, 0, _sprmEx, (FnAttrTrans*)_fnEx },
#define SUB_ATTR(_id)	\
	{ _id, 0, 0, ATTRINFO(_id)->pItem, ATTRINFO(_id)->uCount, 0, 0 },
#define SUB_ATEX(_id, _sprm, _fn)	\
	{ _id, _sprm, (FnAttrTrans*)_fn, ATTRINFO(_id)->pItem, ATTRINFO(_id)->uCount, 0, 0 },
#define END_ATTR(_id)	\
	};	\
	static KDWAttrsInfo AInfo_##_id = \
	{_id, 0, 0, __AInfoSub_##_id, countof(__AInfoSub_##_id)};

// -------------------------------------------------------------------------
inline
STDMETHODIMP ParseAttrInfo(
	IN KDWCAttrsInfo* pAttrInfo,
	IN KDWDocTarget* pTarget, 
	IN IKAttributes* pAttr, 
	IN KDWPropBuffer* pBuf)
{
	if (!pTarget || !pAttr || !pBuf || !pAttrInfo)
	{
		ASSERT(0);
		return E_INVALIDARG;
	}

	HRESULT hr = S_OK;
	UINT uCount = pAttr->Count();
	for (int i = 0; i < uCount; ++i)
	{
		ATTRID Id;
		ATTRVALUE_PTR pAttrVal;
		hr = pAttr->GetAt(i, &Id, &pAttrVal);
		KS_CHECK(hr);

		KDWCAttrsInfo* pInfo = pAttrInfo->Item(Id);
		if (pInfo)
		{
			if (pAttrVal->vt == ATTRVALUE::vtAttrList)
			{
				for (;;)
				{
					if (pInfo->pFn)
					{
						hr = pInfo->pFn(pInfo->sprmOp, pTarget, pAttrVal, pBuf);
						ASSERT_OK(hr);
					}

					if (pInfo->sprmOpEx && pInfo->pFnEx)
					{
						hr = pInfo->pFnEx(pInfo->sprmOpEx, pTarget, pAttrVal, pBuf);
						ASSERT_OK(hr);
					}

					hr = ParseAttrInfo(
						pInfo, pTarget, (IKAttributes*)pAttrVal->punkVal, pBuf);
					ASSERT_OK(hr);
					if (hr == IO_S_ATTR_UNHANDLE)
					{
						if (pInfo = pAttrInfo->Item(Id, pInfo))
							continue;
					}
					break;
				}
			}
			else
			{
				for (;;)
				{
					if (pInfo->pFn)
					{
						hr = pInfo->pFn(pInfo->sprmOp, pTarget, pAttrVal, pBuf);
						ASSERT_OK(hr);
						if (hr == IO_S_ATTR_UNHANDLE)
						{
							if (pInfo = pAttrInfo->Item(Id, pInfo))
								continue;
						}
					}

					if (pInfo && pInfo->sprmOpEx && pInfo->pFnEx)
					{
						hr = pInfo->pFnEx(pInfo->sprmOpEx, pTarget, pAttrVal, pBuf);
						ASSERT_OK(hr);
						if (hr == IO_S_ATTR_UNHANDLE)
						{
							if (pInfo = pAttrInfo->Item(Id, pInfo))
								continue;
						}
					}

					break;
				}
			}
		}
	}

KS_EXIT:
	return hr;
}

// -------------------------------------------------------------------------

#endif /* __ATTRINFO_H__ */

// $Log: attrinfo.h,v $
// Revision 1.7  2005/07/18 13:20:14  zhuyie
// no message
//
// Revision 1.6  2005/07/13 07:04:25  rongjianxing
// *** empty log message ***
//
// Revision 1.5  2005/07/12 12:36:32  huangjianing
// KDWAttrsInfo���ӵ���sprmEx�ĳ�Ա
//
// Revision 1.4  2005/07/07 07:08:50  xushiwei
// ���Զ�ȡ���ݴ���
//
// Revision 1.3  2005/04/25 08:15:04  wangdong
// �޶�״̬��д��
//
