/* -------------------------------------------------------------------------
//	�ļ���		��	text_range_end.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 21:08:51
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_range_end.h"
#include <bookmark/bookmarkconnect.h>
#include <doctarget.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace kso_text;

// -------------------------------------------------------------------------

STDMETHODIMP KTextRangeEndHandler::StartElement(
												IN ELEMENTID uElementID,
												IN KROAttributes* pAttrs)
{
	UINT uRangeID = 0;
	VERIFY_OK(
		pAttrs->GetByID(text_range_id, &uRangeID));

	const KDWRangeMap& rgMap = m_pDocTarget->GetRangeMap();
	
	KDWRangeMapIt itFind = rgMap.find(uRangeID);
	ASSERT(itFind != rgMap.end());

	if (itFind == rgMap.end())
		return E_INVALIDARG;

	const KDWRangeData& rgData = (*itFind).second;
	switch (rgData.rgt)
	{
	case rgtBookmark:	{
		KBookmarkConnection* pConnect = m_pDocTarget->GetBookmarkConnection();
		if (pConnect)
		{
			CP cpEnd = m_pDocTarget->GetFcMax();
			ASSERT(
				rgData.subdocType == m_pDocTarget->GetCurSubdocType()
				);
			pConnect->DecodeRange(uRangeID, rgData.cpStart, cpEnd + m_AdjustCpEnd);
		}
		break;			}
	default:
		REPORT_ONCE("KTextRangeEndHandler::AddAttributes - Unexcepted Attributes!");
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
