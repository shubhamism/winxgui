/* -------------------------------------------------------------------------
//	�ļ���		��	text_frame.cpp
//	������		��	����
//	����ʱ��	��	2004-8-24 18:10:18
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#include <doctarget.h>
#include <texttable/text_table.h>

#include "text_frame.h"
#include "attrframe.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KTextFrameHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	KDWPropBuffer* prop = m_pDocTarget->GetPropBuffer();
	VERIFY_OK(TransFrameAttr(m_pDocTarget, pAttrs, prop));
	return m_pDocTarget->EnterFrame(prop);
}

STDMETHODIMP KTextFrameHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_p:
		m_paraElement.Init(m_pDocTarget);
		*ppHandler = &m_paraElement;
		break;
	case kso_schema::text_table:
		if (m_tableElement == NULL)
			m_tableElement = new KTextTableHandler;
		m_tableElement->Init(m_pDocTarget);
		*ppHandler = m_tableElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

STDMETHODIMP KTextFrameHandler::EndElement(IN ELEMENTID uElementID)
{
	return m_pDocTarget->LeaveFrame();
}

KTextFrameHandler::KTextFrameHandler()
	: m_tableElement(NULL), m_pDocTarget(NULL)
{
}

KTextFrameHandler::~KTextFrameHandler()
{
	delete m_tableElement;
}

// -------------------------------------------------------------------------
