/* -------------------------------------------------------------------------
//	�ļ���		��	text_span.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 19:00:45
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_SPAN_H__
#define __TEXT_SPAN_H__

#ifndef __TEXT_RANGE_BEGIN_H__
#include "text_range_begin.h"
#endif

#ifndef __TEXT_RANGE_END_H__
#include "text_range_end.h"
#endif

#ifndef __TEXT_ANNOTATION_BEGIN_H__
#include <comment/text_annotation_begin.h>
#endif

#ifndef __TEXT_ANNOTATION_END_H__
#include <comment/text_annotation_end.h>
#endif

#ifndef __TEXT_CITATION_BREAK_H__
#include <footnote/text_citation_break.h>
#endif

#ifndef __TEXT_SYMBOL_H__
#include "text_symbol.h"
#endif

class KTextAnchorHandler;
class KTextFootnoteHandler;
class KHyperlinkBeginHandler;
class KHyperlinkEndHandler;

// -------------------------------------------------------------------------

class KTextSpanHandler : public KFakeUnknown<KElementHandler>
{
public:
	KTextSpanHandler() : 
		m_hypBeginElement(NULL),
		m_hypEndElement(NULL),
		m_pSubPropBuf(NULL)
	{
		m_anchorElement = NULL;
		m_footnoteElement = NULL;
	}
	~KTextSpanHandler();

private:
	KDWDocTarget* m_pDocTarget;
	KDWPropBuffer* m_pSubPropBuf;

	// bookmark
	KTextRangeBeginHandler m_rangeBeginElement;
	KTextRangeEndHandler m_rangeEndElement;

	// annotation(commnet)
	KTextAnnBeginHandler m_annBeginElement;
	KTextAnnEndHandler m_annEndElement;

	// footnote(endnote)
	KTextFootnoteHandler* m_footnoteElement;
	KTextCitationBreakHandler m_citationbreakElement;

	// drawing
	KTextAnchorHandler* m_anchorElement;

	KHyperlinkBeginHandler* m_hypBeginElement;
	KHyperlinkEndHandler* m_hypEndElement;

	// symbol
	KTextSymbolHandler m_symbolElement;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
	
	STDMETHODIMP AddContent(IN CONTENTVALUE_PTR pContent);

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_SPAN_H__ */
