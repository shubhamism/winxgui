/* -------------------------------------------------------------------------
//	�ļ���		��	commentconnect.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 10:14:27
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __COMMENTCONNECT_H__
#define __COMMENTCONNECT_H__

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

// -------------------------------------------------------------------------

class KCommentConnection
{
private:
	typedef std::map<INT32, HANNOTATION> AnnIDMap;
	typedef std::map<INT32, HANNOTATIONREF> AnnRefIDMap;
	KDWDocTarget* m_pDocTarget;
	AnnIDMap	m_AnnIDMap;
	AnnRefIDMap m_AnnRefIDMap;
	HANNOTATION m_curhAnn;

	typedef std::vector<int> AnnRefIDList;
	AnnRefIDList m_CachedAnnRefIDList;

protected:
	STDMETHODIMP MapAnnID(int nAnnID, HANNOTATION hAnnID)
	{
		HRESULT hr;
		if (m_AnnIDMap.find(nAnnID) == m_AnnIDMap.end())
		{
			m_AnnIDMap[nAnnID] = hAnnID;
			hr = S_OK;
		}
		else
		{
			ASSERT(FALSE);
			hr = E_FAIL;
		}
		return hr;
	}
	STDMETHODIMP AnnIDLookup(int nAnnID, HANNOTATION* phAnnID)
	{
		ASSERT(phAnnID);

		HRESULT hr;
		if (m_AnnIDMap.find(nAnnID) != m_AnnIDMap.end())
		{
			*phAnnID = m_AnnIDMap[nAnnID];
			hr = S_OK;
		}
		else
		{
			ASSERT(FALSE);
			hr = E_FAIL;
		}
		return hr;
	}
	STDMETHODIMP MapAnnRefID(int nAnnRefID, HANNOTATIONREF hAnnRefID)
	{
		HRESULT hr;
		if (m_AnnRefIDMap.find(nAnnRefID) == m_AnnRefIDMap.end())
		{
			m_AnnRefIDMap[nAnnRefID] = hAnnRefID;
			hr = S_OK;
		}
		else
		{
			ASSERT(FALSE);
			hr = E_FAIL;
		}
		return hr;
	}
	STDMETHODIMP AnnRefIDLookup(int nAnnRefID, HANNOTATIONREF* phAnnRefID)
	{
		ASSERT(phAnnRefID);

		HRESULT hr;
		if (m_AnnRefIDMap.find(nAnnRefID) != m_AnnRefIDMap.end())
		{
			*phAnnRefID = m_AnnRefIDMap[nAnnRefID];
			hr = S_OK;
		}
		else
		{
			ASSERT(FALSE);
			hr = E_FAIL;
		}
		return hr;
	}

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP CreateAnnotationsHandler(
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP_(KDWDocTarget*) GetDocTarget() const
	{
		ASSERT(m_pDocTarget);
		return m_pDocTarget;
	}

	STDMETHODIMP BeginAddAnnotation(
		IN int nAnnID,
		IN int nAuthorID,
		IN const DATE& theDate);

	STDMETHODIMP EndAddAnnotation();

	STDMETHODIMP MarkAnnRefBegin(
		IN int nAnnID,
		IN int nAnnRefID);

	STDMETHODIMP MarkAnnRefEnd(
		IN int nAnnRefID);

public:
	__forceinline
	STDMETHODIMP_(VOID) OnReachLowerBound()
	{
		AnnRefIDList::const_iterator i = m_CachedAnnRefIDList.begin();
		for (; i != m_CachedAnnRefIDList.end(); ++i)
			ForceMarkAnnRefEnd(*i);
		m_CachedAnnRefIDList.clear();
	}

private:
	STDMETHODIMP ForceMarkAnnRefEnd(
		IN int nAnnRefID);
};

// -------------------------------------------------------------------------

#endif /* __COMMENTCONNECT_H__ */
