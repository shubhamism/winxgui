
#ifndef __TESTCOMMON_H__
#include "testcommon.h"
#endif

#define _IoFormat_RTF				(filterKSOXMLText | 0x05)
#define _IoFormat_Rtf				(filterKSOXMLText | 0x01)

// -------------------------------------------------------------------------

STDAPI filterpluginExportCreate(
								IN long lFormat,
								IN IKFilterEventNotify* pNotify,
								OUT IKFilterMediaInit** ppv);

// -------------------------------------------------------------------------

typedef STDMETHODIMP _FnInitialize();
typedef STDMETHODIMP _FnTermiate();
typedef STDMETHODIMP _FnFilterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv);
typedef _FnInitialize* FnInitialize;
typedef _FnTermiate* FnTermiate;
typedef _FnFilterpluginImportCreate* FnFilterpluginImportCreate;

class KConvertRtf2Rtf
{
private:
	HMODULE m_hLib;
	HMODULE m_hLib2;
	FnFilterpluginImportCreate m_fnCreateSource;
	FnTermiate m_fnTerm;
	
public:
	KConvertRtf2Rtf() : m_fnCreateSource(NULL), m_fnTerm(NULL), m_hLib(NULL), m_hLib2(NULL)
	{
	}
	~KConvertRtf2Rtf()
	{
		term();
	}
	
	void term()
	{
		if (m_fnTerm)
		{
			m_fnTerm();
			m_fnTerm = NULL;
			m_fnCreateSource = NULL;
		}
		if (m_hLib)
		{
			FreeLibrary(m_hLib);
			m_hLib = NULL;
		}
		if (m_hLib2)
		{
			FreeLibrary(m_hLib2);
			m_hLib2 = NULL;
		}
	}

	void convert(
		IN LPCWSTR szDocFileSrc,
		IN LPCWSTR szRtfFileDest)
	{
		printf("\n[loading \"%S\"...]\n", szDocFileSrc);
		WCHAR szSrcFile[_MAX_PATH];
		WCHAR szRtfFile[_MAX_PATH];

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szSrcFile, MAX_PATH);
		wcscat(szSrcFile, __L("/"));
		wcscat(szSrcFile, szDocFileSrc);

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szRtfFile, MAX_PATH);
		wcscat(szRtfFile, __L("/"));
		wcscat(szRtfFile, szRtfFileDest);

		convertFile(szSrcFile, szRtfFile);
	}

	HRESULT convertFile(
		IN LPCWSTR szSrcFile,
		IN LPCWSTR szRtfFile)
	{
		//_XMsgBoxTraceW(__X("src = \"%s\", dest = \"%s\"\n"), szSrcFile, szDocFile);

		HRESULT hr = E_FAIL;
		if (m_fnCreateSource == NULL)
		{
			m_hLib = LoadLibrary("docreader");
			KS_CHECK_BOOL(m_hLib);

			m_hLib2 = LoadLibrary("rtfreader");
			KS_CHECK_BOOL(m_hLib2);
			
			FnInitialize fnInit = (FnInitialize)GetProcAddress(m_hLib, "_dr_Initialize");
			KS_CHECK_BOOL(fnInit);
			
			hr = fnInit();
			KS_CHECK(hr);
			
			m_fnCreateSource = (FnFilterpluginImportCreate)
				GetProcAddress(m_hLib2, "filterpluginImportCreate");
			KS_CHECK_BOOLEX(m_fnCreateSource, hr = E_FAIL);
			
			m_fnTerm = (FnTermiate)GetProcAddress(m_hLib, "_dr_Terminate");
		}
		{
			ks_stdptr<IKFilterMediaInit> spInitSrc;
			hr = m_fnCreateSource(_IoFormat_Rtf, NULL, &spInitSrc);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInitSrc, szSrcFile, STGM_T_READ);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentSource> spSrc;
			hr = spInitSrc->QI(IKContentSource, &spSrc);
			KS_CHECK(hr);
			
			ks_stdptr<IKFilterMediaInit> spInit;
			hr = filterpluginExportCreate(_IoFormat_RTF, NULL, &spInit);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInit, szRtfFile, STGM_G_CREATE);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentHandler> spAcc;
			hr = spInit->QI(IKContentHandler, &spAcc);
			KS_CHECK(hr);
			
			hr = spSrc->Transfer(spAcc);
			spSrc->Close();
			ASSERT_OK(hr);
		}
KS_EXIT:
		return hr;
	}
};
