/* -------------------------------------------------------------------------
//	�ļ���		��	commentconnect.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 10:14:43
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "commentconnect.h"
#include "office_annotation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

typedef KDWCollectionHandler<KOfficeAnnotationHandler, office_annotation>
		KOfficeAnnotationsHandler;

STDMETHODIMP KCommentConnection::CreateAnnotationsHandler(
									  OUT IKElementHandler** ppHandler)
{
	KOfficeAnnotationsHandler* pHandler = DW_NEWHANDLER(KOfficeAnnotationsHandler);
	pHandler->Init(this);
	*ppHandler = pHandler;
	return S_OK;
}

// -------------------------------------------------------------------------

STDMETHODIMP KCommentConnection::BeginAddAnnotation(
									IN int nAnnID,
									IN int nAuthorID,
									IN const DATE& theDate)
{
	// ��authorID��ӳ��ת��
	UINT uUserID;
	HRESULT hr;
	hr = m_pDocTarget->AnnotationUserIDLookup(nAuthorID, &uUserID);
	if (hr != S_OK)
		return hr;

	// ���������ʹ�DATEתΪDTTM
	DTTM theDTTM;
	DATE2DTTM(theDate, &theDTTM);

	// ��ʼ
	m_curhAnn = NULL;
	ASSERT(m_pDocTarget);
	hr = m_pDocTarget->BeginAddAnnotation(
			uUserID, &theDTTM, &m_curhAnn);
	if (hr == S_OK)
		MapAnnID(nAnnID, m_curhAnn);
	return hr;
}

STDMETHODIMP KCommentConnection::EndAddAnnotation()
{
	ASSERT(m_pDocTarget);
	return m_pDocTarget->EndAddAnnotation(m_curhAnn);
}

STDMETHODIMP KCommentConnection::MarkAnnRefBegin(
		IN int nAnnID,		// ��ע���ID
		IN int nAnnRefID)	// ��ע���õ�ID
{
	HANNOTATION hAnn;
	HRESULT hr = AnnIDLookup(nAnnID, &hAnn);
	if (hr != S_OK)
	{
		ASSERT(FALSE);	// ������һ�������ڵ���ע��
	}
	else
	{
		HANNOTATIONREF hAnnRef;
		ASSERT(m_pDocTarget);
		hr = m_pDocTarget->MarkAtnRefBegin(hAnn, &hAnnRef);
		if (hr == S_OK)
			MapAnnRefID(nAnnRefID, hAnnRef);
	}
	return hr;
}

STDMETHODIMP KCommentConnection::ForceMarkAnnRefEnd(
	IN int nAnnRefID)
{
	HANNOTATIONREF hAnnRef;
	HRESULT hr = AnnRefIDLookup(nAnnRefID, &hAnnRef);
	if (hr != S_OK)
	{
		ASSERT(FALSE);	// ����ע����û�ж�Ӧ��MarkAnnRefBegin
		hr = E_FAIL;
	}
	else
	{
		HANNOTATIONREF hAnnRef = m_AnnRefIDMap[nAnnRefID];
		ASSERT(m_pDocTarget);
		hr = m_pDocTarget->MarkAtnRefEnd(hAnnRef);
	}
	return hr;
}

STDMETHODIMP KCommentConnection::MarkAnnRefEnd(IN int nAnnRefID)
{
	
	if (m_pDocTarget->GetCurSubdoc()->TextPool().size())
	{
		const WCHAR lastCh = 
			m_pDocTarget->GetCurSubdoc()->TextPool().back();
		if ( lastCh == 0x0c || lastCh == 0x0d )
		{
			m_CachedAnnRefIDList.push_back(nAnnRefID);
			return S_OK;
		}
	}
	return ForceMarkAnnRefEnd(nAnnRefID);
}

// -------------------------------------------------------------------------
