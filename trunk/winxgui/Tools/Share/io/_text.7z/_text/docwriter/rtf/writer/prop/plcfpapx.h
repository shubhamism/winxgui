/* -------------------------------------------------------------------------
//	�ļ���		��	plcfpapx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:52:43
//	��������	��	
//
//	$Id: plcfpapx.h,v 1.3 2006/01/21 09:06:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PLCFPAPX_H__
#define __PLCFPAPX_H__
#include "papx.h"
#include "table.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWPapxsWriter
{
private:
	const KDWPlcfPapx* m_papxs;
	RtfWGlobalInfo* m_ginfo;

	KDWPlcfPapx::Enumerator m_enumer;
	
	RtfWPapxWriter m_wrPapx;
	RtfWTableWriter m_wrTbl;
	INT m_current;
public:
	RtfWPapxsWriter(const KDWPlcfPapx* papxs, RtfWGlobalInfo* info);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(UINT) GetIstd(UINT cp);
	STDMETHODIMP_(RtfWPapxWriter&) GetPapInfo();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
};
// -------------------------------------------------------------------------
//	$Log: plcfpapx.h,v $
//	Revision 1.3  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.2  2006/01/20 08:43:00  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:02  xulingjiao
//	*** empty log message ***
//	

#endif /* __PLCFPAPX_H__ */
