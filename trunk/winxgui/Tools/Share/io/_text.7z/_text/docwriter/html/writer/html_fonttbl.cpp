/* -------------------------------------------------------------------------
//	�ļ���		��	html_fonttbl.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:29:55
//	��������	��	
//
//	$Id: html_fonttbl.cpp,v 1.7 2006/07/24 01:28:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "html_fonttbl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
STDMETHODIMP HtmlWFontWriter::Write(HtmlDirectWriterA* ar, const KDWFont* font)
{
	HRESULT hr = Convert2Cssprop(font);
	if(SUCCEEDED(hr))
		m_cssprop.Write(ar);
	return hr;
}

STDMETHODIMP HtmlWFontWriter::Convert2Cssprop(const KDWFont* font)
{
	if(!font)
		return E_FAIL;
	m_cssprop.SetSelector("@font-face");
	m_cssprop.StartBlock();	
	unsigned char utf8name[MAX_PATH] = "";
	int nutf8name = MAX_PATH;
	int nname = wcslen(font->name)*2;
	int nret = UTF16LEToUTF8(utf8name, &nutf8name, (const unsigned char*)font->name, &nname, 1);
	utf8name[nret] ='\0';
	utf8name[nret+1] = '\0';
	m_cssprop.AddString(cssprop_font_family, (LPCSTR)utf8name, '\"');
	/*
	m_cssprop.AddString(cssprop_panose_1, panose);
	@todo ��Ϊdocreader��������panose�Ǵ���, ��ʱ��д
	*/
	m_cssprop.EndBlock();
	return S_OK;
}

HtmlWFontTableWriter::HtmlWFontTableWriter(HtmlWGlobalInfo* info) : m_ginfo(info)
{
}

STDMETHODIMP HtmlWFontTableWriter::Write()
{
	const KDWFontTable* fTbl = &m_ginfo->doc->GetFontTable();	
	for(UINT i=0; i<fTbl->Count(); ++i)
	{
		KDWFont font;
		if(SUCCEEDED(fTbl->Item(i, &font)))
			m_wrFont.Write(m_ginfo->ar, &font);
	}
	return S_OK;
}