/* -------------------------------------------------------------------------
//	�ļ���		��	html_htmlwriter.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:31:24
//	��������	��	
//
//	$Id: html_htmlwriter.h,v 1.9 2006/07/17 06:26:41 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_HTMLWRITER_H__
#define __HTML_HTMLWRITER_H__

#include "mso/io/html/writer/include/htmlfile.h"
#include "html_document.h"

class KHtmlWriter :
	public KElementDispatcher,
	public IKFilterMediaInit,
	public KComObjectRoot
{
private:
	KOfficeDocHandler m_docHandler;
	KDWDocTarget m_Target;
	DWFileType m_FileType;

	HtmlDirectWriterA m_ar;
	
public:
	STDMETHODIMP SetDestFile(LPCWSTR szFileName)
	{
		m_ar.SetDestFile(szFileName);
		return S_OK;
	}
	STDMETHODIMP SetSrcFile(LPCWSTR szFileName)
	{
		m_ar.SetSrcFile(szFileName);
		return S_OK;		
	}
	STDMETHODIMP StartDocument(IN UINT nReservedParam)
	{			
		ks_stdptr<IStorage> pDestStg;
		HRESULT hr;
		DWORD crmode = 0|STGM_READ|STGM_WRITE|STGM_CREATE|STGM_SHARE_EXCLUSIVE;
		hr = StgCreateDocfile(NULL, crmode, 0, &pDestStg);
		if (FAILED(hr))
			return hr;

		_kso_InitIoSchemaDbgInfo();

		m_docHandler.Init(&m_Target);
		KElementDispatcher::Init(office_document, &m_docHandler);
		return m_Target.NewDocument(pDestStg, NULL, m_FileType);
	}

    STDMETHODIMP EndDocument(
		IN BOOL fAbort)
	{
		if (!fAbort)
		{
			HtmlWDocumentWriter wrDocument;
			wrDocument.Write(&m_ar, &m_Target);
		}
		m_Target.Close(TRUE);
		return S_OK;
	}

	STDMETHODIMP Init(IN DWFileType FileType = dwFileDefault)
	{
		m_FileType = FileType;
		return S_OK;
	}
	STDMETHODIMP Init(IN LPCFILTERMEDIUM pMedium)
	{
		switch (pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			return m_ar.Open(pMedium->lpszFileName);
			break;
		case FILTER_TYMED_ISTREAM:
			return m_ar.Open(pMedium->pstm, TRUE);
			break;
		}

		return E_NOTIMPL;
	}
	
	BEGIN_QUERYINTERFACE(IKContentHandler)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_COUNT(KHtmlWriter)
};
#endif /* __HTML_HTMLWRITER_H__ */
