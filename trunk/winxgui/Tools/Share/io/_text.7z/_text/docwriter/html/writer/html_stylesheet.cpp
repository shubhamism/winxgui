/* -------------------------------------------------------------------------
//	�ļ���		��	html_stylesheet.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:33:17
//	��������	��	
//
//	$Id: html_stylesheet.cpp,v 1.6 2006/06/29 05:43:57 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "html_globalinfo.h"
#include "html_style.h"
#include "html_stylesheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
STDMETHODIMP_(void) HtmlWStyleSheetWriter::Write(IN HtmlWGlobalInfo* info)
{
	INT count = info->doc->GetStyleSheet().Count();
	if (count <= 0)
		return;
	HtmlWStyleWriter wr(info);
	for (INT i = 0; i < count; ++i)		
		wr.Write(i);		
}