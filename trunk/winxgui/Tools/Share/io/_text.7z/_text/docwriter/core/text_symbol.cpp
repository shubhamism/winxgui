/* -------------------------------------------------------------------------
//	�ļ���		��	text_symbol.cpp
//	������		��	����
//	����ʱ��	��	2004-8-24 11:39:49
//	��������	��	
//	$Id: text_symbol.cpp,v 1.4 2004/10/06 07:12:57 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_symbol.h"
#include <doctarget.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextSymbolHandler::StartElement(
											  IN ELEMENTID uElementID,
											  IN KROAttributes* pAttrs)
{
	ASSERT(pAttrs);
	ATTRVALUE_PTR pvFontId = NULL;
	pAttrs->GetIndex(text_symbol_font, &pvFontId);
	ATTRVALUE_PTR pvCode = NULL;
	pAttrs->GetIndex(text_symbol_code, &pvCode);
	if (pvFontId && pvCode)
	{
		KDWFontIDMap& IdMap = m_pDocTarget->GetFontIDMap();
		KDWFontIDMapIt i = IdMap.find(pvFontId->lVal);
		UINT uFontId = 0;
		if (i != IdMap.end())
			uFontId = (*i).second;

		if (m_pPropBuf == NULL)
			m_pPropBuf = m_pDocTarget->GetPropBuffer();
		INT32 oprand = 0;
		oprand = (INT16)uFontId + (((INT16)pvCode->lVal) << (sizeof(INT16) * 8));
		m_pPropBuf->AddPropFix(sprmCSymbol, oprand);
		m_pDocTarget->NewSpan(m_pPropBuf);
		m_pDocTarget->AddContent('\x28');
		return S_OK;
	}
	ASSERT_ONCE(0);
	return S_FALSE;
}


// -------------------------------------------------------------------------
