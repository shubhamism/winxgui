/* -------------------------------------------------------------------------
//	�ļ���		��	html_style.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:32:56
//	��������	��	
//
//	$Id: html_style.cpp,v 1.12 2006/07/17 06:26:41 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "mso/io/css/cssbuffer.h"
#include "props/html_chpx.h"
#include "props/html_papx.h"
#include "html_style.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
void HtmlWStyleWriter::GenerateSelector(ks_string& sel, UINT sgc, UINT sti, INT istd)
{		
	char buf[35] = "";
	_itoa(istd, buf, 10);			
	switch(sgc)
	{
	case mso_sgcParagraph:
		sel = "p.";
		sel.append(buf);				
		break;
	case mso_sgcCharacter:
		sel = "span.";					
		sel.append(buf);								
		break;
	default:
		ASSERT_ONCE(0);
		break;
	}
}

HtmlWStyleWriter::HtmlWStyleWriter(HtmlWGlobalInfo* info) : m_info(info)
{
}

STDMETHODIMP HtmlWStyleWriter::Write(INT istd)
{	
	HtmlWStyleSheet* styles = m_info->htmlstsh;
	KDWStyle style;
	if (FAILED(styles->GetStyle(istd, &style)))
		return E_FAIL;
	CssPropBuffer cssbuf;
	UINT sgc = style.GetType();
	UINT sti = style.GetId();

	ks_string sel;
	GenerateSelector(sel, sgc, sti, istd);
	cssbuf.SetSelector(sel.c_str());
	
	cssbuf.StartBlock();

	HtmlWSpanPr spanpr;
	const HtmlWSpanPr* chpx = NULL;
	if (sgc != mso_sgcCharacter) // �����ϣ�ֻ�д��ַ���ʽ��û�ж�����
	{
		const HtmlWParaPr* papx = styles->GetMergedPapx(istd);
		HtmlWPapxWriter wrPapx(m_info);
		if (papx)			
		{
			if(istd == stiNormal)
			{
				cssbuf.AddLength(cssprop_margin, 0, lu_pt);
				cssbuf.AddLength(cssprop_margin_bottom, 0.0001, lu_pt);
			}
			wrPapx.ToCss(papx, &cssbuf);
		}
		chpx = styles->GetMergedChpxAtPStyle(istd);
	}
	else
		chpx = styles->GetMergedChpx(spanpr, istd, stiNil);
	
	HtmlWChpxWriter wrChpx(m_info);
	if (chpx)		
		wrChpx.ToCss(chpx, &cssbuf);

	cssbuf.EndBlock();
	cssbuf.Write(m_info->ar);
	return S_OK;
}
