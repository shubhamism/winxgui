/* -------------------------------------------------------------------------
//	�ļ���		��	ranges.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:10:07
//	��������	��	
//
//	$Id: ranges.h,v 1.9 2006/08/07 01:51:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFRANGES_H__
#define __RTFRANGES_H__
#include "range/atnref.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/

// -------------------------------------------------------------------------
// todo: �ýyһ��һ��CP�������


//#include "range/annotations.h" new_annotation
class RtfWGlobalInfo;
class RtfWChpxWriter;
class RtfWChpxsWriter;
class RtfWPapxWriter;
class RtfWPapxsWriter;
class RtfWSepxsWriter;
class RtfWBookmarkStartsWriter;
class RtfWBookmarkEndsWriter;
class RtfWFieldsWriter;
class RtfDirectWriter;
class RtfWNotesWriter;
typedef RtfWNotesWriter RtfWFndsWriter, RtfWEndsWriter;
class RtfAcceptFieldCode;
class RtfWRangesWriter
{
private:
	RtfWGlobalInfo* m_ginfo;

	RtfWChpxsWriter* m_wrChpxs;
	RtfWPapxsWriter* m_wrPapxs;
	RtfWSepxsWriter* m_wrSepxs;
	RtfWBookmarkStartsWriter* m_wrBookmarkStarts;
	RtfWBookmarkEndsWriter* m_wrBookmarkEnds;
	RtfWFndsWriter* m_wrFnds;
	RtfWEndsWriter* m_wrEnds;
	RtfWFieldsWriter* m_wrFields;

	RtfWAtnRefStartsWriter* m_wrAtnStarts;
	RtfWAtnRefEndsWriter* m_wrAtnEnds;	

	struct CurrentMask
	{
		BOOL fChpxs, fPapxs, fSepxs;
		BOOL fBookmarkStarts, fBookmarkEnds;
		BOOL fAtnStarts, fAtnEnds, fAtnTxts;
		BOOL fFnds, fEnds;
		BOOL fFields;
		CurrentMask() {	Reset(); }
		void Reset(){ZeroMemory(this, sizeof(CurrentMask));}
	}m_current;

	CP m_cp;
public:
	STDMETHODIMP_(KDWRange) GetRefRange(BOOL fEndNote);
	RtfWRangesWriter(RtfWGlobalInfo* info);
	STDMETHODIMP_(RtfWGlobalInfo*) GetGlobalInfo();
	STDMETHODIMP_(RtfWChpxWriter&) GetChpInfo();
	STDMETHODIMP_(RtfWPapxWriter&) GetPapInfo();
	STDMETHODIMP_(void) SetPlcfChpx(RtfWChpxsWriter* wrChpxs);
	STDMETHODIMP_(void) SetPlcfPapx(RtfWPapxsWriter* wrPapxs);
	STDMETHODIMP_(void) SetPlcfSepx(RtfWSepxsWriter* wrSepxs);
	STDMETHODIMP_(void) SetBookmarkStarts(RtfWBookmarkStartsWriter* wrStarts);
	STDMETHODIMP_(void) SetBookmarkEnds(RtfWBookmarkEndsWriter* wrEnds);
	STDMETHODIMP_(void) SetAtnStarts(RtfWAtnRefStartsWriter* wrAtnStarts);
	STDMETHODIMP_(void) SetAtnEnds(RtfWAtnRefEndsWriter* wrAtnEnds);	
	STDMETHODIMP_(void) SetFnds(RtfWFndsWriter* wrFnds);
	STDMETHODIMP_(void) SetEnds(RtfWEndsWriter* wrEnds);
	STDMETHODIMP_(void) SetFields(RtfWFieldsWriter* wrFields);	
public:	
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(CP) GetCp();
	STDMETHODIMP_(CP) GetNextCp();
	STDMETHODIMP_(CP) GetSectCurrentCp();	
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
	STDMETHODIMP_(void) EnsureWriteEnd(RtfDirectWriter* ar);

private:
	UINT __GetCp();
	UINT __GetCpNext();
};
// -------------------------------------------------------------------------
//	$Log: ranges.h,v $
//	Revision 1.9  2006/08/07 01:51:38  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.8  2006/08/03 03:45:29  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.7  2006/08/02 08:54:28  xulingjiao
//	�޸�BUG
//	
//	Revision 1.6  2006/04/05 04:53:20  xulingjiao
//	��ע
//	
//	Revision 1.5  2006/02/13 01:33:05  xulingjiao
//	rtfwriter�Ѿ�֧����ע��
//	
//	Revision 1.4  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.3  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.2  2006/01/11 02:47:46  rongjianxing
//	wpio�ӵ������С�
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __RANGES_H__ */
