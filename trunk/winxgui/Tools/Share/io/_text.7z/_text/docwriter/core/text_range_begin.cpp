/* -------------------------------------------------------------------------
//	�ļ���		��	text_range_begin.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 21:06:41
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_range_begin.h"
#include <doctarget.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace kso_text;

// -------------------------------------------------------------------------

STDMETHODIMP KTextRangeBeginHandler::StartElement(
												  IN ELEMENTID uElementID,
												  IN KROAttributes* pAttrs)
{
	IKElementHandler* pHandler = NULL;
	UINT uRangeID = 0;
	UINT uRangeType = rgtInvalid;
	VERIFY_OK(
		pAttrs->GetByID(text_range_type, &uRangeType));
	VERIFY_OK(
		pAttrs->GetByID(text_range_id, &uRangeID));

	KDWRangeMap& rgMap = m_pDocTarget->GetRangeMap();
	ASSERT(
		rgMap.find(uRangeID) == rgMap.end());

	KDWRangeData rgData;
	rgData.cpStart = m_pDocTarget->GetFcMax();
	rgData.subdocType = m_pDocTarget->GetCurSubdocType();
	rgData.rgt = (RANGE_TYPE)uRangeType;
	ASSERT(rgData.rgt == rgtBookmark);

	rgMap[uRangeID] = rgData;
	return S_OK;
}

// -------------------------------------------------------------------------
