/* -------------------------------------------------------------------------
//	�ļ���		��	html2doc.h
//	������		��	���὿
//	����ʱ��	��	2006-7-5 14:56:39
//	��������	��	
//
//	$Id: html2doc.h,v 1.1 2006/07/05 08:27:40 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML2DOC_H__
#define __HTML2DOC_H__

class KConvertDoc2Html
{
private:
	HMODULE m_hLib;
	FnFilterpluginImportCreate m_fnCreateSource;
	FnTermiate m_fnTerm;
	
public:
	KConvertDoc2Html();
	~KConvertDoc2Html();	
	void term();
	void convert(IN LPCWSTR szDocFileSrc, IN LPCWSTR szHtmlFileDest);
	HRESULT convertFile(IN LPCWSTR szSrcFile, IN LPCWSTR szHtmlFile);
};
#endif /* __HTML2DOC_H__ */
