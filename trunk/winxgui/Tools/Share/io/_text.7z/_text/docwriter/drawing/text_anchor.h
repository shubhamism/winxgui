/* -------------------------------------------------------------------------
//	�ļ���		��	text_anchor.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-18 10:56:31
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_ANCHOR_H__
#define __TEXT_ANCHOR_H__

#ifndef __DRAW_SHAPE_H__
#include "draw_group.h"
#endif

#ifndef __DRAWINGCONNECT_H__
#include "drawingconnect.h"
#endif

#ifndef __EMB_ANALYZER_H__
#include "emb_analyzer.h"
#endif

// -------------------------------------------------------------------------
// ������������붥���������ֶ����Ǵ�doctarge�����ģ�����ӵ��ê�����ԡ�
class KTextAnchorHandler : public KFakeUnknown<KElementHandler>
{
private:
	enum { atInvalid = -1 };

	KDWDocTarget*	m_pDocTarget;

	INT				m_AnchorType;
	UINT			m_ZOrder;
	KDWShapeAnchor	m_Anchor;

	KDWShapeHandlerContext	m_ShapeContext;
	KDWAnchorShapeHandler*	m_pShapeElem;
	KDWAnchorGroupHandler*	m_pGroupElem;
	IKElementHandler*		m_pElement;

	ELEMENTID m_ElementId;

	STDMETHODIMP_(KDWOleShape) _NewOleShape(IN KROAttributes* pAttrs);
	STDMETHODIMP_(KDWOleShape) _NewOleControl(IN KROAttributes* pOleControl);

public:

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementId,
		IN KROAttributes* pAttrs);
		
	STDMETHODIMP EndElement(IN ELEMENTID uElementId)
	{
		ASSERT(m_pElement);
		return m_pElement->EndElement(uElementId);
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		ASSERT(m_pElement);
		return m_pElement->EnterSubElement(uSubElementID, ppHandler);
	}

public:
	KTextAnchorHandler()
	{
		m_pShapeElem = NULL;
		m_pGroupElem = NULL;
		m_pElement = NULL;
		ZeroStruct(m_Anchor);
	}
	~KTextAnchorHandler()
	{
		delete m_pShapeElem;
		delete m_pGroupElem;
	}
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
		m_ShapeContext.m_pDocTarget = m_pDocTarget;
		m_ShapeContext.m_pDgg = pDocTarget->GetDrawingConnection();
		m_AnchorType = atInvalid;
		m_ElementId = 0;
	}
};

// -------------------------------------------------------------------------

#endif /* __TEXT_ANCHOR_H__ */

// $Log: text_anchor.h,v $
// Revision 1.25  2006/04/07 04:08:11  laipinge
// no message
//
// Revision 1.24  2004/12/06 10:13:58  wangdong
// no message
//
// Revision 1.23  2004/11/26 10:39:38  xushiwei
// *** empty log message ***
//
// Revision 1.22  2004/10/10 12:23:26  wangdong
// *** empty log message ***
//
// Revision 1.21  2004/10/08 03:34:56  wangdong
// *** empty log message ***
//
// Revision 1.20  2004/10/08 03:32:00  wangdong
// *** empty log message ***
//
// Revision 1.19  2004/10/06 07:12:57  xushiwei
// *** empty log message ***
//
// Revision 1.18  2004/09/30 07:16:58  wangdong
// *** empty log message ***
//
// Revision 1.17  2004/09/30 07:16:00  wangdong
// ������Ѿ�����text_anchor��ǩ��ȡ�����ı������塣

// ���������������ն�������:draw_shape, draw_group
//
