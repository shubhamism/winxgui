/* -------------------------------------------------------------------------
//	�ļ���		��	textstream.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:40:05
//	��������	��	
//
//	$Id: textstream.cpp,v 1.19 2006/09/06 01:25:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "ranges.h"
#include "prop/plcfchpx.h"
#include "prop/plcfpapx.h"
#include "drawing/drawing.h"
#include "drawing/embshape.h"
#include "range/field.h"
#include "range/fields.h"
#include "textstream.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP RtfWTextStreamWriter::AddSpecChar(RtfDirectWriter* ar, WCHAR wch, CP cp, RtfWChpxWriter* wrChpx)
{
	BOOL fSpec = wrChpx->GetChp().fSpec;
	if(!fSpec)	
		return E_FAIL;
	switch(wch)
	{
	case FOOTNOTE_REF:		
		ar->AddAttribute(rtf_chftn);
		return S_OK;
	case FOOTNOTE_SEP:
		ar->AddAttribute(rtf_chftnsep);
		return S_OK;
	case FOOTNOTE_CONT:
		ar->AddAttribute(rtf_chftnsepc);
		return S_OK;
	case ANNOTATION_REF:
		return S_OK;
	case FIELD_BEGIN:		
		return S_OK;
	case FIELD_SEP:
		return S_OK;
	case FIELD_END:
		return S_OK;
	case EMB_SHAPE:		
		if (m_wrEmbShape)
			m_wrEmbShape->Write(ar, wrChpx->GetPicLocation());		
		return S_OK;
	case DRAWING_OBJ:
		if (m_wrDrawing)
			m_wrDrawing->Write(ar, cp);
		return S_OK;
	}
	ASSERT_ONCE(0);
	return E_FAIL;
}

STDMETHODIMP RtfWTextStreamWriter::Add0x0d(RtfDirectWriter* ar, DWORD ciACP, INT filtermask)
{	
	if(!m_wrRanges->GetPapInfo().GetPap().mask.fNestCell && !m_wrRanges->GetPapInfo().GetPap().mask.fRowEnd2)
	{
		if(filtermask & CHAR_FILTER_LOWCHAR)
			ar->AddContentChar(0x0d, ciACP);
		else
			ar->AddAttribute(rtf_par);
	}
	else
	{
		if(!m_wrRanges->GetPapInfo().GetPap().fRowEnd2)
		{
			ar->AddAttribute(rtf_nestcell);
			m_wrRanges->GetPapInfo().GetPap().fNestCell = 0;
			m_wrRanges->GetPapInfo().GetPap().mask.fNestCell = 0;
		}
		else				
		{
			ar->AddAttribute(rtf_nestrow);
			m_wrRanges->GetPapInfo().GetPap().fNestCell = 0;
			m_wrRanges->GetPapInfo().GetPap().mask.fNestCell = 0;
			m_wrRanges->GetPapInfo().GetPap().fRowEnd2 = 0;
			m_wrRanges->GetPapInfo().GetPap().mask.fRowEnd2 = 0;
			ar->EndGroup();
		}
	}
	return S_OK;
}

STDMETHODIMP RtfWTextStreamWriter::Add0x07(RtfDirectWriter* ar, DWORD ciACP, INT filtermask)
{
	if(!m_wrRanges->GetPapInfo().GetPap().mask.fRowEnd)
	{
		ar->AddAttribute(rtf_cell);				
	}
	else
	{
		if(m_wrRanges->GetPapInfo().GetPap().fRowEnd)
		{
			ar->AddAttribute(rtf_row);
			m_wrRanges->GetPapInfo().GetPap().fRowEnd = 0;
			m_wrRanges->GetPapInfo().GetPap().mask.fRowEnd = 0;
		}				
	}
	return S_OK;
}

STDMETHODIMP RtfWTextStreamWriter::Add0x0e(RtfDirectWriter* ar, DWORD ciACP, INT filtermask)
{
	if(filtermask & CHAR_FILTER_LOWCHAR)			
		ar->AddContentChar(0x0e, ciACP);
	else
		ar->AddAttribute(rtf_column);
	return S_OK;
}

STDMETHODIMP RtfWTextStreamWriter::Add0x0b(RtfDirectWriter* ar, DWORD ciACP, INT filtermask)
{
	if(filtermask & CHAR_FILTER_LOWCHAR)
		ar->AddContentChar(0x0b, ciACP);
	else
		ar->AddAttribute(rtf_line);
	return S_OK;
}

STDMETHODIMP RtfWTextStreamWriter::Add0x09(RtfDirectWriter* ar, DWORD ciACP, INT filtermask)
{
	if(filtermask & CHAR_FILTER_LOWCHAR)
		ar->AddContentChar(0x09, ciACP);
	else
		ar->AddAttribute(rtf_tab);
	return S_OK;
}

STDMETHODIMP RtfWTextStreamWriter::Add0x0c(RtfDirectWriter* ar, DWORD ciACP, CP cp, INT filtermask)
{	
	if(filtermask & CHAR_FILTER_LOWCHAR)
		ar->AddContentChar(0x0c, ciACP);
	else
	{
		INT cpSect = m_wrRanges->GetSectCurrentCp();
		if(cp == cpSect-1)
			ar->AddAttribute(rtf_sect);
		else
		{
			if(m_CurCp != m_stream->Count()-1)
				ar->AddAttribute(rtf_page);
			else
				ar->AddAttribute(rtf_sect);
		}
	}
	return S_OK;
}

STDMETHODIMP RtfWTextStreamWriter::AddNormalChar(RtfDirectWriter* ar, TxCharClass chclass, WCHAR wch, INT& iLastFont, RtfWChpxWriter* wrChpx)
{
	DWORD ciACP = wrChpx->GetCharsetInfo().ciACP;	
	switch(chclass)
	{
	case CC_FarEast:
		{	
			INT iFastEastFont = m_wrRanges->GetChpInfo().GetChp().rgftc[mso_ftcFastEast];
			INT iftc = m_wrRanges->GetChpInfo().GetChp().iftc;
			INT iCurrentFont = m_wrRanges->GetChpInfo().GetChp().rgftc[iftc];
			CHARSETINFO chset = m_wrRanges->GetChpInfo().GetCharsetInfo(iFastEastFont);
			// �����ǰ���岻��ȷ�Բ���û��д����ȷ����
			if(iFastEastFont != iCurrentFont && iFastEastFont != iLastFont)
			{						
				ar->AddAttribute(rtf_dbch);
				ar->AddAttribute(rtf_f, iFastEastFont);
				iLastFont = iFastEastFont;					
			}
			ar->AddContentChar(wch, chset.ciACP);
		}
		break;
	default:
		if(chclass != CC_NoFarEast && chclass != CC_Shared)
			ar->AddContentChar(wch, ciACP);
		else
			ar->AddUnicodeChar(wch, FALSE);
		break;
	}
	return S_OK;
}

STDMETHODIMP_(void) RtfWTextStreamWriter::WriteText(RtfDirectWriter* ar, const KDWTextStream* p, RtfWChpxWriter* wrChpx, CP cp, INT cch, INT filtermask)
{
	if (cch <= 0)
		return;	
	DWORD ciACP = wrChpx->GetCharsetInfo().ciACP;
	UINT8 fSpec = wrChpx->GetChp().fSpec;
	INT iLastFont = -1;
	HRESULT hr = S_OK;
	for(UINT i=0; i<cch; ++i)
	{
		WCHAR wch = p->GetText(cp);
		TxCharClass chclass = _TxGetCharClass(wch);
		switch(wch)
		{		
		case SYMBOL:
			if(!wrChpx->GetChp().symbol.opval)
				ar->AddContentChar(wch, ciACP);
			break;
		case 0x0D:
			Add0x0d(ar, ciACP, filtermask);
			break;
		case 0x07:
			Add0x07(ar, ciACP, filtermask);
			break;
		case 0x0E:
			Add0x0e(ar, ciACP, filtermask);
			break;
		case 0x0B:
			Add0x0b(ar, ciACP, filtermask);
			break;
		case 0x09:
			Add0x09(ar, ciACP, filtermask);
			break;
		case 0x0C:
			Add0x0c(ar, ciACP, cp, filtermask);
			break;
		default:
			hr = AddSpecChar(ar, wch, cp, wrChpx);
			if(SUCCEEDED(hr))
			{
				++cp;
				continue;
			}			
			AddNormalChar(ar, chclass, wch, iLastFont, wrChpx);
			break;
		}
		++cp;
	}
	m_CurCp = cp;
}

RtfWTextStreamWriter::RtfWTextStreamWriter(
	const KDWTextStream* stream,
	RtfWRangesWriter* wrRanges,	
	SUBDOC_TYPE subDoc,
	RtfWDrawingWriter* wrDrawing,
	RtfWEmbShapeWriter* wrEmbShape) :
	m_stream(stream),
	m_wrRanges(wrRanges),
	m_SubDoc(subDoc),
	m_wrDrawing(wrDrawing),
	m_wrEmbShape(wrEmbShape)
{
	ASSERT(wrRanges);
}

STDMETHODIMP_(RtfWRangesWriter*) RtfWTextStreamWriter::GetRangesWriter()
{
	return m_wrRanges;
}

STDMETHODIMP_(const KDWTextStream*) RtfWTextStreamWriter::GetTextStream() const
{
	return m_stream;
}

STDMETHODIMP_(RtfWGlobalInfo*) RtfWTextStreamWriter::GetGlobalInfo()
{
	return m_wrRanges->GetGlobalInfo();
}

STDMETHODIMP_(void) RtfWTextStreamWriter::Write(RtfDirectWriter* ar, SUBDOC_TYPE subdoctype)
{
	if (!m_stream)
		return;
	Write(ar, 0, m_stream->Count(), subdoctype);
}

STDMETHODIMP RtfWTextStreamWriter::WriteNoteRef(RtfDirectWriter* ar, CP cp)
{
	WCHAR wch = m_stream->GetText(cp);
	if(wch == 0x0d)
		return E_FAIL;
	WriteText(ar, m_stream, &m_wrRanges->GetChpInfo(), cp, 1);
	m_CurCp = cp+1;
	return S_OK;
}

STDMETHODIMP_(void) RtfWTextStreamWriter::Write(RtfDirectWriter* ar, CP cp, INT cch, SUBDOC_TYPE subdoctype)
{
	if (!m_stream)
		return;
	if (cch <= 0)
		return;
	const KDWTextStream* t = m_stream;
	RtfWRangesWriter*& wrRanges = m_wrRanges;

	KDWPlcfPapx papx = t->GetPlcfPapx();
	RtfWPapxsWriter wrPapxs(&papx, wrRanges->GetGlobalInfo());
	wrRanges->SetPlcfPapx(&wrPapxs);

	KDWPlcfChpx chpx = t->GetPlcfChpx();
	RtfWChpxsWriter wrChpxs(&chpx, wrRanges->GetGlobalInfo());
	wrRanges->SetPlcfChpx(&wrChpxs);

	cch = (cch >= 0) ? cch : (t->Count() - cp);
	CP cpWriteEnd = cp + cch;
	cpWriteEnd = MIN(cpWriteEnd, t->TextPool().size());
	m_CurCp = cp;

	wrRanges->Reset();

	while (m_CurCp < cpWriteEnd)
	{		
		CP cpEnd = wrRanges->GetCp();		
		cpEnd = MIN(cpEnd, cpWriteEnd);		
		if (cpEnd >= m_CurCp)
		{			
			WriteText(ar, t, &wrChpxs.GetChpInfo(), m_CurCp, cpEnd - m_CurCp);
			if(cpEnd < cpWriteEnd)
				wrRanges->Write(ar);
		}
		else
		{			
			ASSERT_ONCE(0);
			if(cpEnd < cpWriteEnd)
			{
				wrRanges->Write(ar);
			}			
		}
		if (FAILED(wrRanges->Next()))
		{
			cpEnd = cpWriteEnd;
			WriteText(ar, t, &wrChpxs.GetChpInfo(), m_CurCp, cpEnd - m_CurCp);
			if(m_SubDoc == SUBDOC_MAIN)
			{
				WCHAR chLast = m_stream->GetLastChar();				
				if(chLast==0x0C)
				{
					ar->StartGroup(rtf_pard);
					ar->AddAttribute(rtf_par);
					ar->EndGroup();
				}
			}
			break;
		}
	}
	wrRanges->EnsureWriteEnd(ar);
}