/* -------------------------------------------------------------------------
//	�ļ���		��	hyperlinkconnect.h
//	������		��	����
//	����ʱ��	��	2004-8-24 10:32:59
//	��������	��	
//	$Id: hyperlinkconnect.h,v 1.4 2004/09/17 09:55:52 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __HYPERLINKCONNECT_H__
#define __HYPERLINKCONNECT_H__


// -------------------------------------------------------------------------
class KDWDocTarget;
class KHyperlinkConnection
{
	KDWDocTarget* m_pDocTarget;
	UINT32 m_uNestLevel;
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_uNestLevel = 0;
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP CreateHyperlinkHandler(
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP_(KDWDocTarget*) GetDocTarget() const
	{
		ASSERT(m_pDocTarget);
		return m_pDocTarget;
	}

public:
	STDMETHODIMP AddHyperlink(
		IN LPCWSTR szHref,
		IN LPCWSTR szBookmark,
		IN LPCWSTR szTargetFrame,
		IN LPCWSTR szToolTip,
		IN LPCWSTR szStyle,
		IN LPCWSTR szVisitedStyle);
	STDMETHODIMP BeginHyperlink(
		IN UINT uHyperlinkId);
	STDMETHODIMP EndHyperlink();

private:
	struct HyperlinkInfo
	{
		ks_wstring strHref;
		ks_wstring strBookmark;
		ks_wstring strTargetFrame;
		ks_wstring strToolTip;
		ks_wstring szStyle;
		ks_wstring szVisitedStyle;
	};

	typedef std::vector<HyperlinkInfo> HypListType;
	HypListType m_HyperlinkList;
};


// -------------------------------------------------------------------------

#endif /* __HYPERLINKCONNECT_H__ */
