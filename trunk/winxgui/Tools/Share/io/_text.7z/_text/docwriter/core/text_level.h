/* -------------------------------------------------------------------------
//	�ļ���		��	text_level.h
//	������		��	����
//	����ʱ��	��	2004-8-18 15:15:06
//	��������	��	
//	$Id: text_level.h,v 1.6 2004/12/23 08:07:26 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_LEVEL_H__
#define __TEXT_LEVEL_H__


// -------------------------------------------------------------------------
class KTextLevelHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWV6Lists* m_pLists;
	KDWListLevel m_listLevel;
	INT m_iLst;
	INT m_iLvl;

public:
	STDMETHODIMP_(void) Init(
		IN KDWV6Lists* pLists,
		IN INT iLst, IN INT iLvl,
		IN KDWListLevel listLevel)
	{
		m_iLst = iLst;
		m_iLvl = iLvl;
		m_pLists = pLists;
		m_listLevel = listLevel;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_LEVEL_H__ */
