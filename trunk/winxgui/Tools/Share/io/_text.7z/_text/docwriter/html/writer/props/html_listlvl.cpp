/* -------------------------------------------------------------------------
//	�ļ���		��	html_listlvl.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:48:35
//	��������	��	
//
//	$Id: html_listlvl.cpp,v 1.18 2006/08/25 08:21:15 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "../draws/html_draws_helper.h"
#include "../props/html_chpx.h"
#include "html_listlvl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
HtmlWListLevelWriter::HtmlWListLevelWriter(HtmlWGlobalInfo* info) : m_ginfo(info)
{
}
STDMETHODIMP HtmlWListLevelWriter::Write(UINT ilfo, UINT ilvl)
{	
	const _DW_ListLevel* pLvl = m_ginfo->doc->GetListTable().GetListLevel(ilfo, ilvl);
	if(!pLvl)
		return E_FAIL;
	if(pLvl->lvlf.nfc != 23)
	{
		LPCWSTR pXstByteswap = pLvl->pXstByteswap;
		const UINT8* pRgbxchNums = pLvl->lvlf.rgbxchNums;
		m_ginfo->ar->StartElement(elem_span);
		HtmlWChpxWriter wrchpLvl(pLvl->pChpx, pLvl->lvlf.cbGrpprlChpx, m_ginfo);
		CssPropBuffer csspropLvl;
		wrchpLvl.ToCss(&csspropLvl, "; ");
		WriteStyleAttribute(m_ginfo->ar, &csspropLvl);
		INT cXst = pXstByteswap[0], iXst, iNumber = 0;
		for(iXst=1; iXst<=cXst; ++iXst)
		{			
			INT iHolder = pRgbxchNums[iNumber];
			if(iHolder == iXst)
			{	
				INT iStartAt = pLvl->lvlf.iStartAt;
				++iNumber;
				INT number = pXstByteswap[iHolder];	
				INT count = m_ginfo->listcount.GetCount(ilfo, ilvl, number, &m_ginfo->doc->GetListTable());
				if(count != -1)
				{
					char buf[32] = "";
					itoa(count, buf, 10);
					m_ginfo->ar->put(buf);
				}				
			}
			else
			{
				WCHAR wch = pXstByteswap[iXst];
				m_ginfo->ar->AddUtf8Char(wch);				
			}
		}
		switch(pLvl->lvlf.ixchFollow)
		{
		case 0:
			m_ginfo->ar->AddUtf8Char(' ');
			break;
		case 1:
			m_ginfo->ar->AddUtf8Char(' ');
			break;		
		}		
		m_ginfo->ar->EndElement(elem_span);
		return E_FAIL;
	}
	//��Ŀ����
	m_ginfo->ar->StartElement(elem_span);
	HtmlWChpxWriter wrchp(pLvl->pChpx, pLvl->lvlf.cbGrpprlChpx, m_ginfo);
	CssPropBuffer cssprop;
	wrchp.ToCss(&cssprop, "; ");
	WriteStyleAttribute(m_ginfo->ar, &cssprop);
	if(!pLvl->cbChpxPicBullet)
		m_ginfo->ar->AddUtf8Char(pLvl->pXstByteswap[1]);
	else
	{
		const KDWBlip* picbullet = m_ginfo->doc->GetPicBullets().GetBlip(pLvl->nPicIndex);
		if(picbullet)
		{					
			ks_wstring src_attrval;
			ExportBlip2File(src_attrval, *picbullet, m_ginfo->ar->GetSrcFile());			
			/*
			Ҫ�����ֺż�������ĸ߶ȺͿ���.@todo
			*/			
			InchType inch = pt_to_inch(wrchp.GetChp().hps);			
			PixelType pixel = inch_to_pixel(inch);
			WriteIMGtag(m_ginfo->ar, src_attrval, pixel, pixel);
		}
	}
	m_ginfo->ar->EndElement(elem_span);
	return S_OK;
}	
