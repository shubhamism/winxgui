/* -------------------------------------------------------------------------
//	�ļ���		��	style.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:15:08
//	��������	��	
//
//	$Id: style.cpp,v 1.7 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "styleshelper.h"
#include "style.h"
#include "prop/chpx.h"
#include "prop/papx.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) RtfWStyleWriter::Write(
	RtfDirectWriter* ar, IN RtfWGlobalInfo* info, IN INT istd)
{
	RtfWStyleSheet* styles = info->styles;

	KDWStyle style;
	if (FAILED(styles->GetStyle(istd, &style)))
		return;

	UINT sgc = style.GetType();
	if (style.GetId() == stiNormal) // Normal��ʽ����"\*"ǰ׺�ͽM��
		ar->StartBlankGroup();
	else if (sgc == mso_sgcParagraph)
		ar->StartGroup(rtf_s, istd);
	else if (sgc == mso_sgcCharacter)
		ar->StartGroup(rtf_cs, istd, TRUE);
	else if (sgc == mso_sgcTextTable)
		ar->StartGroup(rtf_ts, istd, TRUE);
	else if (sgc == mso_sgcList)
		ar->StartGroup(rtf_ls, istd, TRUE);
	else
		ASSERT(0);

	RtfWSpanPr spanpr;
	const RtfWSpanPr* chpx = NULL;
	if (styles->GetSgc(istd) != mso_sgcCharacter) // �����ϣ�ֻ�д��ַ���ʽ��û�ж�����
	{
		const RtfWParaPr* papx = styles->GetMergedPapx(istd);
		RtfWPapxWriter wrPapx(info);
		if (papx)
			wrPapx.Write(ar, papx, istdNil);
		chpx = styles->GetMergedChpxAtPStyle(istd);
	}
	else
		chpx = styles->GetMergedChpx(spanpr, istd, stiNil);
	
	RtfWChpxWriter wrChpx(info);
	if (chpx)
		wrChpx.Write(ar, chpx);

	if (style.GetBaseStyle() != stiNil)
		ar->AddAttribute(rtf_sbasedon, style.GetBaseStyle());
	if (style.GetNextStyle() != stiNil)
		ar->AddAttribute(rtf_snext, style.GetNextStyle());
	if (style.GetLinkStyle() != stiNil && style.GetLinkStyle() != stiNormal)
		ar->AddAttribute(rtf_slink, style.GetLinkStyle());

	if (style.GetAutoRedef())
		ar->AddAttribute(rtf_sautoupd);
	
	if (style.GetId() == stiNormal)
	{
		ar->AddContent("Normal", 6);
	}
	else if (style.GetId() == stiNormalChar)
	{
		ar->AddContent("Default Paragraph Font", 22);
	}
	else
	{	
		LPCWSTR name = NULL;
		INT cch = 0;
		style.GetName(&name, &cch);
		// ��ʽ������ܳ���242���ַ�,����Word������, wps����.
		cch = cch > max_cch_of_style_name ? max_cch_of_style_name : cch;
		if (cch > 0)
			ar->AddContentWcs(name, cch);				
	}
	ar->AddContentWcs(__X(";"), 1);
	ar->EndGroup();
}