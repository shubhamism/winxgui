/* -------------------------------------------------------------------------
//	�ļ���		��	html_papxhelper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:06:26
//	��������	��	
//
//	$Id: html_papxhelper.h,v 1.7 2006/07/08 02:16:46 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_PAPXHELPER_H__
#define __HTML_PAPXHELPER_H__
#include "mso/propstruct/maskparapr.h"

struct HtmlWParaPr : MaskParaPr
{
	typedef HtmlWParaPr ThisType;
	typedef MaskParaPr BaseType;	
	STDMETHODIMP Sprms2ParaPr(IN const KDWSprmList* sprms, 
							  IN const HtmlWParaPr* baseon, 
							  IN const KDWListTable* lists)
	{
		return Sprms2MaskParaPr(sprms, this, baseon, lists);
	}
	STDMETHODIMP Sprms2ParaPr(IN const KDWPropx* prop, 
							  IN const HtmlWParaPr* baseon, 
							  IN const KDWListTable* lists)
	{	
		return Sprms2MaskParaPr(prop, this, baseon, lists);
	}
};

inline HtmlWParaPr* GetDefaultPapx()
{
	static HtmlWParaPr s_prop;
	static BOOL s_initflag = FALSE;
	if (!s_initflag)
	{
		s_prop.Reset();	
		s_initflag = TRUE;
	}
	return &s_prop;
}
#endif /* __HTML_PAPXHELPER_H__ */
