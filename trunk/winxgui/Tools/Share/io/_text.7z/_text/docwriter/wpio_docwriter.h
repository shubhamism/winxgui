/* -------------------------------------------------------------------------
//	�ļ���		��	wpio_docwriter.h
//	������		��	�ݽ���
//	����ʱ��	��	2006-1-10 10:56:35
//	��������	��	
//
//	$Id: wpio_docwriter.h,v 1.4 2006/02/20 01:34:00 rongjianxing Exp $
// -----------------------------------------------------------------------*/
#ifndef __WPIO_DOCWRITER_H__
#define __WPIO_DOCWRITER_H__

/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/

#include "../../../filter/wpio/wpio.h"

#ifndef __IO_ADAPTER_ISTREAMADAPTER_H__
#include "adapter/IStreamAdapter.h"
#endif

// -------------------------------------------------------------------------
class KWpioDocWirter : public KDocWriter
{
public:
	STDMETHODIMP Init(
		IN IKFilterEventNotify* pNotify, 
		IN DWFileType FileType = dwFileDefault)
	{
		return KDocWriter::Init(pNotify, FileType);
	}

	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		ks_stdptr<ILockBytes> splkbyt;
		
		HRESULT hr = _CreateILockBytesOnHGlobal(NULL, TRUE,	&splkbyt);
	
		if (FAILED(hr))
			return hr;

		ks_stdptr<IStorage> spStorage;
		hr = StgCreateDocfileOnILockBytes(
			splkbyt,
			STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE,
			0,
			&spStorage);

		if (FAILED(hr))
			return hr;
		
		FILTERMEDIUM medium;
		medium.tymed = FILTER_TYMED_ISTORAGE;
		medium.pstg = spStorage;
		return _kso_CreateStorageFromMedium(&medium, &m_pRootStg);
	}

	STDMETHODIMP EndDocument(
		IN BOOL fAbort)
	{	
		HRESULT hr = E_FAIL;
		{
		typedef 
		STDMETHODIMP _wpio_FnCreateDocument(
							IN KDWDocument& data,
							OUT interface WpioDocument** ppDoc
							);

		static HMODULE hLib = ::LoadLibrary("wpioapi");
		if (NULL == hLib)
			return E_FAIL;

		static _wpio_FnCreateDocument* fnCreateDocument = 
			(_wpio_FnCreateDocument*)::GetProcAddress(hLib, "_wpio_CreateDocument");
		if (NULL ==fnCreateDocument)
			return E_FAIL;

		ks_stdptr<WpioDocument> spWpioDocument;
		hr = fnCreateDocument(GetDocumentData(), &spWpioDocument);
		KS_CHECK(hr);

		VARIANT var;
		var.punkVal = spWpioDocument;
		hr = m_pNotify->OnNotify(FILTEREVENT_ENDDOCUMENT, 0, &var);
		}

KS_EXIT:
		return hr;
	}

	STDMETHODIMP_(KDWDocument&) GetDocumentData()
	{
		return m_target;
	}
};

// -------------------------------------------------------------------------
//	$Log: wpio_docwriter.h,v $
//	Revision 1.4  2006/02/20 01:34:00  rongjianxing
//	no message
//	
//	Revision 1.3  2006/01/17 06:54:33  rongjianxing
//	no message
//	
//	Revision 1.2  2006/01/11 05:14:03  rongjianxing
//	*** empty log message ***
//	
//	Revision 1.1  2006/01/11 02:47:10  rongjianxing
//	wpio�ӵ������С�
//	

#endif /* __WPIO_DOCWRITER_H__ */
