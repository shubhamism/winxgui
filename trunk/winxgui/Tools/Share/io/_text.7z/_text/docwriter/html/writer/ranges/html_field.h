/* -------------------------------------------------------------------------
//	�ļ���		��	html_field.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:10:34
//	��������	��	
//
//	$Id: html_field.h,v 1.6 2006/06/29 05:43:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_FIELD_H__
#define __HTML_FIELD_H__
// ===============
// Default Handler
class HtmlWGlobalInfo;
class HtmlDirectWriterA;
class HtmlWFieldHandler
{
public:	
	HtmlWFieldHandler(HtmlWGlobalInfo* info);
	virtual HRESULT HandleBeginMark(HtmlDirectWriterA* ar, KDWField* field = NULL);
	virtual HRESULT HandleSeparatorMark(HtmlDirectWriterA* ar, KDWField* field = NULL);
	virtual HRESULT HandleEndMark(HtmlDirectWriterA* ar, KDWField* field = NULL);
	virtual UCHAR GetMarkType() const;
	virtual UCHAR GetFieldType() const;
	virtual HRESULT AddCodeChar(WCHAR wch);	
protected:
	virtual HRESULT Clear();
protected:
	ks_wstring m_code;
	KDWField* m_field;
	HtmlWGlobalInfo* m_ginfo;
};

// =========
// Hyperlink
class HyperlinkFieldHandler : public HtmlWFieldHandler
{
public:
	HyperlinkFieldHandler(HtmlWGlobalInfo* info);
	virtual HRESULT HandleBeginMark(HtmlDirectWriterA* ar, KDWField* field = NULL);
	virtual HRESULT HandleSeparatorMark(HtmlDirectWriterA* ar, KDWField* field = NULL);
	virtual HRESULT HandleEndMark(HtmlDirectWriterA* ar, KDWField* field = NULL);
};
#endif /* __HTML_FIELD_H__ */
