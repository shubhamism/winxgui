/* -------------------------------------------------------------------------
//	�ļ���		��	drawingprop.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 19:04:30
//	��������	��	
//
//	$Id: drawingprop.h,v 1.15 2006/07/12 01:51:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAWINGPROP_H__
#define __DRAWINGPROP_H__
#include "drawingbasic.h"
#include "rtf/writer/include/rtffile.h"
#include <gdiplus.h>
#include <mso/filefmt/escher/ShapeProperties.h>
#include <mso/dom/text/drawing/drawing_helper.h>

// �ο�FIX2FLOAT����
inline float Fixnumber2Double(LONG fixnum)
{
	return (float)fixnum / 0x10000;
}

inline const RtfControl GetBlipTypeCtrl(UINT type)
{
	// todo: ������鲻һ������

	// ��: �ĵ��оٵ�rtf֧�ָ�ʽ:
	// emfblip pngblip jpegblip macpict pmmetafile wmetafile 
	// dibitmap <bitmapinfo>
	// wbitmap <bitmapinfo>

	const RtfControl s_items[] =
	{
		rtf_unknown,	//BlipERROR = 0,
		rtf_unknown,	//BlipUNKNOWN,            
		rtf_emfblip,	//BlipEMF,                
		rtf_wmetafile,	//BlipWMF,                
		rtf_pict,		//BlipPICT,               
		rtf_jpegblip,	//BlipJPEG,
		rtf_pngblip,	//BlipPNG,
		rtf_wmetafile,	//BlipDIB,
		rtf_unknown,	//BlipTIF,				
		rtf_unknown,	//BlipGIF,				
		rtf_unknown,	//BlipFirstClient = 32,   
		rtf_unknown,	//BlipLastClient  = 255
	};
	ASSERT(type < countof(s_items));
	ASSERT(s_items[type] != rtf_unknown);
	return s_items[type];
}	

// -------------------------------------------------------------------------
inline void WriteBlipCrop(RtfDirectWriter* ar, const CropType* rc)
{
	ar->AddAttribute(rtf_piccropl, rc->left);
	ar->AddAttribute(rtf_piccropr, rc->right);
	ar->AddAttribute(rtf_piccropt, rc->top);
	ar->AddAttribute(rtf_piccropb, rc->bottom);
}

inline void WriteBlipType(RtfDirectWriter* ar, const KDWBlip* p)
{
	const _MsoBlipData* blipEmb = p->Data();
	if (!blipEmb)	
	{
		ar->AddAttribute(rtf_wmetafile, 8);
		return;
	}
	RtfControl bliptype = GetBlipTypeCtrl(blipEmb->blipType);
	if (bliptype != rtf_unknown && bliptype != rtf_wmetafile)
		ar->AddAttribute(bliptype);
	else
		ar->AddAttribute(rtf_wmetafile, 8); // todo: ����ʶ�ľ�дwmetafile�����Բ���
}

inline void WriteBlipSize(RtfDirectWriter* ar, INT picwgoal, INT pichgoal)
{
	ar->AddAttribute(rtf_picscalex, 100);
	ar->AddAttribute(rtf_picscaley, 100);
	ar->AddAttribute(rtf_picwgoal, picwgoal);
	ar->AddAttribute(rtf_pichgoal, pichgoal);
}

inline void WriteBlipUid(RtfDirectWriter* ar, const KDWBlip* p)
{
	const _MsoBlipData* blipEmb = p->Data();
	ar->StartGroup(rtf_blipuid, rtf_nilParam, TRUE);
		ar->AddBinary(&blipEmb->blipHash, sizeof(blipEmb->blipHash));
		ar->AddBinary(&blipEmb->blipHash, sizeof(blipEmb->blipHash));
		ar->AddBinary(&blipEmb->blipHash, sizeof(blipEmb->blipHash));
		ar->AddBinary(&blipEmb->blipHash, sizeof(blipEmb->blipHash));
	ar->EndGroup();
}

inline STDMETHODIMP WriteConvertBlipData(RtfDirectWriter* ar,
						  const KDWBlip* blipEmbWrap,	
						  LPCWSTR szDesImageFmt)
{
	IStream* des = NULL;
	void* blipData = NULL;
	UINT cbBlipData;
	blipEmbWrap->Data()->blipBits->Lock(&blipData, &cbBlipData);	
	Gdiplus::Status err = _XGdiBlipConvert(&des, blipData, cbBlipData, szDesImageFmt);	
	if(err != Gdiplus::Ok)
	{
		if(des)
			des->Release();
		return E_FAIL;
	}
	HGLOBAL hGbl;
	GetHGlobalFromStream(des, &hGbl);
	LARGE_INTEGER li;
	LISet32(li, 0);
	ULARGE_INTEGER uli;
	ULISet32(uli, 0);
	des->Seek(li, STREAM_SEEK_END, &uli);
	BYTE* bits = (BYTE*)GlobalLock(hGbl);
	INT cb = uli.LowPart;	
	ar->AddBinary(bits, cb);
	if(des)
		des->Release();
	return S_OK;
}

inline STDMETHODIMP_(BOOL) WriteBlipData(RtfDirectWriter* ar, const KDWBlip* p)
{	
	const _MsoBlipData* blipEmb = p->Data();
	if(blipEmb->blipType != msoblipDIB)
	{		
		void* bits = NULL; UINT cb = 0;
		blipEmb->blipBits->Lock(&bits, &cb);
		// wmfͼƬҪ��ͷ����Ϣ������ֻд����
		// ��СΪ�ṹ��KWmfPlaceableFileHeader(pack 2)
		enum {WMF_HEADER_SIZE = 22};
		if (blipEmb->blipType == BlipWMF)
		bits = (BYTE*)bits + (INT)WMF_HEADER_SIZE;
		WriteBlipType(ar, p);
		WriteBlipUid(ar, p);
		ar->AddBinary(bits, cb);
		return FALSE;
	}
	ar->AddAttribute(rtf_pngblip);
	WriteBlipUid(ar, p);
	WriteConvertBlipData(ar, p, __X("image/png"));
	return TRUE;
}

inline void WritePropSN(RtfDirectWriter* ar, LPCSTR name, INT debugid = -1)
{
	ar->StartGroup(rtf_sn);
	{
		ar->AddContent(name, strlen(name));
		if (!IsValidName(name) && debugid != -1) // for debug
			ar->AddAttribute("id", debugid);
	}
	ar->EndGroup();
}

inline void WritePropSPI4(RtfDirectWriter* ar, LPCSTR name, INT value, INT debugid = -1)
{
	ar->StartGroup(rtf_sp);
		WritePropSN(ar, name, debugid);
		ar->StartGroup(rtf_sv);
		{
			char buff[32];
			sprintf(buff, "%d", value);
			ar->AddContent(buff, strlen(buff));
		}
		ar->EndGroup();
	ar->EndGroup();
}

inline void WritePropSPI4(RtfDirectWriter* ar, INT id, INT value, INT debugid = -1)
{
	WritePropSPI4(ar, GetPropName(id), value, debugid);
}

inline void WritePropSPI4(RtfDirectWriter* ar, MsoROShapeProp* prop)
{
	WritePropSPI4(ar, prop->pid, prop->op, prop->pid);
}

inline void WritePropSPBool(RtfDirectWriter* ar, MsoROShapeProp* prop)
{
	INT id = 0;
	BOOL value = FALSE;
	for (INT i = 0; i < 16; ++i)
	{
		if ((HIWORD(prop->op) & (1 << i)))
		{
			id = prop->pid - i;
			value = LOWORD(prop->op & (1 << i)) ? 1 : 0;
			WritePropSPI4(ar, id, value, id);
		}
	}
}

inline void WriteShapeTypeNFilp(RtfDirectWriter* ar, const _MsoShape* p, BOOL ischild = FALSE)
{
	if(!p->grf.fGroup)
		WritePropSPI4(ar, "shapeType", p->spt);
	if (!ischild)
	{
		WritePropSPI4(ar, "fFlipH", p->grf.fFlipH);
		WritePropSPI4(ar, "fFlipV", p->grf.fFlipV);
	}
	else
	{
		WritePropSPI4(ar, "fRelFlipH", p->grf.fFlipH);
		WritePropSPI4(ar, "fRelFlipV", p->grf.fFlipV);
	}
}

inline void WritePropSPString(RtfDirectWriter* ar, INT pid, LPCWSTR value)
{
	ar->StartGroup(rtf_sp);
		WritePropSN(ar, GetPropName(pid));
		ar->StartGroup(rtf_sv);
		ar->AddContentWcs(value);
		ar->EndGroup();
	ar->EndGroup();
}



class RtfWDrawingPropWriter
{
private:
	const MsoBlipStore* m_blipstore;
	const _KDWShape* m_shape;
	CropType m_crop;
	SIZE m_blipsize;

public:
	RtfWDrawingPropWriter(const KDWBlipStore* blipstore, const _KDWEmbShapeEx* p) : m_blipstore(blipstore)
	{
		m_crop.Init();
		PreScan(p->opt, &m_crop, &m_cdvec, p);
		m_blipsize.cx = p->cxaShape;
		m_blipsize.cy = p->cyaShape;
		m_blipsize = GetBlipSize(m_blipsize, m_crop);
	}
	RtfWDrawingPropWriter(const KDWBlipStore* blipstore, const _KDWShape* p) : m_blipstore(blipstore)
	{
		m_crop.Init();
		PreScan(p->opt, &m_crop, &m_cdvec, p);
		m_blipsize = GetShapeSize(p);
		m_blipsize = GetBlipSize(m_blipsize, m_crop);
	}
	void WriteShapeProp(RtfDirectWriter* ar, const _MsoShape* p, BOOL writepib = TRUE, BOOL writecrop = TRUE)
	{
		if (p->opt)
			WriteOPT(ar, p->opt, FALSE, writepib, writecrop);
		if (p->optUDef)
			WriteOPT(ar, p->optUDef, TRUE, writepib, writecrop);
	}	
	void WriteBlip(RtfDirectWriter* ar, const _KDWEmbShapeEx* p)
	{
		// todo: �Ż������Բ���lookup
		KDWBlip blipEmbWrap = _MsoLookupBlip(p->opt, msopt_pib, *m_blipstore);
		if(!blipEmbWrap.Good())
			return;
		const _MsoBlipData* blipEmb = blipEmbWrap.Data();
		WriteBlipCrop(ar, &m_crop);
		WriteBlipSize(ar, m_blipsize.cx, m_blipsize.cy);		
		WriteBlipData(ar, &blipEmbWrap);
	}
	void WriteConvertBlip(	RtfDirectWriter* ar, 
							const _KDWShape* p,							
							LPCWSTR szDesImageFmt,
							RtfAttribute blipType)
	{		
		KDWBlip blipEmbWrap = _MsoLookupBlip(p->opt, msopt_pib, *m_blipstore);
		if(!blipEmbWrap.Good())
			return;		
		WriteBlipSize(ar, m_blipsize.cx, m_blipsize.cy);
		WriteBlipCrop(ar, &m_crop);
		ar->AddAttribute(blipType.prop, blipType.value);
		WriteBlipUid(ar, &blipEmbWrap);		
		WriteConvertBlipData(ar, &blipEmbWrap, szDesImageFmt);
	}
private:
	void WriteOPT(RtfDirectWriter* ar, _MsoShapeOPT* p, BOOL udef, BOOL writepib = TRUE, BOOL writecrop = TRUE)
	{
		KObjPropsTable opt(p, udef);

		MsoROShapeProp prop;
		INT count = opt.GetCount();
		KObjPropsTable::Enumerator _enum(opt);
		
		for (INT i = 0; i < count; ++i)
		{
			VERIFY_OK(_enum.Next(&prop));
			INT id = prop.pid;
			if (!writepib && id == msopt_pib)
				continue;
		
			if (!writecrop && (
				id == msopt_cropFromLeft ||
				id == msopt_cropFromRight ||
				id == msopt_cropFromTop ||
				id == msopt_cropFromRight))
				continue;

			if (!prop.fComplex)
			{
				switch(id)
				{
				case msopt_pib:					
					WritePropSPPib(ar, &m_blipstore->GetBlip(prop.op), "pib");
					break;
				case msopt_fillBlip:			
					WritePropSPPib(ar, &m_blipstore->GetBlip(prop.op), "fillBlip");
					break;
				case msopt_lineFillBlip:
					WritePropSPPib(ar, &m_blipstore->GetBlip(prop.op), "lineFillBlip");
					break;					
				default:
					if (_MsoIsBoolPid(id))
						WritePropSPBool(ar, &prop);
					else					
						WritePropSPI4(ar, &prop);						
				}				
			}
			else
			{
				const UINT8* data = prop.dataComplex + m_cdvec.GetOffset(id);			
				if (IsArrayProp(id))
					WritePropSPArray(ar, data, GetPropName(id));
				else if (IsWStringProp(id))
					WritePropSPString(ar, id, (LPCWSTR)data);
				else
				{
					ASSERT_ONCE(0);
				}
			}
		}
	}	
	void WritePropSPPib(RtfDirectWriter* ar, const KDWBlip* p, LPCSTR sn)
	{
		ar->StartGroup(rtf_sp);
			WritePropSN(ar, sn);
			ar->StartGroup(rtf_sv);
				ar->StartGroup(rtf_pict);
					WriteBlipCrop(ar, &m_crop);
					WriteBlipSize(ar, m_blipsize.cx, m_blipsize.cy);					
					WriteBlipData(ar, p);
				ar->EndGroup();
			ar->EndGroup();
		ar->EndGroup();
	}
	void WritePropSPArray(RtfDirectWriter* ar, const UINT8* prop, LPCSTR sn)
	{
		ar->StartGroup(rtf_sp);
		WritePropSN(ar, sn);
		ar->StartGroup(rtf_sv);

		MsoArrayHeader* header = (MsoArrayHeader*)prop;
		CHAR buff[32];
		
		UINT16 size_of_each_element = header->cbItem;		
		UINT16 number_of_element = header->cItem;
		UINT16 cbNumber = header->cbItem;

		sprintf(buff, "%d;%d;", size_of_each_element, number_of_element);

		ar->AddContent(buff, strlen(buff));
		
		const BYTE* pt = (const BYTE*)(header + 1);

		for (INT i = 0; i < number_of_element; ++i)
		{
			// todo: �����ɴ�Сֱ���ж����ͣ���һ����ȷ���μ�IsArrayProp�е�����˵��
			buff[0] = '\0';

			switch(size_of_each_element)
			{
			case 2:
				{
					UINT16 val = *(UINT16*)(pt);
					sprintf(buff, "%d", val);
					pt += header->cbItem;
				}
				break;
			case 4:
				{
					UINT32 val = *(UINT32*)(pt);
					sprintf(buff, "%d", val);
					pt += header->cbItem;
				}
				break;
			case 8:
				{
					UINT32 val1 = *(UINT32*)(pt);
					pt += 4;
					UINT32 val2 = *(UINT32*)(pt);
					pt += 4;
					sprintf(buff, "(%d,%d)", val1, val2);					
				}
				break;
			}

			ar->AddContent(buff, strlen(buff));
			if (i + 1 != number_of_element)
				ar->AddContent(";", 1);
		}

		ar->EndGroup();
		ar->EndGroup();
	}
	

private:
	// OPT�и������͵����ݽ�����OPT��������pid��С������ģ������ɽ����е��鷳���ο�word97�ĵ�:OPT
	// todo: �ŵ�optparser��ȥ
	
	class ComplexDataVec
	{
		struct Item
		{
			INT pid;
			INT offset;
			bool operator<(const Item& x)
			{
				return pid < x.pid;
			}
		};
		typedef std::vector<Item> ItemList;
		ItemList m_items;

		INT m_cb;

	public:
		ComplexDataVec() : m_cb(0)
		{}
		void Add(INT pid, INT len)
		{
			Item newitem = {pid, 0};
			ItemList::iterator it = std::lower_bound(m_items.begin(), m_items.end(), newitem);

			if (it != m_items.end())
				newitem.offset = it->offset;
			else
				newitem.offset = m_cb;

			for (ItemList::iterator itset = it; itset != m_items.end(); ++itset)
				itset->offset += len;

			m_items.insert(it, newitem);
			m_cb += len;
		}
		INT GetOffset(INT pid)
		{
			for (ItemList::iterator it = m_items.begin(); it != m_items.end(); ++it)
				if (it->pid == pid)
					return it->offset;
			ASSERT(0);
			return 0;
		}
	};
	ComplexDataVec m_cdvec;
	void PreScan(const _MsoShapeOPT* opt, OUT CropType* crop, OUT ComplexDataVec* cdvec, const _KDWShape* p)
	{
		memset(crop, 0, sizeof(RECT));
		if (opt == NULL)
			return;

		const FOPTE* it = (const FOPTE*)(opt + 1);
		const FOPTE* last = it + opt->inst;
		for ( ; it != last; ++it)
		{
			double ret = 0;
			
			switch (it->pid)
			{
			case msopt_cropFromLeft:
				ret = Fixnumber2Double(it->op);				
				crop->left = ret*p->cxaShape;
				break;
			case msopt_cropFromRight:
				ret = Fixnumber2Double(it->op);
				crop->right = ret*p->cxaShape;
				break;
			case msopt_cropFromTop:
				ret = Fixnumber2Double(it->op);
				crop->top = ret*p->cyaShape;
				break;
			case msopt_cropFromBottom:
				ret = Fixnumber2Double(it->op);
				crop->bottom = ret*p->cyaShape;
				break;
			}
			if (it->fComplex)
				cdvec->Add(it->pid, it->len);
		}
	}
};
// -------------------------------------------------------------------------
//	$Log: drawingprop.h,v $
//	Revision 1.15  2006/07/12 01:51:51  xulingjiao
//	��BUG
//	
//	Revision 1.14  2006/05/08 05:31:11  xulingjiao
//	�޸�25795��BUG
//	
//	Revision 1.13  2006/04/29 01:01:35  xulingjiao
//	�޸�#25968��BUG
//	
//	Revision 1.12  2006/04/25 01:01:57  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.11  2006/04/25 00:44:06  xulingjiao
//	ͼƬ�ü�
//	
//	Revision 1.10  2006/04/24 01:54:34  xulingjiao
//	
//	�޸�23432�ŵ�BUG
//	
//	Revision 1.9  2006/04/19 07:52:36  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.8  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.7  2006/04/13 00:52:30  xulingjiao
//	�޸�ͼƬ��ʾ��������BUG
//	
//	Revision 1.6  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.5  2006/03/13 03:40:26  xulingjiao
//	�޸���עBUG
//	
//	Revision 1.4  2006/02/06 02:19:38  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.3  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __DRAWINGPROP_H__ */
