/* -------------------------------------------------------------------------
//	�ļ���		��	html_papx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:05:19
//	��������	��	
//
//	$Id: html_papx.h,v 1.14 2006/07/17 06:26:41 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_PAPX_H__
#define __HTML_PAPX_H__

#include "html_papxhelper.h"
#include "html_listlvl.h"

class HtmlWGlobalInfo;
class CssPropBuffer;
class HtmlWPapxWriter
{
public:
	HtmlWPapxWriter(HtmlWGlobalInfo* info, const KDWPropx* prop = NULL);
public:	
	STDMETHODIMP_(void) SetProp(const KDWPropx* prop);
	STDMETHODIMP_(void) SetProp(const BYTE* buff, INT cb, BOOL hasIstd = TRUE);
	STDMETHODIMP_(void) SetSprms(const KDWSprmList& sprms, UINT istd = stiNil);
public:	
	STDMETHODIMP_(void) Write(CssPropBuffer* cssprop);
	STDMETHODIMP_(void) ToCss(CssPropBuffer* cssprop, LPCSTR delim = DefalutDelim);
	STDMETHODIMP_(void) ToCss(const HtmlWParaPr* p, CssPropBuffer* cssprop, LPCSTR delim = DefalutDelim);
public:	
	STDMETHODIMP_(UINT) GetIstd();
	STDMETHODIMP_(HtmlWParaPr&) GetPap();	
private:
	KDWSprmList m_sprms;
	HtmlWGlobalInfo* m_ginfo;
	HtmlWListLevelWriter m_lvl;
	UINT m_istd;
	HtmlWParaPr prop;
	const HtmlWParaPr* baseon;
};	
#endif /* __HTML_PAPX_H__ */
