/* -------------------------------------------------------------------------
//	�ļ���		��	html_plcfchpx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:07:59
//	��������	��	
//
//	$Id: html_plcfchpx.h,v 1.7 2006/06/29 05:43:57 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_PLCFCHPX_H__
#define __HTML_PLCFCHPX_H__

#include "html_chpx.h"
#include "mso/io/css/cssbuffer.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class HtmlWGlobalInfo;
class HtmlWChpxsWriter
{
private:
	const KDWPlcfChpx* m_chpxs;
	HtmlWGlobalInfo* m_ginfo;

	KDWPlcfChpx::Enumerator m_enumer;
	
	HtmlWChpxWriter m_wrChpx;
	CssPropBuffer m_cssprop;

	INT m_istdpara, m_current;
	BOOL m_fOpend, m_fWriteSpanElem;	
public:
	// gets
	STDMETHODIMP_(HtmlWChpxWriter&) GetChpinfo();	
public:	
	HtmlWChpxsWriter(
		const KDWPlcfChpx* chpxs, HtmlWGlobalInfo* info);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) SetIstdPara(INT istdpara);
	STDMETHODIMP_(void) Write(UINT SpecText);
	STDMETHODIMP_(void) EnsureWriteEnd();
	STDMETHODIMP_(CssPropBuffer*) GetCurrentChpxCssprop();
};
#endif /* __HTML_PLCFCHPX_H__ */
