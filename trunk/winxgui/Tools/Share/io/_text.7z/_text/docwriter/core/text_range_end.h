/* -------------------------------------------------------------------------
//	�ļ���		��	text_range_end.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 21:08:36
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_RANGE_END_H__
#define __TEXT_RANGE_END_H__

// -------------------------------------------------------------------------
class KTextRangeEndHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	CP m_AdjustCpEnd;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget,
		IN CP AdjustCpEnd = 0)
	{
		m_pDocTarget = pDocTarget;
		m_AdjustCpEnd = AdjustCpEnd;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_RANGE_END_H__ */
