/* -------------------------------------------------------------------------
//	�ļ���		��	office_annotation.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 20:32:49
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_ANNOTATION_H__
#define __OFFICE_ANNOTATION_H__

#ifndef __TEXT_P_H__
#include "core/text_p.h"
#endif

#ifndef __COMMENTCONNECT_H__
// #include "commentconnect.h" new_annotation
#endif

// -------------------------------------------------------------------------
class KTextTableHandler;

class KOfficeAnnotationHandler : public KFakeUnknown<KElementHandler>
{
private:

	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;
	KTextTableHandler* m_tableElement;
	HANNOTATION m_curhAnn;
	
public:
	KOfficeAnnotationHandler();
	~KOfficeAnnotationHandler();
	

	STDMETHODIMP_(void) Init(KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
	
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP EndElement(IN ELEMENTID uElementID);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_ANNOTATION_H__ */
