/* -------------------------------------------------------------------------
//	�ļ���		��	listtable.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:07:41
//	��������	��	
//
//	$Id: listtable.cpp,v 1.8 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "list.h"
#include "drawing/drawingprop.h"
#include "listtable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) RtfWlistPictureWriter::WriteBulletAttribute(RtfDirectWriter* ar, const KDWBlip* pBlip)
{
	ar->AddAttribute(rtf_picscalex, 100);
	ar->AddAttribute(rtf_picscaley, 100);
	ar->AddAttribute(rtf_piccropl, 0);
	ar->AddAttribute(rtf_piccropr, 0);
	ar->AddAttribute(rtf_piccropt, 0);
	ar->AddAttribute(rtf_piccropb, 0);	
}
STDMETHODIMP_(void) RtfWlistPictureWriter::WriteBulletPicture(RtfDirectWriter* ar, const KDWBlip* pBlip)
{
	ar->StartGroup(rtf_shppict, rtf_nilParam, TRUE);
		ar->StartGroup(rtf_pict);
			ar->StartGroup(rtf_picprop, rtf_nilParam, TRUE);
				ar->AddAttribute(rtf_shplid, pBlip->__GetBlipId());
				WritePropSPI4(ar, "shapeType", 75);
				WritePropSPI4(ar, "fFlipH", 0);
				WritePropSPI4(ar, "fFlipV", 0);
				WritePropSPI4(ar, "pibFlags", 2);
				WritePropSPI4(ar, "fLine", 0);
				WritePropSPI4(ar, "fLayoutInCell", 1);
				WritePropSPI4(ar, "fIsBullet", 1);
			ar->EndGroup();
			WriteBulletAttribute(ar, pBlip);
			WriteBlipData(ar, pBlip);
		ar->EndGroup();
	ar->EndGroup();
}
RtfWlistPictureWriter::RtfWlistPictureWriter(const KDWPicBullets* bullets) : m_bullets(bullets)
{		
}	
STDMETHODIMP_(void) RtfWlistPictureWriter::Write(RtfDirectWriter* ar)
{
	if(!m_bullets)
		return;
	ar->StartGroup(rtf_listpicture, rtf_nilParam, TRUE);
	for(INT idx = 0; idx < m_bullets->size(); ++idx)
	{			
		 const KDWBlip* pBlip = m_bullets->GetBlip(idx);
		 if(pBlip)
			 WriteBulletPicture(ar, pBlip);
	}
	ar->EndGroup();
}

RtfWListTableWriter::RtfWListTableWriter()
{
	m_listPicWriter = NULL;
}
STDMETHODIMP_(void) RtfWListTableWriter::SetListPictureWriter(RtfWlistPictureWriter* listPicWriter)
{
	m_listPicWriter = listPicWriter;
}

STDMETHODIMP RtfWListTableWriter::Write(RtfDirectWriter* ar, RtfWGlobalInfo* info)
{	
	const KDWListTable* p = info->lists;
	if(p && p->GetListCount() > 0 && p->GetLfoTable()->Count() > 0)
	{
		RtfWListWriter wrList;
		ar->StartGroup(rtf_listtable, rtf_nilParam, TRUE);
		if(m_listPicWriter)
			m_listPicWriter->Write(ar);		
		for (INT i = 0; i < p->GetListTable()->Count(); ++i)
			wrList.WriteLst(ar, p->GetListTable()->Item(i).Data(), info);
		ar->EndGroup();

		ar->StartGroup(rtf_listoverridetable, rtf_nilParam, TRUE);
			for (INT j = 0; j < p->GetLfoTable()->Count(); ++j)
				wrList.WriteLfo(ar, p->GetLfoTable()->Item(j).Data(), info, j);
		ar->EndGroup();
		return S_OK;
	}
	return E_FAIL;
}
