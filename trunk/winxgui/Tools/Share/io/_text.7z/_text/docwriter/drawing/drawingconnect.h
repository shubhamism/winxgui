/* -------------------------------------------------------------------------
//	�ļ���		��	drawingconnect.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-21 18:04:06
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DRAWINGCONNECT_H__
#define __DRAWINGCONNECT_H__

#ifndef __MSO_HANDLER_ESCHER_H__
#include <mso/handler/escher.h>
#endif

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

__USING_MSO_ESCHER;

// -------------------------------------------------------------------------

class KDrawingConnection : public MsoDrawingGroupContext
{
	KDWDocTarget* m_pDocTarget;
	std::vector<_FConnectorRule> m_vecConnRules;
public:
	KDrawingConnection(
		IN KDWDocTarget* pDocTarget)
		: m_pDocTarget(pDocTarget)
	{
		MsoDrawingGroupContext::Init(pDocTarget->GetBlipStore());
	}
	~KDrawingConnection()
	{
		std::vector<_FConnectorRule>::iterator pRule = m_vecConnRules.begin();
		for ( ; pRule != m_vecConnRules.end(); ++pRule)
		{
			pRule->spidA = GetShapeIDFromXML(pRule->spidA);
			pRule->spidB = GetShapeIDFromXML(pRule->spidB);
			pRule->spidC = GetShapeIDFromXML(pRule->spidC);

			m_pDocTarget->GetCurrentDrawing().AddRule(*pRule);
		}
		m_vecConnRules.clear();
	}
	
	STDMETHODIMP AddRule(_FConnectorRule ConnRule)
	{
		m_vecConnRules.push_back(ConnRule);
		return S_OK;
	}

	int GetShapeIDFromXML(int idXML)
	{
		MsoShapeIdMap::const_iterator it = m_shapeIdMap.find(idXML);
		if (it != m_shapeIdMap.end())
			return (*it).second.__GetSpid();

		ASSERT(NULL);
		return idXML;
	}
};

// -------------------------------------------------------------------------

#endif /* __DRAWINGCONNECT_H__ */
