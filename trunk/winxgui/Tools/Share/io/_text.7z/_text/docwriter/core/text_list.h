/* -------------------------------------------------------------------------
//	�ļ���		��	text_list.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 9:45:00
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_LIST_H__
#define __TEXT_LIST_H__

#include "doctarget.h"
#include "text_level.h"

// -------------------------------------------------------------------------

class KTextListHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWV6Lists* m_pLists;
	KTextLevelHandler m_levelHandler;
	KDWList m_list;
	UINT m_iLst;
	UINT m_iLevel;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pLists = pDocTarget->GetListTableV6();
	}

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);

	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_LIST_H__ */
