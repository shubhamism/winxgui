/* -------------------------------------------------------------------------
//	�ļ���		��	office_bookmark.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 16:45:55
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_bookmark.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeBookmarkHandler::StartElement(
												  IN ELEMENTID uElementID,
												  IN KROAttributes* pAttrs
												  )
{
	BSTR bstrName = NULL;
	UINT uRangeID = 0;
	VERIFY_OK(
		pAttrs->GetByID(office_bookmark_name, &bstrName));
	
	VERIFY_OK(
		pAttrs->GetByID(office_text_range_ref, &uRangeID));

	if (bstrName == NULL)
		return E_INVALIDARG;

	m_pConnection->NewBookmark(bstrName, uRangeID);
	return S_OK;
}

// -------------------------------------------------------------------------
