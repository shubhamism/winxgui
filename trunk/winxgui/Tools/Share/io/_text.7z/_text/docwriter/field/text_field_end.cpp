/* -------------------------------------------------------------------------
//	�ļ���		��	text_field_end.cpp
//	������		��	����
//	����ʱ��	��	2004-8-23 15:41:36
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

#ifndef __TEXT_FIELD_END_H__
#include "text_field_end.h"
#endif

#ifndef __ATTRTRANS_H__
#include <core/attributes/attrtrans.h>
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextFieldEndHandler::StartElement(
	IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	ASSERT(uElementID == text_field_end);
	ASSERT(m_pDocTarget);

	KROAttributes* pAttrChpx = NULL;
	pAttrs->GetByID(kso::text_r_prop, &pAttrChpx);

	KDWPropBuffer* prop = m_pDocTarget->GetPropBuffer();
	TransSpanAttr(m_pDocTarget, (IKAttributes*)pAttrChpx, prop);

	m_pDocTarget->NewSpan(prop);
	return m_pDocTarget->MarkFieldEnd();
}


// -------------------------------------------------------------------------
