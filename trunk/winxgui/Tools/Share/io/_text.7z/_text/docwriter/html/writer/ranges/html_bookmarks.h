/* -------------------------------------------------------------------------
//	�ļ���		��	html_bookmarks.h
//	������		��	���὿
//	����ʱ��	��	2006-1-4 14:42:00
//	��������	��	
//
//	$Id: html_bookmarks.h,v 1.6 2006/06/29 05:43:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_BOOKMARKS_H__
#define __HTML_BOOKMARKS_H__

class HtmlDirectWriterA;
class HtmlWBookmarkStartsWriter
{
private:
	const KDWBookmarkStarts* m_data;
	KDWBookmarkStarts::Enumerator m_enumer;
	
public:
	HtmlWBookmarkStartsWriter(const KDWBookmarkStarts* data);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(HtmlDirectWriterA* ar);
};

class HtmlWBookmarkEndsWriter
{
private:
	const KDWBookmarkEnds* m_data;
	KDWBookmarkEnds::Enumerator m_enumer;
	
public:
	HtmlWBookmarkEndsWriter(const KDWBookmarkEnds* data);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(HtmlDirectWriterA* ar);
};
#endif /* __HTML_BOOKMARKS_H__ */
