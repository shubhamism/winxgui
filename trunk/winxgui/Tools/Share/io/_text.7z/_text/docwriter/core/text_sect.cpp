/* -------------------------------------------------------------------------
//	�ļ���		��	text_sect.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 20:30:24
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include "text_sect.h"
#include "attributes/attrtrans.h"
// #include <comment/commentconnect.h>  new_annotation

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextSectionHandler::StartElement(
						  IN ELEMENTID uElementID,
						  IN KROAttributes* pAttrs)
{
	HRESULT hr = E_FAIL;
	{
		KDWPropBuffer* pPropBuffer = m_pDocTarget->GetPropBuffer();
		hr = TransSectAttr(m_pDocTarget, pAttrs, pPropBuffer);
		KS_CHECK(hr);

		if (m_fFirstSecion)
		{
			m_fFirstSecion = FALSE;
			hr = TransSepx2Dop(m_pDocTarget, pAttrs);
			KS_CHECK(hr);
		}
	
		m_pDocTarget->NewSection(pPropBuffer);
//		m_pDocTarget->GetCommentConnection()->OnReachLowerBound();  new_annotation
	}

KS_EXIT:
	return hr;
}

STDMETHODIMP KTextSectionHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_header_even:
	case text_header_odd:
	case text_footer_even:
	case text_footer_odd:
	case text_header_first:
	case text_footer_first:
		{
			const HEADERFOOTER_TYPE typeCurrent = MapHeaderFooterType(uSubElementID);
			if (typeCurrent <= m_typeLastHeaderFooter)
			{
				REPORT_ONCE("ҳüҳ��δ�������֡�");
				return E_UNEXPECTED;
			}
			m_typeLastHeaderFooter = typeCurrent;

			m_HeaderFooterHandler.Init(m_pDocTarget);
			*ppHandler = &m_HeaderFooterHandler;
		}
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

STDMETHODIMP KTextSectionHandler::EndElement(IN ELEMENTID uElementID)
{
	return S_OK;
}

// -------------------------------------------------------------------------
