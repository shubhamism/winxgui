/* -------------------------------------------------------------------------
//	�ļ���		��	testdoc2rtf_annotaion.cpp
//	������		��	���὿
//	����ʱ��	��	2006-2-9 17:21:05
//	��������	��	
//
//	$Id: testdoc2rtf_annotaion.cpp,v 1.4 2006/04/18 05:42:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testdoc2rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// -------------------------------------------------------------------------
class testdoc2rtf_annotation : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(testdoc2rtf_annotation);
		CPPUNIT_TEST(testAnnotation);
	CPPUNIT_TEST_SUITE_END();
public:
	void setUp() {}
	void tearDown()
	{
	}
	
public:
	void testAnnotation()
	{
		testDoc2RtfFile("annotation/anns.doc", "annotation_anns.rtf");
		testDoc2RtfFile("annotation/annotation.doc", "annotation_annotation.rtf");
		testDoc2RtfFile("annotation/basic.doc", "annotation_basic.rtf");
	}
};
CPPUNIT_TEST_SUITE_REGISTRATION_DBG(testdoc2rtf_annotation);
// -------------------------------------------------------------------------
//	$Log: testdoc2rtf_annotaion.cpp,v $
//	Revision 1.4  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.3  2006/02/14 07:18:50  xulingjiao
//	�޸���ע��ص�BUG
//	
//	Revision 1.2  2006/02/13 01:33:05  xulingjiao
//	rtfwriter�Ѿ�֧����ע��
//	
//	Revision 1.1  2006/02/09 09:16:01  xulingjiao
//	*** empty log message ***
//	
