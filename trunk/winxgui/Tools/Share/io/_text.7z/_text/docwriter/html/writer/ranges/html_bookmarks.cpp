/* -------------------------------------------------------------------------
//	�ļ���		��	html_bookmarks.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-4 14:42:38
//	��������	��	
//
//	$Id: html_bookmarks.cpp,v 1.6 2006/06/29 05:43:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "html_bookmark.h"
#include "html_bookmarks.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HtmlWBookmarkStartsWriter::HtmlWBookmarkStartsWriter(const KDWBookmarkStarts* data) : m_data(data)
{
	Reset();
}
STDMETHODIMP_(BOOL) HtmlWBookmarkStartsWriter::Good() const
{
	return m_data != NULL && m_data->Count();
}
STDMETHODIMP_(void) HtmlWBookmarkStartsWriter::Reset()
{
	m_enumer = KDWBookmarkStarts::Enumerator(m_data);
	Next();
}
STDMETHODIMP HtmlWBookmarkStartsWriter::Next()
{
	return m_enumer.Next();
}
STDMETHODIMP_(UINT) HtmlWBookmarkStartsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.GetCurrentCp();
}
STDMETHODIMP_(UINT) HtmlWBookmarkStartsWriter::GetNextCp()
{
	return (UINT)m_enumer.GetNextCp();
}
STDMETHODIMP_(void) HtmlWBookmarkStartsWriter::Write(HtmlDirectWriterA* ar)
{
	HtmlWBookmarkWriter wrBookMark;
	wrBookMark.WriteBegin(ar, &m_enumer.Item());
}

HtmlWBookmarkEndsWriter::HtmlWBookmarkEndsWriter(const KDWBookmarkEnds* data) : m_data(data)
{		
	Reset();
}
STDMETHODIMP_(BOOL) HtmlWBookmarkEndsWriter::Good() const
{
	return m_data != NULL && m_data->Count();
}
STDMETHODIMP_(void) HtmlWBookmarkEndsWriter::Reset()
{
	m_enumer = KDWBookmarkEnds::Enumerator(m_data);
	Next();
}
STDMETHODIMP HtmlWBookmarkEndsWriter::Next()
{
	return m_enumer.Next();
}
STDMETHODIMP_(UINT) HtmlWBookmarkEndsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.GetCurrentCp();
}
STDMETHODIMP_(UINT) HtmlWBookmarkEndsWriter::GetNextCp()
{
	return (UINT)m_enumer.GetNextCp();
}
STDMETHODIMP_(void) HtmlWBookmarkEndsWriter::Write(HtmlDirectWriterA* ar)
{
	HtmlWBookmarkWriter wrBookMark;
	wrBookMark.WriteEnd(ar, &m_enumer.Item());
}
