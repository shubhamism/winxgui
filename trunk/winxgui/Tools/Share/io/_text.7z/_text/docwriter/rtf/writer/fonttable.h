/* -------------------------------------------------------------------------
//	�ļ���		��	fonttable.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:59:13
//	��������	��	
//
//	$Id: fonttable.h,v 1.2 2006/01/20 08:42:59 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __FONTTABLE_H__
#define __FONTTABLE_H__

/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfDirectWriter;
class RtfWFontTableWriter
{
private:
	// todo: ʹ��Item()��ȡ����
	struct _Target : public KDWFontTable
	{
		static const _Target* Cast(const KDWFontTable* p)
		{
			return static_cast<const _Target*>(p);
		}

		typedef DW_FontFamilyName _Array;
		const _Array* GetArray() const
		{
			return &m_aryFontFamily;
		}
	};

public:
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const KDWFontTable* p);
};
// -------------------------------------------------------------------------
//	$Log: fonttable.h,v $
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __FONTTABLE_H__ */
