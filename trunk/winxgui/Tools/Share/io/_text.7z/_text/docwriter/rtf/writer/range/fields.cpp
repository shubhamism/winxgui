/* -------------------------------------------------------------------------
//	�ļ���		��	fields.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:15:50
//	��������	��	
//
//	$Id: fields.cpp,v 1.8 2006/08/07 01:51:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "../textstream.h"
#include "field.h"
#include "fields.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

FieldWriter* RtfWFieldWriterFactory::GetFieldWriter(KDWField* fld, INT flt)
{
	if(fld)	
		return new RtfWFieldWriter(fld);	
	return NULL;
}

RtfWFieldsWriter::RtfWFieldsWriter(const KDWFields* data) :
	m_data(data),
	m_enumer(data),
	m_wrTextStream(NULL)
{
}

RtfWFieldsWriter::~RtfWFieldsWriter()
{
	while(!m_wrFields.empty())
	{
		FieldWriter* wrField = GetField();
		m_wrFields.pop();
		delete wrField;
	}
}

STDMETHODIMP_(BOOL) RtfWFieldsWriter::Good() const
{
	return m_data != NULL && m_data->Count();
}
STDMETHODIMP_(void) RtfWFieldsWriter::SetStreamWriter(RtfWTextStreamWriter* wrTextStream)
{
	ASSERT(wrTextStream);
	m_wrTextStream = wrTextStream;
}
STDMETHODIMP_(void) RtfWFieldsWriter::Reset()
{
	m_enumer = KDWFields::Enumerator(m_data);
	Next();
}
STDMETHODIMP RtfWFieldsWriter::Next()
{
	if (!m_data)
		return E_FAIL;
	return m_enumer.Next();
}
STDMETHODIMP_(UINT) RtfWFieldsWriter::GetCurrentCp()
{
	if (!m_data)
		return (UINT)-1;
	return m_enumer.GetCp();
}
STDMETHODIMP_(UINT) RtfWFieldsWriter::GetNextCp()
{
	if (!m_data)
		return (UINT)-1;
	return m_enumer.GetNextCp();
}

STDMETHODIMP_(FieldWriter*) RtfWFieldsWriter::GetField() const
{
	if(m_wrFields.empty())
		return NULL;
	return m_wrFields.top();
}

STDMETHODIMP_(void) RtfWFieldsWriter::Write(RtfDirectWriter* ar)
{
	if (!m_data)
		return;	
	m_fld = m_enumer.Item();
	FieldWriter* wrField = NULL;	
	switch (m_fld.GetMarkType())
	{
	case mso_fldBeginMark:
		wrField = m_factory.GetFieldWriter(&m_fld, m_fld.GetFieldType());
		if(wrField)
		{			
			wrField->WriteBegin(ar);
			m_wrFields.push(wrField);
		}
		break;
	case mso_fldSeparatorMark:
		wrField = GetField();
		if(wrField)		
			wrField->WriteSep(ar);		
		break;
	case mso_fldEndMark:
		wrField = GetField();
		if(wrField)
		{			
			wrField->WriteEnd(ar);
			m_wrFields.pop();
			delete wrField;
			wrField = NULL;
		}
		break;
	default:
		ASSERT(0);
	};
}