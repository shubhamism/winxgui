/* -------------------------------------------------------------------------
//	�ļ���		��	text_cell.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-23 15:24:39
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_CELL_H__
#define __TEXT_CELL_H__

#ifndef __TEXT_P_H__
#include <core/text_p.h>
#endif

// -------------------------------------------------------------------------
class KTextDiagHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		m_pDocTarget->rowtbl_NewDiagonal();
		return S_OK; 
	}
};

// -------------------------------------------------------------------------
class KTextTableHandler;
class KTextCellHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;
	KTextTableHandler* m_textTableElement;
	KTextDiagHandler m_textDiagElement;
	
public:
	KTextCellHandler() : m_textTableElement(NULL) {}
	~KTextCellHandler();

	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
		
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_CELL_H__ */
