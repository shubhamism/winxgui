/* -------------------------------------------------------------------------
//	�ļ���		��	tab.cpp
//	������		��	����
//	����ʱ��	��	2004-12-22 10:16:11
//	��������	��	
//	$Id: tabstop.cpp,v 1.4 2005/02/24 04:28:39 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#include <kso/io/schema_text.h>
#include <core/attributes/attrtrans.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
inline
static STDMETHODIMP_(INT) MapLeadChar(IN LPCWSTR str)
{
	static LPCWSTR const LeadCharMap[] =
	{ 
		kso_text::szLeaderNone,
		kso_text::szLeaderDotted,
		kso_text::szLeaderHyphenated,
		kso_text::szLeaderSingleLine,
		kso_text::szLeaderHeavyLine,
		kso_text::szLeaderMiddleDot,
	};
	if (str == 0 || wcslen(str) == 0)
		return 0;
	for (int i = 0; i < countof(LeadCharMap); ++i)
	{
		if (wcscmp(LeadCharMap[i], str) == 0)
			return i;
	}
	ASSERT_ONCE(0);
	return 0;
}

// -------------------------------------------------------------------------
STDMETHODIMP_(VOID) MakeChgTAB(
	IN KROAttributes* pAttr, IN KDWChgTAB* pChgTAB)
{
	KROAttributes* pAttrTAB = NULL;
	pAttr->GetByID(kso::text_tabs, &pAttrTAB);
	if (!pAttrTAB)
	{
		INT iListTAB;
		if (SUCCEEDED(pAttr->GetByID(kso::text_list_tab, &iListTAB)))
		{
			TBD tbd;
			ZeroStruct(tbd);
			tbd.jc = 6;
			pChgTAB->Append(iListTAB, tbd);
		}
		return;
	}

	pChgTAB->put_ForceEmpty();
	UINT cSubAttr = pAttrTAB->Count();
	for (UINT i = 0; i < cSubAttr; ++i)
	{
		ATTRID AttrId = 0;
		ATTRVALUE_PTR pAttrVal = NULL;
		VERIFY_OK(pAttrTAB->GetAt(i, &AttrId, &pAttrVal));
		if (AttrId == kso::text_tab)
		{
			KROAttributes* pAttrTab = (KROAttributes*)pAttrVal->punkVal;
			if (pAttrTab)
			{
				TBD tbd;
				ZeroStruct(tbd);
			
				BSTR bstr = NULL;
				pAttrTab->GetByID(kso::text_tab_leader, &bstr);
				tbd.tlc = MapLeadChar(bstr);

				UINT jc = kso_text::ttLeft;
				pAttrTab->GetByID(kso::text_tab_type, &jc);
				tbd.jc = jc;

				INT dxa = 0;
				VERIFY_OK(pAttrTab->GetByID(
					kso::text_tab_position, &dxa));

				pChgTAB->Append(dxa, tbd);
			}
		}
	}
}

// -------------------------------------------------------------------------
enum {
	__lenOp		= sizeof(UINT16),
	offsetIstd	= sizeof(UINT16),
	offsetLvl	= offsetIstd + __lenOp + 1 /* = _DW_GetOpLen(sprmPIlvl) */,
	offsetLfo	= offsetLvl  + __lenOp + 2 /* = _DW_GetOpLen(sprmPIlfo) */,
};

// У��sprmPIlvl��sprmPIlfo�Ƿ������istd���沢������������
#define __DW_ASSERT_VALID_LST(data)											\
	ASSERT( *(UINT16*)((UINT8*)(data) + offsetIstd) == sprmPIlvl &&			\
			*(UINT16*)((UINT8*)(data) + offsetLvl ) == sprmPIlfo )

// -------------------------------------------------------------------------
STDMETHODIMP_(VOID) TransTAB(
	IN KDWDocTarget* pTarget,
	IN INT xmlIdBase,
	IN INT xmlIdLst, IN INT xmlIdLvl,
	IN KCDWChgTAB* pChgTAB,
	IN KDWPropBuffer* pPropBuf)
{
	ASSERT(pChgTAB);
	KDWAutoFreeAlloc* pAlloc = pTarget->GetAllocater();
	{
		KCDWChgTAB& StyChgTAB = pTarget->GetTABMap().LookupStyleTAB(xmlIdBase);
		KCDWChgTAB& LstChgTAB = pTarget->GetTABMap().LookupLstTAB(xmlIdLst, xmlIdLvl);
		if (!pChgTAB->get_Null())
		{
			// ɾ����ʽ���Զ�����е��Ʊ�λ
			if (LstChgTAB.Size())
			{
				//@@note:
				//  ���Ǽ���: ��sprmPIlvl��sprmPIlfo�����֣�
				//  �����ǳ���ʱ������������papx��ʼ����������istd֮��
				//  ��˳����ϣ���sprmPIlvl��sprmPIlfo
				//  �˼�����TransLfo����֤��
				//  �������Ǳ���ģ���ϸ˵����ο�docwriter.xls��
				//
				__DW_ASSERT_VALID_LST(pPropBuf->Data());
				KDWPropBuffer prop;
				__DW_AddChgTabPapx(&prop, LstChgTAB.AllocDataDel(pAlloc));
				__DW_AddPropAt(offsetLfo, pPropBuf, &prop);
			}
			if (StyChgTAB.Size())
			{
				KDWPropBuffer prop;
				__DW_AddChgTabPapx(&prop, StyChgTAB.AllocDataDel(pAlloc));
				__DW_AddPropAt(offsetIstd, pPropBuf, &prop);
			}
			// ���������Ʊ�λ
			if (pChgTAB->Size())
				__DW_AddChgTabPapx(pPropBuf, pChgTAB->AllocDataAdd(pAlloc));
		}
		else if (LstChgTAB.Size() && StyChgTAB.Size())
		{
			// ���������Ʊ�λ������ʽ���Զ����ͬʱ���Ʊ�λ��
			// �򷴵���ʽ���Ʊ�λ��
			KDWPropBuffer prop;
			__DW_AddChgTabPapx(&prop, StyChgTAB.AllocDataDel(pAlloc));
			__DW_AddPropAt(offsetIstd, pPropBuf, &prop);
		}
	}
}

STDMETHODIMP_(VOID) TransTAB(
	IN KDWDocTarget* pTarget, 
	IN KROAttributes* pAttr,
	IN KDWPropBuffer* pPropBuf)
{
	ASSERT(pAttr);

	INT iXmlBase = -1;
	pAttr->GetByID(kso::text_p_styleref, &iXmlBase);

	INT iXmlLst = -1;
	INT iXmlLvl = 8;
	KROAttributes* pAttrLst;
	if (SUCCEEDED(pAttr->GetByID(kso::text_list_info, &pAttrLst)))
	{
		pAttrLst->GetByID(kso::text_list_id, &iXmlLst);
		pAttrLst->GetByID(kso::text_list_level, &iXmlLvl);
	}
	
	KDWChgTAB ChgTAB;
	MakeChgTAB(pAttr, &ChgTAB);
	TransTAB(pTarget, iXmlBase, iXmlLst, iXmlLvl, &ChgTAB, pPropBuf);
}

// -------------------------------------------------------------------------
// $Log: tabstop.cpp,v $
// Revision 1.4  2005/02/24 04:28:39  wangdong
// �����Ʊ�λ��д��˳��
//
