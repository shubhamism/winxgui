/* -------------------------------------------------------------------------
//	�ļ���		��	drawing.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:44:28
//	��������	��	
//
//	$Id: drawing.h,v 1.4 2006/04/13 00:52:30 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAWING_H__
#define __DRAWING_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWTextStreamWriter;
class RtfDirectWriter;
class RtfWDrawingWriter
{
private:	
	const _KDWSubdocDrawing* m_drawing;
	const MsoBlipStore* m_blipstore;
	RtfWTextStreamWriter* m_wrTextbox;	
	SUBDOC_TYPE m_subdoc;

public:
	RtfWDrawingWriter(const _KDWDrawings* p, SUBDOC_TYPE subdoc, const MsoBlipStore* blipstore);
	STDMETHODIMP_(void) SetTxtboxStreamWriter(RtfWTextStreamWriter* wrTextStream);	
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, INT cp);
	STDMETHODIMP WriteBackground(RtfDirectWriter* ar);	
	void WriteShape(RtfDirectWriter* ar, _KDWShape* p);
private:	
	void WriteShprslt(RtfDirectWriter* ar, const _KDWShape* p);	
	void WriteSPTextBoxLink(RtfDirectWriter* ar, _KDWShape* p);
	void WriteShapeText(RtfDirectWriter* ar, const MsoKernData* data, SUBDOC_TYPE subdoc);
};
// -------------------------------------------------------------------------
//	$Log: drawing.h,v $
//	Revision 1.4  2006/04/13 00:52:30  xulingjiao
//	�޸�ͼƬ��ʾ��������BUG
//	
//	Revision 1.3  2006/04/12 01:46:10  xulingjiao
//	textbox
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __DRAWING_H__ */
