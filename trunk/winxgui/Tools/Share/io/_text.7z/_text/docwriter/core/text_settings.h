/* -------------------------------------------------------------------------
//	�ļ���		��	text_settings.h
//	������		��	����
//	����ʱ��	��	2004-8-23 19:38:09
//	��������	��	
//	$Id: text_settings.h,v 1.3 2006/02/27 03:02:22 rongjianxing Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_SETTINGS_H__
#define __TEXT_SETTINGS_H__


// -------------------------------------------------------------------------
class KTextSettingsHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KDWMailMerge* m_pMailMerge;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
		m_pMailMerge = pDocTarget->GetMailMerge();
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);

private:
	//�ʼ��ϲ�
	STDMETHODIMP AddMailMergeAttrs(IN KROAttributes* pMailMergeAttrs) const;
	STDMETHODIMP AddOdsoAttrs(IN KROAttributes* pOdsoAttrs) const;
	STDMETHODIMP AddFieldMapDatasAttrs(IN KROAttributes* pFieldMapDatasAttrs) const;
};

// -------------------------------------------------------------------------

#endif /* __TEXT_SETTINGS_H__ */
