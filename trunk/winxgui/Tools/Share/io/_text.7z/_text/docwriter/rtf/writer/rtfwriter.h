/* -------------------------------------------------------------------------
//	�ļ���		��	rtfwriter.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:36:42
//	��������	��	
//
//	$Id: rtfwriter.h,v 1.8 2006/08/11 08:14:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFWRITER_H__
#define __RTFWRITER_H__
#include "rtf/writer/include/rtffile.h"
#include "document.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class KRtfWriter :
	public KElementDispatcher,
	public IKFilterMediaInit,
	public KComObjectRoot
{
private:
	KOfficeDocHandler m_docHandler;
	KDWDocTarget m_Target;
	DWFileType m_FileType;

	RtfDirectWriter m_ar;
	
public:
	STDMETHODIMP Init(LPCWSTR szFileName)
	{
		return m_ar.Open(szFileName);
	}
	STDMETHODIMP StartDocument(IN UINT nReservedParam)
	{		
		ks_stdptr<IStorage> pDestStg;
		HRESULT hr;
		DWORD crmode = 0|STGM_READ|STGM_WRITE|STGM_CREATE|STGM_SHARE_EXCLUSIVE;
		hr = StgCreateDocfile(NULL, crmode, 0, &pDestStg);
		if (FAILED(hr))
			return hr;

		_kso_InitIoSchemaDbgInfo();

		m_docHandler.Init(&m_Target);
		KElementDispatcher::Init(office_document, &m_docHandler);
		return m_Target.NewDocument(pDestStg, NULL, m_FileType);
	}

    STDMETHODIMP EndDocument(
		IN BOOL fAbort)
	{
		if (!fAbort)
		{
			RtfWDocumentWriter wrDocument(&m_Target);
			wrDocument.Write(&m_ar);
		}
		m_Target.Close(TRUE);
		m_ar.Close();
		return S_OK;
	}

	STDMETHODIMP Init(IN DWFileType FileType = dwFileDefault)
	{
		m_FileType = FileType;
		return S_OK;
	}
	STDMETHODIMP Init(IN LPCFILTERMEDIUM pMedium)
	{
		switch (pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			return m_ar.Open(pMedium->lpszFileName);
		case FILTER_TYMED_ISTREAM:
			return m_ar.Open(pMedium->pstm);
		}
		return E_NOTIMPL;
	}
	
	BEGIN_QUERYINTERFACE(IKContentHandler)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_COUNT(KRtfWriter)
};
#endif /* __RTFWRITER_H__ */
