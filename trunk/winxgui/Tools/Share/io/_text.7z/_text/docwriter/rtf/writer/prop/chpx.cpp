/* -------------------------------------------------------------------------
//	�ļ���		��	chpx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:59:24
//	��������	��	
//
//	$Id: chpx.cpp,v 1.18 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "../styleshelper.h"
#include "../globalinfo.h"
#include "../colortable.h"
#include "chpxhelper.h"
#include "../colortable.h"
#include "chpx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SetPlainProp(mem, val)\
{\
	if(!mask.mem)\
	{\
		_MemSetInt(mask.mem);\
		prop->mem = val;\
	}\
}

void AddPlain(RtfWSpanPr* prop)
{
	RtfWSpanPr::MaskType& mask = prop->mask;
	SetPlainProp(hps, 20);
}

STDMETHODIMP_(RtfWSpanPr&) RtfWChpxWriter::GetChp()
{
	return prop;
}
STDMETHODIMP_(CHARSETINFO) RtfWChpxWriter::GetCharsetInfo()
{
	CHARSETINFO charsetinfo;
	if(!TranslateCharsetInfo((DWORD*)m_font.charset, &charsetinfo, TCI_SRCCHARSET))	
		return GetSysCharsetInfo();
	return charsetinfo;
}

STDMETHODIMP_(CHARSETINFO) RtfWChpxWriter::GetSysCharsetInfo()
{
	CHARSETINFO charsetinfo;
	DWORD acp = GetACP();
	TranslateCharsetInfo((DWORD*)acp, &charsetinfo, TCI_SRCCODEPAGE);
	return charsetinfo;
}

STDMETHODIMP_(CHARSETINFO) RtfWChpxWriter::GetCharsetInfo(INT iFont)
{
	KDWFont font;
	m_ginfo->fonttbl->GetFont(font, iFont);
	CHARSETINFO charsetinfo;
	if(!TranslateCharsetInfo((DWORD*)font.charset, &charsetinfo, TCI_SRCCHARSET))	
		return GetSysCharsetInfo();
	return charsetinfo;
}

STDMETHODIMP_(const KDWPropx*) RtfWChpxWriter::GetPicLocation() const
{
	if(m_piclocation)
		return m_piclocation;
	return m_chpx;
}

RtfWChpxWriter::RtfWChpxWriter(const KDWSprmList& sprms, RtfWGlobalInfo* info, INT istdpara)
	: m_sprms(sprms), m_ginfo(info)
{	
	m_font.charset = GetSysCharsetInfo().ciCharset;
	m_chpx = m_piclocation = NULL;
	m_istdpara = istdpara;
	m_istd = m_sprms.GetCharIstd();	
}

RtfWChpxWriter::RtfWChpxWriter(RtfWGlobalInfo* info)
	: m_ginfo(info)
{
	m_font.charset = GetSysCharsetInfo().ciCharset;
	m_chpx = m_piclocation = NULL;
	m_istdpara = stiNil;
	m_istd = m_sprms.GetCharIstd();	
}
STDMETHODIMP_(void) RtfWChpxWriter::SetProp(const KDWPropx* prop, INT istdpara)
{
	m_piclocation = m_chpx;
	m_chpx = prop;
	if(prop)
	{
		m_sprms = KDWSprmList((const BYTE*)_MsoPdata(prop), prop->cb);
		m_istd = m_sprms.GetCharIstd();
	}
	m_istdpara = istdpara;
	
}
STDMETHODIMP_(void) RtfWChpxWriter::SetProp(const KDWSprmList& sprms, INT istdpara)
{
	m_chpx = m_piclocation = NULL;
	m_sprms = sprms;
	m_istdpara = istdpara;
	m_istd = m_sprms.GetCharIstd();	
}
STDMETHODIMP_(void) RtfWChpxWriter::SetIstdPara(INT istdPara)
{
	m_istdpara = istdPara;
}

STDMETHODIMP_(void) RtfWChpxWriter::Write(RtfDirectWriter* ar, const RtfWSpanPr* prop, BOOL fOnlyAf)
{		
	WriteMerged(m_ginfo, ar, prop, prop, fOnlyAf);
}

STDMETHODIMP_(void) RtfWChpxWriter::Write(RtfDirectWriter* ar)
{		
	RtfWSpanPr spanpr;	
	m_ginfo->styles->GetMergedChpx(spanpr, m_istd, m_istdpara);	
	Write(ar, &spanpr, &spanpr);
}

STDMETHODIMP_(void) RtfWChpxWriter::Write(RtfDirectWriter* ar, const RtfWSpanPr* mergewith, const RtfWSpanPr* baseon)
{	
	prop.Reset();
	if (mergewith != NULL)
		prop = *mergewith;
	if (baseon == NULL)
		baseon = GetDefaultChpx();	
	prop.Sprms2SpanPr(m_sprms, baseon);
	WriteMerged(m_ginfo, ar, &prop, baseon);
}

void RtfWChpxWriter::WriteMerged(RtfWGlobalInfo* ginfo, RtfDirectWriter* ar, const RtfWSpanPr* p, const RtfWSpanPr* baseon, BOOL fOnlyAf)
{
	const RtfWSpanPr::MaskType* d = &p->mask;

	_AddAttributeMask(d->istd, ar, rtf_cs, p->istd);		
	_AddBoolAttributeMask(d->fBold, ar, rtf_b, p->fBold);
	_AddBoolAttributeMask(d->fItalic, ar, rtf_i, p->fItalic);
	_AddAttributeMask(d->hps, ar, rtf_fs, p->hps);
	_AddAttributeMask(d->hpsKern, ar, rtf_kerning, p->hpsKern);
	
	if(!p->fSpec)
		WriteFontCtrl(p, baseon, ar, fOnlyAf);
	else
		WriteFontCtrl(p, baseon, ar, TRUE);

	_AddAttributeMask(d->wCharScale, ar, rtf_charscalex, p->wCharScale);
	_AddAttributeMask(d->dxaSpace, ar, rtf_expnd, p->dxaSpace);
	_AddAttributeMask(d->dxaSpace, ar, rtf_expndtw, p->dxaSpace);
	WriteHpsPosCtrl(p->hpsPos, d->hpsPos, ar);
	_AddBoolAttributeMask(d->fcgrid, ar, rtf_cgrid, p->fcgrid);
	WriteBrcCtrl(p->brc, d->brc, ar, ginfo->colors, rtf_chbrdr);
	WriteChShdCtrl(p->shd, d->shd, ginfo->colors, ar);		
	_AddAttributeMask(d->sfxtText, ar, rtf_animtext, p->sfxtText);

	WriteLangCtrl(p, ar);
	_AddAttributeMask(d->crTextColor, ar, rtf_cf, ginfo->colors->GetColorIndex(p->crTextColor));

	// �»���
	_AddAttributeMask(d->kul, ar, GetUlCtrl(p->kul), p->kul);
	_AddAttributeMask(d->crKulColor, ar, rtf_ulc, ginfo->colors->GetColorIndex(p->crKulColor));

	// Ч��
	_AddBoolAttributeMask(d->fStrike, ar, rtf_strike, p->fStrike);
	_AddBoolAttributeMask(d->fDStrike, ar, rtf_striked, p->fDStrike);
	_AddBoolAttributeMask(d->iss, ar, GetIssCtrl(p->iss), p->iss);
	_AddBoolAttributeMask(d->fShadow, ar, rtf_shad, p->fShadow);
	_AddBoolAttributeMask(d->fOutline, ar, rtf_outl, p->fOutline);
	_AddBoolAttributeMask(d->fEmboss, ar, rtf_embo, p->fEmboss);
	_AddBoolAttributeMask(d->fImprint, ar, rtf_impr, p->fImprint);
	_AddBoolAttributeMask(d->fSmallCaps, ar, rtf_scaps, p->fSmallCaps);
	_AddBoolAttributeMask(d->fCaps, ar, rtf_caps, p->fCaps);
	_AddBoolAttributeMask(d->fVanish, ar, rtf_v, p->fVanish);

	// ���غ�	
	_AddAttributeMask(d->kcd, ar, GetKcdCtrl(p->kcd), p->kcd);

	// ����		
	_AddAttributeMask(d->icoHighlight, ar, rtf_highlight, ginfo->colors->GetColorIndex(Ico2RGB(p->icoHighlight)));		
	WriteSymbol(p, ar, ginfo->fonttbl);
	// �����޶���ص�
	_AddAttributeMask(d->fRMark, ar, rtf_revised, p->fRMark);
	_AddAttributeMask(d->ibstRMark, ar, rtf_revauth, p->ibstRMark);		
	_AddAttributeMask(d->dttmRMark, ar, rtf_revdttm, (INT32&)p->dttmRMark);
	// ɾ���޶���ص�
	_AddAttributeMask(d->fRMarkDel, ar, rtf_deleted, p->fRMarkDel);
	_AddAttributeMask(d->ibstRMarkDel, ar, rtf_revauthdel, p->ibstRMarkDel);
	_AddAttributeNotdefvalMask(d->dttmRMarkDel, (INT32&)p->dttmRMarkDel, 0, ar, rtf_revdttmdel, (INT32&)p->dttmRMarkDel);
}

void RtfWChpxWriter::WriteChShdCtrl(const KDWShd& shd, UINT8 refShd, RtfWColorTable* colors, RtfDirectWriter* ar)
{
	if(refShd)
		WriteCharShdCtrl(shd, colors, ar);
}

void RtfWChpxWriter::WriteBrcCtrl(const KDWBrc& brc, UINT8 refBrc, RtfDirectWriter* ar,
	RtfWColorTable* colors, RtfControl whichBrc)
{
	if(refBrc)
		::WriteBrcCtrl(brc, ar, colors, whichBrc);
}

void RtfWChpxWriter::WriteHpsPosCtrl(INT16 hpsPos, INT16 refHpsPos, RtfDirectWriter* ar)
{
	if(hpsPos > 0)
	{
		_AddAttributeMask(refHpsPos, ar, rtf_up, abs(hpsPos));
	}
	else if(hpsPos < 0)
	{
		_AddAttributeMask(refHpsPos, ar, rtf_dn, abs(hpsPos));
	}
}

void RtfWChpxWriter::WriteFareastFont(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf)
{	
	// ���ӹ�����������
	ar->AddAttribute(rtf_loch);
	if(p->mask.rgftc[0])
		ar->AddAttribute(rtf_af, p->rgftc[0]);		
	else
		ar->AddAttribute(rtf_af, baseon->rgftc[0]);

	ar->AddAttribute(rtf_hich);
	if(p->mask.rgftc[2])
		ar->AddAttribute(rtf_af, p->rgftc[2]);
	else
		ar->AddAttribute(rtf_af, baseon->rgftc[2]);

	// ������������
	ar->AddAttribute(rtf_dbch);
	if(p->mask.rgftc[1])
	{
		if(!fOnlyAf)
		{
			m_ginfo->fonttbl->GetFont(m_font, p->rgftc[1]);
			ar->AddAttribute(rtf_f, p->rgftc[1]);
		}
		else
		{
			ar->AddAttribute(rtf_af, p->rgftc[1]);
		}
	}
	else
	{
		if(!fOnlyAf)
		{		
			m_ginfo->fonttbl->GetFont(m_font, baseon->rgftc[1]);
			ar->AddAttribute(rtf_f, baseon->rgftc[1]);
		}
		else
		{
			ar->AddAttribute(rtf_af, baseon->rgftc[1]);
		}
	}
}	

void RtfWChpxWriter::WriteAsciiFont(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf)
{
	// ���ӹ�����������
	ar->AddAttribute(rtf_dbch);
	if(p->mask.rgftc[1])
		ar->AddAttribute(rtf_af, p->rgftc[1]);
	else
		ar->AddAttribute(rtf_af, baseon->rgftc[1]);

	ar->AddAttribute(rtf_hich);
	if(p->mask.rgftc[2])
		ar->AddAttribute(rtf_af, p->rgftc[2]);
	else
		ar->AddAttribute(rtf_af, baseon->rgftc[2]);
	
	// ������������
	ar->AddAttribute(rtf_loch);
	if(p->mask.rgftc[0])
	{
		if(!fOnlyAf)
		{
			m_ginfo->fonttbl->GetFont(m_font, p->rgftc[0]);
			ar->AddAttribute(rtf_f, p->rgftc[0]);
		}
		else
		{
			ar->AddAttribute(rtf_af, p->rgftc[0]);
		}
	}
	else
	{
		if(!fOnlyAf)
		{
			m_ginfo->fonttbl->GetFont(m_font, baseon->rgftc[0]);
			ar->AddAttribute(rtf_f, baseon->rgftc[0]);
		}
		else
		{
			ar->AddAttribute(rtf_af, baseon->rgftc[0]);
		}
	}
}

void RtfWChpxWriter::WriteOtherFont(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf)
{
	// ���ӹ�����������
	ar->AddAttribute(rtf_dbch);
	if(p->mask.rgftc[1])
		ar->AddAttribute(rtf_af, p->rgftc[1]);
	else
		ar->AddAttribute(rtf_af, baseon->rgftc[1]);		
	
	ar->AddAttribute(rtf_loch);
	if(p->mask.rgftc[0])
		ar->AddAttribute(rtf_af, p->rgftc[0]);
	else
		ar->AddAttribute(rtf_af, baseon->rgftc[0]);

	// ������������
	ar->AddAttribute(rtf_hich);
	if(p->mask.rgftc[2])
	{
		if(!fOnlyAf)
		{
			m_ginfo->fonttbl->GetFont(m_font, p->rgftc[2]);
			ar->AddAttribute(rtf_f, p->rgftc[2]);
		}
		else
		{
			ar->AddAttribute(rtf_af, p->rgftc[2]);
		}
	}
	else
	{
		if(!fOnlyAf)
		{		
			m_ginfo->fonttbl->GetFont(m_font, baseon->rgftc[2]);
			ar->AddAttribute(rtf_f, baseon->rgftc[2]);
		}
		else
		{
			ar->AddAttribute(rtf_af, baseon->rgftc[2]);
		}
	}
}

void RtfWChpxWriter::WriteFontCtrl(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf)
{
	UINT8 idctHintMask = p->mask.idctHint;
	UINT8 idctHint = p->idctHint;	

	if(idctHintMask)
	{
		if(idctHint != 0)
		{
			WriteFareastFont(p, baseon, ar, fOnlyAf);
			prop.iftc = mso_ftcFastEast;
		}
		else
		{
			WriteAsciiFont(p, baseon, ar, fOnlyAf);
			prop.iftc = mso_ftcAscii;
		}
	}
	else
	{
		if(prop.idctHint)
		{
			WriteFareastFont(p, baseon, ar, fOnlyAf);
			prop.iftc = mso_ftcFastEast;
		}
		else
		{
			WriteAsciiFont(p, baseon, ar, fOnlyAf);
			prop.iftc = mso_ftcAscii;
		}
	}	
	prop.idctHint = 0;	
}

void RtfWChpxWriter::WriteLangCtrl(const RtfWSpanPr* p, RtfDirectWriter* ar)
{
	/*
	const RtfWSpanPr::MaskType* d = &p->mask;
	UINT16 dlid, plid;		
	dlid = d->rglid[0];
	plid = p->rglid[0];
	_AddAttributeMask(dlid, ar, rtf_lang, plid);
	
	dlid = d->rglid[1];
	plid = p->rglid[1];
	_AddAttributeMask(dlid, ar, rtf_langfe, plid);
	*/
}

void RtfWChpxWriter::WriteSymbol(const RtfWSpanPr* p, RtfDirectWriter* ar, const KDWFontTable* fonttbl)
{
	if(p->mask.symbol)
	{
		ar->StartGroup(rtf_field);
			ar->StartGroup(rtf_fldinst, rtf_nilParam, TRUE);
				WCHAR buf[40];
				KDWFont font;
				HRESULT hr;
				hr = fonttbl->GetFont(font, p->symbol.oprand.ftcSym);
				if(SUCCEEDED(hr))
				{						
					UINT8 ch = p->symbol.oprand.xchSym;
					swprintf(buf, __X("SYMBOL %d \\f \"%s\" \\s %d\0"),	ch, font.name, p->hps/2);
					ar->AddContentWcs(buf, wcslen(buf));						
				}
			ar->EndGroup();
			ar->StartGroup(rtf_fldrslt);
			ar->AddAttribute(rtf_f, p->symbol.oprand.ftcSym);
			ar->AddAttribute(rtf_fs, p->hps);
			ar->EndGroup();				
		ar->EndGroup();		
	}
}
