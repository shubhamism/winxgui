/* -------------------------------------------------------------------------
//	�ļ���		��	text_level.cpp
//	������		��	����
//	����ʱ��	��	2004-8-18 15:15:07
//	��������	��	
//
//	$Id: text_level.cpp,v 1.14 2006/10/25 07:17:00 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attributes/attrtrans.h"
#include "text_level.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
inline
STDMETHODIMP _MakeChpx(
					   IN KDWDocTarget* pDocTarget,
					   IN KROAttributes* pAttrs,
					   IN KDWPropBuffer* pPropBuf)
{
	HRESULT hr = E_FAIL;
	ATTRVALUE_PTR pAttrVal(NULL);
	if (pAttrs->GetIndex(kso::text_r_prop, &pAttrVal) >= 0)
	{
#if (1)
		hr = TransSpanAttr(pDocTarget,
			(IKAttributes*)pAttrVal->punkVal, pPropBuf);
#else
		/** bug# 15454
		������
			��word�򿪲���wps����ļ���������������Ŀ���š�
		������
			����ΪsprmCIdctHintд������ȷӦ����0��wps����Ϊ1��
		˵����
			��β��Դ��������Բ��԰���CaseBullet3д��Ӳ���롣
		*/
		pPropBuf->AddPropFix(sprmCRgFtc0, 4);
		pPropBuf->AddPropFix(sprmCRgFtc1, 4);
		pPropBuf->AddPropFix(sprmCRgFtc2, 4);
		pPropBuf->AddPropFix(sprmCIdctHint, 0);
		hr = S_OK;
#endif
		KS_CHECK(hr);
	}
	
KS_EXIT:
	return hr;
}

inline
STDMETHODIMP _MakePapx(
					   IN KDWDocTarget* pDocTarget,
					   IN KROAttributes* pAttrs,
					   IN KDWPropBuffer* pPropBuf)
{
	HRESULT hr = E_FAIL;
	ATTRVALUE_PTR pAttrVal(NULL);
	hr = TransParaAttr(pDocTarget, 
		(IKAttributes*)pAttrs, pPropBuf);
	TransTAB(pDocTarget, pAttrs, pPropBuf);
	KS_CHECK(hr);
KS_EXIT:
	return hr;
}

// -------------------------------------------------------------------------
STDMETHODIMP KTextLevelHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	ATTRVALUE_PTR pAttrVal = NULL;

	if (pAttrs->GetIndex(kso::text_legal, &pAttrVal) >= 0)
		m_listLevel.SetLegal(pAttrVal->lVal);

	if (pAttrs->GetIndex(kso::text_list_number_style, &pAttrVal) >= 0)
		m_listLevel.SetNfc((NFC)pAttrVal->lVal);
	
	if (pAttrs->GetIndex(kso::text_number_format, &pAttrVal) >= 0)
	{
		ASSERT(pAttrVal->vt == ATTRVALUE::vtString);
		m_listLevel.SetXst(pAttrVal->bstrVal);
	}
	if (pAttrs->GetIndex(kso::text_list_start, &pAttrVal) >= 0)
		m_listLevel.SetStartAt(pAttrVal->lVal);
	
	if (pAttrs->GetIndex(kso::text_list_align, &pAttrVal) >= 0)
		m_listLevel.SetJc((JC)pAttrVal->lVal);
	
	if (pAttrs->GetIndex(kso::text_list_restart, &pAttrVal) >= 0)
		m_listLevel.SetNoRestart(!pAttrVal->lVal);
	
	if (pAttrs->GetIndex(kso::text_restart_after_level, &pAttrVal) >= 0)
		m_listLevel.SetRestartAfterLevel(pAttrVal->lVal);

	if (pAttrs->GetIndex(kso::text_follow_char, &pAttrVal) >= 0)
		m_listLevel.SetIxchFollow((XCHFOLLOW)pAttrVal->lVal);

	UINT idImage;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_list_image_source, &idImage)))
	{
		m_pLists->SetPicBullet(m_listLevel, idImage);
	}

	KDWDocTarget* pDocTarget = m_pLists->GetDocTarget();


	KDWPropBuffer* papx = pDocTarget->GetPropBuffer();
	if (SUCCEEDED(_MakePapx(pDocTarget, pAttrs, papx)))
		m_listLevel.SetPapx(papx);

	
/*
	@@note: �ݲ�����������ʽ�����´���һֱ����Ч�ġ�


	UINT istdLink;
	if (SUCCEEDED(
		pAttrs->GetByID(text_link_style, &istdLink)
		))
	{
		KDWStyleIDMap& IdMap = pDocTarget->GetPStyleIDMap();
		KDWStyleIDMap::const_iterator i = IdMap.find(istdLink);
		if (i != IdMap.end())
		{
			KDWPropBuffer* papx = pDocTarget->GetPropBuffer();
			if (SUCCEEDED(
				_MakePapx(pDocTarget, pAttrs, papx)
				))
			{
				m_listLevel.SetPapx(papx, (*i).second);
			}
		}
	}
*/
	
	KDWPropBuffer* chpx = pDocTarget->GetPropBuffer();
	if (!FAILED(_MakeChpx(pDocTarget, pAttrs, chpx)))
		m_listLevel.SetChpx(chpx);


	KDWChgTAB* pChgTAB = pDocTarget->GetTABMap().NewLstTAB(m_iLst, m_iLvl);
	MakeChgTAB(pAttrs, pChgTAB);

	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: text_level.cpp,v $
// Revision 1.14  2006/10/25 07:17:00  wangdong
// #31555, ������ʧָ��λ��\n������ʽʵ����һֱδ��֧�֣�ȥ�����õĴ������롣
//
// Revision 1.13  2005/08/09 06:15:44  rongjianxing
// *** empty log message ***
//
// Revision 1.12  2005/06/22 09:53:00  xushiwei
// bug# 15454 ����
//
