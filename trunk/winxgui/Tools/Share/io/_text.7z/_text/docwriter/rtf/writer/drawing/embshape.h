/* -------------------------------------------------------------------------
//	�ļ���		��	embshape.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:50:45
//	��������	��	
//
//	$Id: embshape.h,v 1.4 2006/04/13 00:52:30 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __EMBSHAPE_H__
#define __EMBSHAPE_H__
//#include "drawingprop.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWEmbShapes;
class RtfDirectWriter;
class RtfWEmbShapeWriter
{
private:
	const _KDWEmbShapes* m_embshapes;
	const KDWBlipStore* m_blipstore;

private:
	STDMETHODIMP_(void) WriteArttext(RtfDirectWriter* ar, const _KDWEmbShapeEx* shape);
	STDMETHODIMP_(void) WriteShape(RtfDirectWriter* ar, const _KDWEmbShapeEx* shape);
	STDMETHODIMP_(void) WritePic(RtfDirectWriter* ar, const _KDWEmbShapeEx* shape);
	BOOL IsArttext(MSOSPT spt);	
public:
	RtfWEmbShapeWriter(const _KDWEmbShapes* embshapes, const KDWBlipStore* blipstore);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const KDWPropx* stub);
};
// -------------------------------------------------------------------------
//	$Log: embshape.h,v $
//	Revision 1.4  2006/04/13 00:52:30  xulingjiao
//	�޸�ͼƬ��ʾ��������BUG
//	
//	Revision 1.3  2006/04/12 01:46:10  xulingjiao
//	textbox
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __EMBSHAPE_H__ */
