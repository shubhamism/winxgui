/* -------------------------------------------------------------------------
//	�ļ���		��	bookmarks.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:13:19
//	��������	��	
//
//	$Id: bookmarks.cpp,v 1.4 2006/07/31 06:29:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "bookmark.h"
#include "bookmarks.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWBookmarkStartsWriter::RtfWBookmarkStartsWriter()
{
	m_data = NULL;
}
RtfWBookmarkStartsWriter::RtfWBookmarkStartsWriter(const KDWBookmarkStarts* data) : m_data(data)
{
	SetData(data);	
}
STDMETHODIMP RtfWBookmarkStartsWriter::SetData(const KDWBookmarkStarts* data)
{
	m_data = data;
	Reset();
	return S_OK;
}
STDMETHODIMP_(BOOL) RtfWBookmarkStartsWriter::Good() const
{
	return m_data != NULL && m_data->Count();
}
STDMETHODIMP_(void) RtfWBookmarkStartsWriter::Reset()
{
	m_enumer = KDWBookmarkStarts::Enumerator(m_data);
	Next();
}
STDMETHODIMP RtfWBookmarkStartsWriter::Next()
{
	return m_enumer.Next();
}
STDMETHODIMP_(UINT) RtfWBookmarkStartsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.GetCurrentCp();
}
STDMETHODIMP_(UINT) RtfWBookmarkStartsWriter::GetNextCp()
{
	return (UINT)m_enumer.GetNextCp();
}
STDMETHODIMP_(void) RtfWBookmarkStartsWriter::Write(RtfDirectWriter* ar)
{
	RtfWBookmarkWriter wrBookMark;
	wrBookMark.WriteBegin(ar, &m_enumer.Item());
}

RtfWBookmarkEndsWriter::RtfWBookmarkEndsWriter()
{
	m_data = NULL;
}
RtfWBookmarkEndsWriter::RtfWBookmarkEndsWriter(const KDWBookmarkEnds* data) : m_data(data)
{		
	Reset();
}
STDMETHODIMP RtfWBookmarkEndsWriter::SetData(const KDWBookmarkEnds* data)
{
	m_data = data;
	Reset();
	return S_OK;
}
STDMETHODIMP_(BOOL) RtfWBookmarkEndsWriter::Good() const
{
	return m_data != NULL && m_data->Count();
}
STDMETHODIMP_(void) RtfWBookmarkEndsWriter::Reset()
{
	m_enumer = KDWBookmarkEnds::Enumerator(m_data);
	Next();
}
STDMETHODIMP RtfWBookmarkEndsWriter::Next()
{
	return m_enumer.Next();
}
STDMETHODIMP_(UINT) RtfWBookmarkEndsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.GetCurrentCp();
}
STDMETHODIMP_(UINT) RtfWBookmarkEndsWriter::GetNextCp()
{
	return (UINT)m_enumer.GetNextCp();
}
STDMETHODIMP_(void) RtfWBookmarkEndsWriter::Write(RtfDirectWriter* ar)
{
	RtfWBookmarkWriter wrBookMark;
	wrBookMark.WriteEnd(ar, &m_enumer.Item());
}
