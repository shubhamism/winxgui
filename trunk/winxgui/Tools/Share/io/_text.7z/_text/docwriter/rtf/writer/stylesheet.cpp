/* -------------------------------------------------------------------------
//	�ļ���		��	stylesheet.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:16:41
//	��������	��	
//
//	$Id: stylesheet.cpp,v 1.3 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "style.h"
#include "stylesheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) RtfWStyleSheetWriter::Write(IN OUT RtfDirectWriter* ar, IN RtfWGlobalInfo* info)
{
	INT count = info->styles->Count();
	if (count <= 0)
		return;

	ar->StartGroup(rtf_stylesheet);

	RtfWStyleWriter wr;
	for (INT i = 0; i < count; ++i)
	{
		wr.Write(ar, info, i);
	}

	ar->EndGroup();
}
