/* -------------------------------------------------------------------------
//	�ļ���		��	tablehelper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:03:50
//	��������	��	
//
//	$Id: tablehelper.h,v 1.1 2006/01/04 03:42:05 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TABLEHELPER_H__
#define __TABLEHELPER_H__
#include "propbasic.h"

struct Doc2RtfCellPr : KDWCellPr
{		
	INT16 dxaTC;
	STDMETHODIMP_(void) ConvertTC(const TC& tc)
	{
		noWrap = tc.fNoWrap;
		tcFitText = tc.fFitText;		
		// tcWidth �����
		tcBorders[mso_tcBrcTop].put_Brc(tc.brc[mso_tcBrcTop]);
		tcBorders[mso_tcBrcLeft].put_Brc(tc.brc[mso_tcBrcLeft]);
		tcBorders[mso_tcBrcBottom].put_Brc(tc.brc[mso_tcBrcBottom]);
		tcBorders[mso_tcBrcRight].put_Brc(tc.brc[mso_tcBrcRight]);
		textFlow = tc.textFlow;	
		vertAlign = tc.vertAlign;
		vertMerge = tc.vertMerge;		
		horiMerge = tc.horiMerge;
	}
};

struct Doc2RtfRowTablePr : KDWRowTablePr
{	
	INT16 dxaLeft, dxaGapHalf, dyaRowHeight;
	UINT8 fRowEnd, fRowEnd2;
	KDWTablePos tblPos;
	std::vector<Doc2RtfCellPr> m_cells;

	Doc2RtfRowTablePr()
	{
		Reset();
	}
	STDMETHODIMP_(void) ConvertSprmTDefTable(const sprmTDefTableOprand& opr)
	{
		m_cells.resize(opr.itc);

		dxaLeft = opr.rgdxaCenter[0];
		
		for(INT i=0; i<opr.itc; ++i)
		{
			m_cells[i].ConvertTC(opr.rgtc[i]);
			m_cells[i].dxaTC = opr.rgdxaCenter[i+1];
		}
	}
	STDMETHODIMP_(void) ConvertSprmTCellMargin(const SprmTCellMarginOprand& opr)
	{
		INT i;
		for(i=opr.itcFirst; i<opr.itcLim; ++i)
		{
			Doc2RtfCellPr& cl = m_cells[i];
			if(opr.grbitChg & mso_ChgTop)
			{
				cl.tcMar[mso_tcMarginTop].type = opr.type;
				cl.tcMar[mso_tcMarginTop].wVal = opr.wCellMargin;
			}
			if(opr.grbitChg & mso_ChgBottom)
			{
				cl.tcMar[mso_tcMarginBottom].type = opr.type;
				cl.tcMar[mso_tcMarginBottom].wVal = opr.wCellMargin;
			}
			if(opr.grbitChg & mso_ChgLeft)
			{
				cl.tcMar[mso_tcMarginLeft].type = opr.type;
				cl.tcMar[mso_tcMarginLeft].wVal = opr.wCellMargin;
			}
			if(opr.grbitChg & mso_ChgRight)
			{
				cl.tcMar[mso_tcMarginRight].type = opr.type;
				cl.tcMar[mso_tcMarginRight].wVal = opr.wCellMargin;
			}		
		}
	}	
	STDMETHODIMP_(void) Reset()
	{	
		ZeroMemory(this, sizeof(Doc2RtfRowTablePr));		
		tblCellMar[mso_tcMarginLeft].put_Value(108);
		tblCellMar[mso_tcMarginRight].put_Value(108);
		typeCellWidth = 3;
		tblWidth.put_Auto();		
		trwWidthB.put_Value(0);
		trwWidthA.put_Value(0);
		jc = 0;		
		tblInd.put_Nil(0);
		INT i;
		for(i=0; i<4; ++i)
		{
			tblCellMar[i].put_Value(0);
		}
		for(i=0; i<4; ++i)
		{
			tblBorders[i].put_Nil();
		}
		shd.put_Nil();
		trHeight.put_Auto();
		tblPos.Reset();
		tblPos.tblOverlap = 0;
	}	
};

// -------------------------------------------------------------------------

inline STDMETHODIMP Sprms2RtfTablePr(IN const KDWSprmList* sprms, IN OUT Doc2RtfRowTablePr* d)
{	
	HRESULT hr = E_FAIL;

	KDWSprm sprm;
	const BYTE* arg = NULL;
	int len = -1;

	KDWSprmList::Enumerator enumer(sprms);
	for (; SUCCEEDED(enumer.Next(&sprm)); )
	{
		VERIFY(SUCCEEDED(sprm.GetArgument(&arg, &len)));
		USHORT opcode = sprm.GetOpcode();
		switch (opcode)
		{
		// @bug��ָ��û�ж�����
		case sprmTTableWidth:
			AssignKDWValueExt(d->tblWidth, arg);
			hr = S_OK;
			break;
		// @bug��ָ��û�ж�����
		case sprmTWidthBefore:
			AssignKDWValueExt(d->trwWidthA, arg);
			hr = S_OK;
			break;
		// @bug��ָ��û�ж�����
		case sprmTWidthAfter:
			AssignKDWValueExt(d->trwWidthB, arg);
			hr = S_OK;
			break;
		case sprmTCellSpacing:
			{
				const BYTE* pArg = arg;
				pArg += 3;
				AssignKDWValueExt(d->tblCellSpacing, pArg);
			}
			hr = S_OK;
			break;
		case sprmTDxaGapHalf:
			d->dxaGapHalf = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmTDefCellMargin:
			{	
				const BYTE* pArg = arg;
				pArg += 2;
				UINT8 grbitChg = *pArg++;
				if(grbitChg & mso_ChgTop)
					AssignKDWValueExt(d->tblCellMar[mso_tcMarginTop], pArg);
				if(grbitChg & mso_ChgBottom)
					AssignKDWValueExt(d->tblCellMar[mso_tcMarginBottom], pArg);
				if(grbitChg & mso_ChgLeft)
					AssignKDWValueExt(d->tblCellMar[mso_tcMarginLeft], pArg);
				if(grbitChg & mso_ChgRight)
					AssignKDWValueExt(d->tblCellMar[mso_tcMarginRight], pArg);				
			}
			hr = S_OK;
			break;
		case sprmTCellMargin:
			{
				SprmTCellMarginOprand opr;
				opr.itcFirst = *arg++;
				opr.itcLim = *arg++;
				opr.grbitChg = *arg++;
				opr.type = *arg++;
				opr.wCellMargin = GetValue<INT16>(arg);
				d->ConvertSprmTCellMargin(opr);
			}
			hr = S_OK;
			break;
		case sprmTFit:			
			d->tblFixedLayout = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmTTableHeader:
			d->tblHeader = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmTFCantSplit:
			d->cantSplit = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmTFCantSplitEx:
			d->cantSplit = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmTDyaRowHeight:
			d->dyaRowHeight = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmTDefTable:
			{
				sprmTDefTableOprand opr;
				AssignsprmTDefTableOprand(opr, arg, len);
				d->ConvertSprmTDefTable(opr);
			}
			hr = S_OK;
			break;
		case sprmTDefTableShdEx:
			{
				UINT itc = len / sizeof(SHDEX), i;
				for(i=0; i<itc; ++i)
				{
					AssignShdex(d->m_cells[i].shd, arg);
					arg += sizeof(SHDEX);
				}
			}
			hr = S_OK;
			break;		
		case sprmTTableBordersEx:
			for(INT i=0; i<6; ++i)
			{
				AssignBrcEx(d->tblBorders[i], arg);
				arg += sizeof(KDWBrc);
			}
			hr = S_OK;
			break;
		// ���ӱ���λ������
		case sprmTDxaLeftFromText:
			d->tblPos.leftFromText = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmTDxaRightFromText:
			d->tblPos.rightFromText = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmTDyaTopFromText:
			d->tblPos.topFromText = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmTDyaBottomFromText:
			d->tblPos.bottomFromText = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmTCantOverlap:
			d->tblPos.tblOverlap = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmTPc:
			{
				UINT8 data = *arg;
				data >>= 4;
				d->tblPos.pcVert = data & 3;
				data >>= 2;
				d->tblPos.pcHorz = data & 3;
				data >>= 2;
			}
			hr = S_OK;
			break;
		case sprmTDxaAbs:
			d->tblPos.tblpX = GetValue<INT16>(arg);
			hr = S_OK;
			break;		
		case sprmTDyaAbs:
			d->tblPos.tblpY = GetValue<INT16>(arg);
			hr = S_OK;
			break;
		case sprmPFTtp:
			d->fRowEnd = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmPFTtp2:
			d->fRowEnd2 = GetValue<UINT8>(arg);
			hr = S_OK;
			break;
		case sprmTSetBrc:
			hr = S_OK;
			break;
		// @bug ��ָ��û�ж�ȡ������
		case sprmTSetBrcEx:
			{
				SprmTSetBrcExOprand opr;
				AssignSprmTSetBrcExOprand(opr, arg, len);
			}
			hr = S_OK;
			break;
		case sprmTJcEx:
			d->jc = GetValue<UINT16>(arg);
			hr = S_OK;
			break;
		}
	}
	return hr;
}

inline STDMETHODIMP Sprms2RtfTablePr(IN const KDWPropx* prop, IN OUT Doc2RtfRowTablePr* d)
{
	KDWSprmList sprms;
	sprms.AssignTapx(prop);
	return Sprms2RtfTablePr(&sprms, d);
}
// -------------------------------------------------------------------------
//	$Log: tablehelper.h,v $
//	Revision 1.1  2006/01/04 03:42:05  xulingjiao
//	*** empty log message ***
//	

#endif /* __TABLEHELPER_H__ */
