/* -------------------------------------------------------------------------
//	�ļ���		��	text_annotation_begin.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 9:58:55
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_ANNOTATION_BEGIN_H__
#define __TEXT_ANNOTATION_BEGIN_H__

// -------------------------------------------------------------------------

class KTextAnnBeginHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
};	

// -------------------------------------------------------------------------

#endif /* __TEXT_ANNOTATION_BEGIN_H__ */
