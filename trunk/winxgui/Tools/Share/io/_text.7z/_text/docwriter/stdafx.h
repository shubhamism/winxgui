// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//	
// $Id: stdafx.h,v 1.42 2006/07/31 07:00:01 wangdong Exp $

#if !defined(AFX_STDAFX_H__16597D90_66B1_4199_92E8_7FE88DF62C5D__INCLUDED_)
#define AFX_STDAFX_H__16597D90_66B1_4199_92E8_7FE88DF62C5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "buildcfg/wps_buildcfg.h"

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <kfc.h>

#ifndef __KFC_COM_OLE_H__
#include <kfc/com/ole.h>
#endif

#ifndef __KFC_COM_SIMPOBJ_H__
#include <kfc/com/simpobj.h>
#endif

#ifndef __KFC_IO_ARCHIVE_H__
#include <kfc/io/archive.h>
#endif

#ifndef __KFC_ALLOCATER_KERNDATA_H__
#include <kfc/allocater/kerndata.h>
#endif

// -------------------------------------------------------------------------

#ifndef __KSO_IO_CONTENTHANDLER_H__
#include <kso/io/contenthandler.h>
#endif

#ifndef __KSO_IO_SCHEMA_H__
#include <kso/io/schema.h>
#endif

#ifndef __KSO_SCHEMA_IO_V6_STD_TEXT_TABLE_H__
#include <kso/io/v6/std/text_table.h>
#endif


__USING_KSO

// -------------------------------------------------------------------------

#ifndef __MSO_DOM_TEXTV2_H__
#include <mso/dom/textv2.h>
#endif

#include "attr/attrtools.h"

#include "kso/linklib.h"
// -------------------------------------------------------------------------

#ifndef _DW_AddRefHandler
#define _DW_AddRefHandler(pHandler)		do { ASSERT(pHandler); NULL; } while(0)
#endif

#ifndef _DW_Fix2Float
#define _DW_Fix2Float(value) ((float)(value) / 0x10000)
#endif

#ifndef IO_E_IGNORE
#define IO_E_IGNORE						E_UNEXPECTED
#endif

#ifndef IO_S_ATTR_UNHANDLE
#define IO_S_ATTR_UNHANDLE				((HRESULT)(S_FALSE + 101))
#endif

#ifdef IO_S_ATTR_CONTINUE
#undef IO_S_ATTR_CONTINUE
#endif
#define IO_S_ATTR_CONTINUE				IO_S_ATTR_UNHANDLE


//#ifdef _DEBUG
#define __DW_REGISTER_RTF_WRITER
#define __DW_REGISTER_HTML_WRITER
//#endif

// -------------------------------------------------------------------------

#if defined(X_CC_VC)
#pragma warning(disable:4065)
#endif

class KDWDocument;
class KDWDocTarget;

// -------------------------------------------------------------------------
// class KDWCollectionHandler

template <class HandlerType, int SubElementID, class InitClass = KDWDocTarget>
class KDWCollectionHandler : public KFakeUnknown<KElementHandler>
{
protected:
	HandlerType m_subElement;
	InitClass* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN InitClass* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs)
	{
		return S_OK;
	}

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case SubElementID:
			m_subElement.Init(m_pDocTarget);
			*ppHandler = &m_subElement;
			break;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		_DW_AddRefHandler(*ppHandler);
		return S_OK;
	}
};
#include "docwriter.h"
#include "rtf/writer.h"
// -------------------------------------------------------------------------

#endif // !defined(AFX_STDAFX_H__16597D90_66B1_4199_92E8_7FE88DF62C5D__INCLUDED_)

// $Log: stdafx.h,v $
// Revision 1.42  2006/07/31 07:00:01  wangdong
// #26126������дdocʱ��feature��������ݡ�
//
// Revision 1.41  2006/05/11 03:16:18  wangdong
// no message
//
// Revision 1.40  2006/04/13 00:52:30  xulingjiao
// �޸�ͼƬ��ʾ��������BUG
//
// Revision 1.39  2006/04/12 01:46:10  xulingjiao
// textbox
//
// Revision 1.38  2006/01/20 08:42:54  xulingjiao
// html����BASEԪ��
//
// Revision 1.37  2006/01/18 01:48:11  wangdong
// ������HTML���ơ�
//
// Revision 1.36  2006/01/11 02:47:46  rongjianxing
// wpio�ӵ������С�
//
// Revision 1.35  2006/01/04 03:41:47  xulingjiao
// *** empty log message ***
//
// Revision 1.34  2005/12/30 01:43:02  xulingjiao
// html������,Ƕ����ͼƬ,��Ŀ����
//
// Revision 1.33  2005/12/23 02:48:21  xulingjiao
// *** empty log message ***
//
// Revision 1.32  2005/12/21 09:38:42  xulingjiao
// *** empty log message ***
//
// Revision 1.31  2005/11/21 08:19:28  wangdong
// ȥ���˺ꡣ
//
// Revision 1.30  2005/11/18 01:23:39  xulingjiao
// �޸������ļ�����ΪRTF��ʽʱ����������
//
// Revision 1.29  2005/10/09 09:16:51  wangdong
// ��releaseʱ��RTFд��
//
// Revision 1.28  2005/08/05 07:15:31  wangdong
// �����˺�����Ƿ�ע��RTFд��
//
// Revision 1.26  2005/02/24 03:20:33  wangdong
// �����˸�����_DW_Fix2Float���ƺ�Ӧ�����ڱ𴦡�
//
