/* -------------------------------------------------------------------------
//	�ļ���		��	html_textstream.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:35:01
//	��������	��	
//
//	$Id: html_textstream.h,v 1.12 2006/08/07 01:51:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_TEXTSTREAM_H__
#define __HTML_TEXTSTREAM_H__
#include "mso/dom/text/texttable/tables_cache.h"
class HtmlWRangesWriter;
class HtmlWChpxWriter;
class HtmlDirectWriterA;
class HtmlWTextStreamWriter
{
private:
	const KDWTextStream* m_stream;
	KDWTablesCache m_tables;
	HtmlWRangesWriter* m_wrRanges;
	UINT m_SpecText;
	CP m_CurCp;
private:	
	enum
	{
		END_PARA = 0x0d,
	};
private:
	STDMETHODIMP_(void) AddUtf8Char(HtmlDirectWriterA* ar, WCHAR wch);
	STDMETHODIMP AddSpecChar(HtmlDirectWriterA* ar, WCHAR wch, HtmlWChpxWriter* chpInfo);
	STDMETHODIMP_(void) AddMultibyteChar(HtmlDirectWriterA* ar, WCHAR wch, DWORD ciACP);
public:
	STDMETHODIMP_(void) WriteMultibyteText(const KDWTextStream* p, CP cp, INT cch, HtmlWChpxWriter* chpInfo);
	STDMETHODIMP_(void) WriteUtf8Text(const KDWTextStream* p, CP cp, INT cch, HtmlWChpxWriter* chpInfo);
	STDMETHODIMP_(CP&) GetCurrentCp()
	{
		return m_CurCp;
	}
	STDMETHODIMP_(KDWTablesCache&) GetTables()
	{
		return m_tables;
	}
	STDMETHODIMP_(const KDWTextStream*) GetStream() const
	{
		return m_stream;
	}
	STDMETHODIMP_(HtmlWRangesWriter*) GetRange()
	{
		return m_wrRanges;
	}
	HtmlWTextStreamWriter(
		const KDWTextStream* stream,
		HtmlWRangesWriter* wrRanges);
	STDMETHODIMP_(void) Write();
	STDMETHODIMP_(void) Write(CP cp, INT cch);
};
#endif /* __HTML_TEXTSTREAM_H__ */
