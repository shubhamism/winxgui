/* -------------------------------------------------------------------------
//	�ļ���		��	dwbookmarks.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-21 10:18:40
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "bookmarkconnect.h"
#include "office_bookmark.h"
#include <doctarget.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

typedef KDWCollectionHandler<KOfficeBookmarkHandler, office_bookmark, KBookmarkConnection>
		KOfficeBookmarksHandler;

// -------------------------------------------------------------------------

STDMETHODIMP KBookmarkConnection::CreateBookmarksHandler(
														OUT IKElementHandler** ppHandler)
{
	KOfficeBookmarksHandler* pHandler = DW_NEWHANDLER(KOfficeBookmarksHandler);
	pHandler->Init(this);
	*ppHandler = pHandler;
	return S_OK;
}

STDMETHODIMP KBookmarkConnection::NewBookmark(
						 IN BSTR bstrName,
						 IN RANGE_ID uRangeID)
{
	ASSERT(
		m_map.find(uRangeID) == m_map.end()
		);
	m_map[uRangeID] = m_pDocTarget->AllocStringByBSTR(bstrName);
	return S_OK;
}

STDMETHODIMP KBookmarkConnection::DecodeRange(
					  IN RANGE_ID uRangeID,
					  IN CP cpStart,
					  IN CP cpEnd)
{
	BookMarkMap::iterator itFind = m_map.find(uRangeID);
	ASSERT(itFind != m_map.end());
	
	if (itFind != m_map.end())
	{
		KDWBookmarks& bookmarks = m_pDocTarget->GetBookmarks();
		bookmarks.NewBookmark(
			(*itFind).second,
			cpStart,
			cpEnd);
		m_map.erase(itFind);
	}
	return S_OK;
}

// -------------------------------------------------------------------------
