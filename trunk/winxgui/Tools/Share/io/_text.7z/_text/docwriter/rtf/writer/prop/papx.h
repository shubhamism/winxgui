/* -------------------------------------------------------------------------
//	�ļ���		��	papx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:21:37
//	��������	��	
//
//	$Id: papx.h,v 1.6 2006/03/06 01:44:13 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PAPX_H__
#define __PAPX_H__
#include "papxhelper.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWColorTable;

void AddPard(RtfWParaPr* prop);

class RtfWPapxWriter
{
private:
	RtfWParaPr prop;
	KDWSprmList m_sprms;
	RtfWGlobalInfo* m_ginfo;
	UINT m_istd;
public:
	STDMETHODIMP_(void) WriteLevelPapx(RtfDirectWriter* ar);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const RtfWParaPr* prop, UINT istd);
	RtfWPapxWriter(RtfWGlobalInfo* info, const KDWPropx* prop = NULL);
	STDMETHODIMP_(void) SetProp(const KDWPropx* prop);
	STDMETHODIMP_(void) SetProp(const BYTE* buff, INT cb, BOOL hasIstd = TRUE);
	STDMETHODIMP_(void) SetIstd(UINT istd);
	STDMETHODIMP_(UINT) GetIstd();
	STDMETHODIMP_(RtfWParaPr&) GetPap();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
private:
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const RtfWParaPr* mergewith, const RtfWParaPr* baseon);	
	void WriteMerged(RtfDirectWriter* ar, const RtfWParaPr* p, UINT istd, RtfWGlobalInfo* ginfo);
private:
	void WriteParaShdCtrl(const KDWShd& shd, UINT8 refShd, RtfWColorTable* colors, RtfDirectWriter* ar);
	 void WriteBrcCtrl(const KDWBrc& brc, UINT8 refBrc, RtfDirectWriter* ar, RtfWColorTable* colors, RtfControl whichBrc);
	 void WriteLspdCtrl(LSPD lspd, UINT8 refLspd, RtfDirectWriter* ar);
	 void WriteTabCtrl(const KDWTab& ktab, RtfDirectWriter*ar);
	 void WriteTabCtrl(const KDWTab& ktab,UINT8 refKtab, RtfDirectWriter*ar);
	 void WriteFrameDropcapCtrl(const DCS& dropCap, RtfDirectWriter*ar);
	 void WriteFrameDropcapCtrl(const DCS& dropCap, UINT8 refDropCap, RtfDirectWriter*ar);
	 void WriteFramePPcOprandCtrl(const KDWFrame::unionSprmPPcOprand& ppcOprand, RtfDirectWriter*ar);
	 void WriteFramePPcOprandCtrl(const KDWFrame::unionSprmPPcOprand& ppcOprand, UINT8 refPPcOprand, RtfDirectWriter*ar);
	 void WriteFrameDxaAbsCtrl(INT16 dxaAbs, UINT8 refDxaAbs, RtfDirectWriter*ar);
	 void WriteFrameDyaAbsCtrl(INT16 dyaAbs, UINT8 refDyaAbs, RtfDirectWriter*ar);
	 void WriteFrameWrCtrl(INT8 wr, UINT8 refWr, RtfDirectWriter* ar);
	 void WriteFrameWHeightAbsOprandCtrl(const KDWFrame::sprmWHeightAbsOprand& wHeightAbsOprand, RtfDirectWriter* ar);
	 void WriteFrameWHeightAbsOprandCtrl(const KDWFrame::sprmWHeightAbsOprand& wHeightAbsOprand, UINT8 refWHeightAbsOprand, RtfDirectWriter* ar);
	 void WriteFWidowControlCtrl(UINT8 fWidowControl, UINT8 refFWidowControl, RtfDirectWriter* ar);
	 void WriteLsCtrl(RtfDirectWriter* ar, const RtfWParaPr* p, RtfWGlobalInfo* ginfo);
};
// -------------------------------------------------------------------------
//	$Log: papx.h,v $
//	Revision 1.6  2006/03/06 01:44:13  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.5  2006/02/22 01:13:58  xulingjiao
//	�޸��޶���BUG,rtfreader����������ת����BUG,��������
//	
//	Revision 1.4  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.3  2006/01/20 08:43:00  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.2  2006/01/13 09:19:48  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.1  2006/01/04 03:42:02  xulingjiao
//	*** empty log message ***
//	

#endif /* __PAPX_H__ */
