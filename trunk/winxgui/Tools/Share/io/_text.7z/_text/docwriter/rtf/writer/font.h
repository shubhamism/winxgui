/* -------------------------------------------------------------------------
//	�ļ���		��	font.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:58:25
//	��������	��	
//
//	$Id: font.h,v 1.3 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __FONT_H__
#define __FONT_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfDirectWriter;
class RtfWFontWriter
{
private:
	struct _Helper
	{
		static STDMETHODIMP_(void) GetName(const _DW_FONT* font, WCHAR (&xszFfn)[66])
		{		
			memcpy(xszFfn, font->xszFfn, sizeof(font->xszFfn));
			LPWSTR p = xszFfn + wcslen(xszFfn) -1;
			while(*p)
			{
				if(!iswspace(*p))				
					break;				
				*p-- = '\0';
			}
		}
		static LPCWSTR GetAltName(const _DW_FONT* font)
		{
			return font->xszFfn + font->ixchSzAlt;
		}
		static void PutWcs(RtfDirectWriter* ar, LPCWSTR s)
		{
			RtfWAutoBuff buff;
			UINT size = 0;
			RtfWcs2Mbs(s, wcslen(s), GetACP(), &buff, &size);
			ar->AddContent((LPCSTR)buff.Data(), size);
		}
	};
	RtfControl GetFamilyEnum(UINT family);
private:
	STDMETHODIMP_(DWORD) _GetCodePage(const _DW_FONT* font)
	{
		DWORD ciACP = GetACP();
		CHARSETINFO chsinfo;
		if(TranslateCharsetInfo((DWORD*)font->chs, &chsinfo, TCI_SRCCHARSET))
			ciACP = chsinfo.ciACP;
		return ciACP;
	}
public:
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const _DW_FONT* font, INT Id);
};
// -------------------------------------------------------------------------
//	$Log: font.h,v $
//	Revision 1.3  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __FONT_H__ */
