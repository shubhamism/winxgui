/* -------------------------------------------------------------------------
//	�ļ���		��	doctarget.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-22 10:00:06
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include "../bookmark/bookmarkconnect.h"
//#include "../comment/commentconnect.h"
#include "../footnote/footnoteconnect.h"
#include "../drawing/drawingconnect.h"
#include "../field/hyperlinkconnect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP_(void) KDWDocTarget::Close(IN BOOL fAbort)
{
	ASSERT(m_mapOleStg.empty());

	if (m_drawingConnection)
	{
		delete m_drawingConnection;
		m_drawingConnection = NULL;
	}
	if (m_bookmarkConnection)
	{
		delete m_bookmarkConnection;
		m_bookmarkConnection = NULL;
	}
	if (m_footnoteConnection)
	{
		delete m_footnoteConnection;
		m_footnoteConnection = NULL;
	}
	/* 
	if (m_commentConnection)
	{
		delete m_commentConnection;
		m_commentConnection = NULL;
	}
	new_annotation */
	if (m_hyperlinkConnection)
	{
		delete m_hyperlinkConnection;
		m_hyperlinkConnection = NULL;
	}
	KDWDocument::Close(fAbort);
}

STDMETHODIMP KDWDocTarget::AnnotationUserIDLookup(UINT uID_MidLayer, UINT* puID_FileLayer)
{
	ASSERT(puID_FileLayer);

	HRESULT hr;
	if (m_Annotation_Mid2FileID.find(uID_MidLayer) == m_Annotation_Mid2FileID.end())
	{
		if (m_useridMap.find(uID_MidLayer) != m_useridMap.end())
		{
			if (m_usermode == UAM_UNKNOWN)
				m_usermode = UAM_USERS_FIRST;

			ASSERT(m_usermode == UAM_USERS_FIRST);	//���ܻ��ʹ��

			UINT uAllUserID = m_useridMap[uID_MidLayer];
			const _DW_UserNameInfo* pUser = m_userslist.GetUserNameInfo(uAllUserID);
			ASSERT(pUser);
			hr = GetAnnotationUsers().Add(pUser->userName,
											pUser->userNameAbbr,
											puID_FileLayer);
			if (SUCCEEDED(hr))
				m_Annotation_Mid2FileID[uID_MidLayer] = *puID_FileLayer;
		}
		else
		{
			if (m_usermode == UAM_UNKNOWN)
				m_usermode = UAM_USERS_LAST;

			ASSERT(m_usermode == UAM_USERS_LAST);	//���ܻ��ʹ��

			*puID_FileLayer = m_userlast_AnnotationID;
			m_Annotation_Mid2FileID[uID_MidLayer] = *puID_FileLayer;
			m_userlast_AnnotationID++;
			hr = S_OK;
		}
	}
	else
	{
		*puID_FileLayer = m_Annotation_Mid2FileID[uID_MidLayer];
		hr = S_OK;
	}
	return hr;
}

STDMETHODIMP KDWDocTarget::RevisionUserIDLookup(UINT uID_MidLayer, UINT* puID_FileLayer)
{
	ASSERT(puID_FileLayer);

	HRESULT hr;
	if (m_Revision_Mid2FileID.find(uID_MidLayer) == m_Revision_Mid2FileID.end())
	{
		if (m_Revision_Mid2FileID.empty())
		{
			UINT userid;
			GetRevisionUsers().Add(
							__X("Unknown"),
							__X("Unknown"),
							&userid);
		}

		if (m_useridMap.find(uID_MidLayer) != m_useridMap.end())
		{
			if (m_usermode == UAM_UNKNOWN)
				m_usermode = UAM_USERS_FIRST;

			ASSERT(m_usermode == UAM_USERS_FIRST);	//���ܻ��ʹ��

			UINT uAllUserID = m_useridMap[uID_MidLayer];
			const _DW_UserNameInfo* pUser = m_userslist.GetUserNameInfo(uAllUserID);
			ASSERT(pUser);
			hr = GetRevisionUsers().Add(pUser->userName,
											pUser->userNameAbbr,
											puID_FileLayer);
			if (SUCCEEDED(hr))
				m_Revision_Mid2FileID[uID_MidLayer] = *puID_FileLayer;
		}
		else
		{
			if (m_usermode == UAM_UNKNOWN)
				m_usermode = UAM_USERS_LAST;

			ASSERT(m_usermode == UAM_USERS_LAST);	//���ܻ��ʹ��

			*puID_FileLayer = m_userlast_RevisionID;
			m_Revision_Mid2FileID[uID_MidLayer] = *puID_FileLayer;
			m_userlast_RevisionID++;
			hr = S_OK;
		}
	}
	else
	{
		*puID_FileLayer = m_Revision_Mid2FileID[uID_MidLayer];
		hr = S_OK;
	}
	return hr;
}

STDMETHODIMP KDWDocTarget::WriteUsersLast()
{
	if (m_usermode == UAM_USERS_LAST)
	{
		UINT uID_MidLayer;
		UINT uID_FileLayer;
		UINT uAllUserID;
		UINT uID_TrueFileLayer;
		KDWUserIDMap::const_iterator it = m_Annotation_Mid2FileID.begin();
		while (it != m_Annotation_Mid2FileID.end())
		{
			uID_MidLayer = (*it).first;
			uID_FileLayer = (*it).second;
			uAllUserID = m_useridMap[uID_MidLayer];
			const _DW_UserNameInfo* pUser = m_userslist.GetUserNameInfo(uAllUserID);
			ASSERT(pUser);
			uID_TrueFileLayer = 0;
			GetAnnotationUsers().Add(pUser->userName,
									pUser->userNameAbbr,
									&uID_TrueFileLayer);
			ASSERT(uID_TrueFileLayer == uID_FileLayer);
			it++;
		}

		it = m_Revision_Mid2FileID.begin();
		while (it != m_Revision_Mid2FileID.end())
		{
			uID_MidLayer = (*it).first;
			uID_FileLayer = (*it).second;
			uAllUserID = m_useridMap[uID_MidLayer];
			const _DW_UserNameInfo* pUser = m_userslist.GetUserNameInfo(uAllUserID);
			ASSERT(pUser);
			uID_TrueFileLayer = 0;
			GetRevisionUsers().Add(pUser->userName,
									pUser->userNameAbbr,
									&uID_TrueFileLayer);
			ASSERT(uID_TrueFileLayer == uID_FileLayer);
			it++;
		}
	}

	return S_OK;
}

STDMETHODIMP_(KDrawingConnection*) KDWDocTarget::GetDrawingConnection()
{
	if (m_drawingConnection == NULL)
	{
		m_drawingConnection = new KDrawingConnection(this);
	}
	return m_drawingConnection;
}

STDMETHODIMP_(KBookmarkConnection*) KDWDocTarget::GetBookmarkConnection()
{
	if (m_bookmarkConnection == NULL)
	{
		m_bookmarkConnection = new KBookmarkConnection;
		m_bookmarkConnection->Init(this);
	}
	return m_bookmarkConnection;
}

STDMETHODIMP_(KFootnoteConnection*) KDWDocTarget::GetFootnoteConnection()
{
	if (m_footnoteConnection == NULL)
	{
		m_footnoteConnection = new KFootnoteConnection;
		m_footnoteConnection->Init(this);
	}
	return m_footnoteConnection;
}

/*
STDMETHODIMP_(KCommentConnection*) KDWDocTarget::GetCommentConnection()
{
	if (m_commentConnection == NULL)
	{
		m_commentConnection = new KCommentConnection;
		m_commentConnection->Init(this);
	}
	return m_commentConnection;
}
new_annotation */
STDMETHODIMP_(KHyperlinkConnection*) KDWDocTarget::GetHyperlinkConnection()
{
	if (m_hyperlinkConnection == NULL)
	{
		m_hyperlinkConnection = new KHyperlinkConnection;
		m_hyperlinkConnection->Init(this);
	}
	return m_hyperlinkConnection;
}

// -------------------------------------------------------------------------
