/* -------------------------------------------------------------------------
//	�ļ���		��	text_hyperlink_range.cpp
//	������		��	����
//	����ʱ��	��	2004-8-23 20:29:09
//	��������	��	
//	$Id: text_hyperlink_range.cpp,v 1.5 2004/10/06 07:12:58 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_hyperlink_range.h"

#include <doctarget.h>
#include "hyperlinkconnect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KHyperlinkBeginHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	if (pAttrs)
	{
		ATTRVALUE_PTR pVar = NULL;
		ks_wstring strBookmark;
		if (pAttrs->GetIndex(text_hyperlink_info, &pVar) >= 0)
		{
			return m_pDocTarget->GetHyperlinkConnection()
				->BeginHyperlink(pVar->lVal);
		}
	}
	ASSERT_ONCE(0);
	return S_FALSE;
}

// -------------------------------------------------------------------------
STDMETHODIMP KHyperlinkEndHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	return m_pDocTarget->GetHyperlinkConnection()->EndHyperlink();
}

// -------------------------------------------------------------------------
