// -------------------------------------------------------------------------
//	�ļ���		��	rtf2rtf.cpp
//	������		��	nature(liucong)
//	����ʱ��	��	2005-7-19 ���� 03:02:40
//	��������	��	
//
// -------------------------------------------------------------------------

#include "stdafx.h"

#include <kfc.h>
#include <kso/io/contenthandler.h>
#include <kso/io/linklib_docreader.h>
#include <kso/io/linklib_docwriter.h>

#include "testcase/testrtf2rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

int main()
{
	if (__argc < 2)
		return -1;

	LPCWSTR szSrcFile = __wargv[1];

	WCHAR szDestFile[_MAX_PATH];
	wcscpy(szDestFile, szSrcFile);
	wcscat(szDestFile, __X(".rtf"));

	printf("processing %S ... ", szSrcFile);
	
	HRESULT hr = E_FAIL;
	try
	{
		KConvertRtf2Rtf rtf2rtf;
		hr = rtf2rtf.convertFile(szSrcFile, szDestFile);
	}
	catch (...)
	{
	}

	if (FAILED(hr))
		printf("failed!\n");
	else
		printf("ok!\n");

	return 0;
}

// -------------------------------------------------------------------------
