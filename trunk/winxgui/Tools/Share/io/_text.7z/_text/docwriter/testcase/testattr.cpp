/* -------------------------------------------------------------------------
//	�ļ���		��	attrtestsuit.cpp
//	������		��	����
//	����ʱ��	��	2004-8-15 14:45:00
//	��������	��	
//	$Id: testattr.cpp,v 1.5 2004/09/22 07:29:37 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#include <kso/io/v6/attributes.h>
#include "core/attributes/attrtrans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class SuiteAttr : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(SuiteAttr);
		CPPUNIT_TEST(CaseBasic);
		CPPUNIT_TEST(CaseSpan);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void CaseBasic()
	{
		BEGIN_ATTR(text_font)
			SIM_ATTR(text_font_latin, sprmCRgFtc0, NULL)
		END_ATTR(text_font)

		BEGIN_ATTR(text_r)
			SIM_ATTR(text_bold, sprmCFBold, NULL)
			SUB_ATTR(text_font)
		END_ATTR(text_r)

		ASSERT(ATTRINFO(text_r)->uCount == 2);
		ASSERT(ATTRINFO(text_r)->Item(text_font)->uCount == 1);
	}
	void CaseSpan()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(__X("data/_pm_basic_.doc"), &spRootStg));
		
		KDWDocTarget doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;

//		chpx1.AddPropFix(sprmCFBold, TRUE);
//		chpx1.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
//		chpx2.AddPropFix(sprmCHps, 100);
		papx.AddIstd(0);

		KAttributes Attr, FontAttr;
		FontAttr.AddProp(kso::text_font_color, RGB(0,0,0xff));
		Attr.AddProp(kso::text_font, &FontAttr);
		Attr.AddProp(kso::text_bold, TRUE);
		HRESULT hr = TransSpanAttr(&doc, &Attr, &chpx1);
		ASSERT(SUCCEEDED(hr));

		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x0d"), 2);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}
};

// CPPUNIT_TEST_SUITE_REGISTRATION_DBG(SuiteAttr);


// -------------------------------------------------------------------------
