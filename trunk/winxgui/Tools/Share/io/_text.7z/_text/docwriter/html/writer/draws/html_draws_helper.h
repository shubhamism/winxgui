/* -------------------------------------------------------------------------
//	�ļ���		��	html_draws_helper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 13:31:42
//	��������	��	
//
//	$Id: html_draws_helper.h,v 1.10 2006/11/23 09:49:05 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_DRAWS_HELPER_H__
#define __HTML_DRAWS_HELPER_H__
#include <mso/dom/text/drawing/drawing_helper.h>
#include "htm/length_unit.h"
#include "mso/io/html/writer/include/htmlfile.h"

inline STDMETHODIMP BlipType2Str(WCHAR* btype, ImageFormatType imgType)
{
	switch(imgType)
	{
	case bmp_imgt:
		wcscpy(btype, __X(".bmp"));
		break;
	case dib_imgt:
		wcscpy(btype, __X(".dib"));
		break;
	case emf_imgt:
		wcscpy(btype, __X("emf"));
		break;
	case wmf_imgt:
		wcscpy(btype, __X(".wmf"));
		break;
	case jpg_imgt:
		wcscpy(btype, __X(".jpg"));
		break;
	case png_imgt:
		wcscpy(btype, __X(".png"));		
		break;
	case gif_imgt:
		wcscpy(btype, __X(".png"));
		break;
	case tiff_imgt:
	case exif_imgt:
	case icon_imgt:	
	default:
		wcscpy(btype, __X(".png"));
		ASSERT_ONCE(0);
		break;
	}
	return S_OK;
}

inline STDMETHODIMP_(ImageFormatType) GetImageFormatType(INT blipType)
{
	switch(blipType)
	{
	case msoblipERROR:
	case msoblipUNKNOWN:
	case msoblipPICT:
	case msoblipPNG:
		return png_imgt;
	case msoblipEMF:
		return emf_imgt;
	case msoblipWMF:
		return wmf_imgt;
	case msoblipJPEG:
		return jpg_imgt;	
	case msoblipDIB:
		return dib_imgt;
	case msoblipWBITMAP:
		return bmp_imgt;
	}
	return png_imgt;
}

inline STDMETHODIMP ExportBlip2File(OUT ks_wstring& src_attrval, IN const MsoBlip& blip, IN const ks_wstring& szFileName)
{	
	if(!blip.Good())
	{
		ASSERT_ONCE(0);
		return E_FAIL;
	}
	WCHAR picfile[_MAX_PATH] = __X("");
	WCHAR bid[40] = __X("");
	WCHAR btype[10] = __X("");
	_itow(blip.__GetBlipId(), bid, 10);

	char* blipBits = NULL; UINT cb;	
	blip.Data()->blipBits->Lock((void**)&blipBits, &cb);	
	GUID format;
	INT blipType; ImageFormatType imgType;
	HRESULT hr = _XGdiGetBlipType(blipBits, cb, &blipType, &format);
	if( FAILED(hr) )
		imgType = GetImageFormatType( blip.Data()->blipType );	
	else	
		imgType = _XGdiGetImageFormat(format);
	BlipType2Str(btype, imgType);

	if(!szFileName.empty())
	{
		WCHAR driv[_MAX_DRIVE]=__X(""), dir[_MAX_DIR]=__X(""), fName[_MAX_FNAME]=__X(""), ext[_MAX_EXT]=__X("");
		_wsplitpath(szFileName.c_str(), driv, dir, fName, ext);		
		wcscat(picfile, driv);
		wcscat(picfile, dir);
		UINT fNamePos = wcslen(picfile);			
		wcscat(picfile, fName);
		wcscat(picfile, __X(".files"));		
		CreateDirectory(picfile);
		wcscat(picfile, __X("/"));
		wcscat(picfile, fName);
		wcscat(picfile, bid);		
		wcscat(picfile, btype);
		src_attrval = picfile+fNamePos;
	}
	else
	{			
		GetTempPath(_MAX_PATH, picfile);
		wcscat(picfile, __X("ksohtml\\"));
		CreateDirectory(picfile);		
		wcscat(picfile, __X("clip_image"));
		wcscat(picfile, bid);
		wcscat(picfile, btype);		
		src_attrval = "file:///";
		src_attrval += picfile;
	}
	KWriteArchive wr;
	wr.open(picfile);
	
	ks_wstring strEncoder;
	switch(imgType)
	{
	case none_imgt:	
	case gif_imgt:
	case wmf_imgt:
	case tiff_imgt:
	case dib_imgt:
	case exif_imgt:
	case icon_imgt:
		strEncoder = _XGdiGetEncoderName(png_imgt);
		break;
	default:		
		wr.put(blipBits, cb);
		wr.close();
		blip.Data()->blipBits->Unlock();
		return S_OK;
	}
	ks_stdptr<IStream> gif_strm;	
	if( _XGdiBlipConvert(&gif_strm, blipBits, cb, strEncoder.c_str())
		==Gdiplus::Ok )
	{
		HGLOBAL gif_global;
		GetHGlobalFromStream(gif_strm, &gif_global);		
		LPVOID pData = GlobalLock(gif_global);
		UINT cbData = GlobalSize(gif_global);
		wr.put((CHAR*)pData, cbData);
		wr.close();
		blip.Data()->blipBits->Unlock();
	}
	else
	{		
		ASSERT_ONCE(0);
		wr.put(blipBits, cb);
		wr.close();
		blip.Data()->blipBits->Unlock();
		return S_OK;
	}
	return S_FALSE;
}

inline STDMETHODIMP WriteIMGtag(HtmlDirectWriterA* ar, LPCWSTR src_attrval, PixelType cx,PixelType cy)
{
	ar->StartElement(elem_img);
	char bufint[35] = "";
	ar->AddAttribute(htm_attr_width, _itoa(cx, bufint, 10));
	ar->AddAttribute(htm_attr_height, _itoa(cy, bufint, 10));	
	ar->AddAttribute(htm_attr_src, src_attrval);
	return S_OK;
}
#endif /* __HTML_DRAWS_HELPER_H__ */
