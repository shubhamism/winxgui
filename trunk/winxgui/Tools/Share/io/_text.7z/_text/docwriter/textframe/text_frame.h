/* -------------------------------------------------------------------------
//	�ļ���		��	text_frame.h
//	������		��	����
//	����ʱ��	��	2004-8-24 18:07:55
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_FRAME_H__
#define __TEXT_FRAME_H__

#ifndef __TEXT_P_H__
#include "core/text_p.h"
#endif


// -------------------------------------------------------------------------
class KDWDocTarget;
class KTextTableHandler;
class KTextFrameHandler : public KFakeUnknown<KElementHandler>
{
protected:
	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;
	KTextTableHandler* m_tableElement;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	KTextFrameHandler();
	~KTextFrameHandler();

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP EndElement(IN ELEMENTID uElementID);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_FRAME_H__ */
