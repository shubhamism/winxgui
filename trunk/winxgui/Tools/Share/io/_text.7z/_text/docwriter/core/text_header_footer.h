/* -------------------------------------------------------------------------
//	�ļ���		��	text_header_footer.h
//	������		��	����
//	����ʱ��	��	2004-8-22 13:00:07
//	��������	��	
//	$Id: text_header_footer.h,v 1.13 2004/12/27 02:12:26 sunhongqiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_HEADER_FOOTER_H__
#define __TEXT_HEADER_FOOTER_H__

#ifndef __STL_ALGORITHM_H__
#include <stl/algorithm.h>
#endif

#ifndef __DOCTARGET_H__
#include "doctarget.h"
#endif

#ifndef __TEXT_P_H__
#include "text_p.h"
#endif

#ifndef __TEXT_FRAME_H__
#include "textframe/text_frame.h"
#endif

#ifndef __TEXT_TABLE_H__
#include <texttable/text_table.h>
#endif

// -------------------------------------------------------------------------
inline 
static STDMETHODIMP_(HEADERFOOTER_TYPE) MapHeaderFooterType(
	IN UINT32 uElementId)
{
	typedef const ELEMENTID ITEM;
	typedef ITEM* const CPITEM;

	static 
	ITEM s_Map[] =
	{
		text_header_even,
		text_header_odd,
		text_footer_even,
		text_footer_odd,
		text_header_first,
		text_footer_first,
	};
	static 
	CPITEM s_iEnd = s_Map + countof(s_Map);

	CPITEM i = std::find(s_Map, s_iEnd, uElementId);
	return i != s_iEnd ?
		(HEADERFOOTER_TYPE)(std::distance(s_Map, i)) : DW_INVALID_HEADERFOOTER;
}

// -------------------------------------------------------------------------
class KTextHeaderFooter : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;

	KTextFrameHandler* m_frameElement;
	KTextTableHandler* m_tableElement;

public:
	KTextHeaderFooter()
	{
		m_frameElement = NULL;
		m_tableElement = NULL;
	}
	~KTextHeaderFooter()
	{
		delete m_frameElement;
		delete m_tableElement;
	}
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget);
	
public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementId,
		IN KROAttributes* pAttrs);
	STDMETHODIMP EndElement(
		IN ELEMENTID uElementId);
	STDMETHODIMP EnterSubElement(
		 IN ELEMENTID uSubElementID,
		 OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------
inline 
STDMETHODIMP_(void) KTextHeaderFooter::Init(
		IN KDWDocTarget* pDocTarget)
{
	m_pDocTarget = pDocTarget;
}

inline 
STDMETHODIMP KTextHeaderFooter::StartElement(
	IN ELEMENTID uElementId,
	IN KROAttributes* pAttrs)
{
	return m_pDocTarget->EnterHeaderFooter(MapHeaderFooterType(uElementId));
}

inline
STDMETHODIMP KTextHeaderFooter::EndElement(
	IN ELEMENTID uElementId)
{
	return m_pDocTarget->LeaveHeaderFooter();
}

inline 
STDMETHODIMP KTextHeaderFooter::EnterSubElement(
	 IN ELEMENTID uSubElementID,
	 OUT IKElementHandler** ppHandler)
{
	switch(uSubElementID)
	{
	case text_p:
		m_paraElement.Init(m_pDocTarget);
		*ppHandler = &m_paraElement;
		break;
	case text_frame:
		if (m_frameElement == NULL)
		{
			m_frameElement = new KTextFrameHandler;
		}
		m_frameElement->Init(m_pDocTarget);
		*ppHandler = m_frameElement;
		break;
	case kso_schema::text_table:
		if (m_tableElement == NULL)
		{
			m_tableElement = new KTextTableHandler;
		}
		m_tableElement->Init(m_pDocTarget);
		*ppHandler = m_tableElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	};
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------

#endif /* __TEXT_HEADER_FOOTER_H__ */
