/* -------------------------------------------------------------------------
//	�ļ���		��	office_para_style.cpp
//	������		��	����
//	����ʱ��	��	2004-8-17 15:43:16
//	��������	��	
//	$Id: office_para_style.cpp,v 1.16 2006/08/23 02:19:31 chenghui Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_para_style.h"
#include "attributes/attrtrans.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KOfficeParaStyleHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	HRESULT hr = E_FAIL;
	{
		KDWStyleSheet& StyleSheet = m_pDocTarget->GetStyleSheet();

		ATTRVALUE_PTR pVal(NULL);
		UINT uSti = stiUser;
		if (pAttrs->GetIndex(kso::office_style_sti, &pVal) != -1)
			uSti = pVal->lVal;
		if (pAttrs->GetIndex(kso::office_style_name, &pVal) != -1)
		{
			KDWPropBuffer* propPapx = _MsoNew(m_pDocTarget->GetAllocater(), KDWPropBuffer);

			KDWStyle Style;
			hr = StyleSheet.NewStyle(uSti, pVal->bstrVal, mso_sgcParagraph, &Style);
			KS_CHECK(hr);


			// -------------------------------------------------------------
			{
				propPapx->AddIstd(Style.GetIndex());
				hr = TransParaAttr(m_pDocTarget, pAttrs, propPapx);
				KS_CHECK(hr);
				Style.SetSprmList(mso_sgcParagraph, propPapx);
			}
			if (pAttrs->GetIndex(kso::text_r_prop, &pVal) != -1)
			{
				KDWPropBuffer* pPropBuffer = m_pDocTarget->GetPropBuffer();
				hr = TransSpanAttr(m_pDocTarget, (IKAttributes*)pVal->punkVal, pPropBuffer);
				KS_CHECK(hr);
				Style.SetSprmList(mso_sgcCharacter, pPropBuffer);
			}


			// -------------------------------------------------------------
			UINT uStyleId = 0;
			KDWStyleRelation StyleInfo;
			if (pAttrs->GetIndex(kso::office_style_id, &pVal) != -1)
				uStyleId = pVal->lVal;
			KDWStyleIDMap& IdMap = m_pDocTarget->GetPStyleIDMap();
			StyleInfo.nIstd = Style.GetIndex();
			IdMap[uStyleId] = StyleInfo.nIstd;

			if (pAttrs->GetIndex(kso::office_base_style, &pVal) != -1)
				StyleInfo.nBase = pVal->lVal;
			if (pAttrs->GetIndex(kso::office_next_style, &pVal) != -1)
				StyleInfo.nNext = pVal->lVal;
			if (pAttrs->GetIndex(kso::office_link_style, &pVal) != -1)
				StyleInfo.nLink = pVal->lVal;


			// list
			KROAttributes* pAttrLst;
			if(SUCCEEDED(pAttrs->GetByID(kso::text_list_info, &pAttrLst)))
			{
				UINT iLevel = -1;
				if(SUCCEEDED(pAttrLst->GetByID(kso::text_list_level, &iLevel)))
					StyleInfo.nLvl = iLevel;

				UINT uListId;
				if(SUCCEEDED(pAttrLst->GetByID(kso::text_list_id, &uListId)))
					StyleInfo.nLst = uListId;
			}

			// -------------------------------------------------------------
			StyleInfo.pPropBuffer = propPapx;
			StyleInfo.pChgTAB = m_pDocTarget->GetTABMap().NewStyleTAB(uStyleId);
			ASSERT(StyleInfo.pChgTAB);
			MakeChgTAB(pAttrs, StyleInfo.pChgTAB);


			// -------------------------------------------------------------
			m_pInfoMap->push_back(StyleInfo);

		}
		else
		{
			KS_CHECK(hr = E_FAIL);
		}
	}

KS_EXIT:
	return hr;
}


// -------------------------------------------------------------------------
