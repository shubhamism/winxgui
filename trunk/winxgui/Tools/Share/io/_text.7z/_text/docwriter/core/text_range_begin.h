/* -------------------------------------------------------------------------
//	�ļ���		��	text_range_begin.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 21:06:55
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_RANGE_BEGIN_H__
#define __TEXT_RANGE_BEGIN_H__

// -------------------------------------------------------------------------

class KTextRangeBeginHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_RANGE_BEGIN_H__ */
