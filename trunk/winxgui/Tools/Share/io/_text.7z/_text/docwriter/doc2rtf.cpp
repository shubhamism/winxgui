// -------------------------------------------------------------------------
//	�ļ���		��	doc2rtf.cpp
//	������		��	nature(liucong)
//	����ʱ��	��	2005-7-19 ���� 03:02:40
//	��������	��	
//
// -------------------------------------------------------------------------

#include "stdafx.h"
#include <kfc.h>
#include <kso/io/contenthandler.h>
#undef __Xclib
#define __Xclib
#include <kso/io/linklib_docreader.h>
#include <kso/io/linklib_docwriter.h>

#include "testcase/testdoc2rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP_(void) GetFname(LPWSTR szFname, LPCWSTR szFileName)
{
	WCHAR szExt[_MAX_EXT];
	_wsplitpath(szFileName, NULL, NULL, szFname, szExt);
	wcscat(szFname, szExt);
}

STDMETHODIMP_(void) GetDir(LPWSTR szDir, LPCWSTR szFileName)
{
	WCHAR szDrive[_MAX_PATH];
	_wsplitpath(szFileName, szDir, szDrive, NULL, NULL);
	wcscat(szDir, szDrive);
}

STDMETHODIMP_(void) GetDestFname(LPWSTR szDestFname, LPCWSTR szSrcFname, LPCWSTR szDestDir = __X(""))
{	
	WCHAR szFname[_MAX_PATH];
	GetFname(szFname, szSrcFname);
	wcscpy(szDestFname, szDestDir);
	wcscat(szDestFname, szFname);
	wcscat(szDestFname, __X(".rtf"));
}

int main()
{
	if (__argc < 2)
		return -1;
	
	WCHAR szSrcFile[MAX_PATH] = __X("");
	for(INT i=1; i<__argc; ++i)
	{
		wcscat(szSrcFile, __wargv[i]);
		if(i != __argc-1)
			wcscat(szSrcFile, __X(" "));
	}

	WCHAR szDestFile[_MAX_PATH];
	WCHAR szDestdir[_MAX_PATH];
	GetDir(szDestdir, szSrcFile);

	GetDestFname(szDestFile, szSrcFile, szDestdir);

	printf("processing %S ... ", szSrcFile);
	
	HRESULT hr = E_FAIL;
	try
	{
		KConvertDoc2Rtf doc2rtf;
		hr = doc2rtf.convertFile(szSrcFile, szDestFile);
	}
	catch (...)
	{
	}

	if (FAILED(hr))
		printf("failed!\n");
	else
		printf("ok!\n");

	return 0;
}

// -------------------------------------------------------------------------
