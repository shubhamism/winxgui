/* -------------------------------------------------------------------------
//	�ļ���		��	doc2rtf.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2006-4-17 20:26:41
//	��������	��	
//
//	$Id: doc2rtf.cpp,v 1.4 2006/08/25 08:21:15 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "mso/dom/text/drawing/drawing_helper.h"
#include "doc2rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

KConvertDoc2Rtf::KConvertDoc2Rtf() : m_fnCreateSource(NULL), m_fnTerm(NULL), m_hLib(NULL)
{
}

KConvertDoc2Rtf::~KConvertDoc2Rtf()
{
	term();
}

void KConvertDoc2Rtf::term()
{
	if (m_fnTerm)
	{
		m_fnTerm();
		m_fnTerm = NULL;
		m_fnCreateSource = NULL;
	}
	if (m_hLib)
	{
		FreeLibrary(m_hLib);
		m_hLib = NULL;
	}
}

HRESULT KConvertDoc2Rtf::convertFile(
	IN LPCWSTR szSrcFile,
	IN LPCWSTR szRtfFile)
{
	HRESULT hr = E_FAIL;
	if (m_fnCreateSource == NULL)
	{
		m_hLib = LoadLibrary("docreader");
		KS_CHECK_BOOL(m_hLib);
		
		FnInitialize fnInit = (FnInitialize)GetProcAddress(m_hLib, "_dr_Initialize");
		KS_CHECK_BOOL(fnInit);
		
		hr = fnInit();
		KS_CHECK(hr);
		
		m_fnCreateSource = (FnFilterpluginImportCreate)
			GetProcAddress(m_hLib, "filterpluginImportCreate");
		KS_CHECK_BOOLEX(m_fnCreateSource, hr = E_FAIL);
		
		m_fnTerm = (FnTermiate)GetProcAddress(m_hLib, "_dr_Terminate");
	}
	{
		ks_stdptr<IKFilterMediaInit> spInitSrc;
		hr = m_fnCreateSource(_IoFormat_MSWORD8, NULL, &spInitSrc);
		KS_CHECK(hr);
		hr = _kso_FileMediaInit(spInitSrc, szSrcFile, STGM_T_READ);
		KS_CHECK(hr);
		
		ks_stdptr<IKContentSource> spSrc;
		hr = spInitSrc->QI(IKContentSource, &spSrc);
		KS_CHECK(hr);
		
		ks_stdptr<IKFilterMediaInit> spInit;
		hr = filterpluginExportCreate(_IoFormat_RTF, NULL, &spInit);
		KS_CHECK(hr);
		hr = _kso_FileMediaInit(spInit, szRtfFile, STGM_G_CREATE);
		KS_CHECK(hr);
		
		ks_stdptr<IKContentHandler> spAcc;
		hr = spInit->QI(IKContentHandler, &spAcc);
		KS_CHECK(hr);
		
		hr = spSrc->Transfer(spAcc);
		spSrc->Close();
		ASSERT_OK(hr);
	}
KS_EXIT:
	return hr;
}

EXPORTAPI ConvertDoc2Rtf(IN LPCWSTR szSrcFile, IN LPCWSTR szRtfFile)
{
	KConvertDoc2Rtf doc2rtf;
	ULONG_PTR token = _XGdiplusStartup();
	HRESULT hr = doc2rtf.convertFile(szSrcFile, szRtfFile);
	_XGdiplusShutdown(token);
	return hr;		 
}