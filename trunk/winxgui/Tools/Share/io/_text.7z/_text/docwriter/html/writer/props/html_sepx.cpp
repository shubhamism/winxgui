/* -------------------------------------------------------------------------
//	�ļ���		��	html_sepx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-12 15:23:49
//	��������	��	
//
//	$Id: html_sepx.cpp,v 1.4 2006/08/25 08:21:15 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htm/length_unit.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "mso/io/css/sectionpr2cssprop.h"
#include "html_sepxhelper.h"
#include "html_sepx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) Sectpr2Css(HtmlWSectionPr* p, CssPropBuffer* cssprop)
{
	HtmlWSectionPr::MaskType* mask = &p->mask;
	cssprop->AddLength(cssprop_margin_top, p->dyaTop, lu_pt);
	cssprop->AddLength(cssprop_margin_bottom, p->dyaBottom, lu_pt);
	cssprop->AddLength(cssprop_margin_left, p->dxaLeft, lu_pt);
	cssprop->AddLength(cssprop_margin_right, p->dxaRight, lu_pt);
	cssprop->AddLength(cssprop_size, twip_to_pt(p->xaPage), lu_pt, " ");
	cssprop->AddLength(cssprop_none, twip_to_pt(p->yaPage), lu_pt);
	cssprop->AddLength(cssprop_layout_grid, twip_to_pt(p->dyaLinePitch), lu_pt, " ");
	cssprop->AddLength(cssprop_none, twip_to_pt(p->dxtCharSpace), lu_pt);
}

STDMETHODIMP_(void) _GenerateSelector(ks_string& sel, INT iSect)
{
	sel = "div.Section";
	char buf[35] = "";
	itoa(iSect, buf, 10);
	sel.append(buf);
}

STDMETHODIMP_(void) _GenerateClass(ks_string& cls, INT iSect)
{
	cls = "Section";
	char buf[35] = "";
	itoa(iSect, buf, 10);
	cls.append(buf);
}

STDMETHODIMP_(void) HtmlWSepxWriter::WriteCss(HtmlWGlobalInfo* info, KDWSection* sect, INT iSect)
{
	if(sect)
	{
		HtmlWSectionPr sectPr;
		sectPr.Sprms2SectionPr(&sect->prop);
		CssPropBuffer cssprop;
		ks_string sel;
		_GenerateSelector(sel, iSect);
		cssprop.InsertString(sel.c_str(), sel.size());
		cssprop.StartBlock();
		SectionPr2Cssprop(&sectPr, &cssprop, DefalutDelim);
		cssprop.EndBlock();	
		cssprop.Write(info->ar);
	}	
}

STDMETHODIMP_(void) HtmlWSepxWriter::Write(HtmlWGlobalInfo* info, KDWSection* sect, INT iSect)
{
	ks_string szClass;
	_GenerateClass(szClass, iSect);
	info->ar->AddAttribute(htm_attr_class, szClass);
}

