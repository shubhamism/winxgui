/* -------------------------------------------------------------------------
//	�ļ���		��	spanattr.cpp
//	������		��	����
//	����ʱ��	��	2004-8-15 14:45:39
//	��������	��	
//
//	$Id: spanattr.cpp,v 1.35 2006/08/22 09:31:19 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attrtrans.h"
#include "stocktrans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
using namespace kso_text;
using namespace DWAttrOp;

// -------------------------------------------------------------------------
// trans

//STDMETHODIMP AttrTransLanguage(
//	IN KDWDocTarget* pTarget,
//	IN IKAttributes* pAttrVal,
//	IN KDWPropBuffer* pBuf)
//{
//	ATTRVALUE_PTR pAttrLang;
//	if (((IKAttributes*)pAttrVal)->GetIndex(kso::text_language, &pAttrLang) == -1)
//		return S_OK;
//
//	ASSERT(pAttrLang->vt == ATTRVALUE::vtAttrList);
//	IKAttributes* pAttr = (IKAttributes*)pAttrLang->punkVal;
//	ASSERT(pAttr);
//	
//	ATTRVALUE_PTR pAttrLid0(NULL);
//	if (pAttr->GetIndex(kso::text_lang_notfareast, &pAttrLid0) != -1)
//	{
//		if (pAttrLid0->lVal)
//		{
//			pBuf->ForceAddPropFix(sprmCRgLid0, pAttrLid0->lVal);
//			pBuf->ForceAddPropFix(sprmCRgLid0Ex, pAttrLid0->lVal);
//		}
//	}
//	ATTRVALUE_PTR pAttrLid1(NULL);
//	if (pAttr->GetIndex(kso::text_lang_fareast, &pAttrLid1) != -1)
//	{
//		if (pAttrLid1->lVal)
//		{
//			pBuf->ForceAddPropFix(sprmCRgLid1, pAttrLid1->lVal);
//			pBuf->ForceAddPropFix(sprmCRgLid1Ex, pAttrLid1->lVal);
//		}
//	}
//	return S_OK;
//}

STDMETHODIMP AttrTransFontRef(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtI4);
	KDWFontIDMap const& FontMap = pTarget->GetFontIDMap();
	KDWFontIDMapIt i = FontMap.find(pAttrVal->lVal);
	if (i != FontMap.end())
	{
		pBuf->ForceAddPropFix(sprmOp, (*i).second);
	}
	return S_OK;
}

STDMETHODIMP AttrTransUnderLine(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	ATTRVALUE_PTR pAttrWord(NULL);
	if (pAttr->GetIndex(kso::text_underline_word, &pAttrWord) != -1)
	{
		if (pAttrWord->lVal)
		{
			pBuf->ForceAddPropFix(sprmOp, ulByWord);
			return S_OK;
		}
	}
	ATTRVALUE_PTR pAttrType(NULL);
	if (pAttr->GetIndex(kso::text_underline_type, &pAttrType) != -1)
	{
		pBuf->ForceAddPropFix(sprmOp, pAttrType->lVal);
		return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP AttrTransChange(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);
	UINT16 sprmOpAuthor;
	UINT16 sprmOpDate;
	HRESULT hrRet = IO_S_ATTR_CONTINUE;

	ATTRVALUE_PTR pAttrType(NULL);
	if (pAttr->GetIndex(kso::office_change_type, &pAttrType) != -1)
	{
		if (pAttrType->lVal == ctDelete)
		{
			pBuf->ForceAddPropFix(sprmCFRMarkDel, 0x81);
			sprmOpAuthor = sprmCIbstRMarkDel;
			sprmOpDate = sprmCDttmRMarkDel;
		}
		else if (pAttrType->lVal == ctInsert)
		{
			pBuf->ForceAddPropFix(sprmCFRMark, 0x81);
			sprmOpAuthor = sprmCIbstRMark;
			sprmOpDate = sprmCDttmRMark;
		}

		hrRet = S_OK;
	}
	else
		return hrRet;

	ATTRVALUE_PTR pAttrAuthor(NULL);
	if (pAttr->GetIndex(kso::office_change_author, &pAttrAuthor) != -1)
	{
		HRESULT hr;
		UINT uUserID;
		hr = pTarget->RevisionUserIDLookup(pAttrAuthor->lVal, &uUserID);
		if (hr != S_OK)
			return hr;
		pBuf->ForceAddPropFix(sprmOpAuthor, uUserID);
	}
	
	ATTRVALUE_PTR pAttrDate(NULL);
	if (pAttr->GetIndex(kso::office_change_date, &pAttrDate) != -1)
	{
		KDateTime Date(pAttrDate->date);
		DTTM dttm;
		dttm.yr   = Date.GetYear() - 1900;
		dttm.mon  = Date.GetMonth();
		dttm.dom  = Date.GetDay();
		dttm.wdy  = Date.GetDayOfWeek();
		dttm.hr   = Date.GetHour();
		dttm.mint = Date.GetMinute();

		pBuf->ForceAddPropFix(sprmOpDate, (INT&)dttm);
	}
	
	return hrRet;
}

STDMETHODIMP AttrTransFitText(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtI4);
	
	FITTEXT fitText = {0};
	fitText.value = pAttrVal->lVal;
	pBuf->AddPropVar(
		sprmOp, &fitText, sizeof(FITTEXT)
		);

	return S_OK;
};

STDMETHODIMP AttrTransAsianLayout(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);

	KROAttributes* attr = 
		(KROAttributes*)pAttrVal->punkVal;

	union
	{
		UINT value;
		
		ASIANLAYOUT_TYPE asianLytType;
		TWOINONE_BRACKETS_TYPE bracketsType;
		HORZVERT_COMPRESS_TYPE compressType;
	};

	if (attr)
	{
		if (SUCCEEDED(
			attr->GetByID(kso::text_AsianLayoutType, &value))
			)
		{
			ASIANLAYOUT lyt = {0};
			lyt.type = asianLytType;

			switch (lyt.type)
			{
			case mso_asianLayoutCombine:
				if (SUCCEEDED(attr->GetByID(kso::text_BracketsType, &value)))
					lyt.brackets = bracketsType;
				break;
			case mso_asianLayoutHorzVert:
				if (SUCCEEDED(attr->GetByID(kso::text_Compress, &value)))
					lyt.compress = compressType;
				break;
			}

			pBuf->AddPropVar(sprmOp, &lyt, sizeof(ASIANLAYOUT));
		}
	}

	return S_OK;
};

// -------------------------------------------------------------------------
UINT /*const*/ EnumPrScript[] = /* д��const��಻����ft */
{
// ���ö�ٵ�Ȼ�ɲ�ת������һ����
	0,
	1,
	2,
};

// -------------------------------------------------------------------------
// schema
BEGIN_ATTR(text_font)
	SIM_ATTR(text_font_latin,		sprmCRgFtc0,	AttrTransFontRef)
	SIM_ATTR(text_font_asian,		sprmCRgFtc1,	AttrTransFontRef)
	SIM_ATTR(text_font_complex,		sprmCRgFtc2,	AttrTransFontRef)
	SIM_ATTR(text_font_color,		sprmCIco,		AttrTransIco)
	SIM_ATTR(text_font_color,		sprmCCusColor,	AttrTransRGB)
	SIM_ATTR(text_font_size,		sprmCHps,		AttrTransTwip2HP)
	SIM_ATTR(text_use_font,			sprmCIdctHint,	AttrTransFixDefault)
END_ATTR(text_font)

BEGIN_ATTR(text_emphasize)
	SIM_ATTR(text_emphasize_type,	sprmCKcd,		AttrTransFixDefault)
END_ATTR(text_emphasize)

BEGIN_ATTR(text_underline)
	SIM_ATTR(text_underline_color,	sprmCKulColor,	AttrTrans<Color>::AddFix)
END_ATTR(text_underline)

BEGIN_ATTR(text_language)
	SIM_ATTR(text_lang_notfareast,	sprmCRgLid0,	AttrTransFixDefaultDual(sprmCRgLid0Ex))
	SIM_ATTR(text_lang_fareast,		sprmCRgLid1,	AttrTransFixDefaultDual(sprmCRgLid1Ex))
END_ATTR(text_language)

//BEGIN_ATTR(office_change)
//	SIM_ATTR(office_change_type,	sprmCFRMarkDel,		AttrTransChangeDel)
//	SIM_ATTR(office_change_type,	sprmCFRMark,		AttrTransChangeIns)
//	SIM_ATTR(office_change_author,	sprmCIbstRMarkDel,	AttrTransChangeDel)
//	SIM_ATTR(office_change_author,	sprmCIbstRMark,		AttrTransChangeIns)
//	SIM_ATTR(office_change_date,	sprmCDttmRMarkDel,	AttrTransChangeDel)
//	SIM_ATTR(office_change_date,	sprmCDttmRMark,		AttrTransChangeIns)
//END_ATTR(office_change)

BEGIN_ATTR(text_r)
	// simple attr
	SIM_ATTR(text_bold,				sprmCFBold,			AttrTransFixDefault)
	SIM_ATTR(text_italic,			sprmCFItalic,		AttrTransFixDefault)
	SIM_ATTR(text_vanish,			sprmCFVanish,		AttrTransFixDefault)
	SIM_ATTR(text_r_outline,		sprmCFOutline,		AttrTransFixDefault)
	SIM_ATTR(text_strike,			sprmCFStrike,		AttrTransFixDefault)
	SIM_ATTR(text_double_strike,	sprmCFDStrike,		AttrTransFixDefault)
	SIM_ATTR(text_relief,			sprmCFImprint,		AttrTransFixDefault)
	SIM_ATTR(text_shadow,			sprmCFShadow,		AttrTransFixDefault)
	SIM_ATTR(text_char_snap_to_grid,sprmCFUsePgsuSettings, AttrTransFixDefault)
	SIM_ATTR(text_letter_spacing,	sprmCDxaSpace,		AttrTransFixDefault)
	SIM_ATTR(text_small_caps,		sprmCFSmallCaps,	AttrTransFixDefault)
	SIM_ATTR(text_capital,			sprmCFCaps,			AttrTransFixDefault)
	SIM_ATTR(text_letter_kerning,	sprmCHpsKern,		AttrTransTwip2HP)
	SIM_ATTR(text_text_scale,		sprmCCharScale,		AttrTransPercent)
	SIM_ATTR(text_r_script_position,sprmCIss,			AttrTrans< LM(EnumPrScript) >::AddFix)
	SIM_ATTR(text_r_position,		sprmCHpsPos,		AttrTransTwip2HP)
	SIM_ATTR(text_highlight,		sprmCHighlight,		AttrTrans<Ico>::AddFix)
	SIM_ATTR(text_FitText,			sprmCFitText,		AttrTransFitText)
	SIM_ATTR(text_AsianLayout,		sprmCAsianLayout,	AttrTransAsianLayout)

	SIM_ATTREX(text_r_fill,		sprmCShd,	AttrTransShd,	
								sprmCShdEx,	AttrTransShdEx)
	SIM_ATTREX(text_r_border,	sprmCBrc,	AttrTransBrc,	
								sprmCBrcEx,	AttrTransBrcEx)

	// sub attr
	SUB_ATTR(text_font)
	SUB_ATTR(text_emphasize)
	SUB_ATEX(text_underline, sprmCKul, AttrTransUnderLine)
	SUB_ATTR(text_language)
	SIM_ATTR(office_change_insertion, sprmCFRMark, AttrTransChange)
	SIM_ATTR(office_change_deletion,  sprmCFRMark, AttrTransChange)
END_ATTR(text_r)

// -------------------------------------------------------------------------
STDMETHODIMP TransSpanAttr(
	IN KDWDocTarget* pTarget,
	IN IKAttributes* pAttr,
	IN KDWPropBuffer* pPropBuf)
{
	VERIFY_OK(ParseAttrInfo(ATTRINFO(text_r), pTarget, pAttr, pPropBuf));

//	VERIFY_OK(AttrTransLanguage(pTarget, pAttr, pPropBuf));

	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: spanattr.cpp,v $
// Revision 1.35  2006/08/22 09:31:19  wangdong
// ��д��С�ʹ�д��ɾ���߷���ʽ��
//
// Revision 1.34  2006/08/21 08:17:41  wangdong
// ��д��С�ʹ�д����ʽ��
//
// Revision 1.33  2006/08/09 07:53:35  wangdong
// �������Ӷ�fittext,twoinone,horzvert�Ķ�д֧�֡�
//
// Revision 1.32  2006/05/22 05:57:58  huangjianing
// ���İ�����һ�����غ�����
//
// Revision 1.31  2005/07/28 05:10:36  zhuyie
// �޶����죬֧��ͬһ���ϵĶ���޶���
//
// Revision 1.30  2005/07/12 12:37:22  huangjianing
// ����sprmEx�ĵ���
//
// Revision 1.29  2005/07/07 07:08:50  xushiwei
// ���Զ�ȡ���ݴ���
//
