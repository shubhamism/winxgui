/* -------------------------------------------------------------------------
//	�ļ���		��	testdocwriter.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-14 10:58:00
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if defined(_DEBUG)
#include "testdocwriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#ifdef X_ENCODE_UCS2
#define testXml2DocFile(from, to)											\
	m_xml2doc.convert(														\
		L"../testcase/docrw/" L ## from,									\
		L"../testcase/output/" L ## to )
#define testDoc2DocFile(from, to)											\
	m_doc2doc.convert(														\
		L"../testcase/docrw/" L ## from,									\
		L"../testcase/output/" L ## to )
#else
#define testXml2DocFile(from, to)											\
	m_xml2doc.convert(														\
		__X("../testcase/docrw/" from),									\
		__X("../testcase/output/" to )
#define testDoc2DocFile(from, to)											\
	m_doc2doc.convert(														\
		__X("../testcase/docrw/" from),									\
		__X("../testcase/output/" to )
#endif

#define DW_CPPUNIT_TEST(Test)												\
	CPPUNIT_TEST(Test);														\
	++m_nRef

// -------------------------------------------------------------------------
//--> ��ʹ��testdocwriter2.cpp��
//	��Ϊ�����������wpsʹ��docreader�����̲�̫һ����testdocwriter2.cpp�����ܹ���ӳ���⡣
//CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestDocWriter);

class TestDocWriter : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestDocWriter);
		//DW_CPPUNIT_TEST(CaseEmb);
		//DW_CPPUNIT_TEST(CaseDrawing);
		DW_CPPUNIT_TEST(CaseTextTable);
		DW_CPPUNIT_TEST(CaseChpx);
		DW_CPPUNIT_TEST(CasePapx);
		DW_CPPUNIT_TEST(CaseSepx);
		DW_CPPUNIT_TEST(CaseAutoNum);
		DW_CPPUNIT_TEST(CaseBkmk);
		DW_CPPUNIT_TEST(CaseHeaderFooter);
		DW_CPPUNIT_TEST(CaseField);
		DW_CPPUNIT_TEST(CaseHyperlink);
		DW_CPPUNIT_TEST(CaseSymbol);
		DW_CPPUNIT_TEST(CaseBullet);
	CPPUNIT_TEST_SUITE_END();

private:
	KConvertXml2Doc m_xml2doc;
	static KConvertDoc2Doc m_doc2doc;
	static UINT m_nRef;
	
public:
	void setUp() {}
	void tearDown()
	{
		if (--m_nRef == 0)
			m_doc2doc.term();
	}

public:
	void CaseEmb()
	{
		testDoc2DocFile("emb/fill.doc", "_emb_fill_.doc");
	}
	void CaseField()
	{
		testDoc2DocFile("field/datetime.doc", "_fld_datetime_.doc");
		testDoc2DocFile("field/���İ�ʽ.doc", "_fld_���İ�ʽ_.doc");
		//testDoc2DocFile("field/toc.doc", "_fld_toc_.doc");
	}
	void CaseBkmk()
	{
		testDoc2DocFile("bookmark/bookmark.doc", "_bkmk_simple_.doc");
	}
	void CaseChpx()
	{
		testDoc2DocFile("core/chpx.doc", "_core_chpx_.doc");
	}
	void CasePapx()
	{
		testDoc2DocFile("core/papx.doc", "_core_papx_.doc");
	}
	void CaseSepx()
	{
		testDoc2DocFile("core/sepx.doc", "_core_sepx_.doc");
	}
	void CaseAutoNum()
	{
		testDoc2DocFile("autonum/autonum.doc", "_autonum_autonum_.doc");
	}
	void CaseDrawing()
	{
		testDoc2DocFile("draw/draw_art.doc", "_draw_art.doc");
		testDoc2DocFile("draw/draw_simple.doc", "_draw_simple_.doc");
		testDoc2DocFile("draw/draw_textbox.doc", "_draw_textbox_.doc");
		testDoc2DocFile("draw/draw_textbox_linked.doc", "_draw_textbox_linked_.doc");
		testDoc2DocFile("draw/draw_textbox_linked2.doc", "_draw_textbox_linked2_.doc");
		testDoc2DocFile("draw/draw_textbox_linked3.doc", "_draw_textbox_linked3_.doc");
	}
	void CaseHeaderFooter()
	{
		testDoc2DocFile("core/headerfooter.doc", "_core_headerfooter_.doc");
	}
	void CaseTextTable()
	{
		testDoc2DocFile("texttable/table_simple.doc", "_table_simple_.doc");
	}
	void CaseHyperlink()
	{
		testDoc2DocFile("field/hyperlink.doc", "_fld_hyperlink_.doc");
	}
	void CaseSymbol()
	{
		testDoc2DocFile("core/symbol.doc", "_core_symbol_.doc");
	}
	void CaseBullet()
	{
		testDoc2DocFile("autonum/ͼƬ���.doc", "_autonum_ͼƬ���_.doc");
		testDoc2DocFile("autonum/����ͼƬ���.doc", "_autonum_����ͼƬ���_.doc");
		testDoc2DocFile("autonum/�ż�ͼƬ���.doc", "_autonum_�ż�ͼƬ���_.doc");
	}
};

KConvertDoc2Doc TestDocWriter::m_doc2doc;

UINT TestDocWriter::m_nRef;

//--> ��ʹ��testdocwriter2.cpp��
//	��Ϊ�����������wpsʹ��docreader�����̲�̫һ����testdocwriter2.cpp�����ܹ���ӳ���⡣
//CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestDocWriter);

// -------------------------------------------------------------------------

#endif // defined(_DEBUG)
