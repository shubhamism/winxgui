/* -------------------------------------------------------------------------
//	�ļ���		��	document.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:56:46
//	��������	��	
//
//	$Id: document.h,v 1.3 2006/02/18 07:33:32 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOCUMENT_H__
#define __DOCUMENT_H__
#include "range/bookmarks.h"
#include "styleshelper.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWRangesWriter;
class RtfWBookmarkStartsWriter;
class RtfWBookmarkEndsWriter;
class RtfDirectWriter;
class RtfWDocumentWriter
{
public:	
	RtfWDocumentWriter(KDWDocument* doc);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);	
private:	
	STDMETHODIMP _SetBookmarks(KDWBookmarkStarts& bkStarts, KDWBookmarkEnds& bkEnds, RtfWBookmarkStartsWriter& wrBkmkStarts, RtfWBookmarkEndsWriter& wrBkmkEnds, RtfWRangesWriter* wrRange, SUBDOC_TYPE subdoc);	
private:	
	KDWDocument* m_doc;
};
// -------------------------------------------------------------------------
//	$Log: document.h,v $
//	Revision 1.3  2006/02/18 07:33:32  xulingjiao
//	�޸�BUG
//	
//	Revision 1.2  2006/01/20 08:42:55  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:51  xulingjiao
//	*** empty log message ***
//	

#endif /* __DOCUMENT_H__ */
