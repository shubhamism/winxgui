/* -------------------------------------------------------------------------
//	�ļ���		��	office_para_style.h
//	������		��	����
//	����ʱ��	��	2004-8-17 15:43:13
//	��������	��	
//	$Id: office_para_style.h,v 1.3 2004/10/06 07:12:57 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_PARA_STYLE_H__
#define __OFFICE_PARA_STYLE_H__

#include "office_styles_base.h"

// -------------------------------------------------------------------------
class KOfficeParaStyleHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KDWStyleInfoMap* m_pInfoMap;
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget,
		IN KDWStyleInfoMap* pMap)
	{
		m_pDocTarget = pDocTarget;
		m_pInfoMap = pMap;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_PARA_STYLE_H__ */
