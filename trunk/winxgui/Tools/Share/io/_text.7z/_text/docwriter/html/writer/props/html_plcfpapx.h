/* -------------------------------------------------------------------------
//	�ļ���		��	html_plcfpapx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:09:07
//	��������	��	
//
//	$Id: html_plcfpapx.h,v 1.8 2006/06/29 05:43:57 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_PLCFPAPX_H__
#define __HTML_PLCFPAPX_H__

#include "html_papx.h"
#include "html_texttable.h"
#include "mso/io/css/cssbuffer.h"

class HtmlWGlobalInfo;
class HtmlWPapxsWriter
{
private:
	const KDWPlcfPapx* m_papxs;
	HtmlWGlobalInfo* m_ginfo;

	KDWPlcfPapx::Enumerator m_enumer;	
	
	HtmlWPapxWriter m_wrPapx;
	HtmlWTablesWriter m_wrTbls;
	CssPropBuffer m_cssprop;
	INT m_current, m_fTblWrite;
	BOOL m_fOpend;
public:
	STDMETHODIMP_(HtmlWPapxWriter&) GetPapInfo();
	STDMETHODIMP_(BOOL&) GetFOpen();
	HtmlWPapxsWriter(const KDWPlcfPapx* papxs, HtmlWGlobalInfo* info);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(UINT) GetIstd(UINT cp);
	STDMETHODIMP_(void) Write();
	STDMETHODIMP_(void) EnsureWriteEnd();
};
#endif /* __HTML_PLCFPAPX_H__ */
