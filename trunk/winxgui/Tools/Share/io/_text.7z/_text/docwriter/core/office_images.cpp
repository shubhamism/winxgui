/* -------------------------------------------------------------------------
//	�ļ���		��	office_images.cpp
//	������		��	����
//	����ʱ��	��	2004-8-30 14:43:11
//	��������	��	
//	$Id: office_images.cpp,v 1.7 2004/11/22 04:48:04 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_images.h"

#include <doctarget.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
/*
STDMETHODIMP KOfficeImagesHandler::EndElement(
	IN ELEMENTID uElementID)
{
	_UpdateBulletData();
	return S_OK;
}

STDMETHODIMP_(VOID) KOfficeImagesHandler::_UpdateBulletData()
{
	KDWBulletArray& Bullets = m_pDocTarget->GetBulletMediums();
	KDWBulletArray::const_iterator i = Bullets.begin();
	for (; i != Bullets.end(); ++i)
	{
		if (!i->second)
			continue;

		_DWCoreImagePoolType::iterator j = m_ImagePool.find(i->first);
		if (j == m_ImagePool.end())
			continue;

		KDWBlip blip = m_pDocTarget->GetBlipStore().NewBlip(
			(__MSO_ESCHER MSOBLIPTYPE)(*j).second.iImageType, (*j).second.spLockBuffer);
		KDWPicBullet PicBullet = m_pDocTarget->GetPicBullets().NewPicBullet(blip);
		i->second->SetPicBullet(PicBullet);
	}
}
*/
// -------------------------------------------------------------------------
