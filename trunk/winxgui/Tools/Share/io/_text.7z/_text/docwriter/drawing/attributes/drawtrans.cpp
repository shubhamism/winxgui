/* -------------------------------------------------------------------------
//	�ļ���		��	drawtrans.cpp
//	������		��	����
//	����ʱ��	��	2004-9-20 15:20:03
//	��������	��	
//
//	$Id: drawtrans.cpp,v 1.16 2006/04/24 01:54:34 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "drawtrans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
static inline
STDMETHODIMP_(VOID) AnchorUDefAttr(
	IN KROAttributes* pAttrs, 
	IN KDWShapeOPT& optUDef)
{
	KROAttributes* pPosAttrs = NULL;
	if (SUCCEEDED(pAttrs->GetByID(text_anchor_position, &pPosAttrs)))
	{
		int val;
		if (SUCCEEDED(pPosAttrs->GetByID(kso::text_anchor_hori_align, &val)))
			optUDef.AddPropFix(msopt_horiAlignMode, ConvAnchorHRelPos(val));
		if (SUCCEEDED(pPosAttrs->GetByID(kso::text_anchor_hori_relative_to, &val)))
			optUDef.AddPropFix(msopt_horiRelativeTo, val);
		if (SUCCEEDED(pPosAttrs->GetByID(kso::text_anchor_vert_align, &val)))
			optUDef.AddPropFix(msopt_vertAlignMode, ConvAnchorVRelPos(val));
		if (SUCCEEDED(pPosAttrs->GetByID(kso::text_anchor_vert_relative_to, &val)))
 			optUDef.AddPropFix(msopt_vertRelativeTo, val);
		if (SUCCEEDED(pPosAttrs->GetByID(kso::text_anchor_page_location, &val)))
			optUDef.AddPropFix(ksextopt_spPageLocation, val);
	}

	BOOL wrapTextbox = FALSE;
	if (
		SUCCEEDED(pAttrs->GetByID(kso::text_wrapTextbox, &wrapTextbox)) && 
		wrapTextbox
		)
	{
		optUDef.AddPropFix(ksextopt_wrapTextbox, TRUE);
	}

	BOOL fAllowOverlap = TRUE;
	if (SUCCEEDED(pAttrs->GetByID(text_allow_overlap, &fAllowOverlap)))
		optUDef.AddPropBool(msopt_fAllowOverlap, fAllowOverlap);
	BOOL fLayoutInCell = TRUE;
	if (SUCCEEDED(pAttrs->GetByID(text_layout_incell, &fLayoutInCell)))
		optUDef.ForceAddPropBool(msopt_fLayoutInCell, fLayoutInCell);
}

// -------------------------------------------------------------------------
struct __KDWPoint
{
	INT32 x;
	INT32 y;
};

// -------------------------------------------------------------------------
STDMETHODIMP AttrTransAnchor(
	IN KROAttributes* pAttrs,
	OUT KDWShapeAnchor& Anchor,
	OUT KDWShapeOPT& opt,
	OUT KDWShapeOPT& optUDef,
	OUT UINT& zOrder)
{
	INT cxaWidth, cyaHeight;
	if (FAILED( pAttrs->GetByID(text_anchor_width, &cxaWidth) ))
		return E_INVALIDARG;
	if (FAILED( pAttrs->GetByID(text_anchor_height, &cyaHeight) ))
		return E_INVALIDARG;

	BOOL fLock = FALSE;
	pAttrs->GetByID(text_anchor_lock, &fLock);

	INT xaLeft = 0;
	INT yaTop = 0;
	INT xRel = hpMargin;
	INT yRel = vpMargin;

	KROAttributes* pPosAttrs;
	if (SUCCEEDED( pAttrs->GetByID(text_anchor_position, &pPosAttrs) ))
	{
		pPosAttrs->GetByID(text_anchor_hori_position, &xaLeft);
		pPosAttrs->GetByID(text_anchor_hori_relative_to, &xRel);
		pPosAttrs->GetByID(text_anchor_vert_position, &yaTop);
		pPosAttrs->GetByID(text_anchor_vert_relative_to, &yRel);
	}
	
	INT wrapMode = wmNone;
	INT wrapType = twBoth;
	KROAttributes* pWrAttrs;
	if (SUCCEEDED( pAttrs->GetByID(text_anchor_wrap, &pWrAttrs) ))
	{
		pWrAttrs->GetByID(text_wrap_mode, &wrapMode); // ���ŷ�ʽ
		pWrAttrs->GetByID(text_text_wrap, &wrapType);

		BSTR bstrWP = NULL;
		pWrAttrs->GetByID(text_wrap_path, &bstrWP);
		if (bstrWP)
		{
			const __KDWPoint* pt = (__KDWPoint*)bstrWP;
			MsoArray<__KDWPoint> Array;
			Array.put_ItemData(pt, SysStringLen(bstrWP) / 4);
			opt.AddPropVar(msopt_pWrapPolygonVertices, &Array);
		}
	}

	Anchor.xaLeft = xaLeft;
	Anchor.yaTop = yaTop;
	Anchor.xaRight = xaLeft + cxaWidth;
	Anchor.yaBottom = yaTop + cyaHeight;
	Anchor.xRel = ConvDgXRel(xRel);
	Anchor.yRel = ConvDgYRel(yRel);
	Anchor.wrapMode = ConvDgWrapMode(wrapMode);
	Anchor.wrapType = ConvDgWrapType(wrapType);
	Anchor.fAnchorLock = fLock;

	pAttrs->GetByID(text_z_index, &zOrder);

	BOOL fBehindDocument = FALSE;
	if (SUCCEEDED(pAttrs->GetByID(text_anchor_behind, &fBehindDocument)))
		opt.AddPropBool(msopt_fBehindDocument, fBehindDocument);

	KROAttributes* pAttrMargin = NULL;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_anchor_margin, &pAttrMargin)))
	{
		INT val;
		if (SUCCEEDED(pAttrMargin->GetByID(kso::text_anchor_margin_left, &val)))
			opt.AddPropFix(msopt_dxWrapDistLeft, val * 635);
		if (SUCCEEDED(pAttrMargin->GetByID(kso::text_anchor_margin_top, &val)))
			opt.AddPropFix(msopt_dyWrapDistTop, val * 635);
		if (SUCCEEDED(pAttrMargin->GetByID(kso::text_anchor_margin_right, &val)))
			opt.AddPropFix(msopt_dxWrapDistRight, val * 635);
		if (SUCCEEDED(pAttrMargin->GetByID(kso::text_anchor_margin_bottom, &val)))
			opt.AddPropFix(msopt_dyWrapDistBottom, val * 635);
 	}

	AnchorUDefAttr(pAttrs, optUDef);

	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: drawtrans.cpp,v $
// Revision 1.16  2006/04/24 01:54:34  xulingjiao
//
// �޸�23432�ŵ�BUG
//
// Revision 1.15  2006/04/03 07:45:46  huangjianing
// ��������֧�ֱ���Ԫ���еİ�ʽ
//
// Revision 1.14  2005/08/24 01:42:19  rongjianxing
// *** empty log message ***
//
// Revision 1.13  2005/08/23 08:42:49  rongjianxing
// ���϶��������ص������ԵĴ���
//
// Revision 1.12  2005/08/18 08:27:35  wangdong
// �����˶��󴴽������̣������˶�InlineShape��EmbPic����⡣
//
// Revision 1.11  2005/06/30 04:15:21  xushiwei
// bug# 17689 ���� - fixed��
//
// Revision 1.10  2005/05/08 06:39:35  wangdong
// ������һ����չ�������ԣ��ı����������Ƿ����š�
//
// Revision 1.9  2004/12/17 08:14:09  xushiwei
// Ϊ֧�־ɰ汾wps��ҳ���������msopt_spPageLocation��չ����(optUDef)��
// �м������anchor����: text_anchor_page_location��
//
