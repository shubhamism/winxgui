/* -------------------------------------------------------------------------
//	�ļ���		��	fonttable.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:52:03
//	��������	��	
//
//	$Id: fonttable.cpp,v 1.3 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "font.h"
#include "fonttable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) RtfWFontTableWriter::Write(RtfDirectWriter* ar, const KDWFontTable* p)
{
	const _Target* t = _Target::Cast(p);

	INT count = t->Count();
	if (count <= 0)
		return;

	ar->StartGroup(rtf_fonttbl);

	RtfWFontWriter font;
	for (INT i = 0; i < count; ++i)
	{
		font.Write(ar, t->GetArray()->at(i), i);
	}

	ar->EndGroup();
}