/* -------------------------------------------------------------------------
//	�ļ���		��	drawtrans.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-20 17:49:06
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DRAWTRANS_H__
#define __DRAWTRANS_H__

using namespace kso_text;
using namespace mso_escher;

// -------------------------------------------------------------------------

__forceinline
STDMETHODIMP_(FSPA_XREL) ConvDgXRel(INT /*enumHPOS*/ xRel)
{
/*	hpMargin	=	0,
	hpPage		=	1,
	hpColumn    =	2,
	hpChar      =   3,
*/
	ASSERT(xRel < 4);
	return (FSPA_XREL)(xRel < 4 ? xRel : 0);
}

__forceinline
STDMETHODIMP_(FSPA_YREL) ConvDgYRel(UINT /*enumVPOS*/ yRel)
{
/*	vpMargin	=	0,
	vpPage		=	1,
	vpParagraph	=   2,
	vpLine		=	3,
*/
	ASSERT(yRel < 4);
	return (FSPA_YREL)(yRel < 4 ? yRel : 0);
}

__forceinline
STDMETHODIMP_(FSPA_TEXTWRAP) ConvDgWrapMode(UINT /*enumWRAPMODE*/ wrapMode)
{
/*	wmTopBottom =   0,  // ����
	wmSquare    =   1,  // ������
	wmNone		=	2,	// ������
	wmThrough   =   3,  // ��Խ��  
	wmTight     =   4,  // ������  
*/
	ASSERT(wrapMode < 5);
	const FSPA_TEXTWRAP g_wrapModes[] =
	{
		mso_spaWrTopBottom,
		mso_spaWrSquare,
		mso_spaWrNone,
		mso_spaWrThrough,
		mso_spaWrTight,
	};
	return wrapMode < 5 ? g_wrapModes[wrapMode] : mso_spaWrSquare;
}

__forceinline
STDMETHODIMP_(FSPA_TEXTWRAPTYPE) ConvDgWrapType(UINT /*enumTEXTWRAP*/ wrapType)
{
/*	twBoth		=	0,	// both sides
	twLeft		=	1,	// left only
	twRight		=	2,	// right only
	twLargest	=	3,	// larest side only
*/
	ASSERT(wrapType < 4);
	return (FSPA_TEXTWRAPTYPE)(wrapType < 4 ? wrapType : 0);
}

__forceinline
STDMETHODIMP_(INT) ConvAnchorHRelPos(UINT /*enumTEXTWRAP*/ relPos)
{
	INT const Pos[] =
	{
		mso_anchorHRelLeft,
		mso_anchorHRelLeft,	
		mso_anchorHRelRight,
		mso_anchorHRelCenter,
		mso_anchorHRelInner,
		mso_anchorHRelOutter,
	};
	
	ASSERT(relPos > 0 && relPos < countof(Pos));
	return relPos < countof(Pos) ? Pos[relPos] : Pos[0];
}

__forceinline
STDMETHODIMP_(INT) ConvAnchorVRelPos(UINT /*enumTEXTWRAP*/ relPos)
{
	INT const Pos[] =
	{
		mso_anchorVRelTop,
		mso_anchorVRelTop,	
		mso_anchorVRelCenter,
		mso_anchorVRelBottom,
		mso_anchorVRelInner,
		mso_anchorVRelOutter,
	};
	
	ASSERT(relPos > 0 && relPos < countof(Pos));
	return relPos < countof(Pos) ? Pos[relPos] : Pos[0];
}

// -------------------------------------------------------------------------
STDMETHODIMP AttrTransAnchor(
	IN KROAttributes* pAttrs,
	OUT KDWShapeAnchor& Anchor,
	OUT KDWShapeOPT& opt,
	OUT KDWShapeOPT& optUDef,
	OUT UINT& zOrder);

// -------------------------------------------------------------------------

#endif /* __DRAWTRANS_H__ */
