/* -------------------------------------------------------------------------
//	�ļ���		��	font.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:49:50
//	��������	��	
//
//	$Id: font.cpp,v 1.4 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "font.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfControl RtfWFontWriter::GetFamilyEnum(UINT family)
{
	typedef struct { UINT family; RtfControl em; } ItemType;
	
	static ItemType s_items[] = 
	{
		FF_DONTCARE		>> 4,	rtf_fnil,
		FF_ROMAN		>> 4,	rtf_froman,
		FF_SWISS		>> 4,	rtf_fswiss,
		FF_MODERN		>> 4,	rtf_fmodern,
		FF_SCRIPT		>> 4,	rtf_fscript,
		FF_DECORATIVE	>> 4,	rtf_fdecor,
//			FF_TECH			>> 4,	rtf_ftech,
//			FF_BIDI			>> 4,	rtf_fbidi,
	};

	for (int i = 0; i < countof(s_items); ++i)
	{
		if (s_items[i].family == family)
			return s_items[i].em;
	}
	ASSERT(0);
	return rtf_fnil;
}

STDMETHODIMP_(void) RtfWFontWriter::Write(RtfDirectWriter* ar, const _DW_FONT* font, INT Id)
{
	ar->StartGroup(rtf_f, Id);

		ar->AddAttribute(GetFamilyEnum(font->ff));

		ar->AddAttribute(rtf_fcharset, font->chs);
		ar->AddAttribute(rtf_fprq, font->prq);			
		
		ar->StartGroup(rtf_panose, rtf_nilParam, TRUE);
			ar->AddBinary(&font->panose, sizeof(font->panose));
		ar->EndGroup();			

		WCHAR name[66];
		_Helper::GetName(font, name);
		DWORD ciACP = _GetCodePage(font);
		if (name != NULL && wcslen(name) != 0)		
			ar->AddFontName(name, -1, ciACP);

		LPCWSTR altname = _Helper::GetAltName(font);
		if (altname != NULL && wcslen(altname) != 0)
		{
			ar->StartGroup(rtf_falt, rtf_nilParam, TRUE);
				ar->AddFontName(altname, -1, ciACP);
			ar->EndGroup();
		}
		ar->AddContentWcs(__X(";"), 1);
	ar->EndGroup();
}