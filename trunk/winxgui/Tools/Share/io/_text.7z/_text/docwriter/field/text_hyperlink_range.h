/* -------------------------------------------------------------------------
//	�ļ���		��	text_hyperlink_range.h
//	������		��	����
//	����ʱ��	��	2004-8-23 20:29:10
//	��������	��	
//	$Id: text_hyperlink_range.h,v 1.3 2004/10/06 07:12:58 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_HYPERLINK_RANGE_H__
#define __TEXT_HYPERLINK_RANGE_H__

// -------------------------------------------------------------------------
class KHyperlinkBeginHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};	

// -------------------------------------------------------------------------
class KHyperlinkEndHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};	

// -------------------------------------------------------------------------

#endif /* __TEXT_HYPERLINK_RANGE_H__ */
