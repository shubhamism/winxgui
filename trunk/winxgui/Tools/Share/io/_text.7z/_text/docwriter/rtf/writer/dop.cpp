/* -------------------------------------------------------------------------
//	�ļ���		��	dop.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:47:39
//	��������	��	
//
//	$Id: dop.cpp,v 1.9 2006/10/26 07:49:23 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "dop.h"
#include "kso/appfeature/kappfeature.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) RtfWDopWriter::WriteGenerator(RtfDirectWriter* ar)
{		
	ar->StartGroup(rtf_generator, rtf_nilParam, TRUE);
	
	LPCWSTR lpszGenerator = _kso_QueryFeatureContent(kaf_kso_ProductName);
	if (!lpszGenerator)
		lpszGenerator = __X("Kingsoft WPS Office RTF Writer 2005");
	kfc::ks_string szGenerator(lpszGenerator);
	ar->AddContent(szGenerator.c_str(), szGenerator.length());
	
	ar->EndGroup();
}
STDMETHODIMP_(void) RtfWDopWriter::WriteDefPageInfo(RtfDirectWriter* ar)
{
	ar->AddAttribute(rtf_paperw, 12240);
	ar->AddAttribute(rtf_paperh, 15840);
	ar->AddAttribute(rtf_margl, 1800);
	ar->AddAttribute(rtf_margr, 1800);
	ar->AddAttribute(rtf_margt, 1440);
	ar->AddAttribute(rtf_margb, 1440);
	ar->AddAttribute(rtf_gutter, 0);
}
STDMETHODIMP_(void) RtfWDopWriter::WriteDop(RtfDirectWriter* ar, const KDWDocProperties* t)
{
	DopPr refDop;
	Reset(&refDop);	
	WriteDefPageInfo(ar);
	_AddAttributeNotdefval(t->dop.fFacingPages, refDop.fFacingPages, ar, rtf_facingp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.dxaTab, refDop.dxaTab, ar, rtf_deftab, t->dop.dxaTab);
	ar->AddAttribute(GetFpcCtrl(t->dop.fpc), rtf_nilParam);
	ar->AddAttribute(GetEpcCtrl(t->dop.epc), rtf_nilParam);
	_AddAttributeNotdefval(t->dop.fShadeFormData, refDop.fShadeFormData, ar, rtf_formshade, rtf_nilParam);
	// rtf_horzdoc
	_AddAttributeNotdefval(t->dop.dogrid.fFollowMargins, refDop.dogrid.fFollowMargins, ar, rtf_dgmargin, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.dogrid.dxaGrid, refDop.dogrid.dxaGrid, ar, rtf_dghspace, t->dop.dogrid.dxaGrid);
	_AddAttributeNotdefval(t->dop.dogrid.dyaGrid, refDop.dogrid.dyaGrid, ar, rtf_dgvspace, t->dop.dogrid.dyaGrid);
	_AddAttributeNotdefval(t->dop.dogrid.xaGrid, refDop.dogrid.xaGrid, ar, rtf_dghorigin, t->dop.dogrid.xaGrid);
	_AddAttributeNotdefval(t->dop.dogrid.yaGrid, refDop.dogrid.yaGrid, ar, rtf_dgvorigin, t->dop.dogrid.yaGrid);
	_AddAttributeNotdefval(t->dop.dogrid.dxGridDisplay, refDop.dogrid.dxGridDisplay, ar, rtf_dghshow, t->dop.dogrid.dxGridDisplay);
	_AddAttributeNotdefval(t->dop.dogrid.dyGridDisplay, refDop.dogrid.dyGridDisplay, ar, rtf_dgvshow, t->dop.dogrid.dyGridDisplay);
	_AddAttributeNotdefval(t->dop.doptypography.iJustification, 2, ar, GetIJustificationCtrl(t->dop.doptypography.iJustification), t->dop.doptypography.iJustification);
	ar->AddAttribute(rtf_viewkind, t->dop.wvkSaved);
	ar->AddAttribute(rtf_viewscale, t->dop.wScaleSaved);
	_AddAttributeNotdefval(t->dop.wScaleSaved, refDop.wScaleSaved, ar, rtf_viewscale, t->dop.wScaleSaved);
	_AddAttributeNotdefval(t->dop.copts.fShapeLayoutLikeWW8, refDop.copts.fShapeLayoutLikeWW8, ar, rtf_splytwnine, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fFootnoteLayoutLikeWW8, refDop.copts.fFootnoteLayoutLikeWW8, ar, rtf_ftnlytwnine, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fHTMLAutoSpace, refDop.copts.fHTMLAutoSpace, ar, rtf_htmautsp, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fForgetLastTabAlignment, refDop.copts.fForgetLastTabAlignment, ar, rtf_useltbaln, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fLayoutTableRowsApart, refDop.copts.fLayoutTableRowsApart, ar, rtf_alntblind, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fLayoutRawTableWidth, refDop.copts.fLayoutRawTableWidth, ar, rtf_lytcalctblwd, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fAlignTablesRowByRow, refDop.copts.fAlignTablesRowByRow, ar, rtf_lyttblrtgr, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.copts.fUseWord97LineBreakingRules, refDop.copts.fUseWord97LineBreakingRules, ar, rtf_lnbrkrule, rtf_nilParam);	// @tocheck
	_AddAttributeNotdefval(t->dop.zkSaved, refDop.zkSaved, ar, rtf_viewzk, t->dop.zkSaved);
	_AddAttributeNotdefval(t->dop.nfcEdnRef, 0, ar, GetNfcCtrl(t->dop.nfcEdnRef, numberformatctrls::which_dopend), rtf_nilParam);
	_AddAttributeNotdefval(t->dop.iGutterPos, !refDop.iGutterPos, ar, GetIGutterPosCtrl(t->dop.iGutterPos), rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fUseAsianBreakRules, !refDop.copts.fUseAsianBreakRules, ar, rtf_asianbrkrule, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fDontAllowFieldEndSelect, !refDop.copts.fDontAllowFieldEndSelect, ar, rtf_allowfieldendsel, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSnapToGridInCell, !refDop.copts.fSnapToGridInCell, ar, rtf_snaptogridincell, rtf_nilParam);
	

	// ������ЩDOP���Ի�û�м��@todo
	_AddAttributeNotdefval(t->dop.dxaHotZ, refDop.dxaHotZ, ar, rtf_hyphhotz, t->dop.dxaHotZ);
	_AddAttributeNotdefval(t->dop.cConsecHypLim, refDop.cConsecHypLim, ar, rtf_hyphconsec, t->dop.cConsecHypLim);
	_AddAttributeNotdefval(t->dop.fHyphCapitals, refDop.fHyphCapitals, ar, rtf_hyphcaps, t->dop.fHyphCapitals);		
	_AddAttributeNotdefval(t->dop.fAutoHyphen, refDop.fAutoHyphen, ar, rtf_hyphauto, t->dop.fAutoHyphen);
	_AddAttributeNotdefval(t->dop.adt, refDop.adt, ar, rtf_doctype, t->dop.adt);				
	_AddAttributeNotdefval(t->dop.wvkSaved, refDop.wvkSaved, ar, rtf_viewkind, t->dop.wvkSaved);
	_AddAttributeNotdefval(t->dop.nFtn, refDop.nFtn, ar, rtf_ftnstart, t->dop.nFtn);
	_AddAttributeNotdefval(t->dop.nEdn, refDop.nEdn, ar, rtf_aftnstart, t->dop.nEdn);
	_AddAttributeNotdefval(t->dop.rncFtn, refDop.rncFtn, ar, GetRncFtnCtrl(t->dop.rncFtn), rtf_nilParam);
	_AddAttributeNotdefval(t->dop.mcEdn, refDop.mcEdn, ar, GetMcEdnCtrl(t->dop.mcEdn), rtf_nilParam);
	_AddAttributeNotdefval(t->dop.nfcFtnRef, refDop.nfcFtnRef, ar, GetNfcCtrl(t->dop.nfcFtnRef, numberformatctrls::which_dopfnd), rtf_nilParam);				
	_AddAttributeNotdefval(t->dop.fMirrorMargins, refDop.fMirrorMargins, ar, rtf_margmirror, t->dop.fMirrorMargins);
	_AddAttributeNotdefval(t->dop.fWidowControl, refDop.fWidowControl, ar, rtf_widowctrl, t->dop.fWidowControl);
	_AddAttributeNotdefval(t->dop.doptypography.f2on1, refDop.doptypography.f2on1, ar, rtf_twoonone, t->dop.doptypography.f2on1);
	_AddAttributeNotdefval(t->dop.fLinkStyles, refDop.fLinkStyles, ar, rtf_linkstyles, t->dop.fLinkStyles);
	if(t->dop.fFormNoFields && t->dop.fProtEnabled)
		ar->AddAttribute(rtf_formprot);		
	//_AddAttributeNotdefval(t->dop.fLockRev, refDop.fLockRev, ar, rtf_revprot, t->dop.fLockRev);
	_AddAttributeNotdefval(t->dop.fRevMarking, refDop.fRevMarking, ar, rtf_revisions, t->dop.fRevMarking);
	_AddAttributeNotdefval(t->dop.fLockAtn, refDop.fLockAtn, ar, rtf_annotprot, t->dop.fLockAtn);
	_AddAttributeNotdefval(t->dop.fIncludeHeader, refDop.fIncludeHeader, ar, rtf_pgbrdrhead, t->dop.fIncludeHeader);
	_AddAttributeNotdefval(t->dop.fIncludeFooter, refDop.fIncludeFooter, ar, rtf_pgbrdrfoot, t->dop.fIncludeFooter);
	_AddAttributeNotdefval(t->dop.fSnapBorder, refDop.fSnapBorder, ar, rtf_pgbrdrsnap, t->dop.fSnapBorder);
	_AddAttributeNotdefval(t->dop.copts.fSuppressTopSpacingMac5, refDop.copts.fSuppressTopSpacingMac5, ar, rtf_sprstsm, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fOrigWordTableRules, refDop.copts.fOrigWordTableRules, ar, rtf_otblrul, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fMWSmallCaps, refDop.copts.fMWSmallCaps, ar, rtf_msmcap, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fLineWrapLikeWord6, refDop.copts.fLineWrapLikeWord6, ar, rtf_oldlinewrap, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fAutoSpaceLikeWord95, refDop.copts.fAutoSpaceLikeWord95, ar, rtf_oldas, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSuppressTopSpacingWP, refDop.copts.fSuppressTopSpacingWP, ar, rtf_sprslnsp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fWPSpaceWidth, refDop.copts.fWPSpaceWidth, ar, rtf_wpsp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fWPJustification, refDop.copts.fWPJustification, ar, rtf_wpjst, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fNoExtraLineSpacing, refDop.copts.fNoExtraLineSpacing, ar, rtf_lytexcttp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fTransparentMetafiles, refDop.copts.fTransparentMetafiles, ar, rtf_transmf, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fNoSpaceRaiseLower, refDop.copts.fNoSpaceRaiseLower, ar, rtf_noextrasprl, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fNoTabForInd, refDop.copts.fNoTabForInd, ar, rtf_notabind, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fDontBreakWrappedTables, refDop.copts.fDontBreakWrappedTables, ar, rtf_nobrkwrptbl, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fNoColumnBalance, refDop.copts.fNoColumnBalance, ar, rtf_nocolbal, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fNoLeading, refDop.copts.fNoLeading, ar, rtf_nolead, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fWrapTextWithPunct, refDop.copts.fWrapTextWithPunct, ar, rtf_wrppunct, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSubFontBySize, refDop.copts.fSubFontBySize, ar, rtf_subfontbysize, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fWrapTrailSpaces, refDop.copts.fWrapTrailSpaces, ar, rtf_wraptrsp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fTruncateFontHeight, refDop.copts.fTruncateFontHeight, ar, rtf_truncatefontheight, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSupressTopSpacing, refDop.copts.fSupressTopSpacing, ar, rtf_sprstsp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fWW6BorderRules, refDop.copts.fWW6BorderRules, ar, rtf_bdrrlswsix, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fApplyBreakingRules, refDop.copts.fApplyBreakingRules, ar, rtf_ApplyBrkRules, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fPrintBodyBeforeHdr, refDop.copts.fPrintBodyBeforeHdr, ar, rtf_bdbfhdr, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fUsePrinterMetrics, refDop.copts.fUsePrinterMetrics, ar, rtf_lytprtmet, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fNoAdjustLineHeightInTable, refDop.copts.fNoAdjustLineHeightInTable, ar, rtf_nolnhtadjtbl, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fMapPrintTextColor, refDop.copts.fMapPrintTextColor, ar, rtf_prcolbl, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSwapBordersFacingPgs, refDop.copts.fSwapBordersFacingPgs, ar, rtf_swpbdr, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fShowBreaksInFrames, refDop.copts.fShowBreaksInFrames, ar, rtf_brkfrm, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSuppressBottomSpacing, refDop.copts.fSuppressBottomSpacing, ar, rtf_sprsbsp, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fConvMailMergeEsc, refDop.copts.fConvMailMergeEsc, ar, rtf_cvmme, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fDoNotExpandShiftReturn, refDop.copts.fDoNotExpandShiftReturn, ar, rtf_expshrtn, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fDoNotLeaveBackslashAlone, refDop.copts.fDoNotLeaveBackslashAlone, ar, rtf_noxlattoyen, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fBalanceSingleByteDoubleByteWidth, refDop.copts.fBalanceSingleByteDoubleByteWidth, ar, rtf_dntblnsbdb, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fULTrailSpace, refDop.copts.fULTrailSpace, ar, rtf_noultrlspc, rtf_nilParam);
	_AddAttributeNotdefval(t->dop.copts.fSpaceForUL, refDop.copts.fSpaceForUL, ar, rtf_nospaceforul, rtf_nilParam);
	WriteChars(ar, t);
}
STDMETHODIMP_(void) RtfWDopWriter::WriteChars(RtfDirectWriter* ar, const KDWDocProperties* t)
{
	ar->StartGroup(rtf_fchars, rtf_nilParam, TRUE);
	ar->AddContentWcs(t->dop.doptypography.rgxchFPunct);
	ar->EndGroup();
	ar->StartGroup(rtf_lchars, rtf_nilParam, TRUE);		
	ar->AddContentWcs(t->dop.doptypography.rgxchLPunct);
	ar->EndGroup();
}
void RtfWDopWriter::Reset(RtfWDop* rtfdop)
{		
	KDWDocProperties s_kdop;
	*(static_cast<DOP*>(rtfdop)) = s_kdop.dop;
	rtfdop->Reset();
}

STDMETHODIMP_(void) RtfWInfoWriter::WriteAssocStrGroup(RtfDirectWriter* ar, LPCWSTR szWstr, UINT len, RtfControl grName, BOOL fDest)
{
	if(szWstr && len)
	{
		ar->StartGroup(grName, rtf_nilParam, fDest);
		ar->AddContentWcs(szWstr, len);			
		ar->EndGroup();
	}		
}

STDMETHODIMP_(void) RtfWInfoWriter::WriteDttm(RtfDirectWriter* ar, DTTM dttm,  RtfControl grName, BOOL fDest)
{
	if((UINT32&)dttm)
	{
		ar->StartGroup(grName, rtf_nilParam, fDest);
		ar->AddAttribute(rtf_yr, dttm.yr + 1900);
		ar->AddAttribute(rtf_mo, dttm.mon);
		ar->AddAttribute(rtf_dy, dttm.dom);
		ar->AddAttribute(rtf_hr, dttm.hr);
		ar->AddAttribute(rtf_min, dttm.mint);
		ar->EndGroup();
	}		
}
STDMETHODIMP_(void) RtfWInfoWriter::WriteNumberGroup(RtfDirectWriter* ar, RtfControl grName, UINT val, BOOL fDest)
{
	if(val)
	{
		ar->StartGroup(grName, val, fDest);
		ar->EndGroup();
	}
}
STDMETHODIMP_(void) RtfWInfoWriter::Write(RtfDirectWriter* ar, const KDWAssocStringTable* assocTbl, const KDWDocProperties* t)
{
	ar->StartGroup(rtf_info);
	UINT len;
	LPCWSTR title = assocTbl->Get(ibstAssocTitle, &len);
	WriteAssocStrGroup(ar, title, len, rtf_title);
	LPCWSTR subject = assocTbl->Get(ibstAssocSubject, &len);
	WriteAssocStrGroup(ar, subject, len, rtf_subject);
	LPCWSTR author = assocTbl->Get(ibstAssocAuthor, &len);
	WriteAssocStrGroup(ar, author, len, rtf_author);
	LPCWSTR keywords = assocTbl->Get(ibstAssocKeyWords, &len);
	WriteAssocStrGroup(ar, keywords, len, rtf_keywords);
	LPCWSTR doccomm = assocTbl->Get(ibstAssocComments, &len);
	WriteAssocStrGroup(ar, doccomm, len, rtf_doccomm);
	LPCWSTR oper = assocTbl->Get(ibstAssocLastRevBy, &len);
	WriteAssocStrGroup(ar, oper, len, rtf_operator);
	WriteDttm(ar, t->dop.dttmCreated, rtf_creatim);
	WriteDttm(ar, t->dop.dttmRevised, rtf_revtim);
	WriteNumberGroup(ar, rtf_version, t->dop.nRevision);
	WriteNumberGroup(ar, rtf_edmins, t->dop.tmEdited);
	WriteNumberGroup(ar, rtf_nofpages, t->dop.cPg);
	WriteNumberGroup(ar, rtf_nofwords, t->dop.cWords);
	WriteNumberGroup(ar, rtf_nofchars, t->dop.cCh);
	WriteNumberGroup(ar, rtf_nofcharsws, t->dop.cChWS);		
	ar->EndGroup();
}