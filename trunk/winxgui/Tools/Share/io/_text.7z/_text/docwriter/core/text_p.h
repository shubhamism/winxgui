/* -------------------------------------------------------------------------
//	�ļ���		��	text_p.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 18:54:03
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_P_H__
#define __TEXT_P_H__

#ifndef __TEXT_SPAN_H__
#include "text_span.h"
#endif

#ifndef __TEXT_FIELD_BEGIN_H__
#include <field/text_field_begin.h>
#endif

#ifndef __TEXT_FIELD_END_H__
#include <field/text_field_end.h>
#endif

// -------------------------------------------------------------------------

class KTextFieldCodeHandler;
class KTextPHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

	KTextSpanHandler m_spanElement;
	KTextFieldBeginHandler m_fieldBeginElement;
	KTextFieldCodeHandler* m_fieldCodeElement;
	KTextFieldEndHandler m_fieldEndElement;
	BOOL m_fIsFakeHandle;	// ���Ϊ�棬��������еĶα�ǩ����ֻ���ɶ����±�ǩ
	
public:
	KTextPHandler() : m_fieldCodeElement(NULL), m_fIsFakeHandle(FALSE) {}
	~KTextPHandler();

	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget, 
		IN BOOL fFakeParagraphHandle = FALSE)
	{
		m_pDocTarget = pDocTarget;
		m_fIsFakeHandle = fFakeParagraphHandle;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
	
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_P_H__ */
