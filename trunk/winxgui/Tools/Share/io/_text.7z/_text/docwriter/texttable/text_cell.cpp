/* -------------------------------------------------------------------------
//	�ļ���		��	text_cell.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-23 15:24:52
//	��������	��	
//
//	$Id: text_cell.cpp,v 1.17 2006/07/31 07:00:06 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include <attr/stocktrans.h>
#include "text_cell.h"
#include "text_table.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

KTextCellHandler::~KTextCellHandler()
{
	delete m_textTableElement;
}


// -------------------------------------------------------------------------
STDMETHODIMP KTextCellHandler::StartElement(
						  IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	KDWCellPr cellPr;

	/** bug# 16289
	������
		WORD���ܶ�ȡ��WPS�ļ��б���ĵ��ƣ��ص�ѡ�����������趨���ƣ�
	�ظ����裺
		1��wps�д���һ�����񣬿ص�ȫѡ���������趨���ƣ�
		2������Ϊdoc
		3����word�򿪱����doc�����ֱ�����ƶ�ʧ��
	ԭ�������
		Word�ı�����Ʋ����ڸ��棻��ϸ�����ο�<mso/io/word/texttable.xls>��
	�����
		KDWCellPr����ʱ�����õ��ǣ�shd.put_Normal(); ���ǣ�shd.put_Nil();
		�ʴˣ�docwriter���������������Ĭ��û�������á�
		����Ҫ��������shd.put_Nil();��ʵ�ָ��档
	*/
	cellPr.shd.put_Nil();
	
	HRESULT hr;
	union
	{
		KROAttributes* tcBorders;
		KROAttributes* tcShd;
		KROAttributes* tcMargin;
		KROAttributes* tcDiagonal;
	};

	pAttrs->GetByID(kso_schema::text_noWrap, &cellPr.noWrap);
	pAttrs->GetByID(kso_schema::text_fitText, &cellPr.tcFitText);
	pAttrs->GetByID(kso_schema::text_width, &cellPr.tcWidth);
	
	hr = pAttrs->GetByID(kso_schema::text_borders, &tcBorders);
	if (SUCCEEDED(hr))
	{
		KROAttributes* border;
		ATTRID borderType[] =
		{
			kso_schema::text_top,
			kso_schema::text_left,
			kso_schema::text_bottom,
			kso_schema::text_right,
			kso_schema::text_tl2br,
			kso_schema::text_tr2bl,
		};
		for (INT i = 0; i < countof(borderType); ++i)
		{
			hr = tcBorders->GetByID(borderType[i], &border);
			if (SUCCEEDED(hr))
				TransTableBrcEx(cellPr.tcBorders[i], border);
		}
	}

	hr = pAttrs->GetByID(draw_fill, &tcShd);
	if (SUCCEEDED(hr))
	{
		TransShdEx(cellPr.shd, tcShd);
	}

	hr = pAttrs->GetByID(kso_schema::text_margin, &tcMargin);
	if (SUCCEEDED(hr))
	{
		INT nValue;
		ATTRID marginType[] =
		{
			kso_schema::text_top,
			kso_schema::text_left,
			kso_schema::text_bottom,
			kso_schema::text_right,
		};
		for (INT i = 0; i < countof(marginType); ++i)
		{
			hr = tcMargin->GetByID(marginType[i], &nValue);
			if (SUCCEEDED(hr))
				cellPr.tcMar[i].put_Value(nValue);
		}
	}

	pAttrs->GetByID(kso_schema::text_textFlow, &cellPr.textFlow);
	pAttrs->GetByID(kso_schema::text_vertAlign, &cellPr.vertAlign);
	pAttrs->GetByID(kso_schema::text_vertMerge, &cellPr.vertMerge);
	pAttrs->GetByID(kso_schema::text_horzMerge, &cellPr.horiMerge);


	
	int cDiagonals = 0; 
	KDWDiagonal* diagonals = NULL;
	
	if (
		m_pDocTarget->getFeature().writeKsExt()
		)
	{
		if (SUCCEEDED(
			pAttrs->GetByID(kso_schema::text_diagonals, &tcDiagonal))
			)
		{
			int cSubAttrs = tcDiagonal->Count();
			INT cbDiags = cSubAttrs * sizeof(KDWDiagonal);
			diagonals = (KDWDiagonal*)alloca(cbDiags);
			ZeroMemory(diagonals, cbDiags);
			for (int i = 0; i < cSubAttrs; ++i)
			{
				ATTRID AttrId = 0;
				ATTRVALUE_PTR pVar = NULL;
				tcDiagonal->GetAt(i, &AttrId, &pVar);
				if (AttrId == kso_schema::text_diagonal)
				{
					KROAttributes* pAttrDiag = (KROAttributes*)pVar->punkVal;
					pAttrDiag->GetByID(kso_schema::text_from, &diagonals[cDiagonals].from);
					diagonals[cDiagonals].from /= 2;
					pAttrDiag->GetByID(kso_schema::text_to, &diagonals[cDiagonals].to);
					diagonals[cDiagonals].to /= 2;
					KROAttributes* pAttrBrc = NULL;
					pAttrDiag->GetByID(kso_schema::text_border, &pAttrBrc);
					if (pAttrBrc)
						TransBrcEx(diagonals[cDiagonals].brc, pAttrBrc);
					++cDiagonals;
				}
			}
		}
	}
 
	m_pDocTarget->rowtbl_NewCell(cellPr, (KDWDiagonal*)diagonals, cDiagonals);

	return S_OK;
}

STDMETHODIMP KTextCellHandler::EnterSubElement(
											  IN ELEMENTID uSubElementID,
											  OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_p:
		m_paraElement.Init(m_pDocTarget);
		*ppHandler = &m_paraElement;
		break;
	case kso_schema::text_table:
		if (m_textTableElement == NULL)
			m_textTableElement = new KTextTableHandler;
		m_textTableElement->Init(m_pDocTarget);
		*ppHandler = m_textTableElement;
		break;
	case kso_schema::text_diagonal:
		m_textDiagElement.Init(m_pDocTarget);
		*ppHandler = &m_textDiagElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: text_cell.cpp,v $
// Revision 1.17  2006/07/31 07:00:06  wangdong
// #26126������дdocʱ��feature��������ݡ�
//
// Revision 1.16  2006/07/24 06:47:08  wangdong
// �������ַ���
//
// Revision 1.15  2006/05/11 03:16:18  wangdong
// no message
//
// Revision 1.14  2005/06/22 08:26:21  xushiwei
// bug# 16289 fix
//
