/* -------------------------------------------------------------------------
//	�ļ���		��	bookmarks.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:11:49
//	��������	��	
//
//	$Id: bookmarks.h,v 1.3 2006/02/18 07:33:32 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __BOOKMARKS_H__
#define __BOOKMARKS_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfDirectWriter;
class RtfWBookmarkStartsWriter
{
private:
	const KDWBookmarkStarts* m_data;
	KDWBookmarkStarts::Enumerator m_enumer;
	
public:
	RtfWBookmarkStartsWriter();
	RtfWBookmarkStartsWriter::RtfWBookmarkStartsWriter(const KDWBookmarkStarts* data);
	STDMETHODIMP SetData(const KDWBookmarkStarts* data);	
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
};

class RtfWBookmarkEndsWriter
{
private:
	const KDWBookmarkEnds* m_data;
	KDWBookmarkEnds::Enumerator m_enumer;
	
public:
	RtfWBookmarkEndsWriter();
	RtfWBookmarkEndsWriter(const KDWBookmarkEnds* data);
	STDMETHODIMP SetData(const KDWBookmarkEnds* data);	
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
};
// -------------------------------------------------------------------------
//	$Log: bookmarks.h,v $
//	Revision 1.3  2006/02/18 07:33:32  xulingjiao
//	�޸�BUG
//	
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:05  xulingjiao
//	*** empty log message ***
//	

#endif /* __BOOKMARKS_H__ */
