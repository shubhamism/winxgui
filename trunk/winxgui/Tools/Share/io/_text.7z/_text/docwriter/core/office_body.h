/* -------------------------------------------------------------------------
//	�ļ���		��	office_body.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 18:46:06
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_BODY_H__
#define __OFFICE_BODY_H__

#ifndef __TEXT_P_H__
#include "text_p.h"
#endif

#ifndef __TEXT_SECT_H__
#include "text_sect.h"
#endif

#ifndef __TEXT_SETTINGS_H__
#include "text_settings.h"
#endif

// -------------------------------------------------------------------------

class KTextTableHandler;
class KTextFrameHandler;
class KOfficeBodyHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;
	KTextSectionHandler m_sectElement;
	KTextTableHandler* m_tableElement;
	KTextSettingsHandler m_settingElement;
	KTextFrameHandler* m_frameElement;
	
public:
	KOfficeBodyHandler()
	{
		m_tableElement = NULL;
		m_frameElement = NULL;
	}
	~KOfficeBodyHandler();

	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		return S_OK;
	}

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_BODY_H__ */
