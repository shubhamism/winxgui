/* -------------------------------------------------------------------------
//	�ļ���		��	feature.h
//	������		��	����
//	����ʱ��	��	2006-7-28 15:35:19
//	��������	��	
//
//	$Id: feature.h,v 1.1 2006/07/31 07:00:01 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __FEATURE_H__
#define __FEATURE_H__


// -------------------------------------------------------------------------
#ifndef __STL_HASH_SET_H__
#include <stl/hash_set.h>
#endif

#ifndef __KFC_VARIANT_H__
#include <kfc/variant.h>
#endif

#ifndef __KSO_APPFEATURE_KAPPFEATURE_H__
#include <kso/appfeature/kappfeature.h>
#endif

#ifndef __FILTER_PLUGIN_H__
#include <filter/plugin.h>
#endif



// -------------------------------------------------------------------------
class KDWFeatureControl
{
public:
	STDMETHODIMP_(BOOL) writeKsExt(
		IN BOOL silently = TRUE
		);


public:	
	STDMETHODIMP Init(
		IN DWFileType FileType,
		IN IKFilterEventNotify* pNotify = NULL
		)
	{
		m_pNotify = pNotify;
		m_FileType = FileType;
		return S_OK;
	}

private:
	STDMETHODIMP_(INT) Prompt(
		IN LPCWSTR str, IN INT flag)
	{
		if (
			m_pNotify &&
			m_promptSet.find(str) == m_promptSet.end()
			)
		{
			KComVariant Msg(str);
			m_pNotify->OnNotify(
				FILTEREVENT_PROMPT, flag, &Msg
				);
			m_promptSet.insert(str);
			return Msg.lVal;
		}
		return IDCANCEL;
	}
	STDMETHODIMP_(INT) Query(
		IN INT feature)
	{
		return _kso_QueryFeatureState(feature);
	}
	
private:
	IKFilterEventNotify* m_pNotify;
	DWFileType m_FileType;

	__std::hash_set<ks_wstring> m_promptSet;
};


// -------------------------------------------------------------------------
//	$Log: feature.h,v $
//	Revision 1.1  2006/07/31 07:00:01  wangdong
//	#26126������дdocʱ��feature��������ݡ�
//	

#endif /* __FEATURE_H__ */
