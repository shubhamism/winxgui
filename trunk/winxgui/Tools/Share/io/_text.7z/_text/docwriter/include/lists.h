/* -------------------------------------------------------------------------
//	�ļ���		��	lists.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-19 17:25:59
//	��������	��	���� Word���Զ����ģ�� -> V6���Զ����ģ��
//	�ĵ�		��	mso/io/word/autonum.htm
//
//	$Id: lists.h,v 1.3 2005/01/20 04:07:46 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DW_V6LISTS_H__
#define __DW_V6LISTS_H__

#ifndef __STL_MAP_H__
#include <stl/map.h>
#endif

// -------------------------------------------------------------------------

#pragma pack(1)

struct KDWV6ListInfo
{
	KDWList list;
	UINT ilfo; // ��1��ʼ, 0Ϊ��Ч��
};

#pragma pack()

// -------------------------------------------------------------------------
#ifndef __MSO_FILEFMT_WORD_SPRM_H__
#include <mso/filefmt/word/sprm.h>
#endif

enum enumDWListRestartMode
{
	DWListRestartContinue = kso_lvlRestartAtRestart - 1,
	DWListRestartRestart  = kso_lvlRestartAtRestart,
};
typedef INT DWListRestartMode;

// -------------------------------------------------------------------------
// ����V6�Ķ���ģ�ͽ�KDWList(s)����

class KDWDocTarget;

class KDWV6Lists
{
private:
	typedef std::map<UINT, KDWV6ListInfo> ListIdToListInfo;
	typedef std::multimap<UINT, KDWListLevel> ImageIdToListLevel;

	ListIdToListInfo m_mapIdToList;
	ImageIdToListLevel m_mapImageIdToLevel;

	KDWDocTarget* m_pDoc;

#if defined(_DEBUG)
public:
	~KDWV6Lists()
	{
		ASSERT(m_mapImageIdToLevel.empty());
	}
#endif

public:
	STDMETHODIMP_(void) Init(IN KDWDocTarget* pDoc)
	{
		 m_pDoc = pDoc;
	}

	STDMETHODIMP_(KDWDocTarget*) GetDocTarget() const
	{
		return m_pDoc;
	}

	STDMETHODIMP_(void) SetPicBullet(
		IN KDWListLevel listLevel,
		IN UINT idImage)
	{
		m_mapImageIdToLevel.insert(
			ImageIdToListLevel::value_type(idImage, listLevel));
	}

	STDMETHODIMP_(void) UpdatePicBullet(
		IN UINT idImage,
		IN UINT iImageType,
		IN IKLockBuffer* pLockBuffer);

	STDMETHODIMP_(KDWList) NewList(
		IN UINT idList);

	STDMETHODIMP_(UINT) GetLfoIndex(
		IN UINT idList,
		IN UINT iLvl,
		IN DWListRestartMode iRestartAt);
};

// -------------------------------------------------------------------------
//	$Log: lists.h,v $
//	Revision 1.3  2005/01/20 04:07:46  wangdong
//	no message
//	
//	Revision 1.2  2005/01/19 03:16:27  wangdong
//	no message
//	
//	Revision 1.1  2004/11/22 04:48:04  xushiwei
//	*** empty log message ***
//	

#endif /* __DW_V6LISTS_H__ */
