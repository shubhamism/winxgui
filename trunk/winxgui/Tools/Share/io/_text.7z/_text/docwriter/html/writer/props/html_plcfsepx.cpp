/* -------------------------------------------------------------------------
//	�ļ���		��	html_plcfsepx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-7-12 14:40:19
//	��������	��	
//
//	$Id: html_plcfsepx.cpp,v 1.1 2006/07/13 02:51:29 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "../html_textstream.h"
#include "../html_ranges.h"
#include "html_plcfpapx.h"
#include "html_plcfchpx.h"
#include "html_sepx.h"
#include "html_plcfsepx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HtmlWSepxsWriter::HtmlWSepxsWriter(HtmlWGlobalInfo* info, KDWSections* sepx) : m_ginfo(info), m_sepxs(sepx), m_wrHdFt(NULL), m_fopen(FALSE), m_current(-1)
{
	Reset();
}

STDMETHODIMP_(BOOL) HtmlWSepxsWriter::Good() const
{
	if(!m_sepxs)
		return FALSE;
	return m_sepxs->Count() > 0;
}

STDMETHODIMP_(void) HtmlWSepxsWriter::Reset()
{
	m_enumer = KDWSections::Enumerator(m_sepxs);
	Next();
}

STDMETHODIMP HtmlWSepxsWriter::Next()
{
	if (FAILED(m_enumer.Next(&m_current)))
		return E_FAIL;
	return S_OK;
}

STDMETHODIMP_(UINT) HtmlWSepxsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.Range().cp;
}

STDMETHODIMP_(UINT) HtmlWSepxsWriter::GetNextCp()
{
	return (UINT)m_enumer.Range().cpNext;
}

STDMETHODIMP_(void) HtmlWSepxsWriter::EnsureWriteEnd()
{
	m_ginfo->htmlwrStream->GetRange()->EnsureWriteEnd(chpxs);
	m_ginfo->htmlwrStream->GetRange()->EnsureWriteEnd(papxs);
	EnsureWriteEndTag(m_fopen, m_ginfo->ar, elem_div);
}

STDMETHODIMP_(void) HtmlWSepxsWriter::WriteCss()
{
	HtmlWSepxWriter wrSepx;
	Reset();
	do
	{
		wrSepx.WriteCss(m_ginfo, &m_enumer.Item(), m_current);
	}while(SUCCEEDED(Next()));	
}

STDMETHODIMP_(void) HtmlWSepxsWriter::Write()
{
	KDWSection sect = m_enumer.Item();	
	HtmlWSepxWriter wrSepx;
	EnsureWriteEnd();
	WriteStartTag(m_fopen, m_ginfo->ar, elem_div);
	wrSepx.Write(m_ginfo, &sect, m_current);
}

