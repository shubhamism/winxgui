/* -------------------------------------------------------------------------
//	�ļ���		��	colortable.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:55:43
//	��������	��	
//
//	$Id: colortable.h,v 1.1 2006/01/04 03:41:47 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __COLORTABLE_H__
#define __COLORTABLE_H__

/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
#include <set>
class RtfDirectWriter;
class RtfWColorTable
{
private:
	typedef std::map<COLORREF, INT> ColorMap;
	ColorMap m_colors;

public:
	RtfWColorTable();
	STDMETHODIMP_(void) AddColor(COLORREF clr);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
	STDMETHODIMP_(UINT) GetColorIndex(COLORREF clr);
};
// -------------------------------------------------------------------------
//	$Log: colortable.h,v $
//	Revision 1.1  2006/01/04 03:41:47  xulingjiao
//	*** empty log message ***
//	

#endif /* __COLORTABLE_H__ */
