/* -------------------------------------------------------------------------
//	�ļ���		��	textstream.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:38:12
//	��������	��	
//
//	$Id: textstream.h,v 1.10 2006/08/11 08:14:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXTSTREAM_H__
#define __TEXTSTREAM_H__

/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class RtfWRangesWriter;
class RtfWDrawingWriter;
class RtfWEmbShapeWriter;
class RtfDirectWriter;
class RtfWChpxWriter;

class RtfWTextStreamWriter
{
private:
	const KDWTextStream* m_stream;
	CP m_CurCp;
	SUBDOC_TYPE m_SubDoc;
	RtfWRangesWriter* m_wrRanges;
	RtfWDrawingWriter* m_wrDrawing;
	RtfWEmbShapeWriter* m_wrEmbShape;	
private:	
	STDMETHODIMP_(void) WriteText(RtfDirectWriter* ar, const KDWTextStream* p, RtfWChpxWriter* wrChpx, CP cp, INT cch, INT filtermask = 0);
	STDMETHODIMP AddSpecChar(RtfDirectWriter* ar, WCHAR wch, CP cp, RtfWChpxWriter* wrChpx);
	STDMETHODIMP AddNormalChar(RtfDirectWriter* ar, TxCharClass chclass, WCHAR wch, INT& iLastFont, RtfWChpxWriter* wrChpx);
	STDMETHODIMP Add0x0d(RtfDirectWriter* ar, DWORD ciACP, INT filtermask);
	STDMETHODIMP Add0x07(RtfDirectWriter* ar, DWORD ciACP, INT filtermask);
	STDMETHODIMP Add0x0e(RtfDirectWriter* ar, DWORD ciACP, INT filtermask);
	STDMETHODIMP Add0x0b(RtfDirectWriter* ar, DWORD ciACP, INT filtermask);
	STDMETHODIMP Add0x09(RtfDirectWriter* ar, DWORD ciACP, INT filtermask);
	STDMETHODIMP Add0x0c(RtfDirectWriter* ar, DWORD ciACP, CP cp, INT filtermask);
public:	
	RtfWTextStreamWriter(
		const KDWTextStream* stream,
		RtfWRangesWriter* wrRanges,
		SUBDOC_TYPE subDoc,
		RtfWDrawingWriter* wrDrawing = NULL,
		RtfWEmbShapeWriter* wrEmbShape = NULL);
	STDMETHODIMP WriteNoteRef(RtfDirectWriter* ar, CP cp);	
	STDMETHODIMP_(RtfWRangesWriter*) GetRangesWriter();
	STDMETHODIMP_(const KDWTextStream*) GetTextStream() const;
	STDMETHODIMP_(RtfWGlobalInfo*) GetGlobalInfo();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, SUBDOC_TYPE subdoctype = DW_SUBDOC_MAIN);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, CP cp, INT cch, SUBDOC_TYPE subdoctype = DW_SUBDOC_MAIN);
};
#endif /* __TEXTSTREAM_H__ */
