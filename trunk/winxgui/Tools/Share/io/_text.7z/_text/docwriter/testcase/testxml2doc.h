/* -------------------------------------------------------------------------
//	�ļ���		��	testxml2doc.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-19 9:36:16
//	��������	��	
//
//	$Id: testxml2doc.h,v 1.4 2005/06/04 08:38:02 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TESTXML2DOC_H__
#define __TESTXML2DOC_H__

#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif

#ifndef __KFC_COM_SIMPOBJ_H__
#include <kfc/com/simpobj.h>
#endif

#ifndef __KSO_IO_COMPONENT_H__
#include <kso/io/component.h>
#endif

#ifndef __L10N_H__
#include "l10n.h"
#endif

#include "kso/dircfginfo.h"

// -------------------------------------------------------------------------

STDAPI filterpluginExportCreate(
							   IN long lFormat,
							   IN IKFilterEventNotify* pNotify,
							   OUT IKFilterMediaInit** ppv);

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(void) testDocWriter(
				   IN IKContentSource* pSrc,
				   IN LPCWSTR szDocFile)
{
	ks_stdptr<IKFilterMediaInit> spInit;
	VERIFY_OK(
		filterpluginExportCreate(_IoFormat_MSWORD8, NULL, &spInit));

	VERIFY_OK(
		_kso_FileMediaInit(spInit, szDocFile, STGM_G_CREATE));

	ks_stdptr<IKContentHandler> spAcc;
	VERIFY_OK(
		spInit->QI(IKContentHandler, &spAcc));

	VERIFY_OK(
		pSrc->Transfer(spAcc));
}

// -------------------------------------------------------------------------
// class KConvertXml2Doc

// FnCreateXmlReader
typedef STDMETHODIMP _kso_FnCreateXmlReader(
											IN KsoXmlStdType uXmlType,
											OUT IKContentSource** ppSource
											);
typedef _kso_FnCreateXmlReader* FnCreateXmlReader;

class KConvertXml2Doc
{
private:
	FnCreateXmlReader m_fnCreateXmlReader;
	
public:
	KConvertXml2Doc() : m_fnCreateXmlReader(NULL)
	{
	}

	void convert(
		IN LPCWSTR szXmlFileSrc,
		IN LPCWSTR szDocFileDest)
	{
		printf("\n[loading \"%S\"...]\n", szXmlFileSrc);

		WCHAR szXmlFile[_MAX_PATH];
		WCHAR szDocFile[_MAX_PATH];
		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szXmlFile, MAX_PATH);
		wcscat(szXmlFile, __L("/"));
		wcscat(szXmlFile, szXmlFileSrc);

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szDocFile, MAX_PATH);
		wcscat(szDocFile, __L("/"));
		wcscat(szDocFile, szDocFileDest);

		if (m_fnCreateXmlReader == NULL)
		{
			HMODULE hLib = LoadLibrary("xmlreader");
			ASSERT(hLib);
			
			m_fnCreateXmlReader = (FnCreateXmlReader)
				GetProcAddress(hLib, "_kso_CreateXmlReader");
			ASSERT(m_fnCreateXmlReader);
		}
		
		ks_stdptr<IKContentSource> spSrc;
		
		VERIFY_OK(
			m_fnCreateXmlReader(kso_xmlWordProcess, &spSrc));
		
		VERIFY_OK(
			_kso_FileMediaInit(spSrc, szXmlFile, STGM_G_READ));
		
		::testDocWriter(spSrc, szDocFile);
	}
};

// -------------------------------------------------------------------------
//	$Log: testxml2doc.h,v $
//	Revision 1.4  2005/06/04 08:38:02  wangdong
//	����IO�ַ�����
//	
//	Revision 1.3  2004/12/10 12:26:05  wanli
//	*** empty log message ***
//	
//	Revision 1.2  2004/11/19 07:13:56  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2004/11/19 01:44:33  xushiwei
//	*** empty log message ***
//	

#endif /* __TESTXML2DOC_H__ */
