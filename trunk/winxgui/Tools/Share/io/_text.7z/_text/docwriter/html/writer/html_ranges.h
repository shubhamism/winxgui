/* -------------------------------------------------------------------------
//	�ļ���		��	html_ranges.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:32:26
//	��������	��	
//
//	$Id: html_ranges.h,v 1.10 2006/07/13 02:51:29 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_RANGES_H__
#define __HTML_RANGES_H__

class HtmlWChpxWriter;
class HtmlWChpxsWriter;
class HtmlWPapxWriter;
class HtmlWPapxsWriter;
class HtmlWFieldHandler;
class HtmlWMainFieldsWriter;
class HtmlWBookmarkStartsWriter;
class HtmlWBookmarkEndsWriter;
class HtmlWGlobalInfo;
class CssPropBuffer;
class HtmlWSepxsWriter;

enum WriterType
{
	chpxs,
	papxs,
	sepxs,
	mainflds,
	bkmkstarts,
	bkmkends,
};

class HtmlWRangesWriter
{
private:
	HtmlWGlobalInfo* m_ginfo;
	HtmlWChpxsWriter* m_wrChpxs;
	HtmlWPapxsWriter* m_wrPapxs;
	HtmlWSepxsWriter* m_wrSepxs;
	HtmlWMainFieldsWriter* m_wrMainFlds;
	HtmlWBookmarkStartsWriter* m_wrBookmarkStarts;
	HtmlWBookmarkEndsWriter* m_wrBookmarkEnds;
	struct CurrentMask
	{
		BOOL fChpxs, fPapxs, fSepxs, fFields, fBookmksStart, fBookmksEnd;
		CurrentMask() {	Reset(); }
		void Reset() { ZeroMemory(this, sizeof(CurrentMask)); }
	}m_current;	
	UINT m_cp;
	BOOL fBookmkOpen;
public:
	// gets
	STDMETHODIMP_(HtmlWChpxWriter&) GetChpinfo();	
	STDMETHODIMP_(HtmlWPapxWriter&) GetPapInfo();
	STDMETHODIMP_(CssPropBuffer*) GetCurrentChpxCssprop();	
	STDMETHODIMP_(HtmlWMainFieldsWriter*) GetFields();
public:	
	HtmlWRangesWriter(HtmlWGlobalInfo* info);
	STDMETHODIMP_(HtmlWGlobalInfo*) GetGlobalInfo();
	STDMETHODIMP_(void) SetPlcfChpx(HtmlWChpxsWriter* wrChpxs);	
	STDMETHODIMP_(void) SetPlcfPapx(HtmlWPapxsWriter* wrPapxs);	
	STDMETHODIMP_(void) SetPlcfSepx(HtmlWSepxsWriter* wrSepxs);	
	STDMETHODIMP_(void) SetMainFields(HtmlWMainFieldsWriter* wrFields);
	STDMETHODIMP_(void) SetMainBookmkStarts(HtmlWBookmarkStartsWriter* wrBookmks);
	STDMETHODIMP_(void) SetMainBookmkEnds(HtmlWBookmarkEndsWriter* wrBookmks);	
public:	
	STDMETHODIMP_(void) Reset();	
	STDMETHODIMP Next();	
	STDMETHODIMP_(UINT) GetCp();	
	STDMETHODIMP_(UINT) GetNextCp();	
	STDMETHODIMP_(void) Write(UINT SpecText);
	STDMETHODIMP_(void) EnsureWriteEnd(WriterType);
	STDMETHODIMP_(void) EnsureWriteEnd();	
private:
	UINT __GetCp();		
	UINT __GetCpNext();	
};
#endif /* __HTML_RANGES_H__ */
