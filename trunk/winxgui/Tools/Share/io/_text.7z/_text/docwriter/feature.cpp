/* -------------------------------------------------------------------------
//	�ļ���		��	feature.cpp
//	������		��	����
//	����ʱ��	��	2006-7-28 15:59:50
//	��������	��	
//
//	$Id: feature.cpp,v 1.1 2006/07/31 07:00:01 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "feature.h"

#include <kso\l10n\wps\wpscore_persist.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP_(BOOL) KDWFeatureControl::writeKsExt(
	IN BOOL silently)
{
	switch (m_FileType)
	{
	case dwFileMSWORD8:
	case dwFileMSWORD8DOT:
		if (Query(kaf_kso_PromptWhenLosingWPSFeature))
		{
			if (!silently)
				Prompt(_TxDocument_FormatNotCompatible_Word97, MB_OK);
			return FALSE;
		}
		break;
	}
	return TRUE;
}


// -------------------------------------------------------------------------
//	$Log: feature.cpp,v $
//	Revision 1.1  2006/07/31 07:00:01  wangdong
//	#26126������дdocʱ��feature��������ݡ�
//	
