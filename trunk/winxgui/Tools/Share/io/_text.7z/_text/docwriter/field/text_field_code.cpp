/* -------------------------------------------------------------------------
//	�ļ���		��	text_field_code.cpp
//	������		��	����
//	����ʱ��	��	2004-8-23 15:43:24
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

#ifndef __TEXT_FIELD_CODE_H__
#include "text_field_code.h"
#endif

#ifndef __ATTRTRANS_H__
#include <core/attributes/attrtrans.h>
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextFieldCodeHandler::StartElement(
						  IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	m_fFirstParagraphOfCode = TRUE;

	pAttrs->GetByID(kso::text_r_prop, &m_pAttrChpx);
	ASSERT(uElementID == text_field_separate);
	ASSERT(m_pDocTarget);

	KROAttributes* pAttrChpx = NULL;
	pAttrs->GetByID(kso::text_r_prop, &pAttrChpx);

	KDWPropBuffer* prop = m_pDocTarget->GetPropBuffer();
	TransSpanAttr(m_pDocTarget, (IKAttributes*)pAttrChpx, prop);

	m_pDocTarget->NewSpan(prop);
	m_pDocTarget->MarkFieldSeparator();
	
	return S_OK;
}

STDMETHODIMP KTextFieldCodeHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_p:
		m_paraElement.Init(m_pDocTarget, m_fFirstParagraphOfCode);
		m_fFirstParagraphOfCode = FALSE;
		*ppHandler = &m_paraElement;
		break;
	case kso_schema::text_table:
		return IO_E_IGNORE;		//@@ todo
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
