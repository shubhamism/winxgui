/* -------------------------------------------------------------------------
//	�ļ���		��	text_span.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 19:00:57
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include "text_span.h"
#include "footnote/text_footnote.h"
#include "drawing/text_anchor.h"
#include "attributes/attrtrans.h"
#include "field/text_hyperlink_range.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

KTextSpanHandler::~KTextSpanHandler()
{
	if (m_footnoteElement)
		delete m_footnoteElement;
	if (m_anchorElement)
		delete m_anchorElement;
	if (m_hypBeginElement)
		delete m_hypBeginElement;
	if (m_hypEndElement)
		delete m_hypEndElement;
}

STDMETHODIMP KTextSpanHandler::StartElement(
											IN ELEMENTID uElementID,
											IN KROAttributes* pAttrs)
{
	HRESULT hr = E_FAIL;

	// ��ʽ
	KDWPropBuffer* pPropBuffer = m_pDocTarget->GetPropBuffer();

	if (pAttrs)
	{
		INT istd = -1;
		{
			UINT value;
			if (pAttrs->GetByID(text_r_styleref, &value) >= 0)
			{
				KDWStyleIDMap& IdMap = m_pDocTarget->GetRStyleIDMap();
				KDWStyleIDMap::const_iterator i = IdMap.find(value);
				if (i != IdMap.end())
					istd = (*i).second;
			}
		}
		if (istd > -1)
			pPropBuffer->AddPropFix(sprmCIstd, istd);
		
		hr = TransSpanAttr(m_pDocTarget, pAttrs, pPropBuffer);
		KS_CHECK(hr);
	}

	m_pDocTarget->NewSpan(pPropBuffer);

	m_pSubPropBuf = pPropBuffer;

KS_EXIT:
	return hr;
}

inline STDMETHODIMP_(WCHAR) FilterSpecChars(
	IN WCHAR ch)
{
	switch(ch)
	{
	case kso_text::chSectMark:
	case kso_text::chPageBrk:
		return 0x0C;
	}
	return ch;
}

STDMETHODIMP KTextSpanHandler::AddContent(IN CONTENTVALUE_PTR pContent)
{
	ASSERT(pContent->vt == KsoVariant::vtString);

	if (pContent->vt != KsoVariant::vtString)
		return E_INVALIDARG;

	UINT const size = SysStringLen(pContent->bstrVal);
	if (size == 1)
		m_pDocTarget->AddContent(FilterSpecChars(pContent->bstrVal[0]));
	else
		m_pDocTarget->AddContent(pContent->bstrVal, size);
	return S_OK;
}

STDMETHODIMP KTextSpanHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_range_begin:
		m_rangeBeginElement.Init(m_pDocTarget);
		*ppHandler = &m_rangeBeginElement;
		break;
	case text_range_end:
		m_rangeEndElement.Init(m_pDocTarget);
		*ppHandler = &m_rangeEndElement;
		break;
	case text_annotation_begin:
		m_annBeginElement.Init(m_pDocTarget);
		*ppHandler = &m_annBeginElement;
		break;
	case text_annotation_end:
		m_annEndElement.Init(m_pDocTarget);
		*ppHandler = &m_annEndElement;
		break;
	case text_footnote:
	case text_endnote:
		if (!m_footnoteElement)
		{
			m_footnoteElement = new KTextFootnoteHandler;
		}
		m_footnoteElement->Init(m_pDocTarget, uSubElementID);
		*ppHandler = m_footnoteElement;
		break;
	case text_citation_break:
		m_citationbreakElement.Init(m_pDocTarget);
		*ppHandler = &m_citationbreakElement;
		break;
	case draw_shape:
	case draw_group:
		if (!m_anchorElement)
		{
			m_anchorElement = new KTextAnchorHandler;
		}
		m_anchorElement->Init(m_pDocTarget);
		*ppHandler = m_anchorElement;
		break;
	case text_hyperlink_begin:
		if (!m_hypBeginElement)
		{
			m_hypBeginElement = new KHyperlinkBeginHandler;
		}
		m_hypBeginElement->Init(m_pDocTarget);
		*ppHandler = m_hypBeginElement;
		break;
	case text_hyperlink_end:
		if (!m_hypEndElement)
		{
			m_hypEndElement = new KHyperlinkEndHandler;
		}
		m_hypEndElement->Init(m_pDocTarget);
		*ppHandler = m_hypEndElement;
		break;
	case text_symbol:
		m_symbolElement.Init(m_pDocTarget, m_pSubPropBuf);
		*ppHandler = &m_symbolElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
