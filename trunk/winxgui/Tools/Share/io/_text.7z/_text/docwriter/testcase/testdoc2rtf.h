
#ifndef __TESTCOMMON_H__
#include "testcommon.h"
#endif

#include "rtf/writer/doc2rtf.h"

#ifdef X_ENCODE_UCS2
#define testDoc2RtfFile(from, to)\
	ConvertDoc2Rtf(\
		L"../../../../Test/office/wps/testcase/rtfrw/" L ## from,\
		L"../../../../Test/office/wps/testcase/output/" L ## to )
#else
#define testDoc2RtfFile(from, to)\
	ConvertDoc2Rtf(\
		__X("../../../../Test/office/wps/testcase/rtfrw/" from),\
		__X("../../../../Test/office/wps/testcase/output/" to )
#endif