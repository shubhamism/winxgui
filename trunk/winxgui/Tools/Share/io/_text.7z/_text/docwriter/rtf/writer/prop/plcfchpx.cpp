/* -------------------------------------------------------------------------
//	�ļ���		��	plcfchpx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:51:19
//	��������	��	
//
//	$Id: plcfchpx.cpp,v 1.6 2006/09/07 07:07:10 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "plcfchpx.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWChpxsWriter::RtfWChpxsWriter(
	const KDWPlcfChpx* chpxs, RtfWGlobalInfo* info) :
	m_chpxs(chpxs),
	m_ginfo(info),
	m_wrChpx(info),
	m_istdpara(stiNil),
	m_fOpend(FALSE)
{
	Reset();
}
STDMETHODIMP_(BOOL) RtfWChpxsWriter::Good() const
{
	return m_chpxs != NULL && m_chpxs->Count();
}
STDMETHODIMP_(void) RtfWChpxsWriter::Reset()
{
	m_enumer = KDWPlcfChpx::Enumerator(m_chpxs);
	Next();
}
STDMETHODIMP RtfWChpxsWriter::Next()
{
	if (FAILED(m_enumer.Next()))
	{
		m_wrChpx.SetProp(NULL);
		return E_FAIL;
	}
	m_wrChpx.SetProp(m_enumer.SrcData(), m_istdpara);
	return S_OK;
}
STDMETHODIMP_(UINT) RtfWChpxsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.Range().cp;
}
STDMETHODIMP_(UINT) RtfWChpxsWriter::GetNextCp()
{
	return (UINT)m_enumer.Range().cpNext;		
}
STDMETHODIMP_(void) RtfWChpxsWriter::SetIstdPara(INT istdpara)
{
	m_istdpara = istdpara;
}
STDMETHODIMP_(void) RtfWChpxsWriter::Write(RtfDirectWriter* ar)
{
	EnsureWriteEnd(ar);
	m_wrChpx.SetIstdPara(m_istdpara);		
	WriteStartGroup(ar);	
	m_wrChpx.Write(ar);
}
STDMETHODIMP_(void) RtfWChpxsWriter::WriteStartGroup(RtfDirectWriter* ar)
{
	ar->StartBlankGroup();
	m_fOpend = TRUE;
}
STDMETHODIMP_(void) RtfWChpxsWriter::EnsureWriteEnd(RtfDirectWriter* ar)
{
	if (m_fOpend)
		ar->EndGroup();
	m_fOpend = FALSE;
}
