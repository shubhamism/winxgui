/* -------------------------------------------------------------------------
//	�ļ���		��	office_user.cpp
//	������		��	����
//	����ʱ��	��	2004-9-29 16:44:55
//	��������	��	
//	$Id: office_user.cpp,v 1.9 2005/01/11 13:14:40 wanli Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_document.h"
#include "office_user.h"

#include <doctarget.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeUserHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	ASSERT(pAttrs);

	// ȡ�������
	HRESULT hr;
	UINT uUserID;
	hr = pAttrs->GetByID(office_user_id, &uUserID);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	BSTR szUserName;
	hr = pAttrs->GetByID(office_user_name, &szUserName);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	BSTR szUserNameAbbr = szUserName;
	hr = pAttrs->GetByID(office_user_initials, &szUserNameAbbr);

	// ����
	KDWUsers& theUsers = m_pDocTarget->GetAllUsers();
	UINT uID;
	hr = theUsers.Add(szUserName, szUserNameAbbr, &uID);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	// ����ӳ���ϵ
	return m_pDocTarget->MapAllUserID(uUserID, uID);
}

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeUsersHandlerLast::EndElement(IN ELEMENTID uElementID)
{
	if (office_users == uElementID)
	{
		m_pDocTarget->WriteUsersLast();
	}

	return S_OK;
}