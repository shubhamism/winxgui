/* -------------------------------------------------------------------------
//	�ļ���		��	testdoc2rtf_draw.cpp
//	������		��	���὿
//	����ʱ��	��	2005-9-2 14:27:16
//	��������	��	
//
//	$Id: testdoc2rtf_draw.cpp,v 1.2 2006/04/18 05:42:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testdoc2rtf.h"
// -------------------------------------------------------------------------
class testdoc2rtf_draw : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(testdoc2rtf_draw);		
		CPPUNIT_TEST(testArttext);
	CPPUNIT_TEST_SUITE_END();
public:
	void setUp() {}
	void tearDown()
	{		
	}

public:
	void testArttext()
	{
		testDoc2RtfFile("draw/embpic/arttext.doc", "embpic_arttext.rtf");
	}	
};


CPPUNIT_TEST_SUITE_REGISTRATION_DBG(testdoc2rtf_draw);
// -------------------------------------------------------------------------
//	$Log: testdoc2rtf_draw.cpp,v $
//	Revision 1.2  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.1  2005/09/12 01:44:45  xulingjiao
//	������ʽ���б��Ķ��BUGs
//	
