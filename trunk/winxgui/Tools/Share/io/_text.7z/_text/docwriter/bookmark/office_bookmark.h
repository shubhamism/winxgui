/* -------------------------------------------------------------------------
//	�ļ���		��	office_bookmark.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 16:46:11
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_BOOKMARK_H__
#define __OFFICE_BOOKMARK_H__

#ifndef __BOOKMARKCONNECT_H__
#include "bookmarkconnect.h"
#endif

// -------------------------------------------------------------------------

class KOfficeBookmarkHandler : public KFakeUnknown<KElementHandler>
{
private:
	KBookmarkConnection* m_pConnection;
	
public:
	STDMETHODIMP_(void) Init(
		IN KBookmarkConnection* pConnection)
	{
		m_pConnection = pConnection;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_BOOKMARK_H__ */
