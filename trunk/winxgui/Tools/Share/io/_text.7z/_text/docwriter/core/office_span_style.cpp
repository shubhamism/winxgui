/* -------------------------------------------------------------------------
//	�ļ���		��	office_span_style.cpp
//	������		��	����
//	����ʱ��	��	2004-8-17 15:43:09
//	��������	��	
//	$Id: office_span_style.cpp,v 1.11 2006/08/23 02:19:31 chenghui Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_span_style.h"
#include "attributes/attrtrans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KOfficeSpanStyleHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	HRESULT hr = E_FAIL;
	{
		KDWStyleSheet& StyleSheet = m_pDocTarget->GetStyleSheet();

		ATTRVALUE_PTR pVal(NULL);
		UINT uSti = stiUser;
		if (pAttrs->GetIndex(kso::office_style_sti, &pVal) != -1)
			uSti = pVal->lVal;
		if (pAttrs->GetIndex(kso::office_style_name, &pVal) != -1)
		{
			KDWStyle Style;
			StyleSheet.NewStyle(uSti, pVal->bstrVal, mso_sgcCharacter, &Style);

			KDWPropBuffer* pPropBuffer = m_pDocTarget->GetPropBuffer();
			hr = TransSpanAttr(m_pDocTarget, pAttrs, pPropBuffer);
			KS_CHECK(hr);
			Style.SetSprmList(mso_sgcCharacter, pPropBuffer);

			UINT uStyleId = 0;
			KDWStyleRelation StyleInfo;
			if (pAttrs->GetIndex(kso::office_style_id, &pVal) != -1)
				uStyleId = pVal->lVal;
			KDWStyleIDMap& IdMap = m_pDocTarget->GetRStyleIDMap();
			//IdMap.insert(__std::make_pair(uStyleId, pStyle->GetIndex()));
			StyleInfo.nIstd = Style.GetIndex();
			IdMap[uStyleId] = StyleInfo.nIstd;

			if (pAttrs->GetIndex(kso::office_base_style, &pVal) != -1)
				StyleInfo.nBase = pVal->lVal;
			if (pAttrs->GetIndex(kso::office_link_style, &pVal) != -1)
				StyleInfo.nLink = pVal->lVal;

			m_pInfoMap->push_back(StyleInfo);
		}
		else
		{
			KS_CHECK(hr = E_FAIL);
		}
	}

KS_EXIT:
	return hr;
}


// -------------------------------------------------------------------------
