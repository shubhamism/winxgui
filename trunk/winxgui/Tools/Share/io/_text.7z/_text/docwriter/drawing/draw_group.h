/* -------------------------------------------------------------------------
//	�ļ���		��	draw_group.h
//	������		��	����
//	����ʱ��	��	2004-9-20 16:21:45
//	��������	��	��϶������Anchor�µ�Group��ǩ��Group��ǩ�Լ�Group�µ�Shape��ǩ��
//	$Id: draw_group.h,v 1.11 2006/11/29 03:21:04 laipinge Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAW_GROUP_H__
#define __DRAW_GROUP_H__

#ifndef __DRAW_SHAPE_H__
#include "draw_shape.h"
#endif

// -------------------------------------------------------------------------
template<class E>
class _KDWChildAnchor : public E
{
public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		ASSERT(E::m_pContext);
		ASSERT(E::m_pContext->m_shape.Good());
		int nWidth = 0;
		int nHeight = 0;
		if (pAttrs && E::m_pContext->m_shape.Good())
		{
			KROAttributes* pAttrRect = NULL;
			pAttrs->GetByID(kso::draw_rect, &pAttrRect);
			ASSERT(pAttrRect);
			if (pAttrRect)
			{
				RECT rect;
				ZeroStruct(rect);
				pAttrRect->GetByID(kso::draw_x,		&rect.left);
				pAttrRect->GetByID(kso::draw_y,		&rect.top);
				pAttrRect->GetByID(kso::draw_width, &rect.right);
				pAttrRect->GetByID(kso::draw_height,&rect.bottom);
				
				nWidth = rect.right;
				nHeight = rect.bottom;

				rect.right	+= rect.left;
				rect.bottom	+= rect.top;

				LONG rotation = 0;
				if (SUCCEEDED(pAttrs->GetByID(draw_rotation, &rotation)))
				{
					if (MsoShape::IsChangeRect(_DW_Fix2Float(rotation)))
						rect = MsoShape::AdjustShapeBoundRect(rect);
				}
				
				E::m_pContext->m_shape.SetChildAnchor(rect);
			}
			
			KROAttributes* pAttrClientData = NULL;
			pAttrs->GetByID(kso::text_dgData, &pAttrClientData);
			if (pAttrClientData)
			{	
				MsoShapeOPT& optUDef = m_pContext->m_optUDef;
				UINT uValue;

				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataTextRotate, &uValue) ))
				{
					optUDef.AddPropFix(ksextopt_TextRotate, uValue);
				}
				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataTextResize, &uValue) ))
				{
					optUDef.AddPropFix(ksextopt_TextResize, uValue);
				}
				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataInnerWidth, &uValue)))
				{
					optUDef.AddPropFix(ksextopt_InnerWidth, uValue);
				}
				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataInnerHeight, &uValue)))
				{
					optUDef.AddPropFix(ksextopt_InnerHeight, uValue);
				}

				KROAttributes* pAttrHorzLine = NULL;
				pAttrClientData->GetByID(kso::text_dgHorzLine, &pAttrHorzLine);
				if (pAttrHorzLine)
				{	
					MsoShapeOPT& optUDef = m_pContext->m_optUDef;
					UINT uValue;

					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHorzLineCXWidthRel, &uValue) ))
					{
						optUDef.AddPropFix(msopt_spCXWidthRel, uValue);
					}
					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHoriLineAlignCenter, &uValue) ))
					{
						optUDef.AddPropFix(msopt_spJc, uValue);
					}
					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHorzLineCXWidth, &uValue)))
					{
						optUDef.AddPropFix(msopt_spCXWidth, uValue);
					}
					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHorzLineCYHeight, &uValue)))
					{
						optUDef.AddPropFix(msopt_spCYHeight, uValue);
					}
				}
			}
		}
		KROAttributes* pOleObject = NULL;
		pAttrs->GetByID(draw_ole_object, &pOleObject);
		//
		// Ole����
		//
		if (pOleObject)
		{
			UINT uStgId = (UINT)-1;
			VERIFY_OK(
				pOleObject->GetByID(draw_ole_medium_source, &uStgId)
				);

			KDWOleShape oleshape = _NewOleShape(pOleObject, nWidth, nHeight);
			m_pContext->m_pDocTarget->SetOleStorage(uStgId, oleshape);
		}
		HRESULT hr = E::StartElement(uElementID, pAttrs);
		ASSERT_OK(hr);
		if (FAILED(hr))
			return hr;


		KROAttributes* textAttr = NULL;
		pAttrs->GetByID(kso::draw_text_prop, &textAttr);
		if (textAttr)
		{
			if (
				m_pContext->m_pDocTarget->getFeature().writeKsExt()
				)
			{
				UINT textFlow = kso::TextFlowNormal;
				if (SUCCEEDED(
					textAttr->GetByID(kso::draw_text_flow, &textFlow))
					)
				{
					UINT8 data[2];
					data[0] = ksopt_textframeFlow;
					data[1] = textFlow;
					m_pContext->m_optUDef.AddPropVar(
						ksextopt_textCodeExt, data, 2
						);
				}
			}
		}

		return hr;
	}
private:
	STDMETHODIMP_(KDWOleShape) _NewOleShape(IN KROAttributes* pOleObject, int nWidth, int nHeight)
	{
		WCHAR szNull[] = { '\0' };
		UINT oleType = ksoOleEmbedded;
		BSTR szProgID = szNull;
		pOleObject->GetByID(draw_ole_progid, &szProgID);
		pOleObject->GetByID(draw_ole_type, &oleType);
		const SIZE size = {nWidth, nHeight};
		if (oleType == ksoOleEmbedded)
		{
			return m_pContext->m_pDocTarget->AddOleEmbed(
				E::m_pContext->m_shape,
				size,
				szProgID);
		}
		else
		{
			BSTR szMonkier = szNull;
			pOleObject->GetByID(draw_ole_moniker, &szMonkier);
			return m_pContext->m_pDocTarget->AddOleLink(
				E::m_pContext->m_shape,
				size,
				szProgID,
				szMonkier);
		}
	}
};

// -------------------------------------------------------------------------
class _KDWDrawShapeHandler : public 
	_KDWChildAnchor< MsoDrawShapeHandler<KDWShapeHandlerContext> >
{
};

// -------------------------------------------------------------------------
class _KDWDrawGroupHandler;
class KDWAnchorGroupHandler : public KFakeUnknown<KElementHandler>
{
protected:
	KDWShapeHandlerContext* m_pContext; // ����AnchorHandler��Context.

private:
	KDWShapeHandlerContext	m_ShapeContext;
	_KDWDrawShapeHandler*	m_pShapeElement;
	_KDWDrawGroupHandler*	m_pGroupElement;

public:
	KDWAnchorGroupHandler()
	{
		m_pShapeElement = NULL;
		m_pGroupElement = NULL;
	}
	~KDWAnchorGroupHandler();

	STDMETHODIMP_(void) Init(
		IN KDWShapeHandlerContext* pContext)
	{
		m_pContext = pContext;
		m_ShapeContext.m_pDocTarget = m_pContext->m_pDocTarget;
		m_ShapeContext.m_pDgg		= m_pContext->m_pDgg;
	}

public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		return m_pContext->SetGroupShapeOPT(pAttrs);
	}
	
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
	
	STDMETHODIMP EndElement(IN ELEMENTID uElementID)
	{
		return m_pContext->EndShape();
	}
};

// -------------------------------------------------------------------------
class _KDWDrawGroupHandler : public _KDWChildAnchor<KDWAnchorGroupHandler>
{
};

// -------------------------------------------------------------------------
inline
KDWAnchorGroupHandler::~KDWAnchorGroupHandler()
{
	delete m_pShapeElement;
	delete m_pGroupElement;
}

// -------------------------------------------------------------------------
inline
STDMETHODIMP KDWAnchorGroupHandler::EnterSubElement(
	IN ELEMENTID uSubElementID,
	OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case kso::draw_shape:
		if (m_pShapeElement == NULL)
		{
			m_pShapeElement = new _KDWDrawShapeHandler;
			m_pShapeElement->Init(&m_ShapeContext);
		}
		m_ShapeContext.m_shape = m_pContext->m_shape.NewShape();
		*ppHandler = m_pShapeElement;
		break;
	case kso::draw_group:
		if (m_pGroupElement == NULL)
		{
			m_pGroupElement = new _KDWDrawGroupHandler;
			m_pGroupElement->Init(&m_ShapeContext);
		}
		m_ShapeContext.m_shape = m_pContext->m_shape.NewGroupShape();
		*ppHandler = m_pGroupElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------

#endif /* __DRAW_GROUP_H__ */
// $Log: draw_group.h,v $
// Revision 1.11  2006/11/29 03:21:04  laipinge
// �������ole����
//
// Revision 1.10  2006/11/02 06:16:43  zhuyie
// Bug31760.
//
// Revision 1.9  2006/10/26 02:30:12  wangdong
// HorzLine
//
// Revision 1.8  2006/07/31 07:00:04  wangdong
// #26126������дdocʱ��feature��������ݡ�
//
// Revision 1.7  2006/07/24 08:00:17  wangdong
// �Ӷ������ַ���
//
// Revision 1.6  2006/03/14 06:30:02  wangdong
// ������ChildShape��ClientData��
//
// Revision 1.5  2005/02/24 03:21:42  wangdong
// �������������롣
//
// Revision 1.4  2005/02/24 03:20:46  wangdong
// �����ˣ���϶����Ӷ������ʱ����ת������
//
