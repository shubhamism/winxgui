/* -------------------------------------------------------------------------
//	�ļ���		��	draw_rules.h
//	������		��	�ݽ���
//	����ʱ��	��	2005-7-26 16:34:40
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DRAW_RULES_H__
#define __DRAW_RULES_H__

#ifndef __DRAW_CONNECTOR_RULE_H__
#include "draw_connector_rule.h"
#endif

// -------------------------------------------------------------------------
class KDrawRulesHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KDrawConnectorRuleHandler m_ConnRuleElem;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElement, OUT IKElementHandler** ppv)
	{
		if (kso::draw_conn_rule == uSubElement)
		{
			m_ConnRuleElem.Init(m_pDocTarget);
			*ppv = &m_ConnRuleElem;

			return S_OK;
		}

		_kso_UnexpectedElement(uSubElement);
		return E_UNEXPECTED;
	}
};


// -------------------------------------------------------------------------

#endif /* __DRAW_RULES_H__ */
