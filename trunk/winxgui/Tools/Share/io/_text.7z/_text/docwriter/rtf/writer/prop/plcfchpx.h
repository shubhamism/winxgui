/* -------------------------------------------------------------------------
//	�ļ���		��	plcfchpx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:49:34
//	��������	��	
//
//	$Id: plcfchpx.h,v 1.3 2006/01/21 09:06:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PLCFCHPX_H__
#define __PLCFCHPX_H__
#include "chpx.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWChpxsWriter
{
private:
	const KDWPlcfChpx* m_chpxs;
	RtfWGlobalInfo* m_ginfo;

	KDWPlcfChpx::Enumerator m_enumer;

	RtfWChpxWriter m_wrChpx;
	INT m_istdpara;
	BOOL m_fOpend;

public:
	RtfWChpxsWriter(
		const KDWPlcfChpx* chpxs, RtfWGlobalInfo* info);
	STDMETHODIMP_(RtfWChpxWriter&) GetChpInfo()
	{
		return m_wrChpx;
	}
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();	
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) SetIstdPara(INT istdpara);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
	STDMETHODIMP_(void) WriteStartGroup(RtfDirectWriter* ar);
	STDMETHODIMP_(void) EnsureWriteEnd(RtfDirectWriter* ar);
};
// -------------------------------------------------------------------------
//	$Log: plcfchpx.h,v $
//	Revision 1.3  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.2  2006/01/20 08:43:00  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:02  xulingjiao
//	*** empty log message ***
//	

#endif /* __PLCFCHPX_H__ */
