/* -------------------------------------------------------------------------
//	�ļ���		��	listtable.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:06:06
//	��������	��	
//
//	$Id: listtable.h,v 1.4 2006/03/23 09:41:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __LISTTABLE_H__
#define __LISTTABLE_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfDirectWriter;
class RtfWlistPictureWriter
{
private:
	const KDWPicBullets* m_bullets;
private:
	STDMETHODIMP_(void) WriteBulletAttribute(RtfDirectWriter* ar, const KDWBlip* pBlip);
	STDMETHODIMP_(void) WriteBulletPicture(RtfDirectWriter* ar, const KDWBlip* pBlip);
public:
	RtfWlistPictureWriter(const KDWPicBullets* bullets);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
};

class RtfWListTableWriter
{
private:
	RtfWlistPictureWriter* m_listPicWriter;
	
public:
	RtfWListTableWriter();
	STDMETHODIMP_(void) SetListPictureWriter(RtfWlistPictureWriter* listPicWriter);
	STDMETHODIMP Write(RtfDirectWriter* ar, RtfWGlobalInfo* info);
};
// -------------------------------------------------------------------------
//	$Log: listtable.h,v $
//	Revision 1.4  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.3  2006/03/07 08:35:54  xulingjiao
//	�޸��Ʊ�λ��BUG
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __LISTTABLE_H__ */
