/* -------------------------------------------------------------------------
//	�ļ���		��	plcfsepx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:56:12
//	��������	��	
//
//	$Id: plcfsepx.cpp,v 1.4 2006/09/05 07:20:55 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "../headerfooter.h"
#include "rtf/writer/include/rtffile.h"
#include "sepx.h"
#include "plcfsepx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWSepxsWriter::RtfWSepxsWriter(const KDWSections* sepxs) : m_sepxs(sepxs), m_wrHdFt(NULL)
{
	Reset();
}
STDMETHODIMP_(BOOL) RtfWSepxsWriter::Good() const
{
	return m_sepxs != NULL && m_sepxs->Count();
}
STDMETHODIMP_(void) RtfWSepxsWriter::SetHdFtWriter(RtfWHeaderFooterWriter* wrHdFt)
{
	m_wrHdFt = wrHdFt;
}
STDMETHODIMP_(void) RtfWSepxsWriter::Reset()
{
	m_enumer = KDWSections::Enumerator(m_sepxs);
	m_enumer.Next();
}
STDMETHODIMP RtfWSepxsWriter::Next()
{
	if (FAILED(m_enumer.Next()))
		return E_FAIL;
	return S_OK;
}
STDMETHODIMP_(UINT) RtfWSepxsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.Range().cp;
}
STDMETHODIMP_(UINT) RtfWSepxsWriter::GetNextCp()
{
	return (UINT)m_enumer.Range().cpNext;
}
STDMETHODIMP_(void) RtfWSepxsWriter::Write(RtfWGlobalInfo* info, RtfDirectWriter* ar)
{
	KDWSection sect = m_enumer.Item();
	RtfWSepxWriter wrSepx;
	wrSepx.Write(ar, info, &sect.prop);
	RtfWSectionPr sep = wrSepx.GetSep();
	if (m_wrHdFt != NULL)
		m_wrHdFt->Write(ar, &sect, info->dop->dop.fFacingPages, sep.fTitlePage);
}
