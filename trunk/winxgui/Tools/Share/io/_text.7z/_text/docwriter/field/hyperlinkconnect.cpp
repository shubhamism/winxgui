/* -------------------------------------------------------------------------
//	�ļ���		��	hyperlinkconnect.cpp
//	������		��	����
//	����ʱ��	��	2004-8-24 10:33:18
//	��������	��	
//	$Id: hyperlinkconnect.cpp,v 1.7 2004/11/26 08:30:55 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "doctarget.h"
#include "hyperlinkconnect.h"
#include "text_hyperlink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
#define HYPERLINK_FIELD_NAME __X("Hyperlink")

// -------------------------------------------------------------------------
STDMETHODIMP KHyperlinkConnection::CreateHyperlinkHandler(
  OUT IKElementHandler** ppHandler)
{
	KOfficeHyperlinksHandler* pHandler = DW_NEWHANDLER(KOfficeHyperlinksHandler);
	pHandler->Init(GetDocTarget());
	*ppHandler = pHandler;
	return S_OK;
}

// -------------------------------------------------------------------------
STDMETHODIMP KHyperlinkConnection::AddHyperlink(
		IN LPCWSTR szHref,
		IN LPCWSTR szBookmark,
		IN LPCWSTR szTargetFrame,
		IN LPCWSTR szToolTip,
		IN LPCWSTR szStyle,
		IN LPCWSTR szVisitedStyle)
{
	HyperlinkInfo info;
	info.strHref = szHref;
	info.strBookmark = szBookmark;
	info.strTargetFrame = szTargetFrame;
	info.strToolTip = szToolTip;
	info.szStyle = szStyle;
	info.szVisitedStyle = szVisitedStyle;

	m_HyperlinkList.push_back(info);

	return S_OK;
}

// ----------------------------------------------------------------------------
#define __Space_Char			__X(" ")
#define __InsertText(_Text)		(strFieldCode += _Text)
#define __InsertSpace()			__InsertText(__Space_Char)
#define __InsertArg(_Arg, _Content)												\
		if (_Content.length())													\
		{																		\
			__InsertSpace();													\
			if (::wcslen(_Arg))													\
			{																	\
				__InsertText(_Arg);												\
				__InsertSpace();												\
			}																	\
			__InsertText(_Content);												\
		}

// ----------------------------------------------------------------------------
STDMETHODIMP KHyperlinkConnection::BeginHyperlink(
	IN UINT uHyperlinkId)
{
	HRESULT hr = S_OK;
	ks_wstring strFieldCode;

	if (uHyperlinkId < 0 || uHyperlinkId >= m_HyperlinkList.size())
		KS_CHECK(hr = E_FAIL);

	hr = m_pDocTarget->MarkFieldBegin(0x58, FALSE); // hyperlink û�ҵ�ö��, ������
	KS_CHECK(hr);

	/* make " Hyperlink " */
	__InsertSpace();
	__InsertText(HYPERLINK_FIELD_NAME);

	/* make arguments */
	{
		HyperlinkInfo& Info = m_HyperlinkList[uHyperlinkId];

		__InsertArg(__X(""),	Info.strHref)
		__InsertArg(__X("\\l"), Info.strBookmark)
		__InsertArg(__X("\\o"),	Info.strToolTip)
		__InsertArg(__X("\\t"),	Info.strTargetFrame)
	}

	/* make a space char before field seperator */
	__InsertSpace();

	m_pDocTarget->AddContent(strFieldCode.c_str(), strFieldCode.length());
	KS_CHECK(hr);

	m_pDocTarget->MarkFieldSeparator();

	++m_uNestLevel;

KS_EXIT:
	return hr;
}

STDMETHODIMP KHyperlinkConnection::EndHyperlink()
{
	if (m_uNestLevel > 0)
		return --m_uNestLevel, m_pDocTarget->MarkFieldEnd();
	ASSERT_ONCE(0);
	return S_FALSE;
}

// -------------------------------------------------------------------------
