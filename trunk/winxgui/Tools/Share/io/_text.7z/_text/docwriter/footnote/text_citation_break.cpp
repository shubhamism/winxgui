/* -------------------------------------------------------------------------
//	�ļ���		��	text_citation_break.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-17 17:46:47
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

#ifndef __TEXT_CITATION_BREAK_H__
#include "text_citation_break.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextCitationBreakHandler::EndElement(IN ELEMENTID uElementID)
{
	ASSERT(m_pDocTarget);
	if (!m_bCustom)
		return m_pDocTarget->AddFndEndRef();
	return S_OK;
}

// -------------------------------------------------------------------------
