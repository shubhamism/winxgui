/* -------------------------------------------------------------------------
//	�ļ���		��	ranges.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:12:45
//	��������	��	
//
//	$Id: ranges.cpp,v 1.12 2006/08/07 01:51:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "prop/plcfchpx.h"
#include "prop/plcfpapx.h"
#include "prop/plcfsepx.h"
#include "range/bookmarks.h"
#include "range/fndends.h"
#include "range/fields.h"
#include "textstream.h"
#include "ranges.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(RtfWChpxWriter&) RtfWRangesWriter::GetChpInfo()
{
	return m_wrChpxs->GetChpInfo();
}
RtfWRangesWriter::RtfWRangesWriter(RtfWGlobalInfo* info) :
	m_ginfo(info),
	m_wrChpxs(NULL),
	m_wrPapxs(NULL),
	m_wrSepxs(NULL),
	m_wrBookmarkStarts(NULL),
	m_wrBookmarkEnds(NULL),	
	m_wrFnds(NULL),
	m_wrEnds(NULL),
	m_wrFields(NULL),
	m_wrAtnStarts(NULL),
	m_wrAtnEnds(NULL),	
	m_cp(-1)
{		
}

STDMETHODIMP_(RtfWGlobalInfo*) RtfWRangesWriter::GetGlobalInfo()
{
	return m_ginfo;
}

STDMETHODIMP_(RtfWPapxWriter&) RtfWRangesWriter::GetPapInfo()
{
	return m_wrPapxs->GetPapInfo();
}

STDMETHODIMP_(void) RtfWRangesWriter::SetPlcfChpx(RtfWChpxsWriter* wrChpxs)
{
	if(wrChpxs && wrChpxs->Good())
		m_wrChpxs = wrChpxs;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetPlcfPapx(RtfWPapxsWriter* wrPapxs)
{		
	if(wrPapxs && wrPapxs->Good())
		m_wrPapxs = wrPapxs;		
}	
STDMETHODIMP_(void) RtfWRangesWriter::SetPlcfSepx(RtfWSepxsWriter* wrSepxs)
{
	if(wrSepxs && wrSepxs->Good())
		m_wrSepxs = wrSepxs;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetBookmarkStarts(RtfWBookmarkStartsWriter* wrStarts)
{
	if(wrStarts && wrStarts->Good())
		m_wrBookmarkStarts = wrStarts;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetBookmarkEnds(RtfWBookmarkEndsWriter* wrEnds)
{
	if(wrEnds && wrEnds->Good())
		m_wrBookmarkEnds = wrEnds;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetAtnStarts(RtfWAtnRefStartsWriter* wrAtnStarts)
{
	if(wrAtnStarts && wrAtnStarts->Good())
		m_wrAtnStarts = wrAtnStarts;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetAtnEnds(RtfWAtnRefEndsWriter* wrAtnEnds)
{
	if(wrAtnEnds && wrAtnEnds->Good())
		m_wrAtnEnds = wrAtnEnds;
}

STDMETHODIMP_(void) RtfWRangesWriter::SetFnds(RtfWFndsWriter* wrFnds)
{
	if(wrFnds && wrFnds->Good())
		m_wrFnds = wrFnds;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetEnds(RtfWEndsWriter* wrEnds)
{
	if(wrEnds && wrEnds->Good())
		m_wrEnds = wrEnds;
}
STDMETHODIMP_(void) RtfWRangesWriter::SetFields(RtfWFieldsWriter* wrFields)
{
	if(wrFields && wrFields->Good())
		m_wrFields = wrFields;
}
STDMETHODIMP_(void) RtfWRangesWriter::Reset()
{
	if (m_wrChpxs)
		m_wrChpxs->Reset();		
	if (m_wrPapxs)
		m_wrPapxs->Reset();
	if (m_wrSepxs)
		m_wrSepxs->Reset();
	if (m_wrBookmarkStarts)
		m_wrBookmarkStarts->Reset();
	if (m_wrBookmarkEnds)
		m_wrBookmarkEnds->Reset();
	if (m_wrFnds)
		m_wrFnds->Reset();
	if (m_wrEnds)
		m_wrEnds->Reset();
	if (m_wrFields)
		m_wrFields->Reset();
	if (m_wrAtnStarts)
		m_wrAtnStarts->Reset();
	if (m_wrAtnEnds)
		m_wrAtnEnds->Reset();	
	
	m_cp = __GetCp();

	if (m_wrPapxs && m_wrChpxs)
		m_wrChpxs->SetIstdPara(m_wrPapxs->GetIstd(m_cp));
}	
STDMETHODIMP RtfWRangesWriter::Next()
{
	HRESULT hr = E_FAIL;
	
	if (m_wrSepxs && m_current.fSepxs)
		hr = SUCCEEDED(m_wrSepxs->Next()) ? S_OK : hr;

	if (m_wrPapxs && m_current.fPapxs)
		hr = SUCCEEDED(m_wrPapxs->Next()) ? S_OK : hr;
	
	if (m_wrChpxs && m_current.fChpxs)
		hr = SUCCEEDED(m_wrChpxs->Next()) ? S_OK : hr;
	
	if (m_wrBookmarkStarts && m_current.fBookmarkStarts)
		hr = SUCCEEDED(m_wrBookmarkStarts->Next()) ? S_OK : hr;
	
	if (m_wrBookmarkEnds && m_current.fBookmarkEnds)
		hr = SUCCEEDED(m_wrBookmarkEnds->Next()) ? S_OK : hr;
	
	if (m_wrFnds && m_current.fFnds)
		hr = SUCCEEDED(m_wrFnds->Next()) ? S_OK : hr;
	
	if (m_wrEnds && m_current.fEnds)
		hr = SUCCEEDED(m_wrEnds->Next()) ? S_OK : hr;
	
	if (m_wrFields && m_current.fFields)
		hr = SUCCEEDED(m_wrFields->Next()) ? S_OK : hr;

	if (m_wrAtnStarts && m_current.fAtnStarts)
		hr = SUCCEEDED(m_wrAtnStarts->Next()) ? S_OK : hr;

	if (m_wrAtnEnds && m_current.fAtnEnds)
		hr = SUCCEEDED(m_wrAtnEnds->Next()) ? S_OK : hr;

	INT cpOld = m_cp;
	m_cp = __GetCp();
	if (cpOld != m_cp)
		hr = S_OK;

	if (SUCCEEDED(hr))
	{
		// �����ǰ�θı䣬���istdparaҪ��������
		if (m_current.fPapxs && m_wrPapxs && m_wrChpxs)			
			m_wrChpxs->SetIstdPara(m_wrPapxs->GetIstd(m_cp));
	}
	return hr;
}
STDMETHODIMP_(CP) RtfWRangesWriter::GetCp()
{		
	return m_cp;
}
STDMETHODIMP_(CP) RtfWRangesWriter::GetNextCp()
{
	return __GetCpNext();
}
STDMETHODIMP_(CP) RtfWRangesWriter::GetSectCurrentCp()
{
	if(m_wrSepxs)
		return m_wrSepxs->GetCurrentCp();
	return -1;
}
STDMETHODIMP_(KDWRange) RtfWRangesWriter::GetRefRange(BOOL fEndNote)
{
	if(fEndNote)
		return m_wrEnds->RefRange();
	return m_wrFnds->RefRange();
}
STDMETHODIMP_(void) RtfWRangesWriter::Write(RtfDirectWriter* ar)
{
	CP cpLast = 0;
	EnsureWriteEnd(ar);
	if (m_current.fSepxs && m_wrSepxs)
		m_wrSepxs->Write(m_ginfo, ar);
	if (m_current.fPapxs && m_wrPapxs)
		m_wrPapxs->Write(ar);	
	if (m_current.fFields && m_wrFields)	
		m_wrFields->Write(ar);
	if (m_current.fChpxs && m_wrChpxs)
		m_wrChpxs->Write(ar);
	if (m_current.fFnds && m_wrFnds)
	{
		// ������д�������ı�
		m_ginfo->wrMainStream->WriteNoteRef(ar, GetRefRange(FALSE).cp);
		m_wrFnds->Write(ar, FALSE);
	}
	if (m_current.fEnds && m_wrEnds)
	{
		// ������д�������ı�
		m_ginfo->wrMainStream->WriteNoteRef(ar, GetRefRange(TRUE).cp);
		m_wrEnds->Write(ar, TRUE);
	}
	if (m_current.fBookmarkStarts && m_wrBookmarkStarts)
		m_wrBookmarkStarts->Write(ar);
	if (m_current.fBookmarkEnds && m_wrBookmarkEnds)
		m_wrBookmarkEnds->Write(ar);
	if (m_current.fAtnStarts && m_wrAtnStarts)
		m_wrAtnStarts->Write(ar);
	if (m_current.fAtnEnds && m_wrAtnEnds)
		m_wrAtnEnds->Write(ar);	
}
STDMETHODIMP_(void) RtfWRangesWriter::EnsureWriteEnd(RtfDirectWriter* ar)
{
	if (m_wrChpxs && (m_current.fChpxs || m_current.fPapxs || m_current.fSepxs))	
		m_wrChpxs->EnsureWriteEnd(ar);	
}
UINT RtfWRangesWriter::__GetCp()
{
	UINT cp = (UINT)-1;

	UINT cpSepxs = cp;
	UINT cpPapxs = cp;
	UINT cpChpxs = cp;
	UINT cpBookmarkStarts = cp;
	UINT cpBookmarkEnds = cp;	
	UINT cpFnds = cp;
	UINT cpEnds = cp;
	UINT cpFields = cp;
	UINT cpAtnStarts = cp;
	UINT cpAtnEnds = cp;	

	if (m_wrSepxs)
		cpSepxs = m_wrSepxs->GetCurrentCp();		

	if (m_wrPapxs)
		cpPapxs = m_wrPapxs->GetCurrentCp();

	if (m_wrChpxs)
		cpChpxs = m_wrChpxs->GetCurrentCp();

	if (m_wrBookmarkStarts)
		cpBookmarkStarts = m_wrBookmarkStarts->GetCurrentCp();		

	if (m_wrBookmarkEnds)
		cpBookmarkEnds = m_wrBookmarkEnds->GetCurrentCp();

	if (m_wrFnds)
		cpFnds = m_wrFnds->GetCurrentCp();		

	if (m_wrEnds)
		cpEnds = m_wrEnds->GetCurrentCp();		

	if (m_wrFields)
		cpFields = m_wrFields->GetCurrentCp();
	
	if (m_wrAtnStarts)
		cpAtnStarts = m_wrAtnStarts->GetCurrentCp();

	if (m_wrAtnEnds)
		cpAtnEnds = m_wrAtnEnds->GetCurrentCp();	

	if (cpPapxs <= cp)
	{
		if (cpPapxs < cp)
			m_current.Reset();
		m_current.fPapxs = TRUE;
		cp = cpPapxs;
	}
	if (cpSepxs <= cp)
	{
		if (cpSepxs < cp)
			m_current.Reset();
		m_current.fSepxs = TRUE;
		cp = cpSepxs;
	}
	if (cpChpxs <= cp)
	{
		if (cpChpxs < cp)
			m_current.Reset();
		m_current.fChpxs = TRUE;
		cp = cpChpxs;
	}
	if (cpBookmarkStarts <= cp)
	{
		if (cpBookmarkStarts < cp)
			m_current.Reset();
		m_current.fBookmarkStarts = TRUE;
		cp = cpBookmarkStarts;
	}
	if (cpBookmarkEnds <= cp)
	{
		if (cpBookmarkEnds < cp)
			m_current.Reset();
		m_current.fBookmarkEnds = TRUE;
		cp = cpBookmarkEnds;
	}	
	if (cpFnds <= cp)
	{
		if (cpFnds < cp)
			m_current.Reset();
		m_current.fFnds = TRUE;
		cp = cpFnds;
	}
	if (cpEnds <= cp)
	{
		if (cpEnds < cp)
			m_current.Reset();
		m_current.fEnds = TRUE;
		cp = cpEnds;
	}
	if (cpFields <= cp)
	{
		if (cpFields < cp)
			m_current.Reset();
		m_current.fFields = TRUE;
		cp = cpFields;
	}
	if (cpAtnStarts <= cp)
	{
		if (cpAtnStarts < cp)
			m_current.Reset();
		m_current.fAtnStarts = TRUE;
		cp = cpAtnStarts;
	}
	if (cpAtnEnds <= cp)
	{
		if (cpAtnEnds < cp)
			m_current.Reset();
		m_current.fAtnEnds = TRUE;
		cp = cpAtnEnds;
	}	
	return cp;
}
// todo: ����__GetCpһ�����Ż�
UINT RtfWRangesWriter::__GetCpNext()
{
	UINT cpNext = (UINT)-1;

	UINT cpSepxs = cpNext;
	UINT cpPapxs = cpNext;
	UINT cpChpxs = cpNext;
	UINT cpBookmarkStarts = cpNext;
	UINT cpBookmarkEnds = cpNext;	
	UINT cpFnds = cpNext;
	UINT cpEnds = cpNext;
	UINT cpFields = cpNext;
	UINT cpAtnStarts = cpNext;
	UINT cpAtnEnds = cpNext;	

	if (m_wrSepxs)
		cpSepxs = m_wrSepxs->GetNextCp();
	if (m_wrPapxs)
		cpPapxs = m_wrPapxs->GetNextCp();
	if (m_wrChpxs)
		cpChpxs = m_wrChpxs->GetNextCp();
	if (m_wrBookmarkStarts)
		cpBookmarkStarts = m_wrBookmarkStarts->GetNextCp();
	if (m_wrBookmarkEnds)
		cpBookmarkEnds = m_wrBookmarkEnds->GetNextCp();
	if (m_wrFnds)
		cpFnds = m_wrFnds->GetNextCp();
	if (m_wrEnds)
		cpEnds = m_wrEnds->GetNextCp();
	if (m_wrFields)
		cpFields = m_wrFields->GetNextCp();
	if (m_wrAtnStarts)
		cpAtnStarts = m_wrAtnStarts->GetNextCp();
	if (m_wrAtnEnds)
		cpAtnEnds = m_wrAtnEnds->GetNextCp();	

	if (cpPapxs <= cpNext)
		cpNext = cpPapxs;
	if (cpSepxs <= cpNext)
		cpNext = cpSepxs;
	if (cpChpxs <= cpNext)
		cpNext = cpChpxs;
	if (cpBookmarkStarts <= cpNext)
		cpNext = cpBookmarkStarts;
	if (cpBookmarkEnds <= cpNext)
		cpNext = cpBookmarkEnds;	
	if (cpFnds <= cpNext)
		cpNext = cpFnds;
	if (cpEnds <= cpNext)
		cpNext = cpEnds;
	if (cpFields <= cpNext)
		cpNext = cpFields;
	if (cpAtnStarts <= cpNext)
		cpNext = cpAtnStarts;
	if (cpAtnEnds <= cpNext)
		cpNext = cpAtnEnds;

	return cpNext;
}