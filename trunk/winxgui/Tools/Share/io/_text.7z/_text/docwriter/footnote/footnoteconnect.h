/* -------------------------------------------------------------------------
//	�ļ���		��	footnoteconnect.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 10:14:27
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __FOOTNOTECONNECT_H__
#define __FOOTNOTECONNECT_H__

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

// -------------------------------------------------------------------------

class KFootnoteConnection
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP_(KDWDocTarget*) GetDocTarget() const
	{
		ASSERT(m_pDocTarget);
		return m_pDocTarget;
	}
};

// -------------------------------------------------------------------------

#endif /* __FOOTNOTECONNECT_H__ */
