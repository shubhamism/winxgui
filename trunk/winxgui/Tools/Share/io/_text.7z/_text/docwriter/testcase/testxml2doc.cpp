/* -------------------------------------------------------------------------
//	�ļ���		��	testxml2doc.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-19 9:36:06
//	��������	��	
//
//	$Id: testxml2doc.cpp,v 1.3 2004/11/19 07:15:22 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testxml2doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#ifdef X_ENCODE_UCS2
#define testXml2DocFile(from, to)											\
	m_xml2doc.convert(														\
		L"../testcase/xmlrw/" L ## from,									\
		L"../testcase/output/" L ## to )
#else
#define testXml2DocFile(from, to)											\
	m_xml2doc.convert(														\
		__X("../testcase/xmlrw/" from),									\
		__X("../testcase/output/" to )
#endif

// -------------------------------------------------------------------------

class TestXml2Doc : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestXml2Doc);
		CPPUNIT_TEST(testPicBullet);
		CPPUNIT_TEST(testCustomMeta);
	CPPUNIT_TEST_SUITE_END();

private:
	KConvertXml2Doc m_xml2doc;
	
public:
	void setUp() {}
	void tearDown() {}

public:
	void testPicBullet()
	{
		testXml2DocFile("autonum/picbullet.xml", "_autonum_picbullet_.doc");
	}
	void testCustomMeta()
	{
		testXml2DocFile("meta/custom_meta.xml", "_meta_custom_.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestXml2Doc);

// -------------------------------------------------------------------------
//	$Log: testxml2doc.cpp,v $
//	Revision 1.3  2004/11/19 07:15:22  xushiwei
//	*** empty log message ***
//	
