/* -------------------------------------------------------------------------
//	�ļ���		��	office_annotation.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 20:32:32
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_annotation.h"
#include <texttable/text_table.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KOfficeAnnotationHandler::StartElement(
						  IN ELEMENTID uElementID,
						  IN KROAttributes* pAttrs)
{
	HRESULT hr;

	INT32 nAnnID;
	hr = pAttrs->GetByID(office_annotation_id, &nAnnID);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	INT32 nAuthorID = 0;
	hr = pAttrs->GetByID(office_annotation_author, &nAuthorID);
	if (hr != S_OK)
		{ ASSERT(FALSE); /*return hr;*/ }

	DATE theDate = 0;
	hr = pAttrs->GetDateByID(office_annotation_date, &theDate);
	if (hr != S_OK)
		{ ASSERT(FALSE); /*return hr;*/ }

	UINT uUserID;
	hr = m_pDocTarget->AnnotationUserIDLookup(nAuthorID, &uUserID);
	if (hr != S_OK)
		return hr;

	// ���������ʹ�DATEתΪDTTM
	DTTM theDTTM;
	DATE2DTTM(theDate, &theDTTM);

	// ��ʼ
	m_curhAnn = NULL;
	ASSERT(m_pDocTarget);

	KDWAnnotations* pAnnotations = const_cast<KDWAnnotations*>(m_pDocTarget->GetAnnotations());
	return pAnnotations->__EnterAnnotation(uUserID, theDTTM, nAnnID);
}

STDMETHODIMP KOfficeAnnotationHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_p:
		m_paraElement.Init(m_pDocTarget);
		*ppHandler = &m_paraElement;
		break;
	case kso_schema::text_table:
		if (m_tableElement == NULL)
		{
			m_tableElement = new KTextTableHandler;
		}
		m_tableElement->Init(m_pDocTarget);
		*ppHandler = m_tableElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

STDMETHODIMP KOfficeAnnotationHandler::EndElement(IN ELEMENTID uElementID)
{
	ASSERT(uElementID == office_annotation);

	KDWAnnotations* pAnnotations = const_cast<KDWAnnotations*>(m_pDocTarget->GetAnnotations());
	return pAnnotations->__LeaveAnnotation();
}

KOfficeAnnotationHandler::KOfficeAnnotationHandler()
{
	m_tableElement = NULL;
}

KOfficeAnnotationHandler::~KOfficeAnnotationHandler()
{
	delete m_tableElement;
}



// -------------------------------------------------------------------------
// $Log: office_annotation.cpp,v $
// Revision 1.9  2006/06/12 08:12:57  wangdong
// *** empty log message ***
//
