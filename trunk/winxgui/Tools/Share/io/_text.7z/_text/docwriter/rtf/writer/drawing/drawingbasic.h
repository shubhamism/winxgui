/* -------------------------------------------------------------------------
//	�ļ���		��	drawingbasic.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:47:44
//	��������	��	
//
//	$Id: drawingbasic.h,v 1.4 2006/04/25 00:44:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAWINGBASIC_H__
#define __DRAWINGBASIC_H__

#include "mso/io/rtf/writer/include/optparser.h"

#define msopt_ShapeType			( (PID)0 )
#define msopt_groupBottom		( (PID)1 )
#define msopt_groupLeft			( (PID)2 )
#define msopt_groupRight		( (PID)3 )
#define msopt_groupTop			( (PID)4 )
#define msopt_relRotation		( (PID)5 )
#define msopt_longValArrayMax	( (PID)6 )
#define msopt_relBottom			msopt_groupBottom
#define msopt_relLeft			msopt_groupLeft
#define msopt_relRight			msopt_groupRight
#define msopt_relTop			msopt_groupTop

#define msopt_fInitiator		( (PID)0x8000 )
#define msopt_fFlipV			( (PID)0x8001 )
#define msopt_fFlipH			( (PID)0x8002 )
#define msopt_fChangePage		( (PID)0x8003 )
#define msopt_boolValArrayMax	( (PID)0x8004 )
#define msopt_fRelFlipH			msopt_fFlipH
#define msopt_fRelFlipV			msopt_fFlipV
#define msopt_fRelChangePage	msopt_fChangePage

enum RtfSpValueType
{
	rtf_vtI4		= 0,
	rtf_vtBOOL		= 1,
	rtf_vtBLIP		= 2,
	rtf_vtSTR		= 3,
	rtf_vtARRAY		= 4,
	rtf_vtHLINK		= 5,
	rtf_vtHSHP		= 6,
	rtf_vtSKIP		= 7,
	rtf_vtMAX,
	rtf_vtBoolean	= rtf_vtBOOL,
	rtf_vtAngle		= rtf_vtI4,
	rtf_vtString	= rtf_vtSTR,
	rtf_vtArray		= rtf_vtARRAY,
	rtf_vtEMU		= rtf_vtI4,
	rtf_vtShapeID	= rtf_vtHSHP,
	rtf_vtLong		= rtf_vtI4,
	rtf_vtEnum		= rtf_vtI4,
	rtf_vtColor		= rtf_vtI4,
	rtf_vtFixed		= rtf_vtI4,
	rtf_vtPicture	= rtf_vtBLIP,
	rtf_vtTwips		= rtf_vtI4,
	rtf_vtHyperlink	= rtf_vtHLINK,
	rtf_vtSkipData	= rtf_vtSKIP,
};

enum RtfSpPropType
{
	rtf_ptProperties	 = 0,
	rtf_ptUDefProperties = 1,
	rtf_ptElse			 = 2,
};

struct CropType
{
	CropType()
	{
		Init();
	}
	void Init()
	{
		left = top = right = bottom = 0;
	}
	double left;
    double top;
    double right;
    double bottom;
};

// -------------------------------------------------------------------------

inline LPCSTR GetPropName(INT id)
{
	struct RtfSpInfo
	{
		PID spId;
		LPCSTR spName;
		RtfSpValueType spValueType;
		RtfSpPropType spPropType;
	};

	static RtfSpInfo s_items[] = 
	{
		{ (PID)0, "@unknown", rtf_vtLong, rtf_ptUDefProperties },
		#include "escherfmt/shapeopt.hxx"
	};

	for (INT i = 0; i < countof(s_items); ++i)
	{
		if (s_items[i].spId == id)
			return s_items[i].spName;
	}

	// ���ֲ���ʶ������	
	ASSERT_ONCE(0);
	return s_items[0].spName;
}

inline BOOL IsValidName(LPCSTR name)
{
	return name[0] != '@';
}
/*
typedef enum
{
	OP_BlipID	= 0x2,
	OP_Complex	= 0x4,
}
MsoPropFlags;
*/

inline BOOL IsArrayProp(UINT32 id)
{	
	switch (id)
	{
	case msopt_pVertices:				// POINT
	case msopt_pSegmentInfo:			// UINT16
	case msopt_fillShadeColors:			// (COLORREF, COLORREF), �ɵ���POINT����
	case msopt_pWrapPolygonVertices:	// POINT
	case msopt_pAdjustHandles:			// POINT
	case msopt_lineDashStyle:			// todo: UNKOWN	
	case msopt_pConnectionSites:
		return TRUE;
	}
	return FALSE;
}

inline BOOL IsWStringProp(UINT32 id)
{
	// todo: ���кö�string���͵���Ҫ����
	switch (id)
	{
	case msopt_gtextFont:
	case msopt_gtextUNICODE:
		return TRUE;
	}
	return FALSE;
}

// -------------------------------------------------------------------------

inline const FSPA* GetShapeFSPA(const _MsoShape* p)
{
	if (p->grf.fChild)
		return NULL;
	if (!p->anchor)
		return NULL;
	const _KDWShapeClientAnchor* anchor = (_KDWShapeClientAnchor*)_MsoPdata(p->anchor);
	return &anchor->data;
}

inline SIZE GetShapeSize(const _MsoShape* p)
{
	const FSPA* fspa = GetShapeFSPA(p);
	if (fspa)
	{
		SIZE size = {abs(fspa->xaRight - fspa->xaLeft), abs(fspa->yaBottom - fspa->yaTop)};
		return size;
	}
	else if (p->anchor)
	{
		const IORECT* rc = (const IORECT*)_MsoPdata(p->anchor);
		SIZE size = {abs(rc->right - rc->left), abs(rc->bottom - rc->top)};
		return size;
	}
	else
	{
		ASSERT(0);
		SIZE size = {100, 100};
		return size;
	}
}

inline SIZE GetBlipSize(const SIZE& shapesize, const CropType& crop)
{
	SIZE size =
	{
		shapesize.cx + crop.right + crop.left,
		shapesize.cy + crop.bottom + crop.top
	};
	return size;
}

inline void GetShapeAnchor(const _MsoShape* p, OUT IORECT* rc)
{
	const FSPA* fspa = GetShapeFSPA(p);
	if (fspa)
	{
		rc->left = fspa->xaLeft;
		rc->top = fspa->yaTop;
		rc->right = fspa->xaRight;
		rc->bottom = fspa->yaBottom;
	}
	else
	{
		memcpy(rc, _MsoPdata(p->anchor), sizeof(IORECT));
	}
}
// -------------------------------------------------------------------------
//	$Log: drawingbasic.h,v $
//	Revision 1.4  2006/04/25 00:44:06  xulingjiao
//	ͼƬ�ü�
//	
//	Revision 1.3  2006/04/24 01:54:34  xulingjiao
//	
//	�޸�23432�ŵ�BUG
//	
//	Revision 1.2  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __DRAWINGBASIC_H__ */
