/* -------------------------------------------------------------------------
//	�ļ���		��	doctarget.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 14:55:35
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DOCTARGET_H__
#define __DOCTARGET_H__

#ifndef __MSO_IO_WORD_WRITER_H__
#include <mso/io/word/writer.h>
#endif

#ifndef __STL_HASH_MAP_H__
#include <stl/hash_map.h>
#endif

#ifndef __DW_V6LISTS_H__
#include "lists.h"
#endif

#ifndef __DW_V6TABMAP_H__
#include "tabmap.h"
#endif

#ifndef __MSO_IO_WORD_ANNOTATION__KDWANNS_H__
#include "mso/dom/text/annotation/_kdwanns.h"
#endif

#ifndef __FEATURE_H__
#include "feature.h"
#endif


#ifndef DW_NEWHANDLER
#define DW_NEWHANDLER(HandlerType)			new KCountObject< HandlerType >
#endif

// -------------------------------------------------------------------------
// struct KDWRangeData

typedef kso_text::enumRANGETYPE RANGE_TYPE;

struct KDWRangeData
{
	RANGE_TYPE rgt;
	SUBDOC_TYPE subdocType;
	CP cpStart;
};

typedef UINT RANGE_ID;

// -------------------------------------------------------------------------
typedef __std::hash_map<RANGE_ID, KDWRangeData> KDWRangeMap;
typedef KDWRangeMap::const_iterator KDWRangeMapIt;

typedef __std::hash_map<UINT, UINT> KDWFontIDMap;
typedef KDWFontIDMap::const_iterator KDWFontIDMapIt;

// -------------------------------------------------------------------------
typedef __std::hash_map<UINT, UINT> KDWUserIDMap;
typedef KDWUserIDMap::const_iterator KDWUserIDMapIt;

// -------------------------------------------------------------------------
typedef __std::hash_map<UINT, UINT> KDWStyleIDMap;
typedef KDWStyleIDMap::const_iterator KDWStyleIDMapIt;

// -------------------------------------------------------------------------
// class KCommentConnection;  new_annotation
class KFootnoteConnection;
class KDrawingConnection;
class KBookmarkConnection;
class KHyperlinkConnection;

class KDWDocTarget : public KDWDocument
{
public:
	KDWDocTarget()
		: m_userslist(*GetAllocater())
	{
		m_usermode = UAM_UNKNOWN;
		m_userlast_AnnotationID = 0;
		m_userlast_RevisionID = 1;		//�Թ�Unknown�û�
	}
	STDMETHODIMP NewDocument(
		IN IStorage* pStorage,
		IN KDWSecurityAttributes* pAttributes = NULL,
		IN DWFileType FileType = dwFileDefault,
		IN IKFilterEventNotify* pNotify = NULL)
	{
		m_drawingConnection = NULL;
//		m_commentConnection = NULL; new_annotation
		m_footnoteConnection = NULL;
		m_bookmarkConnection = NULL;
		m_hyperlinkConnection = NULL;
		m_v6lists.Init(this);
		m_tabstopMap.Init(this->GetAllocater());
		m_featureControl.Init(FileType, pNotify);
		return KDWDocument::NewDocument(pStorage, pAttributes);
	}

	STDMETHODIMP_(void) Close(IN BOOL fAbort = FALSE);
	
public:
	// -------------------------------------------------------------------------
	// tabstop table
	STDMETHODIMP_(KDWV6TABMap&) GetTABMap() { return m_tabstopMap; }
	STDMETHODIMP_(const KDWV6TABMap&) GetTABMap() const { return m_tabstopMap; }

	// -------------------------------------------------------------------------
	// range table
	STDMETHODIMP_(KDWRangeMap&) GetRangeMap() { return m_rangeMap; }
	STDMETHODIMP_(const KDWRangeMap&) GetRangeMap() const { return m_rangeMap; }

	// -------------------------------------------------------------------------
	// font id map
	STDMETHODIMP_(KDWFontIDMap&) GetFontIDMap() { return m_fontidMap; }
	STDMETHODIMP_(const KDWFontIDMap&) GetFontIDMap() const { return m_fontidMap; }

	// -------------------------------------------------------------------------
	// style id map
	STDMETHODIMP_(KDWStyleIDMap&) GetRStyleIDMap() { return m_rstyleMap; }
	STDMETHODIMP_(const KDWStyleIDMap&) GetPStyleIDMap() const { return m_pstyleMap; }
	STDMETHODIMP_(KDWStyleIDMap&) GetPStyleIDMap() { return m_pstyleMap; }
	STDMETHODIMP_(const KDWStyleIDMap&) GetRStyleIDMap() const { return m_rstyleMap; }
	
	// -------------------------------------------------------------------------
	// user id map
	STDMETHODIMP_(KDWUsers&) GetAllUsers() { return m_userslist; }
	STDMETHODIMP MapAllUserID(UINT uID_MidLayer, UINT uID_AllUser)
	{
		if (m_useridMap.find(uID_MidLayer) == m_useridMap.end())
		{
			m_useridMap[uID_MidLayer] = uID_AllUser;
		}
		else
		{
			ASSERT(FALSE);
		}
		return S_OK;
	}

	STDMETHODIMP WriteUsersLast();	//�Ѻ�����Users��ÿ��Userд��Doc

	STDMETHODIMP AnnotationUserIDLookup(UINT uID_MidLayer, UINT* puID_FileLayer);
	STDMETHODIMP RevisionUserIDLookup(UINT uID_MidLayer, UINT* puID_FileLayer);

public:
	STDMETHODIMP_(KDWV6Lists*) GetListTableV6()
	{
		return &m_v6lists;
	}


private:
	typedef __std::hash_map<UINT, IStorage*> KDWOleStorageMap;
	KDWOleStorageMap m_mapOleStg;

public:
	STDMETHODIMP_(void) SetOleStorage(
		IN UINT uStgId,
		IN KDWOleStorage olestg)
	{
		ASSERT( m_mapOleStg.find(uStgId) == m_mapOleStg.end() );

		m_mapOleStg[uStgId] = olestg;
	}

	STDMETHODIMP_(void) UpdateOleStorage(
		IN UINT uStgId,
		IN IStorageSave* pStgSave)
	{
		KDWOleStorageMap::iterator it = m_mapOleStg.find(uStgId);
		ASSERT(it != m_mapOleStg.end());

		if (it != m_mapOleStg.end())
		{
			KDWOleStorage olestg = (*it).second;
			olestg.Persist(pStgSave);
			m_mapOleStg.erase(it);
		}
	}
	
public:
	// -------------------------------------------------------------------------
	// connection
	STDMETHODIMP_(KDrawingConnection*)		GetDrawingConnection();
	STDMETHODIMP_(KBookmarkConnection*)		GetBookmarkConnection();
	STDMETHODIMP_(KFootnoteConnection*)		GetFootnoteConnection();
	// STDMETHODIMP_(KCommentConnection*)		GetCommentConnection(); new_annotation
	STDMETHODIMP_(KHyperlinkConnection*)	GetHyperlinkConnection();

	// -------------------------------------------------------------------------
	// prop buffer
	STDMETHODIMP_(KDWPropBuffer*) GetPropBuffer()
	{
		m_propBuffer.Clear();
		return &m_propBuffer;
	}

	STDMETHODIMP_(void) SetAnnotationID(UINT anntRefID, UINT anntBodyID)
	{
		m_vecAnnotionIDs[anntRefID] = anntBodyID;
	}
	STDMETHODIMP_(UINT) GetAnnotationsID(UINT anntRefID)
	{
		return m_vecAnnotionIDs[anntRefID];
	}
	STDMETHODIMP_(KDWFeatureControl&) getFeature()
	{
		return m_featureControl;
	}

private:
	KDWPropBuffer	m_propBuffer;

	KDWRangeMap		m_rangeMap;
	KDWFontIDMap	m_fontidMap;

	KDWUsers		m_userslist;
	KDWUserIDMap	m_useridMap;
	KDWUserIDMap	m_Annotation_Mid2FileID;
	KDWUserIDMap	m_Revision_Mid2FileID;
	enum USER_ACCEPT_MODE
	{
		UAM_UNKNOWN,
		UAM_USERS_FIRST,
		UAM_USERS_LAST,
	};
	USER_ACCEPT_MODE m_usermode;		//��ʶUsersList�Ľ���ģʽ
	UINT m_userlast_AnnotationID;		//UAM_USERS_LASTģʽ�£�Ԥ�����ʹ���ߵ���עUser��FileID������GetAnnotationUsers().Add���ص�ID�ǵ����ļ���
	UINT m_userlast_RevisionID;			//UAM_USERS_LASTģʽ�£�Ԥ�����ʹ���ߵ��޶�User��FileID������GetRevisionUsers().Add���ص�ID�ǵ����ļ���
	
	KDWStyleIDMap	m_rstyleMap;
	KDWStyleIDMap	m_pstyleMap;
	KDWV6TABMap		m_tabstopMap;	
	KDWV6Lists		m_v6lists;

	KDrawingConnection*		m_drawingConnection;
//	KCommentConnection*		m_commentConnection;
	KFootnoteConnection*	m_footnoteConnection;
	KBookmarkConnection*	m_bookmarkConnection;
	KHyperlinkConnection*	m_hyperlinkConnection;

	std::map<UINT, UINT> m_vecAnnotionIDs;

	KDWFeatureControl	m_featureControl;

};

// -------------------------------------------------------------------------

#ifndef __DW_V6LISTS_IMPL_H__
#include "lists_impl.h"
#endif

// -------------------------------------------------------------------------

#endif /* __DOCTARGET_H__ */
