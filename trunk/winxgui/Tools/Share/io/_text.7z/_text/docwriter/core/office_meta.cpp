/* -------------------------------------------------------------------------
//	�ļ���		��	office_meta.cpp
//	������		��	����
//	����ʱ��	��	2004-8-24 15:06:03
//	��������	��	
//	$Id: office_meta.cpp,v 1.7 2004/12/14 10:01:04 sunhongqiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_meta.h"
#include <doctarget.h>

#include "kso/summary/summary_stgwrite.inl"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeMetaHandler::StartElement(
											  IN ELEMENTID uElementID,
											  IN KROAttributes* pAttrs)
{
	if (!pAttrs)
		return S_OK;

	if (uElementID == kso::office_meta)
	{
		DOP& dop = m_pDocTarget->GetDop().dop;
		ATTRVALUE_PTR pVal(NULL);
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_created, &pVal)))
		{
			ASSERT(pVal->vt == ATTRVALUE::vtDate);
			DATE2DTTM(pVal->date, &dop.dttmCreated);
		}
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_last_saved, &pVal)))
		{
			ASSERT(pVal->vt == ATTRVALUE::vtDate);
			DATE2DTTM(pVal->date, &dop.dttmRevised);
		}
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_pages, &pVal)))
			dop.cPg = pVal->lVal;
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_words, &pVal)))
			dop.cWords = pVal->lVal;
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_characters, &pVal)))
			dop.cCh = pVal->lVal;
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_lines, &pVal)))
			dop.cLines = pVal->lVal;
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_paragraphs, &pVal)))
			dop.cParas = pVal->lVal;
		if (SUCCEEDED(pAttrs->GetIndex(kso::office_chinese_characters, &pVal)))
			dop.cDBC = pVal->lVal;

		KDWAssocStringTable& theAssocTbl = m_pDocTarget->GetAssocTable();
		BSTR bstrVal;
		if (SUCCEEDED(pAttrs->GetByID(kso::office_title, &bstrVal)))
			theAssocTbl.Add(ibstAssocTitle, bstrVal);
		if (SUCCEEDED(pAttrs->GetByID(kso::office_subject, &bstrVal)))
			theAssocTbl.Add(ibstAssocSubject, bstrVal);
		if (SUCCEEDED(pAttrs->GetByID(kso::office_doc_author, &bstrVal)))
			theAssocTbl.Add(ibstAssocAuthor, bstrVal);
		if (SUCCEEDED(pAttrs->GetByID(kso::office_keywords, &bstrVal)))
			theAssocTbl.Add(ibstAssocKeyWords, bstrVal);
		if (SUCCEEDED(pAttrs->GetByID(kso::office_description, &bstrVal)))
			theAssocTbl.Add(ibstAssocComments, bstrVal);
		if (SUCCEEDED(pAttrs->GetByID(kso::office_template, &bstrVal)))
			theAssocTbl.Add(ibstAssocDot, bstrVal);
		if (SUCCEEDED(pAttrs->GetByID(kso::office_last_author, &bstrVal)))
			theAssocTbl.Add(ibstAssocLastRevBy, bstrVal);

		m_pAttrs = pAttrs;

		Handler_SummaryInformation();

		Handler_DocSummaryInformation();
	}
	else if (uElementID == kso::office_custom_metas)
		Handler_UserDefinedProperties();
	else if (uElementID == kso::office_custom_meta)
	{
		m_pAttrs = pAttrs;
		Handler_UserDefinedProperties_Item();
	}
	m_pAttrs = NULL;
	return S_OK;
}

STDMETHODIMP KOfficeMetaHandler::EndElement(IN ELEMENTID uElementID)
{
	if (uElementID == kso::office_custom_metas)
		Close_UserDefinedProperties();

	return S_OK;
}

IPropertySetStorage* KOfficeMetaHandler::GetPropertySetStorage()
{
	ASSERT(m_pDocTarget);
	return m_pDocTarget->GetPropertySetStorage();
}
