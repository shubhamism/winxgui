/* -------------------------------------------------------------------------
//	�ļ���		��	stocktrans.h
//	������		��	����
//	����ʱ��	��	2004-8-16 16:45:41
//	��������	��	
//	$Id: stocktrans.h,v 1.12 2004/10/07 10:11:50 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __STOCKTRANS_H__
#define __STOCKTRANS_H__

#include <attr/attrinfo.h>
#include <attr/stocktrans.h>


// -------------------------------------------------------------------------
inline
STDMETHODIMP AttrTransShd(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	ATTRVALUE_PTR pAttrFlag(NULL);
	if (pAttr->GetIndex(kso::draw_fill_on, &pAttrFlag) != -1)
	{
		if (!pAttrFlag->lVal)
			return S_FALSE;
	}
	else
		return S_FALSE;

	if (pAttr->GetIndex(kso::draw_fill_type, &pAttrFlag) != -1)
	{
		if (pAttrFlag->lVal != __MSO_ESCHER msofillPattern)
			return S_FALSE;
	}
	else
		return S_FALSE;


	if (pAttr->GetIndex(kso::draw_pattern, &pAttrVal) == -1)
		return S_FALSE;
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	SHD shd;
	ZeroStruct(shd);

	ATTRVALUE_PTR pAttrFill(NULL);
	if (pAttr->GetIndex(kso::draw_fill_color, &pAttrFill) != -1)
		shd.icoFore = DWAttrOp::Ico::eval(pAttrFill->lVal);
	ATTRVALUE_PTR pAttrBk(NULL);
	if (pAttr->GetIndex(kso::draw_fill_bk_color, &pAttrBk) != -1)
		shd.icoBack = DWAttrOp::Ico::eval(pAttrBk->lVal);
	ATTRVALUE_PTR pAttrType(NULL);
	if (pAttr->GetIndex(kso::draw_pattern_type, &pAttrType) != -1)
		shd.ipat = pAttrType->lVal;
	pBuf->ForceAddPropFix(sprmOp, *(UINT32*)&shd);
	return IO_S_ATTR_CONTINUE;
}

// -------------------------------------------------------------------------
inline
STDMETHODIMP AttrTransShdEx(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	SHDEX shdex;
	if (S_OK != TransShdEx(shdex, pAttr))
		return S_FALSE;

	pBuf->AddPropVar(sprmOp, &shdex, sizeof(shdex));
	return IO_S_ATTR_CONTINUE;
}

// -------------------------------------------------------------------------
inline
STDMETHODIMP AttrTransBrc(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	BRC brc;
	ZeroStruct(brc);

	ATTRVALUE_PTR pAttrValue(NULL);
	if (pAttr->GetIndex(kso::office_border_type, &pAttrValue) != -1)
		brc.brcType = pAttrValue->lVal;
	if (pAttr->GetIndex(kso::office_border_width, &pAttrValue) != -1)
		brc.dptLineWidth = pAttrValue->lVal * 8 / 20;
	if (pAttr->GetIndex(kso::office_border_shadow, &pAttrValue) != -1)
		brc.fShadow = pAttrValue->lVal;
	if (pAttr->GetIndex(kso::office_border_space, &pAttrValue) != -1)
		brc.dptSpace = pAttrValue->lVal / 20;
	if (pAttr->GetIndex(kso::office_border_color, &pAttrValue) != -1)
		brc.ico = DWAttrOp::Ico::eval(pAttrValue->lVal);

	pBuf->ForceAddPropFix(sprmOp, *(INT32*)&brc);

	return IO_S_ATTR_CONTINUE;
}

inline
STDMETHODIMP AttrTransBrcEx(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget, 
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	BRCEX brcEx;
	TransBrcEx(brcEx, pAttr);

	pBuf->AddPropVar(sprmOp, &brcEx, sizeof(brcEx));

	return IO_S_ATTR_CONTINUE;
}

// -------------------------------------------------------------------------

#endif /* __STOCKTRANS_H__ */
