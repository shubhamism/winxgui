/* -------------------------------------------------------------------------
//	�ļ���		��	office_images.h
//	������		��	����
//	����ʱ��	��	2004-8-30 14:42:55
//	��������	��	
//	$Id: office_images.h,v 1.9 2004/11/22 04:48:04 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_IMAGES_H__
#define __OFFICE_IMAGES_H__

#ifndef __STL_HASH_MAP_H__
#include <stl/hash_map.h>
#endif

#ifndef __DRAWINGCONNECT_H__
#include "../drawing/drawingconnect.h"
#endif

// -------------------------------------------------------------------------
struct _DWCoreImageInfo
{
	ks_stdptr<IKLockBuffer> spLockBuffer;
	INT iImageType;
	_DWCoreImageInfo(IN INT ImgTy, IN IKLockBuffer* pLockBuffer) 
		: spLockBuffer(pLockBuffer), iImageType(ImgTy)
	{
	}
	_DWCoreImageInfo(_DWCoreImageInfo const& rhs)
	{
		iImageType = rhs.iImageType;
		spLockBuffer = rhs.spLockBuffer;
	}
};

typedef __std::hash_map<INT, _DWCoreImageInfo> _DWCoreImagePoolType;

// -------------------------------------------------------------------------
class KOfficeImageHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	INT m_iImageType;
	INT m_iImageId;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

public:
	STDMETHODIMP StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		if (FAILED(pAttrs->GetByID(kso::office_image_id, &m_iImageId)))
		{
			ASSERT(0);
			return E_FAIL;
		}
		if (FAILED(pAttrs->GetByID(kso::office_image_type, &m_iImageType)))
		{
			ASSERT(0);
			m_iImageType = 0;
		}
		return m_pDocTarget->GetDrawingConnection()->GetBlipContext()->StartElement(uElementID, pAttrs);
	}
	STDMETHODIMP EndElement(IN ELEMENTID uElementID)
	{
		return m_pDocTarget->GetDrawingConnection()->GetBlipContext()->EndElement(uElementID);
	}
	
	STDMETHODIMP AddContent(IN CONTENTVALUE_PTR pContent)
	{
		ASSERT(pContent->vt == VT_UNKNOWN);

		if (pContent->vt != VT_UNKNOWN)
			return E_INVALIDARG;
		
		KDWV6Lists* pLists = m_pDocTarget->GetListTableV6();
		pLists->UpdatePicBullet(
			m_iImageId, m_iImageType, (IKLockBuffer*)pContent->punkVal);

		return m_pDocTarget->GetDrawingConnection()->GetBlipContext()->AddContent(pContent);
	}
};

// -------------------------------------------------------------------------
class KOfficeImagesHandler : public KFakeUnknown<KElementHandler>
{
	KOfficeImageHandler m_imageElement;
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		return S_OK;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case kso::office_image:
			m_imageElement.Init(m_pDocTarget);
			*ppHandler = &m_imageElement;
			break;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		_DW_AddRefHandler(*ppHandler);
		return S_OK;
	}
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_IMAGES_H__ */
