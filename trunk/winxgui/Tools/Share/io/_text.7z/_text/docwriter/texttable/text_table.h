/* -------------------------------------------------------------------------
//	�ļ���		��	text_table.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-23 15:12:37
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_TABLE_H__
#define __TEXT_TABLE_H__

#ifndef __TEXT_ROW_H__
#include "text_row.h"
#endif

// -------------------------------------------------------------------------

class KTextTableHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextRowHandler m_rowElement;
	KDWTablePos m_tblPos;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
	
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_TABLE_H__ */
