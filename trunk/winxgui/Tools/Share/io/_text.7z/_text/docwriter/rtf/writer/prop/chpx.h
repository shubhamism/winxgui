/* -------------------------------------------------------------------------
//	�ļ���		��	chpx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:56:01
//	��������	��	
//
//	$Id: chpx.h,v 1.9 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __CHPX_H__
#define __CHPX_H__
#include "chpxhelper.h"

class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWColorTable;
void AddPlain(RtfWSpanPr* prop);
class RtfWChpxWriter
{
private:
	RtfWSpanPr prop;
	const KDWPropx *m_chpx, *m_piclocation;
	KDWFont m_font;
	KDWSprmList m_sprms;
	RtfWGlobalInfo* m_ginfo;	
	INT m_istdpara;		
	UINT16 m_istd;
public:
	RtfWChpxWriter(const KDWSprmList& sprms, RtfWGlobalInfo* info, INT istdpara = stiNil);
	RtfWChpxWriter(RtfWGlobalInfo* info);
	STDMETHODIMP_(RtfWSpanPr&) GetChp();
	STDMETHODIMP_(CHARSETINFO) GetCharsetInfo(INT iFont);
	STDMETHODIMP_(CHARSETINFO) GetCharsetInfo();
	STDMETHODIMP_(const KDWPropx *) GetPicLocation() const;
	STDMETHODIMP_(void) SetProp(const KDWPropx* prop, INT istdpara = stiNil);
	STDMETHODIMP_(void) SetProp(const KDWSprmList& sprms, INT istdpara = stiNil);	
	STDMETHODIMP_(void) SetIstdPara(INT istdPara);	
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const RtfWSpanPr* prop, BOOL fOnlyAf = FALSE);
private:
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const RtfWSpanPr* mergewith, const RtfWSpanPr* baseon);	
	STDMETHODIMP_(CHARSETINFO) GetSysCharsetInfo();
	void WriteMerged(RtfWGlobalInfo* ginfo, RtfDirectWriter* ar, const RtfWSpanPr* p, const RtfWSpanPr* baseon, BOOL fOnlyAf = FALSE);	
private:
	void WriteChShdCtrl(const KDWShd& shd, UINT8 refShd, RtfWColorTable* colors, RtfDirectWriter* ar);
	void WriteBrcCtrl(const KDWBrc& brc, UINT8 refBrc, RtfDirectWriter* ar,	RtfWColorTable* colors, RtfControl whichBrc);
	void WriteHpsPosCtrl(INT16 hpsPos, INT16 refHpsPos, RtfDirectWriter* ar);	
	void WriteFareastFont(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf = FALSE);
	void WriteAsciiFont(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf = FALSE);
	void WriteOtherFont(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf = FALSE);
	void WriteFontCtrl(const RtfWSpanPr* p, const RtfWSpanPr* baseon, RtfDirectWriter* ar, BOOL fOnlyAf = FALSE);
	void WriteLangCtrl(const RtfWSpanPr* p, RtfDirectWriter* ar);
	void WriteSymbol(const RtfWSpanPr* p, RtfDirectWriter* ar, const KDWFontTable* fonttbl);
};
// -------------------------------------------------------------------------
//	$Log: chpx.h,v $
//	Revision 1.9  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.8  2006/05/23 05:54:30  xulingjiao
//	�޸�26431;26432�ŵ�BUG
//	
//	Revision 1.7  2006/04/17 03:06:22  xulingjiao
//	�޸�23338��BUG
//	
//	Revision 1.6  2006/03/06 01:44:13  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.5  2006/02/22 01:13:58  xulingjiao
//	�޸��޶���BUG,rtfreader����������ת����BUG,��������
//	
//	Revision 1.4  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.3  2006/01/20 08:43:00  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.2  2006/01/13 09:19:48  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.1  2006/01/04 03:42:00  xulingjiao
//	*** empty log message ***
//	

#endif /* __CHPX_H__ */
