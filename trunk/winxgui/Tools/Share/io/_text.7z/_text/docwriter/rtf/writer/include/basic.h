/* -------------------------------------------------------------------------
//	�ļ���		��	mso/io/rtf/writer/basic.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-3-1 10:44:06
//	��������	��	
//
//	$Id: basic.h,v 1.3 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __MSO_IO_RTF_WRITER_RTFBASIC_H__
#define __MSO_IO_RTF_WRITER_RTFBASIC_H__

#include <stl/vector.h>
#include <mso/io/basic/autofree.h>
#include <mso/io/basic/kernstr.h>

// @add
#include <kso/textstd/texttool.h>

// -------------------------------------------------------------------------
// AutoFreeAlloc, KernStr

typedef MsoAutoFreeAlloc RtfWAutoFreeAlloc;
typedef MsoKernStr RtfWKernStr;

// -------------------------------------------------------------------------
// RtfWPropx

typedef MsoKernData RtfWPropx;

class RtfWAutoBuff
{
	UINT m_size;
	BYTE* m_data;

public:
	BYTE* Alloc(UINT size)
	{
		ASSERT_ONCE(size != 0);
		Free();
		m_size = size;
		m_data = new BYTE[size];
		return m_data;
	}
	void Free()
	{
		if (m_data)
			delete[] m_data;
	}
	UINT Size()
	{
		return m_size;
	}
	BYTE* Data()
	{
		return m_data;
	}

	RtfWAutoBuff(UINT size = 0) : m_size(0), m_data(NULL)
	{
		if (size != 0)
			Alloc(size);
	}
	~RtfWAutoBuff()
	{
		Free();
	}
}; 

// -------------------------------------------------------------------------

inline BOOL RtfWcs2Mbs(			
				IN LPCWSTR src,
				IN INT len,
				IN UINT cp,
				OUT RtfWAutoBuff* result,
				OUT UINT* pBuffSize = NULL)
{
	INT nBuffSize = WideCharToMultiByte(cp, 0, src, len, NULL, 0, NULL, NULL);
	result->Alloc(nBuffSize);
	BOOL fUseDefChar;
	LPCSTR defChar = "";
	INT rt = WideCharToMultiByte(cp, 0, src, len, (char*)result->Data(), nBuffSize, defChar, &fUseDefChar);
	if (pBuffSize)
		*pBuffSize = nBuffSize;
	return fUseDefChar;
}
// -------------------------------------------------------------------------
//	$Log: basic.h,v $
//	Revision 1.3  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/01/22 02:32:33  xulingjiao
//	����ά��
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	
#endif /* __MSO_IO_RTF_WRITER_RTFBASIC_H__ */
