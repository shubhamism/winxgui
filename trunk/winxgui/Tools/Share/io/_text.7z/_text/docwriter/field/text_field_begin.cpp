/* -------------------------------------------------------------------------
//	�ļ���		��	text_field_begin.cpp
//	������		��	����
//	����ʱ��	��	2004-8-23 15:38:45
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

#ifndef __TEXT_FIELD_BEGIN_H__
#include "text_field_begin.h"
#endif

#ifndef __ATTRTRANS_H__
#include <core/attributes/attrtrans.h>
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextFieldBeginHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	HRESULT hr;

	INT32 nFieldType;
	hr = pAttrs->GetByID(text_field_type, &nFieldType);
	if (hr != S_OK)
	{
		nFieldType = mso_fltNone;
		ASSERT_ONCE(FALSE);
	}

	INT32 nFieldLock;
	hr = pAttrs->GetByID(text_field_lock, &nFieldLock);
	if (hr != S_OK)
	{
		nFieldLock = FALSE;
		ASSERT_ONCE(FALSE);
	}
	KROAttributes* pAttrChpx = NULL;
	pAttrs->GetByID(kso::text_r_prop, &pAttrChpx);

	KDWPropBuffer* prop = m_pDocTarget->GetPropBuffer();
	TransSpanAttr(m_pDocTarget, (IKAttributes*)pAttrChpx, prop);
	
	ASSERT(m_pDocTarget);
	m_pDocTarget->NewSpan(prop);
	return m_pDocTarget->MarkFieldBegin(nFieldType, nFieldLock);
}


// -------------------------------------------------------------------------
