/* -------------------------------------------------------------------------
//	�ļ���		��	text_settings.cpp
//	������		��	����
//	����ʱ��	��	2004-8-23 19:38:11
//	��������	��	
//	$Id: text_settings.cpp,v 1.18 2006/10/25 08:49:53 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_settings.h"

#include "doctarget.h"
#include "mso/dom/text/mailmerge/mailmerge.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KTextSettingsHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	KDWDocProperties& DWDop = m_pDocTarget->GetDop();
	DOP& dop = DWDop.dop;

	int wvkSaved;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_view, &wvkSaved)))
		DWDop.dop.wvkSaved = wvkSaved;

	int wScaleSaved;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_zoom, &wScaleSaved)))
		DWDop.dop.wScaleSaved = wScaleSaved / 100;

	int dxaTab;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_default_tab_pos, &dxaTab)))
		DWDop.dop.dxaTab = dxaTab;
	
	int fRevMarking;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_track_change, &fRevMarking)))
		DWDop.dop.fRevMarking = fRevMarking;

	KROAttributes* pTypoAttr = NULL;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_typography, &pTypoAttr)))
	{
		DOPTYPOGRAPHY& typo = DWDop.dop.doptypography;
		BSTR rgxchLPunct(NULL);
		if (SUCCEEDED(pTypoAttr->GetByID(kso::text_LeadingPunct, &rgxchLPunct)))
		{
			memset(typo.rgxchLPunct, 0, sizeof(typo.rgxchLPunct));
			size_t len = SysStringLen(rgxchLPunct) * sizeof(XCHAR);
			if (len > sizeof(typo.rgxchLPunct))
				len = sizeof(typo.rgxchLPunct);
			memcpy(typo.rgxchLPunct, (void*const)rgxchLPunct, len);
			typo.cchLeadingPunct = len;
		}
		BSTR rgxchFPunct(NULL);
		if (SUCCEEDED(pTypoAttr->GetByID(kso::text_FollowingPunct, &rgxchFPunct)))
		{
			memset(typo.rgxchFPunct, 0, sizeof(typo.rgxchFPunct));
			size_t len = SysStringLen(rgxchFPunct)* sizeof(XCHAR);
			if (len > sizeof(typo.rgxchFPunct))
				len = sizeof(typo.rgxchFPunct);
			memcpy(typo.rgxchFPunct, (void*const)rgxchFPunct, len);
			typo.cchFollowingPunct = len;
		}

		INT val;
		if (SUCCEEDED(pTypoAttr->GetByID(kso::text_kerning_punct, &val)))
			typo.fKerningPunct = val;
		if (SUCCEEDED(pTypoAttr->GetByID(kso::text_kinsoku_for_justification, &val)))
			typo.iJustification = val;
	}

	KROAttributes* pDGridAttr = NULL;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_drawing_grid, &pDGridAttr)))
	{
		DOGRID& DoGrid = DWDop.dop.dogrid;

		INT val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_drawing_grid_horizontal_spacing, &val)))
			DoGrid.dxaGrid = val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_drawing_grid_vertical_spacing, &val)))
			DoGrid.dyaGrid = val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_display_horizontal_drawing_grid_every, &val)))
			DoGrid.dxGridDisplay = val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_display_vertical_drawing_grid_every, &val)))
			DoGrid.dyGridDisplay = val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_use_margins_for_drawing_grid_origin, &val)))
			DoGrid.fFollowMargins = val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_drawing_grid_horizontal_origin, &val)))
			DoGrid.xaGrid = val;
		if (SUCCEEDED(pDGridAttr->GetByID(kso::text_drawing_grid_vertical_origin, &val)))
			DoGrid.yaGrid = val;
	}

	KROAttributes* pAttrComp = NULL;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_compatibility, &pAttrComp)))
	{
		INT value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_wrap_trail_spaces, &value)))
			dop.copts.fWrapTrailSpaces = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_no_column_balance, &value)))
			dop.copts.fNoColumnBalance = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_expand_shift_return, &value)))
			dop.copts.fDoNotExpandShiftReturn = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_balance_single_byte_double_byte, &value)))
			dop.copts.fBalanceSingleByteDoubleByteWidth = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_draw_underlines_spaces, &value)))
			dop.copts.fULTrailSpace = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_no_adjust_line_height_in_table, &value)))
			dop.copts.fNoAdjustLineHeightInTable = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_no_para_spacing_merge, &value)))
			dop.copts.fHTMLAutoSpace = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_no_punc_wrap_in_chargrid, &value)))
			dop.copts.fWrapTextWithPunct = value;
		if (SUCCEEDED(pAttrComp->GetByID(kso::text_dont_break_wrapped_tables, &value)))
			dop.copts.fDontBreakWrappedTables = value;
	}

	KROAttributes* pAttrRev = NULL;
	if (
		SUCCEEDED(pAttrs->GetByID(kso::text_revision, &pAttrRev))
		)
	{
		DOP& dop =  m_pDocTarget->GetDop().dop;
		BOOL fRevMarking = dop.fRevMarking;
		pAttrRev->GetByID(
			kso::text_revMarking,
			&fRevMarking
			);
		dop.fRevMarking = fRevMarking;
	}
	
	KROAttributes* pMailMergeAttr = NULL;
	if (SUCCEEDED(pAttrs->GetByID(kso::text_mailMerge, &pMailMergeAttr)))
		AddMailMergeAttrs(pMailMergeAttr);


	KROAttributes* pAttrPgb = NULL;
	if (
		SUCCEEDED(pAttrs->GetByID(kso::text_PgbSettings, &pAttrPgb))
		)
	{
		DOP& dop =  m_pDocTarget->GetDop().dop;

		BOOL fSnapBorder = dop.fSnapBorder;
		pAttrPgb->GetByID(
			kso::text_PgbSnapBorder,
			&fSnapBorder
			);
		dop.fSnapBorder = fSnapBorder;

		BOOL fIncludeHeader = dop.fIncludeHeader;
		pAttrPgb->GetByID(
			kso::text_PgbIncludeHeader,
			&fIncludeHeader
			);
		dop.fIncludeHeader = fIncludeHeader;

		BOOL fIncludeFooter = dop.fIncludeFooter;
		pAttrPgb->GetByID(
			kso::text_PgbIncludeFooter,
			&fIncludeFooter
			);
		dop.fIncludeFooter = fIncludeFooter;
	}


	return S_OK;
}

STDMETHODIMP KTextSettingsHandler::AddMailMergeAttrs(IN KROAttributes* pMailMergeAttrs) const
{
	int value;
	BSTR bstr;
	
	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_mainDocumentType, &value)))
	{
		m_pMailMerge->SetMainDocumentType((WdMailMergeMainDocType)value);

		if (wdNotAMergeDocument != (WdMailMergeMainDocType)value)
		{
			DOP& dop =  m_pDocTarget->GetDop().dop;
			dop.fPMHMainDoc = TRUE;
		}
	}
	
	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_linkToQuery, &value)))
		m_pMailMerge->LinkToQuery(value);

	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_activeRecord, &value)))
		m_pMailMerge->SetActiveRecord(value);

	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_viewMergedData, &value)))
		m_pMailMerge->SetViewMergedData(value);

	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_query, &bstr)))
		m_pMailMerge->SetQuery(bstr, SysStringLen(bstr));
	
	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_connectString, &bstr)))
		m_pMailMerge->SetConnectString(bstr, SysStringLen(bstr));

	KROAttributes* pOdsoAttrs = NULL;
	if (SUCCEEDED(pMailMergeAttrs->GetByID(kso::text_odso, &pOdsoAttrs)))
		AddOdsoAttrs(pOdsoAttrs);
	
	return S_OK;
}

STDMETHODIMP KTextSettingsHandler::AddOdsoAttrs(IN KROAttributes* pOdsoAttrs) const
{
	BSTR bstr;
	
	if (SUCCEEDED(pOdsoAttrs->GetByID(kso::text_odso_udl, &bstr)))
		m_pMailMerge->SetOdsoUdl(bstr, SysStringLen(bstr));

	if (SUCCEEDED(pOdsoAttrs->GetByID(kso::text_odso_table, &bstr)))
		m_pMailMerge->SetOdsoTable(bstr, SysStringLen(bstr));

	if (SUCCEEDED(pOdsoAttrs->GetByID(kso::text_odso_src, &bstr)))
		m_pMailMerge->SetOdsoDataSource(bstr, SysStringLen(bstr));

	KROAttributes* pFieldMapDatasAttrs = NULL;
	if (SUCCEEDED(pOdsoAttrs->GetByID(kso::text_odso_fieldMapDatas, &pFieldMapDatasAttrs)))
		AddFieldMapDatasAttrs(pFieldMapDatasAttrs);
	return S_OK;
}

STDMETHODIMP KTextSettingsHandler::AddFieldMapDatasAttrs(IN KROAttributes* pFieldMapDatasAttrs) const
{
	int value;
	BSTR bstr;

	FieldMapData fieldMaps[FieldMapDataCount];
	for (int i = 0; i < FieldMapDataCount; ++i)
	{		
		KROAttributes* pFieldMapDataItemAttrs = NULL;
		VERIFY(SUCCEEDED(pFieldMapDatasAttrs->GetByIndex(i, &pFieldMapDataItemAttrs)));
	
		FieldMapData& aFieldMapData = fieldMaps[i];

		if (SUCCEEDED(pFieldMapDataItemAttrs->GetByID(kso::text_fieldMapData_type, &value)))
		{
			aFieldMapData.type = (FieldMapDataType)value;
			aFieldMapData.mark.type = TRUE;
		}
		if (SUCCEEDED(pFieldMapDataItemAttrs->GetByID(kso::text_fieldMapData_name, &bstr)))
		{
			aFieldMapData.name.assign(bstr, SysStringLen(bstr));
			aFieldMapData.mark.name = TRUE;
		}
		if (SUCCEEDED(pFieldMapDataItemAttrs->GetByID(kso::text_fieldMapData_mappedName, &bstr)))
		{
			aFieldMapData.mappedName.assign(bstr, SysStringLen(bstr));
			aFieldMapData.mark.mappedName = TRUE;
		}
		if (SUCCEEDED(pFieldMapDataItemAttrs->GetByID(kso::text_fieldMapData_column, &value)))
		{
			aFieldMapData.column = value;
			aFieldMapData.mark.column = TRUE;
		}
		if (SUCCEEDED(pFieldMapDataItemAttrs->GetByID(kso::text_fieldMapData_lid, &value)))
		{
			aFieldMapData.lid = value;
			aFieldMapData.mark.lid = TRUE;
		}
	}
	
	m_pMailMerge->SetOdsoFieldMapDatas(fieldMaps);

	return S_OK;
}

// -------------------------------------------------------------------------
