/* -------------------------------------------------------------------------
//	�ļ���		��	bookmarkconnect.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-21 10:19:16
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __BOOKMARKCONNECT_H__
#define __BOOKMARKCONNECT_H__

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

// -------------------------------------------------------------------------

class KBookmarkConnection
{
private:
	typedef std::map<RANGE_ID, KDWKernStr*> BookMarkMap;

	KDWDocTarget* m_pDocTarget;
	BookMarkMap m_map;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP CreateBookmarksHandler(
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP NewBookmark(
		IN BSTR bstrName,
		IN RANGE_ID uRangeID);

	STDMETHODIMP DecodeRange(
		IN RANGE_ID uRangeID,
		IN CP cpStart,
		IN CP cpEnd);
};

// -------------------------------------------------------------------------

#endif /* __BOOKMARKCONNECT_H__ */
