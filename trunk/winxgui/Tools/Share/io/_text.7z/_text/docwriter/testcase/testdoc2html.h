/* -------------------------------------------------------------------------
//	�ļ���		��	testdoc2html.h
//	������		��	���὿
//	����ʱ��	��	2005-12-12 15:35:51
//	��������	��	
//
//	$Id: testdoc2html.h,v 1.4 2006/02/06 03:50:13 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TESTDOC2HTML_H__
#define __TESTDOC2HTML_H__

#ifndef __TESTCOMMON_H__
#include "testcommon.h"
#endif

#ifndef __L10N_H__
#include "l10n.h"
#endif
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/

// -------------------------------------------------------------------------

STDAPI filterpluginExportCreate(
								IN long lFormat,
								IN IKFilterEventNotify* pNotify,
								OUT IKFilterMediaInit** ppv);

STDAPI filterpluginExportCreateParameter(
							 IN long lFormat,
							 IN IKFilterEventNotify* pNotify,
							 OUT IKFilterMediaInit** ppv,
							 IN void* parameter);

// -------------------------------------------------------------------------

typedef STDMETHODIMP _FnInitialize();
typedef STDMETHODIMP _FnTermiate();
typedef STDMETHODIMP _FnFilterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv);
typedef _FnInitialize* FnInitialize;
typedef _FnTermiate* FnTermiate;
typedef _FnFilterpluginImportCreate* FnFilterpluginImportCreate;

class KConvertDoc2Html
{
private:
	HMODULE m_hLib;
	FnFilterpluginImportCreate m_fnCreateSource;
	FnTermiate m_fnTerm;
	
public:
	KConvertDoc2Html() : m_fnCreateSource(NULL), m_fnTerm(NULL), m_hLib(NULL)
	{
	}
	~KConvertDoc2Html()
	{
		term();
	}
	
	void term()
	{
		if (m_fnTerm)
		{
			m_fnTerm();
			m_fnTerm = NULL;
			m_fnCreateSource = NULL;
		}
		if (m_hLib)
		{
			FreeLibrary(m_hLib);
			m_hLib = NULL;
		}
	}

	void convert(
		IN LPCWSTR szDocFileSrc,
		IN LPCWSTR szHtmlFileDest)
	{
		printf("\n[loading \"%S\"...]\n", szDocFileSrc);
		WCHAR szSrcFile[_MAX_PATH];
		WCHAR szHtmlFile[_MAX_PATH];

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szSrcFile, MAX_PATH);
		wcscat(szSrcFile, __L("/"));
		wcscat(szSrcFile, szDocFileSrc);

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szHtmlFile, MAX_PATH);
		wcscat(szHtmlFile, __L("/"));
		wcscat(szHtmlFile, szHtmlFileDest);

		convertFile(szSrcFile, szHtmlFile);
	}

	HRESULT convertFile(
		IN LPCWSTR szSrcFile,
		IN LPCWSTR szHtmlFile)
	{
		//_XMsgBoxTraceW(__X("src = \"%s\", dest = \"%s\"\n"), szSrcFile, szDocFile);

		HRESULT hr = E_FAIL;
		if (m_fnCreateSource == NULL)
		{
			m_hLib = LoadLibrary("docreader");
			KS_CHECK_BOOL(m_hLib);
			
			FnInitialize fnInit = (FnInitialize)GetProcAddress(m_hLib, "_dr_Initialize");
			KS_CHECK_BOOL(fnInit);
			
			hr = fnInit();
			KS_CHECK(hr);
			
			m_fnCreateSource = (FnFilterpluginImportCreate)
				GetProcAddress(m_hLib, "filterpluginImportCreate");
			KS_CHECK_BOOLEX(m_fnCreateSource, hr = E_FAIL);
			
			m_fnTerm = (FnTermiate)GetProcAddress(m_hLib, "_dr_Terminate");
		}
		{
			ks_stdptr<IKFilterMediaInit> spInitSrc;
			hr = m_fnCreateSource(_IoFormat_MSWORD8, NULL, &spInitSrc);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInitSrc, szSrcFile, STGM_T_READ);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentSource> spSrc;
			hr = spInitSrc->QI(IKContentSource, &spSrc);
			KS_CHECK(hr);
			
			ks_stdptr<IKFilterMediaInit> spInit;
			hr = filterpluginExportCreateParameter(_IoFormat_HTML, NULL, &spInit, (void*)szHtmlFile);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInit, szHtmlFile, STGM_G_CREATE);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentHandler> spAcc;
			hr = spInit->QI(IKContentHandler, &spAcc);
			KS_CHECK(hr);
			
			hr = spSrc->Transfer(spAcc);
			spSrc->Close();
			ASSERT_OK(hr);
		}
KS_EXIT:
		return hr;
	}
};

//--------------------------------------------------------------------------
#ifdef X_ENCODE_UCS2
#define testDoc2HtmlFile(from, to)											\
	m_doc2rtf.convert(														\
		L"../../../../Test/office/wps/testcase/rtfrw/" L ## from,									\
		L"../../../../Test/office/wps/testcase/output/" L ## to )
#else
#define testDoc2HtmlFile(from, to)											\
	m_doc2rtf.convert(														\
		__X("../../../../Test/office/wps/testcase/rtfrw/" from),										\
		__X("../../../../Test/office/wps/testcase/output/" to )
#endif

#define DW_CPPUNIT_TEST(Test)												\
	if (CPPUNIT_TEST(Test) == S_OK)											\
		++m_nRef

#endif /* __TESTDOC2HTML_H__ */

// -------------------------------------------------------------------------
//	$Log: testdoc2html.h,v $
//	Revision 1.4  2006/02/06 03:50:13  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.3  2006/01/20 10:20:38  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2005/12/15 03:16:54  xulingjiao
//	HtmlWriter���������, ��ת��д��HTML�ļ�
//	
