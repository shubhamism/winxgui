/* -------------------------------------------------------------------------
//	�ļ���		��	directwr.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:52:50
//	��������	��	
//
//	$Id: directwr.h,v 1.10 2006/11/21 07:07:21 laipinge Exp $
// -----------------------------------------------------------------------*/
#ifndef __DIRECTWR_H__
#define __DIRECTWR_H__

#ifndef __MSO_FILEFMT_RTF_H__
#include <mso/filefmt/rtf.h>
#endif

#ifndef __MSO_IO_BASIC_XDIGIT_H__
#include <mso/io/basic/xdigit.h>
#endif

__BEGIN_MSO_RTF

class RtfDirectWriter
{
public:
	typedef _KFC KWriteArchive WriteArchive;
	typedef WriteArchive::char_type char_type;	
protected:
	WriteArchive m_ar;	
public:	
	RtfDirectWriter()
	{
	}
	RtfDirectWriter(
		IN LPCWSTR szFile,
		IN UINT nMode = STGM_CREATE | STGM_WRITE | STGM_SHARE_EXCLUSIVE) : m_ar(szFile, nMode)
	{	
	}
	RtfDirectWriter(
		IN IStream* pStrm) : m_ar(pStrm)
	{	
	}

	STDMETHODIMP_(void) seek(INT n)
	{
		WriteArchive::pos_type curPos = m_ar.tell();
		curPos += n;
		m_ar.seek(curPos);
	}

	STDMETHODIMP Open(
		IN LPCWSTR szFile,
		IN UINT nMode = STGM_CREATE | STGM_WRITE)
	{
		return m_ar.open(szFile, nMode);
	}
	STDMETHODIMP Open(
		IN IStream* pStream)		
	{
		if (pStream) 
			pStream->AddRef();
		m_ar.attach(pStream);
		return m_ar.good() ? S_OK : E_FAIL;
	}

	STDMETHODIMP_(void) Close()
	{
		m_ar.close();
	}
	
	STDMETHODIMP_(BOOL) Good() const
	{
		return m_ar.good();
	}
	
	STDMETHODIMP_(void) StartBlankGroup()
	{
		m_ar.put('{');		
	}

	STDMETHODIMP_(void) StartGroup(
		IN const char_type* grName,
		IN int grValue = rtf_nilParam,
		IN BOOL fDest1987 = FALSE)
	{
		if (fDest1987)
		{
			const char buf[] = { '{', '\\', '*' };
			m_ar.put(buf, sizeof(buf));
		}
		else
		{
			m_ar.put('{');
		}
		AddAttribute(grName, grValue);
	}

	STDMETHODIMP_(void) StartGroup(
		IN RtfControl grName,
		IN int grValue = rtf_nilParam,
		IN BOOL fDest1987 = FALSE)
	{
		if (fDest1987)
		{
			const char buf[] = { '{', '\\', '*' };
			m_ar.put(buf, sizeof(buf));
		}
		else
		{
			m_ar.put('{');
		}
		AddAttribute(
			GetRtfNameById(grName),
			grValue);
	}

	STDMETHODIMP_(void) EndGroup()
	{
		m_ar.put('}');		
	}
	
	STDMETHODIMP_(void) AddAttribute(
		IN const char_type* attrName,
		IN int attrValue = rtf_nilParam)
	{
		m_ar.put('\\');
		m_ar.put(attrName);
		if (attrValue != rtf_nilParam)
		{
			char buf[32];
			m_ar.put(
				itoa(attrValue, buf, 10) );
		}
		m_ar.put(' ');		
	}

	STDMETHODIMP_(void) AddAttribute(
		IN RtfControl attrName,
		IN int attrValue = rtf_nilParam)
	{
		AddAttribute(
			GetRtfNameById(attrName),
			attrValue);
	}

	STDMETHODIMP_(void) AddBinary(
		IN LPCVOID pData,
		IN int cbData)
	{
		int nSize = cbData * 2;
		HGBL hBuf = ::XGlobalAlloc(GHND, nSize);
		if (hBuf)
		{
			UINT16* pBuf = (UINT16*)XGlobalLock(hBuf);
			CHAR* pToCopy = (CHAR*)pBuf;
			const UINT8* ptr = (const UINT8*)pData;
			const UINT8* ptrEnd = ptr + cbData;
			for (; ptr < ptrEnd; ++ptr)
			{
				*pBuf++ = __MsoXDoubleAsciiLower(*ptr);
			}
			m_ar.put(pToCopy, nSize);
			::XGlobalUnlock(hBuf);
			::XGlobalFree(hBuf);
		}
	}

	struct __DefaultFilter
	{
		BOOL AllowWrite(const BYTE** pp, INT ich)
		{
			return TRUE;
		}
	};
	STDMETHODIMP_(void) AddContent(
		IN const char_type* chars,
		IN int cch)
	{
		__AddContent(chars, cch, FALSE, __DefaultFilter());
	}
	
	template<class FilterType>
	STDMETHODIMP_(void) AddContentWithFilter(
		IN const char_type* chars,
		IN int cch,
		FilterType filter)
	{
		__AddContent(chars, cch, TRUE, filter);
	}	
protected:
	template<class FilterType>
	STDMETHODIMP_(void) __PutText(const char_type* chars, int len, FilterType filter)
	{
		const char_type* end = chars + len;
		INT ich = 0;
		for (; chars < end; ++chars)
		{
			if (filter.AllowWrite((const BYTE**)&chars, ich++) && chars < end)
			{
				m_ar.put(*chars);
			}
		}
	}
	
	
	template<class FilterType>
	STDMETHODIMP_(void) __AddBeforeContent(
		IN const char_type* pch,
		IN const char_type* chars,		
		BOOL usefilter,
		FilterType filter)
	{
		if (pch > chars)
		{
			if (usefilter)
				__PutText(chars, pch - chars, filter);
			else
				m_ar.put(chars, pch - chars);
		}
	}

	template<class FilterType>
	STDMETHODIMP_(void) __AddChar(
		IN const char_type* pch,
		BOOL usefilter,
		FilterType filter)
	{		
		if (usefilter)
			__PutText(pch, 1, filter);
		else
			m_ar.put(pch, 1);
	}
	
	template<class FilterType>
	STDMETHODIMP_(void) __AddContent(
		IN const char_type* chars,
		IN int cch,
		BOOL usefilter,
		FilterType filter)
	{
		// todo: ����

		const char_type* pch;
		const char_type* pchEnd = chars + cch;
		for (pch = chars; pch < pchEnd; ++pch)
		{
			switch (*pch)
			{
			case 0x0D:
				__AddBeforeContent(pch, chars, usefilter, filter);
				__AddChar(pch, usefilter, filter);
				if(pch+1 < pchEnd)
				{
					if(*(pch+1) == 0x0A)
						++pch;
				}
				chars = pch + 1;
				break;
			case '\\':
			case '{':
			case '}':
				__AddBeforeContent(pch, chars, usefilter, filter);
				m_ar.put('\\');
				m_ar.put(*pch);
				chars = pch + 1;
			}
		}
		__AddBeforeContent(pch, chars, usefilter, filter);
	}
};
__END_MSO_RTF
// -------------------------------------------------------------------------
//	$Log: directwr.h,v $
//	Revision 1.10  2006/11/21 07:07:21  laipinge
//	�ṩ���ֽ�ת����16�����ַ��ķ���
//	
//	Revision 1.9  2006/11/21 03:18:30  laipinge
//	��ͼƬ�����ر�������Ҫԭ����ͼƬ����תrtf��ʽ�ַ�ʱ�������С��Ƶ�������ڴ�
//	
//	Revision 1.8  2006/04/18 06:33:16  xulingjiao
//	�޸�98������������
//	
//	Revision 1.6  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	
//	Revision 1.5  2006/02/20 08:15:40  xulingjiao
//	�޸���ע������BUG,�����ֶ��˸��س���BUG
//	
//	Revision 1.4  2006/02/08 09:44:49  wangdong
//	����RTF�����嵼����
//	
//	Revision 1.3  2006/01/22 02:32:33  xulingjiao
//	����ά��
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __DIRECTWR_H__ */
