/* -------------------------------------------------------------------------
//	�ļ���		��	atnref.h
//	������		��	���὿
//	����ʱ��	��	2006-2-11 18:00:25
//	��������	��	
//
//	$Id: atnref.h,v 1.10 2006/06/12 08:43:14 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFATNREF_H__
#define __RTFATNREF_H__
#include "atn.h"
class RtfDirectWriter;
class RtfWAtnWriter;
template<BOOL fStart>
class RtfWAtnRefWriter
{
private:	
	RtfWAtnWriter* m_wrAtn;
	_DW_PlcfCPType* m_plcfbkfl;
	INT m_index;
public:
	RtfWAtnRefWriter(RtfWAtnWriter* wrAtn);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(CP) GetCurrentCp();
	STDMETHODIMP_(CP) GetNextCp();
	STDMETHODIMP SetAtnWriter(RtfWAtnWriter* wrAtn);
	STDMETHODIMP Write(RtfDirectWriter* ar);
};

template<BOOL fStart>
inline RtfWAtnRefWriter<fStart>::RtfWAtnRefWriter(RtfWAtnWriter* wrAtn) : m_wrAtn(wrAtn)
{		
	Reset();
}

template<BOOL fStart>
inline STDMETHODIMP_(BOOL) RtfWAtnRefWriter<fStart>::Good() const
{
	return m_plcfbkfl->size();
}

template<BOOL fStart>
inline STDMETHODIMP RtfWAtnRefWriter<fStart>::Reset()
{	
	m_plcfbkfl = m_wrAtn->GetPlcfbkfl(fStart);
	m_index = 0;
	return S_OK;
}

template<BOOL fStart>
inline STDMETHODIMP RtfWAtnRefWriter<fStart>::Next()
{
	++m_index;
	if(m_index < m_plcfbkfl->size())
		return S_OK;	
	return E_FAIL;
}

template<BOOL fStart>
inline STDMETHODIMP_(CP) RtfWAtnRefWriter<fStart>::GetCurrentCp()
{
	if(m_index < m_plcfbkfl->size())
		return m_plcfbkfl->at(m_index);
	return -1;
}

template<BOOL fStart>
inline STDMETHODIMP_(CP) RtfWAtnRefWriter<fStart>::GetNextCp()
{
	INT index = m_index + 1;
	if(index < m_plcfbkfl->size())
		return m_plcfbkfl->at(index);
	return -1;
}

template<BOOL fStart>
inline STDMETHODIMP RtfWAtnRefWriter<fStart>::Write(RtfDirectWriter* ar)
{
	if(m_wrAtn->IsDotAnnotation(m_index))
	{
		if(fStart)
			m_wrAtn->Write(ar, m_index);
		return S_OK;
	}
	if(fStart)
	{
		ar->StartGroup(rtf_atrfstart, rtf_nilParam, TRUE);
		WCHAR buf[35] = __X("");		
		ar->AddContentWcs(_itow(m_wrAtn->GetAtnId(m_index), buf, 10));
		ar->EndGroup();
	}
	else
	{
		ar->StartGroup(rtf_atrfend, rtf_nilParam, TRUE);
		WCHAR buf[35] = __X("");
		ar->AddContentWcs(_itow(m_wrAtn->GetAtnId(m_index), buf, 10));
		ar->EndGroup();		
		m_wrAtn->Write(ar, m_index);
	}
	return S_OK;
}
typedef RtfWAtnRefWriter<TRUE> RtfWAtnRefStartsWriter;
typedef RtfWAtnRefWriter<FALSE> RtfWAtnRefEndsWriter;
// -------------------------------------------------------------------------
//	$Log: atnref.h,v $
//	Revision 1.10  2006/06/12 08:43:14  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.9  2006/06/12 08:30:25  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.8  2006/04/29 01:01:35  xulingjiao
//	�޸�#25968��BUG
//	
//	Revision 1.7  2006/02/18 07:33:32  xulingjiao
//	�޸�BUG
//	
//	Revision 1.6  2006/02/16 09:43:06  xulingjiao
//	�޸���ע��ص�BUG
//	
//	Revision 1.1  2006/02/13 01:33:05  xulingjiao
//	rtfwriter�Ѿ�֧����ע��
//	

#endif /* __ATNREF_H__ */
