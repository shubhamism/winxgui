/* -------------------------------------------------------------------------
//	�ļ���		��	fields.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:14:41
//	��������	��	
//
//	$Id: fields.h,v 1.5 2006/08/07 01:51:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __FIELDS_H__
#define __FIELDS_H__
#include <stack>
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWTextStreamWriter;
class RtfDirectWriter;
class FieldWriter;
class RtfWFieldWriterFactory
{
public:
	FieldWriter* GetFieldWriter(KDWField* fld, INT flt);
};
class RtfAcceptFieldCode;
class RtfWFieldsWriter
{
private:	
	const KDWFields* m_data;
	KDWFields::Enumerator m_enumer;
	RtfWTextStreamWriter* m_wrTextStream;	
	RtfWFieldWriterFactory m_factory;
	std::stack<FieldWriter*> m_wrFields;	
	KDWField m_fld;
public:
	~RtfWFieldsWriter();
	RtfWFieldsWriter(const KDWFields* data);	
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) SetStreamWriter(RtfWTextStreamWriter* wrTextStream);
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar);
	STDMETHODIMP_(FieldWriter*) GetField() const;
};
// -------------------------------------------------------------------------
//	$Log: fields.h,v $
//	Revision 1.5  2006/08/07 01:51:38  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.4  2006/08/02 08:54:28  xulingjiao
//	�޸�BUG
//	
//	Revision 1.3  2006/05/22 07:36:16  xulingjiao
//	�޸�26431�ŵ�BUG
//	
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:05  xulingjiao
//	*** empty log message ***
//	

#endif /* __FIELDS_H__ */
