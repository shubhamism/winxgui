/* -------------------------------------------------------------------------
//	�ļ���		��	embshape.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:52:06
//	��������	��	
//
//	$Id: embshape.cpp,v 1.6 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "drawingprop.h"
#include "embshape.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
STDMETHODIMP_(void) RtfWEmbShapeWriter::WriteArttext(RtfDirectWriter* ar, const _KDWEmbShapeEx* shape)
{
	RtfWDrawingPropWriter wrProp(m_blipstore, shape);

	ar->StartGroup(rtf_pict);
		ar->StartGroup(rtf_picprop, rtf_nilParam, TRUE);
			ar->AddAttribute(rtf_defshp);
			ar->AddAttribute(rtf_shplid, shape->spid);
			WriteShapeTypeNFilp(ar, shape);
			wrProp.WriteShapeProp(ar, shape, FALSE, FALSE);
		ar->EndGroup();
		WriteBlipSize(ar, shape->cxaShape, shape->cyaShape);
		
		CropType crop;		
		WriteBlipCrop(ar, &crop);
		ar->AddAttribute(rtf_wmetafile, 8);
	ar->EndGroup();
}
STDMETHODIMP_(void) RtfWEmbShapeWriter::WriteShape(RtfDirectWriter* ar, const _KDWEmbShapeEx* shape)
{
	RtfWDrawingPropWriter wrProp(m_blipstore, shape);

	ar->StartGroup(rtf_shppict, rtf_nilParam, TRUE);
		ar->StartGroup(rtf_pict);
			ar->StartGroup(rtf_picprop, rtf_nilParam, TRUE);
				ar->AddAttribute(rtf_shplid, shape->spid);
				WriteShapeTypeNFilp(ar, shape);
				wrProp.WriteShapeProp(ar, shape, FALSE, FALSE);
			ar->EndGroup();
			wrProp.WriteBlip(ar, shape);
		ar->EndGroup();
	ar->EndGroup();
	
	/*
	ar->StartGroup(rtf_nonshppict);
		ar->StartGroup(rtf_pict);
		// ��֪���������������ʲô��ʽ��ͼƬ, ԭ����Ϊ��λͼ, ʵ����ʲô��֪��ʲô��ʽ.
			wrProp.WriteConvertBlip(ar, shape, __X("image/bmp"), RtfAttribute(rtf_dibitmap));
		ar->EndGroup();
	ar->EndGroup();
	*/
}
STDMETHODIMP_(void) RtfWEmbShapeWriter::WritePic(RtfDirectWriter* ar, const _KDWEmbShapeEx* shape)
{
	RtfWDrawingPropWriter wrProp(m_blipstore, shape);

	ar->StartGroup(rtf_pict);
		ar->StartGroup(rtf_picprop, rtf_nilParam, TRUE);
			ar->AddAttribute(rtf_shplid, shape->spid);
			WriteShapeTypeNFilp(ar, shape);
			wrProp.WriteShapeProp(ar, shape, FALSE, FALSE);
		ar->EndGroup();
		wrProp.WriteBlip(ar, shape);
	ar->EndGroup();
}

BOOL RtfWEmbShapeWriter::IsArttext(MSOSPT spt)
{
	if (spt >= msosptTextPlainText &&
		spt <= 175)
		return TRUE;		
	return FALSE;
}

RtfWEmbShapeWriter::RtfWEmbShapeWriter(const _KDWEmbShapes* embshapes, const KDWBlipStore* blipstore)
	: m_embshapes(embshapes), m_blipstore(blipstore)
{
}
STDMETHODIMP_(void) RtfWEmbShapeWriter::Write(RtfDirectWriter* ar, const KDWPropx* stub)
{
	const _KDWEmbShapeEx* shape = m_embshapes->GetEmbShape(stub);
	ASSERT(shape);

	if (IsArttext(shape->spt))
		WriteArttext(ar, shape);	
	else
		WriteShape(ar, shape);
}
