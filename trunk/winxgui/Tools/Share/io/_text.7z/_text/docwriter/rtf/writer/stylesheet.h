/* -------------------------------------------------------------------------
//	�ļ���		��	stylesheet.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:16:02
//	��������	��	
//
//	$Id: stylesheet.h,v 1.2 2006/01/20 08:42:59 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __STYLESHEET_H__
#define __STYLESHEET_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfDirectWriter;
class RtfWGlobalInfo;
class RtfWStyleSheetWriter
{
public:
	STDMETHODIMP_(void) Write(IN OUT RtfDirectWriter* ar, IN RtfWGlobalInfo* info);
};
// -------------------------------------------------------------------------
//	$Log: stylesheet.h,v $
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __STYLESHEET_H__ */
