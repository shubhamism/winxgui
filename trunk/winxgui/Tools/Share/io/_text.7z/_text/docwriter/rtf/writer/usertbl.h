/* -------------------------------------------------------------------------
//	�ļ���		��	usertbl.h
//	������		��	���὿
//	����ʱ��	��	2006-2-9 10:44:07
//	��������	��	
//
//	$Id: usertbl.h,v 1.3 2006/03/23 09:41:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __USERTBL_H__
#define __USERTBL_H__
#include "include/rtffile.h"
// -------------------------------------------------------------------------
class UserTableWriter
{
private:
	RtfDirectWriter* m_ar;	
	const KDWUsers* m_users;
	std::vector<_DW_UserNameInfo> m_haveWrite;
public:
	UserTableWriter(RtfDirectWriter* ar, const KDWUsers* users) : m_ar(ar), m_users(users)
	{
		m_haveWrite.clear();
	}
	enum TableType
	{
		tt_revition,
	};
	STDMETHODIMP Write(TableType tt = tt_revition)
	{
		if(m_users->GetCount() <=0 )
			return E_FAIL;

		_StartTable(tt);
		_AddUsers();
		_EndTable();
		return S_OK;
	}
private:
	STDMETHODIMP _StartTable(TableType tt)
	{
		switch(tt)
		{
		case tt_revition:
			m_ar->StartGroup(rtf_revtbl, rtf_nilParam, TRUE);
			break;
		default:
			ASSERT_ONCE(0);
			return E_FAIL;
		}
		return S_OK;
	}
	STDMETHODIMP _AddUsers()
	{
		INT i, j;
		for(i=0; i<m_users->GetCount(); ++i)
		{
			_DW_UserNameInfo usr = *m_users->GetUserNameInfo(i);
			BOOL bHaveWrite = FALSE;			
			for(j=0; j<m_haveWrite.size(); ++j)
			{
				_DW_UserNameInfo usr2 = m_haveWrite.at(j);
				if(usr == usr2)
					bHaveWrite = TRUE;
			}
			if(!bHaveWrite)
			{
				m_haveWrite.push_back(usr);
				_AddUser(&usr);
			}
		}
		return S_OK;
	}
	STDMETHODIMP _AddUser(const _DW_UserNameInfo* user)	
	{
		if(!user)
			return E_FAIL;
		m_ar->StartBlankGroup();
		m_ar->AddContentWcs(user->userName);
		m_ar->AddContentWcs(__X(";"));
		m_ar->EndGroup();
		return S_OK;
	}
	STDMETHODIMP _AddUser(KDWUser* user)
	{
		if(!user)
			return E_FAIL;
		m_ar->StartBlankGroup();
		m_ar->AddContentWcs(user->GetUserName());
		m_ar->AddContentWcs(__X(";"));
		m_ar->EndGroup();
		return S_OK;
	}
	STDMETHODIMP _EndTable()
	{
		m_ar->EndGroup();
		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: usertbl.h,v $
//	Revision 1.3  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.2  2006/02/18 07:33:32  xulingjiao
//	�޸�BUG
//	
//	Revision 1.1  2006/02/09 06:50:33  xulingjiao
//	�����û�����д��
//	

#endif /* __USERTBL_H__ */
