/* -------------------------------------------------------------------------
//	�ļ���		��	lists_impl.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-22 9:52:12
//	��������	��	
//
//	$Id: lists_impl.h,v 1.3 2005/01/26 13:02:50 rongjianxing Exp $
// -----------------------------------------------------------------------*/
#ifndef __DW_V6LISTS_IMPL_H__
#define __DW_V6LISTS_IMPL_H__

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(void) KDWV6Lists::UpdatePicBullet(
									IN UINT idImage,
									IN UINT iImageType,
									IN IKLockBuffer* pLockBuffer)
{
	typedef ImageIdToListLevel::iterator iterator;
	
	std::pair<iterator, iterator> range = m_mapImageIdToLevel.equal_range(idImage);
	ASSERT(
		range.first == m_mapImageIdToLevel.end() ||
		range.first != range.second);

	if (range.first != range.second)
	{
		KDWBlip blip = m_pDoc->GetBlipStore().NewBlip(
			(mso_escher::MSOBLIPTYPE)iImageType, pLockBuffer);

		KDWPicBullet bullet = m_pDoc->GetPicBullets().NewPicBullet(blip);

		iterator it = range.first;
		do
		{
			KDWListLevel listLevel = (*it).second;
			listLevel.SetPicBullet(bullet);
		}
		while (++it != range.second);

		m_mapImageIdToLevel.erase(range.first, range.second);
	}
}

inline
STDMETHODIMP_(KDWList) KDWV6Lists::NewList(IN UINT idList)
{
	ASSERT(m_mapIdToList.find(idList) == m_mapIdToList.end());
	
	KDWV6ListInfo listInfo;
	listInfo.list = m_pDoc->GetListTable().NewList(9);
	listInfo.ilfo = 0;
	m_mapIdToList[idList] = listInfo;
	return listInfo.list;
}

inline
STDMETHODIMP_(UINT) KDWV6Lists::GetLfoIndex(
											IN UINT idList,
											IN UINT iLvl,
											IN DWListRestartMode iRestartAt)
{
	if (-1 == idList)
		return 0;

	ASSERT(iLvl < 9);

	if (iLvl >= 9) // invalid
		return 0;

	ListIdToListInfo::iterator it = m_mapIdToList.find(idList);
	ASSERT(it != m_mapIdToList.end());

	if (it != m_mapIdToList.end())
	{
		KDWV6ListInfo& listInfo = (*it).second;
		if (iRestartAt != DWListRestartContinue || listInfo.ilfo == 0)
		{
			KDWListTable& lists = m_pDoc->GetListTable();
			KDWListFormatOverride lfo = lists.NewListFormatOverride(listInfo.list);
			if (iRestartAt >= 0)
			{
				KDWList listOverride = lfo.Override();
				listOverride.GetLevel(iLvl).SetStartAt(iRestartAt);
			}
			else if (iRestartAt == DWListRestartRestart)
			{
				KDWList listOverride = lfo.Override();
				listOverride.GetLevel(iLvl).SetStartAs( 
					listInfo.list.GetLevel(iLvl));
			}
			listInfo.ilfo = lfo.GetIndex();
			ASSERT(listInfo.ilfo != 0);
		}
		return listInfo.ilfo;
	}
	return 0;
}

// -------------------------------------------------------------------------
//	$Log: lists_impl.h,v $
//	Revision 1.3  2005/01/26 13:02:50  rongjianxing
//	*** empty log message ***
//	
//	Revision 1.2  2005/01/19 03:16:27  wangdong
//	no message
//	
//	Revision 1.1  2004/11/22 04:48:04  xushiwei
//	*** empty log message ***
//	

#endif /* __DW_V6LISTS_IMPL_H__ */
