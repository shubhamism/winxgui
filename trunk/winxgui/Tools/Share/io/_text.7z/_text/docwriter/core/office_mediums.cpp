/* -------------------------------------------------------------------------
//	�ļ���		��	office_mediums.cpp
//	������		��	����
//	����ʱ��	��	2004-8-30 14:42:42
//	��������	��	
//	$Id: office_mediums.cpp,v 1.2 2004/11/26 10:39:38 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_mediums.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KOfficeMediumsHandler::EnterSubElement(
	IN ELEMENTID uSubElement, OUT IKElementHandler** ppHandler)
{
	switch(uSubElement)
	{
	case office_images:
		m_elementImages.Init(m_pDocTarget);
		*ppHandler = &m_elementImages;
		break;
	case office_oledatas:
		m_elementOleDatas.Init(m_pDocTarget);
		*ppHandler = &m_elementOleDatas;
		break;
	case office_sounds:
	default:
		_kso_UnexpectedElement(uSubElement);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
