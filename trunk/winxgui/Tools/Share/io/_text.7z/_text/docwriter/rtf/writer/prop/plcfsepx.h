/* -------------------------------------------------------------------------
//	�ļ���		��	plcfsepx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:54:52
//	��������	��	
//
//	$Id: plcfsepx.h,v 1.2 2006/01/20 08:43:00 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PLCFSEPX_H__
#define __PLCFSEPX_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWHeaderFooterWriter;
class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWSepxsWriter
{
private:
	const KDWSections* m_sepxs;
	RtfWHeaderFooterWriter* m_wrHdFt;
	KDWSections::Enumerator m_enumer;
	
public:
	RtfWSepxsWriter(const KDWSections* sepxs);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) SetHdFtWriter(RtfWHeaderFooterWriter* wrHdFt);
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) Write(RtfWGlobalInfo* info, RtfDirectWriter* ar);
};
// -------------------------------------------------------------------------
//	$Log: plcfsepx.h,v $
//	Revision 1.2  2006/01/20 08:43:00  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:02  xulingjiao
//	*** empty log message ***
//	

#endif /* __PLCFSEPX_H__ */
