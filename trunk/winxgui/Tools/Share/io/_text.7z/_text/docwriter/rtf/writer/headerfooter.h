/* -------------------------------------------------------------------------
//	�ļ���		��	headerfooter.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:01:37
//	��������	��	
//
//	$Id: headerfooter.h,v 1.3 2006/09/05 07:20:55 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HEADERFOOTER_H__
#define __HEADERFOOTER_H__
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWTextStreamWriter;
class RtfDirectWriter;
class RtfWHeaderFooterWriter
{
private:
	RtfWTextStreamWriter* m_wrTextStream;	

public:
	RtfWHeaderFooterWriter();
	STDMETHODIMP_(void) SetStreamWriter(RtfWTextStreamWriter* wrTextStream);
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const KDWSection* sect, BOOL fFacingPage, BOOL fTitlePage);
};
// -------------------------------------------------------------------------
//	$Log: headerfooter.h,v $
//	Revision 1.3  2006/09/05 07:20:55  xulingjiao
//	�޸�28793
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __HEADERFOOTER_H__ */
