/* -------------------------------------------------------------------------
//	�ļ���		��	document.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:44:45
//	��������	��	
//
//	$Id: document.cpp,v 1.19 2006/09/02 04:32:21 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "colortable.h"
#include "dop.h"
#include "fonttable.h"
#include "stylesheet.h"
#include "listtable.h"
#include "headerfooter.h"
#include "textstream.h"
#include "prop/table.h"
#include "prop/plcfsepx.h"
#include "drawing/embshape.h"
#include "drawing/drawing.h"
#include "range/fndends.h"
#include "range/fields.h"
#include "range/bookmarks.h"
#include "range/atnref.h"
#include "ranges.h"
#include "usertbl.h"
#include "document.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWDocumentWriter::RtfWDocumentWriter(KDWDocument* doc) : m_doc(doc)
{
}

STDMETHODIMP RtfWDocumentWriter::_SetBookmarks(KDWBookmarkStarts& bkStarts, KDWBookmarkEnds& bkEnds, RtfWBookmarkStartsWriter& wrBkmkStarts, RtfWBookmarkEndsWriter& wrBkmkEnds, RtfWRangesWriter* wrRange, SUBDOC_TYPE subdoc)
{	
	const KDWBookmarkTable* bk = m_doc->GetBookmarks(subdoc);
	if (bk)
	{
		bk->GetBookmarkStarts(&bkStarts);
		wrBkmkStarts.SetData(&bkStarts);
		wrRange->SetBookmarkStarts(&wrBkmkStarts);
		bk->GetBookmarkEnds(&bkEnds);
		wrBkmkEnds.SetData(&bkEnds);
		wrRange->SetBookmarkEnds(&wrBkmkEnds);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP_(void) RtfWDocumentWriter::Write(RtfDirectWriter* ar)
{
	// global info
		RtfWStyleSheet m_styles(&m_doc->GetStyleSheet(), &m_doc->GetListTable());
		RtfWColorTable wrColors;
		RtfWGlobalInfo info;
		info.colors = &wrColors;
		info.styles = &m_styles;
		info.dop = &m_doc->GetDop();
		ASSERT_ONCE(m_doc->GetListTable().GetListCount());
		info.lists = &m_doc->GetListTable();
		info.fonttbl = &m_doc->GetFontTable();
		info.stsh = &m_doc->GetStyleSheet();
		info.doc = m_doc;
		ScanInfo(m_doc, &info);
	
	// emb pictures & inline shapes		
		RtfWEmbShapeWriter wrEmbShapes(m_doc->_GetEmbShapes(), &m_doc->GetBlipStore());

	// document drawings
		RtfWDrawingWriter wrDrawingMain(m_doc->_GetDrawings(), DW_SUBDOC_MAIN, &m_doc->GetBlipStore());
		RtfWDrawingWriter wrDrawingHdd(m_doc->_GetDrawings(), DW_SUBDOC_HEADERFOOTER, &m_doc->GetBlipStore());

	// Init main stream writer
		RtfWRangesWriter wrRangesMain(&info);
			// Init footnote for wrRangesMain
			KDWNotes fnt = m_doc->GetFootnotes();
			RtfWFndsWriter wrFndsMain(&fnt);
			wrRangesMain.SetFnds(&wrFndsMain);
			// Init endnote for wrRangesMain
			KDWNotes ent = m_doc->GetEndnotes();
			RtfWEndsWriter wrEndsMain(&ent);
			wrRangesMain.SetEnds(&wrEndsMain);			
			// Init sections for wrRangesMain
			KDWSections secs = m_doc->GetSections();
			RtfWSepxsWriter wrSepxs(&secs);
				// Init headerfooter writer for section writer.
				RtfWHeaderFooterWriter wrHdd;
				wrSepxs.SetHdFtWriter(&wrHdd);
			wrRangesMain.SetPlcfSepx(&wrSepxs);
			// Init annotation for wrRangesMain
			RtfWAtnWriter wrAtn(m_doc->GetAnnotations()->Data(), &m_doc->GetAnnotationUsers());
			RtfWAtnRefStartsWriter wrAtnStarts(&wrAtn);
			wrRangesMain.SetAtnStarts(&wrAtnStarts);
			RtfWAtnRefEndsWriter wrAtnEnds(&wrAtn);
			wrRangesMain.SetAtnEnds(&wrAtnEnds);
		// Init stream writer for main stream.
		RtfWTextStreamWriter wrStreamMain(m_doc->GetStream(DW_SUBDOC_MAIN), &wrRangesMain, DW_SUBDOC_MAIN, &wrDrawingMain, &wrEmbShapes);
		
	// Init annotation stream writer
		RtfWRangesWriter wrRangesAnns(&info);
		RtfWTextStreamWriter wrAtnStream(m_doc->GetStream(DW_SUBDOC_ANNOTATION), &wrRangesAnns, DW_SUBDOC_ANNOTATION, NULL, &wrEmbShapes);

	// Init footnotes stream writer
		RtfWRangesWriter wrRangesFnds(&info);		
		RtfWTextStreamWriter wrStreamFnds(m_doc->GetStream(DW_SUBDOC_FOOTNOTE), &wrRangesFnds, DW_SUBDOC_FOOTNOTE, NULL, &wrEmbShapes);

	// Init endnotes stream writer
		RtfWRangesWriter wrRangesEnds(&info);		
		RtfWTextStreamWriter wrStreamEnds(m_doc->GetStream(DW_SUBDOC_ENDNOTE), &wrRangesEnds, DW_SUBDOC_ENDNOTE, NULL, &wrEmbShapes);

	// Init headerfooter stream writer
		RtfWRangesWriter wrRangesHdd(&info);
		RtfWTextStreamWriter wrStreamHdd(m_doc->GetStream(DW_SUBDOC_HEADERFOOTER), &wrRangesHdd, DW_SUBDOC_HEADERFOOTER, &wrDrawingHdd, &wrEmbShapes);
	
	// Init textbox stream writer
		RtfWRangesWriter wrRangesTxtbox(&info);		
		RtfWTextStreamWriter wrStreamTxtbox(m_doc->GetStream(DW_SUBDOC_TEXTBOX), &wrRangesTxtbox, DW_SUBDOC_TEXTBOX, NULL, &wrEmbShapes);

	// Init textbox in header stream writer
		RtfWRangesWriter wrRangesTxtboxHdr(&info);
		RtfWTextStreamWriter wrStreamTxtboxHdr(m_doc->GetStream(DW_SUBDOC_HEADER_TEXTBOX), &wrRangesTxtboxHdr, DW_SUBDOC_HEADER_TEXTBOX, NULL, &wrEmbShapes);

	// connect stream to writer
		wrHdd.SetStreamWriter(&wrStreamHdd);
		wrAtn.SetStreamWriter(&wrAtnStream);
		wrFndsMain.SetStreamWriter(&wrStreamFnds);
		wrEndsMain.SetStreamWriter(&wrStreamEnds);
		wrDrawingMain.SetTxtboxStreamWriter(&wrStreamTxtbox);
		wrDrawingHdd.SetTxtboxStreamWriter(&wrStreamTxtboxHdr);
	// -----------------------------------------------------------------
	// bookmark in main stream
	RtfWBookmarkStartsWriter wrBkmkStartsMain; KDWBookmarkStarts BkmkStartsMain;
	RtfWBookmarkEndsWriter wrBkmkEndsMain; KDWBookmarkEnds BkmkEndsMain;
	_SetBookmarks(BkmkStartsMain, BkmkEndsMain, wrBkmkStartsMain, wrBkmkEndsMain, &wrRangesMain, DW_SUBDOC_MAIN);
	// field in main stream
	RtfWFieldsWriter wrFieldsMain(m_doc->GetFields(DW_SUBDOC_MAIN));
	wrRangesMain.SetFields(&wrFieldsMain);
	// -----------------------------------------------------------------
	// bookmark in footnote stream
	RtfWBookmarkStartsWriter wrBkmkStartsFnd; KDWBookmarkStarts BkmkStartsFnd;
	RtfWBookmarkEndsWriter wrBkmkEndsFnd; KDWBookmarkEnds BkmkEndsFnd;
	_SetBookmarks(BkmkStartsFnd, BkmkEndsFnd, wrBkmkStartsFnd, wrBkmkEndsFnd, &wrRangesFnds, DW_SUBDOC_FOOTNOTE);
	// field in footnote stream
	RtfWFieldsWriter wrFieldsFnds(m_doc->GetFields(DW_SUBDOC_FOOTNOTE));
	wrRangesFnds.SetFields(&wrFieldsFnds);
	// -----------------------------------------------------------------
	// bookmark in header and footer stream
	RtfWBookmarkStartsWriter wrBkmkStartsHdd; KDWBookmarkStarts BkmkStartsHdd;
	RtfWBookmarkEndsWriter wrBkmkEndsHdd; KDWBookmarkEnds BkmkEndsHdd;
	_SetBookmarks(BkmkStartsHdd, BkmkEndsHdd, wrBkmkStartsHdd, wrBkmkEndsHdd, &wrRangesHdd, DW_SUBDOC_HEADERFOOTER);
	// field in header and footer stream
	RtfWFieldsWriter wrFieldsHdd(m_doc->GetFields(DW_SUBDOC_HEADERFOOTER));
	wrRangesHdd.SetFields(&wrFieldsHdd);
	// -----------------------------------------------------------------
	// bookmark in annotation stream
	RtfWBookmarkStartsWriter wrBkmkStartsAnn; KDWBookmarkStarts BkmkStartsAnn;
	RtfWBookmarkEndsWriter wrBkmkEndsAnn; KDWBookmarkEnds BkmkEndsAnn;
	_SetBookmarks(BkmkStartsAnn, BkmkEndsAnn, wrBkmkStartsAnn, wrBkmkEndsAnn, &wrRangesAnns, DW_SUBDOC_ANNOTATION);
	// field in annotation stream
	RtfWFieldsWriter wrFieldsAnns(m_doc->GetFields(DW_SUBDOC_ANNOTATION));
	wrRangesAnns.SetFields(&wrFieldsAnns);
	// -----------------------------------------------------------------
	// bookmark in endnote stream
	RtfWBookmarkStartsWriter wrBkmkStartsEnd; KDWBookmarkStarts BkmkStartsEnd;
	RtfWBookmarkEndsWriter wrBkmkEndsEnd; KDWBookmarkEnds BkmkEndsEnd;
	_SetBookmarks(BkmkStartsEnd, BkmkEndsEnd, wrBkmkStartsEnd, wrBkmkEndsEnd, &wrRangesEnds, DW_SUBDOC_ENDNOTE);
	// field in endnote stream
	RtfWFieldsWriter wrFieldsEnds(m_doc->GetFields(DW_SUBDOC_ENDNOTE));
	wrRangesEnds.SetFields(&wrFieldsEnds);
	// -----------------------------------------------------------------
	// bookmark in textbox stream
	RtfWBookmarkStartsWriter wrBkmkStartsTxtbox; KDWBookmarkStarts BkmkStartsTxtbox;
	RtfWBookmarkEndsWriter wrBkmkEndsTxtbox; KDWBookmarkEnds BkmkEndsTxtbox;
	_SetBookmarks(BkmkStartsTxtbox, BkmkEndsTxtbox, wrBkmkStartsTxtbox, wrBkmkEndsTxtbox, &wrRangesTxtbox, DW_SUBDOC_TEXTBOX);
	// field in textbox stream
	RtfWFieldsWriter wrFieldTxbx(m_doc->GetFields(DW_SUBDOC_TEXTBOX));
	wrRangesTxtbox.SetFields(&wrFieldTxbx);
	// -----------------------------------------------------------------
	// bookmark in textbox stream in header
	RtfWBookmarkStartsWriter wrBkmkStartsTxtboxHdr; KDWBookmarkStarts BkmkStartsTxtboxHdr;
	RtfWBookmarkEndsWriter wrBkmkEndsTxtboxHdr; KDWBookmarkEnds BkmkEndsTxtboxHdr;
	_SetBookmarks(BkmkStartsTxtboxHdr, BkmkEndsTxtboxHdr, wrBkmkStartsTxtboxHdr, wrBkmkEndsTxtboxHdr, &wrRangesTxtboxHdr, SUBDOC_HEADER_TEXTBOX);
	// field in textbox stream in header
	RtfWFieldsWriter wrFieldTxbxHdr(m_doc->GetFields(SUBDOC_HEADER_TEXTBOX));
	wrRangesTxtboxHdr.SetFields(&wrFieldTxbxHdr);
	info.wrMainStream = &wrStreamMain;

	// rtf
	ar->StartGroup(rtf_rtf);

	// charset
	ar->AddAttribute(rtf_ansi);
	ar->AddAttribute(rtf_ansicpg, GetACP());
	
	// default font
	ar->AddAttribute(rtf_deff, 0);	
	ar->AddAttribute(rtf_stshfdbch, info.stsh->GetStandardFtc(mso_ftcFastEast));
	ar->AddAttribute(rtf_stshfloch, info.stsh->GetStandardFtc(mso_ftcAscii));
	ar->AddAttribute(rtf_stshfhich, info.stsh->GetStandardFtc(mso_ftcOther));
	
	// default language
	ar->AddAttribute(rtf_deflang, GetSystemDefaultLangID());
	ar->AddAttribute(rtf_deflangfe, GetSystemDefaultLangID());

	// font table
	RtfWFontTableWriter wrFontTable;
	wrFontTable.Write(ar, &m_doc->GetFontTable());
	
	// color table
	wrColors.Write(ar);
	
	// style sheet
	RtfWStyleSheetWriter wrStyles;
	wrStyles.Write(ar, &info);

	// list table
	RtfWListTableWriter wrLists;
	const KDWPicBullets* picBullets = NULL;
	m_doc->GetPicBullets(&picBullets);
	RtfWlistPictureWriter wrListPic(picBullets);
	wrLists.SetListPictureWriter(&wrListPic);
	wrLists.Write(ar, &info);

	// todo: <revtbl>
	
	// document prop	
	UserTableWriter wrUsers(ar, &m_doc->GetRevisionUsers());
	RtfWInfoWriter wrInfo;
	RtfWDopWriter wrDop;
	wrUsers.Write();
	wrDop.WriteGenerator(ar);
	wrInfo.Write(ar, &m_doc->GetAssocTable(), &m_doc->GetDop());
	wrDop.WriteDop(ar, &m_doc->GetDop());	
	
	// footnote/endnote sep/sepc prop (ftnsep...)
	::WriteFndEndSepProp(ar, &info);
	
	// the most important: main stream
	wrStreamMain.Write(ar, DW_SUBDOC_MAIN);

	// the end
	ar->EndGroup();
}