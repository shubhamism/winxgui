/* -------------------------------------------------------------------------
//	�ļ���		��	text_field_end.h
//	������		��	����
//	����ʱ��	��	2004-8-23 15:41:01
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_FIELD_END_H__
#define __TEXT_FIELD_END_H__

// -------------------------------------------------------------------------

class KTextFieldEndHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};	

// -------------------------------------------------------------------------

#endif /* __TEXT_FIELD_END_H__ */
