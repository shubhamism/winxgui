/* -------------------------------------------------------------------------
//	�ļ���		��	draw_text_frame.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-21 11:26:00
//	��������	��	
//	$Id: draw_text_frame.cpp,v 1.8 2005/04/26 07:54:07 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include "draw_text_frame.h"
#include <texttable/text_table.h>
#include "draw_shape.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

KDWDrawTextFrameHandler::KDWDrawTextFrameHandler() : m_tableElement(NULL)
{
}

KDWDrawTextFrameHandler::~KDWDrawTextFrameHandler()
{
	delete m_tableElement;
}

STDMETHODIMP_(void) KDWDrawTextFrameHandler::Init(
						 IN KDWShapeHandlerContext* pContext)
{
	m_pContext = pContext;
}

STDMETHODIMP KDWDrawTextFrameHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case draw_content:
		*ppHandler = this;
		m_pContext->m_pDocTarget->EnterTextBox(m_pContext->m_shape);
		break;
	case text_p:
		m_textPHandler.Init(m_pContext->m_pDocTarget);
		*ppHandler = &m_textPHandler;
		break;
	case kso_schema::text_table:
		if (m_tableElement == NULL)
		{
			m_tableElement = new KTextTableHandler;
		}
		m_tableElement->Init(m_pContext->m_pDocTarget);
		*ppHandler = m_tableElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_KsoDraw_AddRefHandler(*ppHandler);
	return S_OK;
}

STDMETHODIMP KDWDrawTextFrameHandler::EndElement(IN ELEMENTID uElementID)
{
	if (uElementID == draw_content)
		m_pContext->m_pDocTarget->LeaveTextBox();
	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: draw_text_frame.cpp,v $
// Revision 1.8  2005/04/26 07:54:07  wangdong
// �м���ѽ��ı�������ת����draw_shape�µ�draw_text_prop��
// ������Ӧ�������޸ġ�
//
