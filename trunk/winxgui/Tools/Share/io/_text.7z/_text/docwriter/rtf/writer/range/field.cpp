/* -------------------------------------------------------------------------
//	�ļ���		��	field.cpp
//	������		��	���὿
//	����ʱ��	��	2006-5-22 15:35:28
//	��������	��	
//
//	$Id: field.cpp,v 1.5 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../include/rtffile.h"
#include "field.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP RtfWBaseFieldWriter::WriteBegin(RtfDirectWriter* ar)
{
	return S_OK;
}
STDMETHODIMP RtfWBaseFieldWriter::WriteSep(RtfDirectWriter* ar)
{
	return S_OK;
}
STDMETHODIMP RtfWBaseFieldWriter::WriteEnd(RtfDirectWriter* ar)
{
	return S_OK;
}
STDMETHODIMP RtfWBaseFieldWriter::EnsureWriteEnd(RtfDirectWriter* ar)
{
	return S_OK;
}

RtfWFieldWriter::RtfWFieldWriter(KDWField* field) : m_fOpen(FALSE), m_field(field)
{	
}

STDMETHODIMP RtfWFieldWriter::EnsureWriteEnd(RtfDirectWriter* ar)
{
	if (m_fOpen)
	{
		ar->EndGroup();
		m_fOpen = FALSE;
	}
	return S_OK;
}

STDMETHODIMP RtfWFieldWriter::WriteBegin(RtfDirectWriter* ar)
{
	ar->StartGroup(rtf_field, rtf_nilParam);
	if(m_field->GetFLocked()!=0)
		ar->AddAttribute(rtf_fldlock);
	if(m_field->GetFResultEdited()!=0)
		ar->AddAttribute(rtf_fldedit);
	if(m_field->GetFResultDirty()!=0)
		ar->AddAttribute(rtf_flddirty);
	ar->StartGroup(rtf_fldinst, rtf_nilParam, TRUE);	
	m_fOpen = TRUE;
	return S_OK;
}

STDMETHODIMP RtfWFieldWriter::WriteSep(RtfDirectWriter* ar)
{		
	EnsureWriteEnd(ar);
	ar->StartGroup(rtf_fldrslt, rtf_nilParam, TRUE);
	return S_OK;
}

STDMETHODIMP RtfWFieldWriter::WriteEnd(RtfDirectWriter* ar)
{	
	EnsureWriteEnd(ar);
	ar->EndGroup();
	ar->EndGroup();
	return S_OK;
}
