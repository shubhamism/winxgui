/* -------------------------------------------------------------------------
//	�ļ���		��	testdoc2rtf_field.cpp
//	������		��	���὿
//	����ʱ��	��	2005-9-2 14:27:16
//	��������	��	
//
//	$Id: testdoc2rtf_field.cpp,v 1.2 2006/04/18 05:42:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testdoc2rtf.h"
// -------------------------------------------------------------------------
class testdoc2rtf_field : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(testdoc2rtf_field);		
		CPPUNIT_TEST(testDatetime);
		CPPUNIT_TEST(testUnkfield);
		CPPUNIT_TEST(testCatagory);
		CPPUNIT_TEST(testChinese);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown()
	{
	}

public:
	void testDatetime()
	{
		testDoc2RtfFile("field/datetime.doc", "field_datetime.rtf");
	}
	void testUnkfield()
	{
		testDoc2RtfFile("field/unkfld.doc", "field_unkfld.rtf");
	}
	void testCatagory()
	{
		// @bug
		testDoc2RtfFile("field/Ŀ¼.doc", "field_Ŀ¼.rtf");
	}
	void testChinese()
	{
		// @bug
		testDoc2RtfFile("field/���İ�ʽ.doc", "field_���İ�ʽ.rtf");
	}	
};


CPPUNIT_TEST_SUITE_REGISTRATION_DBG(testdoc2rtf_field);
// -------------------------------------------------------------------------
//	$Log: testdoc2rtf_field.cpp,v $
//	Revision 1.2  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.1  2005/09/12 01:44:45  xulingjiao
//	������ʽ���б��Ķ��BUGs
//	
