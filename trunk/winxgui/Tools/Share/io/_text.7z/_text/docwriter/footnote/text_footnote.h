/* -------------------------------------------------------------------------
//	�ļ���		��	text_footnote.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-17 17:20:57
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_FOOTNOTE_H__
#define __TEXT_FOOTNOTE_H__

#ifndef __TEXT_P_H__
#include "core/text_p.h"
#endif

class KTextTableHandler;

// -------------------------------------------------------------------------

typedef HRESULT (__stdcall KDWDocument::*LPFNENTER)(BOOL bCustomRefName);
typedef HRESULT (__stdcall KDWDocument::*LPFNLEAVE)();

// ��ͬһ���ദ��Footnote/Endnote

class KTextFootnoteHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextPHandler m_paraElement;
//	ELEMENTID m_uElementID;

public:
	KTextFootnoteHandler();
	~KTextFootnoteHandler();

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget,
		IN ELEMENTID uElemID)
	{
		m_pDocTarget = pDocTarget;

		ASSERT(uElemID == text_footnote || uElemID == text_endnote);
	//	m_uElementID = uElemID;
		if (uElemID == text_footnote)
		{
			m_lpfnEnterFtnEdn = m_pDocTarget->EnterFootnotes;
			m_lpfnLeaveFtnEdn = m_pDocTarget->LeaveFootnotes;
		}
		else
		{
			m_lpfnEnterFtnEdn = m_pDocTarget->EnterEndnotes;
			m_lpfnLeaveFtnEdn = m_pDocTarget->LeaveEndnotes;
		}
	}	

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

//	STDMETHODIMP StartElement(IN ELEMENTID uElementID);
	STDMETHODIMP EndElement(IN ELEMENTID uElementID);

protected:
	LPFNENTER m_lpfnEnterFtnEdn;
	LPFNLEAVE m_lpfnLeaveFtnEdn;
	KTextTableHandler* m_tableElement;
};

// -------------------------------------------------------------------------

#endif /* __TEXT_FOOTNOTE_H__ */
