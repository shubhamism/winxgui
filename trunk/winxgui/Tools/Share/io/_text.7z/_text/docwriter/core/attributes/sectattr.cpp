/* -------------------------------------------------------------------------
//	�ļ���		��	sectattr.cpp
//	������		��	����
//	����ʱ��	��	2004-8-17 10:39:08
//	��������	��	
//	$Id: sectattr.cpp,v 1.26 2006/11/17 09:13:52 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attrtrans.h"
#include "stocktrans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP AttrManuscript(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	if (!pTarget->getFeature().writeKsExt())
		return S_FALSE;

	ASSERT(
		pAttrVal != NULL &&
		pAttrVal->vt == ATTRVALUE::vtAttrList
		);

	HRESULT hr = S_OK;
	if (pAttrVal)
	{
		KROAttributes* pAttrMs = (KROAttributes*)pAttrVal->punkVal;

		BOOL boolValue = 0;
		KsoOperandManuscript Manuscript;
		
		pAttrMs->GetByID(
			kso::text_sectManuscriptCharLine, 
			&Manuscript.CharsLine
			);
		pAttrMs->GetByID(
			kso::text_sectManuscriptLinesPage, 
			&Manuscript.LinesPage
			);
		pAttrMs->GetByID(
			kso::text_sectManuscriptColor, 
			&Manuscript.GirdLineColor
			);
		pAttrMs->GetByID(
			kso::text_sectManuscriptHeight, 
			&Manuscript.Height
			);
		pAttrMs->GetByID(
			kso::text_sectManuscriptWidth, 
			&Manuscript.Width
			);
		pAttrMs->GetByID(
			kso::text_sectManuscriptOrientation, 
			&Manuscript.Orientation
			);
		pAttrMs->GetByID(
			kso::text_sectManuscriptGirdStyle, 
			&Manuscript.GirdLineType
			);

		if (SUCCEEDED(
			pAttrMs->GetByID(
				kso::text_sectManuscriptLineBreakControl, 
				&boolValue)
				))
		{
			Manuscript.LineBreakControl = boolValue;
		}
		if (SUCCEEDED(
			pAttrMs->GetByID(
				kso::text_sectManuscriptHangingPunct, 
				&boolValue)
				))
		{
			Manuscript.HangingPunct = boolValue;
		}


		enum {
			cbOperand = sizeof(UINT8) + sizeof(KsoOperandManuscript),
		};
		UINT8* operand = (UINT8*)_alloca(cbOperand);

		operand[0] = kscodeSManuscript;
		CopyMemory(
			operand+1, &Manuscript, 
			sizeof(KsoOperandManuscript)
			);

		pBuf->AddPropVar(sprmSKSCodeExt, operand, cbOperand);
	}
	
//KS_EXIT:
	return hr;
}

STDMETHODIMP AttrKsExtTextFlow(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(
		pAttrVal != NULL &&
		pAttrVal->vt == ATTRVALUE::vtI4
		);

	HRESULT hr = S_OK;

	if (pAttrVal && pAttrVal->vt == ATTRVALUE::vtI4)
	{
		UINT8 textFlow = (UINT8)pAttrVal->lVal;
		
		if (pTarget->getFeature().writeKsExt())
		{
			enum {
				cbOperand = sizeof(UINT8) + sizeof(UINT8),
			};
			UINT8* operand = (UINT8*)_alloca(cbOperand);

			operand[0] = kscodeSTextFlow;
			operand[1] = textFlow;

			pBuf->AddPropVar(sprmSKSCodeExt, operand, cbOperand);
		}

		pBuf->AddPropFix(
			sprmSTextFlow, kso2mso_sectTextFlow(textFlow)
			);
	}

		
//KS_EXIT:
	return hr;
}


// -------------------------------------------------------------------------
STDMETHODIMP TransRefAttr(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(
		pAttrVal->vt == ATTRVALUE::vtI4
		);

	DOP& dop = pTarget->GetDop().dop;
	dop.epc = pAttrVal->lVal;
	
	return S_OK;
}

STDMETHODIMP AttrPgb(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	if (pAttrVal->vt != ATTRVALUE::vtAttrList)
		return S_FALSE;
	
	KROAttributes* pAttr = (KROAttributes*)pAttrVal->punkVal;

	SpgbProp pgbProp = {0}; UINT8 value = 0;
	pAttr->GetByID(text_sectPgbApplyTo, &value);
	pgbProp.applyTo = value; value = 0;
	pAttr->GetByID(text_sectPgbPageDepth, &value);
	pgbProp.pageDepth = value; value = 0;
	pAttr->GetByID(text_sectPgbOffsetFrom, &value);
	pgbProp.offsetFrom = value;


	pBuf->ForceAddPropFix(sprmOp, pgbProp.pgbProp);

	return S_OK;
}



// -------------------------------------------------------------------------
using namespace kso_text;
using namespace DWAttrOp;


// -------------------------------------------------------------------------
BEGIN_ATTR(text_layout_grid)
	SIM_ATTR(text_grid_mode,	sprmSClm,			AttrTransFixDefault)
	SIM_ATTR(text_grid_width,	sprmSDxtCharSpace,	AttrTransFixDefault)	
	SIM_ATTR(text_grid_height,	sprmSDyaLinePitch,	AttrTransFixDefault)
END_ATTR(text_layout_grid)

BEGIN_ATTR(text_sect_page_margin)
	SIM_ATTR(text_sect_margin_top,		sprmSDyaTop,	AttrTransFixDefault)
	SIM_ATTR(text_sect_margin_left,		sprmSDxaLeft,	AttrTransFixDefault)
	SIM_ATTR(text_sect_margin_bottom,	sprmSDyaBottom,	AttrTransFixDefault)
	SIM_ATTR(text_sect_margin_right,	sprmSDxaRight,	AttrTransFixDefault)
END_ATTR(text_sect_page_margin)

BEGIN_ATTR(text_sect_page)
	// �м���ѷ���ֽ������
//	SIM_ATTR(text_sect_page_type,		sprmSDmPaperReq,AttrTransFixDefault)
	SIM_ATTR(text_sect_page_width,		sprmSXaPage,	AttrTransFixDefault)
	SIM_ATTR(text_sect_page_height,		sprmSYaPage,	AttrTransFixDefault)
END_ATTR(text_sect_page)

BEGIN_ATTR(text_gutter)
//	SIM_ATTR(text_gutter_position,		sprmDontSupport,AttrTransFixDefault) // ��Dop��
	SIM_ATTR(text_gutter_distance,		sprmSDzaGutter,	AttrTransFixDefault)
END_ATTR(text_gutter)

BEGIN_ATTR(text_header_pos)
	SIM_ATTR(text_header_distance,		sprmSDyaHdrTop,	AttrTransFixDefault)
//	SIM_ATTR(text_header_gap,			sprmIDontKnow,	AttrTransFixDefault)
END_ATTR(text_header_pos)

BEGIN_ATTR(text_footer_pos)
	SIM_ATTR(text_footer_distance,		sprmSDyaHdrBottom,	AttrTransFixDefault)
//	SIM_ATTR(text_header_gap,			sprmIDontKnow,	AttrTransFixDefault)
END_ATTR(text_footer_pos)

BEGIN_ATTR(text_page_num)
	SIM_ATTR(text_page_start,			sprmSPgnStart,		AttrTransFixDefault)
	SIM_ATTR(text_chapter_style,		sprmSiHeadingPgn,	AttrTransFixDefault)
	SIM_ATTR(text_format,				sprmSNfcPgn,		AttrTransFixDefault)
	SIM_ATTR(text_chapter_sep,			sprmScnsPgn,		AttrTransFixDefault)
	SIM_ATTR(text_page_restart,			sprmSFPgnRestart,	AttrTransFixDefault)
END_ATTR(text_page_num)

		
BEGIN_ATTR(text_footnote_settings)
	SIM_ATTR(text_footnote_start,			sprmSFNNumStart,	AttrTransFixDefault)
	SIM_ATTR(text_footnote_position,		sprmSFNPos,			AttrTransFixDefault)
	SIM_ATTR(text_footnote_restart,			sprmSFNRestart,		AttrTransFixDefault)
	SIM_ATTR(text_footnote_number_style,	sprmSFNNumFmt,		AttrTransFixDefault)
END_ATTR(text_footnote_settings)

BEGIN_ATTR(text_endnote_settings)
	SIM_ATTR(text_endnote_start,			sprmSENStart,		AttrTransFixDefault)
	SIM_ATTR(text_endnote_position,			0,					TransRefAttr)
	SIM_ATTR(text_endnote_restart,			sprmSENRestart,		AttrTransFixDefault)
	SIM_ATTR(text_endnote_number_style,		sprmSENNumFmt,		AttrTransFixDefault)
END_ATTR(text_endnote_settings)

BEGIN_ATTR(text_bin)
	SIM_ATTR(text_bin_first,	sprmSDmBinFirst,	AttrTransFixDefault)
	SIM_ATTR(text_bin_other,	sprmSDmBinOther,	AttrTransFixDefault)
END_ATTR(text_bin)

BEGIN_ATTR(office_borders)
	SIM_ATTREX(office_border_top,		sprmSBrcTop,		AttrTransBrc, 
										sprmSBrcTopEx,		AttrTransBrcEx)
	SIM_ATTREX(office_border_left,		sprmSBrcLeft,		AttrTransBrc, 
										sprmSBrcExLeft,		AttrTransBrcEx)
	SIM_ATTREX(office_border_bottom,	sprmSBrcBottom,		AttrTransBrc, 
										sprmSBrcExBottom,	AttrTransBrcEx)
	SIM_ATTREX(office_border_right,		sprmSBrcRight,		AttrTransBrc, 
										sprmSBrcExRight,	AttrTransBrcEx)
END_ATTR(office_borders)


BEGIN_ATTR(text_sect)
	// simple attr
	SIM_ATTR(text_sect_manuscript,			sprmSKSCodeExt,		AttrManuscript)
	SIM_ATTR(text_sect_type,				sprmSBkc,			AttrTransFixDefault)
	SIM_ATTR(text_text_flow_direction,		0,					AttrKsExtTextFlow)
	SIM_ATTR(text_sect_print_orientation,	sprmSBOrientation,	AttrTransFixDefault)
	SIM_ATTR(text_different_first,			sprmSFTitlePage,	AttrTransFixDefault)
	SIM_ATTR(text_sectPgbProp,				sprmSPgbProp,		AttrPgb)

	// sub attr
	SUB_ATTR(text_sect_page_margin)
	SUB_ATTR(text_sect_page)
	SUB_ATTR(text_gutter)
	SUB_ATTR(text_layout_grid)
	SUB_ATTR(text_header_pos)
	SUB_ATTR(text_footer_pos)
	SUB_ATTR(text_page_num)
	SUB_ATTR(text_footnote_settings)
	SUB_ATTR(text_endnote_settings)
	SUB_ATTR(text_bin)
	SUB_ATTR(office_borders)
END_ATTR(text_sect)

// -------------------------------------------------------------------------
static 
STDMETHODIMP TransExtendSectAttr(
	IN KDWDocTarget* pTarget, 
	IN IKAttributes* pAttr, 
	IN KDWPropBuffer* pPropBuf)
{
	if (!pTarget->getFeature().writeKsExt())
		return S_FALSE;

	ATTRVALUE_PTR pAttrVal(NULL);
	if (!FAILED(pAttr->GetIndex(kso::text_gutter, &pAttrVal)))
	{
		if (!FAILED(((IKAttributes*)pAttrVal->punkVal)->GetIndex(
			text_gutter_position, &pAttrVal)))
		{
			UINT8 value[2];
			value[0] = kscodeSGutterPos;
			value[1] = (pAttrVal->lVal == kso_text::gpTop);
			pPropBuf->AddPropVar(sprmSKSCodeExt, value, sizeof(value));
		}
	}

	if (!FAILED(pAttr->GetIndex(kso::text_mirror_page_margin, &pAttrVal)))
	{
		if (pAttrVal->lVal)
		{
			UINT8 value[2];
			value[0] = kscodeSMirrorMargins;
			value[1] = pAttrVal->lVal;
			pPropBuf->AddPropVar(sprmSKSCodeExt, value, sizeof(value));
		}
	}

	if (!FAILED(pAttr->GetIndex(kso::text_merge_page, &pAttrVal)))
	{
		if (pAttrVal->lVal)
		{
			UINT8 value[2];
			value[0] = kscodeS2on1;
			value[1] = pAttrVal->lVal;
			pPropBuf->AddPropVar(sprmSKSCodeExt, value, sizeof(value));
		}
	}
	
	if (!FAILED(pAttr->GetIndex(kso::text_different_odd_even, &pAttrVal)))
	{
		if (pAttrVal->lVal)
		{
			UINT8 value[2];
			value[0] = kscodeSFacingPages;
			value[1] = pAttrVal->lVal;
			pPropBuf->AddPropVar(sprmSKSCodeExt, value, sizeof(value));
		}
	}

	return S_OK;
}

static STDMETHODIMP TransColumnsAttr(
	IN KDWDocTarget* pTarget,
	IN IKAttributes* pAttrs,
	IN KDWPropBuffer* pPropBuf)
{
#pragma pack(1)
	struct __KDWCol
	{
		UINT8 icol;
		INT16 value;
	};
#pragma pack()

	ATTRVALUE_PTR pAttrVal = 0;
	if (FAILED(pAttrs->GetIndex(kso::text_columns, &pAttrVal)))
		return S_OK;

	KROAttributes* pAttr = (KROAttributes*)pAttrVal->punkVal;

	INT cColumn = 0;
	pAttr->GetByID(kso::text_count, &cColumn);
	if (cColumn <= 1)
		return S_OK;

	pPropBuf->AddPropFix(sprmSCcolumns, --cColumn);

	BOOL fLBetween = FALSE;
	pAttr->GetByID(kso::text_sep, &fLBetween);
	if (fLBetween)
		pPropBuf->AddPropFix(sprmSLBetween, TRUE);

	BOOL fEvenly = FALSE;
	pAttr->GetByID(kso::text_equal_width, &fEvenly);
	pPropBuf->AddPropFix(sprmSFEvenlySpaced, fEvenly);

	INT nSpace = 720;
	KROAttributes* pColAttr = NULL;
	pAttr->GetByID(kso::text_column, &pColAttr);
	if (pColAttr)
		pColAttr->GetByID(kso::text_column_space, &nSpace);
	pPropBuf->AddPropFix(sprmSDxaColumns, nSpace);

	if (!fEvenly)
	{
		UINT cAttrs = pAttr->Count(), iCol = 0;
		for (int i = 0; i < cAttrs; ++i)
		{
			ATTRID AttrId;
			ATTRVALUE_PTR pColVal = NULL;
		
			pAttr->GetAt(i, &AttrId, &pColVal);
			if (AttrId != text_column)
				continue;

			KROAttributes* pColAttr = (KROAttributes*)pColVal->punkVal;
			ASSERT(pColAttr);

			if (!pColAttr) continue;

			INT nWidth = 0;
			pColAttr->GetByID(kso::text_column_width, &nWidth);

			__KDWCol Width;
			Width.icol = iCol;
			Width.value = nWidth;
			pPropBuf->AddPropFix(sprmSDxaColWidth, *(INT32*)&Width);

			if (iCol < cColumn)
			{
				INT nSpace = 720;
				pColAttr->GetByID(kso::text_column_space, &nSpace);

				__KDWCol Spacing;
				Spacing.icol = iCol;
				Spacing.value = nSpace;
				pPropBuf->AddPropFix(sprmSDxaColSpacing, *(INT32*)&Spacing);
			}

			++iCol;
		}
	}

	return S_OK;
}


// -------------------------------------------------------------------------
STDMETHODIMP TransSectAttr(
	IN KDWDocTarget* pTarget, IN IKAttributes* pAttr, IN KDWPropBuffer* pPropBuf)
{
	HRESULT hr = E_FAIL;
	hr = ParseAttrInfo(ATTRINFO(text_sect), pTarget, pAttr, pPropBuf);
	KS_CHECK(hr);

	hr = TransColumnsAttr(pTarget, pAttr, pPropBuf);
	KS_CHECK(hr);

	hr = TransExtendSectAttr(pTarget, pAttr, pPropBuf);
	KS_CHECK(hr);
	
KS_EXIT:
	return hr;
}

// -------------------------------------------------------------------------
STDMETHODIMP TransSepx2Dop(
	IN KDWDocTarget* pTarget, IN IKAttributes* pAttr)
{
	KDWDocProperties& DWDop = pTarget->GetDop();
	ATTRVALUE_PTR pAttrVal(NULL);
	if (!FAILED(pAttr->GetIndex(kso::text_gutter, &pAttrVal)))
	{
		IKAttributes* pGutter = (IKAttributes*)pAttrVal->punkVal;
		if (SUCCEEDED( pGutter->GetIndex(text_gutter_position, &pAttrVal) ))
			DWDop.dop.iGutterPos = pAttrVal->lVal;
	}
	if (!FAILED(pAttr->GetIndex(kso::text_mirror_page_margin, &pAttrVal)))
		DWDop.dop.fMirrorMargins = pAttrVal->lVal;

	if (!FAILED(pAttr->GetIndex(kso::text_merge_page, &pAttrVal)))
		DWDop.dop.doptypography.f2on1 = pAttrVal->lVal;
	
	if (!FAILED(pAttr->GetIndex(kso::text_different_odd_even, &pAttrVal)))
		DWDop.dop.fFacingPages = pAttrVal->lVal;
	
	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: sectattr.cpp,v $
// Revision 1.26  2006/11/17 09:13:52  wangdong
// 31008��������δ��ȷд��BRCEX��
//
// Revision 1.25  2006/07/31 07:00:03  wangdong
// #26126������дdocʱ��feature��������ݡ�
//
// Revision 1.24  2006/07/24 06:47:06  wangdong
// �������ַ���
//
// Revision 1.23  2006/07/14 01:21:25  wangdong
// *** empty log message ***
//
// Revision 1.22  2006/06/13 02:27:54  wangdong
// �����˶��¼ӵ����ŵĴ������������ı���
//
// Revision 1.21  2006/05/11 03:16:18  wangdong
// no message
//
// Revision 1.20  2005/12/08 06:56:18  wangdong
// �����ˣ���dop����װ����λ�á�
//
// Revision 1.17  2005/04/26 02:34:53  wangdong
// ֽ����Դ��
//
// Revision 1.16  2005/04/25 08:15:04  wangdong
// �޶�״̬��д��
//
// Revision 1.15  2005/04/08 09:17:47  wangdong
// �����˸�ֽ���Ե�һ��Сbug��
//
// Revision 1.14  2005/04/08 03:29:06  wangdong
// �����˸�ֽ���ԡ�
//
