/* -------------------------------------------------------------------------
//	�ļ���		��	office_protdoc.h
//	������		��	����
//	����ʱ��	��	2005-3-29 16:11:53
//	��������	��	
//	$Id: office_protdoc.h,v 1.4 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_PROTDOC_H__
#define __OFFICE_PROTDOC_H__

#ifndef __KSO_CRYPT_KSOCRYPT_I_H__
#include <crypt/ksocrypt_i.h>
#endif

#ifndef __CRYPT_CRYPTLIB_H__
#include <crypt/cryptlib.h>
#endif


// -------------------------------------------------------------------------
class KOfficeProtDoc : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
public:
	STDMETHODIMP_(VOID) Init(IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		BOOL fReadOnly = FALSE, fRev = FALSE;
		pAttrs->GetByID(kso::office_docprot_readonly, &fReadOnly);
		pAttrs->GetByID(kso::office_docprot_rev, &fRev);
		ASSERT(
			!fReadOnly || !fRev
			);

		if (fReadOnly || fRev)
		{
			if (fReadOnly)
				m_pDocTarget->GetDop().dop.fLockAtn = TRUE;
			else if (fRev)
				m_pDocTarget->GetDop().dop.fLockRev = TRUE;

			UINT Key = 0;
			pAttrs->GetByID(kso::office_docprot_key, &Key);
			m_pDocTarget->GetDop().dop.lKeyProtDoc = Key;
		}
	
		return S_OK;
	}
};



// -------------------------------------------------------------------------

#endif /* __OFFICE_PROTDOC_H__ */

// $Log: office_protdoc.h,v $
// Revision 1.4  2005/04/22 07:43:01  zhangqingyuan
// *** empty log message ***
//
// Revision 1.2  2005/04/13 06:42:23  wangdong
// �������޶����ĵ�������
//
// Revision 1.1  2005/03/30 03:38:49  wangdong
// ʵ���ĵ�������
//
