/* -------------------------------------------------------------------------
//	�ļ���		��	doc2rtf.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-4-17 20:10:35
//	��������	��	
//
//	$Id: doc2rtf.h,v 1.1 2006/04/18 05:42:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOC2RTF_H__
#define __DOC2RTF_H__

#ifndef __L10N_H__
#include "l10n.h"
#endif

STDAPI filterpluginExportCreate(
								IN long lFormat,
								IN IKFilterEventNotify* pNotify,
								OUT IKFilterMediaInit** ppv);
typedef STDMETHODIMP _FnInitialize();
typedef STDMETHODIMP _FnTermiate();
typedef STDMETHODIMP _FnFilterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv);
typedef _FnInitialize* FnInitialize;
typedef _FnTermiate* FnTermiate;
typedef _FnFilterpluginImportCreate* FnFilterpluginImportCreate;

class KConvertDoc2Rtf
{
private:
	HMODULE m_hLib;
	FnFilterpluginImportCreate m_fnCreateSource;
	FnTermiate m_fnTerm;
	
public:
	KConvertDoc2Rtf();
	~KConvertDoc2Rtf();	
	void term();
	HRESULT convertFile(
		IN LPCWSTR szSrcFile,
		IN LPCWSTR szRtfFile);
};

EXPORTAPI ConvertDoc2Rtf(IN LPCWSTR szSrcFile, IN LPCWSTR szRtfFile);
// -------------------------------------------------------------------------
//	$Log: doc2rtf.h,v $
//	Revision 1.1  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
#endif /* __DOC2RTF_H__ */
