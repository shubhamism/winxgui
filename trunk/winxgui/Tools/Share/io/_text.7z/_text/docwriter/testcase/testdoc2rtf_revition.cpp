/* -------------------------------------------------------------------------
//	�ļ���		��	testdoc2rtf_revition.cpp
//	������		��	���὿
//	����ʱ��	��	2006-2-9 10:12:22
//	��������	��	
//
//	$Id: testdoc2rtf_revition.cpp,v 1.2 2006/04/18 05:42:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testdoc2rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// -------------------------------------------------------------------------
class testdoc2rtf_revition : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(testdoc2rtf_revition);		
		CPPUNIT_TEST(testRevisionTable);
		CPPUNIT_TEST(testInsert);
		CPPUNIT_TEST(testDelete);
		CPPUNIT_TEST(testDelInsert);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown()
	{
	}

public:	
	void testRevisionTable()
	{
		testDoc2RtfFile("revision/revtbl.doc", "revision_revtbl.rtf");
	}
	void testInsert()
	{
		testDoc2RtfFile("revision/insert.doc", "revision_insert.rtf");
	}
	void testDelete()
	{
		testDoc2RtfFile("revision/delete.doc", "revision_delete.rtf");
	}
	void testDelInsert()
	{
		testDoc2RtfFile("revision/insert_delete.doc", "revision_insert_delete.rtf");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(testdoc2rtf_revition);



// -------------------------------------------------------------------------
//	$Log: testdoc2rtf_revition.cpp,v $
//	Revision 1.2  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.1  2006/02/09 06:51:23  xulingjiao
//	�����޶����԰���
//	
