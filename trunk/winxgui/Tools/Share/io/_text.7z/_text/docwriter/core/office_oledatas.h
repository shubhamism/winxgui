/* -------------------------------------------------------------------------
//	�ļ���		��	office_oledatas.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-26 18:24:34
//	��������	��	
//
//	$Id: office_oledatas.h,v 1.1 2004/11/26 10:39:38 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_OLEDATAS_H__
#define __OFFICE_OLEDATAS_H__

// -------------------------------------------------------------------------

class KOfficeOleDataHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	UINT m_uStgId;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);

	STDMETHODIMP AddContent(IN CONTENTVALUE_PTR pContent);
};

typedef KDWCollectionHandler<KOfficeOleDataHandler, office_oledata> 
		KOfficeOleDatasHandler;

// -------------------------------------------------------------------------
//	$Log: office_oledatas.h,v $
//	Revision 1.1  2004/11/26 10:39:38  xushiwei
//	*** empty log message ***
//	

#endif /* __OFFICE_OLEDATAS_H__ */
