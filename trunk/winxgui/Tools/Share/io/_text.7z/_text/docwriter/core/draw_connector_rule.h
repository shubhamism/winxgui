/* -------------------------------------------------------------------------
//	�ļ���		��	draw_connector_rule.h
//	������		��	�ݽ���
//	����ʱ��	��	2005-7-26 16:34:41
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DRAW_CONNECTOR_RULE_H__
#define __DRAW_CONNECTOR_RULE_H__

// -------------------------------------------------------------------------

class KDrawConnectorRuleHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		_FConnectorRule Rule;

		LONG nValue;
		if (SUCCEEDED(pAttrs->GetByID(kso::draw_rule_id, &nValue)))
			Rule.ruid = nValue;

		if(SUCCEEDED(pAttrs->GetByID(kso::draw_shape_id, &nValue)))
			Rule.spidC = nValue;

		int nCnt = pAttrs->Count();
		for (int i = 0; i < nCnt; i++)
		{
			ATTRID nID;
			ATTRVALUE_PTR pTR;
			pAttrs->GetAt(i, &nID, &pTR);

			if (nID == kso::draw_proxy)
			{
				KROAttributes* pSubAttr = NULL;
				pAttrs->GetByIndex(i, &pSubAttr);				
				if (pSubAttr)
				{
					if (SUCCEEDED(pSubAttr->GetByID(kso::draw_start_connect, &nValue)))
					{
						Rule.cptiA = nValue;
						if (SUCCEEDED(pSubAttr->GetByID(kso::draw_shape_id, &nValue)))
							Rule.spidA = nValue;
					}
					if (SUCCEEDED(pSubAttr->GetByID(kso::draw_end_connect, &nValue)))
					{
						Rule.cptiB = nValue;
						if (SUCCEEDED(pSubAttr->GetByID(kso::draw_shape_id, &nValue)))
							Rule.spidB = nValue;
					}
				}
			}
		}

		return m_pDocTarget->GetDrawingConnection()->AddRule(Rule);
	}
};

// -------------------------------------------------------------------------

#endif /* __DRAW_CONNECTOR_RULE_H__ */
