/* -------------------------------------------------------------------------
//	�ļ���		��	html_fonttbl.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:30:16
//	��������	��	
//
//	$Id: html_fonttbl.h,v 1.5 2006/06/29 05:43:57 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_FONTTBL_H__
#define __HTML_FONTTBL_H__
#include "mso/io/css/cssbuffer.h"
class HtmlDirectWriterA;
class HtmlWGlobalInfo;
class HtmlWFontWriter
{
public:	
	STDMETHODIMP Write(HtmlDirectWriterA* ar, const KDWFont* font);	
private:
	STDMETHODIMP Convert2Cssprop(const KDWFont* font);	
private:
	CssPropBuffer m_cssprop;
};

class HtmlWFontTableWriter
{
private:
	HtmlWGlobalInfo* m_ginfo;
	HtmlWFontWriter m_wrFont;
public:
	HtmlWFontTableWriter(HtmlWGlobalInfo* info);
	STDMETHODIMP Write();	
};
#endif /* __HTML_FONTTBL_H__ */
