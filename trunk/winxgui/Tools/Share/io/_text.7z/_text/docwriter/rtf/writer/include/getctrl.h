/* -------------------------------------------------------------------------
//	�ļ���		��	getctrl.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:17:19
//	��������	��	
//
//	$Id: getctrl.h,v 1.3 2006/08/28 05:48:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GETCTRL_H__
#define __GETCTRL_H__
inline RtfControl GetUlCtrl(UINT8 kul)
{	
	const static RtfControl kulArray[] = 
	{
		rtf_ulnone,		rtf_ul,		rtf_ulw,		rtf_uldb,		rtf_uld,
		rtf_ulnone,		rtf_ulth,	rtf_uldash,		rtf_uld,		rtf_uldashd,
		rtf_uldashdd,	rtf_ulwave,	rtf_ulnone,		rtf_ulnone,		rtf_ulnone,
		rtf_ulnone,		rtf_ulnone,	rtf_ulnone,		rtf_ulnone,		rtf_ulnone,
		rtf_ulthd,		rtf_ulnone,	rtf_ulnone,		rtf_ulthdash,	rtf_ulnone,
		rtf_ulthdashd,	rtf_ulthdashdd,rtf_ulhwave,	rtf_ulnone,		rtf_ulnone,
		rtf_ulnone,		rtf_ulnone,	rtf_ulnone,		rtf_ulnone,		rtf_ulnone,
		rtf_ulnone,		rtf_ulnone,	rtf_ulnone,		rtf_ulnone,		rtf_ulldash,
		rtf_ulnone,		rtf_ulnone,	rtf_ulnone,		rtf_ululdbwave,	rtf_ulnone,
		rtf_ulnone,		rtf_ulnone,	rtf_ulnone,		rtf_ulnone,		rtf_ulnone,
		rtf_ulnone,		rtf_ulnone,	rtf_ulnone,		rtf_ulnone,		rtf_ulnone,
		rtf_ulthldash,
	};	
	if(kul >0 && kul < countof(kulArray))
		return kulArray[kul];
	return rtf_ulnone;
}

inline RtfControl GetIssCtrl(UINT8 iss)
{
	const static RtfControl issArray[] = 
	{
		rtf_nosupersub,		rtf_super,		rtf_sub,
	};
	if(iss >= 0 && iss < countof(issArray))
		return issArray[iss];
	return rtf_nosupersub;
}

inline RtfControl GetKcdCtrl(UINT8 kcd)
{
	if(kcd != mso_kcdNone)
		return rtf_accdot;
	else
		return rtf_accnone;
}

inline RtfControl GetBrcTypeCtrl(UINT8 brcType)
{
	const static RtfControl brcArray[] =
	{
		rtf_brdrnone,		rtf_brdrs,			rtf_brdrnone,		rtf_brdrdb,
		rtf_brdrnone,		rtf_brdrhair,		rtf_brdrdot,	rtf_brdrdash,
		rtf_brdrdashd,		rtf_brdrdashdd,		rtf_brdrtriple,	rtf_brdrtnthsg,
		rtf_brdrthtnsg,		rtf_brdrtnthtnsg,	rtf_brdrtnthmg,	rtf_brdrthtnmg,
		rtf_brdrtnthtnmg,	rtf_brdrtnthlg,		rtf_brdrthtnlg,	rtf_brdrtnthtnlg,
		rtf_brdrwavy,		rtf_brdrwavydb,		rtf_brdrdashsm,	rtf_brdrdashdotstr,
		rtf_brdremboss,		rtf_brdrengrave,	rtf_brdroutset,	rtf_brdrinset,
	};	
	if(brcType >= 0 && brcType < countof(brcArray))
		return brcArray[brcType];
	else if(brcType >= 63)
	{
		if(brcType == 255)
			return rtf_brdrnone;
		return rtf_brdrart;
	}
	else
		return rtf_brdrnone;
}

inline UINT16 CalcShading(UINT16 ipat)
{
	const static PATTYPE pat_array[] = 
	{
		mso_patAutomatic, mso_pat2Percent, mso_pat5Percent,	mso_pat7Percent,
		mso_pat10Percent, mso_pat12Percent,	mso_pat15Percent, mso_pat17Percent,
		mso_pat20Percent, mso_pat22Percent,	mso_pat25Percent, mso_pat27Percent,
		mso_pat30Percent, mso_pat32Percent,	mso_pat35Percent, mso_pat37Percent,
		mso_pat40Percent, mso_pat42Percent,	mso_pat45Percent, mso_pat47Percent,
		mso_pat50Percent, mso_pat52Percent, mso_pat55Percent, mso_pat57Percent,
		mso_pat60Percent, mso_pat62Percent,	mso_pat65Percent, mso_pat67Percent,
		mso_pat70Percent, mso_pat72Percent,	mso_pat75Percent, mso_pat77Percent,
		mso_pat80Percent, mso_pat82Percent, mso_pat85Percent, mso_pat87Percent,
		mso_pat90Percent, mso_pat92Percent,	mso_pat95Percent, mso_pat975Percent,
		mso_patSolid,
	};
	
	int i, count = countof(pat_array);
	for(i = 0; i < count; ++i)
	{
		if(pat_array[i] == ipat)
			break;
	}

	if(i < count)
		return i*250;
	return 0;
}

typedef struct tagpatterctrls
{
	RtfControl para_pattern;
	RtfControl cell_pattern;
	RtfControl char_pattern;
	enum WHICH_PATTERN
	{
		which_parapat,
		which_cellpat,
		which_charpat
	};
}patterctrls;

const static patterctrls patterns[] =
{
	rtf_bgdkhoriz, rtf_clbgdkhor, rtf_chbgdkhoriz,
	rtf_bgdkvert,  rtf_clbgdkvert, rtf_chbgdkvert,
	rtf_bgdkfdiag, rtf_clbgdkfdiag, rtf_chbgdkfdiag,

	rtf_bgdkbdiag, rtf_clbgdkbdiag, rtf_chbgdkbdiag,
	rtf_bgdkcross, rtf_clbgdkcross, rtf_chbgdkcross,
	rtf_bgdkdcross, rtf_clbgdkdcross, rtf_chbgdkdcross,

	rtf_bghoriz, rtf_clbghoriz, rtf_chbghoriz,
	rtf_bgvert, rtf_clbgvert, rtf_chbgvert,
	rtf_bgfdiag, rtf_clbgfdiag, rtf_chbgfdiag,

	rtf_bgbdiag, rtf_clbgbdiag, rtf_chbgbdiag,
	rtf_bgcross, rtf_clbgcross, rtf_chbgcross,
	rtf_bgdcross, rtf_clbgdcross, rtf_chbgdcross,
};

inline RtfControl GetPatternCtrl(UINT16 ipat, patterctrls::WHICH_PATTERN which)
{
	const int istart = mso_patDarkHorizontal;
	const int iend = mso_patDiagonalCross;
	switch(which)
	{
	case patterctrls::which_parapat:
		if(ipat >= istart && ipat <= iend)
			return patterns[ipat - istart].para_pattern;
		else
			return rtf_shading;
	case patterctrls::which_cellpat:
		if(ipat >= istart && ipat <= iend)
			return patterns[ipat - istart].cell_pattern;
		else
			return rtf_clshdng;
	case patterctrls::which_charpat:
		if(ipat >= istart && ipat <= iend)
			return patterns[ipat - istart].char_pattern;
		else
			return rtf_chshdng;
	default:
		ASSERT_ONCE(0);
	}
	return rtf_unknown;	
}

typedef struct tagjcctrls
{
	RtfControl para_jc;
	RtfControl table_jc;
	enum WHICH_JC
	{
		which_parajc,
		which_tablejc,
	};
}jcctrls;

const static jcctrls jcs[] =
{
	rtf_ql, rtf_trql,
	rtf_qc, rtf_trqc,
	rtf_qr, rtf_trqr,
	rtf_qj, rtf_unknown,
	rtf_qd, rtf_unknown,
};

inline RtfControl GetJcCtrl(UINT8 jc, jcctrls::WHICH_JC which)
{
	UINT count = countof(jcs);
	switch(which)
	{
	case jcctrls::which_parajc:
		if(jc >= 0 && jc < count)
			return jcs[jc].para_jc;
	case jcctrls::which_tablejc:
		if(jc >= 0 && jc < count)
			return jcs[jc].table_jc;
	default:
		ASSERT_ONCE(0);
	}
	return rtf_unknown;	
}

inline RtfControl GetFaCtrl(UINT16 fa)
{
	const static RtfControl faArray[] = 
	{ rtf_fahang, rtf_facenter, rtf_faroman, rtf_favar, rtf_faauto, };
	if(fa >=0 && fa < countof(faArray))
		return faArray[fa];
	return rtf_faauto;
}

inline RtfControl GetTabKindCtrl(UINT8 tq)
{		
	const static RtfControl taArray[] =
	{ rtf_tql, rtf_tqc, rtf_tqr, rtf_tqdec, rtf_tb };
	if(tq >= 0 && tq < countof(taArray))
		return taArray[tq];
	else if(tq == mso_tbdListTab)
		return rtf_jclisttab;
	else
		return rtf_tql;
}

inline RtfControl GetTabLeadCtrl(UINT8 tl)
{
	const static RtfControl tlArray[] =
	{ rtf_unknown, rtf_tldot, rtf_tlhyph, rtf_tlul, rtf_unknown, rtf_tldot };
	const istart = 1;
	if(tl >=istart && tl < countof(tlArray))
		return tlArray[tl];	
	return rtf_unknown;
}

typedef struct taghpcctrls
{
	RtfControl para_hpc;
	RtfControl table_hpc;
	enum WHICH_HPC
	{
		which_parahpc,
		which_tablehpc,
	};
}hpcctrls;

const static hpcctrls hpcs[] =
{
	rtf_phcol, rtf_tphcol,
	rtf_phmrg, rtf_tphmrg,
	rtf_phpg, rtf_tphpg,	
};

inline RtfControl GetHpcCtrl(UINT8 hpc, hpcctrls::WHICH_HPC which)
{
	UINT count = countof(hpcs);
	switch(which)
	{
	case hpcctrls::which_parahpc:
		if(hpc >= 0 && hpc < count)
			return hpcs[hpc].para_hpc;
		else
			return rtf_phcol;
	case hpcctrls::which_tablehpc:
		if(hpc >= 0 && hpc < count)
			return hpcs[hpc].table_hpc;
		else
			return rtf_tphcol;
	default:
		ASSERT_ONCE(0);
	}
	return rtf_unknown;
}

typedef struct tagvpcctrls
{
	RtfControl para_vpc;
	RtfControl table_vpc;
	enum WHICH_VPC
	{
		which_paravpc,
		which_tablevpc,
	};
}vpcctrls;

const static vpcctrls vpcs[] =
{
	rtf_pvmrg, rtf_tpvmrg,
	rtf_pvpg, rtf_tpvpg,
	rtf_pvpara, rtf_tpvpara,
};

inline RtfControl GetVpcCtrl(UINT8 vpc, vpcctrls::WHICH_VPC which)
{
	switch(which)
	{
	case vpcctrls::which_paravpc:
		if(vpc >= 0 && vpc < countof(vpcs))
			return vpcs[vpc].para_vpc;
		else
			return rtf_pvmrg;
	case vpcctrls::which_tablevpc:
		if(vpc >= 0 && vpc < countof(vpcs))
			return vpcs[vpc].table_vpc;
		else
			return rtf_tpvmrg;
	default:
		ASSERT_ONCE(0);
	}
	return rtf_unknown;
}

inline RtfControl GetParaXposCtrl(INT16 dxaabs)
{	
	switch(dxaabs)
	{
	case mso_posXSpecCenter:
		return rtf_posxc;
	case mso_posXSpecInside:
		return rtf_posxi;
	case mso_posXSpecOutside:
		return rtf_posxo;
	case mso_posXSpecRight:
		return rtf_posxr;
	case mso_posXSpecLeft:
		return rtf_posxl;
	default:
		if(dxaabs >= 0)
			return rtf_posx;
		else
			return rtf_posnegx;
	}	
}

inline RtfControl GetTableXposCtrl(INT16 dxaabs)
{	
	switch(dxaabs)
	{
	case mso_posXSpecCenter:
		return rtf_tposxc;
	case mso_posXSpecInside:
		return rtf_tposxi;
	case mso_posXSpecOutside:
		return rtf_tposxo;
	case mso_posXSpecRight:
		return rtf_tposxr;
	case mso_posXSpecLeft:
		return rtf_tposxl;
	default:
		if(dxaabs >= 0)
			return rtf_tposx;
		else
			return rtf_tposnegx;
	}	
}

inline RtfControl GetParaYposCtrl(INT16 dyaabs)
{	
	switch(dyaabs)
	{
	case mso_posYSpecTop:
		return rtf_posyt;
	case mso_posYSpecCenter:
		return rtf_posyc;
	case mso_posYSpecBottom:
		return rtf_posyb;
	case mso_posYSpecInside:
		return rtf_posyin;
	case mso_posYSpecOutside:
		return rtf_posyout;
	default:
		if(dyaabs >= 0)
			return rtf_posy;
		else
			return rtf_posnegy;
	}
}

inline RtfControl GetTableYposCtrl(INT16 dyaabs)
{		
	switch(dyaabs)
	{
	case -4:
		return rtf_tposyt;
	case -8:
		return rtf_tposyb;
	case -12:
		return rtf_tposyc;
	case -16:
		return rtf_tposyin;
	case -20:
		return rtf_tposyout;
	default:
		if(dyaabs >= 0)
			return rtf_tposy;
		else
			return rtf_tposnegy;
	}
}

typedef struct tagtextflowctrls
{
	RtfControl para_flow;
	RtfControl cell_flow;
	enum WHICH_FLOW
	{
		which_para,
		which_cell,
	};
}textflowctrls;

const static textflowctrls textflows[] =
{
	rtf_frmtxlrtb, rtf_cltxlrtb,
	rtf_frmtxtbrl, rtf_cltxtbrl,
	rtf_frmtxlrtb, rtf_cltxlrtb,
	rtf_frmtxbtlr, rtf_cltxbtlr,
	rtf_frmtxlrtbv, rtf_cltxlrtbv,
	rtf_frmtxtbrlv, rtf_cltxtbrlv,
};

inline RtfControl GetTextflowCtrl(INT16 flow, textflowctrls::WHICH_FLOW which)
{
	UINT count = countof(textflows);
	switch(which)
	{
	case textflowctrls::which_para:
		if(flow >= 0 && flow < count)
			return textflows[flow].para_flow;
		else
			return rtf_frmtxlrtb;
	case textflowctrls::which_cell:
		if(flow >= 0 && flow < count)
			return textflows[flow].cell_flow;
		else
			return rtf_cltxlrtb;
	default:
		ASSERT_ONCE(0);
	}
	return rtf_unknown;
}

inline RtfControl GetPageNumberRestartCtrl(UINT8 fPgnRestart)
{
	if(fPgnRestart)
		return rtf_pgnrestart;
	return rtf_pgncont;
}

inline RtfControl GetCnsPgnCtrl(UINT8 cnsPgn)
{
	const static RtfControl cnsPgnArray[] =
	{ rtf_pgnhnsh, rtf_pgnhnsp, rtf_pgnhnsc, rtf_pgnhnsm, rtf_pgnhnsn };
	if(cnsPgn >= 0 && cnsPgn < countof(cnsPgnArray))
		return cnsPgnArray[cnsPgn];
	return rtf_pgnhnsh;
}


inline RtfControl GetSectBreakCtrl(UINT8 bkc)
{
	const static RtfControl bkcArray[] =
	{ rtf_sbknone, rtf_sbkcol, rtf_sbkpage, rtf_sbkeven, rtf_sbkodd };
	if(bkc >=0 && bkc < countof(bkcArray))
		return bkcArray[bkc];
	return rtf_sbkpage;
}

inline RtfControl GetSectVjcCtrl(UINT8 vjc)
{
	const static RtfControl vjcArray[] = 
	{ rtf_vertalt, rtf_vertalc, rtf_vertalj, rtf_vertal	};
	if(vjc >=0 && vjc < countof(vjcArray))
		return vjcArray[vjc];
	return rtf_vertalt;
}

inline RtfControl GetClmCtrl(UINT16 clm)
{
	const static RtfControl clmArray[] =
	{ rtf_sectdefaultcl, rtf_sectspecifycl, rtf_sectspecifyl, rtf_sectspecifygenN };
	if(clm >=0 && clm < countof(clmArray))
		return clmArray[clm];
	return rtf_sectdefaultcl;
}

inline RtfControl GetFootnotePosCtrl(UINT8 fnpos)
{
	const static RtfControl fnposArray[] =
	{ rtf_sftnbj, rtf_sftnbj, rtf_sftntj };
	if(fnpos >= 0 && fnpos < countof(fnposArray))
		return fnposArray[fnpos];
	return rtf_sftnbj;	
}

inline RtfControl GetFootnoteRestartCtrl(UINT8 FNRestart)
{
	const static RtfControl FNRestartArray[] =
	{ rtf_sftnrstcont, rtf_sftnrestart, rtf_sftnrstpg };
	if(FNRestart >= 0 && FNRestart < countof(FNRestartArray))
		return FNRestartArray[FNRestart];
	return rtf_sftnrstcont;
}

inline RtfControl GetEndnoteRestartCtrl(UINT8 ENRestart)
{
	const static RtfControl ENRestartArray[] =
	{ rtf_saftnrstcont, rtf_saftnrestart, rtf_ftnrstpg };
	if( ENRestart >= 0 && ENRestart < countof(ENRestartArray))
		return ENRestartArray[ENRestart];
	return rtf_saftnrstcont;
}

inline RtfControl GetFpcCtrl(UINT16 fpc)
{
	const static RtfControl fpcArray[] =
	{ rtf_ftnbj, rtf_ftnbj, rtf_ftntj };
	if(fpc >= 1 && fpc < countof(fpcArray))
		return fpcArray[fpc];
	return rtf_ftnbj;
}

inline RtfControl GetEpcCtrl(UINT16 epc)
{
	const static RtfControl epcArray[] =
	{ rtf_aendnotes, rtf_aftnbj, rtf_aftntj, rtf_aenddoc };
	if(epc >= 0 && epc < countof(epcArray))
		return epcArray[epc];
	return rtf_aendnotes;
}

inline RtfControl GetIJustificationCtrl(UINT16 iJustification)
{
	if(iJustification)
		return rtf_jcompress;
	else
		return rtf_jexpand;
}

inline RtfControl GetRncFtnCtrl(UINT16 rncFtn)
{
	const static RtfControl rncFtnArray[] =
	{ rtf_ftnrstcont, rtf_ftnrestart, rtf_ftnrstpg };
	if(rncFtn >= 0 && rncFtn < countof(rncFtnArray))
		return rncFtnArray[rncFtn];
	return rtf_ftnrstcont;
}

inline RtfControl GetMcEdnCtrl(UINT16 mcEdn)
{
	if(mcEdn)
		return rtf_aftnrestart;
	else
		return rtf_aftnrstcont;	
}

inline RtfControl GetIGutterPosCtrl(UINT16 iGutterPos)
{
	if( !iGutterPos )
		return rtf_rtlgutter;
	else if( iGutterPos == 1)
		return rtf_gutterprl;
	return rtf_rtlgutter;
}

// -------------------------------------------------------------------------

typedef struct tagnumberformatctrls
{        
	RtfControl endctrl;                                                                                                                        
	RtfControl fndctrl;
	RtfControl dopendctrl;
	RtfControl dopfndctrl;
	RtfControl pgnctrl;
	enum WHICH_NFC
	{
		which_end,
		which_fnd,
		which_dopend,
		which_dopfnd,
		which_pgn,
	};
}numberformatctrls;

// s: sure; n: not sure; b: bug
const static numberformatctrls nfcs[] =
{
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//s	mso_nfcArabic		= 0,	// decimal							���������֣�1��2��3��4����			\pgndec
	rtf_saftnnruc,		rtf_sftnnruc,		rtf_aftnnruc,		rtf_ftnnruc,		rtf_pgnucrm,		//s mso_nfcUCRoman		= 1,	// upper-roman						��д�������֣�I��II��III��IV����	\pgnucrm
	rtf_saftnnrlc,		rtf_sftnnrlc,		rtf_aftnnrlc,		rtf_ftnnrlc,		rtf_pgnlcrm,		//s mso_nfcLCRoman		= 2,	// lower-roman						Сд�������֣�i��ii��iii��iv����	\pgnlcrm
	rtf_saftnnauc,		rtf_sftnnauc,		rtf_aftnnauc,		rtf_ftnnauc,		rtf_pgnucltr,		//s mso_nfcUCLetter		= 3,	// upper-letter						��д��ĸ��A��B��C��D����			\pgnucltr
	rtf_saftnnalc,		rtf_sftnnalc,		rtf_aftnnalc,		rtf_ftnnalc,		rtf_pgnlcltr,		//s mso_nfcLCLetter		= 4,	// lower-letter						Сд��ĸ��a��b��c��d����			\pgnlcltr
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcOrdinal		= 5,	// ordinal							Ӣ��������1st��2nd��3rd
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcCardtext		= 6,	// cardinal-text					Ӣ�Ļ�����One��Two��Three
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcOrdtext		= 7,	// ordinal-text						Ӣ���ı�������First��Second��Third
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHex			= 8,	// hex								ʮ������
	rtf_saftnnchi,		rtf_sftnnchi,		rtf_aftnnchi,		rtf_ftnnchi,		rtf_pgndec,			//s mso_nfcChiManSty	= 9,	// chicago							Chicago Manual of Style��*��?��?
	rtf_saftnndbnum,	rtf_sftnndbnum,		rtf_aftnndbnum,		rtf_ftnndbnum,		rtf_pgndbnum,		//n mso_nfcDbNum1		= 10,	// ideograph-digital				Ideograph-digital	\pgndbnum
	rtf_saftnndbnumd,	rtf_sftnndbnumd,	rtf_aftnndbnumd,	rtf_ftnndbnumd,		rtf_pgndbnumd,		//n mso_nfcDbNum2		= 11,	// japanese-counting				Japanese counting	\pgndbnumd
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcAiueo		= 12,	// aiueo							Aiueo
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcIroha		= 13,	// iroha							Iroha
	rtf_saftnndbar,		rtf_sftnndbar,		rtf_aftnndbar,		rtf_ftnndbar,		rtf_pgndecd,		//s mso_nfcDbChar		= 14,	// decimal-full-width				ȫ�����֣������������������� \pgndecd
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcSbChar		= 15,	// decimal-half-width				������֣�1��2��3��4����
	rtf_saftnndbnumt,	rtf_sftnndbnumt,	rtf_aftnndbnumt,	rtf_ftnndbnumt,		rtf_pgndbnumt,		//n mso_nfcDbNum3		= 16,	// japanese-legal					����������ʽ���ң��r����	\pgndbnumt
	rtf_saftnndbnumk,	rtf_sftnndbnumk,	rtf_aftnndbnumk,	rtf_ftnndbnumk,		rtf_pgndbnumk,		//n mso_nfcDbNum4		= 17,	// japanese-digital-ten-thousand	Japanese digital ten thousand	\pgndbnumk
	rtf_saftnncnum,		rtf_sftnncnum,		rtf_aftnncnum,		rtf_ftnncnum,		rtf_pgncnum,		//s mso_nfcCirclenum	= 18,	// decimal-enclosed-circle			�٣��ڣ��ۣ���	\pgncnum
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcDArabic		= 19,	// decimal-full-width2				ȫ������2��������������������
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcDAiueo		= 20,	// aiueo-full-width					ȫ��Aiueo
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcDIroha		= 21,	// iroha-full-width					ȫ��Iroha
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcArabicLZ		= 22,	// decimal-zero						01��02���� 09��10��11����
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcBullet		= 23,	// bullet							��Ŀ�����ַ�
	rtf_saftnnganada,	rtf_sftnnganada,	rtf_aftnnganada,	rtf_ftnnganada,		rtf_pgnganada,		//n mso_nfcGanada		= 24,	// ganada							Korean Ganada	\pgnganada
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgnchosung,		//n mso_nfcChosung		= 25,	// chosung							Korea Chosung	\pgnchosung
	rtf_saftnngbnum,	rtf_sftnngbnum,		rtf_aftnngbnum,		rtf_ftnngbnum,		rtf_pgngbnum,		//n mso_nfcGB1			= 26,	// decimal-enclosed-fullstop		ȫ�Ǵ���㣺��������������		\pgngbnum
	rtf_saftnngbnumd,	rtf_sftnngbnumd,	rtf_aftnngbnumd,	rtf_ftnngbnumd,		rtf_pgngbnumd,		//s mso_nfcGB2			= 27,	// decimal-enclosed-paren			(1)��(2)��(3)����				\pgngbnumd
	rtf_saftnngbnuml,	rtf_sftnngbnuml,	rtf_aftnngbnuml,	rtf_ftnngbnuml,		rtf_pgngbnuml,		//n mso_nfcGB3			= 28,	// decimal-enclosed-circle-chinese	���ģ��٣��ڣ��ۣ���			\pgngbnuml
	rtf_saftnngbnumk,	rtf_sftnngbnumk,	rtf_aftnngbnumk,	rtf_ftnngbnumk,		rtf_pgngbnumk,		//s mso_nfcGB4			= 29,	// ideograph-enclosed-circle		�壬�棬�磬��					\pgngbnumk
	rtf_saftnnzodiac,	rtf_sftnnzodiac,	rtf_aftnnzodiac,	rtf_ftnnzodiac,		rtf_pgnzodiac,		//s mso_nfcZodiac1		= 30,	// ideograph-traditional			�ף��ң�������		\pgnzodiac
	rtf_saftnnzodiacd,	rtf_sftnnzodiacd,	rtf_aftnnzodiacd,	rtf_ftnnzodiacd,	rtf_pgnzodiacd,		//s mso_nfcZodiac2		= 31,	// ideograph-zodiac					�ӣ���������		\pgnzodiacd
	rtf_saftnnzodiacl,	rtf_sftnnzodiacl,	rtf_aftnnzodiacl,	rtf_ftnnzodiacl,	rtf_pgnzodiacl,		//s mso_nfcZodiac3		= 32,	// ideograph-zodiac-traditional		Ideograph Zodiac traditional	\pgnzodiacl
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcTpeDbNum1	= 33,	// taiwanese-counting				Taiwanese counting
	rtf_saftnndbnumd,	rtf_sftnndbnumd,	rtf_aftnndbnumd,	rtf_ftnndbnumd,		rtf_pgndbnumd,		//b mso_nfcTpeDbNum2	= 34,	// ideograph-legal-traditional		Ideograph legal traditional		\pgndbnumd
	rtf_saftnndbnumt,	rtf_sftnndbnumt,	rtf_aftnndbnumt,	rtf_ftnndbnumt,		rtf_pgndbnumt,		//n mso_nfcTpeDbNum3	= 35,	// taiwanese-counting-thousand		Taiwanese counting thousand		\pgndbnumt
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcTpeDbNum4	= 36,	// taiwanese-digital				Taiwanese digital
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcChnDbNum1	= 37,	// chinese-counting					����Сд��һ������������
	rtf_saftnndbnumd,	rtf_sftnndbnumd,	rtf_aftnndbnumd,	rtf_ftnndbnumd,		rtf_pgndbnumd,		//b mso_nfcChnDbNum2	= 38,	// chinese-legal-simplified			���Ĵ�д��Ҽ������������		\pgndbnumd	
	rtf_saftnndbnumt,	rtf_sftnndbnumt,	rtf_aftnndbnumt,	rtf_ftnndbnumt,		rtf_pgndbnumt,		//s mso_nfcChnDbNum3	= 39,	// chinese-counting-thousand		Chinese counting thousand��		\pgndbnumt
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndbnum,		//n mso_nfcChnDbNum4	= 40,	// chinese-not-impl					���ģ�δʵ�֣�
	rtf_saftnnchosung,	rtf_sftnnchosung,	rtf_aftnnchosung,	rtf_ftnnchosung,	rtf_pgndbnumd,		//n mso_nfcKorDbNum1	= 41,	// korean-digital					�������֣�?��?��?	\pgndbnum
	rtf_saftnnganada,	rtf_sftnnganada,	rtf_aftnnganada,	rtf_ftnnganada,		rtf_pgndec,			//n mso_nfcKorDbNum2	= 42,	// korean-counting					�������			\pgndbnumd
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcKorDbNum3	= 43,	// korean-legal						����������ʽ
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcKorDbNum4	= 44,	// korean-digital2					��������2
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHebrew1		= 45,	// hebrew-1							ϣ����1
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcArabic1		= 46,	// arabic-alpha						��������ĸ
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHebrew2		= 47,	// hebrew-2							ϣ����2
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcArabic2		= 48,	// arabic-abjad						Arabic abjad��?.��?.��?����
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHindi1		= 49,	// hindi-vowels						ӡ��Ԫ��
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHindi2		= 50,	// hindi-consonants					ӡ�ȸ���
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHindi3		= 51,	// hindi-numbers					ӡ��������
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcHindi4		= 52,	// hindi-counting					ӡ���Ļ���
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcThai1		= 53,	// thai-letters						̩����ĸ
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcThai2		= 54,	// thai-numbers						̩������
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcThai3		= 55,	// thai-counting					̩�Ļ���
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcViet1		= 56,	// vietnamese-counting				Խ���Ļ���
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgnid,			//n mso_nfcNumInDash	= 57,	// number-in-dash					ҳ���ʽ��- 1 -��- 2 -��- 3 -��- 4 - \pgnid
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcLCRus		= 58,	// russian-lower					Сд������ĸ
	rtf_saftnnar,		rtf_sftnnar,		rtf_aftnnar,		rtf_ftnnar,			rtf_pgndec,			//n mso_nfcUCRus		= 59,	// russian-upper					��д������ĸ
	rtf_blank,			rtf_blank,			rtf_aftnnar,		rtf_aftnnar,		rtf_pgndec,			//s mso_nfcMax			= 60,
};

inline RtfControl GetNfcCtrl(UINT8 nfc, numberformatctrls::WHICH_NFC which)
{
	UINT count = countof(nfcs);
	switch(which)
	{
	case numberformatctrls::which_fnd:
		if(nfc >= 0 && nfc < count)
			return nfcs[nfc].fndctrl;
		else
			return rtf_sftnnar;
	case numberformatctrls::which_end:
		if(nfc >= 0 && nfc < count)
			return nfcs[nfc].endctrl;
		else
			return rtf_saftnnar;		
	case numberformatctrls::which_dopfnd:
		if(nfc >= 0 && nfc < count)
			return nfcs[nfc].dopfndctrl;
		else
			return rtf_ftnnar;	
	case numberformatctrls::which_dopend:
		if(nfc >= 0 && nfc < count)
			return nfcs[nfc].dopendctrl;
		else
			return rtf_aftnnar;
	case numberformatctrls::which_pgn:
		if(nfc >=0 && nfc < count)
			return nfcs[nfc].pgnctrl;
		else
			return rtf_pgndec;
	default:
		ASSERT_ONCE(0);
	}
	return rtf_unknown;
}

inline RtfControl GetTcHoriMergeCtrl(UINT8 hm)
{
	const static RtfControl hmArray[] =
	{ rtf_unknown, rtf_unknown, rtf_clmrg, rtf_clmgf };
	const istart = mso_tcHoriMerged;
	if(hm >= istart && hm < countof(hmArray))
		return hmArray[hm];
	return rtf_unknown;
}

inline RtfControl GetTcVertMergeCtrl(UINT8 vm)
{
	const static RtfControl vmArray[] =
	{
		rtf_unknown,
		rtf_clvmrg,
		rtf_unknown,
		rtf_clvmgf,		
	};
	if(vm >=0 && vm < countof(vmArray))
		return vmArray[vm];
	return rtf_unknown;
}

inline RtfControl GetTcVergAlignCtrl(UINT8 vertAlign)
{
	const static RtfControl vaArray[] =
	{
		rtf_clvertalt,
		rtf_clvertalc,
		rtf_clvertalb,
	};
	if(vertAlign >= 0 && vertAlign < countof(vaArray))
		return vaArray[vertAlign];
	return rtf_clvertalt;
}

inline RtfControl GetFspaBxCtrl(ULONG bx)
{
	const static RtfControl bxes[] =
	{
		rtf_shpbxmargin,
		rtf_shpbxpage,
		rtf_shpbxcolumn,
	};
	if(bx >= 0 && bx < countof(bxes))
		return bxes[bx];
	return rtf_shpbxcolumn;
}

inline RtfControl GetFspaByCtrl(ULONG by)
{		
	const static RtfControl byes[] =
	{
		rtf_shpbymargin,
		rtf_shpbypage,
		rtf_shpbypara,
	};
	if(by >= 0 && by < countof(byes))
		return byes[by];
	return rtf_shpbypara;
}
// -------------------------------------------------------------------------
//	$Log: getctrl.h,v $
//	Revision 1.3  2006/08/28 05:48:11  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:00  xulingjiao
//	*** empty log message ***
//	

#endif /* __GETCTRL_H__ */
