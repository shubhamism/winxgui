/* -------------------------------------------------------------------------
//	�ļ���		��	text_annotation_end.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 9:59:29
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_ANNOTATION_END_H__
#define __TEXT_ANNOTATION_END_H__

// -------------------------------------------------------------------------

class KTextAnnEndHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
};	

// -------------------------------------------------------------------------

#endif /* __TEXT_ANNOTATION_END_H__ */
