/* -------------------------------------------------------------------------
//	�ļ���		��	text_anchor.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-18 10:56:21
//	��������	��	
//
//	$Id: text_anchor.cpp,v 1.34 2006/10/26 02:30:12 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_anchor.h"

#include <doctarget.h>
#include "emb_analyzer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP_(KDWOleShape) KTextAnchorHandler::_NewOleControl(IN KROAttributes* pOleControl)
{
	WCHAR szNull[] = { '\0' };
	BSTR szProgID = szNull;
	pOleControl->GetByID(draw_ole_control_progid, &szProgID);
	if (m_AnchorType == atNormal)
	{
		return m_pDocTarget->AddOleControl(m_Anchor, szProgID);
	}
	else
	{
		return m_pDocTarget->AddOleControl(
			abs(m_Anchor.xaRight - m_Anchor.xaLeft),
			abs(m_Anchor.yaTop - m_Anchor.yaBottom),
			szProgID);
	}
}
STDMETHODIMP_(KDWOleShape) KTextAnchorHandler::_NewOleShape(
															IN KROAttributes* pOleObject
															)
{
	WCHAR szNull[] = { '\0' };
	UINT oleType = ksoOleEmbedded;
	BSTR szProgID = szNull;
	pOleObject->GetByID(draw_ole_progid, &szProgID);
	pOleObject->GetByID(draw_ole_type, &oleType);
	if (m_AnchorType == atNormal)
	{
		if (oleType == ksoOleEmbedded)
		{
			return m_pDocTarget->AddOleEmbed(m_Anchor, szProgID);
		}
		else
		{
			BSTR szMonkier = szNull;
			pOleObject->GetByID(draw_ole_moniker, &szMonkier);
			return m_pDocTarget->AddOleLink(m_Anchor, szProgID, szMonkier);
		}
	}
	else
	{
		if (oleType == ksoOleEmbedded)
		{
			return m_pDocTarget->AddOleEmbed(
				abs(m_Anchor.xaRight - m_Anchor.xaLeft),
				abs(m_Anchor.yaTop - m_Anchor.yaBottom),
				szProgID);
		}
		else
		{
			BSTR szMonkier = szNull;
			pOleObject->GetByID(draw_ole_moniker, &szMonkier);
			return m_pDocTarget->AddOleLink(
				abs(m_Anchor.xaRight - m_Anchor.xaLeft),
				abs(m_Anchor.yaTop - m_Anchor.yaBottom),
				szProgID,
				szMonkier);
		}
	}
}

STDMETHODIMP KTextAnchorHandler::StartElement(
											  IN ELEMENTID uElementId,
											  IN KROAttributes* pAttrs)
{
	m_ElementId = uElementId;
	switch (m_ElementId)
	{
	case draw_shape:
		if (!m_pShapeElem)
		{
			m_pShapeElem = new KDWAnchorShapeHandler;
			m_pShapeElem->Init(&m_ShapeContext);
		}
		m_pElement = m_pShapeElem;
		break;
	case draw_group:
		if (!m_pGroupElem)
		{
			m_pGroupElem = new KDWAnchorGroupHandler;
			m_pGroupElem->Init(&m_ShapeContext);
		}
		m_pElement = m_pGroupElem;
		break;
	default:
		ASSERT(0);
		return E_FAIL;
	}
	

	//
	// ����ê������
	//
	KROAttributes* pAnchorAttr = NULL;
	pAttrs->GetByID(kso::text_shape_anchor, &pAnchorAttr);
	if (pAnchorAttr == NULL)
	{
		ASSERT(0);
		return E_FAIL;
	}
	AttrTransAnchor(
		pAnchorAttr, m_Anchor, 
		m_ShapeContext.m_opt, 
		m_ShapeContext.m_optUDef,
		m_ZOrder
		);

	//
	// ����ClientData���ݡ�
	//
	{
		if (m_pDocTarget->getFeature().writeKsExt())
		{
			KROAttributes* pAttrClientData = NULL;
			pAttrs->GetByID(kso::text_dgData, &pAttrClientData);

			if (pAttrClientData)
			{
				MsoShapeOPT& optUDef = m_ShapeContext.m_optUDef;

				UINT uValue;

				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataTextRotate, &uValue) ))
				{
					optUDef.AddPropFix(ksextopt_TextRotate, uValue);
				}
				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataTextResize, &uValue) ))
				{
					optUDef.AddPropFix(ksextopt_TextResize, uValue);
				}
				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataInnerWidth, &uValue)))
				{
					optUDef.AddPropFix(ksextopt_InnerWidth, uValue);
				}
				if (SUCCEEDED(
					pAttrClientData->GetByID(kso::text_dgDataInnerHeight, &uValue)))
				{
					optUDef.AddPropFix(ksextopt_InnerHeight, uValue);
				}


				KROAttributes* pAttrHorzLine = NULL;
				pAttrClientData->GetByID(kso::text_dgHorzLine, &pAttrHorzLine);

				if (pAttrHorzLine)
				{	
					MsoShapeOPT& optUDef = m_ShapeContext.m_optUDef;

					UINT uValue;

					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHorzLineCXWidthRel, &uValue) ))
					{
						optUDef.AddPropFix(msopt_spCXWidthRel, uValue);
					}
					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHoriLineAlignCenter, &uValue) ))
					{
						optUDef.AddPropFix(msopt_spJc, uValue);
					}
					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHorzLineCXWidth, &uValue)))
					{
						optUDef.AddPropFix(msopt_spCXWidth, uValue);
					}
					if (SUCCEEDED(
						pAttrHorzLine->GetByID(kso::text_dgHorzLineCYHeight, &uValue)))
					{
						optUDef.AddPropFix(msopt_spCYHeight, uValue);
					}
				}
			
			}

		}
	}



	//
	// ���ݶ�������ѡ���½�����
	//
	pAnchorAttr->GetByID(kso::text_anchor_type, &m_AnchorType);
	switch (m_ElementId)
	{
	case draw_shape:
		{
			//
			// Ole�ؼ�
			//
			KROAttributes* pOleControl = NULL;
			pAttrs->GetByID(kso::draw_ole_control, &pOleControl);
			if (pOleControl)
			{
				UINT uStgId = (UINT)-1;
				VERIFY_OK(
					pOleControl->GetByID(draw_ole_control_medium_source, &uStgId)
					);

				KDWOleShape oleshape = _NewOleControl(pOleControl);
				m_pDocTarget->SetOleStorage(uStgId, oleshape);
				m_ShapeContext.m_shape = oleshape;
				break;
			}
			KROAttributes* pOleObject = NULL;
			pAttrs->GetByID(draw_ole_object, &pOleObject);
			//
			// Ole����
			//
			if (pOleObject)
			{
				UINT uStgId = (UINT)-1;
				VERIFY_OK(
					pOleObject->GetByID(draw_ole_medium_source, &uStgId)
					);

				KDWOleShape oleshape = _NewOleShape(pOleObject);
				m_pDocTarget->SetOleStorage(uStgId, oleshape);
				m_ShapeContext.m_shape = oleshape;
			}
			//
			// ��ͨ���Ŷ���
			//
			else if (m_AnchorType == atNormal)
			{
				m_ShapeContext.m_shape = m_pDocTarget->AddShape(m_Anchor, FALSE);
			}
			//
			// Ƕ��ʽ����
			//
			else
			{
				//
				// ��ʽǶ��ʽ����
				//
				if (_DWIsEmbPic(m_pDocTarget, pAttrs))
				{
					m_ShapeContext.m_shape = m_pDocTarget->AddInlinePicture(
						abs(m_Anchor.xaRight - m_Anchor.xaLeft),
						abs(m_Anchor.yaTop - m_Anchor.yaBottom)
						);
				}
				//
				// ����Ƕ��ʽ����
				//
				else
				{
					m_ShapeContext.m_optUDef.AddPropBool(
						msopt_fInlineShape, TRUE
						);
					m_ShapeContext.m_shape = m_pDocTarget->AddInlineShape(
						abs(m_Anchor.xaRight - m_Anchor.xaLeft),
						abs(m_Anchor.yaTop - m_Anchor.yaBottom), FALSE
						);
				}
			}
		}
		break;
	case draw_group:
		if (m_AnchorType == atNormal)
		{
			m_ShapeContext.m_shape = m_pDocTarget->AddShape(m_Anchor, TRUE);
		}
		else
		{
			m_ShapeContext.m_optUDef.AddPropBool(
				msopt_fInlineShape, TRUE
				);
			m_ShapeContext.m_shape = m_pDocTarget->AddInlineShape(
				abs(m_Anchor.xaRight - m_Anchor.xaLeft),
				abs(m_Anchor.yaTop - m_Anchor.yaBottom), TRUE);
		}
		break;
	default:
		ASSERT(0);
		return E_FAIL;
	}
	m_ShapeContext.m_shape.SetZOrder(m_ZOrder);
	return m_pElement->StartElement(uElementId, pAttrs);
}

// -------------------------------------------------------------------------
// $Log: text_anchor.cpp,v $
// Revision 1.34  2006/10/26 02:30:12  wangdong
// HorzLine
//
// Revision 1.33  2006/07/31 07:00:04  wangdong
// #26126������дdocʱ��feature��������ݡ�
//
// Revision 1.32  2006/05/11 03:16:18  wangdong
// no message
//
// Revision 1.31  2006/04/10 07:51:15  laipinge
// �ؼ�����Ĵ������̵�����ole����һ��
//
// Revision 1.30  2006/04/07 07:52:04  laipinge
// ����OleControl
//
// Revision 1.29  2006/04/07 04:07:00  laipinge
// no message
//
// Revision 1.28  2005/12/30 07:30:06  wangdong
// �������Ƕ�������д�����ԣ����ϡ�
//
// Revision 1.27  2005/12/20 01:37:01  wangdong
// doc��ʽ��д�����������ԡ�
//
// Revision 1.26  2005/08/18 08:27:35  wangdong
// �����˶��󴴽������̣������˶�InlineShape��EmbPic����⡣
//
// Revision 1.25  2005/06/30 04:15:21  xushiwei
// bug# 17689 ���� - fixed��
//
// Revision 1.24  2005/06/30 02:37:40  xushiwei
// *** empty log message ***
//
// Revision 1.23  2005/06/30 02:32:37  xushiwei
// bug# 17689 - �޸ķ��ֵ�����������⡣
//
