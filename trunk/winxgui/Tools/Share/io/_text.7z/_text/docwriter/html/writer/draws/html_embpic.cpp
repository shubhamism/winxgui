/* -------------------------------------------------------------------------
//	�ļ���		��	html_embpic.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:44:51
//	��������	��	
//
//	$Id: html_embpic.cpp,v 1.6 2006/08/25 08:21:15 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "mso/io/rtf/writer/include/optparser.h"
#include "html_draws_helper.h"
#include "html_embpic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
HtmlWEmbpicWriter::HtmlWEmbpicWriter(HtmlWGlobalInfo* info) : m_ginfo(info)
{
}

STDMETHODIMP HtmlWEmbpicWriter::Write(const Location* picloc)
{
	const _KDWEmbShapeEx* embshp = m_ginfo->doc->_GetEmbShapes()->GetEmbShape(picloc);
	if(!embshp)
		return E_FAIL;
	
	KObjPropsTable opt(embshp->opt, FALSE);
	MsoROShapeProp prop;
	HRESULT hr = opt.Find(msopt_pib, &prop);
	if(FAILED(hr))
		return hr;
	
	ks_wstring src_attrval;
	MsoBlip blip = m_ginfo->doc->GetBlipStore().GetBlip(prop.op);
	hr = ExportBlip2File(src_attrval, blip, m_ginfo->ar->GetDestFile());
	if(FAILED(hr))
	{
		ASSERT_ONCE(0);
		return hr;
	}
	PixelType width = inch_to_pixel(twip_to_inch(embshp->cxaShape));
	PixelType height = inch_to_pixel(twip_to_inch(embshp->cyaShape), FALSE);
	WriteIMGtag(m_ginfo->ar, src_attrval.c_str(), width, height);
	return S_OK;
}
