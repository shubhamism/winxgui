/* -------------------------------------------------------------------------
//	�ļ���		��	html_ranges.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:32:02
//	��������	��	
//
//	$Id: html_ranges.cpp,v 1.11 2006/07/13 02:51:29 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "mso/io/css/cssbuffer.h"
#include "props/html_plcfchpx.h"
#include "props/html_plcfpapx.h"
#include "props/html_plcfsepx.h"
#include "ranges/html_fields.h"
#include "ranges/html_bookmarks.h"
#include "html_ranges.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
STDMETHODIMP_(HtmlWChpxWriter&) HtmlWRangesWriter::GetChpinfo()
{
	return m_wrChpxs->GetChpinfo();
}

STDMETHODIMP_(HtmlWPapxWriter&) HtmlWRangesWriter::GetPapInfo()
{
	return m_wrPapxs->GetPapInfo();
}

STDMETHODIMP_(CssPropBuffer*) HtmlWRangesWriter::GetCurrentChpxCssprop()
{
	return m_wrChpxs->GetCurrentChpxCssprop();
}

STDMETHODIMP_(HtmlWMainFieldsWriter*) HtmlWRangesWriter::GetFields()
{
	return m_wrMainFlds;
}
HtmlWRangesWriter::HtmlWRangesWriter(HtmlWGlobalInfo* info) :
	m_ginfo(info),
	m_wrChpxs(NULL),
	m_wrPapxs(NULL),
	m_wrSepxs(NULL),
	m_wrMainFlds(NULL),
	m_wrBookmarkStarts(NULL),
	m_wrBookmarkEnds(NULL),
	fBookmkOpen(FALSE),
	m_cp(-1)
{
}
STDMETHODIMP_(HtmlWGlobalInfo*) HtmlWRangesWriter::GetGlobalInfo()
{
	return m_ginfo;
}
STDMETHODIMP_(void) HtmlWRangesWriter::SetPlcfChpx(HtmlWChpxsWriter* wrChpxs)
{
	if(wrChpxs && wrChpxs->Good())
		m_wrChpxs = wrChpxs;
}
STDMETHODIMP_(void) HtmlWRangesWriter::SetPlcfPapx(HtmlWPapxsWriter* wrPapxs)
{
	if(wrPapxs && wrPapxs->Good())
		m_wrPapxs = wrPapxs;
}

STDMETHODIMP_(void) HtmlWRangesWriter::SetPlcfSepx(HtmlWSepxsWriter* wrSepxs)
{
	if(wrSepxs && wrSepxs->Good())
		m_wrSepxs = wrSepxs;
}

STDMETHODIMP_(void) HtmlWRangesWriter::SetMainFields(HtmlWMainFieldsWriter* wrFields)
{
	if(wrFields && wrFields->Good())
		m_wrMainFlds = wrFields;
}
STDMETHODIMP_(void) HtmlWRangesWriter::SetMainBookmkStarts(HtmlWBookmarkStartsWriter* wrBookmks)
{
	if(wrBookmks && wrBookmks->Good())
		m_wrBookmarkStarts = wrBookmks;
}
STDMETHODIMP_(void) HtmlWRangesWriter::SetMainBookmkEnds(HtmlWBookmarkEndsWriter* wrBookmks)
{
	if(wrBookmks && wrBookmks->Good())
		m_wrBookmarkEnds = wrBookmks;
}
STDMETHODIMP_(void) HtmlWRangesWriter::Reset()
{
	if (m_wrChpxs)
		m_wrChpxs->Reset();
	if (m_wrPapxs)
		m_wrPapxs->Reset();
	if (m_wrMainFlds)
		m_wrMainFlds->Reset();
	if (m_wrBookmarkStarts)
		m_wrBookmarkStarts->Reset();
	if (m_wrBookmarkEnds)
		m_wrBookmarkEnds->Reset();
	if (m_wrSepxs)
		m_wrSepxs->Reset();

	m_cp = __GetCp();

	if (m_wrPapxs && m_wrChpxs)
		m_wrChpxs->SetIstdPara(m_wrPapxs->GetIstd(m_cp));
}
STDMETHODIMP HtmlWRangesWriter::Next()
{		
	HRESULT hr = E_FAIL;
	if (m_wrSepxs && m_current.fSepxs)
		hr = SUCCEEDED(m_wrSepxs->Next()) ? S_OK : hr;

	if (m_wrPapxs && m_current.fPapxs)
		hr = SUCCEEDED(m_wrPapxs->Next()) ? S_OK : hr;
	
	if (m_wrChpxs && m_current.fChpxs)
		hr = SUCCEEDED(m_wrChpxs->Next()) ? S_OK : hr;

	if (m_wrMainFlds && m_current.fFields)
		hr = SUCCEEDED(m_wrMainFlds->Next()) ? S_OK : hr;

	if (m_wrBookmarkStarts && m_current.fBookmksStart)
		hr = SUCCEEDED(m_wrBookmarkStarts ->Next()) ? S_OK : hr;

	if (m_wrBookmarkEnds && m_current.fBookmksEnd)
		hr = SUCCEEDED(m_wrBookmarkEnds->Next()) ? S_OK : hr;
	
	if(FAILED(hr))
		return hr;

	INT cpOld = m_cp;
	m_cp = __GetCp();

	// �����ǰ�θı䣬���istdparaҪ��������
	if (m_current.fPapxs && m_wrPapxs && m_wrChpxs)
		m_wrChpxs->SetIstdPara(m_wrPapxs->GetIstd(m_cp));
	return hr;
}
STDMETHODIMP_(UINT) HtmlWRangesWriter::GetCp()
{
	return m_cp;
}
STDMETHODIMP_(UINT) HtmlWRangesWriter::GetNextCp()
{
	return __GetCpNext();
}
STDMETHODIMP_(void) HtmlWRangesWriter::Write(UINT SpecText)
{
	if (m_current.fSepxs && m_wrSepxs)
		m_wrSepxs->Write();
	if (m_current.fPapxs && m_wrPapxs)
	{
		if(m_wrChpxs)
			m_wrChpxs->EnsureWriteEnd();
		m_wrPapxs->Write();
	}
	if (m_current.fChpxs && m_wrChpxs)
		m_wrChpxs->Write(SpecText);
	if (m_current.fFields && m_wrMainFlds)
		m_wrMainFlds->Write();
	if (m_current.fBookmksStart && m_wrBookmarkStarts)
	{
		m_wrBookmarkStarts->Write(m_ginfo->ar);
		fBookmkOpen = TRUE;
	}
	if (m_current.fBookmksEnd && m_wrBookmarkEnds)
	{
		m_wrBookmarkEnds->Write(m_ginfo->ar);
		fBookmkOpen = FALSE;
	}
}

STDMETHODIMP_(void) HtmlWRangesWriter::EnsureWriteEnd(WriterType wr)
{
	switch(wr)
	{
	case chpxs:
		if(m_wrChpxs)
			m_wrChpxs->EnsureWriteEnd();
		break;
	case papxs:
		if(m_wrPapxs)
			m_wrPapxs->EnsureWriteEnd();
		break;
	case sepxs:
		if(m_wrSepxs)
			m_wrSepxs->EnsureWriteEnd();
		break;	
	}
}
STDMETHODIMP_(void) HtmlWRangesWriter::EnsureWriteEnd()
{
	if (fBookmkOpen && m_wrBookmarkEnds)
	{
		m_wrBookmarkEnds->Write(m_ginfo->ar);
		fBookmkOpen = FALSE;
	}
	if (m_wrChpxs)
		m_wrChpxs->EnsureWriteEnd();		
	if (m_wrPapxs)
		m_wrPapxs->EnsureWriteEnd();
	if (m_wrSepxs)
		m_wrSepxs->EnsureWriteEnd();
}
UINT HtmlWRangesWriter::__GetCp()
{
	UINT cp = (UINT)-1;		
	UINT cpPapxs = cp;
	UINT cpChpxs = cp;		
	UINT cpFields = cp;
	UINT cpSepxs = cp;
	UINT cpBookmkStarts = cp, cpBookmkEnds = cp;

	if (m_wrSepxs)
		cpSepxs = m_wrSepxs->GetCurrentCp();
	if (m_wrPapxs)
		cpPapxs = m_wrPapxs->GetCurrentCp();
	if (m_wrChpxs)
		cpChpxs = m_wrChpxs->GetCurrentCp();	
	if (m_wrMainFlds)
		cpFields = m_wrMainFlds->GetCurrentCp();
	if (m_wrBookmarkStarts)
		cpBookmkStarts = m_wrBookmarkStarts->GetCurrentCp();
	if (m_wrBookmarkEnds)
		cpBookmkEnds = m_wrBookmarkEnds->GetCurrentCp();

	if (cpSepxs <= cp)
	{
		if (cpSepxs < cp)
			m_current.Reset();
		m_current.fSepxs = TRUE;
		cp = cpSepxs;
	}	
	if (cpPapxs <= cp)
	{
		if (cpPapxs < cp)
			m_current.Reset();
		m_current.fPapxs = TRUE;
		cp = cpPapxs;
	}		
	if (cpChpxs <= cp)
	{
		if (cpChpxs < cp)
			m_current.Reset();
		m_current.fChpxs = TRUE;
		cp = cpChpxs;
	}
	if (cpFields <= cp)
	{
		if (cpFields < cp)
			m_current.Reset();
		m_current.fFields = TRUE;
		cp = cpFields;
	}
	if (cpBookmkStarts <= cp)
	{
		if (cpBookmkStarts < cp)
			m_current.Reset();

		m_current.fBookmksStart = TRUE;
		cp = cpBookmkStarts;
	}
	if (cpBookmkEnds <= cp)
	{
		if (cpBookmkEnds < cp)
			m_current.Reset();

		m_current.fBookmksEnd = TRUE;
		cp = cpBookmkEnds;
	}
	return cp;
}	
UINT HtmlWRangesWriter::__GetCpNext()
{
	UINT cpNext = (UINT)-1;
	
	UINT cpPapxs = cpNext;
	UINT cpChpxs = cpNext;
	UINT cpSepxs = cpNext;
	UINT cpFields = cpNext;
	UINT cpBookmkStarts = cpNext;
	UINT cpBookmkEnds = cpNext;
	if (m_wrSepxs)
		cpSepxs = m_wrSepxs->GetNextCp();
	if (m_wrPapxs)
		cpPapxs = m_wrPapxs->GetNextCp();
	if (m_wrChpxs)
		cpChpxs = m_wrChpxs->GetNextCp();
	if (m_wrMainFlds)
		cpFields = m_wrMainFlds->GetNextCp();
	if (m_wrBookmarkStarts)
		cpBookmkStarts = m_wrBookmarkStarts->GetNextCp();
	if (m_wrBookmarkEnds)
		cpBookmkEnds = m_wrBookmarkEnds->GetNextCp();

	if (cpSepxs <= cpNext)
		cpNext = cpSepxs;
	if (cpPapxs <= cpNext)
		cpNext = cpPapxs;		
	if (cpChpxs <= cpNext)
		cpNext = cpChpxs;
	if (cpFields <= cpNext)
		cpNext = cpFields;
	if (cpBookmkStarts <= cpNext)
		cpNext = cpBookmkStarts;
	if (cpBookmkEnds <= cpNext)
		cpNext = cpBookmkEnds;	
	
	return cpNext;
}