/* -------------------------------------------------------------------------
//	�ļ���		��	draw_shape.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-18 16:28:41
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "draw_shape.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP KDWAnchorShapeHandler::StartElement(
	IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	KROAttributes* textAttr = NULL;

	HRESULT hr = _Base::StartElement(uElementID, pAttrs);
	KS_CHECK(hr);

	pAttrs->GetByID(kso::draw_text_prop, &textAttr);
	if (textAttr)
	{
		UINT textFlow = kso::TextFlowNormal;
		if (m_pContext->m_pDocTarget->getFeature().writeKsExt())
		{
			if (
				SUCCEEDED(textAttr->GetByID(kso::draw_text_flow, &textFlow))
				)
			{
				UINT8 data[2];
				data[0] = ksopt_textframeFlow;
				data[1] = textFlow;
				m_pContext->m_optUDef.AddPropVar(
					ksextopt_textCodeExt, data, 2
					);
			}

		}
	}

KS_EXIT:
	return hr;
}



// -------------------------------------------------------------------------
