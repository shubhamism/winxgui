/* -------------------------------------------------------------------------
//	�ļ���		��	office_document.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 16:54:07
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_DOCUMENT_H__
#define __OFFICE_DOCUMENT_H__

#ifndef __OFFICE_BODY_H__
#include "office_body.h"
#endif

#ifndef __OFFICE_STYLES_H__
#include "office_styles.h"
#endif

#ifndef __OFFICE_USER_H__
#include "office_user.h"
#endif

#ifndef __OFFICE_META_H__
#include "office_meta.h"
#endif

#ifndef __OFFICE_MEDIUMS_H__
#include "office_mediums.h"
#endif

#ifndef __OFFICE_PROTDOC_H__
#include "office_protdoc.h"
#endif

#ifndef __DRAW_CANVAS_H__
#include "draw_canvas.h"
#endif

#ifndef __OFFICE_MACRO_VARIABLES_H__
#include "office_macro_variables.h"
#endif

// -------------------------------------------------------------------------

typedef KDWCollectionHandler<KOfficeUserHandler, office_user> KOfficeUsersHandler;

class KOfficeUsersHandlerLast : public KOfficeUsersHandler
{
public:
	STDMETHODIMP EndElement(IN ELEMENTID uElementID);
};

class KOfficeDocHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KOfficeBodyHandler m_bodyElement;
	KOfficeStylesHandler m_stylesElement;
	KOfficeUsersHandlerLast m_usersElement;
	KOfficeMetaHandler m_metaElement;
	KOfficeMediumsHandler m_mediumElement;
	KDrawCanvasHandler m_CanvasElement;
	KOfficeProtDoc m_protdocElem;
	KMacroHandler m_MacroElement;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
		
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		return S_OK;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_DOCUMENT_H__ */
