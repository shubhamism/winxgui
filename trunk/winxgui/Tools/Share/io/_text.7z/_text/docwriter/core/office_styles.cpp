/* -------------------------------------------------------------------------
//	�ļ���		��	office_styles.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-17 10:03:00
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_styles.h"
#include <core/attributes/attrtrans.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeStylesHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_fonts:
		m_fontsElement.Init(m_pDocTarget);
		*ppHandler = &m_fontsElement;
		break;
	case text_lists:
		m_listsElement.Init(m_pDocTarget);
		*ppHandler = &m_listsElement;
		break;
	case text_p_style:
		m_paraStyleElement.Init(m_pDocTarget, &m_PStyleInfoMap);
		*ppHandler = &m_paraStyleElement;
		break;
	case text_r_style:
		m_spanStyleElement.Init(m_pDocTarget, &m_RStyleInfoMap);
		*ppHandler = &m_spanStyleElement;
		break;
	case draw_default_shapeprops:
		m_defpropElement.Init(m_pDocTarget);
		*ppHandler = &m_defpropElement;
		break;
	case text_table_style: // text-table styles
		return IO_E_IGNORE;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

STDMETHODIMP KOfficeStylesHandler::EndElement(
	IN ELEMENTID uID)
{
	KDWAutoFreeAlloc* const pAlloc = m_pDocTarget->GetAllocater();
	KDWStyleSheet& StyleSheet = m_pDocTarget->GetStyleSheet();

	// ��������ʽ��Ĺ�ϵ
	{
		KDWStyleInfoMap::const_iterator i = m_RStyleInfoMap.begin();
		for (; i != m_RStyleInfoMap.end(); ++i)
		{
			KDWStyleRelation const& Info = *i;
			KDWStyle Style;
			if (SUCCEEDED(StyleSheet.GetStyle(Info.nIstd, &Style)))
			{
				KDWStyleIDMap& IdMapR = m_pDocTarget->GetRStyleIDMap();
				KDWStyleIDMap::const_iterator j = IdMapR.find(Info.nBase);
				if (j != IdMapR.end())
					Style.SetBaseStyle((*j).second);

				KDWStyleIDMap& IdMapP = m_pDocTarget->GetPStyleIDMap();
				j = IdMapP.find(Info.nLink);
				if (j != IdMapP.end())
					Style.SetLinkStyle((*j).second);
			}
		}
	}
	// ��������ʽ��Ĺ�ϵ�������Ʊ�λ
	{
		KDWStyleInfoMap::const_iterator i = m_PStyleInfoMap.begin();
		const KDWV6TABMap& TsMap = m_pDocTarget->GetTABMap();
		for (; i != m_PStyleInfoMap.end(); ++i)
		{
			KDWStyleRelation const& Info = *i;
			KDWStyle Style;
			if (SUCCEEDED(StyleSheet.GetStyle(Info.nIstd, &Style)))
			{
				KDWStyleIDMap& IdMapP = m_pDocTarget->GetPStyleIDMap();
				KDWStyleIDMap::const_iterator j = IdMapP.find(Info.nBase);
				if (j != IdMapP.end())
					Style.SetBaseStyle((*j).second);
				j = IdMapP.find(Info.nNext);
				if (j != IdMapP.end())
					Style.SetNextStyle((*j).second);

				KDWStyleIDMap& IdMapR = m_pDocTarget->GetRStyleIDMap();
				j = IdMapR.find(Info.nLink);
				if (j != IdMapR.end())
					Style.SetLinkStyle((*j).second);

				TransTAB(m_pDocTarget,
					Info.nBase, 
					Info.nLst, Info.nLvl,
					Info.pChgTAB,
					Info.pPropBuffer);

				Style.SetSprmList(mso_sgcParagraph, Info.pPropBuffer);
			}
		}
	}
	return S_OK;
}

// -------------------------------------------------------------------------
