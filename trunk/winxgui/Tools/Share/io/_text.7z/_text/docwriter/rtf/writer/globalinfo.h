// -------------------------------------------------------------------------
//	�ļ���		��	mso/io/rtf/writer/globalinfo.h
//	������		��	nature(liucong)
//	����ʱ��	��	2005-8-3 ���� 09:23:22
//	��������	��	
//
//	$Id: globalinfo.h,v 1.7 2006/04/05 07:49:59 xulingjiao Exp $
// -------------------------------------------------------------------------
#ifndef __MSO_IO_RTF_WRITER_GLOBALINFO_H__
#define __MSO_IO_RTF_WRITER_GLOBALINFO_H__

#include "colortable.h"
#include "styleshelper.h"

class RtfWIdGenerator
{
	ULONG m_id;
public:
	RtfWIdGenerator() : m_id(10000)
	{
	}
	STDMETHODIMP_(ULONG) GenInsrsid()
	{
		return ++m_id;
	}
};

class RtfWColorTable;
class RtfWIdGenerator;
class RtfWTextStreamWriter;
struct RtfWGlobalInfo
{
	RtfWGlobalInfo() : colors(NULL), styles(NULL), dop(NULL), lists(NULL), fonttbl(NULL), stsh(NULL), wrMainStream(NULL), doc(NULL)
	{		
	}
	RtfWColorTable* colors;
	RtfWStyleSheet* styles;	
	RtfWTextStreamWriter* wrMainStream;
	const KDWDocProperties* dop;
	const KDWListTable* lists;
	const KDWFontTable* fonttbl;
	const KDWStyleSheet* stsh;
	const KDWDocument* doc;
	RtfWIdGenerator idgen;
};

inline 
STDMETHODIMP_(void) ScanCharSprms(RtfWGlobalInfo* info, KDWSprmList* sprms)
{	
	RtfWColorTable* colors = info->colors;
	KDWSprm sprm;
	const BYTE* arg = NULL;
	INT len = -1, csprm = sprms->GetCount();
	
	KDWSprmList::Enumerator enumer(sprms);
	while(SUCCEEDED(enumer.Next(&sprm)))
	{
		VERIFY_OK(sprm.GetArgument(&arg, &len));
		USHORT opcode = sprm.GetOpcode();
		switch (opcode)
		{
		case sprmCKulColor:
			colors->AddColor(*((const COLORREF*)arg));
			break;
		case sprmCIco:
			{
				COLORREF cr = Ico2RGB(GetValue<UINT8>(arg));
				colors->AddColor(cr);
			}
			break;
		case sprmCShdEx:
			{
				KDWShd shd;				
				AssignShdex(shd, arg);
				colors->AddColor(shd.crFore);
				colors->AddColor(shd.crBack);
			}
			break;
		case sprmCBrcEx:			
			{
				KDWBrc brc;
				AssignBrcEx(brc, arg);
				colors->AddColor(brc.crFore);
			}
			break;		
		case sprmCTextColor:
			colors->AddColor(GetValue<COLORREF>(arg));
			break;
		case sprmCHighlight:
			colors->AddColor(Ico2RGB(GetValue<UINT8>(arg)));
			break;
		default:
			break;
		}
	}	
}

inline
STDMETHODIMP ScanListData(RtfWGlobalInfo* info)
{
	const _DW_ListTable* pListTable = info->lists->GetListTable();
	if(!pListTable)
		return E_FAIL;
	INT i, j;
	for(i=0; i<pListTable->size(); ++i)
	{
		_DW_ListData* pListData = pListTable->at(i);
		for(j=0; j<pListData->nLevels; ++j)
		{
			const _DW_ListLevel* pListLevel = &(pListData->level[j]);			
			KDWSprmList sprms((const BYTE*)pListLevel->pChpx, pListLevel->lvlf.cbGrpprlChpx);			
			ScanCharSprms(info, &sprms);
		}		
	}
	return S_OK;
}

inline
STDMETHODIMP_(void) ScanParaSprms(RtfWGlobalInfo* info, KDWSprmList* sprms)
{
	RtfWColorTable* colors = info->colors;
	KDWSprm sprm;
	const BYTE* arg = NULL;
	INT len = -1, ilfo = 0, ilvl = 0, csprm = sprms->GetCount();

	KDWSprmList::Enumerator enumer(sprms);
	while(SUCCEEDED(enumer.Next(&sprm)))
	{
		VERIFY_OK(sprm.GetArgument(&arg, &len));
		USHORT opcode = sprm.GetOpcode();
		switch(opcode)
		{
		case sprmPShdEx:
			{
				KDWShd shd;					
				AssignShdex(shd, arg);
				colors->AddColor(shd.crFore);
				colors->AddColor(shd.crBack);
			}
			break;
		case sprmPBrcTopEx:
			{
				KDWBrc brcTop;					
				AssignBrcEx(brcTop, arg);
				colors->AddColor(brcTop.get_Color());
			}
			break;
		case sprmPBrcBottomEx:
			{
				KDWBrc brcBottom;
				AssignBrcEx(brcBottom, arg);
				colors->AddColor(brcBottom.get_Color());
			}
			break;
		case sprmPBrcLeftEx:
			{
				KDWBrc brcLeft;					
				AssignBrcEx(brcLeft, arg);
				colors->AddColor(brcLeft.get_Color());
			}
			break;
		case sprmPBrcRightEx:
			{
				KDWBrc brcRight;					
				AssignBrcEx(brcRight, arg);
				colors->AddColor(brcRight.get_Color());
			}
			break;
		case sprmPBrcBetweenEx:
			{
				KDWBrc brcBetween;					
				AssignBrcEx(brcBetween, arg);
				colors->AddColor(brcBetween.get_Color());
			}
			break;
		case sprmTTableBorders:
			{
				BRC brcs[6];
				for(INT i=0; i<6; ++i)
				{
					AssignBrc(brcs[i], arg);
					colors->AddColor(Ico2RGB(brcs[i].ico));
				}
			}
			break;
		case sprmTTableBordersEx:
			{
				BRCEX brcs[6];					
				for(INT i=0; i<6; ++i)
				{
					AssignBrcEx(brcs[i], arg);
					colors->AddColor(brcs[i].crFore);
				}
			}
			break;			
		case sprmTDefTable:
			{
				UINT8 itcMax = *arg;
				INT cbIgnore = 1 + (itcMax+1)*sizeof(INT16);
				UINT8 itc = (len - cbIgnore) / sizeof(TC);
				arg += cbIgnore;
				INT i, j;
				for(i=0; i<itc; ++i)
				{
					arg += 4;
					for(j=0; j<4; ++j)
					{
						BRC brc;
						AssignBrc(brc, arg);
						arg += sizeof(BRC);
						colors->AddColor(Ico2RGB(brc.ico));							
					}
				}
			}
			break;
		case sprmTDefTableShd:
			{
				UINT itcMax = len / sizeof(SHD), i;
				for(i=0; i<itcMax; ++i)
				{
					SHD shd;
					AssignShd(shd, arg);
					arg += sizeof(SHD);
					colors->AddColor(Ico2RGB(shd.icoFore));
					colors->AddColor(Ico2RGB(shd.icoBack));
				}
			}
			break;
		case sprmTDefTableShdEx:
			{
				UINT itcMax = len / sizeof(SHDEX), i;
				for(i=0; i<itcMax; ++i)
				{
					SHDEX shdex;
					AssignShdex(shdex, arg);
					arg += sizeof(SHDEX);
					colors->AddColor(shdex.crFore);
					colors->AddColor(shdex.crBack);
				}
			}
			break;
		case sprmTDefTableShdEx2:
			{
				UINT itcMax = len / sizeof(SHDEX), i;
				for(i=0; i<itcMax; ++i)
				{
					SHDEX shdex;
					AssignShdex(shdex, arg);
					arg += sizeof(SHDEX);
					colors->AddColor(shdex.crFore);
					colors->AddColor(shdex.crBack);
				}
			}
			break;			
		default:
			ScanCharSprms(info, sprms);
			break;
		}
	}	
}

inline
STDMETHODIMP_(void) ScanStyleSprms(RtfWGlobalInfo* info, KDWSprmList* sprms, STYLE_SGC sgc)
{	
	switch(sgc)
	{
	case mso_sgcCharacter:
		ScanCharSprms(info, sprms);
		break;
	case mso_sgcParagraph:
		ScanParaSprms(info, sprms);
		break;
	}
}

// todo: ��Ҫ�Ż�����
inline
STDMETHODIMP_(void) ScanInfo(const KDWDocument* doc, RtfWGlobalInfo* info)
{	
	RtfWColorTable* colors = info->colors;	

	for (INT subdoc = 0; subdoc < DW_SUBDOC_MAX; ++subdoc)
	{
		const KDWTextStream* stream = doc->GetStream((SUBDOC_TYPE)subdoc);
		if (stream == NULL)
			continue;

		KDWPlcfChpx chpxs = stream->GetPlcfChpx();
		
		for (INT i = 0; i < chpxs.Count(); ++i)
		{
			KDWSprmList sprms;
			sprms.AssignChpx(chpxs.SrcData(i));

			KDWSprmList styleSprms;
			INT istd = sprms.GetCharIstd();
			info->styles->GetChpxSprms(&styleSprms, istd);
			ScanStyleSprms(info, &styleSprms, mso_sgcCharacter);
			ScanCharSprms(info, &sprms);
		}

		KDWPlcfPapx papxs = stream->GetPlcfPapx();		
		for (INT i = 0; i < papxs.Count(); ++i)
		{
			KDWSprmList sprms;
			sprms.AssignPapx(papxs.SrcData(i));
			KDWSprmList styleSprms_ch, styleSprms_para;
			
			UINT16 istd = sprms.GetParaIstd();
			info->styles->GetChpxSprms(&styleSprms_ch, istd);
			ScanStyleSprms(info, &styleSprms_ch, mso_sgcCharacter);
			info->styles->GetPapxSprms(&styleSprms_para, istd);
			ScanStyleSprms(info, &styleSprms_para, mso_sgcParagraph);
			ScanParaSprms(info, &sprms);
		}
		ScanListData(info);
	}
}
// -------------------------------------------------------------------------
//	$Log: globalinfo.h,v $
//	Revision 1.7  2006/04/05 07:49:59  xulingjiao
//	�޸�BUG 24916 .
//	
//	Revision 1.6  2006/04/05 04:53:20  xulingjiao
//	��ע
//	
//	Revision 1.5  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.4  2006/02/22 01:13:58  xulingjiao
//	�޸��޶���BUG,rtfreader����������ת����BUG,��������
//	
//	Revision 1.3  2006/01/22 02:33:34  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	
#endif /* __MSO_IO_RTF_WRITER_GLOBALINFO_H__ */
