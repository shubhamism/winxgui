/* -------------------------------------------------------------------------
//	�ļ���		��	sepx.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:57:59
//	��������	��	
//
//	$Id: sepx.h,v 1.5 2006/09/20 01:54:04 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __SEPX_H__
#define __SEPX_H__
#include "sepxhelper.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWGlobalInfo;
class RtfDirectWriter;
class RtfWSepxWriter
{
public:
	RtfWSepxWriter();
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, RtfWGlobalInfo* info, const KDWSprmList* sprms);	
	STDMETHODIMP_(RtfWSectionPr&) GetSep();
private:
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const RtfWSectionPr* p, RtfWGlobalInfo* info, const RtfWSectionPr* d = GetDefaultSepx());
private:
	RtfWSectionPr prop;
};
// -------------------------------------------------------------------------
//	$Log: sepx.h,v $
//	Revision 1.5  2006/09/20 01:54:04  xulingjiao
//	29237,29017
//	
//	Revision 1.4  2006/09/05 07:20:55  xulingjiao
//	�޸�28793
//	
//	Revision 1.3  2006/02/22 01:13:58  xulingjiao
//	�޸��޶���BUG,rtfreader����������ת����BUG,��������
//	
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:02  xulingjiao
//	*** empty log message ***
//	

#endif /* __SEPX_H__ */
