/* -------------------------------------------------------------------------
//	�ļ���		��	office_document.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 16:52:23
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_document.h"

#include <doctarget.h>

#include <bookmark/bookmarkconnect.h>
// #include <comment/commentconnect.h> new_annotation
#include <field/hyperlinkconnect.h>

#include "comment/office_annotation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KOfficeDocHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case office_body:
		m_bodyElement.Init(m_pDocTarget);
		*ppHandler = &m_bodyElement;
		break;
	case office_styles:
		m_stylesElement.Init(m_pDocTarget);
		*ppHandler = &m_stylesElement;
		break;
	case office_users:
		m_usersElement.Init(m_pDocTarget);
		*ppHandler = &m_usersElement;
		break;
	case office_hyperlinks:
		{
		KHyperlinkConnection* pConnect = m_pDocTarget->GetHyperlinkConnection();
		return pConnect ? pConnect->CreateHyperlinkHandler(ppHandler) : IO_E_IGNORE;
		}
		break;
	case office_meta:
		m_metaElement.Init(m_pDocTarget);
		*ppHandler = &m_metaElement;
		break;
	case office_mediums:
		m_mediumElement.Init(m_pDocTarget);
		*ppHandler = &m_mediumElement;
		break;
	case office_changes:
		return IO_E_IGNORE;
	case office_bookmarks:
		{
		KBookmarkConnection* pConnect = m_pDocTarget->GetBookmarkConnection();
		return pConnect ? pConnect->CreateBookmarksHandler(ppHandler) : IO_E_IGNORE;
		}
	case office_annotations:
		{
			typedef KDWCollectionHandler<KOfficeAnnotationHandler, office_annotation>
				KOfficeAnnotationsHandler;

			KOfficeAnnotationsHandler* pHandler = DW_NEWHANDLER(KOfficeAnnotationsHandler);
			pHandler->Init(m_pDocTarget);
			*ppHandler = pHandler;
			break;
		}
	case office_docprot:
		{
		m_protdocElem.Init(m_pDocTarget);
		*ppHandler = &m_protdocElem;
		break;
		}
	case draw_canvas:
		{
		m_CanvasElement.Init(m_pDocTarget);
		*ppHandler = &m_CanvasElement;
		break;
		}
	case office_macro:
		{
			m_MacroElement.Init(m_pDocTarget);
			*ppHandler = &m_MacroElement;
		}
		break;

	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
