/* -------------------------------------------------------------------------
//	�ļ���		��	docwriter.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-3-30 16:25:02
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DOCWRITER_H__
#define __DOCWRITER_H__

#ifndef __KSO_IO_SCHEMA_DBG_H__
#include <kso/io/schema_dbg.h>
#endif

#ifndef __DOCTARGET_H__
#include <doctarget.h>
#endif

#ifndef __OFFICE_DOCUMENT_H__
#include "core/office_document.h"
#endif


// -------------------------------------------------------------------------
class __novtable KDocWriter :
	public KElementDispatcher,
	public IKFilterMediaInit,
	public KComObjectRoot
{
protected:
	KOfficeDocHandler m_docHandler;
	KDWDocTarget m_target;
	IStorage* m_pRootStg;
	IKFilterEventNotify* m_pNotify;
	DWFileType m_FileType;
	
public:
	KDocWriter() : m_pRootStg(NULL), m_pNotify(NULL) {}
	~KDocWriter()
	{
		KS_RELEASE(m_pNotify);
		ASSERT(m_pRootStg == NULL);
		if (m_pRootStg)
			m_pRootStg->Release();
	}
	STDMETHODIMP Init(
		IN IKFilterEventNotify* pNotify, 
		IN DWFileType FileType = dwFileDefault)
	{
		KS_ASSIGN(m_pNotify, pNotify);
		m_FileType = FileType;
		return S_OK;
	}
	STDMETHODIMP StartDocument(
		IN UINT nReservedParam)
	{
		_kso_InitIoSchemaDbgInfo();
		
		m_docHandler.Init(&m_target);
		KElementDispatcher::Init(office_document, &m_docHandler);

		KDWSecurityAttributes* pAttr = NULL;
		if (m_pNotify)
		{
			VARIANT var;
			VariantInit(&var);
			if (SUCCEEDED(m_pNotify->OnNotify(FILTEREVENT_NEED_CRYPTINFO, 0, &var)))
			{
				if (var.vt == VT_I4)
					pAttr = (KDWSecurityAttributes*)var.lVal;
			}
			VariantClear(&var);

			if (m_pRootStg &&
				SUCCEEDED(
					m_pNotify->OnNotify(
					FILTEREVENT_NEED_DOCUMENT_CLSID, 0, &var
				)))
			{
				if (var.vt == VT_I4)
				{
					if (m_pRootStg)
						m_pRootStg->SetClass(*((const CLSID*)var.lVal));
				}
			}
		}
		return m_target.NewDocument(m_pRootStg, pAttr, m_FileType, m_pNotify);
	}

    STDMETHODIMP EndDocument(
		IN BOOL fAbort)
	{
		m_target.Close(fAbort);

		if (m_pRootStg && m_pNotify)
		{
			VARIANT var;
			if (SUCCEEDED(m_pNotify->OnNotify(FILTEREVENT_NEED_MACRO, 0, &var)) &&
				var.vt == VT_UNKNOWN && var.punkVal)
			{
				IStorage* pMacroStg = (IStorage*)var.punkVal;

				DWORD dwMode = STGM_READWRITE|STGM_SHARE_EXCLUSIVE|STGM_CREATE;

				ks_stdptr<IStorage> spDesStg;
				m_pRootStg->CreateStorage(__X("Macros"), dwMode, 0, 0, &spDesStg);

				if (spDesStg)
					pMacroStg->CopyTo(0, NULL, NULL, spDesStg);

				pMacroStg->Release();
			}
		}
		if (m_pRootStg)
		{
			int ref = m_pRootStg->Release();
			m_pRootStg = NULL;
		}
		return S_OK;
	}
	
	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		if (pMedium == NULL)
			return (E_INVALIDARG);
		
		if (m_pRootStg != NULL)
			return (E_ACCESSDENIED);
		
		return _kso_CreateStorageFromMedium(pMedium, &m_pRootStg);
	}
	
	BEGIN_QUERYINTERFACE(IKContentHandler)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_COUNT(KDocWriter)
};

// -------------------------------------------------------------------------
	
#endif /* __DOCWRITER_H__ */
