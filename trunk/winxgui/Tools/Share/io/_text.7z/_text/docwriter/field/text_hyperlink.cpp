/* -------------------------------------------------------------------------
//	�ļ���		��	text_hyperlink.cpp
//	������		��	����
//	����ʱ��	��	2004-8-23 20:29:06
//	��������	��	
//	$Id: text_hyperlink.cpp,v 1.7 2005/05/28 06:58:48 rongjianxing Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_hyperlink.h"

#include <doctarget.h>
#include "hyperlinkconnect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

inline
ks_wstring FieldParam(ks_wstring strParam)
{
	ks_wstring strResult;
	
	if (strParam.find_first_of(__X(" \t\r\n\x13\x14\x15\0")) == ks_wstring::npos ||
		(strParam[UINT(0)] == '\"' && strParam[strParam.length() - 1] == '\"'))
	{
		strResult = strParam;
	}
	else
	{
		strResult += '\"';
		strResult += strParam;
		strResult += '\"';
	}

	return strResult;
}

// -------------------------------------------------------------------------
STDMETHODIMP KOfficeHyperlinkHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	if (pAttrs)
	{
		ks_wstring strBookmark;
		ks_wstring strHref;
		ks_wstring strToolTip;
		ks_wstring strTargetFrame;

		ATTRVALUE_PTR pVar = NULL;
		if (pAttrs->GetIndex(office_tooltip, &pVar) >= 0)
			strToolTip = FieldParam(pVar->bstrVal);
		if (pAttrs->GetIndex(office_localref, &pVar) >= 0)
			strBookmark = FieldParam(pVar->bstrVal);
		if (pAttrs->GetIndex(office_href, &pVar) >= 0)
			strHref = FieldParam(pVar->bstrVal);
		if (pAttrs->GetIndex(office_target_frame, &pVar) >= 0)
			strTargetFrame = FieldParam(pVar->bstrVal);

		return m_pDocTarget->GetHyperlinkConnection()->AddHyperlink(
			strHref.c_str(), strBookmark.c_str(), strTargetFrame.c_str(),
			strToolTip.c_str(), NULL, NULL);
	}
	ASSERT_ONCE(0);
	return S_FALSE;
}

// -------------------------------------------------------------------------
