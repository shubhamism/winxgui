/* -------------------------------------------------------------------------
//	�ļ���		��	attrframe.cpp
//	������		��	����
//	����ʱ��	��	2004-9-21 20:10:37
//	��������	��	
//	$Id: attrframe.cpp,v 1.11 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attrframe.h"

#include <attr/attrinfo.h>
#include <attr/stocktrans.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
using namespace kso_text;
using namespace DWAttrOp;

// -------------------------------------------------------------------------
// trans
static
STDMETHODIMP AttrFrameHeight(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
#pragma pack(1)
	struct _KDWFrameHeight
	{
		INT16 dyaHeight		:15;
		INT16 fMinHeight	:1;
	};
#pragma pack()

	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	KROAttributes* pAttrHeight = (KROAttributes*)pAttrVal->punkVal;
	if (!pAttrHeight)
		return S_OK;

	if (pAttrHeight)
	{
		_KDWFrameHeight data;
		ZeroStruct(data);
		USHORT val;
		if (SUCCEEDED(pAttrHeight->GetByID(kso::text_frame_height_fixed, &val)))
		{
			STATIC_ASSERT(sizeof(data) == sizeof(val));
			memcpy(&data, &val, sizeof(USHORT));
		}
		else if (SUCCEEDED(pAttrHeight->GetByID(kso::text_frame_height_at_least, &val)))
		{
			data.fMinHeight = 1;
			data.dyaHeight = val;
		}
		pBuf->ForceAddPropFix(sprmOp, *(INT32*)&data);
	}
	return S_OK;
}

static
STDMETHODIMP AttrFrameWidth(
							 IN UINT16 sprmOp,
							 IN KDWDocTarget* pTarget,
							 IN ATTRVALUE_PTR pAttrVal,
							 IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	KROAttributes* pAttrHeight = (KROAttributes*)pAttrVal->punkVal;
	if (!pAttrHeight)
		return S_OK;
	
	if (pAttrHeight)
	{
		INT val;
		if (SUCCEEDED(pAttrHeight->GetByID(kso::text_frame_width_fixed, &val)))
		{
			pBuf->ForceAddPropFix(sprmOp, val);
			//AttrTransFixDefault(sprmOp, pTarget, pAttrVal, pBuf);
		}
		else if (SUCCEEDED(pAttrHeight->GetByID(kso::text_frame_width_at_least, &val)))
		{
			ASSERT(val == 0);
			// do not save sprm
		}
	}
	return S_OK;
}

static
STDMETHODIMP AttrTransPPc(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	if (!pAttrVal->punkVal)
		return S_OK;
	KROAttributes* pAttr = (KROAttributes*)pAttrVal->punkVal;

	INT HoriRel = 0;
	INT VertRel = 0;
	pAttr->GetByID(kso::text_frame_hori_relative_to, &HoriRel);
	pAttr->GetByID(kso::text_frame_vert_relative_to, &VertRel);

	pBuf->ForceAddPropFix(sprmOp, MAKE_PC(VertRel, HoriRel));

	return S_OK;
}

static
STDMETHODIMP AttrTransWr(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	// word��sprmPWrΪ1ʱ�������Ļ��ƣ�Ϊ0��2ʱ�������Ļ���
	ASSERT(pAttrVal->vt == ATTRVALUE::vtI4);
	if (1 == pAttrVal->lVal)
		pBuf->ForceAddPropFix(sprmOp, kso_text::fpNone);
	else
		pBuf->ForceAddPropFix(sprmOp, kso_text::fpAround);
	return S_OK;
}

static 
STDMETHODIMP AttrDropCap(
	IN KDWDocTarget* pTarget, IN IKAttributes* pAttribute, IN KDWPropBuffer* pPropBuf)
{
#pragma pack(1)
	struct _KDWDropCap
	{
		INT16 t_drop		:3;
		INT16 lines			:5;
		INT16 reserved		:8;
	};
#pragma pack()

	INT nDrop = 0;
	KROAttributes* pAttr = (KROAttributes*)pAttribute;
	if (SUCCEEDED(pAttr->GetByID(kso::text_drop_type, &nDrop)))
	{
		_KDWDropCap data;
		ZeroStruct(data);

		data.t_drop = nDrop;
		data.lines = 1;

		INT nLines;
		if (SUCCEEDED(pAttr->GetByID(kso::text_drop_lines, &nLines)) &&
			nLines > 0)
		{
			data.lines = nLines;
		}

		pPropBuf->ForceAddPropFix(sprmPDcs, *(INT32*)&data);
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// schema
BEGIN_ATTR(text_frame_width)
	SIM_ATTR(text_frame_width_fixed,	sprmPDxaWidth,		AttrTransFixDefault)
END_ATTR(text_frame_width)

BEGIN_ATTR(text_frame_position)
	SIM_ATTR(text_frame_hori_position,		sprmPDxaAbs,		AttrTransFixDefault)
	SIM_ATTR(text_frame_hori_align,			sprmPDxaAbs,		AttrTransFixDefault)
	SIM_ATTR(text_frame_vert_position,		sprmPDyaAbs,		AttrTransFixDefault)
	SIM_ATTR(text_frame_vert_align,			sprmPDyaAbs,		AttrTransFixDefault)
END_ATTR(text_frame_position)

BEGIN_ATTR(text_frame_distance)
	SIM_ATTR(text_frame_distance_hori,		sprmPDxaFromText,	AttrTransFixDefault)
	SIM_ATTR(text_frame_distance_vert,		sprmPDyaFromText,	AttrTransFixDefault)
END_ATTR(text_frame_distance)

BEGIN_ATTR(text_frame)
	// simple attr
	SIM_ATTR(text_frame_wrap,		sprmPWr,			AttrTransWr)
	SIM_ATTR(text_frame_lock,		sprmPFLocked,		AttrTransFixDefault)
	SIM_ATTR(text_frame_height,		sprmPWHeightAbs,	AttrFrameHeight)
	SIM_ATTR(text_frame_width,		sprmPDxaWidth,		AttrFrameWidth)
	// sub attr
	SUB_ATEX(text_frame_position,	sprmPPc,			AttrTransPPc)
	SUB_ATTR(text_frame_distance)
//  SUB_ATTR(text_frame_width)
END_ATTR(text_frame)

// -------------------------------------------------------------------------
STDMETHODIMP TransFrameAttr(
	IN KDWDocTarget* pTarget, IN IKAttributes* pAttr, IN KDWPropBuffer* pPropBuf)
{
	HRESULT hr = E_FAIL;
	hr = ParseAttrInfo(ATTRINFO(text_frame), pTarget, pAttr, pPropBuf);
	KS_CHECK(hr);

	hr = AttrDropCap(pTarget, pAttr, pPropBuf);
	KS_CHECK(hr);

KS_EXIT:
	return hr;
}

// -------------------------------------------------------------------------
