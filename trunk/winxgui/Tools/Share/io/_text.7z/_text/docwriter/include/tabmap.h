/* -------------------------------------------------------------------------
//	�ļ���		��	tabmap.h
//	������		��	����
//	����ʱ��	��	2004-12-23 15:17:04
//	��������	��	
//	$Id: tabmap.h,v 1.1 2004/12/23 08:07:26 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DW_V6TABMAP_H__
#define __DW_V6TABMAP_H__


#ifndef __STL_HASH_MAP_H__
#include <stl/hash_map.h>
#endif

#ifndef __TABSTOP_H__
#include <core/attributes/tabstop/tabstop.h>
#endif

// -------------------------------------------------------------------------
struct __DWLst__
{
	UINT Lst;
	UINT Lvl;
	__DWLst__()
	{
		Lst = 0;
		Lvl = 0;
	}
	__DWLst__(UINT Lst, UINT Lvl)
	{
		this->Lst = Lst;
		this->Lvl = Lvl;
	}
	bool operator < (const __DWLst__& rhs) const
	{
		if (Lst != rhs.Lst)
			return Lst < rhs.Lst;
		else
			return Lvl < rhs.Lvl;
	}
	bool operator == (const __DWLst__& rhs) const
	{
		return Lst == rhs.Lst && Lvl == rhs.Lvl;
	}
};

__STL_TEMPLATE_NULL struct __std::hash<__DWLst__>
{
	size_t operator()(const __DWLst__& rhs) const {
		return rhs.Lst + rhs.Lvl; 
	}
};

// -------------------------------------------------------------------------
class KDWV6TABMap
{
	typedef __std::hash_map<UINT, KDWChgTAB*> STYTABMAP;
	typedef __std::hash_map<__DWLst__, KDWChgTAB*> LSTTABMAP;

public:
	STDMETHODIMP_(VOID) Init(IN KDWAutoFreeAlloc* pAlloc)
	{
		m_pAlloc = pAlloc;
	}
public:
	STDMETHODIMP_(KDWChgTAB*) NewStyleTAB(IN UINT iXmlStyle)
	{
		KDWChgTAB*& pTAB = m_StyleMap[iXmlStyle];
		if (pTAB == NULL)
			pTAB = _MsoNew(m_pAlloc, KDWChgTAB);
		return pTAB;
	}
	STDMETHODIMP_(KDWChgTAB*) NewLstTAB(IN UINT iXmlLst, IN UINT iXmlLvl)
	{
		KDWChgTAB*& pTAB = m_LstMap[__DWLst__(iXmlLst, iXmlLvl)];
		if (pTAB == NULL)
			pTAB = _MsoNew(m_pAlloc, KDWChgTAB);
		return pTAB;
	}
public:
	STDMETHODIMP_(const KDWChgTAB&) LookupStyleTAB(
		IN UINT iXmlStyle) const
	{
		STYTABMAP::const_iterator i = m_StyleMap.find(iXmlStyle);
		if (i != m_StyleMap.end())
			return (*i).second ? *(*i).second : m_nullChgTAB;
		return m_nullChgTAB;
	}
	STDMETHODIMP_(const KDWChgTAB&) LookupLstTAB(
		IN UINT iXmlLst, IN UINT iXmlLvl) const
	{
		LSTTABMAP::const_iterator i = m_LstMap.find(__DWLst__(iXmlLst, iXmlLvl));
		if (i != m_LstMap.end())
			return (*i).second ? *(*i).second : m_nullChgTAB;
		return m_nullChgTAB;
	}

private:
	STYTABMAP m_StyleMap;
	LSTTABMAP m_LstMap;
	KDWAutoFreeAlloc* m_pAlloc;
	KDWChgTAB m_nullChgTAB;
};

// -------------------------------------------------------------------------

#endif /* __TABMAP_H__ */
