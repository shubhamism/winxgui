/* -------------------------------------------------------------------------
//	�ļ���		��	html_fields.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:11:12
//	��������	��	
//
//	$Id: html_fields.cpp,v 1.10 2006/06/29 05:43:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "../html_ranges.h"
#include "html_fields.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HtmlWMainFieldsWriter::~HtmlWMainFieldsWriter()
{
	Clear();
}
STDMETHODIMP HtmlWMainFieldsWriter::Clear()
{
	while(!m_fields.empty())
	{
		HtmlWFieldHandler* handler = m_fields.top();
		m_fields.pop();
		delete handler;
	}	
	return S_OK;
}
HtmlWMainFieldsWriter::HtmlWMainFieldsWriter(HtmlWGlobalInfo* info) : m_ginfo(info)
{
	Reset();
}
STDMETHODIMP_(BOOL) HtmlWMainFieldsWriter::Good() const
{
	return m_ginfo->doc->GetFields(DW_SUBDOC_MAIN) && m_ginfo->doc->GetFields(DW_SUBDOC_MAIN)->Count();
}
STDMETHODIMP_(void) HtmlWMainFieldsWriter::Reset()
{		
	m_enumer = KDWFields::Enumerator(m_ginfo->doc->GetFields(DW_SUBDOC_MAIN));
	Next();
}
STDMETHODIMP HtmlWMainFieldsWriter::Next()
{
	if(FAILED(m_enumer.Next()))
		return E_FAIL;		
	return S_OK;
}
STDMETHODIMP_(UINT) HtmlWMainFieldsWriter::GetCurrentCp() const
{
	return m_enumer.GetCp();
}
STDMETHODIMP_(UINT) HtmlWMainFieldsWriter::GetNextCp() const
{
	return m_enumer.GetNextCp();
}

STDMETHODIMP HtmlWMainFieldsWriter::Write()
{
	HtmlWFieldHandler* handler = NULL;
	m_field = m_enumer.Item();
	switch(m_field.GetMarkType())
	{
	case mso_fldBeginMark:
		handler = m_factory.GetFieldHandler(m_ginfo, m_field.GetFieldType());
		m_fields.push(handler);	
		handler->HandleBeginMark(m_ginfo->ar, &m_field);
		break;
	case mso_fldSeparatorMark:
		GetField()->HandleSeparatorMark(m_ginfo->ar, &m_field);
		break;
	case mso_fldEndMark:
		GetField()->HandleEndMark(m_ginfo->ar, &m_field);
		handler = GetField();
		m_fields.pop();
		delete handler;
		handler = NULL;
		break;
	default:
		ASSERT_ONCE(0);
		break;
	}
	return S_OK;
}

STDMETHODIMP_(HtmlWFieldHandler*) HtmlWMainFieldsWriter::GetField() const
{
	if(m_fields.empty())
		return NULL;
	return m_fields.top();
}	
