// -------------------------------------------------------------------------
// docwriter.cpp : Defines the entry point for the DLL application.
// $Id: docwriter.cpp,v 1.28 2006/11/10 03:32:24 wangdong Exp $

#include "stdafx.h"
#include "l10n.h"
//#include "mso/io/html/writer/htmlwriter.h"

#include "rtf/writer/rtfwriter.h"
#include "html/writer/html_htmlwriter.h"
#include "kso/linklib.h"

#include "wpio_docwriter.h"
// -------------------------------------------------------------------------

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved)
{
	//_XSetBreakAlloc(100);
    return TRUE;
}

// -------------------------------------------------------------------------

EXPORTAPI filterpluginRegister(
							   IN IKFilterPluginRegister* pRegister)
{
	pRegister->Register(
		_IoFormat_MSWORD8,
		_KsoName_MSWORD8,
		FILTER_EXPORT,
		FILTER_TYMED_FILE|FILTER_TYMED_ISTORAGE,
		_KsoExt_MSWORD8,
		_KsoFileFormatDesc_MSWORD8_File);

	pRegister->Register(
		_IoFormat_MSWORD8DOT,
		_KsoName_MSWORD8DOT,
			FILTER_EXPORT,
		FILTER_TYMED_FILE|FILTER_TYMED_ISTORAGE,
		_KsoExt_MSWORD8DOT,
		_KsoFileFormatDesc_MSWORD8DOT_File);

	pRegister->Register(
		_IoFormat_WPSV6,
		_KsoName_WPSV6,
		FILTER_EXPORT,
		FILTER_TYMED_FILE|FILTER_TYMED_ISTORAGE,
		_KsoExt_WPSV6,
		_KsoFileFormatDesc_WPSV6_File);

	pRegister->Register(
		_IoFormat_WPSV6DOT,
		_KsoName_WPSV6DOT,
		FILTER_EXPORT,
		FILTER_TYMED_FILE|FILTER_TYMED_ISTORAGE,
		_KsoExt_WPSV6DOT,
		_KsoFileFormatDesc_WPSV6DOT_File);


#ifdef __DW_REGISTER_RTF_WRITER
	pRegister->Register(
		_IoFormat_RTF,
		_KsoName_Rtf,
		FILTER_EXPORT,
		FILTER_TYMED_FILE,
		_KsoExt_Rtf,
		_KsoFileFormatDesc_Rtf_File);

	pRegister->Register(
		_IoFormat_RTF,
		_KsoName_Rtf,
		FILTER_EXPORT_CLIPBOARD,
		FILTER_TYMED_ISTREAM,
		__X("Rich Text Format"),
		__X("Rich Text Format")
		);
#endif

#ifdef __DW_REGISTER_HTML_WRITER
		pRegister->Register(
			_IoFormat_HTML,
			_KsoName_HTML,
			FILTER_EXPORT_CLIPBOARD,
			FILTER_TYMED_ISTREAM,
			_KsoClipboardExts_HTML,
			_KsoClipboardDesc_HTML
			);	
	if (!_kso_QueryFeatureState(kaf_kso_PromptWhenLosingWPSFeature))
	{
		pRegister->Register(
			_IoFormat_HTML,
			_KsoName_HTML,
			FILTER_EXPORT,
			FILTER_TYMED_FILE,
			_KsoExt_HTML,
			_KsoFileFormatDesc_HTML_File
			);
	}
#endif


	return S_OK;
}

EXPORTAPI filterpluginExportCreate(
							 IN long lFormat,
							 IN IKFilterEventNotify* pNotify,
							 OUT IKFilterMediaInit** ppv)
{
	DWFileType FileType = dwFileDefault;
	switch (lFormat)
	{
	case _IoFormat_MSWORD8:
		FileType = dwFileMSWORD8;
		break;
	case _IoFormat_MSWORD8DOT:
		FileType = dwFileMSWORD8DOT;
		break;
	case _IoFormat_WPSV6:
		FileType = dwFileWPSV6;
		break;
	case _IoFormat_WPSV6DOT:
		FileType = dwFileWPSV6DOT;
		break;
	case _IoFormat_RTF:
		FileType = dwFileRTF;
		break;
	case _IoFormat_HTML:
		FileType = dwFileHTML;
	}

	switch (lFormat)
	{
	case _IoFormat_MSWORD8:
	case _IoFormat_MSWORD8DOT:
	case _IoFormat_WPSV6:
	case _IoFormat_WPSV6DOT:
		{
			KCountObject<KDocWriter>* pObj = new KCountObject<KDocWriter>;
			pObj->Init(pNotify, FileType);
			*ppv = pObj;
		}
		break;
	case _IoFormat_RTF:
		{
			KCountObject<KRtfWriter>* pObj = new KCountObject<KRtfWriter>;
			pObj->Init(FileType);
			*ppv = pObj;
		}
		break;
	case _IoFormat_HTML:
		{			
			KCountObject<KHtmlWriter>* pObj = new KCountObject<KHtmlWriter>;			
			pObj->Init(FileType);			
			*ppv = pObj;
		}
		break;
	case _IoFormat_WPIO:
		{
			KCountObjectPtr<KWpioDocWirter> spObj(create_instance);
			spObj->Init(pNotify, FileType);
			*ppv = spObj.detach();
			break;
		}
	default:
		REPORT(__X("Unknown Export Filter!\n"));
		*ppv = NULL;
		return E_UNEXPECTED;
	}
	return S_OK;
}


EXPORTAPI filterpluginExportCreateParameter(
							 IN long lFormat,
							 IN IKFilterEventNotify* pNotify,
							 OUT IKFilterMediaInit** ppv,
							 IN void* parameter)
{
	DWFileType FileType = dwFileDefault;
	switch (lFormat)
	{
	case _IoFormat_MSWORD8:
		FileType = dwFileMSWORD8;
		break;
	case _IoFormat_MSWORD8DOT:
		FileType = dwFileMSWORD8DOT;
		break;
	case _IoFormat_WPSV6:
		FileType = dwFileWPSV6;
		break;
	case _IoFormat_WPSV6DOT:
		FileType = dwFileWPSV6DOT;
		break;
	case _IoFormat_RTF:
		FileType = dwFileRTF;
		break;
	case _IoFormat_HTML:
		FileType = dwFileHTML;
	}

	switch (lFormat)
	{
	case _IoFormat_MSWORD8:
	case _IoFormat_MSWORD8DOT:
	case _IoFormat_WPSV6:
	case _IoFormat_WPSV6DOT:
		{
			KCountObject<KDocWriter>* pObj = new KCountObject<KDocWriter>;
			pObj->Init(pNotify, FileType);
			*ppv = pObj;
		}
		break;
	case _IoFormat_RTF:
		{
			KCountObject<KRtfWriter>* pObj = new KCountObject<KRtfWriter>;
			pObj->Init(FileType);
			*ppv = pObj;
		}
		break;
	case _IoFormat_HTML:
		{			
			KCountObject<KHtmlWriter>* pObj = new KCountObject<KHtmlWriter>;
			pObj->Init(FileType);
			pObj->SetDestFile((LPCWSTR)parameter);
			*ppv = pObj;
		}
		break;
	case _IoFormat_WPIO:
		{
			KCountObjectPtr<KWpioDocWirter> spObj(create_instance);
			spObj->Init(pNotify, FileType);
			*ppv = spObj.detach();
			break;
		}
	default:
		REPORT(__X("Unknown Export Filter!\n"));
		*ppv = NULL;
		return E_UNEXPECTED;
	}
	return S_OK;
}
// -------------------------------------------------------------------------
// $Log: docwriter.cpp,v $
// Revision 1.28  2006/11/10 03:32:24  wangdong
// ��ɾ���̸�ʽ�������ַ�����
//
// Revision 1.27  2006/10/19 03:09:46  wangdong
// �����֧��30959�������ġ�Ӣ�İ�����HTML�ļ���д��
//
// Revision 1.26  2006/06/02 05:15:10  xulingjiao
// *** empty log message ***
//
// Revision 1.25  2006/02/08 09:44:49  wangdong
// ����RTF�����嵼����
//
// Revision 1.24  2006/02/06 02:19:37  xulingjiao
// *** empty log message ***
//
// Revision 1.23  2006/01/20 08:42:54  xulingjiao
// html����BASEԪ��
//
// Revision 1.22  2006/01/18 01:47:32  wangdong
// ������HTML��IStream��֧�֡�
//
// Revision 1.21  2006/01/11 02:47:46  rongjianxing
// wpio�ӵ������С�
//
// Revision 1.20  2006/01/04 03:41:47  xulingjiao
// *** empty log message ***
//
// Revision 1.19  2005/12/12 08:51:35  xulingjiao
// ��������HtmlWriter������
//
// Revision 1.18  2005/08/05 07:15:30  wangdong
// �����˺�����Ƿ�ע��RTFд��
//
