/* -------------------------------------------------------------------------
//	�ļ���		��	office_styles.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-17 10:03:08
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_STYLES_H__
#define __OFFICE_STYLES_H__

#include "doctarget.h"

#ifndef __TEXT_FONT_H__
#include "text_font.h"
#endif

#ifndef __TEXT_LIST_H__
#include "text_list.h"
#endif

#ifndef __OFFICE_PARA_STYLE_H__
#include "office_para_style.h"
#endif

#ifndef __OFFICE_SPAN_STYLE_H__
#include "office_span_style.h"
#endif

#ifndef __DRAW_DEFPROP_H__
#include "draw_defprop.h"
#endif

#ifndef __OFFICE_STYLES_BASE_H__
#include "office_styles_base.h"
#endif

// -------------------------------------------------------------------------
typedef KDWCollectionHandler<KTextListHandler, text_list> KTextListsHandler;

class KOfficeStylesHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextFontsHandler m_fontsElement;
	KTextListsHandler m_listsElement;
	KOfficeSpanStyleHandler m_spanStyleElement;
	KOfficeParaStyleHandler m_paraStyleElement;
	KDefPropHander m_defpropElement;

	KDWStyleInfoMap m_RStyleInfoMap;
	KDWStyleInfoMap m_PStyleInfoMap;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		return S_OK;
	}
	
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);

	STDMETHODIMP EndElement(
		IN ELEMENTID uID);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_STYLES_H__ */
