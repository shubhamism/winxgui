/* -------------------------------------------------------------------------
//	�ļ���		��	plcfpapx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:53:56
//	��������	��	
//
//	$Id: plcfpapx.cpp,v 1.6 2006/08/25 08:21:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "propbasic.h"
#include "plcfpapx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWPapxsWriter::RtfWPapxsWriter(const KDWPlcfPapx* papxs, RtfWGlobalInfo* info) :
	m_papxs(papxs),
	m_ginfo(info),
	m_wrPapx(info),
	m_wrTbl(info, papxs),
	m_current(0)
{
	Reset();
}
STDMETHODIMP_(BOOL) RtfWPapxsWriter::Good() const
{
	return m_papxs != NULL && m_papxs->Count();
}
STDMETHODIMP_(void) RtfWPapxsWriter::Reset()
{
	m_enumer = KDWPlcfPapx::Enumerator(m_papxs);
	Next();
}
STDMETHODIMP RtfWPapxsWriter::Next()
{		
	if (FAILED(m_enumer.Next(&m_current)))
		return E_FAIL;	
	m_wrPapx.SetProp(m_enumer.SrcData());
	return S_OK;
}
STDMETHODIMP_(UINT) RtfWPapxsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.Range().cp;
}
STDMETHODIMP_(UINT) RtfWPapxsWriter::GetNextCp()
{
	return (UINT)m_enumer.Range().cpNext;		
}
STDMETHODIMP_(UINT) RtfWPapxsWriter::GetIstd(UINT cp)
{
	INT idx = m_papxs->GetIndex(cp);

	if (idx < 0)
		return stiNil;

	const KDWPropx* prop = m_papxs->SrcData(idx);

	return GetPapxIstd((const BYTE*)_MsoPdata(prop));
}

STDMETHODIMP_(RtfWPapxWriter&) RtfWPapxsWriter::GetPapInfo()
{
	return m_wrPapx;
}

STDMETHODIMP_(void) RtfWPapxsWriter::Write(RtfDirectWriter* ar)
{
	ar->AddAttribute(rtf_pard);	
	ar->AddAttribute(rtf_plain);
	m_wrPapx.Write(ar);
	m_wrTbl.Write(ar, m_current);
}
