/* -------------------------------------------------------------------------
//	�ļ���		��	html_chpxhelper.h
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:03:48
//	��������	��	
//
//	$Id: html_chpxhelper.h,v 1.7 2006/07/08 02:16:46 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_CHPXHELPER_H__
#define __HTML_CHPXHELPER_H__
#include "mso/propstruct/maskspanpr.h"

struct HtmlWSpanPr : MaskSpanPr
{
	typedef HtmlWSpanPr ThisType;
	typedef MaskSpanPr BaseType;	
	STDMETHODIMP Sprms2SpanPr(IN const KDWSprmList& sprms, 							  
							  IN const HtmlWSpanPr* baseon)
	{	
		return Sprms2MaskSpanPr(sprms, this, baseon);
	}
	STDMETHODIMP Sprms2SpanPr(IN const KDWPropx* prop, 
						      IN const HtmlWSpanPr* baseon)
	{
		return Sprms2MaskSpanPr(prop, this, baseon);
	}
};

inline HtmlWSpanPr* GetDefaultChpx()
{
	static HtmlWSpanPr s_prop;
	static BOOL s_initflag = FALSE;
	if (!s_initflag)
	{
		s_prop.Reset();
		s_initflag = TRUE;
	}
	return &s_prop;
}
#endif /* __HTML_CHPXHELPER_H__ */
