/* -------------------------------------------------------------------------
//	�ļ���		��	testdocwriter.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-14 10:59:35
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTDOCWRITER_H__
#define __TESTDOCWRITER_H__

#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif

#ifndef __KFC_COM_SIMPOBJ_H__
#include <kfc/com/simpobj.h>
#endif

#ifndef __KSO_IO_COMPONENT_H__
#include <kso/io/component.h>
#endif

#ifndef __L10N_H__
#include "l10n.h"
#endif

#include "kso/dircfginfo.h"

// -------------------------------------------------------------------------

STDAPI filterpluginExportCreate(
							   IN long lFormat,
							   IN IKFilterEventNotify* pNotify,
							   OUT IKFilterMediaInit** ppv);

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(void) testDocWriter(
				   IN IKContentSource* pSrc,
				   IN LPCWSTR szDocFile)
{
	ks_stdptr<IKFilterMediaInit> spInit;
	VERIFY_OK(
		filterpluginExportCreate(_IoFormat_MSWORD8, NULL, &spInit));

	VERIFY_OK(
		_kso_FileMediaInit(spInit, szDocFile, STGM_G_CREATE));

	ks_stdptr<IKContentHandler> spAcc;
	VERIFY_OK(
		spInit->QI(IKContentHandler, &spAcc));

	VERIFY_OK(
		pSrc->Transfer(spAcc));
}

// -------------------------------------------------------------------------
// class KConvertXml2Doc

// FnCreateXmlReader
typedef STDMETHODIMP _kso_FnCreateXmlReader(
											IN KsoXmlStdType uXmlType,
											OUT IKContentSource** ppSource
											);
typedef _kso_FnCreateXmlReader* FnCreateXmlReader;

class KConvertXml2Doc
{
private:
	FnCreateXmlReader m_fnCreateXmlReader;
	
public:
	KConvertXml2Doc() : m_fnCreateXmlReader(NULL)
	{
	}

	void convert(
		IN LPCWSTR szXmlFileSrc,
		IN LPCWSTR szDocFileDest)
	{
		printf("\n[loading \"%S\"...]\n", szXmlFileSrc);

		WCHAR szXmlFile[_MAX_PATH];
		WCHAR szDocFile[_MAX_PATH];
		
		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szXmlFile, MAX_PATH);
		wcscat(szXmlFile, __L("/"));
		wcscat(szXmlFile, szXmlFileSrc);

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szDocFile, MAX_PATH);
		wcscat(szDocFile, __L("/"));
		wcscat(szDocFile, szDocFileDest);
		
		if (m_fnCreateXmlReader == NULL)
		{
			HMODULE hLib = LoadLibrary("xmlreader");
			ASSERT(hLib);
			
			m_fnCreateXmlReader = (FnCreateXmlReader)
				GetProcAddress(hLib, "_kso_CreateXmlReader");
			ASSERT(m_fnCreateXmlReader);
		}
		
		ks_stdptr<IKContentSource> spSrc;
		
		VERIFY_OK(
			m_fnCreateXmlReader(kso_xmlWordProcess, &spSrc));
		
		VERIFY_OK(
			_kso_FileMediaInit(spSrc, szXmlFile, STGM_G_READ));
		
		::testDocWriter(spSrc, szDocFile);
	}
};

// -------------------------------------------------------------------------
// class KConvertDoc2Doc

#include "../../include/ioacceptor/ioacceptor.h"
#include "../../include/ioacceptor/iowrapper2.h"

typedef STDMETHODIMP _FnInitialize();
typedef STDMETHODIMP _FnTermiate();
typedef STDMETHODIMP _FnCreateSource(LPCWSTR, BOOL, IIOSource**);
typedef _FnInitialize* FnInitialize;
typedef _FnTermiate* FnTermiate;
typedef _FnCreateSource* FnCreateSource;

inline
STDMETHODIMP testTranslate(IIOSource* pSrc, IKContentHandler* pAcc)
{
	KCountObjectPtr<KAcceptorAdapter> ptrAcceptorAdapter(create_instance);
	ptrAcceptorAdapter->Init(pAcc);
	
	ptrAcceptorAdapter->StartDocument();
	HRESULT hr =
		pSrc->Translate(ptrAcceptorAdapter);
	ptrAcceptorAdapter->EndDocument();
	return hr;
}

class KConvertDoc2Doc
{
private:
	HMODULE m_hLib;
	FnCreateSource m_fnCreateSource;
	FnTermiate m_fnTerm;

public:
	KConvertDoc2Doc() : m_fnCreateSource(NULL), m_fnTerm(NULL), m_hLib(NULL)
	{
	}
	~KConvertDoc2Doc()
	{
		term();
	}
	
	void term()
	{
		if (m_fnTerm)
		{
			m_fnTerm();
			m_fnTerm = NULL;
			m_fnCreateSource = NULL;
		}
		if (m_hLib)
		{
			FreeLibrary(m_hLib);
			m_hLib = NULL;
		}
	}

	void convert(
		IN LPCWSTR szDocFileSrc,
		IN LPCWSTR szDocFileDest)
	{
		printf("\n[loading \"%S\"...]\n", szDocFileSrc);
		WCHAR szSrcFile[_MAX_PATH];
		WCHAR szDocFile[_MAX_PATH];
		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szSrcFile, MAX_PATH);
		wcscat(szSrcFile, __L("/"));
		wcscat(szSrcFile, szDocFileSrc);

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szDocFile, MAX_PATH);
		wcscat(szDocFile, __L("/"));
		wcscat(szDocFile, szDocFileDest);

		convertFile(szSrcFile, szDocFile);
	}

	HRESULT convertFile(
		IN LPCWSTR szSrcFile,
		IN LPCWSTR szDocFile)
	{
		HRESULT hr = E_FAIL;
		if (m_fnCreateSource == NULL)
		{
			m_hLib = LoadLibrary("docreader");
			KS_CHECK_BOOL(m_hLib);

			FnInitialize fnInit = (FnInitialize)GetProcAddress(m_hLib, "_dr_Initialize");
			KS_CHECK_BOOL(fnInit);

			hr = fnInit();
			KS_CHECK(hr);
			
			m_fnCreateSource = (FnCreateSource)GetProcAddress(m_hLib, "CreateSource2");
			KS_CHECK_BOOLEX(m_fnCreateSource, hr = E_FAIL);

			m_fnTerm = (FnTermiate)GetProcAddress(m_hLib, "_dr_Terminate");
		}
		{
			ks_stdptr<IIOSource> spSrc;
			
			hr = m_fnCreateSource(szSrcFile, TRUE, &spSrc);
			KS_CHECK(hr);
			
			ks_stdptr<IKFilterMediaInit> spInit;
			hr = filterpluginExportCreate(_IoFormat_MSWORD8, NULL, &spInit);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInit, szDocFile, STGM_G_CREATE);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentHandler> spAcc;
			hr = spInit->QI(IKContentHandler, &spAcc);
			KS_CHECK(hr);

			return testTranslate(spSrc, spAcc);
		}
KS_EXIT:
		return hr;
	}
};

// -------------------------------------------------------------------------

KComModule _Module;

EXPORTAPI testConvert(
					  IN LPCSTR szDocFileSrc,
					  IN LPCSTR szDocFileDest)
{
	USES_CONVERSION;
	KConvertDoc2Doc cnv;
	return cnv.convertFile(A2W(szDocFileSrc), A2W(szDocFileDest));
}

// -------------------------------------------------------------------------

#endif /* __TESTDOCWRITER_H__ */
