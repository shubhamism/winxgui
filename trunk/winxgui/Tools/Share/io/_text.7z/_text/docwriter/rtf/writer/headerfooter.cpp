/* -------------------------------------------------------------------------
//	�ļ���		��	headerfooter.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:02:25
//	��������	��	
//
//	$Id: headerfooter.cpp,v 1.5 2006/09/07 07:07:10 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "textstream.h"
#include "headerfooter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWHeaderFooterWriter::RtfWHeaderFooterWriter() : m_wrTextStream(NULL)
{
}
STDMETHODIMP_(void) RtfWHeaderFooterWriter::SetStreamWriter(RtfWTextStreamWriter* wrTextStream)
{
	ASSERT(wrTextStream);
	m_wrTextStream = wrTextStream;
}

STDMETHODIMP_(void) RtfWHeaderFooterWriter::Write(RtfDirectWriter* ar, const KDWSection* sect, BOOL fFacingPage, BOOL fTitlePage)
{
	KDWRange rg;
	for (INT hddtype = 0; hddtype <= DW_FIRST_FOOTER; ++hddtype)
	{
		sect->GetHeaderFooter((HEADERFOOTER_TYPE)hddtype, &rg);
		rg.cpNext -= 1; // �ѷָ����^�V��;
		if (rg.cpNext - rg.cp <= 0)
			continue;
		switch(hddtype)
		{
		case DW_EVEN_HEADER:
			if(fFacingPage)
				ar->StartGroup(rtf_headerl);
			else
				continue;
			break;
		case DW_ODD_HEADER:
			if(fFacingPage)
				ar->StartGroup(rtf_headerr);
			else
				ar->StartGroup(rtf_header);
			break;
		case DW_EVEN_FOOTER:
			if(fFacingPage)
				ar->StartGroup(rtf_footerl);
			else
				continue;
			break;
		case DW_ODD_FOOTER:
			if(fFacingPage)
				ar->StartGroup(rtf_footerr);
			else
				ar->StartGroup(rtf_footer);
			break;
		case DW_FIRST_HEADER:
			if(fTitlePage)
				ar->StartGroup(rtf_headerf);
			else
				continue;
			break;
		case DW_FIRST_FOOTER:
			if(fTitlePage)
				ar->StartGroup(rtf_footerf);
			else
				continue;
			break;
		default:
			ASSERT_ONCE(0);
			break;
		}
		m_wrTextStream->Write(ar, rg.cp, rg.cpNext - rg.cp, DW_SUBDOC_HEADERFOOTER);
		ar->EndGroup();
	}
}