/* -------------------------------------------------------------------------
//	�ļ���		��	html_plcfchpx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:07:02
//	��������	��	
//
//	$Id: html_plcfchpx.cpp,v 1.14 2006/09/07 07:07:10 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "../ranges/html_field.h"
#include "../ranges/html_fields.h"
#include "../html_ranges.h"
#include "../html_textstream.h"
#include "html_papx.h"
#include "html_texttable.h"
#include "html_plcfchpx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// gets
STDMETHODIMP_(HtmlWChpxWriter&) HtmlWChpxsWriter::GetChpinfo()
{
	return m_wrChpx;
}
STDMETHODIMP_(CssPropBuffer*) HtmlWChpxsWriter::GetCurrentChpxCssprop()
{
	return &m_cssprop;
}
HtmlWChpxsWriter::HtmlWChpxsWriter(
	const KDWPlcfChpx* chpxs, HtmlWGlobalInfo* info) :
	m_chpxs(chpxs),
	m_ginfo(info),
	m_wrChpx(info),
	m_istdpara(stiNil),
	m_fOpend(FALSE)
{
	Reset();
}
STDMETHODIMP_(BOOL) HtmlWChpxsWriter::Good() const
{
	return m_chpxs != NULL && m_chpxs->Count();
}
STDMETHODIMP_(void) HtmlWChpxsWriter::Reset()
{
	m_enumer = KDWPlcfChpx::Enumerator(m_chpxs);
	Next();
}
STDMETHODIMP HtmlWChpxsWriter::Next()
{
	if (FAILED(m_enumer.Next(&m_current)))	
	{
		m_wrChpx.SetProp(NULL);
		return E_FAIL;
	}
	m_wrChpx.SetProp(m_enumer.SrcData(), m_istdpara);
	return S_OK;
}	
STDMETHODIMP_(UINT) HtmlWChpxsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.Range().cp;
}
STDMETHODIMP_(UINT) HtmlWChpxsWriter::GetNextCp()
{
	return (UINT)m_enumer.Range().cpNext;
}
STDMETHODIMP_(void) HtmlWChpxsWriter::SetIstdPara(INT istdpara)
{
	m_istdpara = istdpara;
}

STDMETHODIMP_(void) HtmlWChpxsWriter::EnsureWriteEnd()
{
	EnsureWriteEndTag(m_fOpend, m_ginfo->ar, elem_span);
}

STDMETHODIMP_(void) HtmlWChpxsWriter::Write(UINT SpecText)
{	
	HtmlWRangesWriter* range = m_ginfo->htmlwrStream->GetRange();
	m_cssprop.Clear();
	m_wrChpx.ToCss(&m_cssprop, "; ");
	EnsureWriteEnd();
	if(!m_wrChpx.GetChp().fSpec)
	{		
		switch(SpecText)
		{
		// �����д���
		case FIELD_BEGIN:
		case FIELD_END:
			return;
		// ����
		case FIELD_SEP:
		default:
			if ( !(range->GetPapInfo().GetPap().fInTable) )
			{
				WriteStartTag(m_fOpend, m_ginfo->ar, elem_span);
				m_wrChpx.Write(&m_cssprop);
			}
			else
			{
			}
			break;
		}
	}
	else
	{
		//@todo
	}
}