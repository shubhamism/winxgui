/* -------------------------------------------------------------------------
//	�ļ���		��	office_meta.h
//	������		��	����
//	����ʱ��	��	2004-8-24 15:06:01
//	��������	��	
//	$Id: office_meta.h,v 1.5 2004/11/26 04:12:20 wanli Exp $
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_META_H__
#define __OFFICE_META_H__

#include "kso/summary/summary_stgwrite.h"

// -------------------------------------------------------------------------
class KOfficeMetaHandler : public KFakeUnknown<KElementHandler>, public KKSOWriteMetaHandler
{
	KDWDocTarget* m_pDocTarget;
public:
	STDMETHODIMP_(VOID) Init(IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);

	STDMETHODIMP EndElement(IN ELEMENTID uElementID);

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		if (ppHandler)
		{
			*ppHandler = this;
			(*ppHandler)->AddRef();
		}
		return S_OK;
	}

	IPropertySetStorage* GetPropertySetStorage();
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_META_H__ */
