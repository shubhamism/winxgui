/* -------------------------------------------------------------------------
//	�ļ���		��	html_sepxhelper.h
//	������		��	���὿
//	����ʱ��	��	2006-7-12 15:54:11
//	��������	��	
//
//	$Id: html_sepxhelper.h,v 1.1 2006/07/13 02:51:29 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_SEPXHELPER_H__
#define __HTML_SEPXHELPER_H__
#include "mso/propstruct/masksectpr.h"
struct HtmlWSectionPr : MaskSectionPr
{
	typedef HtmlWSectionPr ThisType;
	typedef MaskSectionPr BaseType;	
	STDMETHODIMP Sprms2SectionPr(IN const KDWSprmList* sprms)
	{
		return Sprms2MaskSectionPr(sprms, this);
	}	
	STDMETHODIMP Sprms2SectionPr(IN const KDWPropx* prop)
	{	
		return Sprms2MaskSectionPr(prop, this);
	}
};

inline HtmlWSectionPr* GetDefaultSepx()
{
	static HtmlWSectionPr s_prop;
	static BOOL s_initflag = FALSE;
	if (!s_initflag)
	{
		s_prop.Reset();	
		s_initflag = TRUE;
	}
	return &s_prop;
}
#endif /* __HTML_SEPXHELPER_H__ */
