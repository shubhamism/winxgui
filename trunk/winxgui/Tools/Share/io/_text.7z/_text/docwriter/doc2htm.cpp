/* -------------------------------------------------------------------------
//	�ļ���		��	doc2htm.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-17 10:08:21
//	��������	��	
//
//	$Id: doc2htm.cpp,v 1.2 2006/07/05 08:27:40 xulingjiao Exp $
/ -----------------------------------------------------------------------*/
#include "stdafx.h"
#include <kfc.h>
#include <kso/io/contenthandler.h>
#include "testcase/testdoc2html.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(void) GetFname(LPWSTR szFname, LPCWSTR szFileName)
{
	WCHAR szExt[_MAX_EXT];
	_wsplitpath(szFileName, NULL, NULL, szFname, szExt);
	wcscat(szFname, szExt);
}

STDMETHODIMP_(void) GetDir(LPWSTR szDir, LPCWSTR szFileName)
{
	WCHAR szDrive[_MAX_PATH];
	_wsplitpath(szFileName, szDir, szDrive, NULL, NULL);
	wcscat(szDir, szDrive);
}

STDMETHODIMP_(void) GetDestFname(LPWSTR szDestFname, LPCWSTR szSrcFname, LPCWSTR szDestDir = __X(""))
{	
	WCHAR szFname[_MAX_PATH];
	GetFname(szFname, szSrcFname);
	wcscpy(szDestFname, szDestDir);
	wcscat(szDestFname, szFname);
	wcscat(szDestFname, __X(".htm"));
}

int main()
{
	if (__argc < 2)
		return -1;
	
	WCHAR szSrcFile[MAX_PATH] = __X("");
	for(INT i=1; i<__argc; ++i)
	{
		wcscat(szSrcFile, __wargv[i]);
		if(i != __argc-1)
			wcscat(szSrcFile, __X(" "));
	}

	WCHAR szDestFile[_MAX_PATH];
	WCHAR szDestdir[_MAX_PATH];
	GetDir(szDestdir, szSrcFile);

	GetDestFname(szDestFile, szSrcFile, szDestdir);

	printf("processing %S ... ", szSrcFile);
	
	HRESULT hr = E_FAIL;
	try
	{
		KConvertDoc2Html doc2htm;
		hr = doc2htm.convertFile(szSrcFile, szDestFile);
	}
	catch (...)
	{
	}

	if (FAILED(hr))
		printf("failed!\n");
	else
		printf("ok!\n");

	return 0;
}
// -------------------------------------------------------------------------
//	$Log: doc2htm.cpp,v $
//	Revision 1.2  2006/07/05 08:27:40  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.1  2006/01/17 06:10:51  xulingjiao
//	*** empty log message ***
//	
