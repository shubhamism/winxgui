/* -------------------------------------------------------------------------
//	�ļ���		��	paraattr.cpp
//	������		��	����
//	����ʱ��	��	2004-8-16 20:32:40
//	��������	��	
//	$Id: paraattr.cpp,v 1.32 2006/07/31 07:00:03 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "attrtrans.h"
#include "stocktrans.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
using namespace kso_text;
using namespace DWAttrOp;

// -------------------------------------------------------------------------
STDMETHODIMP AttrTransLineSpacing(
	IN UINT16 sprmOp,
	IN KDWDocTarget* pTarget,
	IN ATTRVALUE_PTR pAttrVal,
	IN KDWPropBuffer* pBuf)
{
	ASSERT(pAttrVal->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrVal->punkVal;
	ASSERT(pAttr);

	LSPD lspd;
	ZeroStruct(lspd);

	ATTRVALUE_PTR pVal(NULL);
	UINT uType = kso_text::lstAtLeast;
	if (pAttr->GetIndex(kso::text_line_spacing_type, &pVal) != -1)
		uType = pVal->lVal;
	if (pAttr->GetIndex(kso::text_line_spacing_value, &pVal) != -1)
	{
		switch(uType)
		{
		case kso_text::lstMultiLine:
			lspd.fMultLinespace = TRUE;
			lspd.dyaLine = ::MulDiv(pVal->lVal, 240, 10000);			
			break;
		default:
			ASSERT_ONCE(0);
		case kso_text::lstFixed:
			lspd.fMultLinespace = FALSE;
			lspd.dyaLine = -pVal->lVal;
			break;
		case kso_text::lstAtLeast:
			lspd.fMultLinespace = FALSE;
			lspd.dyaLine = pVal->lVal;
			break;
		}
	}
	else
	{
		ASSERT_ONCE(0);
		return S_FALSE;
	}
	pBuf->ForceAddPropFix(sprmOp, *(INT32*)&lspd);
	return S_OK;
}

// -------------------------------------------------------------------------
template<
	class OpType = DWAttrOp::Noop, 
	class OpType2 = DWAttrOp::Noop, 
	class OpType2Ex = OpType2, 
	UINT16 sprmOp2 = __nilsprm, 
	UINT16 sprmOp2Ex = __nilsprm>
struct AttrTransTri
{
	static STDMETHODIMP AddFix(
		IN UINT16 sprmOp,
		IN KDWDocTarget* pTarget, 
		IN ATTRVALUE_PTR pAttrVal,
		IN KDWPropBuffer* pBuf)
	{
		ASSERT(pBuf);
		try{
			try{
				if (sprmOp2 != __nilsprm)
				{
					pBuf->ForceAddPropFix(sprmOp2, OpType2::eval(pAttrVal->lVal));
				}
				pBuf->ForceAddPropFix(sprmOp, OpType::eval(pAttrVal->lVal));
				if (sprmOp2Ex != __nilsprm)
				{
					pBuf->ForceAddPropFix(sprmOp2Ex, OpType2Ex::eval(pAttrVal->lVal));
				}
			}
			catch (EAttrUnhandle const&) {
				return IO_S_ATTR_UNHANDLE;
			}
		}
		catch(EAttrIgnore const&)
		{
			return S_FALSE;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
template<INT secondsprm>
struct AttrRelDual
{
	static 
	STDMETHODIMP AddFix(
		  IN UINT16 sprmOp,
		  IN KDWDocTarget* pTarget,
		  IN ATTRVALUE_PTR pAttrVal,
		  IN KDWPropBuffer* pBuf)
	{
		pBuf->ForceAddPropFix(sprmOp, pAttrVal->lVal);
		pBuf->ForceAddPropFix(secondsprm, 0);
		return S_OK;
	}
};

// -------------------------------------------------------------------------
const INT TWIPSPERCHAR = 210;
const INT TWIPSPERLINE = 312;

typedef Div<100> OpPercent;
typedef Mul_Div<TWIPSPERCHAR, 10000> OpParaChar;
typedef Mul_Div<TWIPSPERLINE, 10000> OpParaLine;

#define AttrTransCharPencentEx(_sec, _secex)	AttrTransTri< Div<100>, , Mul_Div<TWIPSPERCHAR, 10000>, _sec, _secex >::AddFix
#define AttrTransLinePencentEx(_sec)			AttrTransTri< Div<100>, Mul_Div<TWIPSPERLINE, 10000>, Mul_Div<TWIPSPERLINE, 10000>, _sec, __nilsprm >::AddFix

// -------------------------------------------------------------------------
STDMETHODIMP TransParaIndent(IN IKAttributes* pAttrRoot, 
							 IN KDWPropBuffer* pBuf)
{
	ATTRVALUE_PTR pAttrList = 0;
	if (pAttrRoot->GetIndex(text_p_indent, &pAttrList) == -1)
		return S_OK;

	ASSERT(pAttrList->vt == ATTRVALUE::vtAttrList);
	IKAttributes* pAttr = (IKAttributes*)pAttrList->punkVal;
	ASSERT(pAttr);

	int nFirstIndent = 0;

	ATTRVALUE_PTR pVal(NULL);
	if (pAttr->GetIndex(text_p_first_line_relative, &pVal) != -1)
		nFirstIndent = OpParaChar::eval(pVal->lVal);
	if (pAttr->GetIndex(text_p_first_line, &pVal) != -1)
		nFirstIndent = pVal->lVal;

	if (pAttr->GetIndex(text_p_indent_left_relative, &pVal) != -1)
	{
		int nLeftIndent = OpParaChar::eval(pVal->lVal);

		if (nFirstIndent < 0)
			nLeftIndent -= nFirstIndent;

		// why ??? pBuf->AddPropFix(sprmPDxaLeft, nLeftIndent);
		pBuf->AddPropFix(sprmPDxaLeftRel, OpPercent::eval(pVal->lVal));
		// why ??? pBuf->AddPropFix(sprmPDxaLeftEx, nLeftIndent);
	}
	if (pAttr->GetIndex(text_p_indent_left, &pVal) != -1)
	{
		int nLeftIndent = pVal->lVal;
		pBuf->AddPropFix(sprmPDxaLeft, nLeftIndent);
		// why ??? pBuf->ForceAddPropFix(sprmPDxaLeftRel, 0);  // ��ʹ�þ��Է�ʽ����Word�߰汾��Ҫ��Է�ʽд0��
		pBuf->AddPropFix(sprmPDxaLeftEx, nLeftIndent);
	}
	if (pAttr->GetIndex(text_p_first_line_relative, &pVal) != -1)
	{
		// why ??? pBuf->AddPropFix(sprmPDxaLeft1, nFirstIndent);
		pBuf->AddPropFix(sprmPDxaLeft1Rel, OpPercent::eval(pVal->lVal));
		// why ??? pBuf->AddPropFix(sprmPDxaLeft1Ex, nFirstIndent);
	}
	if (pAttr->GetIndex(text_p_first_line, &pVal) != -1)
	{
		pBuf->AddPropFix(sprmPDxaLeft1, nFirstIndent);
		// why ??? pBuf->ForceAddPropFix(sprmPDxaLeft1Rel, 0); // ��ʹ�þ��Է�ʽ����Word�߰汾��Ҫ��Է�ʽд0��
		pBuf->AddPropFix(sprmPDxaLeft1Ex, nFirstIndent);
	}
	if (pAttr->GetIndex(text_p_indent_right_relative, &pVal) != -1)
	{
		int nRightIndent = OpParaChar::eval(pVal->lVal);
		// why ??? pBuf->AddPropFix(sprmPDxaRight, nRightIndent);
		pBuf->AddPropFix(sprmPDxaRightRel, OpPercent::eval(pVal->lVal));
		// why ??? pBuf->AddPropFix(sprmPDxaRightEx, nRightIndent);
	}
	if (pAttr->GetIndex(text_p_indent_right, &pVal) != -1)
	{
		pBuf->AddPropFix(sprmPDxaRight, pVal->lVal);
		// why ??? pBuf->ForceAddPropFix(sprmPDxaRightRel, 0); // ��ʹ�þ��Է�ʽ����Word�߰汾��Ҫ��Է�ʽд0��
		pBuf->AddPropFix(sprmPDxaRightEx, pVal->lVal);
	}
	return S_OK;
}


// -------------------------------------------------------------------------
STDMETHODIMP TransLfo(
	IN KDWDocTarget* pDocTarget,
	IN KROAttributes* pAttr,
	IN KDWPropBuffer* pPropBuf)
{
	KROAttributes* pAttrLst;

	HRESULT hr = pAttr->GetByID(kso::text_list_info, &pAttrLst);
	if (SUCCEEDED(hr))
	{
		HRESULT hrLvl;
		UINT iLevel = -1;
		hrLvl = pAttrLst->GetByID(kso::text_list_level, &iLevel);
		if (SUCCEEDED(hrLvl))
			pPropBuf->AddPropFix(sprmPIlvl, iLevel);
		
		//
		//@@note:
		//	����һ�������м���û���Զ���š�
		//
		UINT uListId;
		hr = pAttrLst->GetByID(kso::text_list_id, &uListId);
		if (SUCCEEDED(hr))
		{
			DWListRestartMode iRestartAt = DWListRestartContinue;
			BOOL fRestart = FALSE;
			pAttrLst->GetByID(kso::text_restart, &fRestart);
			if (fRestart)
			{
				iRestartAt = DWListRestartRestart;
				pAttrLst->GetByID(kso::text_start, &iRestartAt);
				ASSERT(iRestartAt >= kso_lvlRestartAtRestart);
			}

			KDWV6Lists* pLists = pDocTarget->GetListTableV6();
			UINT iLfo = pLists->GetLfoIndex(uListId, iLevel, iRestartAt);
			if (iLfo >= 0)
			{
				if (iLfo == 0 && FAILED(hrLvl))
					pPropBuf->AddPropFix(sprmPIlvl, 0);

				pPropBuf->AddPropFix(sprmPIlfo, iLfo);
			}

			if (fRestart)
			{
				if (pDocTarget->getFeature().writeKsExt())
				{
					INT8 oprand[2] = {kscodePIlvlRestartAt, iRestartAt};
					pPropBuf->AddPropVar(sprmPKSCodeExt, oprand, sizeof(oprand));
				}
			}
		}
		else
		{
			ASSERT_ONCE(0);
			if(FAILED(hrLvl))
				pPropBuf->AddPropFix(sprmPIlvl, 0);
			pPropBuf->AddPropFix(sprmPIlfo, 0);
		}
	}
	return S_OK;
}
// -------------------------------------------------------------------------
BEGIN_ATTR(text_p_borders)
	SIM_ATTREX(text_p_border_top,		sprmPBrcTop,		AttrTransBrc, 
										sprmPBrcExTop,		AttrTransBrcEx)
	SIM_ATTREX(text_p_border_left,		sprmPBrcLeft,		AttrTransBrc, 
										sprmPBrcExLeft,		AttrTransBrcEx)
	SIM_ATTREX(text_p_border_bottom,	sprmPBrcBottom,		AttrTransBrc, 
										sprmPBrcExBottom,	AttrTransBrcEx)
	SIM_ATTREX(text_p_border_right,		sprmPBrcRight,		AttrTransBrc, 
										sprmPBrcExRight,	AttrTransBrcEx)
	SIM_ATTREX(text_p_border_between,	sprmPBrcBetween,	AttrTransBrc, 
										sprmPBrcExBetween,	AttrTransBrcEx)
END_ATTR(text_p_borders)

BEGIN_ATTR(text_p_align)
	SIM_ATTR(text_p_hori_align,				sprmPJc,			AttrTransFixDefaultDual(sprmPJcEx))
	SIM_ATTR(text_text_align,				sprmPWAlignFont,	AttrTransFixDefault)
END_ATTR(text_p_align)

BEGIN_ATTR(text_para_spacing)
SIM_ATTR(text_p_spacing_before,					sprmPDyaBefore,			AttrRelDual<sprmPDyaBeforeRel>::AddFix)
	SIM_ATTR(text_p_spacing_before_relative,	sprmPDyaBeforeRel,		AttrTransLinePencentEx(sprmPDyaBefore))
	SIM_ATTR(text_p_spacing_before_auto,		sprmPDyaBeforeAuto,		AttrTransFixDefault)
	SIM_ATTR(text_p_spacing_after,				sprmPDyaAfter,			AttrRelDual<sprmPDyaAfterRel>::AddFix)
	SIM_ATTR(text_p_spacing_after_relative,		sprmPDyaAfterRel,		AttrTransLinePencentEx(sprmPDyaAfter))
	SIM_ATTR(text_p_spacing_after_auto,			sprmPDyaAfterAuto,		AttrTransFixDefault)
	SIM_ATTR(text_p_spacing_context,			sprmPContextualSpacing, AttrTransFixDefault)
END_ATTR(text_para_spacing)

BEGIN_ATTR(text_p)
	// simple attr
	SIM_ATTR(text_line_spacing,			sprmPDyaLine,			AttrTransLineSpacing)
	SIM_ATTR(text_snap_to_grid,			sprmPFUsePgsuSettings,	AttrTransFixDefault)
	SIM_ATTR(text_autospace_dn,			sprmPFAutoSpaceDN,		AttrTransFixDefault)	
	SIM_ATTR(text_autospace_de,			sprmPFAutoSpaceDE,		AttrTransFixDefault)
	SIM_ATTR(text_widows,				sprmPFWidowControl,		AttrTransFixDefault)
	SIM_ATTR(text_keep_next,			sprmPFKeepFollow,		AttrTransFixDefault)
	SIM_ATTR(text_keep_lines,			sprmPFKeep,				AttrTransFixDefault)
	SIM_ATTR(text_page_break_before,	sprmPFPageBreakBefore,	AttrTransFixDefault)
	SIM_ATTR(text_p_outline,			sprmPOutLvl,			AttrTransFixDefault)
	SIM_ATTR(text_suppress_line_number,	sprmPFNoLineNumb,		AttrTransFixDefault)
	SIM_ATTR(text_suppress_auto_hyphens,sprmPFNoAutoHyph,		AttrTransFixDefault)
	SIM_ATTR(text_break_in_word,		sprmPFWordWrap,			AttrTransNot)
	SIM_ATTR(text_overflow_punct,		sprmPFOverflowPunct,	AttrTransFixDefault)
	SIM_ATTR(text_top_line_punct,		sprmPFTopLinePunct,		AttrTransFixDefault)
	SIM_ATTR(text_kinsoku,				sprmPFKinsoku,			AttrTransFixDefault)
	SIM_ATTR(text_auto_right_indent,	sprmPFAdjustRight,		AttrTransFixDefault)

	SIM_ATTREX(text_p_fill,				sprmPShd,				AttrTransShd, 
										sprmPShdEx,				AttrTransShdEx)
	
	// sub attr
	SUB_ATTR(text_p_borders)
	SUB_ATTR(text_p_align)
	SUB_ATTR(text_para_spacing)
END_ATTR(text_p)

// -------------------------------------------------------------------------
STDMETHODIMP TransParaAttr(
	IN KDWDocTarget* pTarget, IN IKAttributes* pAttr, IN KDWPropBuffer* pPropBuf)
{
	HRESULT hr = E_FAIL;
	//
	//@@note:
	//  �벻Ҫ���������������ĵ���˳��
	//
	hr = TransLfo(pTarget, (KROAttributes*)pAttr, pPropBuf);
	ASSERT_OK(hr);

	hr = ParseAttrInfo(ATTRINFO(text_p), pTarget, pAttr, pPropBuf);
	ASSERT_OK(hr);
	
	hr = TransParaIndent(pAttr, pPropBuf);
	ASSERT_OK(hr);
	
	return hr;
}

// -------------------------------------------------------------------------
// $Log: paraattr.cpp,v $
// Revision 1.32  2006/07/31 07:00:03  wangdong
// #26126������дdocʱ��feature��������ݡ�
//
// Revision 1.31  2006/05/11 03:16:18  wangdong
// no message
//
// Revision 1.30  2006/03/29 02:22:37  xulingjiao
// �޸����BUG
//
// Revision 1.29  2006/03/27 05:47:34  xulingjiao
// �޸����BUG
//
// Revision 1.28  2005/07/12 12:44:18  rongjianxing
// *** empty log message ***
//
// Revision 1.27  2005/07/12 12:37:14  huangjianing
// ����sprmEx�ĵ���
//
// Revision 1.26  2005/06/25 08:58:09  rongjianxing
// *** empty log message ***
//
// Revision 1.25  2005/06/02 06:32:35  rongjianxing
// *** empty log message ***
//
// Revision 1.24  2005/02/25 09:59:07  wangdong
// �޸������¿����sprm��д��˳��
//
