/* -------------------------------------------------------------------------
//	�ļ���		��	papx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:24:59
//	��������	��	
//
//	$Id: papx.cpp,v 1.13 2006/09/20 06:36:25 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "../colortable.h"
#include "../styleshelper.h"
#include "rtf/writer/include/rtffile.h"
#include "chpx.h"
#include "papxhelper.h"
#include "papx.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SetPardProp(mem, val)\
{\
	if(!mask.mem)\
	{\
		_MemSetInt(mask.mem);\
		prop->mem = val;\
	}\
}

void AddPard(RtfWParaPr* prop)
{	
	RtfWParaPr::MaskType& mask = prop->mask;	
	SetPardProp(dxaLeft, 0);	
	SetPardProp(dxaRight, 0);
	SetPardProp(fAutoSpaceDE, 1);
	SetPardProp(fAutoSpaceDN, 1);
	SetPardProp(fAdjustRight, 1);
	SetPardProp(nTableLayer, 0);
	SetPardProp(fWidowControl, 1);
}

STDMETHODIMP_(void) RtfWPapxWriter::WriteLevelPapx(RtfDirectWriter* ar)
{		
	const BYTE* arg = NULL;
	INT len = -1;
	KDWSprm sprm;
	
	KDWSprmList::Enumerator enumer(&m_sprms);
	for(; SUCCEEDED(enumer.Next(&sprm)); )
	{
		sprm.GetArgument(&arg, &len);
		switch(sprm.GetOpcode())
		{
		case sprmPDxaLeft1:
			break;
		case sprmPDxaLeft1Ex:
			ar->AddAttribute(rtf_fi, GetValue<INT16>(arg));
			break;
		case sprmPDxaLeft:
			break;
		case sprmPDxaLeftEx:
			ar->AddAttribute(rtf_li, GetValue<INT16>(arg));
			ar->AddAttribute(rtf_lin, GetValue<INT16>(arg));
			break;
		case sprmPChgTabsPapx:
			{
				KDWTab ktab;
				AssignKDWtab(ktab, arg);
				::WriteTabCtrl(ktab, ar);
			}
			break;
		default:
			ASSERT_ONCE(0);
			break;
		}
	}
}
STDMETHODIMP_(void) RtfWPapxWriter::Write(RtfDirectWriter* ar, const RtfWParaPr* prop, UINT istd)
{		
	RtfWParaPr papx(*prop);
	AddPard(&papx);
	WriteMerged(ar, &papx, istd, m_ginfo);
}

RtfWPapxWriter::RtfWPapxWriter(RtfWGlobalInfo* info, const KDWPropx* prop) :
	m_ginfo(info), m_istd(stiNil)
{
	if (prop != NULL)
		SetProp(prop);
}
STDMETHODIMP_(void) RtfWPapxWriter::SetProp(const KDWPropx* prop)
{			
	SetProp((const BYTE*)_MsoPdata(prop), prop->cb);
}
STDMETHODIMP_(void) RtfWPapxWriter::SetProp(const BYTE* buff, INT cb, BOOL hasIstd)
{	
	const BYTE* pPapx = buff;
	if (hasIstd)
	{
		m_istd = GetPapxIstd(buff);
		pPapx = (const BYTE*)GetPapx(buff, &cb);
		if (m_istd == stiNil)
			m_istd = stiNormal;
	}
	m_sprms = KDWSprmList(pPapx, cb);
}
STDMETHODIMP_(void) RtfWPapxWriter::SetIstd(UINT istd)
{
	m_istd = istd;
}
STDMETHODIMP_(RtfWParaPr&) RtfWPapxWriter::GetPap()
{
	return prop;
}
STDMETHODIMP_(UINT) RtfWPapxWriter::GetIstd()
{
	return m_istd;
}
STDMETHODIMP_(void) RtfWPapxWriter::Write(RtfDirectWriter* ar)
{		
	const RtfWParaPr* base = m_ginfo->styles->GetMergedPapx(GetIstd());
	Write(ar, base, base);
}
STDMETHODIMP_(void) RtfWPapxWriter::Write(RtfDirectWriter* ar, const RtfWParaPr* mergewith, const RtfWParaPr* baseon)
{	
	prop.Reset();
	if (mergewith != NULL)
		prop= *mergewith;
	if (baseon == NULL)
		baseon = GetDefaultPapx();
	
	prop.Sprms2ParaPr(&m_sprms, baseon, m_ginfo->lists);
	AddPard(&prop);
	WriteMerged(ar,&prop, m_istd, m_ginfo);
	const RtfWSpanPr* chpx = m_ginfo->styles->GetMergedChpxAtPStyle(m_istd);
	RtfWChpxWriter wrChpx(m_ginfo);
	if (chpx)
	{
		RtfWSpanPr parachpx = *chpx;
		AddPlain(&parachpx);
		wrChpx.Write(ar, &parachpx, TRUE);
	}
}


void RtfWPapxWriter::WriteMerged(RtfDirectWriter* ar, const RtfWParaPr* p, UINT istd, RtfWGlobalInfo* ginfo)
{
	const RtfWParaPr::MaskType* m = &p->mask;

	if (istd != stiNil && istd != stiNormal)
		ar->AddAttribute(rtf_s, istd);
	
	_AddAttributeMask(m->jc, ar, GetJcCtrl(p->jc, jcctrls::which_parajc), rtf_nilParam);

	// �������ڵ��Զ���ż���
	_AddAttributeNotdefvalMask(m->ilvl, p->ilvl, 0, ar, rtf_ilvl, p->ilvl);
	
	
	// ��������
	_AddAttributeMask(m->dxaLeft1, ar, rtf_fi, p->dxaLeft1);
	_AddAttributeMask(m->dxaLeft1Rel, ar, rtf_cufi, p->dxaLeft1Rel);
	_AddAttributeMask(m->dxaLeft, ar, rtf_li, p->dxaLeft);
	_AddAttributeMask(m->dxaLeftRel, ar, rtf_culi, p->dxaLeftRel);
	_AddAttributeMask(m->dxaRight, ar, rtf_ri, p->dxaRight);		
	_AddAttributeMask(m->dxaRightRel, ar, rtf_curi, p->dxaRightRel);

	// ������		
	_AddAttributeMask(m->dyaBefore, ar, rtf_sb, p->dyaBefore);
	_AddAttributeMask(m->dyaBeforeRel, ar, rtf_lisb, p->dyaBeforeRel);
	_AddAttributeMask(m->dyaAfter, ar, rtf_sa, p->dyaAfter);
	_AddAttributeMask(m->dyaAfterRel, ar, rtf_lisa, p->dyaAfterRel);
	_AddAttributeMask(m->fAutoSpacingBefore, ar, rtf_sbauto, p->fAutoSpacingBefore);
	_AddAttributeMask(m->fAutoSpacingAfter, ar, rtf_saauto, p->fAutoSpacingAfter);
	WriteLspdCtrl(p->lspd, m->lspd, ar);	
	_AddBoolAttributeMaskNot0(m->fUsePgsuSettings, ar, rtf_nosnaplinegrid, p->fUsePgsuSettings==0);	
	// ��ҳ����
	WriteFWidowControlCtrl(p->fWidowControl, m->fWidowControl, ar);
	_AddBoolAttributeMask(m->fKeep, ar, rtf_keep, p->fKeep);
	_AddBoolAttributeMask(m->fKeepFollow, ar, rtf_keepn, p->fKeepFollow);
	_AddBoolAttributeMask(m->fPageBreakBefore, ar, rtf_pagebb, p->fPageBreakBefore);
	_AddBoolAttributeMask(m->fNoLnn, ar, rtf_noline, p->fNoLnn);
	_AddBoolAttributeMask(m->fNoAutoHyph, ar, rtf_hyphpar, !p->fNoAutoHyph);
	
	// ���İ�ʽ		
	_AddBoolAttributeMask(m->fKinsoku, ar, rtf_nocwrap, !p->fKinsoku);
	_AddBoolAttributeMask(m->fWordWrap, ar, rtf_nowwrap, !p->fWordWrap);
	_AddBoolAttributeMask(m->fOverflowPunct, ar, rtf_nooverflow, !p->fOverflowPunct);
	_AddBoolAttributeMaskNot0(m->fAutoSpaceDE, ar, rtf_aspalpha, p->fAutoSpaceDE);
	_AddBoolAttributeMaskNot0(m->fAutoSpaceDN, ar, rtf_aspnum, p->fAutoSpaceDN);
	_AddBoolAttributeMask(m->fTopLinePunct, ar, rtf_toplinepunct, p->fTopLinePunct);
	_AddAttributeMask(m->wAlignFont, ar, GetFaCtrl(p->wAlignFont), rtf_nilParam);

	// ��������
	_AddBoolAttributeMaskNot0(m->fAdjustRight, ar, rtf_adjustright, p->fAdjustRight);
	// todo: Ŀǰ�м�㲻֧��˫�����֣����Զ�Ϊ������������
	_AddAttributeMask(m->dxaLeft, ar, rtf_lin, p->dxaLeft);
	_AddAttributeMask(m->dxaRight, ar, rtf_rin, p->dxaRight);
	//\itap0 \b\fs28\lang1033\langfe2052

	// �������
	WriteParaShdCtrl(p->shd, m->shd, ginfo->colors, ar);

	// ����߿�
	WriteBrcCtrl(p->brcTop, m->brcTop, ar, ginfo->colors, rtf_brdrt);
	WriteBrcCtrl(p->brcBottom, m->brcBottom, ar, ginfo->colors, rtf_brdrb);
	WriteBrcCtrl(p->brcLeft, m->brcLeft, ar, ginfo->colors, rtf_brdrl);
	WriteBrcCtrl(p->brcRight, m->brcRight, ar, ginfo->colors, rtf_brdrr);
	WriteBrcCtrl(p->brcBetween, m->brcBetween, ar, ginfo->colors, rtf_brdrbtw);
	
	// �Ʊ�λ
	WriteTabCtrl(p->ktab, m->ktab, ar);

	// ͼ�Ŀ�
	_AddAttributeMask(m->frame.dxaWidth, ar, rtf_absw, p->frame.dxaWidth);
	WriteFrameWHeightAbsOprandCtrl(p->frame.wHeightAbsOprand, m->frame.wHeightAbsOprand, ar);
	WriteFramePPcOprandCtrl(p->frame.ppcOprand, m->frame.ppcOprand, ar);
	WriteFrameDxaAbsCtrl(p->frame.dxaAbs, m->frame.dxaAbs, ar);
	WriteFrameDyaAbsCtrl(p->frame.dyaAbs, m->frame.dyaAbs, ar);		
	_AddAttributeMask(m->frame.fLocked, ar, rtf_abslock, p->frame.fLocked);
	_AddAttributeMask(m->frame.dxaFromText, ar, rtf_dfrmtxtx, p->frame.dxaFromText);
	_AddAttributeMask(m->frame.dyaFromText, ar, rtf_dfrmtxty, p->frame.dyaFromText);
	WriteFrameWrCtrl(p->frame.wr, m->frame.wr, ar);
	WriteFrameDropcapCtrl(p->frame.dropCap, m->frame.dropCap, ar);
	_AddAttributeMask(m->frame.fabsnoovrlp, ar, rtf_absnoovrlp, p->frame.fabsnoovrlp);
	_AddAttributeMask(m->frame.textFlow, ar, GetTextflowCtrl(p->frame.textFlow, textflowctrls::which_para), rtf_nilParam);
	
	// �������
	_AddBoolAttributeMask(m->fInTable, ar, rtf_intbl, p->fInTable);
	_AddAttributeMask(m->nTableLayer, ar, rtf_itap, p->nTableLayer);

	// todo: ��ôwordд������rtfû���������? doc�����е�(�ھ���ʽ��)
	_AddAttributeMask(m->lvl, ar, rtf_outlinelevel, p->lvl);

	// ���λ�ò��Ի��������������
	_AddAttributeMask(m->ilfo, ar, rtf_ls, p->ilfo);
}
void RtfWPapxWriter::WriteParaShdCtrl(const KDWShd& shd, UINT8 refShd, RtfWColorTable* colors, RtfDirectWriter* ar)
{
	if (refShd)
		::WriteParaShdCtrl(shd, colors, ar);
}
void RtfWPapxWriter::WriteBrcCtrl(const KDWBrc& brc, UINT8 refBrc, RtfDirectWriter* ar, RtfWColorTable* colors, RtfControl whichBrc)
{
	if(refBrc)
		::WriteBrcCtrl(brc, ar, colors, whichBrc);
}
void RtfWPapxWriter::WriteLspdCtrl(LSPD lspd, UINT8 refLspd, RtfDirectWriter* ar)
{
	if(refLspd)
	{
		ar->AddAttribute(rtf_sl, lspd.dyaLine);
		ar->AddAttribute(rtf_slmult, lspd.fMultLinespace);
	}
}
void RtfWPapxWriter::WriteTabCtrl(const KDWTab& ktab, RtfDirectWriter*ar)
{	
	for(UINT i=0; i<ktab.itbdMac; ++i)
	{
		RtfControl tabKind = GetTabKindCtrl(ktab.rgtbd[i].jc);
		if(tabKind != rtf_tb)
		{
			RtfControl tabLead = GetTabLeadCtrl(ktab.rgtbd[i].tlc);
			ar->AddAttribute(tabKind, rtf_nilParam);
			if(tabLead != rtf_unknown)
				ar->AddAttribute(tabLead, rtf_nilParam);
			ar->AddAttribute(rtf_tx, ktab.rgdxaTab[i]);
		}
		else
		{
			ar->AddAttribute(rtf_tb, ktab.rgdxaTab[i]);
		}
	}
}
void RtfWPapxWriter::WriteTabCtrl(const KDWTab& ktab,UINT8 refKtab, RtfDirectWriter*ar)
{
	if(refKtab)
		WriteTabCtrl(ktab, ar);
}
void RtfWPapxWriter::WriteFrameDropcapCtrl(const DCS& dropCap, RtfDirectWriter*ar)
{
	ar->AddAttribute(rtf_dropcapli, dropCap.lines);
	ar->AddAttribute(rtf_dropcapt, dropCap.fdct);
}
void RtfWPapxWriter::WriteFrameDropcapCtrl(const DCS& dropCap, UINT8 refDropCap, RtfDirectWriter*ar)
{
	if(refDropCap)
		WriteFrameDropcapCtrl(dropCap, ar);
}
void RtfWPapxWriter::WriteFramePPcOprandCtrl(const KDWFrame::unionSprmPPcOprand& ppcOprand, RtfDirectWriter*ar)
{
	 ar->AddAttribute(GetHpcCtrl(ppcOprand.ppc.pcHorz, hpcctrls::which_parahpc));
	 ar->AddAttribute(GetVpcCtrl(ppcOprand.ppc.pcVert, vpcctrls::which_paravpc));
}
void RtfWPapxWriter::WriteFramePPcOprandCtrl(const KDWFrame::unionSprmPPcOprand& ppcOprand, UINT8 refPPcOprand, RtfDirectWriter*ar)
{
	if(refPPcOprand)
		WriteFramePPcOprandCtrl(ppcOprand, ar);	
}
void RtfWPapxWriter::WriteFrameDxaAbsCtrl(INT16 dxaAbs, UINT8 refDxaAbs, RtfDirectWriter*ar)
{
	if(refDxaAbs)
	{
		RtfControl xposCtrl = GetParaXposCtrl(dxaAbs);
		if(xposCtrl == rtf_posx || xposCtrl == rtf_posnegx)			
			ar->AddAttribute(xposCtrl, dxaAbs);
		else
			ar->AddAttribute(xposCtrl);
	}
}
void RtfWPapxWriter::WriteFrameDyaAbsCtrl(INT16 dyaAbs, UINT8 refDyaAbs, RtfDirectWriter*ar)
{
	if(refDyaAbs)
	{
		RtfControl yposCtrl = GetParaYposCtrl(dyaAbs);
		if(yposCtrl == rtf_posy || yposCtrl == rtf_posnegy)
			ar->AddAttribute(yposCtrl, dyaAbs);
		else
			ar->AddAttribute(yposCtrl);
	}
}
void RtfWPapxWriter::WriteFrameWrCtrl(INT8 wr, UINT8 refWr, RtfDirectWriter* ar)
{
	if(refWr)
	{
		switch(wr)
		{
		case mso_wrapTopBottom:
			ar->AddAttribute(rtf_nowrap);
			break;
		case mso_wrapSquare:
			break;
		default:
			ar->AddAttribute(rtf_overlay);
			break;
		}			
	}
}
void RtfWPapxWriter::WriteFrameWHeightAbsOprandCtrl(const KDWFrame::sprmWHeightAbsOprand& wHeightAbsOprand, RtfDirectWriter* ar)
{
	if(!wHeightAbsOprand.fMinHeight)
		ar->AddAttribute(rtf_absh, -wHeightAbsOprand.dyaHeight);
	else
		ar->AddAttribute(rtf_absh, wHeightAbsOprand.dyaHeight);
}
void RtfWPapxWriter::WriteFrameWHeightAbsOprandCtrl(const KDWFrame::sprmWHeightAbsOprand& wHeightAbsOprand, UINT8 refWHeightAbsOprand, RtfDirectWriter* ar)
{
	if(refWHeightAbsOprand)
		WriteFrameWHeightAbsOprandCtrl(wHeightAbsOprand, ar);
}
void RtfWPapxWriter::WriteFWidowControlCtrl(UINT8 fWidowControl, UINT8 refFWidowControl, RtfDirectWriter* ar)
{		
	if(fWidowControl)
	{
		_AddBoolAttributeMask(refFWidowControl, ar, rtf_widctlpar, rtf_nilParam);
	}
	else
	{
		_AddBoolAttributeMask(refFWidowControl, ar, rtf_nowidctlpar, rtf_nilParam);
	}		
}	
void RtfWPapxWriter::WriteLsCtrl(RtfDirectWriter* ar, const RtfWParaPr* p, RtfWGlobalInfo* ginfo)
{	
	const _DW_ListLevel* pCurLvl = ginfo->lists->GetListLevel(p->ilfo, p->ilvl);
	if (pCurLvl && pCurLvl->pPapx && pCurLvl->lvlf.cbGrpprlPapx)
	{
		RtfWPapxWriter wrPapx(ginfo);
		wrPapx.SetProp((const BYTE*)pCurLvl->pPapx, pCurLvl->lvlf.cbGrpprlPapx, FALSE);
		wrPapx.WriteLevelPapx(ar);
	}
}