/* -------------------------------------------------------------------------
//	�ļ���		��	text_annotation_end.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 9:59:20
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __COMMENTCONNECT_H__
// #include "commentconnect.h" new_annotation
#endif

#ifndef __TEXT_ANNOTATION_END_H__
#include "text_annotation_end.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextAnnEndHandler::StartElement(
											  IN ELEMENTID uElementID,
											  IN KROAttributes* pAttrs
											  )
{
	HRESULT hr;

	INT32 nAnnRefID;
	hr = pAttrs->GetByID(text_annotation_id, &nAnnRefID);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	/*
	KCommentConnection* pConn = m_pDocTarget->GetCommentConnection();
	if (pConn == NULL)
		{ return E_NOTIMPL; }
	
	return pConn->MarkAnnRefEnd(nAnnRefID);
	 new_annotation */

	UINT anntID = m_pDocTarget->GetAnnotationsID(nAnnRefID);
	
	KDWAnnotations* pAnnotations = const_cast<KDWAnnotations*>(m_pDocTarget->GetAnnotations());
	return pAnnotations->__MarkAnnRefEnd(anntID, m_pDocTarget->GetFcMax());
}

// -------------------------------------------------------------------------
