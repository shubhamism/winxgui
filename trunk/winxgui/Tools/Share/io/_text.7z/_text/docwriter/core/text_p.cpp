/* -------------------------------------------------------------------------
//	�ļ���		��	text_p.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 18:53:55
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include <field/text_field_code.h>
#include "text_p.h"
#include "attributes/attrtrans.h"
// #include <comment/commentconnect.h> new_annotation

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
KTextPHandler::~KTextPHandler()
{
	delete m_fieldCodeElement;
}

STDMETHODIMP KTextPHandler::StartElement(
										 IN ELEMENTID uElementID,
										 IN KROAttributes* pAttrs)
{
	// �������еĶα�ǩ����ֻ���ɶ����±�ǩ
	if (m_fIsFakeHandle)
		return S_OK;

#pragma prompt("�˴�Ϊ��ʱ������ԭ����ο�readme.txt��28�ڡ�")
	m_pDocTarget->NewNullChpxSpan();

	HRESULT hr = E_FAIL;
	{
		KDWPropBuffer* pPropBuffer = m_pDocTarget->GetPropBuffer();
		// ��ʽ
		UINT istd = 0;
		INT iXmlBase = -1; 
		if (pAttrs)
		{
			if (!FAILED(pAttrs->GetByID(text_p_styleref, &iXmlBase)))
			{
				KDWStyleIDMap& IdMap = m_pDocTarget->GetPStyleIDMap();
				KDWStyleIDMap::const_iterator i = IdMap.find(iXmlBase);
				if (i != IdMap.end())
					istd = (*i).second;
			}
		}
		pPropBuffer->AddIstd(istd);
		
		if (pAttrs)
		{
			hr = TransParaAttr(m_pDocTarget, pAttrs, pPropBuffer);
			ASSERT_OK(hr);

			TransTAB(m_pDocTarget, pAttrs, pPropBuffer);
		}
		m_pDocTarget->NewParagraph(pPropBuffer);
//		m_pDocTarget->GetCommentConnection()->OnReachLowerBound();  new_annotation
	}	
	return hr;
}

STDMETHODIMP KTextPHandler::EnterSubElement(
											 IN ELEMENTID uSubElementID,
											 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_span:
		m_spanElement.Init(m_pDocTarget);
		*ppHandler = &m_spanElement;
		break;
	case text_field_begin:
		m_fieldBeginElement.Init(m_pDocTarget);
		*ppHandler = &m_fieldBeginElement;
		break;
	case text_field_separate:
		if (m_fieldCodeElement == NULL)
			m_fieldCodeElement = new KTextFieldCodeHandler;
		m_fieldCodeElement->Init(m_pDocTarget);
		*ppHandler = m_fieldCodeElement;
		break;
	case text_field_end:
		m_fieldEndElement.Init(m_pDocTarget);
		*ppHandler = &m_fieldEndElement;
		break;
	case text_insertion_begin:
	case text_insertion_end:
	case text_deletion:
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
