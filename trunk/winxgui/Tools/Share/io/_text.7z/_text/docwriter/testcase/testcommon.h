/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:32:48
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#if defined(_DEBUG)
#define X_RELEASE_CASE
#endif

#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif

#ifndef __MSO_IO_WORD_WRITER_H__
#include <mso/io/word/writer.h>
#endif

#include "kso/dircfginfo.h"

__USING_MSO_ESCHER;

// -------------------------------------------------------------------------

class TestClientData
{
public:
	MsoKernData* PersistClientData(
		IN MsoAutoFreeAlloc* alloc) const
	{
		MsoKernData* data = _MsoAllocKernData(alloc, 4);
		data->cb = 4;
		*(UINT32*)(data+1) = 1;
		return data;
	}
};

// -------------------------------------------------------------------------

inline
STDMETHODIMP CreateDocfile(
						   IN LPCWSTR szFile,
						   OUT IStorage** ppRootStg)
{
	WCHAR szDocFile[_MAX_PATH];

	_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szDocFile, MAX_PATH);
	wcscat(szDocFile, __L("/"));
	wcscat(szDocFile, szFile);
	
	return StgCreateDocfile(
		szDocFile,
		STGM_READWRITE|STGM_SHARE_EXCLUSIVE|STGM_CREATE,
		0,
		ppRootStg);
}

inline
STDMETHODIMP_(KDWBlip) NewBlip(
							   IN KDWDocument& docu,
							   IN LPCWSTR szImgFile,
							   IN MSOBLIPTYPE blipType = msoblipUNKNOWN)
{
	WCHAR szFile[_MAX_PATH];
	_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szFile, MAX_PATH);
	wcscat(szFile, __L("/"));
	wcscat(szFile, szImgFile);
	
	return docu.GetBlipStore().NewBlip(
		szFile, blipType);	
}

inline
STDMETHODIMP_(KDWPicBullet) NewBullet(
							   IN KDWDocument& docu,
							   IN LPCWSTR szImgFile,
							   IN MSOBLIPTYPE blipType = msoblipUNKNOWN)
{
	WCHAR szFile[_MAX_PATH];

	_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szFile, MAX_PATH);
	wcscat(szFile, __L("/"));
	wcscat(szFile, szImgFile);

	KDWBlip blip = docu.GetBlipStore().NewBlip(
		szFile,
		blipType);	
	return docu.GetPicBullets().NewPicBullet(blip);
}

// -------------------------------------------------------------------------

#endif /* __TESTCOMMON_H__ */
