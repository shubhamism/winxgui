/* -------------------------------------------------------------------------
//	�ļ���		��	text_annotation_begin.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 9:58:42
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifndef __COMMENTCONNECT_H__
// #include "commentconnect.h" new_annotation
#endif

#ifndef __TEXT_ANNOTATION_BEGIN_H__
#include "text_annotation_begin.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextAnnBeginHandler::StartElement(
												IN ELEMENTID uElementID,
												IN KROAttributes* pAttrs)
{
	HRESULT hr;

	INT32 nAnnID;
	hr = pAttrs->GetByID(text_annotation_info, &nAnnID);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	INT32 nAnnRefID;
	hr = pAttrs->GetByID(text_annotation_id, &nAnnRefID);
	if (hr != S_OK)
		{ ASSERT(FALSE); return hr; }

	/*
	KCommentConnection* pConn = m_pDocTarget->GetCommentConnection();
	if (pConn == NULL)
		{ return E_NOTIMPL; }

	return pConn->MarkAnnRefBegin(nAnnID, nAnnRefID);
	*/

	m_pDocTarget->SetAnnotationID(nAnnRefID, nAnnID);

	KDWAnnotations* pAnnotations = const_cast<KDWAnnotations*>(m_pDocTarget->GetAnnotations());
	return pAnnotations->__MarkAnnRefBegin(nAnnID, m_pDocTarget->GetFcMax());
}

// -------------------------------------------------------------------------
