/* -------------------------------------------------------------------------
//	�ļ���		��	bookmark.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:10:07
//	��������	��	
//
//	$Id: bookmark.h,v 1.2 2006/01/20 08:43:01 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __BOOKMARK_H__
#define __BOOKMARK_H__
#include "rtf/writer/include/rtffile.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWBookmarkWriter
{
public:
	STDMETHODIMP_(void) WriteBegin(RtfDirectWriter* ar, const KDWBookmarkData* t)
	{
		ar->StartGroup(rtf_bkmkstart, rtf_nilParam, TRUE);
		ar->AddContentWcs(t->kernName->Data(), t->kernName->Size());
		ar->EndGroup();
	}
	STDMETHODIMP_(void) WriteEnd(RtfDirectWriter* ar, const KDWBookmarkData* t)
	{
		ar->StartGroup(rtf_bkmkend, rtf_nilParam, TRUE);
		ar->AddContentWcs(t->kernName->Data(), t->kernName->Size());
		ar->EndGroup();
	}
};
// -------------------------------------------------------------------------
//	$Log: bookmark.h,v $
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:05  xulingjiao
//	*** empty log message ***
//	

#endif /* __BOOKMARK_H__ */
