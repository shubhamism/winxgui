/* -------------------------------------------------------------------------
//	�ļ���		��	testdoc2rtf_bookmark.cpp
//	������		��	���὿
//	����ʱ��	��	2005-8-20 20:55:30
//	��������	��	
//
//	$Id: testdoc2rtf_bookmark.cpp,v 1.2 2006/04/18 05:42:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testdoc2rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class testdoc2rtf_bookmark : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(testdoc2rtf_bookmark);
		CPPUNIT_TEST(testBookmark_bkmk);
	CPPUNIT_TEST_SUITE_END();
public:
	void setUp() {}
	void tearDown()
	{		
	}

public:
	void testBookmark_bkmk()		// pass
	{
		testDoc2RtfFile("bookmark/��ǩ.doc", "bookmark_��ǩ.rtf");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(testdoc2rtf_bookmark);


// -------------------------------------------------------------------------
//	$Log: testdoc2rtf_bookmark.cpp,v $
//	Revision 1.2  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.1  2005/08/22 05:06:39  xulingjiao
//	������ʽ��������ת����BUG
//	
