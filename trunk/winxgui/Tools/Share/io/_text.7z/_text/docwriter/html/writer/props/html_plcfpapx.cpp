/* -------------------------------------------------------------------------
//	�ļ���		��	html_plcfpapx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:08:31
//	��������	��	
//
//	$Id: html_plcfpapx.cpp,v 1.11 2006/07/13 02:51:29 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "../html_textstream.h"
#include "html_plcfpapx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
STDMETHODIMP_(BOOL&) HtmlWPapxsWriter::GetFOpen()
{
	return m_fOpend;
}
HtmlWPapxsWriter::HtmlWPapxsWriter(const KDWPlcfPapx* papxs, HtmlWGlobalInfo* info) :
	m_papxs(papxs),
	m_ginfo(info),
	m_wrPapx(info),
	m_fOpend(FALSE),
	m_current(0), m_fTblWrite(0)
{		
	Reset();
}
STDMETHODIMP_(BOOL) HtmlWPapxsWriter::Good() const
{
	return m_papxs != NULL && m_papxs->Count();
}
STDMETHODIMP_(void) HtmlWPapxsWriter::Reset()
{		
	m_enumer = KDWPlcfPapx::Enumerator(m_papxs);
	Next();
}
STDMETHODIMP HtmlWPapxsWriter::Next()
{			
	if (FAILED(m_enumer.Next(&m_current)))		
		return E_FAIL;
	m_wrPapx.SetProp(m_papxs->SrcData(m_current));
	return S_OK;
}
STDMETHODIMP_(HtmlWPapxWriter&) HtmlWPapxsWriter::GetPapInfo()
{
	return m_wrPapx;
}
STDMETHODIMP_(UINT) HtmlWPapxsWriter::GetCurrentCp()
{
	return (UINT)m_enumer.Range().cp;
}
STDMETHODIMP_(UINT) HtmlWPapxsWriter::GetNextCp()
{
	return (UINT)m_enumer.Range().cpNext;		
}
STDMETHODIMP_(UINT) HtmlWPapxsWriter::GetIstd(UINT cp)
{
	INT idx = m_papxs->GetIndex(cp);

	if (idx < 0)
		return stiNil;

	const KDWPropx* prop = m_papxs->SrcData(idx);

	return GetPapxIstd(_MsoPdata(prop));
}
STDMETHODIMP_(void) HtmlWPapxsWriter::EnsureWriteEnd()
{
	EnsureWriteEndTag(m_fOpend, m_ginfo->ar, elem_p);
}
STDMETHODIMP_(void) HtmlWPapxsWriter::Write()
{
	EnsureWriteEnd();
	m_cssprop.Clear();
	m_wrPapx.ToCss(&m_cssprop, "; ");
	
	// ���䲻�ڱ�����
	if(!m_wrPapx.GetPap().fInTable)
	{
		WriteStartTag(m_fOpend, m_ginfo->ar, elem_p);
		m_wrPapx.Write(&m_cssprop);
		m_fTblWrite = FALSE;
	}
	else
	{
		if(m_wrPapx.GetPap().nTableLayer == 1)
		{
			if(!m_fTblWrite)
			{
				m_wrTbls.Write(m_ginfo);
				m_fTblWrite = TRUE;
			}
		}		
	}
}
