/* -------------------------------------------------------------------------
//	�ļ���		��	html_chpx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 11:46:56
//	��������	��	
//
//	$Id: html_chpx.cpp,v 1.19 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "mso/io/css/spanpr2cssprop.h"
#include "html_chpx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HtmlWChpxWriter::HtmlWChpxWriter(const KDWPropx* chpx, HtmlWGlobalInfo* info, INT istdpara)
	: m_ginfo(info){SetProp(chpx, istdpara);}

HtmlWChpxWriter::HtmlWChpxWriter(const void* pchpx, INT cb, HtmlWGlobalInfo* info, INT istdpara)
	: m_ginfo(info){SetProp(pchpx, cb, istdpara);}

HtmlWChpxWriter::HtmlWChpxWriter(HtmlWGlobalInfo* info)
	: m_ginfo(info){ResetMember();}

STDMETHODIMP_(void) HtmlWChpxWriter::SetProp(const KDWPropx* chpx, INT istdpara)
{
	ResetMember(chpx, istdpara);
}
STDMETHODIMP_(void) HtmlWChpxWriter::SetProp(const void* pchpx, INT cb, INT istdpara)
{
	m_backupchpx = m_chpx = NULL;		
	m_istdpara = istdpara;
	m_istd = stiNil;		
	if(pchpx)
	{
		m_sprms = KDWSprmList((const BYTE*)pchpx, cb);
		m_istd = m_sprms.GetCharIstd();
	}
}
STDMETHODIMP_(void) HtmlWChpxWriter::ResetMember(const KDWPropx* chpx, INT istdpara)
{	
	m_backupchpx = m_chpx;
	m_chpx = chpx;
	m_istdpara = istdpara;
	m_istd = stiNil;
	if(chpx)
	{
		m_sprms = KDWSprmList((const BYTE*)_MsoPdata(chpx), chpx->cb);		
		m_istd = m_sprms.GetCharIstd();
	}
}

// gets
STDMETHODIMP_(const KDWFont&) HtmlWChpxWriter::GetFont() const
{
	return m_font;
}

STDMETHODIMP_(HtmlWSpanPr&) HtmlWChpxWriter::GetChp()
{
	return m_prop;
}

STDMETHODIMP_(CHARSETINFO) HtmlWChpxWriter::GetCharsetInfo(INT iFont)
{
	KDWFont font;
	m_ginfo->doc->GetFontTable().GetFont(font, iFont);
	CHARSETINFO charsetinfo;
	if(!TranslateCharsetInfo((DWORD*)font.charset, &charsetinfo, TCI_SRCCHARSET))	
		return GetSysCharsetInfo();
	return charsetinfo;
}

STDMETHODIMP_(CHARSETINFO) HtmlWChpxWriter::GetCharsetInfo() const
{
	CHARSETINFO charsetinfo;
	if(!TranslateCharsetInfo((DWORD*)m_font.charset, &charsetinfo, TCI_SRCCHARSET))
		return GetSysCharsetInfo();
	return charsetinfo;
}
STDMETHODIMP_(const KDWPropx*) HtmlWChpxWriter::GetPicLocation() const
{
	if(m_backupchpx)
		return m_backupchpx;
	return m_chpx;
}
STDMETHODIMP_(void) HtmlWChpxWriter::ToChp()
{
	m_prop.Reset();
	HtmlWSpanPr baseon;
	m_ginfo->htmlstsh->GetMergedChpx(baseon, m_istd, m_istdpara);
	m_prop.Sprms2SpanPr(m_sprms, &baseon);
}

STDMETHODIMP_(void) HtmlWChpxWriter::Write(CssPropBuffer* cssprop)
{	
	WriteClassAttribute(m_ginfo->ar, m_istd);
	WriteStyleAttribute(m_ginfo->ar, cssprop);
}

STDMETHODIMP_(void) HtmlWChpxWriter::ToCss(CssPropBuffer* cssprop, LPCSTR delim)
{
	ToChp();
	ToCss(&m_prop, cssprop, delim);
}

STDMETHODIMP_(void) HtmlWChpxWriter::ToCss(const HtmlWSpanPr* p, CssPropBuffer* cssprop, LPCSTR delim)
{	
	if(p->mask.symbol)	
		m_ginfo->doc->GetFontTable().Item(p->symbol.oprand.ftcSym, &m_font);
	else
	{
		if(p->idctHint)
			m_ginfo->doc->GetFontTable().Item(p->rgftc[1], &m_font);
		else
			m_ginfo->doc->GetFontTable().Item(p->rgftc[0], &m_font);
	}
	unsigned char utf8name[MAX_PATH] = "";
	int nutf8name = MAX_PATH;
	int nname = wcslen(m_font.name)*2;
	int nret = UTF16LEToUTF8(utf8name, &nutf8name, (const unsigned char*)m_font.name, &nname, 1);
	utf8name[nret] ='\0';
	utf8name[nret+1] = '\0';
	SpanPr2Cssprop(p, cssprop, (LPCSTR)utf8name, '\'', delim);
}
