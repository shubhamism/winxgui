/* -------------------------------------------------------------------------
//	�ļ���		��	html_field.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-3 12:09:52
//	��������	��	
//
//	$Id: html_field.cpp,v 1.12 2006/07/08 00:39:35 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../html_globalinfo.h"
#include "mso/io/html/writer/include/htmlfile.h"
#include "html_field_helper.h"
#include "../html_ranges.h"
#include "../html_textstream.h"
#include "../props/html_chpx.h"
#include "html_field.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ===============
// Default handler
HtmlWFieldHandler::HtmlWFieldHandler(HtmlWGlobalInfo* info) : m_ginfo(info)
{
}
HRESULT HtmlWFieldHandler::HandleBeginMark(HtmlDirectWriterA* ar, KDWField* field)
{
	m_field = field;	
	ar->StartElement(elem_span);
	HtmlWRangesWriter* range = m_ginfo->htmlwrStream->GetRange();	
	WriteClassAttribute(ar, range->GetChpinfo().GetChp().istd);
	CssPropBuffer* cssprop = range->GetCurrentChpxCssprop();
	WriteStyleAttribute(ar, cssprop);
	return S_OK;
}

HRESULT HtmlWFieldHandler::HandleSeparatorMark(HtmlDirectWriterA* ar, KDWField* field)
{
	m_field = field;
	return S_OK;
}

HRESULT HtmlWFieldHandler::HandleEndMark(HtmlDirectWriterA* ar, KDWField* field)
{
	m_field = field;
	Clear();
	ar->EndElement(elem_span);
	return S_OK;
}

UCHAR HtmlWFieldHandler::GetMarkType() const
{
	if(!m_field)
		return mso_fldNoneMark;	
	return m_field->GetMarkType();
}

UCHAR HtmlWFieldHandler::GetFieldType() const
{		
	if(!m_field)
		return mso_fltNone;
	return m_field->GetFieldType();
}

HRESULT HtmlWFieldHandler::AddCodeChar(WCHAR wch)
{
	m_code.append(1, wch);
	return S_OK;
}

HRESULT HtmlWFieldHandler::Clear()
{
	m_code.clear();
	return S_OK;
}

// =========
// Hyperlink
HyperlinkFieldHandler::HyperlinkFieldHandler(HtmlWGlobalInfo* info) : HtmlWFieldHandler(info)
{
}

HRESULT HyperlinkFieldHandler::HandleBeginMark(HtmlDirectWriterA* ar, KDWField* field)
{	
	m_field = field;

	ar->StartElement(elem_span);

	HtmlWRangesWriter* range = m_ginfo->htmlwrStream->GetRange();
	WriteClassAttribute(ar, range->GetChpinfo().GetChp().istd);
	CssPropBuffer* cssprop = range->GetCurrentChpxCssprop();
	WriteStyleAttribute(ar, cssprop);
	ar->StartElement(elem_a);
	return S_OK;
}

HRESULT HyperlinkFieldHandler::HandleSeparatorMark(HtmlDirectWriterA* ar, KDWField* field)
{	
	m_field = field;
	ks_wstring code;	
	if(SUCCEEDED(ParseHyperlinkFieldCode(m_code, code)))
	{
		ar->AddAttribute(htm_attr_href, code.c_str());
		return S_OK;
	}
	return E_FAIL;
}

HRESULT HyperlinkFieldHandler::HandleEndMark(HtmlDirectWriterA* ar, KDWField* field)
{		
	m_field = field;
	ar->EndElement(elem_a);
	ar->EndElement(elem_span);
	Clear();
	return S_OK;
}
