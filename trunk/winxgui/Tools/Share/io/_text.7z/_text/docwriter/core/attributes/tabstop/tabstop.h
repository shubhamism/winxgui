/* -------------------------------------------------------------------------
//	�ļ���		��	tabstop.h
//	������		��	����
//	����ʱ��	��	2004-12-23 15:10:55
//	��������	��	
//	$Id: tabstop.h,v 1.4 2006/03/10 09:48:30 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TABSTOP_H__
#define __TABSTOP_H__


#ifndef __STL_MAP_H__
#include <stl/map.h>
#endif

// -------------------------------------------------------------------------
template<class pType, class vType>
inline __DW_PutVal(pType*& p, const vType& v)
{
	*(vType*)p = v;
	(UINT8*)p += sizeof(vType);
}

// -------------------------------------------------------------------------
class KDWChgTAB
{
private:
	typedef UINT8 itbdDelMax_t;
	typedef itbdDelMax_t itbdAddMax_t;

	// ʹ��map��������������ĸ����ã�DXA����ȷ��һ��λ����Ψһ��һ��TBD��
	typedef INT16 DXA;
	typedef std::map<DXA, TBD> TBDMAP;
	TBDMAP m_tbd;

public:
	// m_bNoTabsΪTRUE����û�г���<Tabs>����
	// m_tbdΪ�մ�������<Tabs>���ԣ���<Tab>���Ը���Ϊ0��
	BOOL m_fNull;

public:
	KDWChgTAB()
	{
		m_fNull = TRUE;
	}
	
	STDMETHODIMP_(VOID) Append(
		IN INT16 dxa, IN const TBD& tbd)
	{
		m_fNull = FALSE;
		m_tbd.insert(std::make_pair(dxa, tbd));
	}
	// @@note:
	//	Size��Null�ķֱ���ʲô�أ�
	//	�����Ʊ�λ���Զ�ʱget_NullΪFALSE��
	//	����ʱSize����Ϊ0��
	//
	STDMETHODIMP_(UINT) Size() const
	{
		return m_tbd.size();
	}
	STDMETHODIMP_(BOOL) get_Null() const
	{
		return m_fNull;
	}
	STDMETHODIMP_(VOID) Clear()
	{
		m_tbd.clear();
		m_fNull = TRUE;
	}
	STDMETHODIMP_(VOID) put_ForceEmpty()
	{
		Clear();
		m_fNull = FALSE;
	}

public:
	STDMETHODIMP_(KDWKernData*) AllocDataAdd(
		IN KDWAutoFreeAlloc* pAlloc) const
	{
		if (m_tbd.empty())
			return _DW_NullKernData();

		const UINT cbData = 
			sizeof(itbdDelMax_t) + 
			sizeof(itbdAddMax_t) +
			m_tbd.size() * (sizeof(DXA) + sizeof(TBD));

		KDWKernData* pKernData = _MsoAllocKernData(pAlloc, cbData);
		pKernData->cb = cbData;

		UINT8* pData = (UINT8*)_MsoPdata(pKernData);
		__DW_PutVal(pData, (itbdDelMax_t)0);
		__DW_PutVal(pData, (itbdAddMax_t)m_tbd.size());

		TBDMAP::const_iterator i = m_tbd.begin();
		for (; i != m_tbd.end(); ++i)
		{
			DXA dxa = i->first;
			__DW_PutVal(pData, dxa);
		}

		i = m_tbd.begin();
		for (; i != m_tbd.end(); ++i)
		{
			TBD tbd = i->second;
			__DW_PutVal(pData, tbd);
		}
		return pKernData;
	}
	STDMETHODIMP_(KDWKernData*) AllocDataDel(
		IN KDWAutoFreeAlloc* pAlloc) const
	{
		if (m_tbd.empty())
			return _DW_NullKernData();

		const UINT cbData = 
			sizeof(itbdDelMax_t) + 
			m_tbd.size() * sizeof(DXA) +
			sizeof(itbdAddMax_t);

		KDWKernData* pKernData = _MsoAllocKernData(pAlloc, cbData);
		pKernData->cb = cbData;

		UINT8* pData = (UINT8*)_MsoPdata(pKernData);
		__DW_PutVal(pData, (itbdDelMax_t)m_tbd.size());

		TBDMAP::const_iterator i = m_tbd.begin();
		for (; i != m_tbd.end(); ++i)
			__DW_PutVal(pData, (DXA)i->first);

		__DW_PutVal(pData, (itbdAddMax_t)0);

		return pKernData;
	}
};

// -------------------------------------------------------------------------
typedef KDWChgTAB const KCDWChgTAB;

// -------------------------------------------------------------------------
#define __DW_AddChgTabPapx(pPropBuf, data)										\
	do {																		\
		if ((data)->cb)															\
			(pPropBuf)->AddPropVar(												\
				sprmPChgTabsPapx, _MsoPdata(data), (data)->cb);					\
	} while(0)

// -------------------------------------------------------------------------
/*
@fn __DW_AddPropAt
@brief
	��һ��propbuffer src��������һ��propbuffer dest��offset����
	Ч�ʽϵ���Σ�գ����Ǳ�������ʹ�ã�����
@arg [in] offset
@arg [in] dest
@arg [in] src
@return
@remark
@*/
inline
STDMETHODIMP_(VOID) __DW_AddPropAt(
	IN UINT offset,
	IN KDWPropBuffer* dest,
	IN const KDWPropBuffer* src)
{
	const UINT cb = dest->Size() - offset;
	LPVOID prop = _alloca(cb);
	CopyMemory(prop, (UINT8*)dest->Data() + offset , cb);

	LPVOID propOffset = _alloca(offset);
	CopyMemory(propOffset, dest->Data(), offset);

	dest->Clear();

	dest->AddProps(propOffset, offset);
	dest->AddProps(src->Data(), src->Size());
	dest->AddProps(prop, cb);
}
// -------------------------------------------------------------------------

#endif /* __TABSTOP_H__ */

// $Log: tabstop.h,v $
// Revision 1.4  2006/03/10 09:48:30  xulingjiao
// �޸�BUG
//
// Revision 1.3  2005/02/24 04:28:39  wangdong
// �����Ʊ�λ��д��˳��
//
