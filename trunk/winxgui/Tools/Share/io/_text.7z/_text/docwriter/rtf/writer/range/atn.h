/* -------------------------------------------------------------------------
//	�ļ���		��	atn.h
//	������		��	���὿
//	����ʱ��	��	2006-2-11 18:31:43
//	��������	��	
//
//	$Id: atn.h,v 1.6 2006/02/16 09:43:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFATN_H__
#define __RTFATN_H__
class RtfDirectWriter;
class RtfWTextStreamWriter;
class RtfWAtnWriter
{
private:
	RtfWTextStreamWriter* m_wrStream;
	const _KDWAtnData* m_atns;
	const KDWUsers* m_atnUsers;
public:
	RtfWAtnWriter(const _KDWAtnData* atns, const KDWUsers* atnUser);
	STDMETHODIMP SetStreamWriter(RtfWTextStreamWriter* wrStream);
	STDMETHODIMP Write(RtfDirectWriter* ar, INT index);
	STDMETHODIMP_(_DW_PlcfCPType*) GetPlcfbkfl(BOOL fStart);	
	STDMETHODIMP_(INT) GetAtnId(INT index);
	STDMETHODIMP_(INT) IsDotAnnotation(INT index);
private:	
	STDMETHODIMP _WriteOwner(RtfDirectWriter* ar, KDWAtn* atn);
	STDMETHODIMP _WriteAnnotation(RtfDirectWriter* ar, INT id);
};

// -------------------------------------------------------------------------
//	$Log: atn.h,v $
//	Revision 1.6  2006/02/16 09:43:06  xulingjiao
//	�޸���ע��ص�BUG
//	
//	Revision 1.1  2006/02/13 01:33:05  xulingjiao
//	rtfwriter�Ѿ�֧����ע��
//	

#endif /* __ATN_H__ */
