/* -------------------------------------------------------------------------
//	�ļ���		��	text_citation_break.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-17 17:46:54
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_CITATION_BREAK_H__
#define __TEXT_CITATION_BREAK_H__

// -------------------------------------------------------------------------

class KTextCitationBreakHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	BOOL		  m_bCustom;
	
public:
	KTextCitationBreakHandler() : m_pDocTarget(NULL), m_bCustom(FALSE)
	{
	}

	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		BOOL bCustom = m_bCustom = FALSE;
		if (pAttrs && pAttrs->GetByID(kso::text_custom_citation_ref, &bCustom) == S_OK)
			m_bCustom = bCustom;
		return S_OK;
	}
	
	STDMETHODIMP EndElement(IN ELEMENTID uElementID);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_CITATION_BREAK_H__ */
