/* -------------------------------------------------------------------------
//	�ļ���		��	html_plcfsepx.h
//	������		��	��ʽΰ
//	����ʱ��	��	2006-7-12 14:37:31
//	��������	��	
//
//	$Id: html_plcfsepx.h,v 1.1 2006/07/13 02:51:29 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTML_PLCFSEPX_H__
#define __HTML_PLCFSEPX_H__

class HtmlWHeaderFooterWriter;
class HtmlDirectWriterA;
class HtmlWGlobalInfo;
class HtmlWSepxsWriter
{
private:
	HtmlWGlobalInfo* m_ginfo;
	const KDWSections* m_sepxs;	
	HtmlWHeaderFooterWriter* m_wrHdFt;
	KDWSections::Enumerator m_enumer;
	BOOL m_fopen;
	INT m_current;
public:
	HtmlWSepxsWriter(HtmlWGlobalInfo* info, KDWSections* sepx);
	STDMETHODIMP_(BOOL) Good() const;
	STDMETHODIMP_(void) Reset();
	STDMETHODIMP Next();
	STDMETHODIMP_(UINT) GetCurrentCp();
	STDMETHODIMP_(UINT) GetNextCp();
	STDMETHODIMP_(void) EnsureWriteEnd();
	STDMETHODIMP_(void) WriteCss();
	STDMETHODIMP_(void) Write();
};
#endif /* __HTML_PLCFSEPX_H__ */
