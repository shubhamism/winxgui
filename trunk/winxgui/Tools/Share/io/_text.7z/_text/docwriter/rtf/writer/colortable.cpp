/* -------------------------------------------------------------------------
//	�ļ���		��	colortable.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:43:04
//	��������	��	
//
//	$Id: colortable.cpp,v 1.3 2006/08/25 08:21:15 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "rtf/writer/include/rtffile.h"
#include "colortable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWColorTable::RtfWColorTable()
{
	// add ico color
	for (INT i = 1; i <= 16; ++i)
		AddColor(Ico2RGB(i));
}

STDMETHODIMP_(void) RtfWColorTable::AddColor(COLORREF clr)
{
	m_colors[clr] = -1;
}

STDMETHODIMP_(void) RtfWColorTable::Write(RtfDirectWriter* ar)
{
	ar->StartGroup(rtf_colortbl, rtf_nilParam, TRUE);
	ar->AddContent(";", 1);
	
	ColorMap::iterator it = m_colors.begin();
	for (INT i = 1; it != m_colors.end(); ++it, ++i)
	{
		const COLORREF& clr = it->first;
		ar->AddAttribute(rtf_red,  GetRValue(clr));
		ar->AddAttribute(rtf_green, GetGValue(clr));
		ar->AddAttribute(rtf_blue,  GetBValue(clr));
		ar->AddContent(";", 1);

		// ����ID
		it->second = i;
	}

	ar->EndGroup();
}

STDMETHODIMP_(UINT) RtfWColorTable::GetColorIndex(COLORREF clr)
{
	if(clr == mso_shdAutoColor)
		return 0;
	ColorMap::iterator it = m_colors.find(clr);
	ASSERT_ONCE(it != m_colors.end());
	ASSERT_ONCE(it->second >= 0);
	if(it != m_colors.end())
		return it->second;
	return 0;
}