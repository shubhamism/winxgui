/* -------------------------------------------------------------------------
//	�ļ���		��	office_body.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-16 18:46:19
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "office_body.h"
#include <texttable/text_table.h>
#include <textframe/text_frame.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

KOfficeBodyHandler::~KOfficeBodyHandler()
{
	delete m_tableElement;
	delete m_frameElement;
}

STDMETHODIMP KOfficeBodyHandler::EnterSubElement(
											IN ELEMENTID uSubElementID,
											OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_p:
		m_paraElement.Init(m_pDocTarget);
		*ppHandler = &m_paraElement;
		break;
	case text_section:
		m_sectElement.Init(m_pDocTarget);
		*ppHandler = &m_sectElement;
		break;
	case kso_schema::text_table:
		if (m_tableElement == NULL)
		{
			m_tableElement = new KTextTableHandler;
		}
		m_tableElement->Init(m_pDocTarget);
		*ppHandler = m_tableElement;
		break;
	case text_settings:
		m_settingElement.Init(m_pDocTarget);
		*ppHandler = &m_settingElement;
		break;
	case text_frame:
		if (m_frameElement == NULL)
		{
			m_frameElement = new KTextFrameHandler;
		}
		m_frameElement->Init(m_pDocTarget);
		*ppHandler = m_frameElement;
		break;
	case draw_canvas:
		return IO_E_IGNORE;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
