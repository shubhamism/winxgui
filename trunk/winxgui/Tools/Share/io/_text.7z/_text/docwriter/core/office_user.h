/* -------------------------------------------------------------------------
//	�ļ���		��	office_user.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-14 17:49:19
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __OFFICE_USER_H__
#define __OFFICE_USER_H__

// -------------------------------------------------------------------------

class KOfficeUserHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};

// -------------------------------------------------------------------------

#endif /* __OFFICE_USER_H__ */
