/* -------------------------------------------------------------------------
//	�ļ���		��	text_row.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-23 15:24:19
//	��������	��	
//	$Id: text_row.cpp,v 1.11 2005/06/02 03:42:17 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include <attr/stocktrans.h>
#include <kso/io/v6/std/text_table.h>
#include "text_row.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace kso_text;
// -------------------------------------------------------------------------

STDMETHODIMP KTextRowHandler::StartElement(
						  IN ELEMENTID uElementID,
						  IN KROAttributes* pAttrs)
{
	m_tblPr.Reset();
	m_tblPr.typeCellWidth = mso_vetDxa;
	
	HRESULT hr;
	union
	{
		INT nValue;
		KROAttributes* tblCellMar;
		KROAttributes* tblBorders;
		KROAttributes* tblShd;
		KROAttributes* rowHeight;
	};
	
	pAttrs->GetByID(kso_schema::text_align, &m_tblPr.jc);
	
	hr = pAttrs->GetByID(kso_schema::text_cellSpacing, &nValue);
	if (SUCCEEDED(hr))
		m_tblPr.tblCellSpacing.put_Value(nValue);
	
	hr = pAttrs->GetByID(kso_schema::text_leftIndent, &nValue);
	if (SUCCEEDED(hr))
		m_tblPr.tblInd.put_Value(nValue);

	hr = pAttrs->GetByID(kso_schema::text_cellMargin, &tblCellMar);
	if (SUCCEEDED(hr))
	{
		INT nValue;
		static ATTRID const marginType[] =
		{
			kso_schema::text_top,
			kso_schema::text_left,
			kso_schema::text_bottom,
			kso_schema::text_right,
		};
		for (INT i = 0; i < countof(marginType); ++i)
		{
			hr = tblCellMar->GetByID(marginType[i], &nValue);
			if (SUCCEEDED(hr))
				m_tblPr.tblCellMar[i].put_Value(nValue);
		}
	}

	static ATTRID const borderType[] =
	{
		kso_schema::text_top,
			kso_schema::text_left,
			kso_schema::text_bottom,
			kso_schema::text_right,
			kso_schema::text_horzInside,
			kso_schema::text_vertInside
	};

	hr = pAttrs->GetByID(kso_schema::text_borders, &tblBorders);
	if (SUCCEEDED(hr))
	{
		KROAttributes* border;
		for (INT i = 0; i < countof(borderType); ++i)
		{
			hr = tblBorders->GetByID(borderType[i], &border);
			if (SUCCEEDED(hr))
				TransBrcEx(m_tblPr.tblBorders[i], border);
		}
	}
	else
	{
		for (INT i = 0; i < countof(borderType); ++i)
		{
			m_tblPr.tblBorders[i].put_Value(mso_brcexDelete);
		}
	}

	hr = pAttrs->GetByID(draw_fill, &tblShd);
	if (SUCCEEDED(hr))
		TransShdEx(m_tblPr.shd, tblShd);

	pAttrs->GetByID(kso_schema::text_fixLayout, &m_tblPr.tblFixedLayout);
	
	hr = pAttrs->GetByID(kso_schema::text_noSplit, &nValue);
	if (SUCCEEDED(hr))
		m_tblPr.cantSplit = nValue;

	hr = pAttrs->GetByID(kso_schema::text_headerRow, &nValue);
	if (SUCCEEDED(hr))
		m_tblPr.tblHeader = nValue;

	hr = pAttrs->GetByID(kso_schema::text_height, &rowHeight);
	if (SUCCEEDED(hr))
	{
		INT hrule;
		rowHeight->GetByID(kso_schema::text_rule, &hrule);
		
		INT hval = 0;
		rowHeight->GetByID(kso_schema::text_val, &hval);
		
		if (hrule == hruleExact)
			m_tblPr.trHeight.put_Exact(hval);
		else
			m_tblPr.trHeight.put_AtLeast(hval);
	}
	
	m_pDocTarget->rowtbl_NewRow(&m_tblPr);
	return S_OK;
}

STDMETHODIMP KTextRowHandler::EnterSubElement(
							 IN ELEMENTID uSubElementID,
							 OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case kso_schema::text_cell:
		m_cellElement.Init(m_pDocTarget);
		*ppHandler = &m_cellElement;
		break;
	case kso::text_p:
		m_rowPara.Init(m_pDocTarget);
		*ppHandler = &m_rowPara;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
STDMETHODIMP KRowEndSpanHandler::StartElement(
	IN ELEMENTID uElementID,
	IN KROAttributes* pAttrs)
{
	return S_OK;
}

STDMETHODIMP KRowEndSpanHandler::EnterSubElement(
	IN ELEMENTID uSubElementID,
	OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_range_begin:
		m_rangeBeginElement.Init(m_pDocTarget);
		*ppHandler = &m_rangeBeginElement;
		break;
	case text_range_end:
		m_rangeEndElement.Init(m_pDocTarget, 1);
		*ppHandler = &m_rangeEndElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;	
}

STDMETHODIMP KRowEndParaHandler::StartElement(
	IN ELEMENTID uElementID,
	IN KROAttributes* pAttrs)
{
	return S_OK;
}

STDMETHODIMP KRowEndParaHandler::EnterSubElement(
	IN ELEMENTID uSubElementID,
	OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case kso::text_span:
		m_rowSpan.Init(m_pDocTarget);
		*ppHandler = &m_rowSpan;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: text_row.cpp,v $
// Revision 1.11  2005/06/02 03:42:17  wangdong
// ������ǩ��
//
