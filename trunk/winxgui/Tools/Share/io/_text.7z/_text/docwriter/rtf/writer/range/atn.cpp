/* -------------------------------------------------------------------------
//	�ļ���		��	atn.cpp
//	������		��	���὿
//	����ʱ��	��	2006-2-11 18:41:04
//	��������	��	
//
//	$Id: atn.cpp,v 1.8 2006/07/31 06:29:16 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../include/rtffile.h"
#include "../textstream.h"
#include "atn.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWAtnWriter::RtfWAtnWriter(const _KDWAtnData* atns, const KDWUsers* atnUser) : m_atns(atns), m_atnUsers(atnUser)
{	
}

STDMETHODIMP RtfWAtnWriter::SetStreamWriter(RtfWTextStreamWriter* wrStream)
{
	m_wrStream = wrStream;
	return S_OK;
}

STDMETHODIMP RtfWAtnWriter::Write(RtfDirectWriter* ar, INT index)
{		
	if(index >= m_atns->Count())	
	{
		ASSERT_ONCE(0);
		return E_FAIL;
	}	
	_WriteAnnotation(ar, index);
	return S_OK;
}

STDMETHODIMP RtfWAtnWriter::_WriteOwner(RtfDirectWriter* ar, KDWAtn* atn)
{
	const _DW_UserNameInfo* atnUser = m_atnUsers->GetUserNameInfo(atn->GetOnwerId());
	if(!atnUser)
		return E_FAIL;
	ar->StartGroup(rtf_atnid, rtf_nilParam, TRUE);
	ar->AddContentWcs(atnUser->userNameAbbr);
	ar->EndGroup();
	ar->StartGroup(rtf_atnauthor, rtf_nilParam, TRUE);
	ar->AddContentWcs(atnUser->userName);
	ar->EndGroup();
	return S_OK;
}

STDMETHODIMP RtfWAtnWriter::_WriteAnnotation(RtfDirectWriter* ar, INT index)
{
	KDWAtn atn = m_atns->Item(index);
	_WriteOwner(ar, &atn);
	ar->AddAttribute(rtf_chatn);
	ar->StartGroup(rtf_annotation, rtf_nilParam, TRUE);
	char buf[35] = "";
	if(!IsDotAnnotation(index))
	{
		DWORD id = GetAtnId(index);
		ar->StartGroup(rtf_atnref, rtf_nilParam, TRUE);		
		_itoa(id, buf, 10);
		ar->AddContent(buf, strlen(buf));
		ar->EndGroup();
	}	
		ar->StartGroup(rtf_atndate, rtf_nilParam, TRUE);
		_itoa((INT32&)atn.GetDttm(), buf, 10);
		ar->AddContent(buf, strlen(buf));
		ar->EndGroup();	
		KDWRange txtRange = atn.GetTxtRange();
		INT cch = txtRange.cpNext-txtRange.cp;		
		--cch;
		m_wrStream->Write(ar, txtRange.cp, cch, DW_SUBDOC_ANNOTATION);
	ar->EndGroup();
	return S_OK;
}

STDMETHODIMP_(_DW_PlcfCPType*) RtfWAtnWriter::GetPlcfbkfl(BOOL fStart)
{
	if(fStart)
		return &m_atns->m_plcfAtnbkf;
	else
		return &m_atns->m_plcfAtnbkl;
}

STDMETHODIMP_(INT) RtfWAtnWriter::GetAtnId(INT index)
{
	return m_atns->m_Atnbkmks.at(index).lTagBkmk;
}

STDMETHODIMP_(INT) RtfWAtnWriter::IsDotAnnotation(INT index)
{	
	return m_atns->m_plcfAtnbkf.at(index) == m_atns->m_plcfAtnbkl.at(index);
}