/* -------------------------------------------------------------------------
//	�ļ���		��	text_row.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-23 15:24:28
//	��������	��	
//	$Id: text_row.h,v 1.6 2005/06/02 03:42:17 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXT_ROW_H__
#define __TEXT_ROW_H__

#ifndef __TEXT_CELL_H__
#include "text_cell.h"
#endif

#ifndef __TEXT_RANGE_BEGIN_H__
#include <core/text_range_begin.h>
#endif

#ifndef __TEXT_RANGE_END_H__
#include <core/text_range_end.h>
#endif


// -------------------------------------------------------------------------
class KRowEndSpanHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KTextRangeBeginHandler m_rangeBeginElement;
	KTextRangeEndHandler m_rangeEndElement;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

class KRowEndParaHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KRowEndSpanHandler m_rowSpan;
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};


class KTextRowHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	KTextCellHandler m_cellElement;
	KRowEndParaHandler m_rowPara;
	KDWRowTablePr m_tblPr;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID,
		IN KROAttributes* pAttrs);

	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler);
};

// -------------------------------------------------------------------------

#endif /* __TEXT_ROW_H__ */
// $Log: text_row.h,v $
// Revision 1.6  2005/06/02 03:42:17  wangdong
// ������ǩ��
//
