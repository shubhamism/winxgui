/* -------------------------------------------------------------------------
//	�ļ���		��	text_font.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-19 20:01:27
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <doctarget.h>
#include "text_font.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextFontHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	ASSERT(pAttrs);

	HRESULT hr;

	UINT uFontID;
	hr = pAttrs->GetByID(office_font_id, &uFontID);
	if (hr != S_OK)
		{ ASSERT(false); return E_FAIL; }

	BSTR szFontName;
	hr = pAttrs->GetByID(office_font_name, &szFontName);
	if (hr != S_OK)
		{ ASSERT(false); return E_FAIL; }

//	const KsoVariant* pPanose;
//	pAttrs->GetIndex(office_panose, &pPanose);
	BSTR szPanose;
	hr = pAttrs->GetByID(office_panose, &szPanose);
	if (hr != S_OK)
		{ ASSERT(false); return E_FAIL; }

	BSTR szSignature;
	hr = pAttrs->GetByID(office_signature, &szSignature);
	if (hr != S_OK)
		{ ASSERT(false); return E_FAIL; }

	BSTR szAltFontName = NULL;
	pAttrs->GetByID(office_font_altername, &szAltFontName);

	UINT uFamily = FF_DONTCARE;		// Դ��LOGFONT.lfPitchAndFamily
	hr = pAttrs->GetByID(office_font_family, &uFamily);

	UINT charset = DEFAULT_CHARSET;
	hr = pAttrs->GetByID(kso::office_font_charset, &charset);
	

	KDWFont ffn;
	ffn.name = szFontName;
	ffn.altername = szAltFontName;
	ffn.family = uFamily;
	ffn.charset = charset;	// Դ��LOGFONT.lfCharSet
	ffn.fTrueType = TRUE;
	ffn.reserved = 0;
	memcpy(&(ffn.panose), szPanose, sizeof(ffn.panose));
	memcpy(&(ffn.signature), szSignature, sizeof(ffn.signature));

	ASSERT(m_pDocTarget);
	KDWFontTable& theTbl = m_pDocTarget->GetFontTable();
	UINT uID;
	theTbl.Add(ffn, &uID);

	KDWFontIDMap& theMap = m_pDocTarget->GetFontIDMap();
	theMap[uFontID] = uID;

	return S_OK;
}

// -------------------------------------------------------------------------
STDMETHODIMP KTextDefaultFontHandler::StartElement(
	IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	HRESULT hr = S_OK;
	if (pAttrs)
	{
		ASSERT(m_pDocTarget);
		const KDWFontIDMap& FontMap = m_pDocTarget->GetFontIDMap();
		INT value = -1;
		if (SUCCEEDED(pAttrs->GetByID(kso::office_ascii, &value)))
		{
			KDWFontIDMapIt it = FontMap.find(value);
			if (it != FontMap.end())
				m_pDocTarget->GetStyleSheet().put_DefaultFont_ASCII((*it).second);
			else
				ASSERT(0);
		}
		if (SUCCEEDED(pAttrs->GetByID(kso::office_fareast, &value)))
		{
			KDWFontIDMapIt it = FontMap.find(value);
			if (it != FontMap.end())
				m_pDocTarget->GetStyleSheet().put_DefaultFont_FarEast((*it).second);
			else
				ASSERT(0);
		}
		if (SUCCEEDED(pAttrs->GetByID(kso::office_complex, &value)))
		{
			KDWFontIDMapIt it = FontMap.find(value);
			if (it != FontMap.end())
				m_pDocTarget->GetStyleSheet().put_DefaultFont_Complex((*it).second);
			else
				ASSERT(0);
		}
	}
	return hr;
}

// -------------------------------------------------------------------------
STDMETHODIMP KTextFontsHandler::EnterSubElement(
	IN ELEMENTID uSubElementID,
	OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case office_font:
		m_FontElement.Init(m_pDocTarget);
		*ppHandler = &m_FontElement;
		break;
	case office_default_fonts:
		m_DefaultFontElement.Init(m_pDocTarget);
		*ppHandler = &m_DefaultFontElement;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;	
}

// -------------------------------------------------------------------------
