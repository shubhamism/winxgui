/* -------------------------------------------------------------------------
//	�ļ���		��	sepx.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 16:58:52
//	��������	��	
//
//	$Id: sepx.cpp,v 1.8 2006/09/20 01:54:04 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "sepx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWSepxWriter::RtfWSepxWriter()
{
	prop.Reset();
}

STDMETHODIMP_(RtfWSectionPr&) RtfWSepxWriter::GetSep()
{
	return prop;
}

STDMETHODIMP_(void) RtfWSepxWriter::Write(RtfDirectWriter* ar, RtfWGlobalInfo* info, const KDWSprmList* sprms)
{	
	prop.Reset();
	Sprms2RtfWSectionPr(sprms, &prop);

	ar->AddAttribute(rtf_sectd);
	Write(ar, &prop, info);
}

STDMETHODIMP_(void) RtfWSepxWriter::Write(
	RtfDirectWriter* ar, const RtfWSectionPr* p, RtfWGlobalInfo* info, const RtfWSectionPr* def)
{	
	// ҳ��
	_AddAttributeNotdefval(p->nfcPgn, def->nfcPgn, ar, GetNfcCtrl(p->nfcPgn, numberformatctrls::which_pgn), rtf_nilParam);		
	if(p->fPgnRestart)
	{
		ar->AddAttribute(rtf_pgnrestart);
		ar->AddAttribute(rtf_pgnstarts, p->pgnStart);
	}
	_AddAttributeNotdefval(p->iHeadingPgn, def->iHeadingPgn, ar, rtf_pgnhn, p->iHeadingPgn);
	_AddAttributeNotdefval(p->cnsPgn, def->cnsPgn, ar, GetCnsPgnCtrl(p->cnsPgn), rtf_nilParam);	
	
	_AddAttribute(ar, GetSectBreakCtrl(p->bkc), rtf_nilParam);
	
	// ҳ����Ϣ
	_AddAttributeNotdefval(p->dmPaperReq, def->dmPaperReq, ar, rtf_psz, p->dmPaperReq);
	_AddAttribute(ar, rtf_pgwsxn, p->xaPage);
	_AddAttribute(ar, rtf_pghsxn, p->yaPage);
	_AddAttribute(ar, rtf_marglsxn, p->dxaLeft);
	_AddAttribute(ar, rtf_margrsxn, p->dxaRight);
	_AddAttribute(ar, rtf_margtsxn, p->dyaTop);
	_AddAttribute(ar, rtf_margbsxn, p->dyaBottom);
	_AddAttribute(ar, rtf_guttersxn, p->dzaGutter);
	if(p->dmOrientPage == mso_PageLandscape)
		ar->AddAttribute(rtf_lndscpsxn);
	_AddAttributeNotdefval(p->fTitlePage, def->fTitlePage, ar, rtf_titlepg, p->fTitlePage);
	_AddAttribute(ar, rtf_headery, p->dyaHdrTop);
	_AddAttribute(ar, rtf_footery, p->dyaHdrBottom);
	
	// ҳ�洹ֱ����
	_AddAttributeNotdefval(p->vjc, def->vjc, ar, GetSectVjcCtrl(p->vjc), rtf_nilParam);
	
#if 1
	// ҳ��߿�
	WriteBrcCtrl(p->brcTop, ar, info->colors, rtf_pgbrdrt);
	WriteBrcCtrl(p->brcBottom, ar, info->colors, rtf_pgbrdrb);
	WriteBrcCtrl(p->brcLeft, ar, info->colors, rtf_pgbrdrl);
	WriteBrcCtrl(p->brcRight, ar, info->colors, rtf_pgbrdrr);
	if( p->pgbProp.offsetFrom == mso_pgbFromText &&
		p->pgbProp.pageDepth == mso_pgbback )
		ar->AddAttribute(rtf_pgbrdropt, 8);
	else if( p->pgbProp.offsetFrom == mso_pgbFromEdge &&
			 p->pgbProp.pageDepth == mso_pgbFront)
		ar->AddAttribute(rtf_pgbrdropt, 32);
	else if( p->pgbProp.offsetFrom == mso_pgbFromEdge &&
			 p->pgbProp.pageDepth == mso_pgbback)
		ar->AddAttribute(rtf_pgbrdropt, 40);
	else
	{
		ar->AddAttribute(rtf_pgbrdropt, p->pgbProp.applyTo);
	}
#endif
	
	// ����
	_AddAttributeNotdefval(p->dxtCharSpace, def->dxtCharSpace, ar, rtf_sectexpand, p->dxtCharSpace);
	_AddAttributeNotdefval(p->dyaLinePitch, def->dyaLinePitch, ar, rtf_sectlinegrid, p->dyaLinePitch);
	_AddAttributeNotdefval(p->clm, def->clm, ar, GetClmCtrl(p->clm), rtf_nilParam);
	
	// ����		
	_AddAttributeNotdefval(p->ccolM1, def->ccolM1, ar, rtf_cols, p->ccolM1+1);
	_AddAttributeNotdefval(p->dxaColumns, def->dxaColumns, ar, rtf_colsx, p->dxaColumns);
	_AddAttributeNotdefval(p->fLBetween, def->fLBetween, ar, rtf_linebetcol, p->fLBetween);
	if(!p->fEvenlySpaced)
	{
		for(UINT i=0; i<=p->ccolM1; ++i)
		{
			ar->AddAttribute(rtf_colno, i+1);				
			_AddAttributeNotdefval(p->rgdxaColumnWidth[i], def->rgdxaColumnWidth[i], ar, rtf_colw, p->rgdxaColumnWidth[i]);
			_AddAttributeNotdefval(p->rgdxaColumnSpace[i], def->rgdxaColumnSpace[i], ar, rtf_colsr, p->rgdxaColumnSpace[i]);
		}
	}
	
	// ��ע
	RtfControl ftnnc = GetNfcCtrl(p->FNNumFmt, numberformatctrls::which_fnd);
	if (ftnnc != rtf_blank)
		_AddAttributeNotdefval(p->FNNumFmt, def->FNNumFmt, ar, ftnnc, rtf_nilParam);

	_AddAttributeNotdefval(p->FNPos, def->FNPos, ar, GetFootnotePosCtrl(p->FNPos), rtf_nilParam);
	_AddAttributeNotdefval(p->FNNumStart, def->FNNumStart, ar, rtf_sftnstart, p->FNNumStart);
	_AddAttributeNotdefval(p->FNRestart, def->FNRestart, ar, GetFootnoteRestartCtrl(p->FNRestart), rtf_nilParam);
	
	// βע
	RtfControl aftnnc = GetNfcCtrl(p->ENNumFmt, numberformatctrls::which_end);
	if (aftnnc != rtf_blank)
		_AddAttributeNotdefval(p->ENNumFmt, def->ENNumFmt, ar, aftnnc, rtf_nilParam);

	_AddAttributeNotdefval(p->ENStart, def->ENStart, ar, rtf_saftnstart, p->ENStart);
	_AddAttributeNotdefval(p->ENRestart, def->ENRestart, ar, GetEndnoteRestartCtrl(p->ENRestart), rtf_nilParam);
	
	// ���ַ���
	_AddAttributeNotdefval(p->wTextFlow, def->wTextFlow, ar, rtf_stextflow, p->wTextFlow);
	
	// ����
	// "ȡ��βע"BUGBUG: �������м�㲻֧��
	_AddBoolAttribute(ar, rtf_endnhere, p->fEndNote);
	
	_AddAttributeNotdefval(p->dmBinFirst, def->dmBinFirst, ar, rtf_binfsxn, p->dmBinFirst);
	_AddAttributeNotdefval(p->dmBinOther, def->dmBinOther, ar, rtf_binsxn, p->dmBinOther);
}