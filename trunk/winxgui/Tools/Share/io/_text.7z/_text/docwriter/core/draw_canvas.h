/* -------------------------------------------------------------------------
//	�ļ���		��	draw_canvas.h
//	������		��	�ݽ���
//	����ʱ��	��	2005-7-26 16:31:42
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __DRAW_CANVAS_H__
#define __DRAW_CANVAS_H__

#ifndef __DRAW_RULES_H__
#include "draw_rules.h"
#endif

// -------------------------------------------------------------------------
class KDrawCanvasHandler : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
	KDrawRulesHandler m_RulesElem;

public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElement, OUT IKElementHandler** ppv)
	{
		if (kso::draw_rules == uSubElement)
		{
			m_RulesElem.Init(m_pDocTarget);
			*ppv = &m_RulesElem;

			return S_OK;
		}

		_kso_UnexpectedElement(uSubElement);
		return E_UNEXPECTED;
	}
};

// -------------------------------------------------------------------------

#endif /* __DRAW_CANVAS_H__ */
