/* -------------------------------------------------------------------------
//	�ļ���		��	usernames.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 15:42:45
//	��������	��	
//
//	$Id: usernames.h,v 1.1 2006/01/04 03:41:56 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __USERNAMES_H__
#define __USERNAMES_H__

/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
class RtfWUserNames
{
private:
	const KDWUsers* m_AnnUser;

public:
	RtfWUserNames(const KDWUsers* AnnUser) : m_AnnUser(AnnUser)
	{
	}
	STDMETHODIMP_(const _DW_UserNameInfo*) GetAnnUserInfo(UINT index) const
	{
		return m_AnnUser->GetUserNameInfo(index);
	}
};
// -------------------------------------------------------------------------
//	$Log: usernames.h,v $
//	Revision 1.1  2006/01/04 03:41:56  xulingjiao
//	*** empty log message ***
//	

#endif /* __USERNAMES_H__ */
