/* -------------------------------------------------------------------------
//	�ļ���		��	text_field_begin.h
//	������		��	����
//	����ʱ��	��	2004-8-23 15:39:04
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXT_FIELD_BEGIN_H__
#define __TEXT_FIELD_BEGIN_H__

// -------------------------------------------------------------------------

class KTextFieldBeginHandler : public KFakeUnknown<KElementHandler>
{
private:
	KDWDocTarget* m_pDocTarget;
	
public:
	STDMETHODIMP_(void) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}
	
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
};	

// -------------------------------------------------------------------------

#endif /* __TEXT_FIELD_BEGIN_H__ */
