/* -------------------------------------------------------------------------
//	�ļ���		��	table.cpp
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:02:57
//	��������	��	
//
//	$Id: table.cpp,v 1.5 2006/09/20 01:54:04 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../globalinfo.h"
#include "rtf/writer/include/rtffile.h"
#include "tablehelper.h"
#include "table.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

RtfWTableWriter::RtfWTableWriter(RtfWGlobalInfo* info, const KDWPlcfPapx* papxs)
	: m_ginfo(info), m_papxs(papxs)
{
}

STDMETHODIMP RtfWTableWriter::Write(RtfDirectWriter* ar, UINT index)
{
	KDWSprmList sprms = m_papxs->Item(index).prop;
	Doc2RtfRowTablePr prop;
	if(SUCCEEDED(Sprms2RtfTablePr(&sprms, &prop)))
	{
		Write(ar,&prop);
	}
	return E_FAIL;
}

STDMETHODIMP_(void) RtfWTableWriter::WriteCellSpacing(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p)
{		
	_AddAttributeNotdefval(p->tblCellSpacing.wVal, 0, ar, rtf_trspdl, p->tblCellSpacing.wVal);
	_AddAttributeNotdefval(p->tblCellSpacing.wVal, 0, ar, rtf_trspdt, p->tblCellSpacing.wVal);
	_AddAttributeNotdefval(p->tblCellSpacing.wVal, 0, ar, rtf_trspdb, p->tblCellSpacing.wVal);
	_AddAttributeNotdefval(p->tblCellSpacing.wVal, 0, ar, rtf_trspdr, p->tblCellSpacing.wVal);
	
	_AddAttributeNotdefval(p->tblCellSpacing.type, 0, ar, rtf_trspdfl, p->tblCellSpacing.type);
	_AddAttributeNotdefval(p->tblCellSpacing.type, 0, ar, rtf_trspdft, p->tblCellSpacing.type);
	_AddAttributeNotdefval(p->tblCellSpacing.type, 0, ar, rtf_trspdfb, p->tblCellSpacing.type);
	_AddAttributeNotdefval(p->tblCellSpacing.type, 0, ar, rtf_trspdfr, p->tblCellSpacing.type);				
}
STDMETHODIMP_(void) RtfWTableWriter::WriteDefCellMargin(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p)
{	
	INT16 trpaddl = p->tblCellMar[mso_tcMarginLeft].wVal;
	INT16 trpaddt = p->tblCellMar[mso_tcMarginTop].wVal;
	INT16 trpaddb = p->tblCellMar[mso_tcMarginBottom].wVal;
	INT16 trpaddr = p->tblCellMar[mso_tcMarginRight].wVal;
	_AddAttributeNotdefval(trpaddl, 0, ar, rtf_trpaddl, trpaddl);
	_AddAttributeNotdefval(trpaddt, 0, ar, rtf_trpaddt, trpaddt);
	_AddAttributeNotdefval(trpaddb, 0, ar, rtf_trpaddb, trpaddb);
	_AddAttributeNotdefval(trpaddr, 0, ar, rtf_trpaddr, trpaddr);
	
	UINT8 trpaddfl = p->tblCellMar[mso_tcMarginLeft].type;
	UINT8 trpaddft = p->tblCellMar[mso_tcMarginTop].type;
	UINT8 trpaddfb = p->tblCellMar[mso_tcMarginBottom].type;
	UINT8 trpaddfr = p->tblCellMar[mso_tcMarginRight].type;
	_AddAttributeNotdefval(trpaddfl, 0, ar, rtf_trpaddfl, trpaddfl);
	_AddAttributeNotdefval(trpaddft, 0, ar, rtf_trpaddft, trpaddft);
	_AddAttributeNotdefval(trpaddfb, 0, ar, rtf_trpaddfb, trpaddfb);
	_AddAttributeNotdefval(trpaddfr, 0, ar, rtf_trpaddfr, trpaddfr);				
}

STDMETHODIMP_(void) RtfWTableWriter::WriteCells(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p)
{
	INT i;
	for(i=0; i<p->m_cells.size(); ++i)
	{
		Doc2RtfCellPr cl = p->m_cells[i];
		RtfControl clhmg = GetTcHoriMergeCtrl(cl.horiMerge);
		if(clhmg != rtf_unknown)
			ar->AddAttribute(clhmg);

		RtfControl vmctrl = GetTcVertMergeCtrl(cl.vertMerge);
		if(vmctrl != rtf_unknown)
			ar->AddAttribute(vmctrl);

		RtfControl clvaln = GetTcVergAlignCtrl(cl.vertAlign);
		_AddAttribute(ar, clvaln, rtf_nilParam);

		if(cl.tcBorders[mso_tcBrcLeft].brcexValue != 0)
			WriteBrcCtrl(cl.tcBorders[mso_tcBrcLeft], ar, m_ginfo->colors, rtf_clbrdrl);
		else
			WriteBrcCtrl(p->tblBorders[mso_tblBrcLeft], ar, m_ginfo->colors, rtf_clbrdrl);
		
		if(cl.tcBorders[mso_tcBrcRight].brcexValue != 0)
			WriteBrcCtrl(cl.tcBorders[mso_tcBrcRight], ar, m_ginfo->colors, rtf_clbrdrr);
		else
			WriteBrcCtrl(
				p->tblBorders[mso_tblBrcRight],
				ar,m_ginfo->colors,
				rtf_clbrdrr);
		
		if(cl.tcBorders[mso_tcBrcTop].brcexValue != 0)
			WriteBrcCtrl(cl.tcBorders[mso_tcBrcTop], ar, m_ginfo->colors, rtf_clbrdrt);
		else
			WriteBrcCtrl(
				p->tblBorders[mso_tblBrcTop],
				ar,m_ginfo->colors,
				rtf_clbrdrt);

		if(cl.tcBorders[mso_tcBrcBottom].brcexValue != 0)
			WriteBrcCtrl(cl.tcBorders[mso_tcBrcBottom], ar, m_ginfo->colors, rtf_clbrdrb);
		else
			WriteBrcCtrl(
			p->tblBorders[mso_tblBrcBottom],
			ar,m_ginfo->colors,
			rtf_clbrdrb);
		
		RtfControl cltextfolow = GetTextflowCtrl(cl.textFlow, textflowctrls::which_cell);
		_AddAttribute(ar, cltextfolow, rtf_nilParam);
		
		// ���ǶԵ�rtf_clpadl��Ӧmso_tcMarginTop���޸���29017��BUG
		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginTop].wVal, 
			0, ar, rtf_clpadl, cl.tcMar[mso_tcMarginTop].wVal);

		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginBottom].wVal,
			0, ar, rtf_clpadb, cl.tcMar[mso_tcMarginBottom].wVal);

		// ���ǶԵ�rtf_clpadt��Ӧmso_tcMarginLeft���޸���29017��BUG
		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginLeft].wVal,
			0, ar, rtf_clpadt, cl.tcMar[mso_tcMarginLeft].wVal);

		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginRight].wVal,
			0, ar, rtf_clpadr, cl.tcMar[mso_tcMarginRight].wVal);

		// ���ǶԵ�rtf_clpadfl��Ӧmso_tcMarginTop���޸���29017��BUG
		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginTop].type,
			0, ar, rtf_clpadfl, cl.tcMar[mso_tcMarginTop].type);

		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginBottom].type,
			0, ar, rtf_clpadfb, cl.tcMar[mso_tcMarginBottom].type);

		// ���ǶԵ�rtf_clpadft��Ӧmso_tcMarginLeft���޸���29017��BUG
		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginLeft].type,
			0, ar, rtf_clpadft, cl.tcMar[mso_tcMarginLeft].type);

		_AddAttributeNotdefval(cl.tcMar[mso_tcMarginRight].type,
			0, ar, rtf_clpadfr, cl.tcMar[mso_tcMarginRight].type);
		
		UINT8 fFitText = cl.tcFitText;
		_AddBoolAttribute(ar, rtf_clFitText, fFitText);
		
		_AddBoolAttribute(ar, rtf_clNoWrap, cl.noWrap);

		WriteCellShdCtrl(cl.shd, m_ginfo->colors, ar);
		
		ar->AddAttribute(rtf_cellx, cl.dxaTC);
	}		
}

STDMETHODIMP_(void) RtfWTableWriter::WriteTTableBorders(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p)
{
	WriteBrcCtrl(p->tblBorders[mso_tblBrcTop], ar, m_ginfo->colors, rtf_trbrdrt);
	WriteBrcCtrl(p->tblBorders[mso_tblBrcBottom], ar, m_ginfo->colors, rtf_trbrdrb);
	WriteBrcCtrl(p->tblBorders[mso_tblBrcLeft], ar, m_ginfo->colors, rtf_trbrdrl);
	WriteBrcCtrl(p->tblBorders[mso_tblBrcRight], ar, m_ginfo->colors, rtf_trbrdrr);
	WriteBrcCtrl(p->tblBorders[mso_tblBrcHorzInside], ar, m_ginfo->colors, rtf_trbrdrh);
	WriteBrcCtrl(p->tblBorders[mso_tblBrcVertInside], ar, m_ginfo->colors, rtf_trbrdrv);
}
STDMETHODIMP_(void) RtfWTableWriter::WriteTablePosition(RtfDirectWriter* ar, const Doc2RtfRowTablePr* p)
{			
	_AddAttributeNotdefval(p->tblPos.leftFromText, 0, ar, rtf_tdfrmtxtLeft, p->tblPos.leftFromText);
	_AddAttributeNotdefval(p->tblPos.rightFromText, 0, ar, rtf_tdfrmtxtRight, p->tblPos.rightFromText);
	_AddAttributeNotdefval(p->tblPos.topFromText, 0, ar, rtf_tdfrmtxtTop, p->tblPos.topFromText);
	_AddAttributeNotdefval(p->tblPos.bottomFromText, 0, ar, rtf_tdfrmtxtBottom, p->tblPos.bottomFromText);
	RtfControl pcVertCtrl = GetVpcCtrl(p->tblPos.pcVert, vpcctrls::which_tablevpc);
	_AddAttributeNotdefval(p->tblPos.pcVert, mso_pcVertMargin, ar, pcVertCtrl, rtf_nilParam);
	RtfControl pcHorzCtrl = GetHpcCtrl(p->tblPos.pcHorz, hpcctrls::which_tablehpc);
	_AddAttributeNotdefval(p->tblPos.pcHorz, mso_pcHorzText, ar, pcHorzCtrl, rtf_nilParam);		
	RtfControl dxaposCtrl = GetTableXposCtrl(p->tblPos.tblpX);
	if(dxaposCtrl == rtf_tposx || dxaposCtrl == rtf_tposnegx)
	{
		_AddAttributeNotdefval(p->tblPos.tblpX, 0, ar, dxaposCtrl, p->tblPos.tblpX);
	}
	else		
	{
		_AddAttributeNotdefval(p->tblPos.tblpX, 0, ar, dxaposCtrl, rtf_nilParam);
	}		
	RtfControl dyaposCtrl = GetTableYposCtrl(p->tblPos.tblpY);
	if(dyaposCtrl == rtf_tposy || dyaposCtrl == rtf_tposnegy)
	{
		_AddAttributeNotdefval(p->tblPos.tblpY, 0, ar, dyaposCtrl, p->tblPos.tblpY);
	}
	else
	{
		_AddAttributeNotdefval(p->tblPos.tblpY, 0, ar, dyaposCtrl, rtf_nilParam);
	}
	_AddAttributeNotdefval(p->tblPos.tblOverlap, 0, ar, rtf_tabsnoovrlp, 1);
}

STDMETHODIMP RtfWTableWriter::Write(
	RtfDirectWriter* ar, const Doc2RtfRowTablePr* p)
{			
	// �����ӱ���������
	if(p->fRowEnd2)		
		ar->StartGroup(rtf_nesttableprops, rtf_nilParam, TRUE);
	
	ar->AddAttribute(rtf_trowd);
	ar->AddAttribute(GetJcCtrl(p->jc, jcctrls::which_tablejc));

	ar->AddAttribute(rtf_trgaph, p->dxaGapHalf);
	_AddAttributeNotdefval(p->dyaRowHeight, 0, ar, rtf_trrh, p->dyaRowHeight);		
	
	ar->AddAttribute(rtf_trleft, p->dxaLeft);

	// ���ӱ���Ĭ�ϱ߿�����
	WriteTTableBorders(ar, p);	
	WriteTablePosition(ar, p);

	_AddBoolAttribute(ar, rtf_trautofit, p->tblFixedLayout);
	_AddBoolAttribute(ar, rtf_trhdr, p->tblHeader);
	_AddBoolAttribute(ar, rtf_trkeep, p->cantSplit);		
	
	_AddAttributeNotdefval(p->tblWidth.wVal, 0, ar, rtf_trwWidth, p->tblWidth.wVal);
	_AddAttributeNotdefval(p->tblWidth.type, 0, ar, rtf_trftsWidth, p->tblWidth.type);		

	_AddAttributeNotdefval(p->trwWidthB.wVal, 0, ar, rtf_trwWidthB, p->trwWidthB.wVal);		
	_AddAttributeNotdefval(p->trwWidthB.type, 0, ar, rtf_trftsWidthB, p->trwWidthB.type);		
	
	_AddAttributeNotdefval(p->trwWidthA.wVal, 0, ar, rtf_trwWidthA, p->trwWidthA.wVal);		
	_AddAttributeNotdefval(p->trwWidthA.type, 0, ar, rtf_trftsWidthA, p->trwWidthA.type);		

	// ���ӱ���Ĭ�ϱ߾�
	WriteDefCellMargin(ar, p);

	// ���ӵ�Ԫ������		
	WriteCells(ar, p);
	
	WriteCellSpacing(ar, p);

	return S_OK;
}
// -------------------------------------------------------------------------
//	$Log: table.cpp,v $
//	Revision 1.5  2006/09/20 01:54:04  xulingjiao
//	29237,29017
//	
//	Revision 1.4  2006/09/06 08:10:06  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.3  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.2  2006/01/20 08:43:01  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:02  xulingjiao
//	*** empty log message ***
//	
