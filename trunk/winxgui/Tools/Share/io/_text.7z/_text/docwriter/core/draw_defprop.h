/* -------------------------------------------------------------------------
//	�ļ���		��	draw_defprop.h
//	������		��	����
//	����ʱ��	��	2005-7-20 17:16:31
//	��������	��	
//	$Id: draw_defprop.h,v 1.3 2005/08/01 07:42:00 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAW_DEFPROP_H__
#define __DRAW_DEFPROP_H__

#ifndef __MSO_HANDLER_ESCHER_H__
#include <mso/handler/escher.h>
#endif

#ifndef __DRAWINGCONNECT_H__
#include <drawing/drawingconnect.h>
#endif

// -------------------------------------------------------------------------
class KDefPropHander : public KFakeUnknown<KElementHandler>
{
	KDWDocTarget* m_pDocTarget;
public:
	STDMETHODIMP_(VOID) Init(
		IN KDWDocTarget* pDocTarget)
	{
		m_pDocTarget = pDocTarget;
	}

public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)	
	{
		__USING_MSO_ESCHER

		BOOL bHasAttr = FALSE;
		MsoShapeOPT opt;
		KROAttributes* pLineAttr = NULL;
		KROAttributes* pFillAttr = NULL;
		if (SUCCEEDED(pAttrs->GetByID(kso::draw_line, &pLineAttr)) &&
			SUCCEEDED(pAttrs->GetByID(kso::draw_fill, &pFillAttr)))
		{
			if (pLineAttr || pFillAttr)
				bHasAttr = TRUE;
		}

		if (bHasAttr)
		{
			InfuseShapeLineProp(opt, pAttrs, 
				*m_pDocTarget->GetDrawingConnection()->GetBlipContext());	
			InfuseShapeFillProp2(opt, pAttrs, 
				*m_pDocTarget->GetDrawingConnection()->GetBlipContext());
			m_pDocTarget->SetDefaultShape(opt);
		}
		
		return S_OK;
	}
};


// -------------------------------------------------------------------------

#endif /* __DRAW_DEFPROP_H__ */

// $Log: draw_defprop.h,v $
// Revision 1.3  2005/08/01 07:42:00  wangdong
// no message
//
// Revision 1.2  2005/07/22 06:39:13  xushiwei
// ���û��defprop�Ͳ���Ҫת���ˡ�������ȷ��д������doc�ļ�û�ж����DggInfo��
//
// Revision 1.1  2005/07/20 09:53:25  wangdong
// no message
//
