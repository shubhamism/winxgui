/* -------------------------------------------------------------------------
//	�ļ���		��	rtffile.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 17:35:55
//	��������	��	
//
//	$Id: rtffile.h,v 1.12 2006/08/31 08:23:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFFILE_H__
#define __RTFFILE_H__
#include "directwr.h"
#include "getctrl.h"
/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
enum CHAR_FILTER_MASK
{		
	CHAR_FILTER_LOWCHAR = 0x0000001,	// 0x19���µ�ASCII��ע����ռλ�����ظ�
};
class RtfDirectWriter : public mso_rtf::RtfDirectWriter
{
	typedef mso_rtf::RtfDirectWriter _Base;
private:
	struct __Filter
	{
		__Filter(RtfDirectWriter* ar) : m_ar(ar)
		{}
	public:
		BOOL AllowWrite(const BYTE** pp, INT ich)
		{			
			const BYTE*& chars = *pp;
			const BYTE ch1 = *chars;
			const BYTE ch2 = *(chars + 1);
			enum { SB_MIN = ' ', SB_MAX = '~'};
			if (ch1 > SB_MAX|| ch1 < SB_MIN)
			{						
				m_ar->WriteEscapedChar(ch1);					
				return FALSE;
			}
			return TRUE;
		}
	private:
		RtfDirectWriter* m_ar;
	};
	friend __Filter;
private:
	STDMETHODIMP_(void) WriteEscapedChar(const BYTE ch)
	{
		static CHAR buff[64] = {0};
		sprintf(buff, "\\\'%02x", ch);	
		m_ar.put(buff, strlen(buff));;
	}
public:	
	STDMETHODIMP_(void) AddUnicodeChar(WCHAR wch, BOOL fGroupUc = TRUE)
	{
		if(fGroupUc)
			StartGroup(rtf_uc, 1);
		else
			AddAttribute(rtf_uc, 1);
		AddAttribute(rtf_u, wch);
		m_ar.put("?", 1);		
		if(fGroupUc)
			EndGroup();
	}
	
	STDMETHODIMP_(void) AddContent(IN LPCSTR chars, IN INT cch)
	{
		_Base::AddContentWithFilter(chars, cch, __Filter(this));
	}

	// ��ѡ��ʽ����һ���ַ���
	STDMETHODIMP_(void) AddContentChar(WCHAR ch, DWORD ciACP = GetACP())
	{		
		BOOL fUseDefChar;
		LPCSTR defChar = "";
		char buf[5]="";
		UINT retcb=WideCharToMultiByte(ciACP, 0, &ch, 1, buf, 5, defChar, &fUseDefChar);
		if(!fUseDefChar)
			AddContent(buf, retcb);
		else
			AddUnicodeChar(ch, TRUE);
	}

	// �Զ��ֽڷ�ʽ�������ݡ�
	STDMETHODIMP_(void) AddContentWcs(IN LPCWSTR chars, IN INT cch = -1, DWORD ciACP = GetACP())
	{	
		cch = (cch > 0) ? cch : wcslen(chars);
		for(UINT i=0; i<cch; ++i)		
			AddContentChar(chars[i], ciACP);		
	}

	STDMETHODIMP_(void) AddFontName(IN LPCWSTR chars, IN INT cch = -1, DWORD ciACP = GetACP())
	{
		cch = (cch > 0) ? cch : wcslen(chars);
		for(UINT i=0; i<cch; ++i)		
		{
			if(iswascii(chars[i]))
				m_ar.put(chars[i]);
			else
				AddContentChar(chars[i], ciACP);
		}
	}
	
	STDMETHODIMP_(void) AddContentWcs(IN KDWKernStr* kernStr, DWORD ciACP = GetACP())
	{
		AddContentWcs(kernStr->Data(), kernStr->Size(), ciACP);
	}
};

#define _AddAttributeMask(maskmem, ar, ctrl, val)							\
	if((maskmem) != 0)														\
	{																		\
		(ar)->AddAttribute((ctrl), (val));									\
	}

#define _AddAttributeNotdefval(mem, defval, ar, ctrl, val)					\
	if((mem) != (defval))													\
	{																		\
		(ar)->AddAttribute((ctrl), (val));									\
	}

#define _AddAttributeNotdefvalMask(maskmem, mem, defval, ar, ctrl, val)		\
	if((maskmem) != 0)														\
	{																		\
		_AddAttributeNotdefval((mem), (defval), (ar), (ctrl), (val));		\
	}

#define _AddAttribute(ar, ctrl, val)  (ar)->AddAttribute((ctrl), (val));

#define _AddBoolAttributeMaskNot0(maskmem, ar, ctrl, val)\
	if((maskmem) != 0)\
	{\
		if(val != 0)\
			{ (ar)->AddAttribute((ctrl)); }\
	}
// ��Ȼ��������sprmָ��ģ���ȻӦ����ȷд�ϼ��������Ľ���������ǲ���0��
// ����Ὣ��sprmֵ��0x81������ʽ��1ʱ������д�ɴ��塣
#define _AddBoolAttributeMask(maskmem, ar, ctrl, val)						\
	if((maskmem) != 0)														\
	{																		\
		(ar)->AddAttribute((ctrl), (val));									\
	}

#define _AddBoolAttribute(ar, ctrl, val)									\
	if((val) != 0)															\
	{																		\
		(ar)->AddAttribute((ctrl));											\
	}

// -------------------------------------------------------------------------

// ���ӵ��ƿ�����
template<class ColorTableType>
inline STDMETHODIMP_(void) WriteCellShdCtrl(const SHD& shd, ColorTableType* colors, RtfDirectWriter* ar)
{
	RtfControl pat = GetPatternCtrl(shd.ipat, patterctrls::which_cellpat);
	if(pat == rtf_clshdng)
	{
		UINT16 val = CalcShading(shd.ipat);
		_AddAttributeNotdefval(val, 0, ar, rtf_clshdng, val);
	}
	else
	{
		ar->AddAttribute(pat);
	}
	COLORREF crFore = Ico2RGB(shd.icoFore);
	COLORREF crBack = Ico2RGB(shd.icoBack);
	_AddAttributeNotdefval(colors->GetColorIndex(crFore), 0, ar, rtf_clcfpat, colors->GetColorIndex(crFore));
	_AddAttributeNotdefval(colors->GetColorIndex(crBack), 0, ar, rtf_clcbpat, colors->GetColorIndex(crBack));	
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteCellShdCtrl(const SHDEX& shdex, ColorTableType* colors, RtfDirectWriter* ar)
{
	RtfControl pat = GetPatternCtrl(shdex.ipat, patterctrls::which_cellpat);
	if(pat == rtf_clshdng)
	{
		UINT16 val = CalcShading(shdex.ipat);
		_AddAttributeNotdefval(val, 0, ar, rtf_clshdng, val);		
	}
	else
	{
		ar->AddAttribute(pat);
	}	
	_AddAttributeNotdefval(colors->GetColorIndex(shdex.crFore), 0, ar, rtf_clcfpat, colors->GetColorIndex(shdex.crFore));
	_AddAttributeNotdefval(colors->GetColorIndex(shdex.crBack), 0, ar, rtf_clcbpat, colors->GetColorIndex(shdex.crBack));	
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteCharShdCtrl(const SHD& shd, ColorTableType* colors, RtfDirectWriter* ar)
{
	RtfControl pat = GetPatternCtrl(shd.ipat, patterctrls::which_charpat);
	if(pat == rtf_chshdng)
	{
		UINT16 val = CalcShading(shd.ipat);
		_AddAttributeNotdefval(val, 0, ar, rtf_chshdng, val);		
	}
	else
	{
		ar->AddAttribute(pat);
	}
	COLORREF crFore = Ico2RGB(shd.icoFore);
	COLORREF crBack = Ico2RGB(shd.icoBack);
	_AddAttributeNotdefval(colors->GetColorIndex(crFore), 0, ar, rtf_chcfpat, colors->GetColorIndex(crFore));
	_AddAttributeNotdefval(colors->GetColorIndex(crBack), 0, ar, rtf_chcbpat, colors->GetColorIndex(crBack));	
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteCharShdCtrl(const SHDEX& shdex, ColorTableType* colors, RtfDirectWriter* ar)
{
	RtfControl pat = GetPatternCtrl(shdex.ipat, patterctrls::which_charpat);
	if(pat == rtf_chshdng)
	{
		UINT16 val = CalcShading(shdex.ipat);
		_AddAttributeNotdefval(val, 0, ar, rtf_chshdng, val);		
	}
	else
	{
		ar->AddAttribute(pat);
	}	
	_AddAttributeNotdefval(colors->GetColorIndex(shdex.crFore), 0, ar, rtf_chcfpat, colors->GetColorIndex(shdex.crFore));
	_AddAttributeNotdefval(colors->GetColorIndex(shdex.crBack), 0, ar, rtf_chcbpat, colors->GetColorIndex(shdex.crBack));	
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteParaShdCtrl(const SHD& shd, ColorTableType* colors, RtfDirectWriter* ar)
{
	RtfControl pat = GetPatternCtrl(shd.ipat, patterctrls::which_parapat);
	if(pat == rtf_shading)
	{
		UINT16 val = CalcShading(shd.ipat);
		_AddAttributeNotdefval(val, 0, ar, rtf_shading, val);		
	}
	else
	{
		ar->AddAttribute(pat);
	}
	COLORREF crFore = Ico2RGB(shd.icoFore);
	COLORREF crBack = Ico2RGB(shd.icoBack);
	_AddAttributeNotdefval(colors->GetColorIndex(crFore), 0, ar, rtf_cfpat, colors->GetColorIndex(crFore));
	_AddAttributeNotdefval(colors->GetColorIndex(crBack), 0, ar, rtf_cbpat, colors->GetColorIndex(crBack));	
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteParaShdCtrl(const SHDEX& shdex, ColorTableType* colors, RtfDirectWriter* ar)
{
	RtfControl pat = GetPatternCtrl(shdex.ipat, patterctrls::which_parapat);
	if(pat == rtf_shading)
	{
		UINT16 val = CalcShading(shdex.ipat);
		_AddAttributeNotdefval(val, 0, ar, rtf_shading, val);		
	}
	else
	{
		ar->AddAttribute(pat);
	}	
	_AddAttributeNotdefval(colors->GetColorIndex(shdex.crFore), 0, ar, rtf_cfpat, colors->GetColorIndex(shdex.crFore));
	_AddAttributeNotdefval(colors->GetColorIndex(shdex.crBack), 0, ar, rtf_cbpat, colors->GetColorIndex(shdex.crBack));	
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteBrcCtrl(
	const BRCEX& brc, RtfDirectWriter* ar, ColorTableType* colors, RtfControl whichBrc)
{	
	RtfControl brcType = GetBrcTypeCtrl(brc.brcType);
	if(brcType != rtf_brdrnone)
	{
		ar->AddAttribute(whichBrc);
		ar->AddAttribute(brcType);
		ar->AddAttribute(rtf_brdrw, brc.dptLineWidth * 20 / 8);
		_AddAttributeNotdefval(colors->GetColorIndex(brc.crFore), 0, ar, rtf_brdrcf, colors->GetColorIndex(brc.crFore));
		_AddAttributeNotdefval(brc.fShadow, 0, ar, rtf_brdrsh, rtf_nilParam);	
		_AddAttributeNotdefval(brc.dptSpace * 20, 0, ar, rtf_brsp, brc.dptSpace * 20);
	}
	else
	{
		if(brc.brcexValue == BRCEX_DELETE_VALUE)
		{
			ar->AddAttribute(whichBrc);
			ar->AddAttribute(rtf_brdrnone);			
		}
	}
}

template<class ColorTableType>
inline STDMETHODIMP_(void) WriteBrcCtrl(const BRC& brc, RtfDirectWriter* ar, ColorTableType* colors, RtfControl whichBrc)
{	
	RtfControl brcType = GetBrcTypeCtrl(brc.brcType);
	if(brcType != rtf_brdrnone)
	{
		ar->AddAttribute(whichBrc);
		ar->AddAttribute(brcType);
		ar->AddAttribute(rtf_brdrw, brc.dptLineWidth * 20 / 8);
		COLORREF cr = Ico2RGB(brc.ico);
		UINT crIndex = colors->GetColorIndex(cr);
		_AddAttributeNotdefval(crIndex, 0, ar, rtf_brdrcf, crIndex);
		_AddAttributeNotdefval(brc.fShadow, 0, ar, rtf_brdrsh, rtf_nilParam);
		_AddAttributeNotdefval(brc.dptSpace * 20, 0, ar, rtf_brsp, brc.dptSpace * 20);	
	}
	else
	{
		if(BRCEX_DELETE_VALUE)
		{
			ar->AddAttribute(whichBrc);
			ar->AddAttribute(rtf_brdrnone);			
		}
	}
}

inline STDMETHODIMP_(void) WriteTabCtrl(const KDWTab& ktab, RtfDirectWriter*ar)
{	
	for(UINT i=0; i<ktab.itbdMac; ++i)
	{
		RtfControl tabKind = GetTabKindCtrl(ktab.rgtbd[i].jc);
		if(tabKind != rtf_tb)
		{
			RtfControl tabLead = GetTabLeadCtrl(ktab.rgtbd[i].tlc);
			ar->AddAttribute(tabKind, rtf_nilParam);
			if(tabLead != rtf_unknown)
				ar->AddAttribute(tabLead, rtf_nilParam);
			ar->AddAttribute(rtf_tx, ktab.rgdxaTab[i]);
		}
		else
		{
			ar->AddAttribute(rtf_tb, ktab.rgdxaTab[i]);
		}
	}
}
// -------------------------------------------------------------------------
//	$Log: rtffile.h,v $
//	Revision 1.12  2006/08/31 08:23:23  xulingjiao
//	�޸�#28711
//	
//	Revision 1.11  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.10  2006/08/11 08:15:42  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.9  2006/04/17 03:06:22  xulingjiao
//	�޸�23338��BUG
//	
//	Revision 1.8  2006/04/07 01:36:32  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.7  2006/02/20 08:15:40  xulingjiao
//	�޸���ע������BUG,�����ֶ��˸��س���BUG
//	
//	Revision 1.6  2006/02/09 06:49:53  xulingjiao
//	rtfwriter�����Ѿ�֧���޶���
//	
//	Revision 1.5  2006/01/22 02:32:33  xulingjiao
//	����ά��
//	
//	Revision 1.4  2006/01/21 09:20:11  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.3  2006/01/21 09:06:50  xulingjiao
//	rtfwriter��������,��������ԭ��
//	
//	Revision 1.2  2006/01/20 08:43:00  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:42:00  xulingjiao
//	*** empty log message ***
//	

#endif /* __RTFFILE_H__ */
