/* -------------------------------------------------------------------------
//	�ļ���		��	text_list.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-7-20 9:45:14
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "text_list.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP KTextListHandler::StartElement(IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	m_iLevel = 0;
	
	HRESULT hr = pAttrs->GetByID(kso::text_list_id, &m_iLst);
	ASSERT_OK(hr);
	
	m_list = m_pLists->NewList(m_iLst);
	
	BSTR listName;
	hr = pAttrs->GetByID(kso::text_list_name, &listName);
	if (SUCCEEDED(hr))
		m_list.SetListName(listName);
	
	return S_OK;
}

STDMETHODIMP KTextListHandler::EnterSubElement(
	IN ELEMENTID uSubElementID,
	OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case text_level:
	{
		ASSERT(m_iLevel <= 8);

		if (m_iLevel > 8)
			return E_UNEXPECTED;

		KDWListLevel listLvl = m_list.GetLevel(m_iLevel);
		m_levelHandler.Init(m_pLists, m_iLst, m_iLevel, listLvl);
		*ppHandler = &m_levelHandler;
	
		++m_iLevel;
		break;
	}
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	_DW_AddRefHandler(*ppHandler);
	return S_OK;
}

STDMETHODIMP KTextListHandler::EndElement(IN ELEMENTID uElementID)
{
	m_list.ShrinkLevels(m_iLevel);
	return S_OK;
}

// -------------------------------------------------------------------------
