/* -------------------------------------------------------------------------
//	�ļ���		��	dop.h
//	������		��	���὿
//	����ʱ��	��	2006-1-1 14:57:46
//	��������	��	
//
//	$Id: dop.h,v 1.4 2006/07/08 02:16:46 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOP_H__
#define __DOP_H__

/*
@category Kingsoft SDK - xxxx
@require
  	<b>Windows:</b> Requires <b>xxxx.dll</b>
  	<b>Linux:</b> Requires <b>libxxxx.so</b>
	<b>Header:</b> Declared in <b><xxxx.h></b>
@group xxxx
@brief
@*/
#include "mso/propstruct/doppr.h"
#include "prop/propbasic.h"
typedef DopPr RtfWDop;
class RtfDirectWriter;
class RtfWDopWriter
{
public:
	STDMETHODIMP_(void) WriteGenerator(RtfDirectWriter* ar);
	STDMETHODIMP_(void) WriteDefPageInfo(RtfDirectWriter* ar);
	STDMETHODIMP_(void) WriteDop(RtfDirectWriter* ar, const KDWDocProperties* t);
	STDMETHODIMP_(void) WriteChars(RtfDirectWriter* ar, const KDWDocProperties* t);
private:
	void Reset(RtfWDop* rtfdop);
};

class RtfWInfoWriter
{
private:
	STDMETHODIMP_(void) WriteAssocStrGroup(RtfDirectWriter* ar, LPCWSTR szWstr, UINT len, RtfControl grName, BOOL fDest = FALSE);
	STDMETHODIMP_(void) WriteDttm(RtfDirectWriter* ar, DTTM dttm,  RtfControl grName, BOOL fDest = FALSE);
	STDMETHODIMP_(void) WriteNumberGroup(RtfDirectWriter* ar, RtfControl grName, UINT val, BOOL fDest = FALSE);
public:
	STDMETHODIMP_(void) Write(RtfDirectWriter* ar, const KDWAssocStringTable* assocTbl, const KDWDocProperties* t);
};
// -------------------------------------------------------------------------
//	$Log: dop.h,v $
//	Revision 1.4  2006/07/08 02:16:46  xulingjiao
//	�ƶ��ļ�
//	
//	Revision 1.3  2006/02/22 01:13:58  xulingjiao
//	�޸��޶���BUG,rtfreader����������ת����BUG,��������
//	
//	Revision 1.2  2006/01/20 08:42:59  xulingjiao
//	html����BASEԪ��
//	
//	Revision 1.1  2006/01/04 03:41:52  xulingjiao
//	*** empty log message ***
//	

#endif /* __DOP_H__ */
