#include "stdafx.h"
#include "rtfreform.h"

WNDPROC richProc;
CHAR toolpath[MAX_PATH];

LRESULT APIENTRY hookProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	int state;
	switch (message)
	{
	case WM_KEYUP:
		switch (wParam)
		{
		case 'F':			
			state = GetKeyState(VK_CONTROL);
			if (state<0)
			 	SendMessage(GetParent(hWnd),WM_COMMAND,MAKEWPARAM(IDM_FIND,0),0);			
			break;
		case VK_F8:
			SendMessage(GetParent(hWnd),WM_COMMAND,MAKEWPARAM(IDM_DIFF,0),0);
			break;		
		case VK_F5:
			SendMessage(GetParent(hWnd),WM_COMMAND,MAKEWPARAM(IDM_REFURBISH,0),0);
		case 'S':
			state = GetKeyState(VK_CONTROL);
			if(state<0)
				SendMessage(GetParent(hWnd),WM_COMMAND,MAKEWPARAM(IDM_SAVE,0),0);
			break;
		case VK_F7:
			state = GetKeyState(VK_CONTROL);
			if(state<0)
				SendMessage(GetParent(hWnd), WM_COMMAND, MAKEWPARAM(IDM_SETTOOL, 0), 0);
			break;
		}
		return 0;
	}
	return CallWindowProc(richProc, hWnd, message,wParam, lParam);
}

void SetTitle(HWND hWnd, std::string fileName)
{
	char szTitle[MAX_PATH];
	sprintf(szTitle,"rtfreform - %s",fileName.c_str());
	SetWindowText(hWnd,szTitle);
}

HRESULT InitTitle(HWND hWnd,LPSTR szRtfFile)
{
	HRESULT hr = S_OK;
	if (!IsSpaceString(g_lpCmdLine))
		strcpy(szRtfFile, g_lpCmdLine);
	else
		hr = GetOpenFileA(hWnd, szRtfFile,MAX_PATH,"rtf file(*.rtf)\0*.rtf\0\0");
	SetTitle(hWnd,szRtfFile);
	return hr;
}

std::string GetCurFile(HWND hWnd)
{
	char szCurFile[MAX_PATH];
	GetWindowText(hWnd,szCurFile,MAX_PATH);
	char* pCurFile = strstr(szCurFile," - ");					
	pCurFile+=3;
	return pCurFile;
}

void FindMessage(FindReplaceText&fr, LPARAM lParam)
{
	LPFINDREPLACE pfr = (LPFINDREPLACE)(lParam);
	if(pfr->Flags&FR_DIALOGTERM)
		g_hFindDlg = NULL;
	if(pfr->Flags&FR_FINDNEXT)
	{
		if(fr.Find(pfr))
			return;
		if(fr.IsExist(pfr))
			return;
		MessageBoxPrintA(g_hFindDlg,"Text is not exist!");
	}
}

void Flush(FillRichEditText& fill,HWND hWnd)
{
	std::string curFile = GetCurFile(hWnd);
	fill.ParseRtf(curFile.c_str());
}

std::string BackupFile(FillRichEditText& fill, HWND hWnd,std::string backupFile)
{	
	DeleteFile(backupFile.c_str());
	std::string curFile = GetCurFile(hWnd);
	std::string tempFile = MakeTempFileName();
	fill.SaveRtf(tempFile.c_str(),FALSE);
	return tempFile;
}

std::string BackupCopyFile(std::string backupFile,std::string backupCopyFile)
{
	DeleteFile(backupCopyFile.c_str());
	std::string tempCopy = MakeTempFileName();
	CopyFile(backupFile.c_str(),tempCopy.c_str(),FALSE);
	return tempCopy;
}

std::string NewestFile(FillRichEditText& fill, HWND hWnd,std::string newestFile)
{	
	DeleteFile(newestFile.c_str());
	std::string curFile = GetCurFile(hWnd);
	std::string strFile = MakeTempFileName();
	Flush(fill,hWnd);
	fill.SaveRtf(strFile.c_str(),FALSE);
	return strFile;
}

std::string Save(FillRichEditText& fill,HWND hWnd)
{
	std::string curFile = GetCurFile(hWnd);
	fill.SaveRtf(curFile.c_str(),TRUE);
	return curFile;
}

std::string SaveAs(FillRichEditText& fill,HWND hWnd)
{
	char saveFile[MAX_PATH]="";
	HRESULT hr = GetSaveFile(hWnd,saveFile,MAX_PATH,"all file(*.*)\0\0");
	if(SUCCEEDED(hr))
		fill.SaveRtf(saveFile,FALSE);
	return saveFile;
}

std::string Open(FillRichEditText& fill,HWND hWnd)
{
	char openFile[MAX_PATH]="";
	HRESULT hr = GetOpenFileA(hWnd,openFile,MAX_PATH,"rtf file(*.rtf)\0*.rtf\0\0");
	if(SUCCEEDED(hr))
	{
		fill.ParseRtf(openFile);
		SetTitle(hWnd,openFile);
	}
	return openFile;
}

LONG RegisterCompareToolPath(std::string path)
{	
	//��HKEY_CURRENT_USER/Software
	HKEY software; LONG res;
	res = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_ALL_ACCESS, &software);
	if(	res != ERROR_SUCCESS )
		return res;
	//����rtfreform�Ӽ�
	HKEY rtfreform; DWORD dwDisposition;
	res = RegCreateKeyEx(software, "rtfreform", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &rtfreform, &dwDisposition);
	if( res != ERROR_SUCCESS )
		return res;
	//����ֵ
	res = RegSetValueEx(rtfreform, "compare tool", 0, REG_SZ, (CONST BYTE *)(path.c_str()), path.size());
	RegCloseKey(rtfreform);
	RegCloseKey(software);
	return res;
}

LONG GetToolPath(CHAR* path, LPDWORD cbData, LPDWORD type)
{	
	LONG res;
	HKEY software;
	res = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_ALL_ACCESS, &software);
	if( res != ERROR_SUCCESS )	
		return res;

	HKEY rtfreform;
	res = RegOpenKeyEx(software, "rtfreform", 0, KEY_ALL_ACCESS, &rtfreform);
	if( res != ERROR_SUCCESS)
	{
		RegCloseKey(software);
		return res;
	}

	res = RegQueryValueEx(rtfreform, "compare tool", NULL, type, (LPBYTE)path, cbData);
	RegCloseKey(rtfreform);
	RegCloseKey(software);
	return res;
}

HRESULT CmpFile(FillRichEditText& fill,std::string& backupCopyFile,std::string backupFile,std::string newestFile)
{
	DWORD attr1,attr2;
	attr1 = GetFileAttributes(backupFile.c_str());
	attr2 = GetFileAttributes(newestFile.c_str());
	if(attr1 == 0xFFFFFFFF || attr2 == 0xFFFFFFFF)
		return E_FAIL;

	backupCopyFile = BackupCopyFile(backupFile,backupCopyFile);

	char szCmd[MAXLEN];
	
	sprintf(szCmd,"%s \"%s\" \"%s\"",toolpath, backupCopyFile.c_str(),newestFile.c_str());
	HRESULT hr = ExecCommand(szCmd);
	fill.SaveRtf(backupFile,FALSE);
	return hr;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;	
	static FillRichEditText fill;
	static KRichEditCtrl hRichEdit;
	static FindReplaceText fr;
	static char szRtfFile[MAX_PATH]="\0";	
	static std::string backupFile,newestFile,backupCopyFile;

	switch (message)
	{
	case WM_CREATE:
		hRichEdit = CreateRichEdit(hWnd);
		fill = (HWND)(hRichEdit);
		fr.SetData(hWnd,(HWND)hRichEdit);
		richProc =(WNDPROC)SetWindowLong((HWND)hRichEdit,GWL_WNDPROC,(LONG)hookProc);
		if(FAILED(InitTitle(hWnd,szRtfFile)))
			return 0;
		fill.ParseRtf(szRtfFile);
		backupFile=BackupFile(fill,hWnd,backupFile);

		LONG res; DWORD cbData, type;
		res = GetToolPath(toolpath, &cbData, &type);
		if(type != REG_SZ || res != ERROR_SUCCESS)		
			SendMessage(hWnd, WM_COMMAND, MAKEWPARAM(IDM_SETTOOL, 0), 0);		
		return 0;	
	case WM_SIZE:
		if((HWND)hRichEdit)
			MoveWindow(hRichEdit,0,0,LOWORD(lParam),HIWORD(lParam),TRUE);
		return 0;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		switch (wmId)
		{
			case IDM_ABOUT:
				DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				break;
			case IDM_EXIT:
				SendMessage(hWnd,WM_CLOSE,0,0);
				break;
			case IDM_SAVEAS:
				SaveAs(fill,hWnd);
				break;
			case IDM_SAVE:
				Save(fill,hWnd);
				break;
			case IDM_REFURBISH:
				Flush(fill,hWnd);
				break;
			case IDM_DIFF:
				newestFile = NewestFile(fill,hWnd,newestFile);
				CmpFile(fill,backupCopyFile,backupFile,newestFile);
				break;
			case IDM_OPEN:{
				std::string OpenFile = Open(fill,hWnd);
				if(OpenFile!=backupFile)
				{
					backupFile = BackupFile(fill,hWnd,backupFile);
				}
				break;}
			case IDM_FIND:
				if(!g_hFindDlg)
					g_hFindDlg=fr.PopFindDlg(FR_HIDEMATCHCASE|FR_HIDEWHOLEWORD);
				break;
			case IDM_SETTOOL:
				{
					char path[MAX_PATH]="";
					OPENFILENAME opnm;
					ZeroMemory(&opnm,sizeof(opnm));
					opnm.lStructSize=sizeof(opnm);
					opnm.Flags=OFN_FILEMUSTEXIST|OFN_EXPLORER;
					opnm.lpstrFilter="exe file(*.exe)\0*.exe\0\0";
					opnm.lpstrFile=path;
					opnm.nMaxFile=MAX_PATH;	
					opnm.hwndOwner=hWnd;
					opnm.lpstrTitle="�����ñȽϹ���";
					HRESULT hr = GetOpenFileNameA(&opnm);
					if(SUCCEEDED(hr))
					{
						LONG res = RegisterCompareToolPath(path);
						if(res == ERROR_SUCCESS)
							strcpy(toolpath, path);
						else
							strcpy(toolpath, "windiff");
					}
					else
						strcpy(toolpath, "windiff");
				}
				break;
		}
		return 0;
	case WM_DESTROY:
		SetWindowLong((HWND)hRichEdit,GWL_WNDPROC,(LONG)richProc);
		DeleteFile(backupFile.c_str());
		DeleteFile(newestFile.c_str());
		DeleteFile(backupCopyFile.c_str());
		PostQuitMessage(0);
		return 0;
	default:
		if(message == FRMSG)
		{
			FindMessage(fr,lParam);
			return 0;
		}
		break;
  }
   return DefWindowProc(hWnd, message, wParam, lParam);
}
