
#if !defined(AFX_RTFBREAK_H__B4BBE3A0_F72C_4C50_8927_CB07F4E1A091__INCLUDED_)
#define AFX_RTFBREAK_H__B4BBE3A0_F72C_4C50_8927_CB07F4E1A091__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_LOADSTRING 100
#define MAXLEN 500

#include "resource.h"
#include "_backward/cdev/method.h"
#include "_backward/windev/common.h"
#include "_backward/windev/richeditctrl.h"

#include "filltext.h"
#include "FindReplaceText.h"

extern LPSTR g_lpCmdLine;
extern HWND g_hFindDlg;
extern LONG FRMSG;
extern HACCEL g_hAccelTable;
extern HINSTANCE hInst;
extern TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
extern TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
extern CHAR toolpath[MAX_PATH];

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

HWND CreateRichEdit(HWND hParent);

DWORD CALLBACK StreamOutCallback(
								  DWORD dwCookie,
								  LPBYTE pbBuff,
								  LONG cb,
								  LONG *pcb
								 );
LRESULT APIENTRY hookProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

void SetTitle(HWND hWnd, std::string fileName);

HRESULT InitTitle(HWND hWnd,LPSTR szRtfFile);

std::string GetCurFile(HWND hWnd);

void FindMessage(FindReplaceText&fr, LPARAM lParam);

void Flush(FillRichEditText& fill,HWND hWnd);

std::string BackupFile(FillRichEditText& fill, HWND hWnd,std::string backupFile);

std::string BackupCopyFile(std::string backupFile,std::string backupCopyFile);

std::string NewestFile(FillRichEditText& fill, HWND hWnd,std::string newestFile);

std::string Save(FillRichEditText& fill,HWND hWnd);

std::string SaveAs(FillRichEditText& fill,HWND hWnd);

std::string Open(FillRichEditText& fill,HWND hWnd);

LONG RegisterCompareToolPath(std::string path);

LONG GetToolPath(CHAR* path, LPDWORD cbData, LPDWORD type);

HRESULT CmpFile(FillRichEditText& fill,std::string& backupCopyFile,std::string backupFile,std::string newestFile);

#endif // !defined(AFX_RTFBREAK_H__B4BBE3A0_F72C_4C50_8927_CB07F4E1A091__INCLUDED_)
