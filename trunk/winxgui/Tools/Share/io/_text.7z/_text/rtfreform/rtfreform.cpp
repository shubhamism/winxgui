// rtf break.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "rtfreform.h"
#pragma comment(lib, "comctl32.lib")

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
char szFind[MAXLEN];
LONG FRMSG;
HWND g_hFindDlg;

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

LPSTR g_lpCmdLine;
HACCEL g_hAccelTable;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	char mdlFile[MAX_PATH];
	GetModuleFileName(hInstance,mdlFile,MAX_PATH);
	strcat(mdlFile," %1");
	RegistryNewShellCommand(".rtf", "�鿴RTF�ļ�", mdlFile);
	if (lpCmdLine)
	{
		DealFileName(lpCmdLine);
		g_lpCmdLine = lpCmdLine;
	}

	// TODO: Place code here.
	if(!LoadLibrary("RICHED32.dll"))
		return EXIT_FAILURE;
	INITCOMMONCONTROLSEX cmex;
	cmex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	cmex.dwICC = ICC_WIN95_CLASSES;	
	if(!InitCommonControlsEx(&cmex))	
		return EXIT_FAILURE;	
	MSG msg;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_RTFBREAK, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	g_hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_RTFBREAK);

	FRMSG = RegisterWindowMessage(TEXT("commdlg_FindReplace"));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if(!g_hFindDlg || !IsDialogMessage(g_hFindDlg,&msg))
		{
			if (!TranslateAccelerator(msg.hwnd, g_hAccelTable, &msg)) 
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}
	return msg.wParam;
}