//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rtfreform.rc
//
#define IDC_MYICON                      2
#define IDD_RTFBREAK_DIALOG             102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_RTFBREAK                    107
#define IDI_SMALL                       108
#define IDC_RTFBREAK                    109
#define IDS_PATH                        110
#define IDS_PREFIX                      111
#define IDR_MAINFRAME                   128
#define IDM_OPEN                        32771
#define IDM_SAVE                        32772
#define IDM_FIND                        32775
#define IDM_DIFF                        32776
#define IDM_SAVEAS                      32777
#define IDM_REFURBISH                   32778
#define IDM_SETTOOL                     32779
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
