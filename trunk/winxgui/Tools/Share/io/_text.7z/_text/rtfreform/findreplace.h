#ifndef __FINDREPLACE_H__
#define __FINDREPLACE_H__
#include "filltext.h"

static char szFindText[MAXLEN];
static char szReplText[MAXLEN];

class FindReplace
{
private:
	HWND hOwner;
public:
	FindReplace()
	{
		hOwner = NULL;
	}
	FindReplace(HWND AhOwner)
	{
		ASSERT(AhOwner);
		hOwner = AhOwner;
	}
	void SetOwner(HWND AhOwner)
	{
		ASSERT(AhOwner);
		hOwner = AhOwner;
	}
	HWND PopFindFindDlg(DWORD Aflags = FR_HIDEUPDOWN | FR_MATCHCASE | FR_HIDEWHOLEWORD)
	{
		if(!hOwner)
			return NULL;
		static FINDREPLACE fr;
		ZeroMemory(&fr,sizeof(FINDREPLACE));
		fr.lStructSize = sizeof(FINDREPLACE);
		fr.hwndOwner = hOwner;		
		fr.Flags = Aflags;
		fr.lpstrFindWhat = szFindText;
		fr.wFindWhatLen = MAXLEN;
		return FindText(&fr);
	}
	HWND PopFindReplaceDlg(DWORD Aflags = FR_HIDEUPDOWN | FR_MATCHCASE | FR_HIDEWHOLEWORD)
	{
		if(!hOwner)
			return NULL;
		static FINDREPLACE fr;
		ZeroMemory(&fr,sizeof(FINDREPLACE));
		fr.lStructSize = sizeof(FINDREPLACE);
		fr.hwndOwner = hOwner;
		fr.Flags = Aflags;
		fr.lpstrFindWhat = szFindText;
		fr.lpstrReplaceWith = szReplText;
		fr.wFindWhatLen = MAXLEN;
		fr.wReplaceWithLen = MAXLEN;
		return ReplaceText(&fr);
	}
	BOOL PopFindFindText(KRichEditCtrl hwndEdit, int* piSearchOffset, LPFINDREPLACE pfr)
	{
		if(!(HWND)(hwndEdit))
			return FALSE;
		int iLen, iPos;
		PSTR pstrDoc, pstrPos;
		iLen = hwndEdit.GetTextLength() + 5;
		pstrDoc = (PSTR)_alloca(iLen);
		if(!pstrDoc)
			return FALSE;
		/*INPARAMETER inPara;
		inPara.p = pstrDoc;
		inPara.pEnd = pstrDoc + iLen;
		EDITSTREAM es;
		ZeroMemory(&es,sizeof(EDITSTREAM));
		ZeroMemory(pstrDoc, iLen);
		es.dwCookie = (DWORD)(&inPara);
		es.pfnCallback = StreamOutCallback;
		hwndEdit.StreamOut(SF_TEXT, es);
		pstrPos = strstr(pstrDoc + (*piSearchOffset), pfr->lpstrFindWhat);
		if(!pstrPos)
			return FALSE;*/
		iPos = hwndEdit.FindText(0,FINDTEXTEX
		//iPos = pstrPos - pstrDoc;
		*piSearchOffset = iPos + strlen(pfr->lpstrFindWhat);
		hwndEdit.SetSel(iPos,*piSearchOffset);
		hwndEdit.ScrollCaret();
		return TRUE;
	}
	BOOL PopFindNextText(KRichEditCtrl hwndEdit, int* piSearchOffset)
	{
		FINDREPLACE fr;
		ZeroMemory(&fr,sizeof(FINDREPLACE));
		fr.lStructSize = sizeof(FINDREPLACE);
		fr.lpstrFindWhat = szFindText;
		return PopFindFindText(hwndEdit,piSearchOffset,&fr);
	}
	BOOL PopFindReplaceText(KRichEditCtrl hwndEdit, int* piSearchOffset, LPFINDREPLACE pfr)
	{
		if(!PopFindFindText(hwndEdit,piSearchOffset,pfr))
			return FALSE;
		hwndEdit.ReplaceSel(pfr->lpstrReplaceWith,TRUE);
		return TRUE;
	}
	BOOL PopFindValidFind()
	{
		return *szFindText != '\0';
	}
};
#endif