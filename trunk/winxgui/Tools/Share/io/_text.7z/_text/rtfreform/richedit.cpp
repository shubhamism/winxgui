#include "stdafx.h"
#include "rtfreform.h"
#include <richedit.h>

HWND CreateRichEdit(HWND hParent)
{
	RECT rect;
	GetClientRect(hParent,&rect);
	return CreateWindowEx  (
							0,
							RICHEDIT_CLASS,
							NULL,
							WS_VISIBLE|
							WS_CHILD|
							ES_MULTILINE|
							ES_AUTOVSCROLL|
							WS_VSCROLL,
							0,
							0,
							rect.right-rect.left,
							rect.bottom-rect.top,
							hParent,
							NULL,
							hInst,
							NULL
							);
}