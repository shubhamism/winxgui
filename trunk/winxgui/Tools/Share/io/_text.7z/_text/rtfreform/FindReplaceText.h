#ifndef __FINDREPLACETEXT__
#define __FINDREPLACETEXT__
#include "_backward/windev/richeditctrl.h"
#include "_backward/windev/common.h"
#include <commdlg.h>

extern HWND g_hFindDlg;

class FindReplaceText
{
	HWND hOwner;
	KRichEditCtrl hRichEdit;
public:
	FindReplaceText()
	{
		hOwner =NULL;
		hRichEdit =NULL;
	}	
	void SetData(HWND AhOwner,HWND AhRichEdit)
	{
		hOwner = AhOwner;
		hRichEdit = AhRichEdit;
		ASSERT(hOwner && (HWND)hRichEdit);
	}
	HWND PopFindDlg(DWORD inFlag)
	{		
		ASSERT(hOwner && (HWND)hRichEdit);
		static FINDREPLACE fr;
		ZeroMemory(&fr,sizeof(FINDREPLACE));
		fr.lStructSize = sizeof(FINDREPLACE);
		fr.Flags = inFlag|FR_DOWN;
		fr.hwndOwner = hOwner;
		static char szFindWhat[MAXLEN];
		char szBackup[MAXLEN];
		strcpy(szBackup,szFindWhat);
		if(!hRichEdit.GetSelText(szFindWhat))
			strcpy(szFindWhat,szBackup);
		fr.lpstrFindWhat = szFindWhat;
		fr.wFindWhatLen = MAXLEN;
		return FindText(&fr);
	}
	BOOL FindDown(LPFINDREPLACE pfr)
	{
		ASSERT(hOwner && (HWND)hRichEdit);
		CHARRANGE chrg;
		hRichEdit.GetSel(chrg);
		FINDTEXTEX ftxex;
		ftxex.chrg.cpMin = chrg.cpMax;
		ftxex.chrg.cpMax = hRichEdit.GetTextLength();
		ftxex.lpstrText = pfr->lpstrFindWhat;
		LONG res = hRichEdit.FindText(FR_DOWN,&ftxex);
		if(res == -1)		
			return FALSE;		
		hRichEdit.SetSel(ftxex.chrgText);		
		hRichEdit.HideSelection(FALSE,0);
		return TRUE;
	}
	BOOL FindUp(LPFINDREPLACE pfr)
	{
		ASSERT(hOwner && (HWND)hRichEdit);
		CHARRANGE chrg;
		hRichEdit.GetSel(chrg);
		FINDTEXTEX ftxex;
		ftxex.chrg.cpMin = chrg.cpMin;
		ftxex.chrg.cpMax = 0;
		ftxex.lpstrText = pfr->lpstrFindWhat;
		LONG res = hRichEdit.FindText(0,&ftxex);
		if(res == -1)
			return FALSE;
		hRichEdit.SetSel(ftxex.chrgText);		
		hRichEdit.HideSelection(FALSE,0);
		return TRUE;
	}
	BOOL IsExist(LPFINDREPLACE pfr)
	{
		char szSel[MAXLEN];
		hRichEdit.GetSelText(szSel);
		if(pfr->Flags&FR_DOWN)
		{
			if(!FindUp(pfr)&&strcmp(szSel,pfr->lpstrFindWhat))
				return FALSE;
			hRichEdit.SetSel(0,0);
			FindDown(pfr);
			return TRUE;
		}
		if(!FindDown(pfr)&&strcmp(szSel,pfr->lpstrFindWhat))
			return FALSE;
		hRichEdit.SetSel(hRichEdit.GetTextLength()-1,hRichEdit.GetTextLength()-1);
		FindUp(pfr);
		return TRUE;
	}
	BOOL Find(LPFINDREPLACE pfr)
	{
		ASSERT(hOwner && (HWND)hRichEdit);
		if(pfr->Flags&FR_DOWN)
			return FindDown(pfr);
		else
			return FindUp(pfr);
	}
};
#endif