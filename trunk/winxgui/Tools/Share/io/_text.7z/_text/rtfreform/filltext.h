#ifndef __FILLTEXT_H__
#define __FILLTEXT_H__
#include <_backward/windev/richedit_streaminout.h>
#include "rtfreform.h"

class FillRichEditText
{
private:
	KRichEditCtrl m_richedit;
	typedef enum
	{INACT,OUTACT}ACT;	
private:
	void VecCutSpace(std::vector<char>& desVec,const std::vector<char>& vec)
	{
		for(int i=0; i<vec.size(); ++i)
		{
			if(vec[i] != '\r' && vec[i] != '\n' && vec[i] != '\t')
				desVec.push_back(vec[i]);
		}
		desVec.push_back('\0');
	}
	void VecPutnChar(std::vector<char>& vec,int num, char ch)
	{
		for(int i=0; i<num; ++i)
			vec.push_back(ch);
	}
	void StreamRichEdit(std::vector<char>& vec,ACT act)
	{
		EDITSTREAM es;
		ZeroMemory(&es,sizeof(EDITSTREAM));
		INPARAMETER parameter;
		parameter.p = vec.begin();
		parameter.pEnd = vec.end();		
		es.dwCookie =(DWORD)(&parameter);
		switch(act)
		{
		case INACT:
			es.pfnCallback = StreamInCallback;
			m_richedit.StreamIn(SF_TEXT,es);
			break;
		case OUTACT:
			es.pfnCallback = StreamOutCallback;
			m_richedit.StreamOut(SF_TEXT,es);
			break;
		}		
	}	
public:
	FillRichEditText()
	{
		m_richedit = NULL;
	}
	FillRichEditText(KRichEditCtrl richedit)
	{
		m_richedit = richedit;
	}
	~FillRichEditText()
	{		
	}
	(operator HWND)() const
	{
		return (HWND)m_richedit;
	}
	FillRichEditText& operator = (HWND richedit)
	{
		m_richedit = richedit;		
		return *this;
	}
	HRESULT SaveRtf(std::string strFileName,BOOL beCutSpace)
	{
		std::ofstream osFile(strFileName.c_str(),std::ios::binary);
		if(!osFile)
		{
			MessageBoxPrintA("%s",strerror(errno));
			return E_FAIL;
		}
		int len = m_richedit.GetTextLength();
		std::vector<char> saveVec(len+5,'\0');
		StreamRichEdit(saveVec,OUTACT);
		if(!beCutSpace)
			osFile << (&saveVec[0]);
		else
		{
			std::vector<char> chVec;
			VecCutSpace(chVec,saveVec);
			osFile<<(&chVec[0]);
		}
		return S_OK;
	}	
	HRESULT ParseRtf(std::string strFileName)
	{
		if(!(HWND)(m_richedit))
			return E_FAIL;
		std::ifstream isFile(strFileName.c_str(),std::ios::binary);
		if(!isFile)
			return E_FAIL;
		m_richedit.ClearAll();
		int m_level = 0,m_innermost=0,cSlash=0;
		std::vector<char> chVec;
		int ch;
		while(1)
		{
			ch = isFile.get();
			int unspacech;
			if(ch == EOF)
			{				
				StreamRichEdit(chVec,INACT);
				m_richedit.LimitText(chVec.size()*2);
				break;
			}
			switch(ch)
			{
			case '{':
				cSlash = 0;
				if(m_level)					
					chVec.push_back('\n');
				VecPutnChar(chVec,m_level,'\t');
				chVec.push_back('{');
				m_innermost = m_level;
				++m_level;
				break;
			case '}':
				--m_level;
				if(m_innermost != m_level)
				{
					chVec.push_back('\n');
					VecPutnChar(chVec,m_level,'\t');
				}
				chVec.push_back('}');
				while(isspace(unspacech=isFile.get()));
				isFile.putback(unspacech);
				if(unspacech=='\\')
				{
					chVec.push_back('\n');
					VecPutnChar(chVec,m_level,'\t');					
				}				
				break;
			case '\r':
			case '\n':
				break;
			case '\\':
				if(cSlash&&cSlash%8==0)
					chVec.push_back('\n');
				++cSlash;
				chVec.push_back('\\');
				break;
			default:
				chVec.push_back(ch);
				break;
			}
		}
		return S_OK;
	}
};

#endif