/* -------------------------------------------------------------------------
//	�ļ���		��	testdocwriter2.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-14 16:40:30
//	��������	��	
//
//	$Id: testdoc2txt.cpp,v 1.1 2005/03/18 01:51:28 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <kfc/encoding/encoding.h>
#include <kso/dircfginfo.h>
#include "testdoc2txt.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#ifdef X_ENCODE_UCS2
#define testDoc2TxtFile(from, to, CP, NL)									\
	m_doc2doc.convert(														\
		L"../testcase/docrw/" L ## from,									\
		L"../testcase/output/" L ## to,										\
		CP, NL)
#else
#define testDoc2TxtFile(from, to, CP, NL)									\
	m_doc2doc.convert(														\
		__X("../testcase/docrw/" from),										\
		__X("../testcase/output/" to,										\
		CP, NL)
#endif

#define DW_CPPUNIT_TEST(Test)												\
	if (CPPUNIT_TEST(Test) == S_OK)											\
		++m_nRef

// -------------------------------------------------------------------------

class TestWriterEx : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestWriterEx);
		DW_CPPUNIT_TEST(CaseChpx);
		DW_CPPUNIT_TEST(CaseAtn);
		DW_CPPUNIT_TEST(CaseTbl);
		DW_CPPUNIT_TEST(CaseMisc);
	CPPUNIT_TEST_SUITE_END();

private:
	static KConvertDoc2DocEx m_doc2doc;
	static UINT m_nRef;

public:
	void setUp() {}
	void tearDown()
	{
		if (--m_nRef == 0)
			m_doc2doc.term();
	}

public:
	// --------------------------------------------------------
	// core
	
	void CaseChpx()
	{
		testDoc2TxtFile(
			"core/����ϵͳ.doc",
			"core_����ϵͳ.txt",
			CP_ACP,
			0);
		testDoc2TxtFile(
			"core/����ϵͳ.doc",
			"core_����ϵͳBigEndian.txt",
			KFC_CP_UCS2BigEndian,
			0);
	}
	void CaseAtn()
	{
		testDoc2TxtFile(
			"comment/basic.doc",
			"comment_basic.txt",
			KFC_CP_Windows1250,
			0);
	}
	void CaseMisc()
	{
		testDoc2TxtFile(
			"�ۺ�/�����ĵ�Ԫ��_ΪTXT����.doc",
			"�ۺ�_�����ĵ�Ԫ��_ΪTXT����.txt",
			CP_ACP,
			0);
		testDoc2TxtFile(
			"�ۺ�/008_�����浥.doc",
			"�ۺ�_008_�����浥.txt",
			CP_ACP,
			0);
		testDoc2TxtFile(
			"�ۺ�/008_�����浥.doc",
			"�ۺ�_008_�����浥Windows1250.txt",
			KFC_CP_Windows1250,
			0);
		
	}
	void CaseTbl()
	{
		testDoc2TxtFile(
			"texttable/regular.doc",
			"texttable_regular.txt",
			CP_ACP,
			0);
	}
};

KConvertDoc2DocEx TestWriterEx::m_doc2doc;

UINT TestWriterEx::m_nRef;

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestWriterEx);

// -------------------------------------------------------------------------
// $Log: testdoc2txt.cpp,v $
// Revision 1.1  2005/03/18 01:51:28  wangdong
// дtxt�ȶ���
//
