/* -------------------------------------------------------------------------
//	�ļ���		��	text.h
//	������		��	����
//	����ʱ��	��	2005-4-20 14:12:30
//	��������	��	
//	$Id: text.h,v 1.1 2005/04/25 01:57:14 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __HANDLER_TEXT_H__
#define __HANDLER_TEXT_H__


// -------------------------------------------------------------------------
class KTxtNormalHandler : public KTxtHandler
{
public:
	STDMETHODIMP_(VOID) Open(
		IN KTxtModel* pModel)
	{
		m_pModel = pModel;
	}
	STDMETHODIMP_(VOID) Close()
	{
		m_pModel = NULL;
	}

public:
	STDMETHODIMP AddContent(
		IN const WCHAR* cont,
		IN UINT cch)
	{
		return m_pModel->AddContent(cont, cch);
	}
	
private:
	KTxtModel* m_pModel;
};


// -------------------------------------------------------------------------

#endif /* __HANDLER_TEXT_H__ */

// $Log: text.h,v $
// Revision 1.1  2005/04/25 01:57:14  wangdong
// ������txt��
//
