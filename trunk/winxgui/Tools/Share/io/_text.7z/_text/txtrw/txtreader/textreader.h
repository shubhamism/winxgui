/* -------------------------------------------------------------------------
//	�ļ���		��	textreader.h
//	������		��	�ݽ���
//	����ʱ��	��	2005-3-8 9:28:35
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TEXTREADER_H__
#define __TEXTREADER_H__

#ifndef __KFC_VARIANT_H__
#include <kfc/variant.h>
#endif

#ifndef __KFC_ENCODING_ENCODING_H__
#include <kfc/encoding/encoding.h>
#endif

#ifndef __KSO_IO_TEXTENCODING_H__
#include <kso/io/textencoding.h>
#endif

#ifndef __KSO_IO_FILTER_H__
#include <kso/io/filter.h>
#endif

#ifndef __PARSER_H__
#include "reader/parser.h"
#endif

#ifndef __HANDLER_DOCUMENT_H__
#include "handler/document.h"
#endif

// -------------------------------------------------------------------------
inline
STDMETHODIMP_(VOID) textResetStream(
									IN IStream* pStream)
{
	ASSERT(
		pStream != NULL
		);

	LARGE_INTEGER li;
	LISet32(li, 0);
	pStream->Seek(li, STREAM_SEEK_SET, NULL);
}

inline
STDMETHODIMP_(VOID) textUnicodeTrimStream(
	IN IStream* pStream, 
	OUT IStream** ppStreamOut, 
	IN BOOL TrimLastNewLine)
{
	//
	// @@note:
	//	�����������:
	//	1. ȥ������ʼ��feff��
	//	2. ��ָ��������ȥ����β�Ļ��С�
	//

	ASSERT(
		pStream != NULL &&
		ppStreamOut != NULL
		);
	
	UINT startOffset = 0;
	UINT endOffset = 0;


	WCHAR ch = 0;
	KReadArchive Ar(pStream);
	Ar.seek(0);
	Ar.read(&ch, sizeof(WCHAR));
	if (ch == 0xfeff)
		startOffset = sizeof(WCHAR);

	const ULARGE_INTEGER size = Ar.size();
	UINT cusor = size.LowPart;
	while ( (INT)(cusor -= sizeof(WCHAR)) >= 0 )
	{
		ULARGE_INTEGER li;
		ULISet32(li, cusor);
		Ar.seek(li);

		WCHAR ch = 0;
		Ar.read(&ch, sizeof(WCHAR));

		if (ch != 0)
			break;
	}

	if (TrimLastNewLine)
	{
		WCHAR ch[2] = {0, 0};
		if ( (INT)(cusor -= sizeof(WCHAR))  >= 0 )
		{
			ULARGE_INTEGER li;
			ULISet32(li, cusor);
			Ar.seek(li);
			
			Ar.read(ch, sizeof(WCHAR) * 2);
			if ( !(ch[0] == '\x0d' && ch[0] == '\x0d') )
			{
				cusor += sizeof(WCHAR);
				ULISet32(li, cusor);
				Ar.seek(li);
			}
			else
			{
				Ar.seek(li);
			}
		}
	}
	
	const ULARGE_INTEGER pos = Ar.tell();
	endOffset = pos.LowPart;

	Ar.close();


	ks_stdptr<IStream> spStreamOut;
	XCreateStreamOnHGlobal(NULL, TRUE, &spStreamOut);

	LARGE_INTEGER li = {0};
	LISet32(li, startOffset);
	pStream->Seek(li, STREAM_SEEK_SET, NULL);

	ULARGE_INTEGER uli = {0};
	ULISet32(uli, endOffset - startOffset);
	pStream->CopyTo(spStreamOut, uli, NULL, NULL);

	textResetStream(spStreamOut);
	*ppStreamOut = spStreamOut.detach();
}


// -------------------------------------------------------------------------
class KTxTextReader : 
	public IKFilterMediaInit,
	public IKContentSource,
	public KComObjectRoot
{
public:
	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		HRESULT hr = S_OK;
		ks_stdptr<IStream> spStream;
		
		switch (pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			{
				hr = CreateStreamOnFile(pMedium->lpszFileName, 
					pMedium->grfModeForFileName, &spStream);
				ASSERT(
					spStream
					);
				if (FAILED(hr))
					return hr;
			}
			break;
		case FILTER_TYMED_ISTREAM:
			spStream = pMedium->pstm;
			break;
		default:
			ASSERT(0);
			return E_FAIL;
		}
		
		return SUCCEEDED(hr) ? InitOnStream(spStream) : hr;
	}

public:
	STDMETHODIMP Transfer(
		IN IKContentHandler* pHandler)
	{
		if (pHandler == NULL)
			return E_INVALIDARG;
		if (m_spStreamUCTxt == NULL)
			return E_ACCESSDENIED;


		ks_stdptr<IStream> spStreamNew;
		textUnicodeTrimStream(
			m_spStreamUCTxt, &spStreamNew, IsPastingET());
		m_spStreamUCTxt = spStreamNew;

		HRESULT hr = E_FAIL;
		m_Document.Open();
		hr = m_Document.Transfer(m_spStreamUCTxt, pHandler, 
			IsPastingET() ? TxtModelTbl : TxtModelNormal);
		ASSERT_OK(hr);
		m_Document.Close();

		return hr;
	}
	
	STDMETHODIMP Close()
	{
		m_spStreamUCTxt.clear();
		return S_OK;
	}

public:
	STDMETHODIMP_(VOID) InitNew(
		IN IKFilterEventNotify* pNotify,
		IN UINT CodePage, 
		IN BOOL fClipboard)
	{
		m_pNotify = pNotify;
		m_SourceCodePage = CodePage;
		m_fClipboard = fClipboard;
	}

private:
	STDMETHODIMP InitOnStream(
		IN IStream* pStream)

	{
		ASSERT(
			pStream
			);
		if (pStream == NULL)
			return E_INVALIDARG;

		HRESULT hr = E_FAIL;

		if (m_SourceCodePage == KFC_CP_UNKNOWN)
		{
			if (m_pNotify)
			{
				KComVariant Var(pStream);
				hr = m_pNotify->OnNotify(
					FILTEREVENT_NEED_ENCODE, 
					KFC_CP_UNKNOWN, 
					&Var);
				CHECK(hr);
				if (Var.vt == VT_I4)
					m_SourceCodePage = LOWORD(Var.lVal);
			}
		}

		hr = _kso_ConvertStreamInline(
			&m_spStreamUCTxt, pStream, NULL, m_SourceCodePage);
		KS_CHECK(hr);

	KS_EXIT:
		return hr;
	}

	STDMETHODIMP_(BOOL) IsPastingET();

private:
	KTxtRDocument m_Document;
	UINT m_SourceCodePage;
	BOOL m_fClipboard;
	IKFilterEventNotify* m_pNotify;
	ks_stdptr<IStream> m_spStreamUCTxt;

	BEGIN_QUERYINTERFACE(IKFilterMediaInit)
		ADD_INTERFACE(IKContentSource)
	END_QUERYINTERFACE()
	DECLARE_COUNT(KTxTextReader)
};

// -------------------------------------------------------------------------
#endif /* __TEXTREADER_H__ */

// $Log: textreader.h,v $
// Revision 1.7  2005/05/27 07:39:40  wangdong
//  �����˶����ļ�鹤����
//
