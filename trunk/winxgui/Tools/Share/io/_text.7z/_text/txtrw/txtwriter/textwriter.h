/* -------------------------------------------------------------------------
//	�ļ���		��	textwriter.h
//	������		��	�ݽ���
//	����ʱ��	��	2005-3-10 16:05:34
//	��������	��	
//	$Id: textwriter.h,v 1.9 2005/08/05 09:44:26 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXTWRITER_H__
#define __TEXTWRITER_H__

#ifndef __KFC_VARIANT_H__
#include <kfc/variant.h>
#endif

#ifndef __KSO_IO_SCHEMA_H__
#include <kso/io/schema.h>
#endif

#ifndef __KSO_IO_FILTER_H__
#include <kso/io/filter.h>
#endif

#ifndef __KSO_IO_SCHEMA_DBG_H__
#include <kso/io/schema_dbg.h>
#endif

#ifndef __DOCUMENT_H__
#include "writer/document.h"
#endif

#ifndef __HANDLER_DOCUMENT_H__
#include "handler/document.h"
#endif

// -------------------------------------------------------------------------
class KTextWriter : 
	public KElementDispatcher, 
	public IKFilterMediaInit,
	public KComObjectRoot
{
public:
	STDMETHODIMP Init(
		IN UINT CodePage,
		IN UINT NewLine,
		IN IKFilterEventNotify* pNofity
		)
	{
		_kso_InitIoSchemaDbgInfo();
		m_CodePage = CodePage;
		m_NewLine = NewLine;
		m_pNotify = pNofity;
		if (m_pNotify)
			m_pNotify->AddRef();
		return S_OK;
	}
	~KTextWriter()
	{
		KS_RELEASE(m_pNotify);
	}

public:
	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		m_ImpContext.Close(TRUE);
		switch (pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			return m_ImpContext.OpenOnFile(
				pMedium->lpszFileName, 
				m_CodePage, 
				(TxtNewLineType)m_NewLine
				);
			break;
		case FILTER_TYMED_ISTREAM:
			return m_ImpContext.OpenOnStream(
				pMedium->pstm, 
				m_CodePage,
				(TxtNewLineType)m_NewLine
				);
			break;
		}
		return E_INVALIDARG;
	}

public:
	STDMETHODIMP StartDocument(
		IN UINT nReservedParam)
	{
		m_DocElem.Init(&m_ImpContext);
		return KElementDispatcher::Init(
			kso::office_document, &m_DocElem);
	}
    STDMETHODIMP EndDocument(
		IN BOOL fAbort)
	{
		if (fAbort)
		{
			m_ImpContext.Abort();
			return S_OK;
		}
		if (
			m_CodePage == KFC_CP_UNKNOWN && 
			m_pNotify
			)
		{
			ks_stdptr<IStream> spStream;
			m_ImpContext.Snapshot(&spStream);

			KComVariant Var(spStream);
			HRESULT hr = m_pNotify->OnNotify(
				FILTEREVENT_NEED_ENCODE, 
				KFC_CP_UNKNOWN, &Var
				);
			if (FAILED(hr))
			{
				m_ImpContext.Abort();
				return hr;
			}
			return m_ImpContext.Close(
				LOWORD(Var.lVal), (TxtNewLineType)HIWORD(Var.lVal));
		}
		return m_ImpContext.Close(m_CodePage);
	}

private:
	KTxtImpContext m_ImpContext;
	KDocElem m_DocElem;

	UINT m_CodePage;
	UINT m_NewLine;

	IKFilterEventNotify* m_pNotify;

	BEGIN_QUERYINTERFACE(IKContentHandler)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_COUNT(KTextWriter)
};


// -------------------------------------------------------------------------

#endif /* __TEXTWRITER_H__ */

// $Log: textwriter.h,v $
// Revision 1.9  2005/08/05 09:44:26  wangdong
// ֻҪ��ʧ�ܶ�Abort��
//
// Revision 1.8  2005/03/23 09:34:42  wangdong
// �����˴��ı���
//
// Revision 1.7  2005/03/18 03:32:42  wangdong
// �����ˡ�
//
// Revision 1.6  2005/03/18 03:32:10  wangdong
// HIWORD��LOWWORD���ˡ�
//
// Revision 1.5  2005/03/18 02:49:48  wangdong
// ��Ӧ����EVENT��
//
// Revision 1.4  2005/03/18 01:51:34  wangdong
// дtxt�ȶ���
//
