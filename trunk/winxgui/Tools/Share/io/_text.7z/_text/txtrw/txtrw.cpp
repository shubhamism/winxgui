// txtrw.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "l10n.h"
#include <kso/linklib.h>

KComModule _Module;

// -------------------------------------------------------------------------
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved)
{
    return TRUE;
}

// -------------------------------------------------------------------------
