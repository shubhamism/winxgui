/* -------------------------------------------------------------------------
//	�ļ���		��	para.h
//	������		��	����
//	����ʱ��	��	2005-3-16 10:28:28
//	��������	��	
//	$Id: para.h,v 1.4 2006/02/14 10:25:58 zhuyie Exp $
// -----------------------------------------------------------------------*/
#ifndef __PARA_H__
#define __PARA_H__

#ifndef __KSO_IO_FILTER_H__
#include <kso/io/filter.h>
#endif

#ifndef __FIELD_H__
#include "field.h"
#endif

class KAtnBegin;
class KAtnEnd;
class KFootnoteElem;
class KFieldBeginHandler;
class KFieldSepHandler;
class KTxtImpContext;

// -------------------------------------------------------------------------
class KSpanElem : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
	KAtnBegin* m_pAtnBegin;
	KAtnEnd* m_pAtnEnd;
	KFootnoteElem* m_pFootnote;
	KFakeUnknown<KElementHandler>* m_pFakeElement;
	BOOL m_revHidden;

public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext);
public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs);
	STDMETHODIMP AddContent(
		IN CONTENTVALUE_PTR pContent);
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID, 
		OUT IKElementHandler** ppHandler);
public:
	KSpanElem();
	~KSpanElem();
};

// -------------------------------------------------------------------------
class KParaElem : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
	KSpanElem m_SpanElem;
	KFieldBeginHandler m_FieldBegin;
	KFieldSepHandler m_FieldSep;

public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
		m_SpanElem.Init(m_pImpContext);
		m_FieldBegin.Init(m_pImpContext);
		m_FieldSep.Init(m_pImpContext);
	}

public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, 
		IN KROAttributes* pAttributes);
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID, 
		OUT IKElementHandler** ppHandler);
	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID);
};

// -------------------------------------------------------------------------

#endif /* __PARA_H__ */

// $Log: para.h,v $
// Revision 1.4  2006/02/14 10:25:58  zhuyie
// �޸�Bug24240��֮ǰ�ĸķ������ڴ�й©��
//
// Revision 1.3  2005/07/13 07:21:24  wangdong
// no message
//
// Revision 1.2  2005/07/02 02:52:23  wangdong
// �޶���
//
// Revision 1.1  2005/03/18 01:51:15  wangdong
// дtxt�ȶ���
//
