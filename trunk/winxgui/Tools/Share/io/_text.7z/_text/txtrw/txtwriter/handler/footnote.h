/* -------------------------------------------------------------------------
//	�ļ���		��	footnote.h
//	������		��	����
//	����ʱ��	��	2005-3-17 11:48:59
//	��������	��	
//	$Id: footnote.h,v 1.1 2005/03/18 01:51:15 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __FOOTNOTE_H__
#define __FOOTNOTE_H__


#ifndef __PARA_H__
#include "para.h"
#endif

// -------------------------------------------------------------------------
class KFootnoteElem : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
	KParaElem m_ParaElem;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
		m_ParaElem.Init(m_pImpContext);
	}
public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		m_pImpContext->BeginRegion();
		return S_OK;
	}
	STDMETHODIMP EndElement(IN ELEMENTID uElementID)
	{
		m_pImpContext->EndRegion();
		return S_OK;
	}
public:
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case kso::text_p:
			*ppHandler = &m_ParaElem;
			break;
		case kso_schema::text_table:
			return IO_E_IGNORE;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};


// -------------------------------------------------------------------------

#endif /* __FOOTNOTE_H__ */

// $Log: footnote.h,v $
// Revision 1.1  2005/03/18 01:51:15  wangdong
// дtxt�ȶ���
//
