/* -------------------------------------------------------------------------
//	�ļ���		��	document_impl.h
//	������		��	����
//	����ʱ��	��	2005-4-20 14:46:13
//	��������	��	
//	$Id: document_impl.h,v 1.2 2005/04/25 08:10:16 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOCUMENT_IMPL_H__
#define __DOCUMENT_IMPL_H__

// -------------------------------------------------------------------------
inline
STDMETHODIMP KTxtRDocument::Open()
{
	m_normalHandl.Open(&m_mainModel);
	m_tokenHandl.Open(&m_mainModel);
	m_tblHandl.Open(&m_mainModel);

	return S_OK;
}

inline
STDMETHODIMP KTxtRDocument::Close()
{
	m_tblHandl.Close();
	m_tokenHandl.Close();
	m_normalHandl.Close();

	return S_OK;
}

inline
STDMETHODIMP KTxtRDocument::Transfer(
	IN IStream* pStream,
	IN IKContentHandler* pHandler,
	IN TxtModel Model)
{
	static LPCWSTR tokensNormal[] = 
	{
			__X("\r\n"),
			__X("\n\r"),
			__X("\n"),
			__X("\r"),
	};

	static LPCWSTR tokensTbl[] = 
	{
			__X("\r\n"),
			__X("\n\r"),
			__X("\n"),
			__X("\r"),
			__X("\t"),
			__X("\""),
	};

	HRESULT hr = E_FAIL;
	{
		switch (Model)
		{
		default:
			ASSERT(0);
		case TxtModelNormal:
			m_mainParser.Open(&m_normalHandl, 
				&m_tokenHandl, tokensNormal, countof(tokensNormal));
			break;
		case TxtModelTbl:
			m_mainParser.Open(&m_normalHandl, 
				&m_tblHandl, tokensTbl, countof(tokensTbl));
			break;
		}

		hr = m_mainModel.BeginDocument(pHandler, Model);
		KS_CHECK(hr);

		hr = m_mainParser.Parse(pStream);
		KS_CHECK(hr);

		hr = m_mainModel.EndDocument();
		KS_CHECK(hr);

		m_mainParser.Close();
	}
	
KS_EXIT:
	return hr;
}

inline
KTxtModel::KTxtModel()
{
	m_Handler = NULL;
}

inline
KTxtModel::~KTxtModel()
{
	ASSERT(
		m_Handler == NULL
		);
	KS_RELEASE(m_Handler);
}

// -------------------------------------------------------------------------

#endif /* __DOCUMENT_IMPL_H__ */

// $Log: document_impl.h,v $
// Revision 1.2  2005/04/25 08:10:16  wangdong
// ����txt��
//
// Revision 1.1  2005/04/25 01:57:14  wangdong
// ������txt��
//
