/* -------------------------------------------------------------------------
//	�ļ���		��	document.h
//	������		��	����
//	����ʱ��	��	2005-4-20 14:17:55
//	��������	��	
//	$Id: document.h,v 1.1 2005/04/25 01:57:14 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __HANDLER_DOCUMENT_H__
#define __HANDLER_DOCUMENT_H__

#ifndef __KSO_IO_FILTER_H__
#include <kso/io/filter.h>
#endif


// -------------------------------------------------------------------------
enum TxtModel { TxtModelNormal, TxtModelTbl };

class KTxtModel
{
public:
	STDMETHODIMP BeginDocument(
		IN IKContentHandler* pHandler,
		IN TxtModel Model
		);
	STDMETHODIMP EndDocument(
		IN BOOL fAbort = FALSE
		);
	
public:
	STDMETHODIMP NewParagraph();
	STDMETHODIMP AddContent(
		IN LPCWSTR cont, 
		IN UINT cch
		);

public:
	STDMETHODIMP NewRow();
	STDMETHODIMP NewCell();

public:
	KTxtModel();
	~KTxtModel();

private:
	STDMETHODIMP EnterTbl();
	STDMETHODIMP LeaveTbl();

private:
	IKContentHandler* m_Handler;
	TxtModel m_Model;
};

// -------------------------------------------------------------------------
#ifndef __HANDLER_TEXT_H__
#include "text.h"
#endif

#ifndef __HANDLER_TOKEN_H__
#include "token.h"
#endif

//
// @@note:
//	�е㻳���������ڵı�Ҫ�ԡ�
//
class KTxtRDocument
{
public:
	STDMETHODIMP Open();
	STDMETHODIMP Close();

public:
	STDMETHODIMP Transfer(
		IN IStream* pStream,
		IN IKContentHandler* pHandler,
		IN TxtModel Model
		);

private:
	KTxtNormalHandler m_normalHandl;
	KTxtTokenHandler m_tokenHandl;
	KTxtTableTokenHandler m_tblHandl;
	KTxtModel m_mainModel;
	KTxtParser m_mainParser;
};


// -------------------------------------------------------------------------
#ifndef __MODEL_IMPL_H__
#include "model_impl.h"
#endif

#ifndef __DOCUMENT_IMPL_H__
#include "document_impl.h"
#endif


// -------------------------------------------------------------------------

#endif /* __HANDLER_DOCUMENT_H__ */

// $Log: document.h,v $
// Revision 1.1  2005/04/25 01:57:14  wangdong
// ������txt��
//
