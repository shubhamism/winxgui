/* -------------------------------------------------------------------------
//	�ļ���		��	textwriter.cpp
//	������		��	�ݽ���
//	����ʱ��	��	2005-3-10 16:05:46
//	��������	��	
//	$Id: textwriter.cpp,v 1.5 2005/03/18 01:51:34 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "textwriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
EXPORTAPI _TxCreateTextWriter(
	OUT IKFilterMediaInit** ppv,
	IN IKFilterEventNotify* pNotify,
	IN UINT CodePage,
	IN UINT NewLine)
{
	if (ppv == NULL)
		return E_INVALIDARG;

	KComObjectPtr<KTextWriter> sp(create_instance);
	sp->Init(CodePage, NewLine, pNotify);
	*ppv = sp.detach();

	return S_OK;
}


// -------------------------------------------------------------------------
// $Log: textwriter.cpp,v $
// Revision 1.5  2005/03/18 01:51:34  wangdong
// дtxt�ȶ���
//
