/* -------------------------------------------------------------------------
//	�ļ���		��	para.cpp
//	������		��	����
//	����ʱ��	��	2005-3-17 9:16:44
//	��������	��	
//	$Id: para.cpp,v 1.7 2006/02/14 10:25:53 zhuyie Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "para.h"

#include <kso/io/schema.h>
#include <txtwriter/writer/document.h>

#include "comment.h"
#include "footnote.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// -------------------------------------------------------------------------
KSpanElem::KSpanElem()
{
	m_pAtnBegin = NULL;
	m_pAtnEnd = NULL;
	m_pFootnote = NULL;
	m_pFakeElement = NULL;
}

KSpanElem::~KSpanElem()
{
	delete m_pAtnEnd;
	delete m_pAtnBegin;
	delete m_pFootnote;
	delete m_pFakeElement;
}

STDMETHODIMP_(VOID) KSpanElem::Init(
	IN KTxtImpContext* pImpContext)
{
	m_pImpContext = pImpContext;
	if (m_pAtnBegin)
		m_pAtnBegin->Init(m_pImpContext);
	if (m_pAtnEnd)
		m_pAtnEnd->Init(m_pImpContext);
	if (m_pFootnote)
		m_pFootnote->Init(m_pImpContext);
	m_pFakeElement = new KFakeUnknown<KElementHandler>;
}

STDMETHODIMP KSpanElem::StartElement(
	IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
{
	const UINT revView = m_pImpContext->get_RevView();

	m_revHidden = FALSE;

	KROAttributes* pAttrChg = NULL;
	pAttrs->GetByID(kso::office_change_deletion, &pAttrChg);
	if (pAttrChg)
	{
		// ɾ�����޶�������״̬������
		UINT ct;
		if (SUCCEEDED( pAttrChg->GetByID(kso::office_change_type, &ct) ))
		{
			ASSERT(ct == ctDelete);
			m_revHidden = (revView == kso_text::revViewFinal) ? TRUE : FALSE;
		}
		goto KS_DONE;
	}

	pAttrs->GetByID(kso::office_change_insertion, &pAttrChg);
	if (pAttrChg)
	{
		// ������޶���ԭʼ״̬������
		UINT ct;
		if (SUCCEEDED( pAttrChg->GetByID(kso::office_change_type, &ct) ))
		{
			ASSERT(ct == ctInsert);
			m_revHidden = (revView == kso_text::revViewOriginal) ? TRUE : FALSE;
		}
	}

KS_DONE:
	return S_OK;
}

STDMETHODIMP KSpanElem::EnterSubElement(
	IN ELEMENTID uSubElementID, 
	OUT IKElementHandler** ppHandler)
{
	if (m_revHidden)
	{
		*ppHandler = m_pFakeElement;
		return S_OK;
	}

	switch (uSubElementID)
	{
	case kso::text_annotation_begin:
		if (m_pAtnBegin == NULL)
		{
			m_pAtnBegin = new KAtnBegin;
			m_pAtnBegin->Init(m_pImpContext);
		}
		*ppHandler = m_pAtnBegin;
		break;
	case kso::text_annotation_end:
		if (m_pAtnEnd == NULL)
		{
			m_pAtnEnd = new KAtnEnd;
			m_pAtnEnd->Init(m_pImpContext);
		}
		*ppHandler = m_pAtnEnd;
		break;
	case kso::text_footnote:
	case kso::text_endnote:
		if (m_pFootnote == NULL)
		{
			m_pFootnote = new KFootnoteElem;
			m_pFootnote->Init(m_pImpContext);
		}
		*ppHandler = m_pFootnote;
		break;
	case kso::draw_shape:
	case kso::draw_group:
	case kso::text_citation_break:
	case kso::text_range_begin:
	case kso::text_range_end:
	case kso::text_hyperlink_begin:
	case kso::text_hyperlink_end:
	case kso::text_symbol:
		return IO_E_IGNORE;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP KSpanElem::AddContent(
	IN CONTENTVALUE_PTR pContent)	
{
	if (m_revHidden)
		return S_OK;

	ASSERT(
		pContent->vt == CONTENTVALUE::vtString
		);

	const UINT cch = SysStringLen(pContent->bstrVal);
	if (cch == 0)
	{
		ASSERT(0);
		return S_OK;
	}
	switch(pContent->bstrVal[cch - 1])
	{
	case kso_text::chHardLineBrk:
	case kso_text::chParaEnd:
	case kso_text::chSectMark:
	case kso_text::chPageBrk:
	case kso_text::chColumnBrk:
		if (cch - 1 > 0)
		{
			return m_pImpContext->AddContent(
				pContent->bstrVal,
				cch - 1
				);
		}
		break;
	default:
		return m_pImpContext->AddContent(
			pContent->bstrVal, 
			cch
			);
		break;
	}
	return S_OK;
}

STDMETHODIMP KParaElem::EnterSubElement(
	IN ELEMENTID uSubElementID, 
	OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case kso::text_span:
		*ppHandler = &m_SpanElem;
		break;
	case kso::text_field_begin:
		*ppHandler = &m_FieldBegin;
		break;
	case kso::text_field_separate:
		*ppHandler = &m_FieldSep;
		break;
	case kso::text_field_end:
		return IO_E_IGNORE;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP KParaElem::EndElement(
	IN ELEMENTID uElementID)
{
	return m_pImpContext->EndParagraph();
}

STDMETHODIMP KParaElem::StartElement(
	IN ELEMENTID uElementID, 
	IN KROAttributes* pAttributes)
{
	KROAttributes* AttrInd = NULL;
	pAttributes->GetByID(kso::text_p_indent, &AttrInd);
	if (AttrInd)
	{
		INT Value = 0;
		if (FAILED(AttrInd->GetByID(kso::text_p_first_line_relative, &Value)))
			AttrInd->GetByID(kso::text_p_first_line, &Value);
		if (Value != 0)
			m_pImpContext->TabRight();
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// $Log: para.cpp,v $
// Revision 1.7  2006/02/14 10:25:53  zhuyie
// �޸�Bug24240��֮ǰ�ĸķ������ڴ�й©��
//
// Revision 1.6  2006/02/14 07:18:49  zhuyie
// �޸�Bug24240����Ϊ�ϲ�Ĵ������EnterSubElement���سɹ�ʱ*ppHandler != NULL��������޶�����������·���һ���յ�Handler��
//
// Revision 1.5  2005/07/28 05:10:30  zhuyie
// �޶����죬֧��ͬһ���ϵĶ���޶���
//
// Revision 1.4  2005/07/13 07:21:24  wangdong
// no message
//
// Revision 1.3  2005/07/02 02:52:23  wangdong
// �޶���
//
// Revision 1.1  2005/03/18 01:51:15  wangdong
// дtxt�ȶ���
//
