/* -------------------------------------------------------------------------
//	�ļ���		��	parser_impl.h
//	������		��	����
//	����ʱ��	��	2005-4-19 15:35:41
//	��������	��	
//	$Id: parser_impl.h,v 1.6 2005/05/11 02:27:39 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __PARSER_IMPL_H__
#define __PARSER_IMPL_H__

#ifndef BOOST_SCOPED_ARRAY_HPP_INCLUDED
#include <boost/scoped_array.hpp>
#endif


// -------------------------------------------------------------------------
inline
STDMETHODIMP KTxtParser::Open(
	IN KTxtHandler* textHandler,
	IN KTxtHandler* tokenHandler,
	IN LPCWSTR Tokens[],
	IN UINT cTokens
	)
{
	ASSERT(
		m_tokenList.empty()
		);
	if (m_tokenList.size())
		return E_ACCESSDENIED;

	//
	// @@note:
	//	�������ֵ�handler����Ҫ�С�
	//
	ASSERT(
		textHandler != NULL
		);
	if (textHandler == NULL)
		return E_INVALIDARG;

	//
	// @@note:
	//	���Բ�����Token����һ��Ҫ����Token���Ǿ�Ҫ���㣺	
	//	(cTokens && Tokens && tokenHandler)
	//
	ASSERT(
		cTokens == 0 ||
		(cTokens && Tokens && tokenHandler)
		);
	if (
		!(cTokens == 0 ||
		(cTokens && Tokens && tokenHandler))
		)
	{
		return E_INVALIDARG;
	}

	m_textHandler = textHandler;
	m_tokenHandler = tokenHandler;

	m_tokenList.resize(cTokens);
	std::copy(Tokens, Tokens + cTokens, m_tokenList.begin());

	return S_OK;
}

__forceinline
STDMETHODIMP KTxtParser::Close()
{
	m_tokenList.clear();
	m_textHandler = NULL;
	m_tokenHandler = NULL;

	return S_OK;
}

inline
STDMETHODIMP KTxtParser::Parse(
							   IN IStream* pStream)
{
	ASSERT(
		pStream != NULL
		);

	if (pStream == NULL)
		return E_INVALIDARG;

	if (m_textHandler == NULL)
		return E_ACCESSDENIED;

	HRESULT hr = S_OK;
	{
		KReadArchive Ar(pStream);
		KS_CHECK_BOOLEX(
			Ar.good(), hr = E_ACCESSDENIED
			);

		std::vector<WCHAR> buf;
		WCHAR ch = 0;
		
		while (Ar.get((char*)&ch, sizeof(WCHAR)) != 0)
		{
			KReadArchive::pos_type pos = Ar.tell();

			TokenIterator i = m_tokenList.begin();
			for (; i != m_tokenList.end(); ++i)
			{
				ASSERT(
					i->size()
					);

				UINT cb = (i->size() - 1) * sizeof(WCHAR);
				if (cb != 0)
				{
					boost::scoped_array<char> sp_tokp(new char[cb + sizeof(WCHAR)]);
					LPWSTR tokp = (LPWSTR)sp_tokp.get();
					tokp[0] = ch;

					UINT cbGot = Ar.get((char*)(tokp + 1), cb);
					if (
						cbGot != cb ||
						memcmp(i->c_str(), tokp, i->size() * sizeof(WCHAR)) != 0
						)
					{
						Ar.seek(Ar.tell() - cbGot);
						continue;
					}
				}
				else
				{
					if (ch != *i->begin())
						continue;
				}

				if (buf.size())
				{
					hr = m_textHandler->AddContent(buf.begin(), buf.size());
					buf.clear();
					KS_CHECK_BOOL(
						hr != E_ABORT
						);
				}

				hr = m_tokenHandler->AddContent(i->c_str(), i->size());
				KS_CHECK_BOOL(
					hr != E_ABORT
					);

				goto TOKEN_MATCHED;
			}

			buf.push_back(ch);

TOKEN_MATCHED:
			continue;
		}

		if (buf.size())
		{
			hr = m_textHandler->AddContent(buf.begin(), buf.size());
			buf.clear();
			KS_CHECK_BOOL(
				hr != E_ABORT
				);
		}

	}
	
KS_EXIT:
	return hr;
}


// -------------------------------------------------------------------------

#endif /* __PARSER_IMPL_H__ */

// $Log: parser_impl.h,v $
// Revision 1.6  2005/05/11 02:27:39  wangdong
// ԭ�ȵ�_allocaʹ���������׵��¶�ջ��������ڻ���new��
//
// Revision 1.5  2005/04/25 08:10:16  wangdong
// ����txt��
//
// Revision 1.4  2005/04/25 01:56:04  wangdong
// ������txt��
//
// Revision 1.1  2005/04/19 09:48:35  wangdong
// ��et����
//
