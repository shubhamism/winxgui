#define FILEVER        1,0,0,66
#define PRODUCTVER     1,0,0,66
#define STRFILEVER     "1,0,0,66\0"
#define STRPRODUCTVER  "1,0,0,66\0" 
