/* -------------------------------------------------------------------------
//	�ļ���		��	write.cpp
//	������		��	����
//	����ʱ��	��	2005-3-14 17:54:43
//	��������	��	
//	$Id: write.cpp,v 1.2 2005/03/18 01:51:28 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "common.h"

#include <kfc/encoding/encoding.h>
#include <txtwriter/writer/document.h>
#include <txtwriter/writer/textstream.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
static 
const WCHAR text[] 
		= L"�������ã�Long Life CCP!";

// -------------------------------------------------------------------------
class TestWriter : public TestFixture
{
	CPPUNIT_TEST_SUITE(TestWriter);
		CPPUNIT_TEST(CaseFile);
		CPPUNIT_TEST(CaseStream);
		CPPUNIT_TEST(CaseArchive);
		CPPUNIT_TEST(CaseDocument);
		CPPUNIT_TEST(CaseRegion);
		CPPUNIT_TEST(CaseSubDocument);
		CPPUNIT_TEST(CaseTrimNewLine);
	CPPUNIT_TEST_SUITE_END();
	
public:
	void setUp()
	{
	}
  	void tearDown()
	{
	}

public:
	void CaseFile()
	{
		KTxtStream txtStream;
		txtStream.OpenOnFile(L"C:\\test.txt", KFC_CP_UCS2LittleEndian);
		
		txtStream.Write(text, countof(text) - 1);
		txtStream.NewLine();
		txtStream.Write(text, countof(text) - 1);
		txtStream.NewLine();
		txtStream.Write(text, countof(text) - 1);
		txtStream.Write(text, countof(text) - 1);
		txtStream.NewLine();
		txtStream.Write(
			L"this\r\n is a\r newline\n\r char:\n",
			wcslen(L"this\r\n is a\r newline\n\r char:\n")
			);
		txtStream.Write(text, countof(text) - 1);
		txtStream.NewLine();

		txtStream.Close(TRUE);
	}
	void CaseStream()
	{
		// 1:
		{
			ks_stdptr<IStream> spStream;
			CreateStreamOnFile(
				L"C:\\test2.txt", 
				STGM_CREATE | STGM_WRITE, 
				&spStream);

			KTxtStream txtStream;
			txtStream.OpenOnStream(spStream, GetACP(), FALSE, DefaultNewLineType);
			
			txtStream.Write(text, countof(text) - 1);
			txtStream.NewLine();
			txtStream.Write(text, countof(text) - 1);
			txtStream.NewLine();
			txtStream.Write(text, countof(text) - 1);
			txtStream.Write(text, countof(text) - 1);
			txtStream.Write(text, countof(text) - 1);

			txtStream.Close();
		}

		// 2:
		{
			KTxtStream txtStream;
			KTxtStream txtStream2;

			txtStream.OpenOnStream(NULL, KFC_CP_UCS2LittleEndian);
			txtStream2.OpenOnFile(L"C:\\test3.txt", KFC_CP_UCS2LittleEndian, TRUE);

			txtStream2.Write(L"TXT", 3);
			txtStream2.NewLine();

			
			txtStream.Write(text, countof(text) - 1);
			txtStream.NewLine();
			txtStream.Write(text, countof(text) - 1);
			txtStream.NewLine();
			txtStream.Write(text, countof(text) - 1);
			txtStream.Write(text, countof(text) - 1);
			txtStream.Write(text, countof(text) - 1);

			txtStream.CopyTo(txtStream2);

			txtStream2.NewLine();
			txtStream2.Write(L"TXT", 3);

			txtStream.Close();
			txtStream2.Close();
		}
	}
	void CaseArchive()
	{
		ks_stdptr<IStream> spStream;
		XCreateStreamOnHGlobal(NULL, TRUE, &spStream);

		KTxtArchive Ar;
		ASSERT(
			Ar.bad()
			);

		VERIFY_OK(
			Ar.open(spStream)
		);
	}
	void CaseDocument()
	{
		KTxtImpContext document;
		document.OpenOnFile(L"C:\\docu.txt", CP_ACP, DefaultNewLineType);

		document.AddContent(L"ABC", 3);
		document.EndParagraph();
		document.AddContent(L"ABC", 3);
		document.EndParagraph();
		document.AddContent(L"ABC", 3);
		document.EndParagraph();

		document.Close(GetACP(), NewLine_LF);
	}
	void CaseRegion()
	{
		KTxtImpContext document;
		document.OpenOnFile(L"C:\\docu2.txt", CP_ACP, DefaultNewLineType);

		document.AddContent(text, wcslen(text));

		document.BeginRegion();
		document.AddContent(L"Comment", wcslen(L"Comment"));
		document.EndRegion();

		document.EndParagraph();

		document.Close();
	}
	void CaseSubDocument()
	{
		KTxtImpContext document;
		document.OpenOnFile(L"C:\\docu3.txt", 
			KFC_CP_UNKNOWN, DefaultNewLineType);

		document.AddContent(text, wcslen(text));

		HDOC hDoc = document.EnterDocument();
		document.AddContent(L"Comment", wcslen(L"Comment"));
		document.LeaveDocument();

		VERIFY_OK(
			document.MergeDocument(hDoc)
			);
		VERIFY_OK(
			document.MergeDocument(hDoc)
			);
		VERIFY_OK(
			document.MergeDocument(hDoc)
			);

		document.EndParagraph();

		document.Close(KFC_CP_UCS2BigEndian);
	}
	void CaseTrimNewLine()
	{
		KTxtStream txtStream;
		txtStream.OpenOnFile(L"C:\\TrimNewLine.txt");
		
		txtStream.Write(text, countof(text) - 1);
		txtStream.NewLine();
		txtStream.Close(TRUE);
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestWriter);

// -------------------------------------------------------------------------
// $Log: write.cpp,v $
// Revision 1.2  2005/03/18 01:51:28  wangdong
// дtxt�ȶ���
//
