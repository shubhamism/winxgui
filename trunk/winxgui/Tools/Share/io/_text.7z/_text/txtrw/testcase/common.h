/* -------------------------------------------------------------------------
//	�ļ���		��	common.h
//	������		��	����
//	����ʱ��	��	2005-3-14 17:54:30
//	��������	��	
//	$Id: common.h,v 1.3 2005/04/25 01:56:04 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __COMMON_H__
#define __COMMON_H__


// -------------------------------------------------------------------------
#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif

#ifndef __KSO_DIRCFGINFO_H__
#include <kso/dircfginfo.h>
#endif

#ifndef __KSO_IO_V6_FILTER_PLUGIN_H__
#include <kso/io/v6/filter/plugin.h>
#endif


// -------------------------------------------------------------------------
interface IKContentHandler;
interface IKFilterMediaInit;
interface IKFilterEventNotify;

// -------------------------------------------------------------------------
inline 
STDMETHODIMP __testCreateDocWriter(
	OUT IKFilterMediaInit** ppMediaInit)
{
	typedef 
	HRESULT  (__stdcall *FnExportCreate)(
		IN long, IN IKFilterEventNotify*, OUT IKFilterMediaInit**);

	
	WCHAR path[_MAX_PATH];
	_kso_GetDirInfo(_kso_dir_root, 
		KSO_LANGUAGE_AUTO, TRUE, path, _MAX_PATH);
	wcscat(path, L"/office6/docwriter.dll");

	HMODULE hLib = LoadLibraryW(path);

	FnExportCreate pFn = (FnExportCreate)GetProcAddress(hLib, "filterpluginExportCreate");
	ASSERT(
		pFn != NULL
		);

	return pFn(filterKSOXMLText | (1) , NULL, ppMediaInit);
}

// -------------------------------------------------------------------------
inline 
STDMETHODIMP testCreateTestHandler(
	OUT IKFilterMediaInit** ppMediaInit)
{
	return __testCreateDocWriter(ppMediaInit);
}

// -------------------------------------------------------------------------

#endif /* __COMMON_H__ */

// $Log: common.h,v $
// Revision 1.3  2005/04/25 01:56:04  wangdong
// ������txt��
//
// Revision 1.2  2005/03/18 01:50:56  wangdong
// дtxt�ȶ���
//
