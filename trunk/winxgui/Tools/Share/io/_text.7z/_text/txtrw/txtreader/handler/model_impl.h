/* -------------------------------------------------------------------------
//	�ļ���		��	model_impl.h
//	������		��	����
//	����ʱ��	��	2005-4-20 14:47:59
//	��������	��	
//	$Id: model_impl.h,v 1.3 2005/06/02 08:51:49 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __MODEL_IMPL_H__
#define __MODEL_IMPL_H__

#ifndef __KSO_IO_SCHEMA_H__
#include <kso/io/schema.h>
#endif


// -------------------------------------------------------------------------
inline
STDMETHODIMP KTxtModel::BeginDocument(
	IN IKContentHandler* pHandler,
	IN TxtModel Model
	)
{
	if (pHandler == NULL)
		return E_INVALIDARG;
	if (m_Handler != NULL)
		return E_ACCESSDENIED;
	KS_ASSIGN(m_Handler, pHandler);

	HRESULT hr = E_FAIL;
	{
		hr = m_Handler->StartDocument(0);
		KS_CHECK(hr);

		hr = m_Handler->StartElement(kso::office_document);
		KS_CHECK(hr);

		hr = m_Handler->StartElement(kso::office_body);
		CHECK(hr);
	}
	
	m_Model = Model;

	switch (m_Model)
	{
	case TxtModelNormal:
		hr = m_Handler->StartElement(kso::text_p);
		if (m_Model != TxtModelTbl)
			m_Handler->AddAttributes(NULL);
		break;
	case TxtModelTbl:
		EnterTbl();
		break;
	}

KS_EXIT:
	return hr;
}

inline
STDMETHODIMP KTxtModel::EndDocument(
	IN BOOL fAbort
	)
{
	if (m_Handler == NULL)
		return E_ACCESSDENIED;

	HRESULT hr = E_FAIL;

	switch (m_Model)
	{
	case TxtModelNormal:
//		AddContent(&kso_text::chParaEnd, 1);
		hr = m_Handler->EndElement(kso::text_p);
		ASSERT_OK(hr);
		break;
	case TxtModelTbl:
		LeaveTbl();
		break;
	}

	hr = m_Handler->EndElement(kso::office_body);
	ASSERT_OK(hr);

	hr = m_Handler->EndElement(kso::office_document);
	ASSERT_OK(hr);

	hr = m_Handler->EndDocument(fAbort);
	KS_CHECK(hr);

KS_EXIT:
	KS_RELEASE(m_Handler);
	return hr;
}
	
inline
STDMETHODIMP KTxtModel::NewParagraph()
{
	AddContent(&kso_text::chParaEnd, 1);

	VERIFY_OK(
		m_Handler->EndElement(kso::text_p)
		);
	VERIFY_OK(
		m_Handler->StartElement(kso::text_p)
		);
	if (m_Model != TxtModelTbl)
		m_Handler->AddAttributes(NULL);
	
	return S_OK;
}

inline
STDMETHODIMP KTxtModel::AddContent(
	IN LPCWSTR cont, 
	IN UINT cch
	)
{
	HRESULT hr = m_Handler->StartElement(kso::text_r);
	KS_CHECK(hr);

	if (m_Model != TxtModelTbl)
		m_Handler->AddAttributes(NULL);

	hr = m_Handler->AddContent(&CONTENTVALUE(cont, cch));
	ASSERT_OK(hr);

	m_Handler->EndElement(kso::text_r);
	ASSERT_OK(hr);

KS_EXIT:
	return hr;
}

inline
STDMETHODIMP KTxtModel::EnterTbl()
{
	HRESULT hr = m_Handler->StartElement(kso_schema::text_table);
	CHECK(hr);
	hr = m_Handler->StartElement(kso_schema::text_row);
	KS_CHECK(hr);
	hr = m_Handler->StartElement(kso_schema::text_cell);
	KS_CHECK(hr);
	hr = m_Handler->StartElement(kso::text_p);
	KS_CHECK(hr);
	if (m_Model != TxtModelTbl)
		m_Handler->AddAttributes(NULL);

KS_EXIT:
	return hr;
}

inline
STDMETHODIMP KTxtModel::NewCell()
{
	HRESULT hr = E_FAIL;
	
	AddContent(&kso_text::chParaEnd, 1);

	hr = m_Handler->EndElement(kso::text_p);
	ASSERT_OK(hr);

	hr = m_Handler->EndElement(kso_schema::text_cell);
	ASSERT_OK(hr);

	hr = m_Handler->StartElement(kso_schema::text_cell);
	ASSERT_OK(hr);

	hr = m_Handler->StartElement(kso::text_p);
	ASSERT_OK(hr);
	if (m_Model != TxtModelTbl)
		m_Handler->AddAttributes(NULL);


	return hr;
}

inline
STDMETHODIMP KTxtModel::NewRow()
{
	HRESULT hr = E_FAIL;
	
	AddContent(&kso_text::chParaEnd, 1);

	hr = m_Handler->EndElement(kso::text_p);
	ASSERT_OK(hr);

	hr = m_Handler->EndElement(kso_schema::text_cell);
	ASSERT_OK(hr);

	m_Handler->StartElement(kso::text_p);
	AddContent(&kso_text::chParaEnd, 1);
	m_Handler->EndElement(kso::text_p);

	hr = m_Handler->EndElement(kso_schema::text_row);
	ASSERT_OK(hr);

	hr = m_Handler->StartElement(kso_schema::text_row);
	ASSERT_OK(hr);

	hr = m_Handler->StartElement(kso_schema::text_cell);
	ASSERT_OK(hr);

	hr = m_Handler->StartElement(kso::text_p);
	ASSERT_OK(hr);
	if (m_Model != TxtModelTbl)
		m_Handler->AddAttributes(NULL);

	return hr;
}

inline
STDMETHODIMP KTxtModel::LeaveTbl()
{
	HRESULT hr = E_FAIL;

	AddContent(&kso_text::chParaEnd, 1);
	
	hr = m_Handler->EndElement(kso::text_p);
	ASSERT_OK(hr);

	hr = m_Handler->EndElement(kso_schema::text_cell);
	ASSERT_OK(hr);

	m_Handler->StartElement(kso::text_p);
	AddContent(&kso_text::chParaEnd, 1);
	m_Handler->EndElement(kso::text_p);
	
	hr = m_Handler->EndElement(kso_schema::text_row);
	ASSERT_OK(hr);

	hr = m_Handler->EndElement(kso_schema::text_table);
	ASSERT_OK(hr);

	return hr;
}

// -------------------------------------------------------------------------

#endif /* __MODEL_IMPL_H__ */

// $Log: model_impl.h,v $
// Revision 1.3  2005/06/02 08:51:49  wangdong
// �����µ��м���޸ı����롣
//
// Revision 1.2  2005/05/27 07:38:20  wangdong
// �����˶����ļ�鹤����
//
// Revision 1.1  2005/04/25 01:57:14  wangdong
// ������txt��
//
