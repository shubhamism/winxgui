/* -------------------------------------------------------------------------
//	�ļ���		��	testdocwriter2.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-14 16:40:43
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTDOCWRITER2_H__
#define __TESTDOCWRITER2_H__

#ifndef __COMMON_H__
#include "common.h"
#endif

#ifndef __L10N_H__
#include "l10n.h"
#endif

#include <kso/io/v6/filter/plugin.h>
#include <kso/io/v6/filter/helper.h>
#include <kso/io/v6/filterstd/filter.h>


#define _IoFormat_Word97	(filterKSOXMLText | 0x01)

// -------------------------------------------------------------------------
interface IKFilterEventNotify;
interface IKFilterMediaInit;

STDAPI _TxCreateTextWriter(
	OUT IKFilterMediaInit** ppv,
	IN IKFilterEventNotify* pNotify,
	IN UINT CodePage,
	IN UINT NewLine);
 
// -------------------------------------------------------------------------

typedef STDMETHODIMP _FnInitialize();
typedef STDMETHODIMP _FnTermiate();
typedef STDMETHODIMP _FnFilterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv);
typedef _FnInitialize* FnInitialize;
typedef _FnTermiate* FnTermiate;
typedef _FnFilterpluginImportCreate* FnFilterpluginImportCreate;

class KConvertDoc2DocEx
{
private:
	HMODULE m_hLib;
	FnFilterpluginImportCreate m_fnCreateSource;
	FnTermiate m_fnTerm;
	
public:
	KConvertDoc2DocEx() : m_fnCreateSource(NULL), m_fnTerm(NULL), m_hLib(NULL)
	{
	}
	~KConvertDoc2DocEx()
	{
		term();
	}
	
	void term()
	{
		if (m_fnTerm)
		{
			m_fnTerm();
			m_fnTerm = NULL;
			m_fnCreateSource = NULL;
		}
		if (m_hLib)
		{
			FreeLibrary(m_hLib);
			m_hLib = NULL;
		}
	}

	void convert(
		IN LPCWSTR szDocFileSrc,
		IN LPCWSTR szDocFileDest,
		IN UINT CodePage,
		IN UINT NewLine)
	{
		printf("\n[loading \"%S\"...]\n", szDocFileSrc);
		WCHAR szSrcFile[_MAX_PATH];
		WCHAR szDocFile[_MAX_PATH];

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szSrcFile, MAX_PATH);
		wcscat(szSrcFile, __L("/"));
		wcscat(szSrcFile, szDocFileSrc);

		_kso_GetDirInfo(_kso_dir_office, KSO_LANGUAGE_NONE, TRUE, szDocFile, MAX_PATH);
		wcscat(szDocFile, __L("/"));
		wcscat(szDocFile, szDocFileDest);

		convertFile(szSrcFile, szDocFile, CodePage, NewLine);
	}

	HRESULT convertFile(
		IN LPCWSTR szSrcFile,
		IN LPCWSTR szDocFile,
		IN UINT CodePage,
		IN UINT NewLine)
	{
		//_XMsgBoxTraceW(__X("src = \"%s\", dest = \"%s\"\n"), szSrcFile, szDocFile);

		HRESULT hr = E_FAIL;
		if (m_fnCreateSource == NULL)
		{
			m_hLib = LoadLibrary("docreader");
			KS_CHECK_BOOL(m_hLib);
			
			FnInitialize fnInit = (FnInitialize)GetProcAddress(m_hLib, "_dr_Initialize");
			KS_CHECK_BOOL(fnInit);
			
			hr = fnInit();
			KS_CHECK(hr);
			
			m_fnCreateSource = (FnFilterpluginImportCreate)
				GetProcAddress(m_hLib, "filterpluginImportCreate");
			KS_CHECK_BOOLEX(m_fnCreateSource, hr = E_FAIL);
			
			m_fnTerm = (FnTermiate)GetProcAddress(m_hLib, "_dr_Terminate");
		}
		{
			ks_stdptr<IKFilterMediaInit> spInitSrc;
			hr = m_fnCreateSource(_IoFormat_Word97, NULL, &spInitSrc);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInitSrc, szSrcFile, STGM_T_READ);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentSource> spSrc;
			hr = spInitSrc->QI(IKContentSource, &spSrc);
			KS_CHECK(hr);
			
			ks_stdptr<IKFilterMediaInit> spInit;
			hr = _TxCreateTextWriter(
				&spInit, NULL, CodePage, NewLine);
			KS_CHECK(hr);
			
			hr = _kso_FileMediaInit(spInit, szDocFile, STGM_G_CREATE);
			KS_CHECK(hr);
			
			ks_stdptr<IKContentHandler> spAcc;
			hr = spInit->QI(IKContentHandler, &spAcc);
			KS_CHECK(hr);
			
			hr = spSrc->Transfer(spAcc);
			spSrc->Close();
			ASSERT_OK(hr);
		}
KS_EXIT:
		return hr;
	}
};

// -------------------------------------------------------------------------

#endif /* __TESTDOCWRITER2_H__ */

// $Log: testdoc2txt.h,v $
// Revision 1.1  2005/03/18 01:51:28  wangdong
// дtxt�ȶ���
//
