/* -------------------------------------------------------------------------
//	�ļ���		��	document.h
//	������		��	����
//	����ʱ��	��	2005-3-16 10:28:33
//	��������	��	
//	$Id: document.h,v 1.6 2006/06/21 07:04:20 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __HANDLER_DOCUMENT_H__
#define __HANDLER_DOCUMENT_H__

#ifndef __DOCUMENT_H__
#include "writer/document.h"
#endif

#ifndef __COMMENT_H__
#include "comment.h"
#endif

#ifndef __PARA_H__
#include "para.h"
#endif

#ifndef __TEXTTBL_H__
#include "texttbl.h"
#endif

class KSettingsElem : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		KROAttributes* pAttrRev = NULL;
		pAttrs->GetByID(kso::text_revision, &pAttrRev);
		if (pAttrRev)
		{
			UINT revView = kso_text::revViewFinal;
			pAttrRev->GetByID(kso::text_revView, &revView);
			m_pImpContext->put_RevView(revView);
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
class KBodyElem : public KFakeUnknown<KElementHandler>
{
	KParaElem m_ParaElem;
	KTableElem m_TableElem;
	KSettingsElem m_SettingElem;
	KFieldBeginHandler m_FieldBeginElem;
	KFieldSepHandler m_FieldSepElem;

public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_ParaElem.Init(pImpContext);
		m_TableElem.Init(pImpContext);
		m_SettingElem.Init(pImpContext);
		m_FieldBeginElem.Init(pImpContext);
		m_FieldSepElem.Init(pImpContext);
	}
	
public:
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID, 
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case kso::text_p:
			*ppHandler = &m_ParaElem;
			break;
		case kso_schema::text_table:
			*ppHandler = &m_TableElem;
			break;
		case kso::text_settings:
			*ppHandler = &m_SettingElem;
			break;
		default:
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
class KDocElem : public KFakeUnknown<KElementHandler>
{
	KBodyElem m_BodyElem;
	KAtnsElem m_AtnsElem;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_AtnsElem.Init(pImpContext);
		m_BodyElem.Init(pImpContext);
	}

public:
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID, 
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case kso::office_body:
			*ppHandler = &m_BodyElem;
			break;
		case kso::office_annotations:
			*ppHandler = &m_AtnsElem;
			break;
		case kso::office_styles:
		case kso::office_mediums:
		case kso::office_meta:
		case kso::office_users:
		case kso::office_changes:
		case kso::office_hyperlinks:
		case kso::office_bookmarks:
		case kso::draw_canvas:
		case kso::office_macro:
			return IO_E_IGNORE;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------

#endif /* __DOCUMENT_H__ */

// $Log: document.h,v $
// Revision 1.6  2006/06/21 07:04:20  wangdong
// ���Ӷ�Variable�Ķ�д֧�֡�
//
// Revision 1.5  2005/07/29 08:49:44  wangdong
// no message
//
// Revision 1.4  2005/07/13 07:21:24  wangdong
// no message
//
// Revision 1.3  2005/07/02 02:52:23  wangdong
// �޶���
//
// Revision 1.2  2005/06/23 06:45:06  rongjianxing
// *** empty log message ***
//
// Revision 1.1  2005/03/18 01:51:15  wangdong
// дtxt�ȶ���
//
