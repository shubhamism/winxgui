/* -------------------------------------------------------------------------
//	�ļ���		��	comment.h
//	������		��	����
//	����ʱ��	��	2005-3-17 11:48:04
//	��������	��	
//	$Id: comment.h,v 1.1 2005/03/18 01:50:50 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __COMMENT_H__
#define __COMMENT_H__

#ifndef __NULLIMPL_H__
#include "nullimpl.h"
#endif

#ifndef __PARA_H__
#include "para.h"
#endif


// -------------------------------------------------------------------------
class KAtnBegin : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
	}
public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		INT AtnInfo = -1;
		if (FAILED(
			pAttrs->GetByID(kso::text_annotation_info, &AtnInfo)
			))
		{
			return E_FAIL;
		}
		INT AtnId = -1;
		if (FAILED(
			pAttrs->GetByID(kso::text_annotation_id, &AtnId)
			))
		{
			return E_FAIL;
		}
		
		const CommentMap& Map = m_pImpContext->GetCommentMap();
		CommentMapIt it = Map.find(AtnInfo);
		if (it == Map.end())
			return E_FAIL;

		CommentMap& scopeMap = m_pImpContext->GetCommentScopeMap();
		scopeMap[AtnId] = (*it).second;

		return S_OK;
	}
};

class KAtnEnd : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
	}

public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		INT AtnId = -1;
		if (FAILED(
			pAttrs->GetByID(kso::text_annotation_id, &AtnId)
			))
		{
			return E_FAIL;
		}
		const CommentMap& Map = m_pImpContext->GetCommentScopeMap();
		CommentMapIt it = Map.find(AtnId);
		if (it == Map.end())
			return E_FAIL;

		m_pImpContext->MergeDocument((*it).second);

		return S_OK;
	}
};

// -------------------------------------------------------------------------
class KAtnElem : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
	KParaElem m_ParaElem;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
		m_ParaElem.Init(m_pImpContext);
	}

public:
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)
	{
		INT AtnId = -1;
		if (FAILED(pAttrs->GetByID(kso::office_annotation_id, &AtnId)))
			return E_FAIL;

		CommentMap& Map = m_pImpContext->GetCommentMap();
		Map[AtnId] = m_pImpContext->EnterDocument();

		return S_OK;
	}
	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID)
	{
		m_pImpContext->LeaveDocument();
		return S_OK;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case kso::text_p:
			*ppHandler = &m_ParaElem;
			break;
		case kso_schema::text_table:
			return IO_E_IGNORE;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
typedef
	KFakeUnknown
	<
		KCollectionHandler
		<
			KAtnElem,
			kso::office_annotation,
			KTxtImpContext
		>
	>
KAtnsElem;

// -------------------------------------------------------------------------

#endif /* __COMMENT_H__ */

// $Log: comment.h,v $
// Revision 1.1  2005/03/18 01:50:50  wangdong
// дtxt�ȶ���
//
