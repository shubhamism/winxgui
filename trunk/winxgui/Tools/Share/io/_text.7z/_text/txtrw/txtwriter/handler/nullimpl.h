/* -------------------------------------------------------------------------
//	�ļ���		��	nullimpl.h
//	������		��	����
//	����ʱ��	��	2005-3-17 11:50:53
//	��������	��	
//	$Id: nullimpl.h,v 1.1 2005/03/18 01:51:15 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __NULLIMPL_H__
#define __NULLIMPL_H__


// -------------------------------------------------------------------------

template <	class HandlerType, 
			int SubElementID, 
			class InitClass = KImpContext, 
			class BaseType = KFakeUnknown<KElementHandler> 
			>
class KCollectionHandler : public BaseType
{
private:
	HandlerType m_SubElement;
protected:
	InitClass* m_pImpContext;

public:
	STDMETHODIMP_(void) Init(
		IN InitClass* pContext)
	{
		m_pImpContext = pContext;
		m_SubElement.Init(m_pImpContext);
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)	
	{
		return S_OK;
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID,
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case SubElementID:
			*ppHandler = &m_SubElement;
			break;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------

#endif /* __NULLIMPL_H__ */

// $Log: nullimpl.h,v $
// Revision 1.1  2005/03/18 01:51:15  wangdong
// дtxt�ȶ���
//
