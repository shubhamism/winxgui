/* -------------------------------------------------------------------------
//	�ļ���		��	texttbl.h
//	������		��	����
//	����ʱ��	��	2005-3-17 11:49:58
//	��������	��	
//	$Id: texttbl.h,v 1.2 2005/06/02 08:51:49 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXTTBL_H__
#define __TEXTTBL_H__

#ifndef __NULLIMPL_H__
#include "nullimpl.h"
#endif

#ifndef __PARA_H__
#include "para.h"
#endif

// -------------------------------------------------------------------------
class KTableElem;
class KCellElem : public 
	KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
	KTableElem* m_pTableElem;
	KParaElem m_ParaElem;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext);

public:
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID, OUT IKElementHandler** ppHandler);
	STDMETHODIMP EndElement(
		IN ELEMENTID uSubElementID)
	{
		m_pImpContext->UndoEndParagraph();
		m_pImpContext->TabRight();
		return S_OK;
	}

public:
	KCellElem()
	{
		m_pTableElem = NULL;
	}
	~KCellElem();
};

class KRowElem : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
	KParaElem m_paraElem;
	KCellElem m_cellElem;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
		m_paraElem.Init(m_pImpContext);
		m_cellElem.Init(m_pImpContext);
	}
	STDMETHODIMP EnterSubElement(
		IN ELEMENTID uSubElementID, 
		OUT IKElementHandler** ppHandler)
	{
		switch (uSubElementID)
		{
		case kso::text_p:
			*ppHandler = &m_paraElem;
			break;
		case kso_schema::text_cell:
			*ppHandler = &m_cellElem;
			break;
		default:
			_kso_UnexpectedElement(uSubElementID);
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

class KTableElem : public 
	KFakeUnknown
	<
		KCollectionHandler
		<
			KRowElem,
			kso_schema::text_row,
			KTxtImpContext
		>
	>
{
};

// -------------------------------------------------------------------------
inline
KCellElem::~KCellElem()
{
	delete m_pTableElem;
}

inline
STDMETHODIMP_(VOID) KCellElem::Init(
	IN KTxtImpContext* pImpContext)
{
	m_pImpContext = pImpContext;
	m_ParaElem.Init(m_pImpContext);
	if (m_pTableElem)
		m_pTableElem->Init(m_pImpContext);
}

inline
STDMETHODIMP KCellElem::EnterSubElement(
	IN ELEMENTID uSubElementID, OUT IKElementHandler** ppHandler)
{
	switch (uSubElementID)
	{
	case kso::text_p:
		*ppHandler = &m_ParaElem;
		break;
	case kso_schema::text_table:
		if (m_pTableElem == NULL)
		{
			m_pTableElem = new KTableElem;
			m_pTableElem->Init(m_pImpContext);
		}
		*ppHandler = m_pTableElem;
		break;
	default:
		_kso_UnexpectedElement(uSubElementID);
		return IO_E_IGNORE;
		break;
	}
	return S_OK;
}

// -------------------------------------------------------------------------

#endif /* __TEXTTBL_H__ */

// $Log: texttbl.h,v $
// Revision 1.2  2005/06/02 08:51:49  wangdong
// �����µ��м���޸ı����롣
//
// Revision 1.1  2005/03/18 01:51:15  wangdong
// дtxt�ȶ���
//
