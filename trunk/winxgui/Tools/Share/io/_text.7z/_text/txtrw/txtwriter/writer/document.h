/* -------------------------------------------------------------------------
//	�ļ���		��	document.h
//	������		��	����
//	����ʱ��	��	2005-3-14 16:31:09
//	��������	��	
//	$Id: document.h,v 1.4 2005/07/13 07:21:24 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOCUMENT_H__
#define __DOCUMENT_H__

#ifndef __STL_VECTOR_H__
#include <stl/vector.h>
#endif

#ifndef __TEXTSTREAM_H__
#include "textstream.h"
#endif


// -------------------------------------------------------------------------
#define __TEXT_REGION_ON	__L("[")
#define __TEXT_REGION_OFF	__L("]")

typedef UINT HDOC;
#define NULL_HDOC 0


// -------------------------------------------------------------------------
class KTxtDocument
{
public:
	STDMETHODIMP OpenOnStream(
		IN IStream* pStream,
		IN UINT16 CodePage, 
		IN TxtNewLineType NewLine)
	{
		m_CodePage = CodePage;
		m_NewLine = NewLine;

		m_CurDocument = 0;
		m_fAccept = TRUE;

		ASSERT(
			m_vecDocument.empty()
			);
		m_vecDocument.push_back(new KTxtStream);
		m_vecDocument.front()->OpenOnStream(
			pStream, m_CodePage, TRUE, m_NewLine);

		return S_OK;
	}
	STDMETHODIMP OpenOnFile(
		IN LPCWSTR FileName,
		IN UINT16 CodePage, 
		IN TxtNewLineType NewLine)
	{
		ks_stdptr<IStream> stream;
		if (SUCCEEDED(
			CreateStreamOnFile(FileName, STGM_CREATE | STGM_WRITE, &stream)
			))
		{
			return OpenOnStream(stream, CodePage, NewLine);
		}
		return E_FAIL;
	}
	STDMETHODIMP Abort()
	{
		for (UINT i = 0; i < m_vecDocument.size(); ++i)
		{
			if (m_vecDocument.at(i))
				m_vecDocument.at(i)->Abort();
			delete m_vecDocument.at(i);
		}
		m_vecDocument.clear();
		return S_OK;
	}
	STDMETHODIMP Close(
		IN UINT CodePage = KFC_CP_UNKNOWN,
		IN TxtNewLineType NewLine = DefaultNewLineType)
	{
		for (UINT i = 0; i < m_vecDocument.size(); ++i)
		{
			if (m_vecDocument.at(i))
				m_vecDocument.at(i)->Close(TRUE, CodePage, NewLine);
			delete m_vecDocument.at(i);
		}
		m_vecDocument.clear();
		return S_OK;
	}

public:
	STDMETHODIMP AddContent(
		IN const WCHAR* cont, IN UINT cch)
	{
		if (m_fAccept)
			return m_vecDocument.at(m_CurDocument)->Write(cont, cch);
		return S_OK;
	}
	STDMETHODIMP AddContent(IN WCHAR ch)
	{
		if (m_fAccept)
			return m_vecDocument.at(m_CurDocument)->Write(ch);
		return S_OK;
	}
	STDMETHODIMP TabRight(IN UINT Count = 1)
	{
		if (m_fAccept)
		{
			for (UINT i = 0; i < Count; ++i)
				AddContent('\t');
			return S_OK;
		}
		return S_OK;
	}
	STDMETHODIMP EndParagraph()
	{
		if (m_fAccept)
			return m_vecDocument.at(m_CurDocument)->NewLine();
		return S_OK;
	}
	STDMETHODIMP UndoEndParagraph()
	{
		if (m_fAccept)
			return m_vecDocument.at(m_CurDocument)->DiscardNewLine();
		return S_OK;
	}

public:
	STDMETHODIMP_(VOID) Accept(
		IN BOOL fAccept = TRUE)
	{
		m_fAccept = fAccept;
	}

public:
	STDMETHODIMP_(HDOC) EnterDocument()
	{
		if (m_CurDocument != 0)
			return E_ACCESSDENIED;
		m_vecDocument.push_back(new KTxtStream);
		m_vecDocument.back()->OpenOnStream(
			NULL, 
			m_CodePage, FALSE,
			m_NewLine
			);
		m_CurDocument = m_vecDocument.size() - 1;
		return m_CurDocument;
	}
	STDMETHODIMP LeaveDocument()
	{
		if (m_CurDocument == 0)
			return E_ACCESSDENIED;
		m_CurDocument = 0;
		return S_OK;
	}

public:
	STDMETHODIMP_(VOID) BeginRegion()
	{
		if (m_fAccept)
		{
			AddContent(
				__TEXT_REGION_ON, 
				wcslen(__TEXT_REGION_ON)
				);
		}
	}
	STDMETHODIMP_(VOID) EndRegion()
	{
		if (m_fAccept)
		{
			GetDocument()->DiscardNewLine();
			AddContent(
				__TEXT_REGION_OFF, 
				wcslen(__TEXT_REGION_OFF)
				);
		}
	}
	STDMETHODIMP MergeDocument(
		IN HDOC hDoc)
	{
		if (m_fAccept)
		{
			if (
				hDoc >= m_vecDocument.size() ||
				hDoc == 0
				)
				return E_INVALIDARG;
			BeginRegion();
			HRESULT hr = m_vecDocument[
				hDoc]->CopyTo(*m_vecDocument.front());
			EndRegion();
			return hr;
		}
		return S_OK;
	}

public:
	STDMETHODIMP Snapshot(
		OUT IStream** ppstm,
		IN UINT CodePage = KFC_CP_UNKNOWN)
	{
		return m_vecDocument.front()->Snapshot(ppstm, CodePage);
	}

private:
	STDMETHODIMP_(KTxtStream*) GetDocument()
	{
		if (m_CurDocument >= m_vecDocument.size())
			return NULL;
		return m_vecDocument.at(m_CurDocument);
	}

public:
	KTxtDocument()
	{
	}
	~KTxtDocument()
	{
		Close(TRUE);
	}

private:
	std::vector<KTxtStream*> m_vecDocument;
	UINT m_CurDocument;

private:
	TxtNewLineType		m_NewLine;
	UINT16				m_CodePage;
	BOOL				m_fAccept;
};


// -------------------------------------------------------------------------
#ifndef __STL_HASH_MAP_H__
#include <stl/hash_map.h>
#endif

typedef __std::hash_map<UINT, UINT> CommentMap;
typedef CommentMap::const_iterator CommentMapIt;

class KTxtImpContext : public KTxtDocument
{
public:
	STDMETHODIMP_(CommentMap&) GetCommentMap()
	{
		return m_CommentMap;
	}
	STDMETHODIMP_(const CommentMap&) GetCommentMap() const
	{
		return m_CommentMap;
	}
	STDMETHODIMP_(CommentMap&) GetCommentScopeMap()
	{
		return m_CommentMapScope;
	}
	STDMETHODIMP_(const CommentMap&) GetCommentScopeMap() const
	{
		return m_CommentMapScope;
	}
	
public:
	STDMETHODIMP_(VOID) put_RevView(
		IN UINT revView)
	{
		m_revView = revView;
	}
	STDMETHODIMP_(UINT) get_RevView()
	{
		return m_revView;
	}

private:
	CommentMap m_CommentMap;
	CommentMap m_CommentMapScope;
	UINT m_revView;
};

// -------------------------------------------------------------------------

#endif /* __DOCUMENT_H__ */

// $Log: document.h,v $
// Revision 1.4  2005/07/13 07:21:24  wangdong
// no message
//
// Revision 1.3  2005/07/02 02:52:23  wangdong
// �޶���
//
// Revision 1.2  2005/03/18 01:51:20  wangdong
// дtxt�ȶ���
//
// Revision 1.1  2005/03/16 02:08:49  wangdong
// дtext�Ѿ���������������
//
