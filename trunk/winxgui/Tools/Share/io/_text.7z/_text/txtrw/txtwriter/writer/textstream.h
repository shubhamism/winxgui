/* -------------------------------------------------------------------------
//	�ļ���		��	textstream.h
//	������		��	����
//	����ʱ��	��	2005-3-14 16:32:40
//	��������	��	
//	$Id: textstream.h,v 1.2 2005/03/18 01:51:20 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXTSTREAM_H__
#define __TEXTSTREAM_H__

#ifndef __KFC_IO_ARCHIVE_H__
#include <kfc/io/archive.h>
#endif

#ifndef __KSO_IO_TEXTENCODING_H__
#include <kso/io/textencoding.h>
#endif


// -------------------------------------------------------------------------
template<class xchar_type>
class KTxtArchiveImpl : public KWriteArchiveBase
{
public:
	typedef KWriteArchiveBase _Base;
	typedef IStream* Handle;
	typedef KTxtArchiveImpl<xchar_type> _Myt;

public:
	KTxtArchiveImpl(
		Handle hFile = NULL,
		size_type nBufSize = default_buffer_size,
		char_type* lpBuf = NULL
		)
		: _Base(hFile, nBufSize, lpBuf)
	{
	}
	
public:
	HRESULT open(
		LPCWSTR szFile, 
		UINT nMode = STGM_CREATE | STGM_WRITE)
	{
		if (good())
			return E_ACCESSDENIED;
		return _handle.open(szFile, nMode);
	}
	HRESULT open(
		Handle hFile = NULL)
	{
		if (good())
			return E_ACCESSDENIED;

		if (
			hFile == NULL
			)
		{
			return XCreateStreamOnHGlobal(NULL, TRUE, &_handle);
		}
		else
		{
			attach(hFile);
			hFile->AddRef();
			return S_OK;
		}
	}
	size_type write(const xchar_type* lpBuf, unsigned int cch)
	{
		return put(
			(const char_type*)lpBuf, 
			sizeof(xchar_type) * cch
			);
	}
	size_type write(const xchar_type ch)
	{
		return write(
			(xchar_type*)&ch, 1
			);
	}

public:
	HRESULT CopyAllTo(_Myt& Ar)
	{
		if (bad() || Ar.bad())
			return E_ACCESSDENIED;

		HRESULT hr = E_ACCESSDENIED;
		flush();
		IStream* stream = static_cast<IStream*>(_handle);
		if (stream)
		{
			STATSTG stat;
			ZeroStruct(stat);
			hr = stream->Stat(&stat, STATFLAG_NONAME);
			KS_CHECK(hr);
			
			LARGE_INTEGER li;
			LISet32(li, 0);

			hr = stream->Seek(li, STREAM_SEEK_SET, NULL);
			KS_CHECK(hr);

			Ar.flush();
			hr =stream->CopyTo(Ar._handle, stat.cbSize, NULL, NULL);
			KS_CHECK(hr);

			li.QuadPart = stat.cbSize.QuadPart;
			hr = stream->Seek(li, STREAM_SEEK_SET, NULL);
			KS_CHECK(hr);
		}

	KS_EXIT:
		return hr;
	}
	HRESULT Snapshot(OUT IStream** ppstm)
	{
		if (ppstm == NULL)
			return E_INVALIDARG;
		if (bad())
			return E_ACCESSDENIED;

		HRESULT hr = E_ACCESSDENIED;
		flush();
		IStream* stream = static_cast<IStream*>(_handle);
		if (stream)
		{
			XCreateStreamOnHGlobal(NULL, TRUE, ppstm);

			STATSTG stat;
			ZeroStruct(stat);
			hr = stream->Stat(&stat, STATFLAG_NONAME);
			KS_CHECK(hr);
			
			LARGE_INTEGER li;
			LISet32(li, 0);

			hr = stream->Seek(li, STREAM_SEEK_SET, NULL);
			KS_CHECK(hr);

			hr =stream->CopyTo(*ppstm, stat.cbSize, NULL, NULL);
			KS_CHECK(hr);

			li.QuadPart = stat.cbSize.QuadPart;
			hr = stream->Seek(li, STREAM_SEEK_SET, NULL);
			KS_CHECK(hr);			
		}
	KS_EXIT:
		return S_OK;
	}
};

typedef KTxtArchiveImpl<WCHAR> KTxtArchive;

// -------------------------------------------------------------------------
#ifndef __TXTFMT_H__
#include <txtfmt/txtfmt.h>
#endif

class KTxtStream
{
public:
	//
	//	@@note:
	//	 �ڴ˴������ֱ��ָ�����з�ʽ��
	//	 ����Ҫ�ǳ���Ч�ʿ��ǡ�
	//
	STDMETHODIMP OpenOnStream(
		IN IStream* pStream = NULL,
		IN UINT16 CP = KFC_CP_UNKNOWN,
		IN BOOL WriteHeader = FALSE,
		IN TxtNewLineType NewLine = DefaultNewLineType
		)
	{
		ASSERT(
			m_ArTxt.bad()
			);
		if (
			m_ArTxt.good()
			)
			return E_ACCESSDENIED;
		m_ArTxt.open();

		m_Target = pStream;
		if (m_Target)
			m_Target->AddRef();

		m_NewLine = NewLine;
		m_CodePage = CP;
		m_WriteHeader = WriteHeader;

		return S_OK;
	}
	STDMETHODIMP OpenOnFile(
		IN LPCWSTR FileName,
		IN UINT16 CP = KFC_CP_UNKNOWN,
		IN BOOL WriteHeader = FALSE,
		IN TxtNewLineType NewLine = DefaultNewLineType
		)
	{
		ASSERT(
			m_ArTxt.bad()
			);
		if (
			m_ArTxt.good()
			)
			return E_ACCESSDENIED;
		m_ArTxt.open();

		m_NewLineCached = FALSE;
		
		HRESULT hr = _XCreateStreamOnFile(
			FileName, STGM_WRITE | STGM_CREATE, &m_Target);
		if (SUCCEEDED(hr))
		{
			m_NewLine = NewLine;
			m_CodePage = CP;
			m_WriteHeader = WriteHeader;
			return S_OK;
		}
		else
		{
			return hr;
		}
	}
	STDMETHODIMP Abort()
	{
		KS_RELEASE(m_Target);
		return Close();
	}
	STDMETHODIMP Close(
		IN BOOL TrimEndNewLine = FALSE,
		IN UINT CodePage = KFC_CP_UNKNOWN,
		IN TxtNewLineType NewLine = DefaultNewLineType
		)
	{
		if (m_ArTxt.bad())
			return S_OK;

		if (!TrimEndNewLine)
			FlushNewLine();

		ks_stdptr<IStream> stream;
		stream.attach(m_ArTxt.detach());
		m_ArTxt.close();

		HRESULT hr = S_OK;
		if (m_Target)
		{
			if (NewLine != m_NewLine)
				ReplaceNewLine(stream, m_NewLine, NewLine);

			if (CodePage != KFC_CP_UNKNOWN)
				hr = Encode(stream, m_Target, CodePage);
			else
				hr = Encode(stream, m_Target, m_CodePage);
			KS_CHECK(hr);
		}

	KS_EXIT:
		KS_RELEASE(m_Target);
		return hr;
	}

public:
	STDMETHODIMP Write(
		IN LPCWSTR cont,
		IN UINT cch)
	{
		FlushNewLine();

		LPCWSTR head = cont;
		LPCWSTR tail = cont;

		while (tail < cont + cch)
		{
			if (*tail == '\r')
			{
				if (tail > head)
					m_ArTxt.write(head, tail - head);
				ForceNewLine();
				if (tail+1 < cont + cch)
				{
					if (*(tail+1) == '\n')
						++tail;
				}
				head = ++tail;
				continue;
			}
			if (*tail == '\n')
			{
				if (tail > head)
					m_ArTxt.write(head, tail - head);
				ForceNewLine();
				if (tail+1 < cont + cch)
				{
					if (*(tail+1) == '\r')
						++tail;
				}
				head = ++tail;
				continue;
			}
			++tail;
		}
		if (tail > head)
			m_ArTxt.write(head, tail - head);
		return S_OK;
	}
	__forceinline
	STDMETHODIMP Write(
		IN WCHAR ch)
	{
		FlushNewLine();
		if (ch == '\r' || ch == '\n')
			return ForceNewLine();
		else
			return Write(&ch, 1);
	}
	__forceinline
	STDMETHODIMP NewLine()
	{
		FlushNewLine();
		m_NewLineCached = TRUE;
		return S_OK;
	}
	STDMETHODIMP DiscardNewLine()
	{
		m_NewLineCached = FALSE;
		return S_OK;
	}
private:
	__forceinline
	STDMETHODIMP FlushNewLine()
	{
		if (m_NewLineCached)
		{
			m_NewLineCached = FALSE;
			return ForceNewLine();
		}
		return S_OK;
	}
	__forceinline
	STDMETHODIMP ForceNewLine()
	{
		return m_ArTxt.write(
			TxtNL::content(m_NewLine),
			TxtNL::length (m_NewLine)
			);
	}
	STDMETHODIMP Encode(
		IN IStream* streamIn, 
		IN IStream* streamOut,
		IN UINT CP)
	{
		if (
			streamIn == NULL ||
			streamOut == NULL
			)
			return E_INVALIDARG;

		HRESULT hr = S_OK;

		ks_stdptr<IStream> streamNew;
		hr = _kso_ConvertStreamWideCharToMultiByte(
			&streamNew,
			streamIn,
			CP);
		KS_CHECK(hr);
		
		LARGE_INTEGER li;
		LISet32(li, 0);
		streamNew->Seek(li, STREAM_SEEK_SET, NULL);
		
		STATSTG stat;
		ZeroStruct(stat);
		streamNew->Stat(&stat, STATFLAG_NONAME);
		
		streamNew->CopyTo(streamOut, stat.cbSize, NULL, NULL);

	KS_EXIT:
		return hr;
	}
	STDMETHODIMP ReplaceNewLine(
		IN IStream* stream, 
		IN TxtNewLineType NewLine2Find,
		IN TxtNewLineType NewLine4Replace)
	{
		if (
			stream == NULL
			)
			return E_INVALIDARG;

		HRESULT hr = S_OK;

		KReadArchive ArIn(stream);
		ArIn.seek(0);

		ks_stdptr<IStream> streamOut;
		XCreateStreamOnHGlobal(NULL, TRUE, &streamOut);
		KWriteArchive ArOut(streamOut);

		const UINT lenNewLine = TxtNL::length(NewLine2Find);
		const UINT cbNewLine = sizeof(WCHAR) * lenNewLine;
		LPCWSTR charNewLine = TxtNL::content(NewLine2Find);

		LPWSTR tmpbuf = (LPWSTR)alloca(cbNewLine);
		while (true)
		{
			WCHAR ch = 0;
			if (ArIn.read(&ch, sizeof(WCHAR)) == 0)
				break;

			if (ch == charNewLine[0])
			{
				tmpbuf[0] = ch;
				ArIn.read(tmpbuf + 1, (lenNewLine - 1) * sizeof(WCHAR));
				if (memcmp(tmpbuf, charNewLine, cbNewLine) == 0)
				{
					ArOut.write(
						TxtNL::content(NewLine4Replace),
						TxtNL::length(NewLine4Replace) * sizeof(WCHAR)
						);
					continue;
				}
				else
					ArIn.unget();
			}
			ArOut.write(&ch, sizeof(WCHAR));
		}

		ULARGE_INTEGER uli;
		ULISet32(uli, 0);
		stream->SetSize(uli);

		LARGE_INTEGER li;
		LISet32(li, 0);
		stream->Seek(li, STREAM_SEEK_SET, NULL);

		ks_stdptr<IStream> streamOut2;
		streamOut2.attach(ArOut.detach());
		
		streamOut2->Seek(li, STREAM_SEEK_SET, NULL);
		
		STATSTG stat;
		ZeroStruct(stat);
		streamOut2->Stat(&stat, STATFLAG_NONAME);
		
		streamOut2->CopyTo(stream, stat.cbSize, NULL, NULL);

//	KS_EXIT:
		return hr;
	}

public:
	STDMETHODIMP CopyTo(
		IN KTxtStream& stream, 
		IN BOOL fFlushNewLine = FALSE)
	{
		if (
			m_NewLine != stream.m_NewLine ||
			m_CodePage != stream.m_CodePage
			)
		{
			return E_ACCESSDENIED;
		}
		if (fFlushNewLine)
			FlushNewLine();
		stream.FlushNewLine();
		
		return m_ArTxt.CopyAllTo(
			stream.m_ArTxt
			);
	}
	STDMETHODIMP Snapshot(
		OUT IStream** ppstm,
		IN UINT CodePage = KFC_CP_UNKNOWN)
	{
		ks_stdptr<IStream> streamIn;
		HRESULT hr = m_ArTxt.Snapshot(&streamIn);
		KS_CHECK(hr);

		if (CodePage != KFC_CP_UNKNOWN)
		{
			ks_stdptr<IStream> streamOut;
			XCreateStreamOnHGlobal(NULL, TRUE, &streamOut);
			hr = Encode(streamIn, streamOut, CodePage);
			KS_CHECK(hr);
			*ppstm = streamOut.detach();
		}
		else
		{
			*ppstm = streamIn.detach();
		}

	KS_EXIT:
		return hr;
	}

public:
	KTxtStream()
	{
		m_NewLineCached = FALSE;
	}
	~KTxtStream()
	{
		Abort();
	}

private:
	KTxtArchive			m_ArTxt;
	IStream*			m_Target;
	TxtNewLineType		m_NewLine;
	UINT16				m_CodePage;
	BOOL				m_WriteHeader;
	BOOL				m_NewLineCached;
};

// -------------------------------------------------------------------------

#endif /* __TEXTSTREAM_H__ */

// $Log: textstream.h,v $
// Revision 1.2  2005/03/18 01:51:20  wangdong
// дtxt�ȶ���
//
// Revision 1.1  2005/03/16 02:08:49  wangdong
// дtext�Ѿ���������������
//
