/* -------------------------------------------------------------------------
//	�ļ���		��	read.cpp
//	������		��	����
//	����ʱ��	��	2005-3-14 17:54:10
//	��������	��	
//	$Id: read.cpp,v 1.6 2005/04/25 01:56:04 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "common.h"

#include <kfc/encoding/encoding.h>
#include <txtreader/reader/handler.h>
#include <txtreader/reader/parser.h>
#include <txtreader/handler/document.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
WCHAR sTestString[] = L"ABC\nDEF\tAB\r\n";
WCHAR sTextString[] = L"DEFAB";
WCHAR sTokenString[] = L"ABC\n\t\r\n";

// -------------------------------------------------------------------------
class KTestHandler : public KTxtHandler
{
public:
	STDMETHODIMP AddContent(
		IN const WCHAR* cont,
		IN UINT cch)
	{
		TRACEW(L"%s\n", cont);
		m_cont.resize(m_cont.size() + cch);
		std::copy(
			cont, cont + cch, 
			m_cont.end() - cch
			);

		return S_OK;
	}

public:
	KTestHandler(const ks_wstring& StdString)
		: m_std(StdString) 
	{
	}
	~KTestHandler()
	{
		ASSERT(
			Check()
			);
	}

public:
	STDMETHODIMP_(BOOL) Check()
	{
		return m_cont == m_std;
	}
	
private:
	ks_wstring m_cont;
	const ks_wstring m_std;
};

// -------------------------------------------------------------------------
class KTestContentHandler : public KFakeUnknown<IKContentHandler>
{
public:
    STDMETHODIMP StartElement(
		IN ELEMENTID uElementID)
	{
		return S_OK;
	}
	STDMETHODIMP AddAttributes(
		IN IKAttributes* pAttributes)
	{
		return S_OK;
	}
    STDMETHODIMP AddContent(
		IN CONTENTVALUE_PTR pContent)
	{
		return S_OK;
	}
	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID)
	{
		return S_OK;
	}
	STDMETHODIMP StartDocument(
		IN UINT nReservedParam)
	{
		return S_OK;
	}
    STDMETHODIMP EndDocument(
		IN BOOL fAbort)
	{
		return S_OK;
	}
};

// -------------------------------------------------------------------------
class TestReader : public TestFixture
{
	CPPUNIT_TEST_SUITE(TestReader);
		CPPUNIT_TEST(CaseBasic);
		CPPUNIT_TEST(CaseNormal);
		CPPUNIT_TEST(CaseTbl);
	CPPUNIT_TEST_SUITE_END();
	
public:
	void setUp()
	{
	}
  	void tearDown()
	{
	}

public:
	void CaseBasic()
	{
		UINT cbString = wcslen(sTestString) * sizeof(WCHAR);
		HGBL hGbl = XGlobalAlloc(GPTR, cbString);
		void* buf = XGlobalLock(hGbl);
		CopyMemory(buf, (void*)sTestString, cbString);
		XGlobalUnlock(hGbl);

		ks_stdptr<IStream> spStream;
		XCreateStreamOnHGlobal(hGbl, TRUE, &spStream);
		ASSERT(spStream);

		LPCWSTR tokens[] = {
			L"\r\n",
			L"\n",
			L"\r",
			L"\t",
			L"ABC",
		};
		
		KTestHandler textHan(sTextString);
		KTestHandler tokenHan(sTokenString);
		{
			KTxtParser parser;
			parser.Open(&textHan, &tokenHan, tokens, countof(tokens));
			parser.Parse(spStream);
			parser.Close();
		}
	}

	void CaseNormal()
	{
		UINT cbString = wcslen(sTestString) * sizeof(WCHAR);
		HGBL hGbl = XGlobalAlloc(GPTR, cbString);
		void* buf = XGlobalLock(hGbl);
		CopyMemory(buf, (void*)sTestString, cbString);
		XGlobalUnlock(hGbl);

		ks_stdptr<IStream> spStream;
		XCreateStreamOnHGlobal(hGbl, TRUE, &spStream);
		ASSERT(spStream);
		
		KTestContentHandler cont;

		ks_stdptr<IKFilterMediaInit> spInit;
		testCreateTestHandler(&spInit);

		FILTERMEDIUM Medium;
		Medium.tymed = FILTER_TYMED_FILE;
		Medium.lpszFileName = L"C:/testTxtR1.doc";
		Medium.grfModeForFileName = STGM_G_CREATE;
		spInit->Init(&Medium);

		ks_stdptr<IKContentHandler> spHandl(spInit);

		KTxtRDocument docu;
		docu.Open();
		docu.Transfer(spStream, spHandl, TxtModelNormal);
		docu.Close();
	}

	void CaseTbl()
	{
		UINT cbString = wcslen(sTestString) * sizeof(WCHAR);
		HGBL hGbl = XGlobalAlloc(GPTR, cbString);
		void* buf = XGlobalLock(hGbl);
		CopyMemory(buf, (void*)sTestString, cbString);
		XGlobalUnlock(hGbl);

		ks_stdptr<IStream> spStream;
		XCreateStreamOnHGlobal(hGbl, TRUE, &spStream);
		ASSERT(spStream);
		
		KTestContentHandler cont;

		ks_stdptr<IKFilterMediaInit> spInit;
		testCreateTestHandler(&spInit);

		FILTERMEDIUM Medium;
		Medium.tymed = FILTER_TYMED_FILE;
		Medium.lpszFileName = L"C:/testTxtR2.doc";
		Medium.grfModeForFileName = STGM_G_CREATE;
		spInit->Init(&Medium);

		ks_stdptr<IKContentHandler> spHandl(spInit);

		KTxtRDocument docu;
		docu.Open();
		docu.Transfer(spStream, spHandl, TxtModelTbl);
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestReader);


// -------------------------------------------------------------------------
// $Log: read.cpp,v $
// Revision 1.6  2005/04/25 01:56:04  wangdong
// ������txt��
//
// Revision 1.3  2005/04/19 09:48:35  wangdong
// ��et����
//
// Revision 1.2  2005/03/18 01:51:28  wangdong
// дtxt�ȶ���
//
