/* -------------------------------------------------------------------------
//	�ļ���		��	field.h
//	������		��	����
//	����ʱ��	��	2005-7-13 11:36:45
//	��������	��	
//	$Id: field.h,v 1.1 2005/07/13 07:21:24 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __FIELD_H__
#define __FIELD_H__

#ifndef __DOCUMENT_H__
#include <txtwriter/writer/document.h>
#endif

// -------------------------------------------------------------------------
class KTxtImpContext;

// -------------------------------------------------------------------------
class KFieldBeginHandler : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
	}
	STDMETHODIMP StartElement(
		IN ELEMENTID uElementID, IN KROAttributes* pAttrs)	
	{ 
		m_pImpContext->Accept(FALSE);
		return S_OK;
	}
};


// -------------------------------------------------------------------------
class KFieldSepHandler : public KFakeUnknown<KElementHandler>
{
	KTxtImpContext* m_pImpContext;
public:
	STDMETHODIMP_(VOID) Init(
		IN KTxtImpContext* pImpContext)
	{
		m_pImpContext = pImpContext;
	}
	STDMETHODIMP EndElement(
		IN ELEMENTID uElementID)	
	{ 
		m_pImpContext->Accept(TRUE);
		return S_OK;
	}
};


// -------------------------------------------------------------------------

#endif /* __FIELD_H__ */

// $Log: field.h,v $
// Revision 1.1  2005/07/13 07:21:24  wangdong
// no message
//
