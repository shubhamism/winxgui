/* -------------------------------------------------------------------------
//	�ļ���		��	txtfmt.h
//	������		��	����
//	����ʱ��	��	2005-3-14 16:40:19
//	��������	��	
//	$Id: txtfmt.h,v 1.1 2005/03/18 01:51:49 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TXTFMT_H__
#define __TXTFMT_H__

#ifndef __KSO_IO_TEXTENCODING_H__
#include <kso/io/textencoding.h>
#endif

// -------------------------------------------------------------------------
// TXT_CRLF:
//	CR/LF��ʽ�Ļ��С�
//
#define TXT_CRLF			__X("\r\n")
#define TXT_CRLF_LENGTH		(countof(TXT_CRLF) - 1)

// -------------------------------------------------------------------------
// TXT_CR:
//		CR��ʽ�Ļ��С�
//
#define TXT_CR				__X("\r")
#define TXT_CR_LENGTH		(countof(TXT_CR) - 1)

// -------------------------------------------------------------------------
// TXT_LF:
//		LF��ʽ�Ļ��С�
//
#define TXT_LF				__X("\n")
#define TXT_LF_LENGTH		(countof(TXT_LF) - 1)

// -------------------------------------------------------------------------
// TXT_LFCR:
//		LF/CR��ʽ�Ļ��С�
//
#define TXT_LFCR			__X("\n\r")
#define TXT_LFCR_LENGTH		(countof(TXT_LFCR) - 1)


// -------------------------------------------------------------------------
//
// DefaultNewLineType NewLine_CRLF
//	���ı��ı�׼�Ļ��з�ʽ��
//
#define DefaultNewLineType NewLine_CRLF

// -------------------------------------------------------------------------
struct TxtNL
{
	static STDMETHODIMP_(LPCWSTR) content(
		IN TxtNewLineType type)
	{
		static LPCWSTR s_data[] =
		{
			TXT_CRLF,
			TXT_CR,
			TXT_LF,
			TXT_LFCR,
		};
		ASSERT(
			(UINT)type < countof(s_data)
			);
		return s_data[type];
	}
	static STDMETHODIMP_(UINT) length(
		IN TxtNewLineType type)
	{
		static UINT s_data[] =
		{
			TXT_CRLF_LENGTH,
			TXT_CR_LENGTH,
			TXT_LF_LENGTH,
			TXT_LFCR_LENGTH,
		};
		ASSERT(
			(UINT)type < countof(s_data)
			);
		return s_data[type];
	}
};

// -------------------------------------------------------------------------

#endif /* __TXTFMT_H__ */

// $Log: txtfmt.h,v $
// Revision 1.1  2005/03/18 01:51:49  wangdong
// дtxt�ȶ���
//
