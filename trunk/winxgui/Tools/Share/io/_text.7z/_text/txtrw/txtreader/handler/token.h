/* -------------------------------------------------------------------------
//	�ļ���		��	token.h
//	������		��	����
//	����ʱ��	��	2005-4-20 14:13:42
//	��������	��	
//	$Id: token.h,v 1.1 2005/04/25 01:57:14 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __HANDLER_TOKEN_H__
#define __HANDLER_TOKEN_H__


// -------------------------------------------------------------------------
class KTxtTokenHandler : public KTxtHandler
{
public:
	STDMETHODIMP_(VOID) Open(
		IN KTxtModel* pModel)
	{
		m_pModel = pModel;
	}
	STDMETHODIMP_(VOID) Close()
	{
		m_pModel = NULL;
	}

public:
	STDMETHODIMP AddContent(
		IN const WCHAR* cont,
		IN UINT cch)
	{
		if (cch == 0)
		{
			return E_INVALIDARG;
		}
		switch (cont[0])
		{
		case '\r':
		case '\n':
			m_pModel->NewParagraph();
			break;
		default:
			ASSERT_ONCE(0);
			m_pModel->AddContent(cont, cch);
			break;
		}
		return S_OK;
	}

private:
	KTxtModel* m_pModel;
};


// -------------------------------------------------------------------------
class KTxtTableTokenHandler : public KTxtHandler
{
public:
	STDMETHODIMP_(VOID) Open(
		IN KTxtModel* pModel)
	{
		m_pModel = pModel;
		m_InCell = FALSE;
	}
	STDMETHODIMP_(VOID) Close()
	{
		m_pModel = NULL;
	}

public:
	STDMETHODIMP AddContent(
		IN const WCHAR* cont,
		IN UINT cch)
	{
		switch (cont[0])
		{
		case '\r':
		case '\n':
			if (!m_InCell)
				m_pModel->NewRow();
			else
				m_pModel->NewParagraph();
			break;
		case '\t':
			if (!m_InCell)
				m_pModel->NewCell();
			else
				m_pModel->AddContent(cont, cch);
			break;
		case '"':
			m_InCell = !m_InCell;
			break;
		default:
			ASSERT_ONCE(0);
			m_pModel->AddContent(cont, cch);
			break;
		}
		return S_OK;
	}

	
private:
	KTxtModel* m_pModel;
	BOOL m_InCell;
};

// -------------------------------------------------------------------------

#endif /* __HANDLER_TOKEN_H__ */

// $Log: token.h,v $
// Revision 1.1  2005/04/25 01:57:14  wangdong
// ������txt��
//
