/* -------------------------------------------------------------------------
//	�ļ���		��	group_shppict.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-10 16:38:00
//	��������	��	
//
//	$Id: group_shppict.h,v 1.17 2006/08/03 02:08:32 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_SHPPICT_H__
#define __GROUP_SHPPICT_H__

#ifndef __GROUP_PICT_H__
#include "group_pict.h"
#endif

#ifndef __GROUP_SP_H__
#include "group_sp.h"
#endif

// -------------------------------------------------------------------------
// class Group_picprop

class Group_picprop : public Group_Base
{
public:
	RtfGrpObject<Group_sp> m_sp;
	RtfDocument* m_doc;
	BOOL m_fDefShape;

	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
};

// -------------------------------------------------------------------------
// class Group_pict

struct RtfIncludePicture //@@feature: includepicture
{
	STDPROC IncludePicture(
		IN OUT RtfShapeOPT& opt) PURE;
};

class Group_pict : public Group_pict_Base
{
private:
	KDWBlip m_blip;
public:
	RtfShapeOPT m_opt;
	RtfShapeInfo m_info;
	RtfDocument* m_doc;	
	RtfGrpObject<Group_picprop> m_picprop;
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{		
		Group_pict_Base::StartGroup(grName, grValue, fDest);
		m_picprop.m_fDefShape = FALSE;
		return S_OK;
	}
	
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue)
	{
		switch (attrName)
		{
		case rtf_wbmbitspixel:			
			break;
		case rtf_wbmplanes:
			break;
		case rtf_wbmwidthbytes:
			break;
		case rtf_picw:			
			m_info.m_cxaShape = attrValue;
			break;
		case rtf_pich:
			m_info.m_cyaShape = attrValue;
			break;
		case rtf_picwgoal:
			m_info.m_cxaShape = attrValue;
			break;
		case rtf_pichgoal:
			m_info.m_cyaShape = attrValue;
			break;
		case rtf_picscalex:
			m_info.m_picscalex = attrValue;
			break;
		case rtf_picscaley:
			m_info.m_picscaley = attrValue;
			break;
		default:
			return Group_pict_Base::AddAttribute(attrName, attrValue);
		}
		return S_OK;
	}
	
	STDMETHODIMP AddBinary(
		LPCVOID pData,
		int cbData);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
	
	STDMETHODIMP EndGroup();	
private:
	STDMETHODIMP_(void) _AddPict();
};

// -------------------------------------------------------------------------
// class Group_shppict

class Group_shppict : public Group_Base
{
public:
	RtfGrpObject<Group_pict> m_pict;
	
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
};

// -------------------------------------------------------------------------
// class Group_nonshppict

typedef Group_Skipped Group_nonshppict;
#endif /* __GROUP_SHPPICT_H__ */
