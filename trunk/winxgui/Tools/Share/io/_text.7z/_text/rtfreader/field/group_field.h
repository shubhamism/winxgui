/* -------------------------------------------------------------------------
//	�ļ���		��	group_field.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 14:44:27
//	��������	��	
//
//	$Id: group_field.h,v 1.22 2006/09/11 08:00:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FIELD_H__
#define __GROUP_FIELD_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include <core/group_textstream.h>
#endif

#include "group_field.h"

// -------------------------------------------------------------------------
// class Group_fldinst

class Group_fldinst : public Group_TextStream
{
public:
	UINT m_cpFldinst;
	UINT m_cpFldinstStart;
	
public:
	STDMETHODIMP IncludePicture(IN OUT RtfShapeOPT& opt);

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{
		m_cpFldinst = m_cpFldinstStart = m_doc->GetFcMax();
		return Group_TextStream::StartGroup(grName, grValue, fDest);
	}
	
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// class Group_fldrslt

class Group_fldrslt : public Group_TextStream
{
public:
	UINT16 m_ifont;
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);	
};

// -------------------------------------------------------------------------
// class Group_field

class Group_field : public Group_TextStream, public RtfIncludePicture
{
private:
	RtfGrpObject<Group_fldinst> m_fldinst;
	RtfGrpObject<Group_fldrslt> m_fldrslt;
	
	friend class Group_fldrslt;

public:
	//RtfDocument* m_doc;

	STDMETHODIMP_(RtfIncludePicture*) GetIncludePicture();

	STDMETHODIMP IncludePicture(
		IN OUT RtfShapeOPT& opt)
	{
		return m_fldinst.IncludePicture(opt);
	}
	
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{
		TRACEA("<< start ----------------------------\n");
		Group_TextStream::StartGroup(grName, grValue, fDest);
		return m_doc->MarkFieldBegin();
	}
	
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);

	STDMETHODIMP EndGroup();
};

class Group_tc : public Group_TextStream
{
public:
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue, 
		int& fDest)
	{
		Group_TextStream::StartGroup(grName, grValue, fDest);
		m_doc->MarkFieldBegin();
		m_doc->SetCurrentFieldType(mso_fltTC);		
		m_doc->AddContent(__X("tc "), 3);
		return S_OK;
	}
	STDMETHODIMP EndGroup()
	{
		m_doc->MarkFieldSeparator();		
		m_doc->MarkFieldEnd();
		return Group_TextStream::EndGroup();
	}
};
// -------------------------------------------------------------------------
//	$Log: group_field.h,v $
//	Revision 1.22  2006/09/11 08:00:24  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.21  2006/07/31 06:29:16  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.20  2006/06/14 03:32:58  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.19  2006/02/27 08:19:54  xulingjiao
//	rtfreader����mask
//	
#endif /* __GROUP_FIELD_H__ */
