/* -------------------------------------------------------------------------
//	�ļ���		��	rtfdocument.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 16:18:00
//	��������	��	
//
//	$Id: rtfdocument.h,v 1.107 2006/09/21 10:42:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFDOCUMENT_H__
#define __RTFDOCUMENT_H__

#ifndef __MSO_IO_WORD_RTFTABLE_RTFTABLE_H__
#include <mso/io/word/rtftable/rtftable.h>
#endif

#ifndef __RTFPROP_H__
#include "rtfprop.h"
#endif

#ifndef __RTFSTYLE_H__
#include "rtfstyle.h"
#endif

#ifndef __RTFRCOLORTBL_H__
#include "colortbl.h"
#endif

#ifndef __RTFRBACKUP_H__
#include "rtfrbackup.h"
#endif

#ifndef __RTFRLINKTEXTBOX_H__
#include "rtfrlinktextbox.h"
#endif

#ifndef __RTFTOKEN_H__
#include "rtftoken.h"
#endif

#include "../drawing/shapeopt.h"

// -------------------------------------------------------------------------
// RtfBlipType
__USING_MSO_ESCHER;

typedef MSOBLIPTYPE RtfBlipType;
typedef INT32 RtfCellPos;
typedef KDWListLevel RtfListLevel;
typedef KDWList RtfList;
typedef KDWListFormatOverride RtfListOverride;
typedef KDWTablePos RtfTablePos;

typedef RtfBackup<RtfParaPr> RtfBackup_RtfParaPr;
typedef RtfBackup<RtfSpanPr> RtfBackup_RtfSpanPr;
typedef RtfBackup<RtfDop> RtfBackup_RtfDop;
typedef RtfBackup<RtfSectionPr> RtfBackup_RtfSectionPr;
typedef RtfBackup<RtfTableRowPr> RtfBackup_RtfTableRowPr;
typedef RtfBackup<RtfTablePos> RtfBackup_RtfTablePos;

class Group_rtf;

class RtfDocument : public KDWDocument
{
public:
	RtfLinkTextboxes m_textboxes;
	RtfColorTable m_colortbl;	
	RtfStyleSheet m_stylesheet;
	RtfSpanPr m_spanPrParaStyle;	
	RtfDop m_dop;	
	RtfSpanPr m_spanPr;	
	RtfParaPr m_paraPr;
	RtfBackup_RtfParaPr m_backupParaPr;
	RtfSectionPr m_sectPr;	
	RtfTableRowPr m_trow;	
	RtfTablePos m_tblPos;	
	RtfShapeInfo m_includePictureOpt;
	mutable KDWBrc* m_brc;
	Group_rtf* m_rtf;	
	BOOL m_fHaveAf;
	//footnote & endnote
	RtfSpanPr m_noteref_spanPr;
	BOOL m_fHaveEnter;
	BOOL m_fNoFndEndRef;
	SUBDOC_TYPE m_rtf_subdoc;
private:
	typedef std::basic_string<WCHAR> BookmarkKeyType;
	KDWBookmarksExImpl<BookmarkKeyType> m_bkmks;
	
private:
	typedef KDWDocument Base;
	STDMETHODIMP NewParagraph(IN const KDWPropBuffer* papx);
	STDMETHODIMP NewNullPapxParagraph();
	STDMETHODIMP NewSpan(IN const KDWPropBuffer* chpx);
	STDMETHODIMP NewNullChpxSpan();
	STDMETHODIMP_(void) NewSpan(RtfSpanPr& spanpr)
	{
#if defined(_DEBUG_DIRTY)
		if (m_spanPr.fIsDirty)
		{
			putchar('\n');
			putchar('C');
		}
		else
		{
			putchar('#');
		}
#endif
		KDWPropBuffer chpx;
		ConvertChpx(chpx, &spanpr, this);
		Base::NewSpan(&chpx);		
	}
	STDMETHODIMP_(void) NewSpan()
	{
		NewSpan(m_spanPr);
/*
#if defined(_DEBUG_DIRTY)
		if (m_spanPr.fIsDirty)
		{
			putchar('\n');
			putchar('C');
		}
		else
		{
			putchar('#');
		}
#endif
		//if (m_spanPr.fIsDirty)
		//{
			KDWPropBuffer chpx;
			ConvertChpx(chpx, &m_spanPr, this);
			Base::NewSpan(&chpx);
			m_spanPr.fIsDirty = FALSE;
		//}
*/
	}	
	__forceinline
	STDMETHODIMP_(void) NewParagraph(WCHAR wch, BOOL fNestCell = FALSE)
	{
		AddContent(wch);
		
		KDWPropBuffer papx;
		ConvertPapx(papx, &m_paraPr, this);
		if (fNestCell)
			papx.AddPropFix(sprmPFTc, 1);
		Base::SetCurrentPapx(&papx);
		
		Base::NewNullPapxParagraph();
	}
	// annotation
private:
	typedef struct tagItemInfo
	{
		CP start;
		CP end;		
	}ItemInfo;
	typedef std::map<ks_wstring, ItemInfo> ItemInfoType;
	typedef ItemInfoType::value_type ItemType;	
	ItemInfoType m_atnInfo;
	_DW_UserNameInfo m_user;	
private:
	UINT GetUserId()
	{		
		KDWUsers& users = GetAnnotationUsers();
		UINT id, i;		
		for(i=0; i<users.GetCount(); ++i)
		{
			_DW_UserNameInfo info = *users.GetUserNameInfo(i);
			if(info == m_user)
				return i;
		}
		if(m_user.userName == NULL)
		{
			m_user.userName = AllocString(__X(""), 1);
		}
		if(m_user.userNameAbbr == NULL)
		{
			m_user.userName = AllocString(__X(""), 1);
		}
		users.Add(m_user.userName, m_user.userNameAbbr, &id);
		return id;
	}
	DTTM GetDttm(ks_wstring atndate)
	{
		INT32 dt = _wtoi(atndate.c_str());
		DTTM dttm;
		dttm.mint = dt & 0x3F;
		dt >>= 6;
		dttm.hr = dt & 0x1F;
		dt >>= 5;
		dttm.dom = dt & 0x1F;
		dt >>= 5;
		dttm.mon = dt & 0xF;
		dt >>= 4;
		dttm.yr = dt & 0x1FF;
		dt >>= 9;
		dttm.wdy = dt & 0x7;
		dt >>= 3;
		return dttm;
	}
public:		
	STDMETHODIMP_(void) MarkAtnRefBegin(ks_wstring atnRefId, CP atnCp)
	{	
		ASSERT_ONCE(!m_atnInfo.count(atnRefId));
		ItemInfo info;
		info.start = atnCp;
		m_atnInfo.insert(ItemType(atnRefId, info));
	}
	STDMETHODIMP_(void) MarkAtnRefEnd(ks_wstring atnRefId, CP atnCp)
	{
		ASSERT_ONCE(m_atnInfo.count(atnRefId));
		ItemInfo& info = m_atnInfo[atnRefId];
		info.end = atnCp;
	}
	STDMETHODIMP_(void) SetAnnotationUser(LPCWSTR pContent, int cch, BOOL fAbbr)
	{
		if(fAbbr)		
			m_user.userNameAbbr = AllocString(pContent, cch);				
		else
			m_user.userName = AllocString(pContent, cch);
	}
	STDMETHODIMP EnterAnnotation(ks_wstring atnref, ks_wstring atndate)
	{	
		ItemInfo info;
		if(atnref.empty())
			info.start = info.end = GetMainSubdoc()->TextPool().size();
		else
			info = m_atnInfo[atnref];
		UINT userId = GetUserId(), cch = info.end - info.start;
		DTTM dttm = GetDttm(atndate);
		HRESULT hr = Base::EnterAnnotation(userId, dttm, cch);
		if (SUCCEEDED(hr))
			return Base::NewNullPapxParagraph();
		return hr;
	}
	STDMETHODIMP LeaveAnnotation()
	{
		m_user.userName = m_user.userNameAbbr = NULL;
		EndParagraph();
		return Base::LeaveAnnotation();
	}
public:	
	STDMETHODIMP_(UINT) GetCodePage()
	{	
		CHARSETINFO chsInfo;
		UINT fId;
		if(m_spanPr.mask.iftc)
			fId = m_spanPr.rgftc[m_spanPr.iftc];
		else
			fId = GetFontId(0);
		BOOL fSuccess = GetFontTable().GetCharsetInfo(chsInfo, fId);
		UINT ciACP = m_dop.DefCodePage;
		if(fSuccess)
			ciACP = chsInfo.ciACP;
		return ciACP;
	}
	STDMETHODIMP AddContent(LPCSTR pContent, INT cch, INT codepage)
	{
		UINT szWchBuf = cch*2 + 10;
		std::vector<WCHAR> wchBuf(szWchBuf);
		INT szRet = MultiByteToWideChar(codepage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
		AddContent(wchBuf.begin(), szRet);
		return S_OK;
	}
	STDMETHODIMP AddContent(LPCSTR pContent, INT cch)
	{
		AddContent(pContent, cch, GetCodePage());
		return S_OK;
	}
	STDMETHODIMP_(void) AddPlaceHolder(IN const WCHAR wch)
	{
		NewSpan();
		Base::AddPlaceHolder(wch);
	}
	STDMETHODIMP_(void) AddSpecChar(UINT16 wch)
	{	
		//��Ϊ��\emdash�ȿ�����Ӧ����\dbch\f�󣬻���ʹ���������塣@tocheck
		UINT8 idctHint = m_spanPr.idctHint;
		m_spanPr.idctHint = 0;
		m_spanPr.fIsDirty = 1;
		AddContent(wch);
		m_spanPr.idctHint = idctHint;
		m_spanPr.fIsDirty = 1;
	}
	STDMETHODIMP_(void) AddField(FLT flt, LPCWSTR szMsg)
	{
		MarkFieldBegin();
		SetCurrentFieldType(flt);
		AddContent(szMsg, wcslen(szMsg));
		MarkFieldSeparator();
		MarkFieldEnd();
	}
public:
	STDMETHODIMP_(KDWOleShape) AddOleEmbed(
										   IN UINT cxaShape,
										   IN UINT cyaShape,
										   IN LPCWSTR szProgID = NULL,
										   IN BOOL fMergeFormat = TRUE)
	{
		NewSpan();
		return Base::AddOleEmbed(cxaShape, cyaShape, szProgID, fMergeFormat);
	}
	
	STDMETHODIMP_(KDWOleShape) AddOleLink(
										  IN UINT cxaShape,
										  IN UINT cyaShape,
										  IN LPCWSTR szProgID,
										  IN LPCWSTR szMonkier,
										  IN LPCWSTR szPlaceReference = NULL,
										  IN BOOL fAutoUpdateLink = TRUE,
										  IN DWOleLinkAs linkAs = mso_oleLinkAsPicture,
										  IN DWOleLinkFormat linkFormat = mso_oleKeepSource)//@add
	{
		NewSpan();
		return  Base::AddOleLink(
				cxaShape, cyaShape, szProgID,
				szMonkier, szPlaceReference, fAutoUpdateLink, linkAs, linkFormat);					
	}

	RtfDocument() : m_stylesheet(GetAllocater())
	{
		m_brc = &m_spanPr.brc;
		m_fHaveAf = FALSE;
		m_fNoFndEndRef = TRUE;
		m_fHaveEnter = FALSE;
		m_rtf_subdoc = DW_SUBDOC_MAIN;		
	}

	STDMETHODIMP NewDocument(
		IN IStorage* pStorage)
	{			
		Base::NewDocument(pStorage);
		Base::NewNullSepxSection();
		Base::NewNullPapxParagraph();
		//Base::NewNullChpxSpan();
		*static_cast<DOP*>(&m_dop) = Base::GetDop().dop;
		m_dop.Reset();
		return S_OK;
	}

protected:
	STDMETHODIMP_(void) __RtfFinalize()
	{
		KDWPropBuffer sepx;
		ConvertSepx(sepx, &m_sectPr);
		Base::SetCurrentSepx(&sepx);
		Base::GetDop().dop = m_dop;		
		m_textboxes.LinkTextbox(this);
	}
public:
	STDMETHODIMP_(void) Close(BOOL fAbort = FALSE)
	{		
		Finalize();
		Base::Close(fAbort);
	}
	
	STDMETHODIMP Finalize()
	{
		__RtfFinalize();
		return Base::Finalize();
	}

public:
	// textstream	
	STDMETHODIMP_(void) AddContent(WCHAR wch)
	{
		NewSpan();
		Base::AddContent(wch);
	}
	STDMETHODIMP_(void) AddContent(LPCWSTR szText, UINT cch)
	{
		NewSpan();
		Base::AddContent(szText, cch);		
	}
	STDMETHODIMP_(void) EndParagraph()
	{
		NewParagraph(0x0d);
	}

public:
	// section	
	STDMETHODIMP_(void) EndSection()
	{
		NewParagraph(0x0c);		
		KDWPropBuffer sepx;
		ConvertSepx(sepx, &m_sectPr);
		Base::SetCurrentSepx(&sepx);
		Base::NewNullSepxSection();
	}
	STDMETHODIMP EnterHeaderFooter(HEADERFOOTER_TYPE hdrftrType)
	{
		HRESULT hr = Base::EnterHeaderFooter(hdrftrType);
		if (SUCCEEDED(hr))	
			return Base::NewNullPapxParagraph();		
		return hr;
	}	
public:
	STDMETHODIMP GetCpFieldInst(CP& cpFieldInst, CP cpFieldStart) const
	{
		const KDWFieldContext* pFc = m_fields.GetCurrentFC(this);
		if(!pFc)
			return E_FAIL;		
		KDWTextStream* cur = GetCurSubdoc();
		if(!cur)
			return E_FAIL;		
		CP cpEnd = cpFieldStart;
		while(cpFieldStart < GetFcMax())
		{
			if(cur->TextPool().at(cpFieldStart) == 0x13)
			{
				++cpFieldStart;
				while(cpFieldStart < GetFcMax())
				{
					if(cur->TextPool().at(cpFieldStart) == 0x15)
					{	
						++cpFieldStart;
						cpEnd = cpFieldStart;
						break;
					}
					++cpFieldStart;
				}
			}
			++cpFieldStart;
		}
		cpFieldInst = cpEnd;
		return S_OK;
	}
	// fields
	STDMETHODIMP MarkFieldBegin()
	{
		NewSpan();
		return Base::MarkFieldBegin();
	}
public:
	// bookmarks
	STDMETHODIMP MarkBookmarkBegin(LPCWSTR szBkmk, UINT cch)
	{
		KDWKernStr* szBkmkName = AllocString(szBkmk, cch);
		BookmarkKeyType idBkmk(szBkmk, cch);
		return m_bkmks.MarkBookmarkBegin(this, szBkmkName, idBkmk);
	}	
	STDMETHODIMP MarkBookmarkEnd(LPCWSTR szBkmk, UINT cch)
	{
		BookmarkKeyType idBkmk(szBkmk, cch);
		return m_bkmks.MarkBookmarkEnd(this, idBkmk);
	}	
public:
	// drawing	
	STDMETHODIMP EnterTextBox(IN KDWShape shape)
	{
		HRESULT hr = Base::EnterTextBox(shape);
		if (SUCCEEDED(hr))		
			return Base::NewNullPapxParagraph();		
		return hr;
	}	
	STDMETHODIMP_(KDWShape) AddInlinePicture(IN UINT cxaShape, IN UINT cyaShape)
	{
		NewSpan();
		return Base::AddInlinePicture(cxaShape, cyaShape);
	}
	STDMETHODIMP_(KDWShape) AddShape(IN BOOL fGroup)
	{
		NewSpan();
		return Base::AddShape(fGroup);
	}	
	STDMETHODIMP_(KDWShape) AddShape()
	{
		NewSpan();
		return Base::AddShape();
	}
	STDMETHODIMP_(KDWShape) AddGroupShape()
	{
		NewSpan();
		return Base::AddGroupShape();
	}	
public:
	// texttable
	STDMETHODIMP_(void) EndCell()
	{
		NewParagraph(0x07);
	}
	STDMETHODIMP_(void) EndNestCell()
	{		
		NewParagraph(0x0d, TRUE);		
	}	
	STDMETHODIMP_(void) EndTableRow()
	{	
		if(m_trow.m_fhoriMerge)
			m_trow.HoriMerge();
		m_trow.EndTableRow(this, m_paraPr.nTableLayer,&m_tblPos);
		Base::NewNullPapxParagraph();
	}	
public:
	// footnote & endnote
	STDMETHODIMP_(void) AddFndEndRef()
	{	
		switch(m_rtf_subdoc)
		{
		case DW_SUBDOC_MAIN:
			m_noteref_spanPr = m_spanPr;
			m_fNoFndEndRef = FALSE;
			m_fHaveEnter = FALSE;
			break;
		case DW_SUBDOC_FOOTNOTE:
		case DW_SUBDOC_ENDNOTE:			
			m_spanPr.fSpec=1;
			NewSpan();
			Base::AddContent(0x02);
			break;		
		}		
	}
	STDMETHODIMP EnterFndEndBody(SUBDOC_TYPE rtf_subdoc)
	{
		if(m_fNoFndEndRef)
			NewSpan();
		else
			NewSpan(m_noteref_spanPr);
		HRESULT hr = E_FAIL;
		if(!m_fHaveEnter)
		{			
			switch(rtf_subdoc)
			{
			case DW_SUBDOC_FOOTNOTE:
				hr = Base::EnterFootnotes(m_fNoFndEndRef);
				if(SUCCEEDED(hr))
				{
					m_fHaveEnter=TRUE;
					return Base::NewNullPapxParagraph();
				}
			case DW_SUBDOC_ENDNOTE:
				hr = Base::EnterEndnotes(m_fNoFndEndRef);
				if(SUCCEEDED(hr))
				{
					m_fHaveEnter=TRUE;
					return Base::NewNullPapxParagraph();
				}
			}				
		}		
		return hr;
	}
	STDMETHODIMP_(void) LeaveFndEndBody()
	{
		Base::LeaveFootnotes();
		m_fNoFndEndRef = TRUE;
		m_fHaveEnter=FALSE;
		m_rtf_subdoc = DW_SUBDOC_MAIN;
	}
private:
	typedef std::map<UINT, RtfList> listid2list_type;
	typedef std::vector<UINT> listoverride_table_type;
	typedef std::vector<KDWPicBullet> picbullet_table_type;
	listid2list_type m_listid2list;
	listoverride_table_type m_listoverridetbl;
	picbullet_table_type m_picbullettbl;
public:
	// list table
	STDMETHODIMP_(void) SetListId(RtfList list, UINT listid)
	{
		ASSERT(m_listid2list.find(listid) == m_listid2list.end());		
		m_listid2list[listid] = list;
	}
	STDMETHODIMP GetList(UINT listid, RtfList* list) const
	{
		listid2list_type::const_iterator 
			it = m_listid2list.find(listid);
		if (it != m_listid2list.end())
		{
			*list = (*it).second;
			return S_OK;
		}
		ASSERT(0);
		return E_FAIL;
	}
	STDMETHODIMP_(void) SetListOverrideIndex(const RtfListOverride& lfo, UINT ilfo)
	{
		enum { MAX_ILFO = 4000 /* RTF�ĵ�˵�ǣ�2000 */ };
		--ilfo;
		ASSERT(ilfo < MAX_ILFO);
		if (ilfo < m_listoverridetbl.size())		
			m_listoverridetbl[ilfo] = lfo.GetIndex();		
		else if (ilfo < MAX_ILFO)
		{
			m_listoverridetbl.resize(ilfo + 1);
			m_listoverridetbl[ilfo] = lfo.GetIndex();
		}
	}
	STDMETHODIMP_(UINT) GetListOverrideIndex(UINT ilfo) const
	{
		--ilfo;
		if (ilfo < m_listoverridetbl.size())		
			return m_listoverridetbl[ilfo];
		return 0;		
	}
	STDMETHODIMP_(void) NewPicBullet(KDWBlip blip)
	{
		ASSERT(blip.Good());		
		KDWPicBullet picbullet = GetPicBullets().NewPicBullet(blip);		
		m_picbullettbl.push_back(picbullet);
	}	
	STDMETHODIMP GetPicBullet(UINT ipicbullet, KDWPicBullet* picbullet) const
	{
		if (ipicbullet < m_picbullettbl.size())
		{
			*picbullet = m_picbullettbl[ipicbullet];
			return S_OK;
		}
		ASSERT(0);
		return E_FAIL;
	}	
private:
	typedef std::map<UINT, UINT> FontIdMap;
	FontIdMap m_fontidmap;
public:
	// font table
	STDMETHODIMP_(void) NewFont(UINT ifont, const KDWFont& font)
	{
		UINT fontid;
		GetFontTable().Add(font, &fontid);
		m_fontidmap[ifont] = fontid;
	}
	STDMETHODIMP_(UINT) GetFontId(UINT ifont) const
	{
		FontIdMap::const_iterator it = m_fontidmap.find(ifont);
		if (it != m_fontidmap.end())		
			return (*it).second;		
		ASSERT_ONCE(0);
		return DW_DEFAULT_FASTEAST_FONT;
	}
};
extern Group_Skipped _group_skipped;
class Group_Default : public Group_Base
{
public:
	RtfDocument* m_doc;	
	STDMETHODIMP StartGroup(RtfControl grName, int grValue, int& fDest)
	{
		if (fDest)
			fDest |= rtf_destSkipMask;
		return S_OK;
	}	
	STDMETHODIMP AddContent(LPCWSTR pContent, int cch)
	{		
		m_doc->AddContent(pContent, cch);
		return S_OK;
	}
	STDMETHODIMP EnterSubGroup(IN RtfControl grSubName, IN BOOL fDest1987, OUT RtfGroup** ppsubGroup)
	{
		if (grSubName == rtf_pict)
		{
			*ppsubGroup = &_group_skipped;
			return S_OK;
		}
		return E_NOTIMPL;
	}
};
class Group_Content : public Group_Base
{
public:
	RtfDocument* m_doc;	
	STDMETHODIMP AddContent(LPCWSTR pContent, int cch)
	{
		m_doc->AddContent(pContent, cch);
		return S_OK;
	}
};
#endif /* __RTFDOCUMENT_H__ */
