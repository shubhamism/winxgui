/* -------------------------------------------------------------------------
//	�ļ���		��	group_fldinst2.h
//	������		��	���὿
//	����ʱ��	��	2006-6-30 16:58:29
//	��������	��	
//
//	$Id: group_fldinst2.h,v 1.6 2006/09/21 06:29:05 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FLDINST2_H__
#define __GROUP_FLDINST2_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include "../core/group_textstream.h"
#endif

class Group_fldinst2 : public Group_TextStream
{
private:	
	int m_cpFldinstStart;
	ks_wstring m_incPic;
	INT _SkipSwitch(const KDWTextPool& textpool, INT cpFldinst)
	{
		INT cpMax = textpool.size();
		while(cpFldinst < cpMax)
		{
			WCHAR wch = textpool[cpFldinst];
			if(iswspace(wch))
				break;
			++cpFldinst;
		}
		while(cpFldinst < cpMax)
		{
			WCHAR wch = textpool[cpFldinst];
			if(!iswspace(wch))
				break;
			++cpFldinst;
		}
		return cpFldinst;
	}
public:	
	STDMETHODIMP_(ks_wstring&) GetIncludePicturePath();
	STDMETHODIMP_(int) GetCp();	
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);
	
	STDMETHODIMP EndGroup();
};

#endif /* __GROUP_FLDINST2_H__ */
