/* -------------------------------------------------------------------------
//	�ļ���		��	htmlfilter.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-22 17:41:44
//	��������	��	
//
//	$Id: htmlfilter.h,v 1.20 2006/09/12 06:09:34 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTMLFILTER_H__
#define __HTMLFILTER_H__

// -------------------------------------------------------------------------

#ifndef __KSO_IO_CONTENTSOURCE_H__
#include <kso/io/contentsource.h>
#endif

#ifndef __KSO_IO_FMTCHECK_H__
#include <kso/io/fmtcheck.h>
#endif

#ifndef __KSO_IO_COMPONENT_H__
#include <kso/io/component.h>
#endif

#ifndef __KSO_IO_HTML_HTML2RTF_H__
#include <kso/io/html/html2rtf.h>
#endif

#ifndef __KHTM2RTF_H__
#include "htm2rtf/khtm2rtf.h"
#endif

#ifndef __KHTM2RTF_LINKLIB_H__
#include "htm2rtf/khtm2rtf_linklib.h"
#endif

#include "htm/istream_itf_utility.h"

// -------------------------------------------------------------------------

inline
STDMETHODIMP htmlExport(IN IStream* pHtmlStrm, IN IStorage* pDocStg, LPCSTR htmlPath)
{	
	INT backupPos;
	SeekPos(pHtmlStrm, SEEK_CUR, 0, &backupPos);
#ifdef _DEBUG	
	ks_stdptr<IStream> spHtmlStrmTrace;
	spHtmlStrmTrace = pHtmlStrm;
	ks_stdptr<IStream> spRtfStrmTrace;
	CreateStreamOnFile(__X("c:\\trace_htmlExport.rtf"), STGM_WRITE|STGM_CREATE|STGM_SHARE_EXCLUSIVE, &spRtfStrmTrace);
	htm2rtf_ConvertHtm2Rtf(spHtmlStrmTrace, spRtfStrmTrace, UTF_8, GetACP(), htmlPath);
	spRtfStrmTrace->Commit(0);
#endif	
	SeekPos(pHtmlStrm, SEEK_SET, backupPos);
	ks_stdptr<IStream> spRtfStrm;
	HRESULT hr = XCreateStreamOnHGlobal(NULL, TRUE, &spRtfStrm);
	if (FAILED(hr))
		return hr;

	hr = htm2rtf_ConvertHtm2Rtf(
		pHtmlStrm, spRtfStrm, 
		UTF_8, GetACP(),
		htmlPath
		);
	if (FAILED(hr))
		return hr;
	SeekPos(spRtfStrm, SEEK_SET, 0);	
	return rtfExport(spRtfStrm, pDocStg);
}

void _GetFileNames(char* szRtfFile, char* szHtmFile, LPCSTR htmlFileA)
{	
	strcpy(szHtmFile, htmlFileA);
	strcpy(szRtfFile, szHtmFile);
	strcat(szRtfFile, ".rtf");
}

inline
STDMETHODIMP htmlExport(IN LPCWSTR htmlFile, IN DWORD grfMode, IN IStorage* pDocStg)
{	
	USES_CONVERSION;
	char szRtfFile[MAX_PATH] = "", szHtmFile[MAX_PATH] = ""; HRESULT hr;
	_GetFileNames(szRtfFile, szHtmFile, W2A(htmlFile));
	hr = htm2rtf_ConvertHtm2RtfByFile(szHtmFile, grfMode, szRtfFile, UTF_8, GetACP());
	if(FAILED(hr))
		return hr;
	hr = rtfExportEx(A2W(szRtfFile), pDocStg);
	DeleteFileA(szRtfFile);
	return hr;
}

inline
STDMETHODIMP htmlConvert(IN LPCWSTR htmlFile, IN DWORD grfMode, IN LPCWSTR docFile)
{
	ks_stdptr<IStorage> spRootStg;
	
	HRESULT hr = StgCreateDocfile(
		docFile, STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE, 0, &spRootStg);
	ASSERT_OK(hr);
	
	if (FAILED(hr))
		return hr;
	
	return htmlExport(htmlFile, grfMode, spRootStg);
}

// -------------------------------------------------------------------------

class KHtmlFilter : 
	public IKContentSource,
	public IKFilterMediaInit
{
private:
	IKContentSource* m_pSrc;

public:
	KHtmlFilter() : m_pSrc(NULL)
	{
	}
	~KHtmlFilter()
	{
		KS_RELEASE(m_pSrc);
	}

public:
	// IKFilterMediaInit
	
	STDMETHODIMP Init(
		IN LPCFILTERMEDIUM pMedium)
	{
		if (m_pSrc != NULL)
			return E_ACCESSDENIED;
		
		HRESULT hr = S_OK;
		ks_stdptr<ILockBytes> spLB;
		switch(pMedium->tymed)
		{
		case FILTER_TYMED_FILE:
			hr = XCreateILockBytesOnHGlobal(NULL, TRUE, &spLB);
			KS_CHECK(hr);
			{
				ks_stdptr<IStorage> spStg;
				hr = StgCreateDocfileOnILockBytes(
					spLB, STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 0, &spStg);
				KS_CHECK(hr);
				
				hr = htmlExport(pMedium->lpszFileName, pMedium->grfModeForFileName, spStg);
				KS_CHECK(hr);
				
				hr = _dr_CreateSourceEx(spStg, &m_pSrc);
				KS_CHECK(hr);
			}
			return S_OK;
		case FILTER_TYMED_ISTREAM:
			hr = XCreateILockBytesOnHGlobal(NULL, TRUE, &spLB);
			KS_CHECK(hr);
			{
				ks_stdptr<IStorage> spStg;
				hr = StgCreateDocfileOnILockBytes(
					spLB, STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 0, &spStg);
				KS_CHECK(hr);
				
				hr = htmlExport(pMedium->pstm, spStg);
				KS_CHECK(hr);
				
				hr = _dr_CreateSourceEx(spStg, &m_pSrc);
				KS_CHECK(hr);
			}
			return S_OK;
		default:
			return E_INVALIDARG;
		}
KS_EXIT:
		return hr;
	}
	
public:
	// IKContentSource
	
	/*
	@fn Transfer
	@brief
		��������Դ���������ݣ���һ�����ݽ�����(IKContentHandler)�С�
	@arg [in] pHandler
		�ṩ�����ݽ�������ָ�롣���ڽ��ܴ�������ݡ�
	@return
		���ܵķ���ֵ�У�
		@val S_OK
			����ɹ���
		@val E_ACCESSDENIED
			����û��׼���á�
		@val �κ���������ֵ
			�κ���IKContentHandler���صĴ���ֵ��
	*/
	STDMETHODIMP Transfer(
		IN IKContentHandler* pAcc)
	{
		if (m_pSrc == NULL)
			return E_ACCESSDENIED;

		return m_pSrc->Transfer(pAcc);
	}

	/*
	@fn Close
	@brief
		�رո�����Դ���˺��������Transfer������E_ACCESSDENIED��
	*/
	STDMETHODIMP Close()
	{
		if (m_pSrc)
		{
			m_pSrc->Release();
			m_pSrc = NULL;
		}
		return S_OK;
	}

	BEGIN_QUERYINTERFACE(IKContentSource)
		ADD_INTERFACE(IKFilterMediaInit)
	END_QUERYINTERFACE()
	DECLARE_CLASS(KHtmlFilter)
	DECLARE_COUNT(KHtmlFilter)
};
#endif /* __HTMLFILTER_H__ */
