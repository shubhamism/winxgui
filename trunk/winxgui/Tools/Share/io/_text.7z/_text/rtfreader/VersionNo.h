#define FILEVER        1,0,0,322
#define PRODUCTVER     1,0,0,322
#define STRFILEVER     "1,0,0,322\0"
#define STRPRODUCTVER  "1,0,0,322\0" 
