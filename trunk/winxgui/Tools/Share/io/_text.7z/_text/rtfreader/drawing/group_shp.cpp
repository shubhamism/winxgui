/* -------------------------------------------------------------------------
//	�ļ���		��	group_shp.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-30 0:00:02
//	��������	��	
//
//	$Id: group_shp.cpp,v 1.23 2006/08/09 06:29:32 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_shp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Group_shpinst

Group_shpinst::~Group_shpinst()
{
	RTF_DELETE_GROUP(m_shptxt);
	RTF_DELETE_GROUP(m_shpchild);
}

STDMETHODIMP Group_shpinst::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	switch (attrName)
	{
	case rtf_shpleft:
		m_anchor.xaLeft = attrValue;
		break;
	case rtf_shptop:
		m_anchor.yaTop = attrValue;
		break;
	case rtf_shpright:
		m_anchor.xaRight = attrValue;
		break;
	case rtf_shpbottom:
		m_anchor.yaBottom = attrValue;
		break;
	case rtf_shplockanchor:
		m_anchor.fAnchorLock = (attrValue != 0);
		break;	
	case rtf_shpz:
		m_shape.SetZOrder(attrValue);
		break;	
	case rtf_shpbxpage:
		m_anchor.xRel = mso_spaXRelTopOfPage;
		break;
	case rtf_shpbxmargin:
		m_anchor.xRel = mso_spaXRelPageMargin;
		break;
	case rtf_shpbxcolumn:
		m_anchor.xRel = mso_spaXRelText;
		break;	
	case rtf_shpbypage:
		m_anchor.yRel = mso_spaYRelTopOfPage;
		break;
	case rtf_shpbymargin:
		m_anchor.yRel = mso_spaYRelPageMargin;
		break;
	case rtf_shpbypara:
		m_anchor.yRel = mso_spaYRelText;
		break;	
	case rtf_shpwr:
		m_anchor.wrapMode = (FSPA_TEXTWRAP)attrValue;
		break;
	case rtf_shpwrk:
		m_anchor.wrapType = (FSPA_TEXTWRAPTYPE)attrValue;
		break;
	case rtf_shpbxignore:
		break;
	case rtf_shpbyignore:
		break;
	case rtf_shpfblwtxt:		
		break;
	case rtf_shplid:
		m_shplid = attrValue;
		break;
	case rtf_shpfhdr:
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_shpinst::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_sp:
		*ppsubGroup = &m_sp;
		m_sp.m_doc = m_doc;
		break;
	case rtf_shptxt:
		// ��Ϊ�����ͼƬ�󣬾Ͳ��������ı����ˣ�û������ġ��޸�#24580��BUG��		
		if(m_info.fPIB)
		{
			*ppsubGroup = &_group_skipped;
			m_info.fPIB = FALSE;
			break;
		}		
		if (m_shptxt == NULL)
			m_shptxt = RTF_NEW_GROUP(Group_shptxt);
		m_shptxt->m_doc = m_doc;;
		m_shptxt->m_shape = &m_shape;
		*ppsubGroup = m_shptxt;
		break;
	case rtf_shp:
	case rtf_shpgrp:
		if ( !m_shape.IsGroupShape() )
			return E_UNEXPECTED;
		if (m_shpchild == NULL)
			m_shpchild = RTF_NEW_GROUP(Group_shp_child);
		m_shpchild->m_doc = m_doc;
		m_shpchild->m_shpinst.NewChildShape(
			grSubName == rtf_shpgrp,
			m_shape	);
		*ppsubGroup = m_shpchild;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_shp_toplevel

STDMETHODIMP Group_shp_toplevel::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_shpinst:
		*ppsubGroup = &m_shpinst;
		m_shpinst.m_doc = m_doc;
		m_shpinst.Reset();
		break;
	case rtf_shprslt:		
		*ppsubGroup = &_group_skipped;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_shp_toplevel::EndGroup()
{
	m_shpinst.UpdateShape();
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_shp_child

STDMETHODIMP Group_shp_child::EnterSubGroup(
								   RtfControl grSubName,
								   BOOL fDest1987,
								   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_shpinst:
		*ppsubGroup = &m_shpinst;
		m_shpinst.m_doc = m_doc;
		m_shpinst.Reset();
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_shp_child::EndGroup()
{
	m_shpinst.UpdateChildShape();
	return S_OK;
}
