/* -------------------------------------------------------------------------
//	�ļ���		��	conv_paragraph.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-17 17:37:54
//	��������	��	
//
//	$Id: conv_paragraph.cpp,v 1.58 2006/09/04 08:28:19 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#if (0)
#define RTF_NO_PAPX
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP ConvertDxaLeft1(KDWPropBuffer& propx, RtfParaPr* pap, const RtfParaPr* baseOn, const RtfParaPr* listBaseOn)
{
	RtfParaPr::MaskType* mask = &pap->mask;	
	if(!listBaseOn)
	{
		AddPropFixMask(propx, sprmPDxaLeft1, mask->dxaLeft1, pap->dxaLeft1, baseOn->dxaLeft1);
		AddPropFixMask(propx, sprmPDxaLeft1Ex, mask->dxaLeft1, pap->dxaLeft1, baseOn->dxaLeft1);
		return S_OK;
	}
	AddPropFixMask(propx, sprmPDxaLeft1, mask->dxaLeft1, pap->dxaLeft1, listBaseOn->dxaLeft1);
	AddPropFixMask(propx, sprmPDxaLeft1Ex, mask->dxaLeft1, pap->dxaLeft1, listBaseOn->dxaLeft1);
	return S_OK;
}

STDMETHODIMP ConvertDxaLeft(KDWPropBuffer& propx, RtfParaPr* pap, const RtfParaPr* baseOn, const RtfParaPr* listBaseOn)
{
	RtfParaPr::MaskType* mask = &pap->mask;	
	if(!listBaseOn)
	{
		AddPropFixMask(propx, sprmPDxaLeft, mask->dxaLeft, pap->dxaLeft, baseOn->dxaLeft);
		AddPropFixMask(propx, sprmPDxaLeftEx, mask->dxaLeft, pap->dxaLeft, baseOn->dxaLeft);
		return S_OK;
	}
	AddPropFixMask(propx, sprmPDxaLeft, mask->dxaLeft, pap->dxaLeft, listBaseOn->dxaLeft);
	AddPropFixMask(propx, sprmPDxaLeftEx, mask->dxaLeft, pap->dxaLeft, listBaseOn->dxaLeft);
	return S_OK;
}

STDMETHODIMP ConvertTabStops(KDWPropBuffer& propx, RtfParaPr* pap, const RtfParaPr* baseOn, const RtfParaPr* listBaseOn)
{
	RtfParaPr::MaskType* mask = &pap->mask;
	const RtfParaPr* base = NULL;
	const RtfParaPr::MaskType* baseMask = NULL;
	base = baseOn;
	/*
	if(!listBaseOn)
		base = baseOn;
	else	
		base = listBaseOn;
	*/
	baseMask = &base->mask;	
	if(mask->ktab||baseMask->ktab)
	{
		if(base->ktab != pap->ktab)
		{
			if(baseMask->ktab)
			{
				pap->ktab.itbdDelMax = base->ktab.itbdMac;
				for(UINT i=0; i<base->ktab.itbdMac; ++i)
					pap->ktab.rgdxaDel[i] = base->ktab.rgdxaTab[i];
			}
		}
		propx.AddTabStops(pap->ktab.itbdDelMax, pap->ktab.rgdxaDel, 
						  pap->ktab.itbdMac, pap->ktab.rgdxaTab, pap->ktab.rgtbd);
	}	
	return S_OK;
}

STDMETHODIMP AddPropIlfo(KDWPropBuffer& propx, RtfParaPr* pap, const RtfParaPr* baseOn)
{
	RtfParaPr::MaskType* mask = &pap->mask;	
	if(mask->ilfo)
	{
		if(pap->ilfo == 0)
		{
			propx.AddPropFix(sprmPIlfo, pap->ilfo);
			propx.AddPropFix(sprmPIlvl, pap->ilvl);
		}
		else
		{
			AddPropFixMask(propx, sprmPIlvl, mask->ilvl, pap->ilvl, baseOn->ilvl);
			AddPropFixMask(propx, sprmPIlfo, mask->ilfo, pap->ilfo, baseOn->ilfo);
		}
	}
	else
	{
		if(baseOn->mask.ilfo)
		{
			propx.AddPropFix(sprmPIlfo, 0);
			propx.AddPropFix(sprmPIlvl, 0);
		}
	}
	return S_OK;
}
STDMETHODIMP ConvertPapx(KDWPropBuffer& propx, RtfParaPr* pap, const RtfParaPr* baseOn, const RtfParaPr* listBaseOn)
{
	RtfParaPr::MaskType* mask = &pap->mask;
	AddPropIlfo(propx, pap, baseOn);	
	AddPropFixMask(propx, sprmPOutLvl, mask->lvl, pap->lvl, baseOn->lvl);
	AddPropFixMask(propx, sprmPJc, mask->jc, pap->jc, baseOn->jc);
	AddPropFixMask(propx, sprmPJcEx, mask->jc, pap->jc, baseOn->jc);	
	ConvertDxaLeft1(propx, pap, baseOn, listBaseOn);
	AddPropFixMask(propx, sprmPDxaLeft1Rel, mask->dxaLeft1Rel, pap->dxaLeft1Rel, baseOn->dxaLeft1Rel);
	ConvertDxaLeft(propx, pap, baseOn, listBaseOn);		
	AddPropFixMask(propx, sprmPDxaLeftRel, mask->dxaLeftRel, pap->dxaLeftRel, baseOn->dxaLeftRel);
	ConvertTabStops(propx, pap, baseOn, listBaseOn);
	AddPropFixMask(propx, sprmPDxaRight, mask->dxaRight, pap->dxaRight, baseOn->dxaRight);
	AddPropFixMask(propx, sprmPDxaRightEx, mask->dxaRight, pap->dxaRight, baseOn->dxaRight);
	AddPropFixMask(propx, sprmPDxaRightRel, mask->dxaRightRel, pap->dxaRightRel, baseOn->dxaRightRel);
	AddPropFixMask(propx, sprmPDyaBefore, mask->dyaBefore, pap->dyaBefore, baseOn->dyaBefore);
	AddPropFixMask(propx, sprmPDyaBeforeRel, mask->dyaBeforeRel, pap->dyaBeforeRel, baseOn->dyaBeforeRel);
	AddPropFixMask(propx, sprmPDyaAfter, mask->dyaAfter, pap->dyaAfter, baseOn->dyaAfter);
	AddPropFixMask(propx, sprmPDyaAfterRel, mask->dyaAfterRel, pap->dyaAfterRel, baseOn->dyaAfterRel);
	AddPropBoolMask(propx, sprmPFDyaBeforeAuto, mask->fAutoSpacingBefore,
							pap->fAutoSpacingBefore, baseOn->fAutoSpacingBefore);
	AddPropBoolMask(propx, sprmPFDyaAfterAuto, mask->fAutoSpacingAfter,
							pap->fAutoSpacingAfter, baseOn->fAutoSpacingAfter);	
	AddPropBoolMask(propx, sprmPFAdjustRight, mask->fAdjustRight,
							pap->fAdjustRight, baseOn->fAdjustRight);	
	AddPropFixMask(propx, sprmPDyaLine, mask->lspd, pap->lspd, baseOn->lspd);
	AddPropBoolMask(propx, sprmPFUsePgsuSettings, mask->fUsePgsuSettings,
							pap->fUsePgsuSettings, baseOn->fUsePgsuSettings);
	
	AddPropBoolMask(propx, sprmPFWidowControl, mask->fWidowControl,
	pap->fWidowControl, baseOn->fWidowControl);	
	
	AddPropBoolMask(propx, sprmPFKeep, mask->fKeep, pap->fKeep, baseOn->fKeep);
	AddPropBoolMask(propx, sprmPFKeepFollow, mask->fKeepFollow, pap->fKeepFollow, baseOn->fKeepFollow);
	AddPropBoolMask(propx, sprmPFPageBreakBefore, mask->fPageBreakBefore,
							pap->fPageBreakBefore, baseOn->fPageBreakBefore);
	AddPropBoolMask(propx, sprmPFNoLineNumb, mask->fNoLnn, 
							pap->fNoLnn, baseOn->fNoLnn);
	AddPropBoolMask(propx, sprmPFNoAutoHyph, mask->fNoAutoHyph,
							pap->fNoAutoHyph, baseOn->fNoAutoHyph);
	AddPropBoolMask(propx, sprmPFKinsoku, mask->fKinsoku,
							pap->fKinsoku, baseOn->fKinsoku);
	AddPropBoolMask(propx, sprmPFWordWrap, mask->fWordWrap,
							pap->fWordWrap, baseOn->fWordWrap);
	AddPropBoolMask(propx, sprmPFOverflowPunct, mask->fOverflowPunct,
							pap->fOverflowPunct, baseOn->fOverflowPunct);
	AddPropBoolMask(propx, sprmPFAutoSpaceDE, mask->fAutoSpaceDE,
							pap->fAutoSpaceDE, baseOn->fAutoSpaceDE);
	AddPropBoolMask(propx, sprmPFAutoSpaceDN, mask->fAutoSpaceDN,
							pap->fAutoSpaceDN, baseOn->fAutoSpaceDN);
	AddPropBoolMask(propx, sprmPFTopLinePunct, mask->fTopLinePunct,
							pap->fTopLinePunct, baseOn->fTopLinePunct);
	AddPropFixMask(propx, sprmPWAlignFont, mask->wAlignFont, pap->wAlignFont, baseOn->wAlignFont);
	AddPropFixMask(propx, sprmPDxaWidth, mask->frame.dxaWidth, pap->frame.dxaWidth, baseOn->frame.dxaWidth);
	AddPropFixMask(propx, sprmPWHeightAbs, mask->frame.wHeightAbsOprand, pap->frame.wHeightAbsOprand.oprand, baseOn->frame.wHeightAbsOprand.oprand);
	AddPropFixMask(propx, sprmPPc, mask->frame.ppcOprand, pap->frame.ppcOprand.oprand, baseOn->frame.ppcOprand.oprand);
	AddPropFixMask(propx, sprmPDxaAbs, mask->frame.dxaAbs, pap->frame.dxaAbs, baseOn->frame.dxaAbs);
	AddPropFixMask(propx, sprmPDyaAbs, mask->frame.dyaAbs, pap->frame.dyaAbs, baseOn->frame.dyaAbs);
	AddPropFixMask(propx, sprmPFLocked, mask->frame.fLocked, pap->frame.fLocked, baseOn->frame.fLocked);
	AddPropFixMask(propx, sprmPDxaFromText, mask->frame.dxaFromText, pap->frame.dxaFromText, baseOn->frame.dxaFromText);
	AddPropFixMask(propx, sprmPDyaFromText, mask->frame.dyaFromText, pap->frame.dyaFromText, baseOn->frame.dyaFromText);
	AddPropFixMask(propx, sprmPWr, mask->frame.wr, pap->frame.wr, baseOn->frame.wr);
	AddPropFixMask(propx, sprmPDcs, mask->frame.dropCap, pap->frame.dropCap, baseOn->frame.dropCap);
	AddPropFixMask(propx, sprmPCantOverlap, mask->frame.fabsnoovrlp, pap->frame.fabsnoovrlp, baseOn->frame.fabsnoovrlp);
	AddPropFixMask(propx, sprmPFrameTextFlow, mask->frame.textFlow, pap->frame.textFlow, baseOn->frame.textFlow);

	AddBrcMask(propx, sprmPBrcTop, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcExMask(propx, sprmPBrcTopEx, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcMask(propx, sprmPBrcLeft, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcExMask(propx, sprmPBrcLeftEx, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcMask(propx, sprmPBrcBottom, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcExMask(propx, sprmPBrcBottomEx, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcMask(propx, sprmPBrcRight, mask->brcBox, pap->brcBox, baseOn->brcBox);
	AddBrcExMask(propx, sprmPBrcRightEx, mask->brcBox, pap->brcBox, baseOn->brcBox);

	AddBrcMask(propx, sprmPBrcTop, mask->brcTop, pap->brcTop, baseOn->brcTop);
	AddBrcExMask(propx, sprmPBrcTopEx, mask->brcTop, pap->brcTop, baseOn->brcTop);
	AddBrcMask(propx, sprmPBrcLeft, mask->brcLeft, pap->brcLeft, baseOn->brcLeft);
	AddBrcExMask(propx, sprmPBrcLeftEx, mask->brcLeft, pap->brcLeft, baseOn->brcLeft);
	AddBrcMask(propx, sprmPBrcBottom, mask->brcBottom, pap->brcBottom, baseOn->brcBottom);
	AddBrcExMask(propx, sprmPBrcBottomEx, mask->brcBottom, pap->brcBottom, baseOn->brcBottom);
	AddBrcMask(propx, sprmPBrcRight, mask->brcRight, pap->brcRight, baseOn->brcRight);
	AddBrcExMask(propx, sprmPBrcRightEx, mask->brcRight, pap->brcRight, baseOn->brcRight);
	AddBrcMask(propx, sprmPBrcBetween, mask->brcBetween, pap->brcBetween, baseOn->brcBetween);
	AddBrcExMask(propx, sprmPBrcBetweenEx, mask->brcBetween, pap->brcBetween, baseOn->brcBetween);
	AddShdMask(propx, sprmPShd, mask->shd, pap->shd, baseOn->shd);
	AddShdExMask(propx, sprmPShdEx, mask->shd, pap->shd, baseOn->shd);
	if(mask->fInTable)
		propx.AddPropFix(sprmPFInTable, pap->fInTable!=0);
	if(mask->nTableLayer)
		propx.AddPropFix(sprmPPeriLayer, pap->nTableLayer);
	return S_OK;
}

STDMETHODIMP GetListPap(RtfParaPr* listPapx, const RtfParaPr* pap, RtfDocument* doc)
{	
	const RtfParaPr::MaskType* mask = &pap->mask;
	if(mask->ilfo && mask->ilvl)
	{
		const _DW_ListLevel* pLvl = doc->GetListTable().GetListLevel(pap->ilfo, pap->ilvl);
		if(!pLvl)
			return E_FAIL;
		KDWSprmList sprms((const BYTE*)pLvl->pPapx, pLvl->lvlf.cbGrpprlPapx);
		KDWSprmList::Enumerator enumer(&sprms);		
		RtfParaPr::MaskType* listMask = &listPapx->mask;
		KDWSprm sprm;
		while(SUCCEEDED(enumer.Next(&sprm)))
		{			
			const BYTE* pArg; INT len = -1;			
			switch(sprm.GetOpcode())
			{
			case sprmPDxaLeft1:
			case sprmPDxaLeft1Ex:
				sprm.GetSprmValue(&listPapx->dxaLeft1);
				_MemSetInt(listMask->dxaLeft1);
				break;
			case sprmPChgTabsPapx:
				sprm.GetArgument(&pArg, &len);
				AssignKDWtab(listPapx->ktab, pArg);
				_MemSetInt(listMask->ktab);
				break;
			case sprmPDxaLeft:
			case sprmPDxaLeftEx:				
				sprm.GetSprmValue(&listPapx->dxaLeft);
				_MemSetInt(listMask->dxaLeft);				
				break;
			}
		}
		return S_OK;
	}
	return E_FAIL;
}
STDMETHODIMP ConvertPapx(KDWPropBuffer& propx, RtfParaPr* pap, RtfDocument* doc)
{	
	RtfStyle* style = NULL;
	if(pap->mask.istd)
	{		
		style = doc->m_stylesheet.GetStyle(pap->istd);		
		propx.AddIstd(style->m_styleIdByWord);
	}
	if (style == NULL)	
	{
		propx.AddIstd(stiNormal);
		style = doc->m_stylesheet.GetNormalStyle();	
	}

	const RtfParaPr& baseOn = style->SafeGetParaPr();
	
	if(pap->mask.ilfo)
	{
		RtfParaPr listPapx;
		if(SUCCEEDED(GetListPap(&listPapx, pap, doc)))		
		{
			AddPard(pap);
			return ConvertPapx(propx, pap, &baseOn, &listPapx);
		}
	}
	AddPard(pap);
	return ConvertPapx(propx, pap, &baseOn);
}