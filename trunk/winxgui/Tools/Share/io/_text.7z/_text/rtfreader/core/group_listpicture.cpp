/* -------------------------------------------------------------------------
//	�ļ���		��	group_listpicture.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-4 22:26:40
//	��������	��	
//
//	$Id: group_listpicture.cpp,v 1.5 2006/02/27 08:19:49 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_listpicture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Group_listpict

STDMETHODIMP Group_listpict::AddBinary(
					   LPCVOID pData,
					   int cbData)
{
	KDWBlip blip = 
		m_doc->GetBlipStore().NewBlip(pData, cbData, m_blipType);
	m_doc->NewPicBullet(blip);
	return S_OK;
}

STDMETHODIMP Group_listpict::EndGroup()
{
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_listpicture

STDMETHODIMP Group_listpicture::EnterSubGroup(
											  RtfControl grSubName,
											  BOOL fDest1987,
											  RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_pict:
		*ppsubGroup = &m_pict;
		break;
	case rtf_shppict:
		*ppsubGroup = this;
		break;
	case rtf_nonshppict:
		*ppsubGroup = &_group_skipped;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: group_listpicture.cpp,v $
//	Revision 1.5  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	
