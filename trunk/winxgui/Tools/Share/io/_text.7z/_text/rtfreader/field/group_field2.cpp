/* -------------------------------------------------------------------------
//	�ļ���		��	group_field2.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-30 16:53:34
//	��������	��	
//
//	$Id: group_field2.cpp,v 1.22 2006/09/18 09:19:14 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#include "stdafx.h"
#include "htm/length_unit.h"
#include <mso/dom/text/drawing/drawing_helper.h>
#include "group_field2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP Group_field2::StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
{
	Group_TextStream::StartGroup(grName, grValue, fDest);
	m_doc->m_includePictureOpt.Reset();
	m_fDirty = FALSE;
	m_fEdited = FALSE;
	m_fLock = FALSE;	
	return m_doc->MarkFieldBegin();	
}

STDMETHODIMP Group_field2::AddAttribute(
		RtfControl attrName,
		int attrValue)
{
	switch(attrName)
	{
	case rtf_flddirty:
		m_fDirty = (attrValue!=0);		
		m_fEdited = m_fDirty;
		break;
	case rtf_fldedit:
		m_fEdited = (attrValue!=0);
		m_fDirty = m_fEdited;
		break;
	case rtf_fldlock:
		m_fLock = (attrValue!=0);		
		break;
	default:
		return Group_TextStream::AddAttribute(attrName, attrValue);
	}
	return S_OK;
}

STDMETHODIMP Group_field2::EnterSubGroup(
	RtfControl grSubName,
	BOOL fDest1987,
	RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_fldinst:
		*ppsubGroup = &m_fldinst;
		m_fldinst.m_doc = m_doc;
		break;
	case rtf_fldrslt:
		*ppsubGroup = &m_fldrslt;
		m_fldrslt.m_doc = m_doc;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_field2::EndGroup()
{	
	_IncludePicture();
	m_doc->SetCurrentFieldResultDirty(m_fDirty);
	m_doc->SetCurrentFieldResultEdited(m_fEdited);
	m_doc->SetCurrentFieldLock(m_fLock);
	m_doc->MarkFieldEnd();
	_DeleteSymbolField();
	m_fldinst.GetIncludePicturePath().clear();
	m_doc->m_includePictureOpt.Reset();
	return Group_TextStream::EndGroup();
}

STDMETHODIMP_(INT) Group_field2::_GetPictureType(LPCWSTR picFile)
{
	LPCWSTR pExt = wcsrchr(picFile, '.');
	INT bliptype;
	if(pExt)
	{
		if(!wcsicmp(pExt, __X(".emf")))
			return msoblipEMF;
		else if(!wcsicmp(pExt, __X(".wmf")))
			return msoblipWMF;
		else if(!wcsicmp(pExt, __X(".pict")))
			return msoblipPICT;
		else if(!wcsicmp(pExt, __X(".jpg")))
			return msoblipJPEG;
		else if(!wcsicmp(pExt, __X(".jpeg")))
			return msoblipJPEG;
		else if(!wcsicmp(pExt, __X(".png")))
			return msoblipPNG;
		else if(!wcsicmp(pExt, __X(".dib")))
			return msoblipDIB;
		else if(!wcsicmp(pExt, __X(".gif")))
			return msoblipGIF;
		else
			return msoblipPNG;
	}
	Gdiplus::Image image(picFile);
	GUID fmt;
	image.GetRawFormat(&fmt);
	_XGdiGetBlipType(fmt, &bliptype);
	return bliptype;
}

STDMETHODIMP Group_field2::_InitPictureOpt(LPCWSTR picFile)
{	
	if(
		!m_doc->m_includePictureOpt.m_cxaShape ||
		!m_doc->m_includePictureOpt.m_cyaShape)
	{
		Gdiplus::Image image(picFile);
		PixelType width;
		PixelType height;
		InchType inchwidth;
		InchType inchheight;
		width = image.GetWidth();
		height = image.GetHeight();
		inchwidth = pixel_to_inch(width);
		inchheight = pixel_to_inch(height);
		m_doc->m_includePictureOpt.m_cxaShape = inch_to_twip(inchwidth);
		m_doc->m_includePictureOpt.m_cyaShape = inch_to_twip(inchheight);
	}
	return S_OK;
}

STDMETHODIMP Group_field2::_IncludePicture()
{	
	if(m_doc->GetCurrentFieldType() != mso_fltIncludePicture)
		return E_FAIL;
	if(m_fldinst.GetIncludePicturePath().size() <= 0)
		return E_FAIL;	
	enum
	{
		lenof_picFile = 1000,
	};
	WCHAR picFile[lenof_picFile] = __X("");
	USES_CONVERSION;
	LPCWSTR pUrl = m_fldinst.GetIncludePicturePath().c_str();
	HRESULT hr = IsValidURL(NULL, pUrl, 0);
	if( hr!=S_OK)
		return E_FAIL;	
	hr = _XUrlDownloadToCacheFile(pUrl, picFile, lenof_picFile);
	KDWBlip newBlip;
	INT bliptype;
	if(FAILED(hr))
	{	
		ASSERT_ONCE(0);
		return hr;
	}
	_InitPictureOpt(picFile);
	bliptype = _GetPictureType(picFile);
	newBlip = m_doc->GetBlipStore().NewBlip(picFile, (MSOBLIPTYPE)bliptype);
	if(newBlip.Good())
	{
		KDWShape shape = m_doc->AddInlinePicture(
		MulDiv(m_doc->m_includePictureOpt.m_cxaShape, m_doc->m_includePictureOpt.m_picscalex, 100),
		MulDiv(m_doc->m_includePictureOpt.m_cyaShape, m_doc->m_includePictureOpt.m_picscaley, 100)
		);
		RtfShapeOPT opt;
		opt.m_opt[0].AddPropFix(msopt_pib, newBlip);
		opt.UpdateShape(shape);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP Group_field2::_DeleteSymbolField()
{
	if (m_doc->GetCurrentFieldType() != mso_fltSymbol)
		return E_FAIL;
	// ---> start: ȡ��xch -- by xulingjiao
	const KDWTextPool& textpool = m_doc->GetCurSubdoc()->TextPool();
	UINT cpMax = textpool.size();
	UINT cpFldinst = m_fldinst.GetCp();
	while (cpFldinst < cpMax)
	{
		if ( isdigit(textpool[cpFldinst]) )
			break;
		++cpFldinst;
	}
	UINT16 xch = 0;
	while (cpFldinst < cpMax)
	{
		WCHAR wch = textpool[cpFldinst];
		if ( !isdigit(wch) )
			break;
		xch = xch * 10 + (wch - '0');
		++cpFldinst;
	}
	// ---> end
	m_doc->EraseFrom(m_fldinst.GetCp()-1);
	RtfSpanPr* spanPr = &(m_doc->m_spanPr);
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	spanPr->symbol.oprand.ftcSym = m_doc->GetFontId(m_fldrslt.m_ifont);
	spanPr->symbol.oprand.xchSym = xch;
	_MemSetInt(mask->symbol);
	spanPr->fIsDirty = TRUE;
	m_doc->AddContent(0x28);
	m_fldinst.GetIncludePicturePath().clear();
	return S_OK;
}






























