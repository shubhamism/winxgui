/* -------------------------------------------------------------------------
//	�ļ���		��	group_annotation.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-6 13:19:07
//	��������	��	
//
//	$Id: group_annotation.h,v 1.6 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_ANNOTATION_H__
#define __GROUP_ANNOTATION_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include "../core/group_textstream.h"
#endif

// -------------------------------------------------------------------------
class RtfGroup_atrfstart : public Group_Base
{
	ks_wstring m_atnRefId;
	CP m_atnRefStartCp;
public:
	RtfDocument* m_doc;
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);
	
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	

	STDMETHODIMP EndGroup();
};

class RtfGroup_atrfend : public Group_Base
{
	ks_wstring m_atnRefId;
	CP m_atnRefEndCp;
public:
	RtfDocument* m_doc;
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);
	
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	

	STDMETHODIMP EndGroup();
};

class RtfGroup_atnid : public Group_Base
{	
public:
	RtfDocument* m_doc;	
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	
};

class RtfGroup_atnauthor : public Group_Base
{	
public:
	RtfDocument* m_doc;
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	
};

class RtfGroup_atnref : public Group_Base
{		
public:
	RtfDocument* m_doc;
	ks_wstring* m_ref;
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);
	
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	
};

class RtfGroup_atndate : public Group_Base
{	
public:	
	ks_wstring* m_date;
	RtfDocument* m_doc;
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);
	
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	
};

class RtfGroup_annotation : public Group_TextStream
{
	RtfGrpObject<RtfGroup_atnref> m_atnref;
	RtfGrpObject<RtfGroup_atndate> m_atndate;
	ks_wstring m_date;
	ks_wstring m_ref;
	UINT m_fHasEnter;
private:
	STDMETHODIMP EnterEnterAnnotation();
	
public:	
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);
	
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch);	
	
	STDMETHODIMP AddBinary(
		IN LPCVOID pData,
		IN int cbData);
		
	STDMETHODIMP EndGroup();
	
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);	
};

// -------------------------------------------------------------------------
//	$Log: group_annotation.h,v $
//	Revision 1.6  2006/09/11 08:00:23  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.5  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.4  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.3  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	
#endif /* __GROUP_ANNOTATION_H__ */
