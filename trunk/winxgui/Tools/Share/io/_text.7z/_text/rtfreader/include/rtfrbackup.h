/* -------------------------------------------------------------------------
//	�ļ���		��	rtfrbackup.h
//	������		��	���὿
//	����ʱ��	��	2006-2-26 22:16:27
//	��������	��	
//
//	$Id: rtfrbackup.h,v 1.3 2006/06/06 01:53:28 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFRBACKUP_H__
#define __RTFRBACKUP_H__
template<class BackupType>
class RtfBackup
{	
private:
	UINT8 fBackup;
	BackupType m_backup;
public:
	RtfBackup() : fBackup(0){}
	STDMETHODIMP_(UINT8) beBackup()
	{
		return fBackup;
	}	
	STDMETHODIMP_(void) Backup(BackupType pr)
	{
		ASSERT_ONCE(fBackup == 0);
		m_backup = pr;
		fBackup = 1;
	}		
	STDMETHODIMP_(void) Restore(BackupType* pr)
	{
		ASSERT_ONCE(fBackup == 1);
		if(fBackup && pr)
		{
			*pr = m_backup;
			fBackup = 0;
		}
	}
};
// -------------------------------------------------------------------------
//	$Log: rtfrbackup.h,v $
//	Revision 1.3  2006/06/06 01:53:28  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/06/05 07:35:14  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.1  2006/02/27 01:53:01  xulingjiao
//	��������
//	

#endif /* __RTFRBACKUP_H__ */
