/* -------------------------------------------------------------------------
//	�ļ���		��	group_colortbl.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 14:39:12
//	��������	��	
//
//	$Id: group_colortbl.h,v 1.6 2006/03/06 01:39:48 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_COLORTBL_H__
#define __GROUP_COLORTBL_H__

// -------------------------------------------------------------------------

class Group_colortbl : public Group_Base
{
private:
	union
	{
		COLORREF m_rgb;
		struct
		{
			UINT8 r;
			UINT8 g;
			UINT8 b;
			UINT8 fauto;
		}m_color;
	};

public:
	RtfColorTable* m_colortbl;

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{
		m_rgb = RtfDefaultColor;
		fDest = TRUE;
		return S_OK;
	}

	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);	
	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);
};

// -------------------------------------------------------------------------
//	$Log: group_colortbl.h,v $
//	Revision 1.6  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.5  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	

#endif /* __GROUP_COLORTBL_H__ */
