/* -------------------------------------------------------------------------
//	�ļ���		��	prop_base.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-13 16:10:40
//	��������	��	
//
//	$Id: prop_base.h,v 1.1 2006/03/23 09:41:25 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __PROP_BASE_H__
#define __PROP_BASE_H__
// ����(Shd)
inline
PATTYPE GetShdng(int attrValue)
{		
	PATTYPE pat_array[] = 
	{
		mso_patAutomatic, mso_pat2Percent, mso_pat5Percent,	mso_pat7Percent,
		mso_pat10Percent, mso_pat12Percent,	mso_pat15Percent, mso_pat17Percent,
		mso_pat20Percent, mso_pat22Percent,	mso_pat25Percent, mso_pat27Percent,
		mso_pat30Percent, mso_pat32Percent,	mso_pat35Percent, mso_pat37Percent,
		mso_pat40Percent, mso_pat42Percent,	mso_pat45Percent, mso_pat47Percent,
		mso_pat50Percent, mso_pat52Percent, mso_pat55Percent, mso_pat57Percent,
		mso_pat60Percent, mso_pat62Percent,	mso_pat65Percent, mso_pat67Percent,
		mso_pat70Percent, mso_pat72Percent,	mso_pat75Percent, mso_pat77Percent,
		mso_pat80Percent, mso_pat82Percent, mso_pat85Percent, mso_pat87Percent,
		mso_pat90Percent, mso_pat92Percent,	mso_pat95Percent, mso_pat975Percent,
		mso_patSolid,
	};
	if(attrValue>=0 && attrValue<=10000)
	{
		UINT iPat = attrValue/250;
		if(pat_array[iPat] != 38)
			return pat_array[iPat];
		else
		{
			if(attrValue >= 9700)
				return mso_pat97Percent;
			else
				return pat_array[iPat];
		}
	}
	else
	{
		if(attrValue<0)
			return mso_patAutomatic;
		else
			return mso_patSolid;
	}
}

inline
STDMETHODIMP GetClPattern(KDWShd& shd, RtfControl attrName,int attrValue)
{
	switch(attrName)
	{	
	case rtf_clshdng:	
		shd.put_Pattern(GetShdng(attrValue));
		break;
	case rtf_clbghoriz:
		shd.put_Pattern(mso_patHorizontal);
		break;
	case rtf_clbgvert:	
		shd.put_Pattern(mso_patVertical);
		break;
	case rtf_clbgfdiag:	
		shd.put_Pattern(mso_patForwardDiagonal);
		break;	
	case rtf_clbgbdiag:	
		shd.put_Pattern(mso_patBackwardDiagonal);
		break;	
	case rtf_clbgcross:	
		shd.put_Pattern(mso_patCross);
		break;	
	case rtf_clbgdcross:	
		shd.put_Pattern(mso_patDiagonalCross);
		break;	
	case rtf_clbgdkhor:	
		shd.put_Pattern(mso_patDarkHorizontal);
		break;	
	case rtf_clbgdkvert:	
		shd.put_Pattern(mso_patDarkVertical);
		break;
	case rtf_clbgdkfdiag:	
		shd.put_Pattern(mso_patDarkForwardDiagonal);
		break;	
	case rtf_clbgdkbdiag:	
		shd.put_Pattern(mso_patDarkBackwardDiagonal);
		break;	
	case rtf_clbgdkcross:	
		shd.put_Pattern(mso_patDarkCross);
		break;	
	case rtf_clbgdkdcross:	
		shd.put_Pattern(mso_patDarkDiagonalCross);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}
inline
STDMETHODIMP GetChPattern(KDWShd& shd, RtfControl attrName,int attrValue)
{
	switch(attrName)
	{
	case rtf_chshdng:	
		shd.put_Pattern(GetShdng(attrValue));
		break;		
	case rtf_chbghoriz:	
		shd.put_Pattern(mso_patHorizontal);
		break;
	case rtf_chbgvert:	
		shd.put_Pattern(mso_patVertical);
		break;		
	case rtf_chbgfdiag:	
		shd.put_Pattern(mso_patForwardDiagonal);
		break;
	case rtf_chbgbdiag:	
		shd.put_Pattern(mso_patBackwardDiagonal);
		break;
	case rtf_chbgcross:	
		shd.put_Pattern(mso_patCross);
		break;
	case rtf_chbgdcross:	
		shd.put_Pattern(mso_patDiagonalCross);
		break;
	case rtf_chbgdkhoriz:	
		shd.put_Pattern(mso_patDarkHorizontal);
		break;
	case rtf_chbgdkvert:	
		shd.put_Pattern(mso_patDarkVertical);
		break;
	case rtf_chbgdkfdiag:	
		shd.put_Pattern(mso_patDarkForwardDiagonal);
		break;
	case rtf_chbgdkbdiag:	
		shd.put_Pattern(mso_patDarkBackwardDiagonal);
		break;
	case rtf_chbgdkcross:	
		shd.put_Pattern(mso_patDarkCross);
		break;
	case rtf_chbgdkdcross:	
		shd.put_Pattern(mso_patDarkDiagonalCross);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;	
}
inline
STDMETHODIMP GetParaPattern(KDWShd& shd, RtfControl attrName,int attrValue)
{
	switch(attrName)
	{	
	case rtf_shading:
		shd.put_Pattern(GetShdng(attrValue));
		break;
	case rtf_bghoriz:
		shd.put_Pattern(mso_patHorizontal);
		break;	
	case rtf_bgvert:
		shd.put_Pattern(mso_patVertical);
		break;
	case rtf_bgfdiag:
		shd.put_Pattern(mso_patForwardDiagonal);
		break;	
	case rtf_bgbdiag:
		shd.put_Pattern(mso_patBackwardDiagonal);
		break;	
	case rtf_bgcross:
		shd.put_Pattern(mso_patCross);
		break;	
	case rtf_bgdcross:
		shd.put_Pattern(mso_patDiagonalCross);
		break;	
	case rtf_bgdkhoriz:
		shd.put_Pattern(mso_patDarkHorizontal);
		break;	
	case rtf_bgdkvert:
		shd.put_Pattern(mso_patDarkVertical);
		break;	
	case rtf_bgdkfdiag:
		shd.put_Pattern(mso_patDarkForwardDiagonal);
		break;	
	case rtf_bgdkbdiag:
		shd.put_Pattern(mso_patDarkBackwardDiagonal);
		break;	
	case rtf_bgdkcross:
		shd.put_Pattern(mso_patDarkCross);
		break;	
	case rtf_bgdkdcross:
		shd.put_Pattern(mso_patDarkDiagonalCross);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: prop_base.h,v $
//	Revision 1.1  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	
//	Revision 1.26  2006/02/27 08:19:51  xulingjiao
//	rtfreader����mask
//	
#endif /* __PROP_BASE_H__ */
