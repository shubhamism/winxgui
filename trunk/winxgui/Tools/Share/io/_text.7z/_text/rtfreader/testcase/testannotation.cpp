/* -------------------------------------------------------------------------
//	�ļ���		��	testannotation.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-6 13:20:00
//	��������	��	
//
//	$Id: testannotation.cpp,v 1.3 2006/02/16 08:03:32 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestAnnotation : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestAnnotation);
		CPPUNIT_TEST(testBasic);	
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testBasic()
	{
		testRtf2DocFile("annotation/basic.rtf", "annotation_basic.doc");
		testRtf2DocFile("annotation/anns.rtf", "annotation_anns.doc");
		testRtf2DocFile("annotation/annotation.rtf", "annotation_annotation.doc");
	}	
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestAnnotation);

// -------------------------------------------------------------------------
//	$Log: testannotation.cpp,v $
//	Revision 1.3  2006/02/16 08:03:32  xulingjiao
//	�޸�����עBUG,���񵥶�����BUG
//	
//	Revision 1.2  2005/04/26 09:20:23  xushiwei
//	��bug
//	
//	Revision 1.1  2005/01/06 05:26:37  xushiwei
//	��ʼת����ע�ˡ�
//	
