/* -------------------------------------------------------------------------
//	�ļ���		��	rtfrannotation.h
//	������		��	���὿
//	����ʱ��	��	2006-2-26 22:20:21
//	��������	��	
//
//	$Id: rtfrannotation.h,v 1.1 2006/02/27 01:53:01 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFRANNOTATION_H__
#define __RTFRANNOTATION_H__
class RtfRAnnotation
{
private:
	typedef struct tagItemInfo
	{
		CP start;
		CP end;		
	}ItemInfo;
	typedef std::map<ks_wstring, ItemInfo> ItemInfoType;
	typedef ItemInfoType::value_type ItemType;	
	ItemInfoType m_atnInfo;
	_DW_UserNameInfo m_user;	
private:
	UINT GetUserId()
	{		
		KDWUsers& users = GetAnnotationUsers();
		UINT id, i;		
		for(i=0; i<users.GetCount(); ++i)
		{
			const _DW_UserNameInfo* info = users.GetUserNameInfo(i);
			if( info->userName->cb == m_user.userName->cb &&
				!memcmp(info->userName, m_user.userName, info->userName->cb) &&
				info->userNameAbbr->cb == m_user.userNameAbbr->cb &&
				!memcmp(info->userNameAbbr, m_user.userNameAbbr, info->userNameAbbr->cb))
				return i;
		}
		if(m_user.userName == NULL)
		{
			m_user.userName = AllocString(__X(""), 1);
		}
		if(m_user.userNameAbbr == NULL)
		{
			m_user.userName = AllocString(__X(""), 1);
		}
		users.Add(m_user.userName, m_user.userNameAbbr, &id);
		return id;		
	}
	DTTM GetDttm(ks_wstring atndate)
	{
		INT32 dt = _wtoi(atndate.c_str());
		DTTM dttm;
		dttm.mint = dt & 0x3F;
		dt >>= 6;
		dttm.hr = dt & 0x1F;
		dt >>= 5;
		dttm.dom = dt & 0x1F;
		dt >>= 5;
		dttm.mon = dt & 0xF;
		dt >>= 4;
		dttm.yr = dt & 0x1FF;
		dt >>= 9;
		dttm.wdy = dt & 0x7;
		dt >>= 3;
		return dttm;
	}
public:		
	STDMETHODIMP_(void) MarkAtnRefBegin(ks_wstring atnRefId, CP atnCp)
	{	
		ASSERT_ONCE(!m_atnInfo.count(atnRefId));
		ItemInfo info;
		info.start = atnCp;
		m_atnInfo.insert(ItemType(atnRefId, info));
	}
	STDMETHODIMP_(void) MarkAtnRefEnd(ks_wstring atnRefId, CP atnCp)
	{
		ASSERT_ONCE(m_atnInfo.count(atnRefId));
		ItemInfo& info = m_atnInfo[atnRefId];
		info.end = atnCp;
	}
	STDMETHODIMP_(void) SetAnnotationUser(LPCWSTR pContent, int cch, BOOL fAbbr)
	{
		if(fAbbr)		
			m_user.userNameAbbr = AllocString(pContent, cch);				
		else
			m_user.userName = AllocString(pContent, cch);
	}
	STDMETHODIMP EnterAnnotation(ks_wstring atnref, ks_wstring atndate)
	{	
		ItemInfo info;
		if(atnref.empty())
			info.start = info.end = GetMainSubdoc()->TextPool().size();
		else
			info = m_atnInfo[atnref];
		UINT userId = GetUserId(), cch = info.end - info.start;
		DTTM dttm = GetDttm(atndate);
		HRESULT hr = Base::EnterAnnotation(userId, dttm, cch);
		if (SUCCEEDED(hr))
			return Base::NewNullPapxParagraph();
		return hr;
	}
	STDMETHODIMP LeaveAnnotation()
	{
		m_user.userName = m_user.userNameAbbr = NULL;
		EndParagraph();
		return Base::LeaveAnnotation();
	}
}

// -------------------------------------------------------------------------
//	$Log: rtfrannotation.h,v $
//	Revision 1.1  2006/02/27 01:53:01  xulingjiao
//	��������
//	

#endif /* __RTFRANNOTATION_H__ */
