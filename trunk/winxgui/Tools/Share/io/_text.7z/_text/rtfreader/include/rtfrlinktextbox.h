/* -------------------------------------------------------------------------
//	�ļ���		��	rtfrlinktextbox.h
//	������		��	���὿
//	����ʱ��	��	2006-2-26 22:18:34
//	��������	��	
//
//	$Id: rtfrlinktextbox.h,v 1.1 2006/02/27 01:53:01 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFRLINKTEXTBOX_H__
#define __RTFRLINKTEXTBOX_H__
// һ��ר�����ı������ӵİ�װ��
// 1����Ҫ����shplid��ʵ��id��ӳ�����
// 2��һ������������Ϣ�Ľṹ
// struct
//{
//	UINT shplid;
//	UINT hspNext;
//};
// 3�����ĵ�Closeǰ���������ı���
class RtfLinkTextboxes
{
private:
	typedef ULONG RTFRSPID;
	typedef struct tagLinkInfo
	{
		tagLinkInfo(INT shplid, INT hspNext):
		m_shplid(shplid), m_hspNext(hspNext){}

		RTFRSPID m_shplid;
		RTFRSPID m_hspNext;
	}LinkInfo;
	typedef std::map<RTFRSPID, RTFRSPID> RTFRSPID_MAP;
	typedef std::vector<LinkInfo> LinkInfoType;
	RTFRSPID_MAP m_idMap;
	LinkInfoType m_linkInfo;
private:
	STDMETHODIMP_(void) LinkTextbox(KDWDrawing& drawing)
	{
		for(UINT i=0; i<m_linkInfo.size(); ++i)
		{
			RTFRSPID shplid = m_linkInfo[i].m_shplid;
			RTFRSPID id = m_idMap[shplid];
			RTFRSPID hspNext = m_linkInfo[i].m_hspNext;
			RTFRSPID idNext = m_idMap[hspNext];
			drawing.LinkTextBoxById(id, idNext);
		}
	}
public:	
	~RtfLinkTextboxes()
	{
		Clear();
	}
	STDMETHODIMP_(void) Clear()
	{
		m_idMap.clear();
		m_linkInfo.clear();
	}
	STDMETHODIMP_(void) AddIdMap(RTFRSPID key, RTFRSPID id)
	{
		ASSERT_ONCE(!m_idMap.count(key));
		m_idMap.insert(RTFRSPID_MAP::value_type(key, id));
	}
	STDMETHODIMP_(void) SetLinkInfo(RTFRSPID shplid, RTFRSPID hspNext)
	{
		m_linkInfo.push_back(LinkInfo(shplid, hspNext));
	}
	STDMETHODIMP_(void) LinkTextbox(KDWDocument* doc)
	{
		SUBDOC_TYPE curSubDoc = doc->GetCurSubdocType();
		if(curSubDoc != DW_SUBDOC_MAIN && curSubDoc != DW_SUBDOC_HEADERFOOTER)
			return;
		KDWDrawing drawing = doc->GetCurrentDrawing();
		if(drawing.Good())
			LinkTextbox(drawing);
		Clear();
	}
};
// -------------------------------------------------------------------------
//	$Log: rtfrlinktextbox.h,v $
//	Revision 1.1  2006/02/27 01:53:01  xulingjiao
//	��������
//	

#endif /* __RTFRLINKTEXTBOX_H__ */
