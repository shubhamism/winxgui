/* -------------------------------------------------------------------------
//	�ļ���		��	group_rtf.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 9:24:22
//	��������	��	
//
//	$Id: group_rtf.cpp,v 1.55 2006/10/26 01:01:09 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_fonttbl.h"
#include "group_stylesheet.h"
#include "group_upr.h"
#include "group_rtf.h"
#include <wingdi.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Group_Skipped _group_skipped;

// -------------------------------------------------------------------------

typedef RtfDocument RtfDopContext;

STDMETHODIMP Dop_AddAttribute(
							  RtfDop* dop,
							  RtfDopContext* context,
							  RtfControl attrName,
							  int attrValue)
{
	switch (attrName)	//---Page Information
	{
	case rtf_ansicpg:
		dop->DefCodePage = attrValue;
		break;
	case rtf_paperw:
		dop->DefXaPage = attrValue;
		break;
	case rtf_paperh:
		dop->DefYaPage = attrValue;
		break;
	case rtf_margl:
		dop->DefDxaLeft = attrValue;
		break;
	case rtf_margr:
		dop->DefDxaRight = attrValue;
		break;
	case rtf_margt:
		dop->DefDyaTop = attrValue;
		break;
	case rtf_margb:
		dop->DefDyaBottom = attrValue;
		break;
	case rtf_facingp:
		dop->fFacingPages = (attrValue!=1);//@tocheck
		break;
	case rtf_gutter:
		dop->DefDzaGutter = attrValue;
		break;
	case rtf_landscape:
		dop->DefDmOrientPage = mso_PageLandscape;
		break;
	case rtf_viewscale:
		dop->wScaleSaved = attrValue;
		break;
	case rtf_deftab:
		dop->dxaTab = attrValue;
		break;
	case rtf_hyphhotz:
		dop->dxaHotZ = attrValue;
		break;
	case rtf_hyphconsec:
		dop->cConsecHypLim = attrValue;
		break;
	case rtf_hyphcaps:
		dop->fHyphCapitals = attrValue!=0;
		break;
	case rtf_hyphauto:
		dop->fAutoHyphen = attrValue!=0;
		break;
	case rtf_linestart:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_fracwidth:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_makebackup:		//----dop���޶�Ӧ��Ա
		break;
	case rtf_defformat:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_psover:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_doctemp:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_deflang:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_deflangfe:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_doctype:
		dop->adt = attrValue;
		break;
	case rtf_fromtext:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_fromhtml:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_horzdoc:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_vertdoc:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_jcompress:
		dop->doptypography.iJustification = 1;//dop->doptypography.iJustification=2�����δ����
		break;
	case rtf_jexpand:
		dop->doptypography.iJustification = 0;
		break;
	case rtf_lnongrid:			//----dop���޶�Ӧ��Ա
		break;
	case rtf_viewkind:
		dop->wvkSaved = attrValue;
		break;
	case rtf_viewzk:
		dop->zkSaved = attrValue;
		break;
	case rtf_fet:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_endnotes:
		break;
	case rtf_enddoc:
		break;
	case rtf_ftntj:
		dop->fpc = 2;
		break;
	case rtf_ftnbj:
		dop->fpc = 1;
		break;	
	case rtf_aendnotes:
		dop->epc = 0;
		break;
	case rtf_aenddoc:
		dop->epc = 3;
		break;
	case rtf_aftntj:
		dop->epc = 2;
		break;
	case rtf_aftnbj:
		dop->epc = 1;
		break;
	case rtf_ftnstart:
		dop->nFtn = attrValue;
		break;
	case rtf_aftnstart:
		dop->nEdn = attrValue;
		break;
	case rtf_ftnrstcont:
		dop->rncFtn = 0;
		break;
	case rtf_ftnrestart:
		dop->rncFtn = 1;
		break;
	case rtf_ftnrstpg:
		dop->rncFtn = 2;
		break;
	case rtf_aftnrestart:
		dop->mcEdn = 1;
		break;
	case rtf_aftnrstcont:
		dop->mcEdn = 0;
		break;
	case rtf_ftnnar:
		dop->nfcFtnRef = mso_nfcArabic;
		break;	
	case rtf_ftnnalc:
		dop->nfcFtnRef = mso_nfcLCLetter;
		break;
	case rtf_ftnnauc:
		dop->nfcFtnRef = mso_nfcUCLetter;
		break;
	case rtf_ftnnrlc:
		dop->nfcFtnRef = mso_nfcLCRoman;
		break;
	case rtf_ftnnruc:
		dop->nfcFtnRef = mso_nfcUCRoman;
		break;
	case rtf_ftnnchi:
		dop->nfcFtnRef = mso_nfcChiManSty;
		break;
	case rtf_ftnnchosung:
		dop->nfcFtnRef = mso_nfcChosung;
		break;
	case rtf_ftnncnum:
		dop->nfcFtnRef = mso_nfcCirclenum;
		break;
	case rtf_ftnndbnum:
		dop->nfcFtnRef = mso_nfcDbNum1;
		break;
	case rtf_ftnndbnumd:
		dop->nfcFtnRef = mso_nfcDbNum2;
		break;
	case rtf_ftnndbnumt:
		dop->nfcFtnRef = mso_nfcDbNum3;
		break;
	case rtf_ftnndbnumk:
		dop->nfcFtnRef = mso_nfcDbNum4;
		break;
	case rtf_ftnndbar:
		dop->nfcFtnRef = mso_nfcDbChar;
		break;
	case rtf_ftnnganada:
		dop->nfcFtnRef = mso_nfcGanada;
		break;
	case rtf_ftnngbnum:
		dop->nfcFtnRef = mso_nfcGB1;
		break;
	case rtf_ftnngbnumd:
		dop->nfcFtnRef = mso_nfcGB2;
		break;
	case rtf_ftnngbnuml:
		dop->nfcFtnRef = mso_nfcGB3;
		break;
	case rtf_ftnngbnumk:
		dop->nfcFtnRef = mso_nfcGB4;
		break;
	case rtf_ftnnzodiac:
		dop->nfcFtnRef = mso_nfcZodiac1;
		break;
	case rtf_ftnnzodiacd:
		dop->nfcFtnRef = mso_nfcZodiac2;
		break;
	case rtf_ftnnzodiacl:
		dop->nfcFtnRef = mso_nfcZodiac3;
		break;	
	case rtf_aftnnar:
		dop->nfcEdnRef = mso_nfcArabic;
		break;
	case rtf_aftnnalc:
		dop->nfcEdnRef = mso_nfcLCLetter;
		break;
	case rtf_aftnnauc:
		dop->nfcEdnRef = mso_nfcUCLetter;
		break;
	case rtf_aftnnrlc:
		dop->nfcEdnRef = mso_nfcLCRoman;
		break;
	case rtf_aftnnruc:
		dop->nfcEdnRef = mso_nfcUCRoman;
		break;
	case rtf_aftnnchi:
		dop->nfcEdnRef = mso_nfcChiManSty;
		break;
	case rtf_aftnnchosung:
		dop->nfcEdnRef = mso_nfcChosung;
		break;
	case rtf_aftnncnum:
		dop->nfcEdnRef = mso_nfcCirclenum;
		break;
	case rtf_aftnndbnum:
		dop->nfcEdnRef = mso_nfcDbNum1;
		break;
	case rtf_aftnndbnumd:
		dop->nfcEdnRef = mso_nfcDbNum2;
		break;
	case rtf_aftnndbnumt:
		dop->nfcEdnRef = mso_nfcDbNum3;
		break;
	case rtf_aftnndbnumk:
		dop->nfcEdnRef = mso_nfcDbNum4;
		break;
	case rtf_aftnndbar:
		dop->nfcEdnRef = mso_nfcDbChar;
		break;
	case rtf_aftnnganada:
		dop->nfcEdnRef = mso_nfcGanada;
		break;
	case rtf_aftnngbnum:
		dop->nfcEdnRef = mso_nfcGB1;
		break;
	case rtf_aftnngbnumd:
		dop->nfcEdnRef = mso_nfcGB2;
		break;
	case rtf_aftnngbnuml:
		dop->nfcEdnRef = mso_nfcGB3;
		break;
	case rtf_aftnngbnumk:
		dop->nfcEdnRef = mso_nfcGB4;
		break;
	case rtf_aftnnzodiac:
		dop->nfcEdnRef = mso_nfcZodiac1;
		break;
	case rtf_aftnnzodiacd:
		dop->nfcEdnRef = mso_nfcZodiac2;
		break;
	case rtf_aftnnzodiacl:
		dop->nfcEdnRef = mso_nfcZodiac3;
		break;		
	case rtf_rtlgutter:
		dop->iGutterPos = 0;
		break;
	case rtf_gutterprl:
		dop->iGutterPos = 1;
		break;
	case rtf_margmirror:
		dop->fMirrorMargins = attrValue!=0;
		break;
	case rtf_pgnstart:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_widowctrl:
		dop->fWidowControl = attrValue!=0;
		break;
	case rtf_twoonone:
		dop->doptypography.f2on1 = 1;
		break;
	case rtf_linkstyles:
		dop->fLinkStyles = attrValue;
		break;
	case rtf_formprot:				//---@tocheck
		dop->fFormNoFields = attrValue!=0;
		dop->fProtEnabled = attrValue!=0;
		break;
	case rtf_formshade:
		dop->fShadeFormData = attrValue!=0;
		break;
	case rtf_allprot:				//---@tocheck
		break;
	case rtf_formdisp:				//---@tocheck
		break;
	case rtf_printdata:
		break;
	case rtf_revprot:
		dop->fLockRev = attrValue!=0;
		break;
	case rtf_revisions:
		dop->fRevMarking = attrValue!=0;
		break;
	case rtf_revprop:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_revbar:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_annotprot:
		dop->fLockAtn = attrValue!=0;
		break;
	case rtf_rtldoc:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_ltrdoc:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_cts:					//----dop���޶�Ӧ��Ա
		break;
	case rtf_jsksu:					//----dop���޶�Ӧ��Ա
		break;
	case rtf_ksulang:				//----dop���޶�Ӧ��Ա
		break;
	case rtf_dghspace:
		dop->dogrid.dxaGrid = attrValue;
		break;
	case rtf_dgvspace:
		dop->dogrid.dyaGrid = attrValue;
		break;
	case rtf_dghorigin:
		dop->dogrid.xaGrid = attrValue;
		break;
	case rtf_dgvorigin:
		dop->dogrid.yaGrid = attrValue;
		break;
	case rtf_dgvshow:
		dop->dogrid.dyGridDisplay = attrValue;
		break;
	case rtf_dghshow:
		dop->dogrid.dxGridDisplay = attrValue;
		break;
	case rtf_dgsnap:				//----dop���޶�Ӧ��Ա
		break;
	//��ͼ����Ķ�����������룬�����������������δ������dop��û����Ӧ��Ա��//@todo
	case rtf_dgmargin:
		dop->dogrid.fFollowMargins = attrValue;
		break;
	case rtf_pgbrdrhead:
		dop->fIncludeHeader = attrValue!=0;
		break;
	case rtf_pgbrdrfoot:
		dop->fIncludeFooter = attrValue!=0;
		break;
	case rtf_pgbrdrsnap:
		dop->fSnapBorder = attrValue!=0;
		break;
	//------------------------------------------------@add
	case rtf_sprstsm:
		dop->copts.fSuppressTopSpacingMac5 = attrValue!=0;
		break;
	case rtf_otblrul:		
		dop->copts.fOrigWordTableRules = attrValue!=0;		
		break;
	case rtf_msmcap:
		dop->copts.fMWSmallCaps = attrValue!=0;
		break;
	case rtf_oldlinewrap:
		dop->copts.fLineWrapLikeWord6 = attrValue!=0;
		break;
	case rtf_ftnlytwnine:
		dop->copts.fFootnoteLayoutLikeWW8 = 0;	//�ͽ����෴,Ĭ�����е�dop->copts.fFootnoteLayoutLikeWW8 = 1;
		break;
	case rtf_oldas:
		dop->copts.fAutoSpaceLikeWord95 = attrValue!=0;
		break;
	case rtf_splytwnine:
		dop->copts.fShapeLayoutLikeWW8 = 0;		//Ĭ����1
		break;
	case rtf_sprslnsp:
		dop->copts.fSuppressTopSpacingWP = attrValue!=0;
		break;
	case rtf_wpsp:
		dop->copts.fWPSpaceWidth = attrValue!=0;
		break;
	case rtf_wpjst:
		dop->copts.fWPJustification = attrValue!=0;
		break;
	case rtf_truncex:		//----dop���޶�Ӧ��Ա		
		break;	
	case rtf_lytexcttp:
		dop->copts.fNoExtraLineSpacing = attrValue!=0;
		break;
	case rtf_transmf:
		dop->copts.fTransparentMetafiles = attrValue!=0;
		break;
	case rtf_htmautsp:
		dop->copts.fHTMLAutoSpace = 0;			//Ĭ����1
		break;
	case rtf_noextrasprl:
		dop->copts.fNoSpaceRaiseLower = attrValue!=0;
		break;
	case rtf_notabind:
		dop->copts.fNoTabForInd = attrValue!=0;
		break;
	case rtf_nobrkwrptbl:
		dop->copts.fDontBreakWrappedTables = 0;		//Ĭ����1
		break;
	case rtf_nocolbal:
		dop->copts.fNoColumnBalance = attrValue!=0;
		break;
	case rtf_nolead:
		dop->copts.fNoLeading = attrValue!=0;
		break;
	case rtf_alntblind:								//�������������		
		break;
	case rtf_lnbrkrule:
		dop->copts.fUseWord97LineBreakingRules = 0;	//Ĭ����1
		break;
	case rtf_asianbrkrule:
		dop->copts.fUseAsianBreakRules = 0;		//Ĭ����1
		break;
	case rtf_wrppunct:
		dop->copts.fWrapTextWithPunct = 0;		//Ĭ����1
		break;
	case rtf_subfontbysize:
		dop->copts.fSubFontBySize = attrValue!=0;
		break;
	case rtf_useltbaln:
		dop->copts.fForgetLastTabAlignment = 0;	//Ĭ����1
		break;
	case rtf_wraptrsp:
		dop->copts.fWrapTrailSpaces = attrValue!=0;
		break;
	case rtf_truncatefontheight:
		dop->copts.fTruncateFontHeight = attrValue!=0;
		break;
	case rtf_sprstsp:
		dop->copts.fSupressTopSpacing = attrValue!=0;
		break;
	case rtf_sprsspbf:								//ȡ��Ӳ��ҳ���������ǰ��Ŀո�
		break;
	case rtf_newtblstyruls:							//ʹ��word2002������ʽ
		break;
	case rtf_bdrrlswsix:
		dop->copts.fWW6BorderRules = attrValue!=0;
		break;
	case rtf_ApplyBrkRules:
		dop->copts.fApplyBreakingRules = attrValue!=0;
		break;
	case rtf_bdbfhdr:
		dop->copts.fPrintBodyBeforeHdr = attrValue!=0;
		break;
	case rtf_allowfieldendsel:
		dop->copts.fDontAllowFieldEndSelect = 0;	//Ĭ����1
		break;
	case rtf_lytprtmet:
		dop->copts.fUsePrinterMetrics = attrValue!=0;
		break;
	case rtf_lytcalctblwd:
		dop->copts.fLayoutRawTableWidth = 0;	//Ĭ����1
		break;
	case rtf_nogrowautofit:						//������������߾�-dop�޶�Ӧ��Ա
		break;
	case rtf_lyttblrtgr:						//���������зֿ�չʾ@tocheck
		dop->copts.fAlignTablesRowByRow = attrValue!=0;
		break;
	case rtf_nolnhtadjtbl:
		dop->copts.fNoAdjustLineHeightInTable = attrValue!=0;
		break;
	case rtf_snaptogridincell:
		dop->copts.fSnapToGridInCell = 0;
		break;
	case rtf_prcolbl:
		dop->copts.fMapPrintTextColor = attrValue!=0;
		break;
	case rtf_swpbdr:
		dop->copts.fSwapBordersFacingPgs = attrValue!=0;
		break;
	case rtf_brkfrm:
		dop->copts.fShowBreaksInFrames = attrValue!=0;
		break;
	case rtf_sprsbsp:
		dop->copts.fSuppressBottomSpacing = attrValue!=0;
		break;
	case rtf_cvmme:
		dop->copts.fConvMailMergeEsc = attrValue!=0;
		break;		
	case rtf_expshrtn:
		dop->copts.fDoNotExpandShiftReturn = attrValue!=0;
		break;
	case rtf_noxlattoyen:
		dop->copts.fDoNotLeaveBackslashAlone = attrValue!=0;
		break;	
	case rtf_dntblnsbdb:
		dop->copts.fBalanceSingleByteDoubleByteWidth = attrValue!=0;
		break;
	case rtf_noultrlspc:
		dop->copts.fULTrailSpace = attrValue!=0;
		break;
	case rtf_nospaceforul:
		dop->copts.fSpaceForUL = attrValue!=0;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

Group_rtf::Group_rtf() : m_fonttbl(NULL), m_stylesheet(NULL), m_upr(NULL), fClose(FALSE)
{
}


Group_rtf::~Group_rtf()
{
	RTF_DELETE_GROUP(m_fonttbl);
	RTF_DELETE_GROUP(m_stylesheet);
	RTF_DELETE_GROUP(m_upr);
}


STDMETHODIMP Group_rtf::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{	
	Group_TextStream::StartGroup(grName, grValue, fDest);
	m_doc->m_rtf = this;
	/*
	m_stylesheet = RTF_NEW_GROUP(Group_stylesheet);
	m_stylesheet->m_doc = m_doc;
	m_stylesheet->MakeNormalStyle();
	m_stylesheet->EndGroup();
	RtfStyle* style;
	style = m_doc->m_stylesheet.GetNormalStyle();
	m_doc->m_spanPrParaStyle = style->SafeGetSpanPr();
	*/
	return S_OK;
}

STDMETHODIMP Group_rtf::EndGroup()
{	
	if(fClose)
		return E_FAIL;
	fClose = TRUE;
	Group_TextStream::EndGroup();
	m_doc->Close(FALSE);
	return S_OK;
}

STDMETHODIMP Group_rtf::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	HRESULT hr = Span_AddAttribute(&m_doc->m_spanPr, m_doc, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;

	hr = Para_AddAttribute(&m_doc->m_paraPr, m_doc, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;

	hr = Section_AddAttribute(&m_doc->m_sectPr, m_doc, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;

	return Dop_AddAttribute(&m_doc->m_dop, m_doc, attrName, attrValue);
}

STDMETHODIMP Group_rtf::EnterSubGroup(
						   RtfControl grSubName,						   
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_colortbl:
		m_colortbl.m_colortbl = &m_doc->m_colortbl;
		*ppsubGroup = &m_colortbl;
		break;
	case rtf_fonttbl:
		if(m_fonttbl == NULL)
		{
			m_fonttbl = RTF_NEW_GROUP(Group_fonttbl);
			m_fonttbl->m_doc = m_doc;
		}
		*ppsubGroup = m_fonttbl;		
		break;
	case rtf_stylesheet:
		if (m_stylesheet == NULL)
		{
			m_stylesheet = RTF_NEW_GROUP(Group_stylesheet);
			m_stylesheet->m_doc = m_doc;			
		}
		*ppsubGroup = m_stylesheet;
		break;
	case rtf_listtext:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_listtable:
		m_listtable.m_doc = m_doc;
		//m_listtable.m_list.m_listlevel.m_doc = m_doc;
		*ppsubGroup = &m_listtable;
		break;
	case rtf_listoverridetable:
		m_listoverridetable.m_listoverride.m_doc = m_doc;
		*ppsubGroup = &m_listoverridetable;
		break;
	case rtf_header:	// ��������żҳ
	case rtf_headerr:	// odd header -- see New_hdrftr, bug# 17747 fix
		*ppsubGroup = New_hdrftr(DW_ODD_HEADER);
		break;
	case rtf_footer:	// ��������żҳ
	case rtf_footerr:	// odd footer
		*ppsubGroup = New_hdrftr(DW_ODD_FOOTER);
		break;
	case rtf_headerl:	// even header
		*ppsubGroup = New_hdrftr(DW_EVEN_HEADER);
		break;
	case rtf_footerl:	// even footer
		*ppsubGroup = New_hdrftr(DW_EVEN_FOOTER);
		break;
	case rtf_headerf:	// first header
		*ppsubGroup = New_hdrftr(DW_FIRST_HEADER);
		break;
	case rtf_footerf:	// first footer
		*ppsubGroup = New_hdrftr(DW_FIRST_FOOTER);
		break;
	case rtf_info:
		*ppsubGroup = &m_info;
		m_info.m_doc = m_doc;
		break;
	case rtf_nextfile:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_template:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_windowcaption:	//�������κεط�@todo
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_ftnsep:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_ftnsepc:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_ftncn:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_aftnsep:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_aftnsepc:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_aftncn:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_fchars:
		*ppsubGroup = &m_fchars;
		m_fchars.m_doc = m_doc;
		break;
	case rtf_lchars:
		*ppsubGroup = &m_lchars;
		m_lchars.m_doc = m_doc;
		break;
	case rtf_upr:
		if(m_upr == NULL)
		{
			m_upr = RTF_NEW_GROUP(Group_upr);
			m_upr->m_doc = m_doc;
		}		
		*ppsubGroup = m_upr;
		break;
	//  Indicates that there are style and formatting 
	//  usage restrictions in the document.
	case rtf_latentstyles:
		*ppsubGroup = &_group_skipped;
		break;
	//  RSID table
	case rtf_rsidtbl:
		*ppsubGroup = &_group_skipped;
		break;
	//  Word 2002 and Word 2003 allow the RTF emitter 
	//  application to stamp the document with its name,
	//  version, and build number. 
	case rtf_generator:
		*ppsubGroup = &_group_skipped;
		break;
	//  ��ʱ���б�
	case rtf_pnseclvl:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_userprops:
		*ppsubGroup = &_group_skipped;
		break;
	//  ����
	case rtf_background:		
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_revtbl:		
		*ppsubGroup = &m_revtbl;
		m_revtbl.m_doc = m_doc;
		break;
	default:		
		return Group_TextStream::EnterSubGroup(grSubName, fDest1987, ppsubGroup);			
	}
	return S_OK;
}
// -------------------------------------------------------------------------
//	$Log: group_rtf.cpp,v $
//	Revision 1.55  2006/10/26 01:01:09  wangdong
//	����ʧ�ܡ�
//	
//	Revision 1.54  2006/09/21 06:29:05  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.53  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.52  2006/06/06 01:53:28  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.51  2006/04/18 05:42:56  xulingjiao
//	�޸�25796��BUG
//	
//	Revision 1.50  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.49  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.48  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	