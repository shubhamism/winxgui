/* -------------------------------------------------------------------------
//	�ļ���		��	group_upr.cpp
//	������		��	���὿
//	����ʱ��	��	2006-3-21 16:16:07
//	��������	��	
//
//	$Id: group_upr.cpp,v 1.1 2006/03/23 09:41:25 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_stylesheet.h"
#include "group_fchars.h"
#include "group_upr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Group_upr::~Group_upr()
{
	RTF_DELETE_GROUP(m_stylesheet);
	RTF_DELETE_GROUP(m_fchars);
	RTF_DELETE_GROUP(m_lchars);
}


STDMETHODIMP Group_upr::EnterSubGroup(
		IN RtfControl grSubName,		
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_fchars:
		if(m_fchars == NULL)
		{
			m_fchars = RTF_NEW_GROUP(Group_fchars);
			m_fchars->m_doc = m_doc;
		}
		*ppsubGroup = m_fchars;
		break;
	case rtf_lchars:
		if(m_lchars == NULL)
		{
			m_lchars = RTF_NEW_GROUP(Group_lchars);
			m_lchars->m_doc = m_doc;
		}
		*ppsubGroup = m_lchars;
		break;
	case rtf_ud:
		*ppsubGroup = &m_ud;
		m_ud.m_doc = m_doc;
		break;
	case rtf_stylesheet:
		if (m_stylesheet == NULL)
		{
			m_stylesheet = RTF_NEW_GROUP(Group_stylesheet);
			m_stylesheet->m_doc = m_doc;			
		}
		*ppsubGroup = m_stylesheet;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}
// -------------------------------------------------------------------------
//	$Log: group_upr.cpp,v $
//	Revision 1.1  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	
