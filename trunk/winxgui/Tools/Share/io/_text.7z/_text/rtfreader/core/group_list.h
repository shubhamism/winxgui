/* -------------------------------------------------------------------------
//	�ļ���		��	group_list.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-4 14:29:16
//	��������	��	
//
//	$Id: group_list.h,v 1.28 2006/08/09 04:29:34 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_LIST_H__
#define __GROUP_LIST_H__

#ifndef __GROUP_LISTPICTURE_H__
#include "group_listpicture.h"
#endif

typedef KDWListLevel RtfListLevel;
typedef KDWList RtfList;
typedef KDWListFormatOverride RtfListOverride;

typedef Group_Skipped Group_listtext;
class Group_bullet_uc : public Group_Base
{
private:	
	INT  m_fDest, m_cIgnore;
public:
	ks_wstring* m_unicodes;
	STDMETHODIMP Init(ks_wstring* unicodes)
	{
		m_unicodes = unicodes;
		return S_OK;
	}
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
	{
		m_fDest = fDest;
		if(grValue != rtf_nilParam)
			m_cIgnore = 1;
		else
			m_cIgnore = grValue;
		return S_OK;
	}

	STDMETHODIMP AddContent(
		IN LPCWSTR pContent,
		IN int cch)
	{
		m_unicodes->append(pContent, cch);
		return S_OK;
	}
};

class Group_leveltext : public Group_Base
{
public:
	RtfListLevel* m_level;
	RtfDocument* m_doc;
	ks_wstring m_leveltext;
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);	

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);
	
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);	

	STDMETHODIMP EndGroup();
private:
	RtfGrpObject<Group_bullet_uc> m_bullet;
};

// -------------------------------------------------------------------------
// class Group_levelnumbers

class Group_levelnumbers : public Group_Base
{
	RtfListLevel* m_level;	
public:	
	RtfDocument* m_doc;
	STDMETHODIMP_(void) Init(RtfListLevel* level)
	{		
		m_level = level;		
	}
	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);	
};

// -------------------------------------------------------------------------
// class Group_listlevel

class Group_listlevel : public Group_Base
{
private:
	RtfGrpObject<Group_leveltext> m_leveltext;
	RtfGrpObject<Group_levelnumbers> m_levelnumbers;
	KDWPropBuffer m_papx;
	RtfSpanPr m_spanpr;
	KDWTab tab;
public:
	RtfListLevel m_level;	
	RtfDocument* m_doc;
	
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);

	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// Group_listname
class Group_listname : public Group_Base
{
public:
	RtfDocument* m_doc;
	RtfList* m_list;	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);	
};

// -------------------------------------------------------------------------
// class Group_list

class Group_list : public Group_Base
{
private:
	UINT m_iLevel;

	UINT m_listid;
	RtfList m_list;

public:
	RtfDocument* m_doc;
	RtfGrpObject<Group_listname> m_listname;
	RtfGrpObject<Group_listlevel> m_listlevel;
	
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
		
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);

	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// class Group_listtable

class Group_listtable : public Group_Base
{
public:
	RtfDocument* m_doc;
	RtfGrpObject<Group_list> m_list;
	RtfGrpObject<Group_listpicture> m_listpicture;	
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup)
	{
		switch (grSubName)
		{
		case rtf_list:
			*ppsubGroup = &m_list;
			m_list.m_doc = m_doc;
			break;
		case rtf_listpicture:
			m_listpicture.m_pict.m_doc = m_doc;
			*ppsubGroup = &m_listpicture;
			break;
		default:
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};
// -------------------------------------------------------------------------
// class Group_lfolevel
class Group_lfolevel : public Group_Base
{	
public:
	RtfDocument* m_doc;
	RtfGrpObject<Group_listlevel> m_listlevel;
	STDMETHODIMP AddAttribute(
		IN RtfControl attrName,
		IN int attrValue);

	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);	
};
// -------------------------------------------------------------------------
// class Group_listoverride
class Group_listoverride : public Group_Base
{
private:
	UINT m_ilfo, m_iLfoLevel, m_cOveride;
	RtfListOverride m_listoverride;
	RtfGrpObject<Group_lfolevel> m_lfolevel;

public:
	RtfDocument* m_doc;
	
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);

	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);	

	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// class Group_listoverridetable

class Group_listoverridetable : public Group_Base
{
public:
	RtfGrpObject<Group_listoverride> m_listoverride;

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup)
	{
		switch (grSubName)
		{
		case rtf_listoverride:
			*ppsubGroup = &m_listoverride;
			break;
		default:
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: group_list.h,v $
//	Revision 1.28  2006/08/09 04:29:34  xulingjiao
//	#28604
//	
//	Revision 1.27  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.26  2006/03/07 08:35:54  xulingjiao
//	�޸��Ʊ�λ��BUG
//	
//	Revision 1.25  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.24  2006/03/01 06:02:57  xulingjiao
//	������listoverride��.
//	
//	Revision 1.23  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	
#endif /* __GROUP_LIST_H__ */
