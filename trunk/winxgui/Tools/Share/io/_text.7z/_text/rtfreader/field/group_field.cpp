/* -------------------------------------------------------------------------
//	�ļ���		��	group_field.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 14:44:57
//	��������	��	
//
//	$Id: group_field.cpp,v 1.24 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_field.h"
#include <mso/filefmt/word/field/fieldinstr.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Group_fldinst

STDMETHODIMP Group_fldinst::EndGroup()
{
	Group_TextStream::EndGroup();
	
	enum { CCH_INSTR_MAX = 31 };
	
	char szInstr[CCH_INSTR_MAX+1];
	
	const KDWTextPool& textpool = m_doc->GetCurSubdoc()->TextPool();
	
	UINT cpMax = textpool.size();
	while (m_cpFldinst < cpMax)
	{
		if ( !isspace(textpool[m_cpFldinst]) )
			break;
		++m_cpFldinst;
	}
	
	UINT cchMax = cpMax - m_cpFldinst;
	if (cchMax > CCH_INSTR_MAX)
		cchMax = CCH_INSTR_MAX;	
	UINT i;
	for (i = 0; i < cchMax; ++i)
	{
		WCHAR ch = textpool[m_cpFldinst+i];
		if ( !(isalpha(ch) && ch != '=') )
			break;
		szInstr[i] = (char)toupper(ch);
	}
	szInstr[i] = '\0';
	m_cpFldinst += i;
	
	static const FieldInstrToIdMap& _s_map = GetFieldInstrToIdMap();
	
	FieldInstrToIdMap::const_iterator itFind = _s_map.find(szInstr);
	const FLT flt = (itFind != _s_map.end() ? (*itFind).second : mso_fltBookmark);
	
	TRACEA("type %s ----------------------------\n", szInstr);
	return m_doc->SetCurrentFieldType(flt);
}

// ---------------------------------
// @@feature: includepicture


STDMETHODIMP Group_fldinst::IncludePicture(
										 IN OUT RtfShapeOPT& opt)
{
	const KDWTextPool& textpool = m_doc->GetCurSubdoc()->TextPool();
	
	RtfToken<KDWTextPool::const_iterator>
		token(textpool.begin() + m_cpFldinst, textpool.end());

	if (token.skip_until('"'))
	{
		KDWTextPool::const_iterator from = ++token.first;
		if (token.skip_until('"'))
		{
			const UINT length = token.first - from;
			const UINT bytes = sizeof(WCHAR) * (length + 1);
			WCHAR* path = (WCHAR*)_alloca(bytes);
			std::copy(from, token.first, path);
			path[length] = '\0';
			opt.m_opt[0].RemoveBlipProp(msopt_pib, m_doc->GetBlipStore());
			opt.m_opt[0].AddPropFix(msopt_pibFlags, 6|msoblipflagLinkToFile);
			opt.m_opt[0].AddPropVar(msopt_pibName, path, bytes, 1);
		}
	}

	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_fldrslt

STDMETHODIMP Group_fldrslt::StartGroup(
									   RtfControl grName,
									   int grValue,
									   int& fDest)
{
	TRACEA("-- sep ----------------------------\n");
	m_doc->MarkFieldSeparator();	
	return Group_TextStream::StartGroup(grName, grValue, fDest);
}

STDMETHODIMP Group_fldrslt::AddAttribute(
		RtfControl attrName,
		int attrValue)
{
	switch(attrName)
	{
	case rtf_f:
		m_ifont = attrValue;
		break;	
	}
	return Group_TextStream::AddAttribute(attrName, attrValue);
}
// -------------------------------------------------------------------------
// class Group_field

STDMETHODIMP_(RtfIncludePicture*) Group_field::GetIncludePicture()
{
	if (m_doc->GetCurrentFieldType() == mso_fltIncludePicture)
		return this;
	else
		return NULL;
}

STDMETHODIMP Group_field::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_fldinst:
		m_fldinst.m_doc = m_doc;
		*ppsubGroup = &m_fldinst;
		break;
	case rtf_fldrslt:
		m_fldrslt.m_doc = m_doc;
		*ppsubGroup = &m_fldrslt;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_field::EndGroup()
{
	FLT flt = m_doc->GetCurrentFieldType();
	TRACEA(">> end ----------------------------\n");
	HRESULT hr = m_doc->MarkFieldEnd();
	/** bug# 17313
	������
		����ճ������word�������ݣ�ճ������������ֵķ����޷����ơ�
	������
		��rtf�ļ��а�����symbol�򡣶�word/wps������Ϊsymbol����
	������
		1������KDWDocument::EraseFrom(UINT cpFrom)ɾ�����ɵ���
		2�������Symbol��
	*/
	if (flt == mso_fltSymbol)
	{
		// ---> start: ȡ��xch -- by xulingjiao
		const KDWTextPool& textpool = m_doc->GetCurSubdoc()->TextPool();
		
		UINT cpMax = textpool.size();
		UINT cpFldinst = m_fldinst.m_cpFldinst;

		while (cpFldinst < cpMax)
		{
			if ( isdigit(textpool[cpFldinst]) )
				break;
			++cpFldinst;
		}
		
		UINT16 xch = 0;
		while (cpFldinst < cpMax)
		{
			WCHAR wch = textpool[cpFldinst];
			if ( !isdigit(wch) )
				break;
			xch = xch * 10 + (wch - '0');
			++cpFldinst;
		}
		// ---> end

		m_doc->EraseFrom(m_fldinst.m_cpFldinstStart-1);
		
		RtfSpanPr* spanPr = &(m_doc->m_spanPr);
		RtfSpanPr::MaskType* mask = &spanPr->mask;
		spanPr->symbol.oprand.ftcSym = m_doc->GetFontId(m_fldrslt.m_ifont);
		spanPr->symbol.oprand.xchSym = xch;
		_MemSetInt(mask->symbol);
		spanPr->fIsDirty = TRUE;
		m_doc->AddContent(0x28);
	}
	Group_TextStream::EndGroup();
	return hr;
}
