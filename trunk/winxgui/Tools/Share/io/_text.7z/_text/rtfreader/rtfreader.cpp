/* -------------------------------------------------------------------------
//	�ļ���		��	rtfreader.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 9:49:25
//	��������	��	
//
//	$Id: rtfreader.cpp,v 1.30 2006/09/21 10:14:57 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#include "rtfreader.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

BOOL APIENTRY DllMain(
					  HANDLE hModule, 
					  DWORD  ul_reason_for_call, 
					  LPVOID lpReserved
					  )
{
	//SetBreakAlloc(1407);
    return TRUE;
}

// -------------------------------------------------------------------------

#if defined(_DEBUG)

typedef 
STDMETHODIMP _wpio_FnCreateDocument(
									IN KDWDocument& data,
									OUT interface WpioDocument** ppDoc
									);

interface IRtfLoader
{
	virtual HRESULT __stdcall release() = 0;
	virtual HRESULT __stdcall load(IN LPCWSTR rtfFile, OUT WpioDocument** ppDoc) = 0;
};

STDAPI _rtfdbg_GetLoader(OUT IRtfLoader** ppLoader);

class CRtfLoader : public IRtfLoader
{
private:
	Rtf2DocHandler m_handler;

	static STDMETHODIMP_(_wpio_FnCreateDocument*) _fn_ptr()
	{
		HMODULE hLib = LoadLibraryA("wpioapi");
		if (hLib == NULL)
			return NULL;
		return (_wpio_FnCreateDocument*)GetProcAddress(hLib, "_wpio_CreateDocument");
	}

public:
	CRtfLoader(IStorage* pStg) : m_handler(pStg)
	{
	}

	STDMETHODIMP release()
	{
		delete this;
		return S_OK;
	}

	STDMETHODIMP load(IN LPCWSTR rtfFile, OUT WpioDocument** ppDoc)
	{
		KRtfSimpleParser<Rtf2DocHandler> parser(rtfFile);
		HRESULT hr = parser.Parse(&m_handler);
		ASSERT_OK(hr);
	
		static _wpio_FnCreateDocument* fnCreateDocument = _fn_ptr();
		if (fnCreateDocument == NULL)
			return E_FAIL;

		return fnCreateDocument(m_handler.Data(), ppDoc);
	}
};

EXPORTAPI _rtfdbg_GetLoader(OUT IRtfLoader** ppLoader)
{
	ILockBytes* plkbyt = NULL;
	
	HRESULT hr = _CreateILockBytesOnHGlobal(
		NULL,
		TRUE,
		&plkbyt);
	
	if (FAILED(hr))
		return hr;

	IStorage* pdest = NULL;

	hr = StgCreateDocfileOnILockBytes(
		plkbyt,
		STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE,
		0,
		&pdest);

	if (SUCCEEDED(hr))
	{
		*ppLoader = new CRtfLoader(pdest);
		hr = S_OK;
		pdest->Release();
	}

	plkbyt->Release();
	return hr;
}

#else

interface IRtfLoader
{
};

EXPORTAPI _rtfdbg_GetLoader(OUT IRtfLoader** ppLoader)
{
	return E_NOTIMPL;
}

#endif

// -------------------------------------------------------------------------

EXPORTAPI rtfExportEx(IN LPCWSTR rtfFile, IN IStorage* pDocStg)
{		
	Rtf2DocHandler* handler = new Rtf2DocHandler(pDocStg);
	KRtfSimpleParser<Rtf2DocHandler> parser(rtfFile);	
	HRESULT hr = parser.Parse(handler);
	ASSERT_OK(hr);
	delete handler;	
	return hr;
}

EXPORTAPI rtfExport(IN IStream* pRtfStrm, IN IStorage* pDocStg)
{	
	Rtf2DocHandler* handler = new Rtf2DocHandler(pDocStg);
	KRtfSimpleParser<Rtf2DocHandler> parser(pRtfStrm);	
	HRESULT hr = parser.Parse(handler);
	ASSERT_OK(hr);
	delete handler;	
	return hr;
}

EXPORTAPI rtfConvert(IN LPCWSTR rtfFile, IN LPCWSTR docFile)
{
	ks_stdptr<IStorage> spRootStg;	
	HRESULT hr = StgCreateDocfile(
		docFile, STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE, 0, &spRootStg);
	ASSERT_OK(hr);

	if (FAILED(hr))
		return hr;
	
	return rtfExportEx(rtfFile, spRootStg);
}
// -------------------------------------------------------------------------
//	$Log: rtfreader.cpp,v $
//	Revision 1.30  2006/09/21 10:14:57  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.29  2006/07/27 02:39:51  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.28  2006/07/19 08:55:03  xulingjiao
//	�޸�html2rtf���ļ�ͼƬ��ʧ��BUG
//	
//	Revision 1.27  2006/07/04 01:17:00  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.26  2006/06/06 01:53:28  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.25  2006/03/06 01:39:49  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.24  2006/01/11 02:47:46  rongjianxing
//	wpio�ӵ������С�
//	
//	Revision 1.23  2005/11/15 02:27:48  zhuyie
//	Release���벻����
//	
//	Revision 1.22  2005/11/14 03:42:35  xushiwei
//	����_rtfdbg_GetLoader
//	
//	Revision 1.21  2005/04/26 09:20:23  xushiwei
//	��bug
//	
//	Revision 1.20  2005/02/24 02:26:24  xushiwei
//	��rtfparser�ƶ���<mso/io/rtf/parser>Ŀ¼�£���Ϊ���������
//	������ֻ��Ҫ����: <mso/io/rtf/parser.h>���ɡ�
//	
//	Revision 1.19  2005/01/22 10:11:59  xushiwei
//	��֧��html�ļ���ʽ��
//	
//	Revision 1.16  2004/12/23 08:25:30  xushiwei
//	��������صĴ������̡�
//	
