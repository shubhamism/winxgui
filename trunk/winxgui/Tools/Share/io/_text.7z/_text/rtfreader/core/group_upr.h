/* -------------------------------------------------------------------------
//	�ļ���		��	group_upr.h
//	������		��	���὿
//	����ʱ��	��	2006-3-21 16:14:21
//	��������	��	
//
//	$Id: group_upr.h,v 1.1 2006/03/23 09:41:25 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_UPR_H__
#define __GROUP_UPR_H__
#include "group_ud.h"

class Group_stylesheet;
class Group_fchars;
class Group_lchars;
class RtfDocument;
class Group_upr : public Group_Base
{
	Group_stylesheet* m_stylesheet;
	RtfGrpObject<Group_ud> m_ud;
	Group_fchars* m_fchars;
	Group_lchars* m_lchars;
	
public:	
	RtfDocument* m_doc;	

	Group_upr() : m_stylesheet(NULL), m_fchars(NULL), m_lchars(NULL)
	{
	}

	~Group_upr();

	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);	
};
// -------------------------------------------------------------------------
//	$Log: group_upr.h,v $
//	Revision 1.1  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	

#endif /* __GROUP_UPR_H__ */
