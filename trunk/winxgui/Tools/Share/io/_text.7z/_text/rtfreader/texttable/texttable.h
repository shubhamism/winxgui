/* -------------------------------------------------------------------------
//	�ļ���		��	texttable.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-29 9:33:39
//	��������	��	
//
//	$Id: texttable.h,v 1.7 2006/06/05 06:47:00 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXTTABLE_H__
#define __TEXTTABLE_H__
#include "../core/group_textstream.h"
// -------------------------------------------------------------------------
// class Group_nesttableprops
class Group_nesttableprops : public Group_TextStream
{
public:	
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);
};

// -------------------------------------------------------------------------

typedef RtfDocument RtfTableRowContent;

//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP TableRow_AddAttribute(
							   RtfTableRowPr& trowPr,
							   RtfTablePos& tblPos,
							   RtfTableRowContent* context,
							   RtfControl attrName,
							   int attrValue);

// -------------------------------------------------------------------------
//	$Log: texttable.h,v $
//	Revision 1.7  2006/06/05 06:47:00  xulingjiao
//	�޸������BUG
//	
//	Revision 1.6  2006/03/21 04:22:53  xulingjiao
//	�޸��û�������BUG
//	
//	Revision 1.5  2006/02/27 08:19:55  xulingjiao
//	rtfreader����mask
//	
#endif /* __TEXTTABLE_H__ */
