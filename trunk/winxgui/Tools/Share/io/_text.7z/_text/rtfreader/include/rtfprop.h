/* -------------------------------------------------------------------------
//	�ļ���		��	rtfprop.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-13 15:03:20
//	��������	��	
//
//	$Id: rtfprop.h,v 1.97 2006/07/08 02:16:46 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFPROP_H__
#define __RTFPROP_H__
#include "mso/propstruct/maskparapr.h"
#include "mso/propstruct/maskspanpr.h"
#include "mso/propstruct/sectpr.h"
#include "mso/propstruct/doppr.h"
#include "prop_base.h"

typedef MaskSpanPr RtfSpanPr;
typedef MaskParaPr RtfParaPr;
typedef SectionPr RtfSectionPr;
typedef DopPr RtfDop;

#define rtf_ftcFastEast mso_ftcFastEast
#define rtf_ftcAscii mso_ftcAscii
#define rtf_ftcOther mso_ftcOther
#define rtf_lidAscii mso_lidAscii
#define rtf_lidFastEast mso_lidFastEast

#define AddPropFixWhatEver(propbuf, sprm, mem)\
{\
	propbuf.AddPropFix(sprm, mem);\
}

#define AddPropFixNotDefval(propbuf, sprm, mem, defval)\
{\
	if(mem != defval)\
		propbuf.AddPropFix(sprm, mem);\
}

#define _AddPropFix(propbuf, sprm, maskmem, mem, basemem)\
{\
	if(mem != basemem)\
		propbuf.AddPropFix(sprm, mem);\
}

#define _AddPropFixMask(propbuf, sprm, maskmem, mem, basemem)\
{\
	if(maskmem)\
	{\
		if(mem != basemem)\
			propbuf.AddPropFix(sprm, mem);\
	}\
}
#define USE_MASK
#ifdef USE_MASK
#define AddPropFixMask _AddPropFixMask
#else
#define AddPropFixMask _AddPropFix
#endif

#define AddPropFixMaskNotDefval(propbuf, sprm, maskmem, mem, basemem, defval)\
{\
	if(maskmem)\
	{\
		if(mem != basemem && mem != defval)\
			propbuf.AddPropFix(sprm, mem);\
	}\
}

#define _AddPropBool(propbuf, sprm, maskmem, mem, basemem)\
{\
	if(mem != basemem)\
		propbuf.AddPropFix(sprm, 0x81);\
}

#define _AddPropBoolMask(propbuf, sprm, maskmem, mem, basemem)\
{\
	if(maskmem)\
	{\
		if(mem != basemem)\
		{\
			if(mem != 0)\
				propbuf.AddPropFix(sprm, 0x81);\
			else\
				propbuf.AddPropFix(sprm, 0);\
		}\
	}\
}

#ifdef USE_MASK
#define AddPropBoolMask _AddPropBoolMask
#else
#define AddPropBoolMask _AddPropBool
#endif

#define _AddBrc(propbuf, sprmBrc, maskmem, brc, basebrc)\
{\
	if(brc != basebrc)\
		propbuf.AddPropFix(sprmBrc, (const UINT32&)brc.get_Brc());\
}

#define _AddBrcMask(propbuf, sprmBrc, maskmem, brc, basebrc)\
{\
	if(maskmem)\
	{\
		if(brc != basebrc)\
			propbuf.AddPropFix(sprmBrc, (const UINT32&)brc.get_Brc());\
	}\
}

#ifdef USE_MASK
#define AddBrcMask _AddBrcMask
#else
#define AddBrcMask _AddBrc
#endif

#define _AddBrcEx(propbuf, sprmBrcEx, maskmem, brcEx, basebrcEx)\
{\
	if(brcEx != basebrcEx)\
		propbuf.AddPropVar(sprmBrcEx, &brcEx, sizeof(BRCEX));\
}

#define _AddBrcExMask(propbuf, sprmBrcEx, maskmem, brcEx, basebrcEx)\
{\
	if(maskmem)\
	{\
		if(brcEx != basebrcEx)\
			propbuf.AddPropVar(sprmBrcEx, &brcEx, sizeof(BRCEX));\
	}\
}

#ifdef USE_MASK
#define AddBrcExMask _AddBrcExMask
#else
#define AddBrcExMask _AddBrcEx
#endif

#define _AddShd(propbuf, sprmShd, maskmem, shd, baseshd)\
{\
	if(shd != baseshd)\
		propbuf.AddPropFix(sprmShd, (const UINT16&)shd.get_Shd());\
}

#define _AddShdMask(propbuf, sprmShd, maskmem, shd, baseshd)\
{\
	if(maskmem)\
	{\
		if(shd != baseshd)\
			propbuf.AddPropFix(sprmShd, (const UINT16&)shd.get_Shd());\
	}\
}

#ifdef USE_MASK
#define AddShdMask _AddShdMask
#else
#define AddShdMask _AddShd
#endif

#define _AddShdEx(propbuf, sprmShdEx, maskmem, shdEx, baseshdEx)\
{\
	if(maskmem)\
	{\
		if(shdEx != baseshdEx)\
			propbuf.AddPropVar(sprmShdEx, &shdEx, sizeof(SHDEX));\
	}\
}

#define _AddShdExMask(propbuf, sprmShdEx, maskmem, shdEx, baseshdEx)\
{\
	if(maskmem)\
	{\
		if(shdEx != baseshdEx)\
			propbuf.AddPropVar(sprmShdEx, &shdEx, sizeof(SHDEX));\
	}\
}

#ifdef USE_MASK
#define AddShdExMask _AddShdExMask
#else
#define AddShdExMask _AddShdEx
#endif

class RtfDocument;

typedef RtfDocument RtfSectionContext;

//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP SectionBase_AddAttribute(
								   RtfSectionPr* sectPr,
								   RtfSectionContext* context,
								   RtfControl attrName,
								   int attrValue);

//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP Section_AddAttribute(
							   RtfSectionPr* sectPr,
							   RtfSectionContext* context,
							   RtfControl attrName,
							   int attrValue);

typedef const RtfDocument RtfAttrBaseContext;
STDMETHODIMP Brc_AddAttribute(
							  KDWBrc& brc,
							  RtfAttrBaseContext* context,
							  RtfControl attrName,
							  int attrValue);

typedef RtfDocument RtfSpanContext;
STDMETHODIMP AddPlain(RtfSpanPr* prop);
//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP SpanBase_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue);

//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP Span_AddAttribute(
							   RtfSpanPr* spanPr,
							   RtfSpanContext* context,
							   RtfControl attrName,
							   int attrValue);

typedef RtfDocument RtfParaContext;
void AddPard(RtfParaPr* prop);
//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP ParaBase_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue);

//
//δ�����򷵻�E_UNEXPECTED
//
STDMETHODIMP Para_AddAttribute(
							   RtfParaPr* paraPr,
							   RtfParaContext* context,
							   RtfControl attrName,
							   int attrValue);
STDMETHODIMP GetListPap(RtfParaPr* listPapx, const RtfParaPr* pap, RtfDocument* doc);
STDMETHODIMP ConvertPapx(KDWPropBuffer& propx, RtfParaPr* pap, const RtfParaPr* baseOn, const RtfParaPr* listBaseOn = NULL);
STDMETHODIMP ConvertPapx(KDWPropBuffer& propx, RtfParaPr* pap, RtfDocument* doc);
STDMETHODIMP ConvertChpx(KDWPropBuffer& propx, RtfSpanPr* chp, const RtfSpanPr* baseOnChp);
STDMETHODIMP ConvertChpx(KDWPropBuffer& chpx, RtfSpanPr* chp, RtfDocument* doc);
STDMETHODIMP ConvertSepx(KDWPropBuffer& propx, RtfSectionPr* sec);
// -------------------------------------------------------------------------
#endif /* __RTFPROP_H__ */
