/* -------------------------------------------------------------------------
//	�ļ���		��	testtextbox.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-12 12:31:51
//	��������	��	
//
//	$Id: testtextbox.cpp,v 1.2 2005/05/11 10:07:52 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestTextBox : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestTextBox);
		CPPUNIT_TEST(testBasic);
		CPPUNIT_TEST(testLinkBox);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testBasic()
	{
		testRtf2DocFile("draw/textbox/simple.rtf", "textbox_simple.doc");		
	}
	void testLinkBox()
	{		
		testRtf2DocFile("draw/textbox/linktextbox.rtf", "textbox_linktextbox.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestTextBox);

// -------------------------------------------------------------------------
//	$Log: testtextbox.cpp,v $
//	Revision 1.2  2005/05/11 10:07:52  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2005/01/12 05:03:03  xushiwei
//	���Ӽ��ı�������
//	
