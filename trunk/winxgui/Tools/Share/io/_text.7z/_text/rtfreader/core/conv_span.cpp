/* -------------------------------------------------------------------------
//	�ļ���		��	conv_span.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-13 17:30:42
//	��������	��	
//
//	$Id: conv_span.cpp,v 1.58 2006/09/20 10:18:38 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#if (0)
#define RTF_NO_CHPX
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP ConvertChpx(KDWPropBuffer& propx, RtfSpanPr* chp, const RtfSpanPr* baseOnChp)
{	
	RtfSpanPr::MaskType* mask = &chp->mask;
	if(!mask->fId)
		chp->idctHint = 0;
	if(chp->fSpec)
		propx.AddPropFix(sprmCFSpec, 1);
	propx.AddPropFix(sprmCIdctHint, chp->idctHint);
	AddPropFixMask(	propx, sprmCRgLid0, mask->rglid[rtf_lidAscii], 
					chp->rglid[rtf_lidAscii], baseOnChp->rglid[rtf_lidAscii]);
	AddPropFixMask(	propx, sprmCRgLid0Ex, mask->rglid[rtf_lidAscii], 
					chp->rglid[rtf_lidAscii], baseOnChp->rglid[rtf_lidAscii]);
	AddPropFixMask(	propx, sprmCRgLid1, mask->rglid[rtf_lidFastEast],
					chp->rglid[rtf_lidFastEast], baseOnChp->rglid[rtf_lidFastEast]);
	AddPropFixMask(	propx, sprmCRgLid1Ex, mask->rglid[rtf_lidFastEast],
					chp->rglid[rtf_lidFastEast], baseOnChp->rglid[rtf_lidFastEast]);
	AddPropFixMask(	propx, sprmCRgFtc0, mask->rgftc[rtf_ftcAscii],
					chp->rgftc[rtf_ftcAscii], baseOnChp->rgftc[rtf_ftcAscii]);
	AddPropFixMask(	propx, sprmCRgFtc1, mask->rgftc[rtf_ftcFastEast],
					chp->rgftc[rtf_ftcFastEast], baseOnChp->rgftc[rtf_ftcFastEast]);
	AddPropFixMask(	propx, sprmCRgFtc2, mask->rgftc[rtf_ftcOther],
					chp->rgftc[rtf_ftcOther], baseOnChp->rgftc[rtf_ftcOther]);
	AddPropFixMask(	propx, sprmCSymbol, mask->symbol, chp->symbol.opval, baseOnChp->symbol.opval);
	INT icoChp = MatchRGB2Ico(chp->crTextColor);
	INT icoBaseChp = MatchRGB2Ico(baseOnChp->crTextColor);
	AddPropFixMask(	propx, sprmCIco, mask->crTextColor, icoChp, icoBaseChp);
	AddPropFixMask( propx, sprmCTextColor, mask->crTextColor,
					chp->crTextColor, baseOnChp->crTextColor);
	AddPropFixMask(	propx, sprmCKul, mask->kul, chp->kul, baseOnChp->kul);
	AddPropFixMask(	propx, sprmCKulColor, mask->crKulColor, chp->crKulColor, baseOnChp->crKulColor);
	AddPropFixMask(	propx, sprmCIss, mask->iss, chp->iss, baseOnChp->iss);
	AddPropFixMask(	propx, sprmCHps, mask->hps, chp->hps, baseOnChp->hps);
	AddPropFixMask(	propx, sprmCKcd, mask->kcd, chp->kcd, baseOnChp->kcd);
	AddPropFixMask(	propx, sprmCHpsPos, mask->hpsPos, chp->hpsPos, baseOnChp->hpsPos);
	AddPropFixMask(	propx, sprmCDxaSpace, mask->dxaSpace, chp->dxaSpace, baseOnChp->dxaSpace);
	AddPropFixMask(	propx, sprmCCharScale, mask->wCharScale, chp->wCharScale, baseOnChp->wCharScale);
	AddPropFixMask(	propx, sprmCHpsKern, mask->hpsKern, chp->hpsKern, baseOnChp->hpsKern);
	AddPropFixMask(	propx, sprmCFUsePgsuSettings, mask->fcgrid, chp->fcgrid, baseOnChp->fcgrid);
	AddPropFixMask(	propx, sprmCSfxText, mask->sfxtText, chp->sfxtText, baseOnChp->sfxtText);
	AddPropFixMask(	propx, sprmCHighlight, mask->icoHighlight, chp->icoHighlight, baseOnChp->icoHighlight);
	AddPropBoolMask( propx, sprmCFItalic, mask->fItalic, chp->fItalic, baseOnChp->fItalic);
	AddPropBoolMask( propx, sprmCFBold, mask->fBold, chp->fBold, baseOnChp->fBold);
	AddPropBoolMask( propx, sprmCFOutline, mask->fOutline, chp->fOutline, baseOnChp->fOutline);
	AddPropBoolMask( propx, sprmCFSmallCaps, mask->fSmallCaps, chp->fSmallCaps, baseOnChp->fSmallCaps);
	AddPropBoolMask( propx, sprmCFCaps, mask->fCaps, chp->fCaps, baseOnChp->fCaps);
	AddPropBoolMask( propx, sprmCFVanish, mask->fVanish, chp->fVanish, baseOnChp->fVanish);
	AddPropBoolMask( propx, sprmCFStrike, mask->fStrike, chp->fStrike, baseOnChp->fStrike);
	AddPropBoolMask( propx, sprmCFDStrike, mask->fDStrike, chp->fDStrike, baseOnChp->fDStrike);
	AddPropBoolMask( propx, sprmCFShadow, mask->fShadow, chp->fShadow, baseOnChp->fShadow);
	AddPropBoolMask( propx, sprmCFEmboss, mask->fEmboss, chp->fEmboss, baseOnChp->fEmboss);
	AddPropBoolMask( propx, sprmCFImprint, mask->fImprint, chp->fImprint, baseOnChp->fImprint);
	AddBrcMask( propx, sprmCBrc, mask->brc, chp->brc, baseOnChp->brc);
	AddBrcExMask( propx, sprmCBrcEx, mask->brc, chp->brc, baseOnChp->brc);
	AddShdMask( propx, sprmCShd, mask->shd, chp->shd, baseOnChp->shd);
	AddShdExMask( propx, sprmCShdEx, mask->shd, chp->shd, baseOnChp->shd);

	//�޶����
	AddPropBoolMask( propx, sprmCFRMark, mask->fRMark, chp->fRMark, baseOnChp->fRMark);
	AddPropFixMask( propx, sprmCIbstRMark, mask->ibstRMark, chp->ibstRMark, baseOnChp->ibstRMark);
	AddPropFixMask( propx, sprmCDttmRMark, mask->dttmRMark, (INT32&)chp->dttmRMark, (INT32&)baseOnChp->dttmRMark);
	AddPropBoolMask( propx, sprmCFRMarkDel, mask->fRMarkDel, chp->fRMarkDel, baseOnChp->fRMarkDel);
	AddPropFixMask( propx, sprmCIbstRMarkDel, mask->ibstRMarkDel, chp->ibstRMarkDel, baseOnChp->ibstRMarkDel);
	AddPropFixMask( propx, sprmCDttmRMarkDel, mask->dttmRMarkDel, (INT32&)chp->dttmRMarkDel, (INT32&)baseOnChp->dttmRMarkDel);
	return S_OK;
}

STDMETHODIMP ConvertChpx(KDWPropBuffer& chpx, RtfSpanPr* chp, RtfDocument* doc)
{
	RtfSpanPr baseOn = doc->m_spanPrParaStyle;
	if (chp->istd != stiNil)
	{
		RtfStyle* style = doc->m_stylesheet.GetStyle(chp->istd);
		MsoKernData* attrs = style->GetCharStyleAttributes();
		if (attrs != NULL)
		{
			chpx.AddPropFix(sprmCIstd, style->m_styleIdByWord);
			const RtfAttribute* attr = (const RtfAttribute*)_MsoPdata(attrs);
			const RtfAttribute* attrEnd = attr + (attrs->cb / sizeof(RtfAttribute));
			while (attr != attrEnd)
			{
				SpanBase_AddAttribute(&baseOn, doc, attr->prop, attr->value);
				++attr;
			}
		}
	}
	AddPlain(chp);
	return ConvertChpx(chpx, chp, &baseOn);	
}
