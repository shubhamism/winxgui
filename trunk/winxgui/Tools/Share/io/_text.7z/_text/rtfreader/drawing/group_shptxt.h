/* -------------------------------------------------------------------------
//	�ļ���		��	group_shptxt.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-12 11:53:38
//	��������	��	
//
//	$Id: group_shptxt.h,v 1.4 2006/09/11 08:00:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_SHPTXT_H__
#define __GROUP_SHPTXT_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include "../core/group_textstream.h"
#endif

// -------------------------------------------------------------------------
// Group_shptxt

class Group_shptxt : public Group_TextStream
{
public:
	KDWShape* m_shape;

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	
	STDMETHODIMP EndGroup();	
};

#endif /* __GROUP_SHPTXT_H__ */
