/* -------------------------------------------------------------------------
//	�ļ���		��	rtffilter.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-15 14:55:23
//	��������	��	
//
//	$Id: rtffilter.cpp,v 1.21 2006/11/10 03:32:25 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#if !defined(RTF_NO_FILTER)

#include "rtffilter.h"
#include "htmlfilter.h"
#include "escherfilter.h"
#include "l10n.h"

#include <kso/io/linklib_docreader.h>
#include <kso/linklib.h>
#include <kso/appfeature/kappfeature.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

EXPORTAPI filterpluginRegister(IN IKFilterPluginRegister* pReg)
{
	pReg->Register(
		_IoFormat_Rtf,
		_KsoName_Rtf,
		FILTER_IMPORT,
		FILTER_TYMED_FILE,
		_KsoExt_Rtf,
		_KsoFileFormatDesc_Rtf_File
		);

	pReg->Register(
		_IoFormat_Rtf,
		_KsoName_Rtf,
		FILTER_IMPORT_CLIPBOARD,
		FILTER_TYMED_ISTREAM,
		__X("Rich Text Format"),
		__X("Rich Text Format")
		);

#if !defined(RTF_NO_HTMLFILTER)
	if (!_kso_QueryFeatureState(kaf_kso_PromptWhenLosingWPSFeature))
	{
		pReg->Register(
			_IoFormat_HTML,
			_KsoName_HTML,
			FILTER_IMPORT,
			FILTER_TYMED_FILE,
			_KsoExt_HTML,
			_KsoFileFormatDesc_HTML_File
			);
	}

	pReg->Register(
		_IoFormat_HTML,
		_KsoName_HTML,
		FILTER_IMPORT_CLIPBOARD,
		FILTER_TYMED_ISTREAM,
		__X("HTML Format"),
		__X("HTML Format")
		);
#endif

#if !defined(RTF_NO_ESCHERFILTER)
	pReg->Register(
		_IoFormat_Escher,
		_KsoName_Escher,
		FILTER_IMPORT_CLIPBOARD,
		FILTER_TYMED_ISTREAM,
		__X("Office Drawing Shape Format"),
		__X("Microsoft Office Drawing Shape Format")
		);
#endif

	return S_OK;
}

EXPORTAPI filterpluginFormatCorrect(
									IN LPCFILTERMEDIUM pMedium,
									IN long lFormat)
{
	switch (lFormat)
	{
	case _IoFormat_Rtf:
		{
			switch (pMedium->tymed)
			{
			case FILTER_TYMED_FILE:
				return FormatCorrectRTF(pMedium->lpszFileName);
			case FILTER_TYMED_ISTREAM:
				return FormatCorrectRTF(pMedium->pstm);
			default:
				return E_UNEXPECTED;
			}
		}

#if !defined(RTF_NO_HTMLFILTER)
	case _IoFormat_HTML:
		{
			switch (pMedium->tymed)
			{
			case FILTER_TYMED_FILE:
				return FormatCorrectHTML(pMedium->lpszFileName);
			case FILTER_TYMED_ISTREAM:
				return FormatCorrectHTML(pMedium->pstm);				
			default:
				return E_UNEXPECTED;
			}
		}
#endif

	default:
		return E_UNEXPECTED;
	}
}

EXPORTAPI filterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv)
{
	if (lFormat == _IoFormat_Rtf)
	{
		*ppv = new KCountObject<KRtfFilter>;
		return S_OK;
	}

#if !defined(RTF_NO_HTMLFILTER)
	else if (lFormat == _IoFormat_HTML)
	{
		*ppv = new KCountObject<KHtmlFilter>;
		return S_OK;
	}
#endif

#if !defined(RTF_NO_ESCHERFILTER)
	else if (lFormat == _IoFormat_Escher)
	{
		*ppv = new KCountObject<KEscherFilter>;
		return S_OK;
	}
#endif
	
	return E_UNEXPECTED;
}

// -------------------------------------------------------------------------
#else
#include <kso/io/contentsource.h>

EXPORTAPI filterpluginRegister(IN IKFilterPluginRegister* pReg)
{
	return S_OK;
}

EXPORTAPI filterpluginFormatCorrect(
									IN LPCFILTERMEDIUM pMedium,
									IN long lFormat)
{
	return E_UNEXPECTED;
}

EXPORTAPI filterpluginImportCreate(
								   IN long lFormat,
								   IN IKFilterEventNotify* pNotify,
								   OUT IKFilterMediaInit** ppv)
{
	return E_NOTIMPL;
}

#endif