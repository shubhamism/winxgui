/* -------------------------------------------------------------------------
//	�ļ���		��	group_listpicture.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-4 22:26:22
//	��������	��	
//
//	$Id: group_listpicture.h,v 1.5 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_LISTPICTURE_H__
#define __GROUP_LISTPICTURE_H__

#ifndef __GROUP_PICT_H__
#include "../drawing/group_pict.h"
#endif

// -------------------------------------------------------------------------
// class Group_listpict

class Group_listpict : public Group_pict_Base
{
public:
	RtfDocument* m_doc;
	
	STDMETHODIMP AddBinary(
		LPCVOID pData,
		int cbData);
	
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// class Group_listpicture

class Group_listpicture : public Group_Base
{
private:
//	Group_shppict m_shppict;
//	Group_nonshppict m_nonshppict;
	
public:
	RtfGrpObject<Group_listpict> m_pict;
	
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
};

// -------------------------------------------------------------------------
//	$Log: group_listpicture.h,v $
//	Revision 1.5  2006/09/11 08:00:23  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.4  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	
#endif /* __GROUP_LISTPICTURE_H__ */
