/* -------------------------------------------------------------------------
//	�ļ���		��	group_fchars.h
//	������		��	���὿
//	����ʱ��	��	2006-3-21 16:11:45
//	��������	��	
//
//	$Id: group_fchars.h,v 1.2 2006/07/27 02:39:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FCHARS_H__
#define __GROUP_FCHARS_H__

class RtfDocument;
class Group_fchars : public Group_Base
{
	Group_fchars* m_subfchars;
public:
	Group_fchars() : m_subfchars(NULL)
	{
	}
	~Group_fchars()
	{
		RTF_DELETE_GROUP(m_subfchars);
	}
	RtfDocument* m_doc;

	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
	{
		if(grName == rtf_fchars)
		{
			m_doc->m_dop.doptypography.rgxchFPunct[0] = '\0';
		}
		return S_OK;
	}

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch)
	{
		INT szWchBuf = cch*2 + 10, szRet;
		std::vector<WCHAR> wchBuf(szWchBuf);
		szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
		wchBuf.resize(szRet);
		wchBuf.push_back('\0');
		wcscat(m_doc->m_dop.doptypography.rgxchFPunct, wchBuf.begin());
		return S_OK;
	}
		
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
	{
		if(m_subfchars == NULL)
		{
			m_subfchars = RTF_NEW_GROUP(Group_fchars);
			m_subfchars->m_doc = m_doc;
		}
		*ppsubGroup = m_subfchars;
		return S_OK;
	}
};

class Group_lchars : public Group_Base
{
	Group_lchars* m_sublchars;
public:
	RtfDocument* m_doc;
	Group_lchars() : m_sublchars(NULL)
	{
	}
	~Group_lchars()
	{
		RTF_DELETE_GROUP(m_sublchars);
	}

	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
	{
		if(grName == rtf_lchars)
		{
			m_doc->m_dop.doptypography.rgxchLPunct[0] = '\0';
		}
		return S_OK;
	}
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch)
	{
		INT szWchBuf = cch*2 + 10, szRet;
		std::vector<WCHAR> wchBuf(szWchBuf);
		szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
		wchBuf.resize(szRet);
		wchBuf.push_back('\0');
		wcscat(m_doc->m_dop.doptypography.rgxchLPunct, wchBuf.begin());
		return S_OK;
	}
	
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
	{
		if(m_sublchars == NULL)
		{
			m_sublchars = RTF_NEW_GROUP(Group_lchars);
			m_sublchars->m_doc = m_doc;
		}
		*ppsubGroup = m_sublchars;
		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: group_fchars.h,v $
//	Revision 1.2  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.1  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	

#endif /* __GROUP_FCHARS_H__ */
