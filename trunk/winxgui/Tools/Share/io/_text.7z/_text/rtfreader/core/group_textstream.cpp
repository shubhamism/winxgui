/* -------------------------------------------------------------------------
//	�ļ���		��	group_textstream.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 14:42:36
//	��������	��	
//
//	$Id: group_textstream.cpp,v 1.30 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_textstream.h"
#include "../drawing/group_shppict.h"
#include "../drawing/group_shp.h"
#include "../footnote/group_footnote.h"
#include "../field/group_field.h"
#include "../field/group_field2.h"
#include "../annotation/group_annotation.h"
#include "../drawing/group_obj.h"
#include "../texttable/texttable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Group_TextStream::Group_TextStream()
  : m_shppict(NULL), m_shp(NULL),
	m_footnote(NULL),
	m_field(NULL), m_tc(NULL),
	m_subTextStrm(NULL),
	m_atrfstart(NULL),
	m_atrfend(NULL),
	m_atnid(NULL),
	m_atnauthor(NULL),
	m_annotation(NULL),
	m_object(NULL),
	m_nesttableprops(NULL)
{
}

Group_TextStream::~Group_TextStream()
{
	RTF_DELETE_GROUP(m_field);	
	RTF_DELETE_GROUP(m_tc);
	RTF_DELETE_GROUP(m_shppict);
	RTF_DELETE_GROUP(m_shp);
	RTF_DELETE_GROUP(m_object);
	RTF_DELETE_GROUP(m_footnote);
	RTF_DELETE_GROUP(m_subTextStrm);
	RTF_DELETE_GROUP(m_atrfstart);
	RTF_DELETE_GROUP(m_atrfend);
	RTF_DELETE_GROUP(m_atnid);
	RTF_DELETE_GROUP(m_atnauthor);
	RTF_DELETE_GROUP(m_annotation);
	RTF_DELETE_GROUP(m_nesttableprops);
}

STDMETHODIMP Group_TextStream::StartGroup(
		RtfControl grName,
		int grValue, 
		int& fDest)
{
	m_paraPrBackup.Backup(m_doc->m_paraPr);	
	m_spanPrBackup.Backup(m_doc->m_spanPr);	
	m_trowBackup.Backup(m_doc->m_trow);	
	m_tblPosBackup.Backup(m_doc->m_tblPos);	
	m_spanPrParaStyleBackup.Backup(m_doc->m_spanPrParaStyle);	
	AddAttribute(grName, grValue);
	return S_OK;
}

STDMETHODIMP Group_TextStream::AddAttribute(
		RtfControl attrName,
		int attrValue)
{
	HRESULT hr = Span_AddAttribute(&m_doc->m_spanPr, m_doc, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;
	
	hr = Para_AddAttribute(&m_doc->m_paraPr, m_doc, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;

	return E_UNEXPECTED;
}

STDMETHODIMP Group_TextStream::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{	
	case rtf_pict:
		if (m_shppict == NULL)
			m_shppict = RTF_NEW_GROUP(Group_shppict);
		m_shppict->m_pict.m_doc = m_doc;
		m_shppict->m_pict.m_opt.Reset();		
		*ppsubGroup = &m_shppict->m_pict;
		break;
	case rtf_shppict:
		if (m_shppict == NULL)
			m_shppict = RTF_NEW_GROUP(Group_shppict);
		m_shppict->m_pict.m_doc = m_doc;
		*ppsubGroup = m_shppict;
		break;
	case rtf_shp:
	case rtf_shpgrp:
		if (m_shp == NULL)
			m_shp = RTF_NEW_GROUP(Group_shp_toplevel);
		m_shp->m_doc = m_doc;		
		if ( FAILED(m_shp->m_shpinst.NewShape(grSubName == rtf_shpgrp, m_doc)) )
			return E_UNEXPECTED;
		*ppsubGroup = m_shp;
		break;
	case rtf_nonshppict:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_listtext:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_pntext:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_footnote:
		//RTF_DELETE_GROUP(m_footnote);
		if(m_footnote == NULL)
			m_footnote = RTF_NEW_GROUP(RtfGroup_footnote);
		m_footnote->m_doc = m_doc;
		*ppsubGroup = m_footnote;
		break;
	case rtf_object:		
		if (m_object == NULL)		
			m_object = RTF_NEW_GROUP(Group_object);
		m_object->m_doc = m_doc;
		*ppsubGroup = m_object;		
		break;
	case rtf_field:
		if (m_field == NULL)
			m_field = RTF_NEW_GROUP(Group_field2);
		m_field->m_doc = m_doc;
		*ppsubGroup = m_field;
		break;
	case rtf_bkmkstart:
		m_bkmkstart.m_doc = m_doc;
		*ppsubGroup = &m_bkmkstart;
		break;
	case rtf_bkmkend:
		m_bkmkend.m_doc = m_doc;
		*ppsubGroup = &m_bkmkend;
		break;
	case rtf_nesttableprops:		
		if(m_nesttableprops == NULL)
			m_nesttableprops = RTF_NEW_GROUP(Group_nesttableprops);
		m_nesttableprops->m_doc = m_doc;
		*ppsubGroup = m_nesttableprops;
		break;
	case rtf_nonesttables:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_tc:
		if(m_tc == NULL)
			m_tc = RTF_NEW_GROUP(Group_tc);
		m_tc->m_doc = m_doc;
		*ppsubGroup = m_tc;
		break;
	case rtf_atrfstart:
		if(m_atrfstart == NULL)
			m_atrfstart = RTF_NEW_GROUP(RtfGroup_atrfstart);
		m_atrfstart->m_doc = m_doc;
		*ppsubGroup = m_atrfstart;
		break;
	case rtf_atrfend:
		if(m_atrfend == NULL)
			m_atrfend = RTF_NEW_GROUP(RtfGroup_atrfend);
		m_atrfend->m_doc = m_doc;
		*ppsubGroup = m_atrfend;
		break;
	case rtf_atnid:		
		if(m_atnid == NULL)
			m_atnid = RTF_NEW_GROUP(RtfGroup_atnid);
		m_atnid->m_doc = m_doc;
		*ppsubGroup = m_atnid;
		break;
	case rtf_atnauthor:		
		if(m_atnauthor == NULL)
			m_atnauthor = RTF_NEW_GROUP(RtfGroup_atnauthor);
		m_atnauthor->m_doc = m_doc;
		*ppsubGroup = m_atnauthor;
		break;
	case rtf_annotation:
		RTF_DELETE_GROUP(m_annotation);
		if(m_annotation == NULL)
			m_annotation = RTF_NEW_GROUP(RtfGroup_annotation);
		m_annotation->m_doc = m_doc;
		*ppsubGroup = m_annotation;
		break;	
	case rtf_uc:
		*ppsubGroup = &m_uc;
		m_uc.m_parent = this;
		break;
	default:
		if (fDest1987)
			return E_UNEXPECTED;
		else
		{
			if (m_subTextStrm == NULL)
				m_subTextStrm = RTF_NEW_GROUP(Group_TextStream);
			m_subTextStrm->m_doc = m_doc;
			*ppsubGroup = m_subTextStrm;
		}
	}
	return S_OK;
}

STDMETHODIMP Group_TextStream::AddContent(
		LPCSTR pContent,
		int cch)
{	
	m_doc->AddContent(pContent, cch);
	return S_OK;
}

STDMETHODIMP Group_TextStream::AddContent(
		LPCWSTR pContent,
		int cch)
{
	m_doc->AddContent(pContent, cch);
	return S_OK;
}

STDMETHODIMP Group_TextStream::EndGroup()
{	
	m_spanPrBackup.Restore(&m_doc->m_spanPr);	
	m_paraPrBackup.Restore(&m_doc->m_paraPr);	
	m_trowBackup.Restore(&m_doc->m_trow);	
	m_tblPosBackup.Restore(&m_doc->m_tblPos);	
	m_spanPrParaStyleBackup.Restore(&m_doc->m_spanPrParaStyle);	
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: group_textstream.cpp,v $
//	Revision 1.30  2006/09/11 08:00:23  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.29  2006/08/30 08:19:24  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.28  2006/08/09 06:29:32  xulingjiao
//	�޸�#28594
//	
//	Revision 1.27  2006/08/09 04:29:34  xulingjiao
//	#28604
//	
//	Revision 1.26  2006/08/03 02:08:32  xulingjiao
//	�޸�m_docδ��ʼ������ı���
//	
//	Revision 1.25  2006/07/31 06:29:16  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.24  2006/07/03 06:50:46  xulingjiao
//	�޸�IncludePicture��ͼƬ��ʾ������������
//	
//	Revision 1.23  2006/06/30 09:42:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.22  2006/06/05 07:35:14  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.21  2006/06/05 06:47:00  xulingjiao
//	�޸������BUG
//	
//	Revision 1.20  2006/04/30 07:43:51  xulingjiao
//	�޸�#24580 ��BUG
//	
//	Revision 1.19  2006/03/21 04:22:53  xulingjiao
//	�޸��û�������BUG
//	
//	Revision 1.18  2006/03/10 01:05:20  xulingjiao
//	�����ͼƬ��ʧ
//	
//	Revision 1.17  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.16  2006/03/01 01:49:56  xulingjiao
//	�޸����BUG
//	
//	Revision 1.15  2006/02/27 08:19:50  xulingjiao
//	rtfreader����mask
//	