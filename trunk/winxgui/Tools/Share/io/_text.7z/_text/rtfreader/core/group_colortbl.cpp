/* -------------------------------------------------------------------------
//	�ļ���		��	group_colortbl.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 14:38:58
//	��������	��	
//
//	$Id: group_colortbl.cpp,v 1.6 2006/03/06 01:39:48 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_colortbl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP Group_colortbl::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	switch (attrName)
	{
	case rtf_red:
		m_color.r = attrValue;
		break;
	case rtf_green:		
		m_color.g = attrValue;
		break;		
	case rtf_blue:
		m_color.b = attrValue;
		break;
	default:
		return E_UNEXPECTED;
	}
	m_color.fauto = 0;
	return S_OK;
}

STDMETHODIMP Group_colortbl::AddContent(
						LPCSTR pContent,
						int cch)
{
	for (LPCSTR pContentEnd = pContent + cch; pContent != pContentEnd; ++pContent)
	{
		if (*pContent == ';')
		{
			m_colortbl->Add(m_rgb);
			m_rgb = RtfDefaultColor;
		}
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: group_colortbl.cpp,v $
//	Revision 1.6  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.5  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	