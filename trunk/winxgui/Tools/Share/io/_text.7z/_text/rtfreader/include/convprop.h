/* -------------------------------------------------------------------------
//	�ļ���		��	convprop.h
//	������		��	���὿
//	����ʱ��	��	2006-2-26 17:39:40
//	��������	��	
//
//	$Id: convprop.h,v 1.1 2006/02/27 01:53:01 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __CONVPROP_H__
#define __CONVPROP_H__
STDMETHODIMP MaskConvertChpx(KDWPropBuffer& propx, 
							 RtfSpanBasePr* self,
							 const RtfSpanBasePr* baseOn);
STDMETHODIMP_(void) ConvertChpx(KDWPropBuffer& propx, 
								RtfSpanBasePr* self,
								const RtfSpanBasePr* baseOn);
STDMETHODIMP_(void) ConvertChpx( KDWPropBuffer& chpx,
								 RtfSpanPr* self,
								 RtfDocument* doc);
STDMETHODIMP MaskConvertPapx(KDWPropBuffer& propx,
							 RtfParaBasePr* self,
							 const RtfParaBasePr* baseOn);
STDMETHODIMP_(void) ConvertPapx(KDWPropBuffer& propx,
								RtfParaBasePr* self,
								const RtfParaBasePr* baseOn);
STDMETHODIMP_(void) ConvertPapx(KDWPropBuffer& propx,
								RtfParaPr* self,
								RtfDocument* doc);
STDMETHODIMP_(void) ConvertSepx(KDWPropBuffer& propx, RtfSectionPr* self);
// -------------------------------------------------------------------------
//	$Log: convprop.h,v $
//	Revision 1.1  2006/02/27 01:53:01  xulingjiao
//	��������
//	

#endif /* __CONVPROP_H__ */
