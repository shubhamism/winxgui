/* -------------------------------------------------------------------------
//	�ļ���		��	group_ud.h
//	������		��	���὿
//	����ʱ��	��	2006-3-21 16:04:49
//	��������	��	
//
//	$Id: group_ud.h,v 1.1 2006/03/23 09:41:25 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_UD_H__
#define __GROUP_UD_H__

class Group_fchars;
class Group_lchars;
class RtfDocument;
class Group_stylesheet;
class Group_ud : public Group_Base
{
	Group_stylesheet* m_stylesheet;
	Group_fchars* m_fchars;
	Group_lchars* m_lchars;

public:	
	RtfDocument* m_doc;
	Group_ud();

	~Group_ud();

	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);
};
// -------------------------------------------------------------------------
//	$Log: group_ud.h,v $
//	Revision 1.1  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	

#endif /* __GROUP_UD_H__ */
