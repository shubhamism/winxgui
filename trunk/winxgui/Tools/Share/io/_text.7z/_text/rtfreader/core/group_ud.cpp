/* -------------------------------------------------------------------------
//	�ļ���		��	group_ud.cpp
//	������		��	���὿
//	����ʱ��	��	2006-3-21 16:06:10
//	��������	��	
//
//	$Id: group_ud.cpp,v 1.1 2006/03/23 09:41:25 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_stylesheet.h"
#include "group_fchars.h"
#include "group_ud.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Group_ud::Group_ud() : m_stylesheet(NULL), m_fchars(NULL), m_lchars(NULL)
{
}

Group_ud::~Group_ud()
{
	RTF_DELETE_GROUP(m_stylesheet);
	RTF_DELETE_GROUP(m_fchars);
	RTF_DELETE_GROUP(m_lchars);
}

STDMETHODIMP Group_ud::EnterSubGroup(
		IN RtfControl grSubName,		
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_stylesheet:
		if (m_stylesheet == NULL)
		{
			m_stylesheet = RTF_NEW_GROUP(Group_stylesheet);
			m_stylesheet->m_doc = m_doc;			
		}
		*ppsubGroup = m_stylesheet;		
		break;
	case rtf_fchars:
		if (m_fchars == NULL)
		{
			m_fchars = RTF_NEW_GROUP(Group_fchars);
			m_fchars->m_doc = m_doc;
		}
		*ppsubGroup = m_fchars;
		break;
	case rtf_lchars:
		if (m_lchars == NULL)
		{
			m_lchars = RTF_NEW_GROUP(Group_lchars);
			m_lchars->m_doc = m_doc;
		}
		*ppsubGroup = m_lchars;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}
// -------------------------------------------------------------------------
//	$Log: group_ud.cpp,v $
//	Revision 1.1  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	
