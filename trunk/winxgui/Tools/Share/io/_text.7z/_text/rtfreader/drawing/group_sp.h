/* -------------------------------------------------------------------------
//	�ļ���		��	group_sp.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-29 23:57:16
//	��������	��	�������������
//
//	$Id: group_sp.h,v 1.21 2006/08/30 08:19:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_SP_H__
#define __GROUP_SP_H__

#ifndef __SHAPEOPT_H__
#include "shapeopt.h"
#endif

#ifndef __GROUP_PICT_H__
#include "group_pict.h"
#endif
#include <Hlink.h>

typedef KDWShape RtfShape;

// -------------------------------------------------------------------------
// class Group_sn

class Group_sn : public Group_Base
{
public:
	const RtfSpInfo* m_spInfo;
	INT32 m_filltype;

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	
	STDMETHODIMP AddBinary(
		LPCVOID pContent,
		int cch);
};

// -------------------------------------------------------------------------
// class Group_sv_pict

class Group_sv_pict : public Group_pict_Base
{
public:
	RtfDocument* m_doc;

	STDMETHODIMP AddBinary(
		LPCVOID pData,
		int cbData);
	
	STDMETHODIMP EndGroup();		
};

// -------------------------------------------------------------------------
// class Group_hl

class Group_hlfr : public Group_Base
{
};

class Group_hlsrc : public Group_Base
{
};

class Group_hlloc : public Group_Base
{
};

class Group_hl : public Group_Base
{	
};

// -------------------------------------------------------------------------
// class Group_sv

class Group_sv : public Group_Base
{
public:
	RtfGrpObject<Group_sv_pict> m_pict;
	RtfGrpObject<Group_hl> m_hl;
	RtfGrpObject<Group_uc> m_uc;
public:	
	RtfShapeOPT* m_opt;
	RtfShapeInfo* m_info;
	RtfDocument* m_doc;
	const RtfSpInfo* m_spInfo;	
	ks_wstring m_wcontent;
	STDMETHODIMP StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest);	
	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);

	STDMETHODIMP AddContent(
		LPCWSTR pContent,
		int cch);
	
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);	
	
	STDMETHODIMP EndGroup();

private:
	STDMETHODIMP _AddWContent();		
};

// -------------------------------------------------------------------------
// class Group_sp

class Group_sp : public Group_Base
{
private:
	RtfGrpObject<Group_sn> m_sn;
	RtfGrpObject<Group_sv> m_sv;	
public:	
	RtfDocument* m_doc;
	STDMETHODIMP_(void) Init(		
		RtfShapeOPT* opt,
		RtfShapeInfo* info)
	{			
		m_sv.m_opt = opt;
		m_sv.m_info = info;
	}

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{
		return S_OK;
	}

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);	
};
#endif /* __GROUP_SP_H__ */
