/* -------------------------------------------------------------------------
//	�ļ���		��	group_field2.h
//	������		��	���὿
//	����ʱ��	��	2006-6-30 16:47:33
//	��������	��	
//
//	$Id: group_field2.h,v 1.10 2006/09/11 08:00:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FIELD2_H__
#define __GROUP_FIELD2_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include "../core/group_textstream.h"
#endif

#include "group_fldinst2.h"
#include "group_fldrslt2.h"

class Group_field2 : public Group_TextStream
{
private:
	RtfGrpObject<Group_fldinst2> m_fldinst;
	RtfGrpObject<Group_fldrslt2> m_fldrslt;
	BOOL m_fDirty, m_fEdited, m_fLock;
public:
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
	STDMETHODIMP EndGroup();
private:
	STDMETHODIMP _DeleteSymbolField();	
	STDMETHODIMP _IncludePicture();
	STDMETHODIMP _InitPictureOpt(LPCWSTR picFile);
	STDMETHODIMP_(INT) _GetPictureType(LPCWSTR picFile);	
};

#endif /* __GROUP_FIELD2_H__ */
