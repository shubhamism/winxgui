/* -------------------------------------------------------------------------
//	�ļ���		��	group_footnote.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-6 13:11:24
//	��������	��	
//
//	$Id: group_footnote.h,v 1.7 2006/09/21 06:29:05 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FOOTNOTE_H__
#define __GROUP_FOOTNOTE_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include "../core/group_textstream.h"
#endif

// -------------------------------------------------------------------------
// RtfGroup_footnote

class RtfGroup_footnote : public Group_TextStream
{
	STDMETHODIMP EnterFootEndNote();
public:
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue, 
		int& fDest);

	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);
	STDMETHODIMP AddContent(
		LPCWSTR pContent,
		int cch);
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,		
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
//	$Log: group_footnote.h,v $
//	Revision 1.7  2006/09/21 06:29:05  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.6  2006/09/11 08:00:24  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.5  2006/07/31 06:29:16  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.4  2006/02/27 08:19:55  xulingjiao
//	rtfreader����mask
//	
#endif /* __GROUP_FOOTNOTE_H__ */
