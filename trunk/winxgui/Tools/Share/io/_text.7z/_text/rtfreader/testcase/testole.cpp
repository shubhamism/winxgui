/* -------------------------------------------------------------------------
//	�ļ���		��	testole.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-14 11:45:31
//	��������	��	
//
//	$Id: testole.cpp,v 1.2 2005/01/14 04:29:03 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestOleObject : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestOleObject);
		CPPUNIT_TEST(testEmbOle_Shape);
		CPPUNIT_TEST(testEmbOle_InlineShape);
		CPPUNIT_TEST(testLinkOle_Shape);
		CPPUNIT_TEST(testLinkOle_InlineShape);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testEmbOle_Shape()
	{
		testRtf2DocFile("draw/ole/embole_shape.rtf", "embole_shape.doc");
	}
	void testEmbOle_InlineShape()
	{
		testRtf2DocFile("draw/ole/embole_inlineshape.rtf", "embole_inlineshape.doc");
	}
	void testLinkOle_Shape()
	{
		testRtf2DocFile("draw/ole/linkole_shape.rtf", "linkole_shape.doc");
	}
	void testLinkOle_InlineShape()
	{
		testRtf2DocFile("draw/ole/linkole_inlineshape.rtf", "linkole_inlineshape.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestOleObject);

// -------------------------------------------------------------------------
//	$Log: testole.cpp,v $
//	Revision 1.2  2005/01/14 04:29:03  xushiwei
//	��ʼ֧��ole����
//	1��nametoid������ole��صĿ��Ʒ���
//	2������ole���԰�����
//	
