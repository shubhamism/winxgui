/* -------------------------------------------------------------------------
//	�ļ���		��	group_stylesheet.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 14:42:18
//	��������	��	
//
//	$Id: group_stylesheet.cpp,v 1.34 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "../include/rtfstyle_impl.h"
#include "group_stylesheet.h"
#include "group_rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// ������ʽ��
inline
STDMETHODIMP StyleBase_AddContent(
						  ks_wstring stylename,
						  Group_stylesheet* stylesheet)
{
	RtfDocument* doc = stylesheet->m_doc;
	ks_wstring::size_type pos = stylename.find_first_not_of(__X("\t\r\n "));
	if(pos != ks_wstring::npos)	
	{
		KDWKernStr* name = doc->AllocString(stylename.begin(), stylename.size());
		stylesheet->m_style->SetName(name);
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// ��ʽ�������
typedef const RtfDocument RtfStyleBaseContext;

inline
STDMETHODIMP StyleBase_AddAttribute(
									RtfStyle* style,
									RtfStyleBaseContext* context,
									RtfControl attrName,
									int attrValue)
{	
	switch (attrName)
	{
	case rtf_sbasedon:
		style->SetBaseStyle(attrValue);
		break;
	case rtf_additive:
		break;
	case rtf_slink:
		style->SetLinkStyle(attrValue);
		break;
	case rtf_snext:
		if(attrValue!=rtf_nilParam)
			style->SetNextStyle(attrValue);
		break;
	case rtf_sautoupd:
		style->SetAutoRedefine(attrValue!=0);
		break;
	case rtf_shidden:
		style->SetHiddenUI(attrValue!=0);
		break;
	case rtf_ssemihidden:
		style->SetSemiHidden(attrValue!=0);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// Group_s

STDMETHODIMP RtfGroup_s::StartGroup(
		const RtfAttribute* attr,
		const RtfAttribute* attrEnd,
		int& fDest)
{	
	m_attrs.clear();
	m_stylename.clear();
	m_attrs.insert(m_attrs.end(), attr, attrEnd);
	return S_OK;
}

STDMETHODIMP RtfGroup_s::AddAttributes(
		const RtfAttribute* attr,
		const RtfAttribute* attrEnd)
{	
	m_attrs.insert(m_attrs.end(), attr, attrEnd);
	return S_OK;
}

STDMETHODIMP RtfGroup_s::AddContent(
						LPCSTR pContent,
						int cch)
{	
	if (pContent[cch-1] == ';')
		--cch;
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_stylename.append(wchBuf.begin(), szRet);
	return S_OK;
}

STDMETHODIMP RtfGroup_s::AddContent(
		IN LPCWSTR pContent,
		IN int cch)
{
	m_stylename.append(pContent, cch);
	return S_OK;
}

STDMETHODIMP RtfGroup_s::EndGroup()
{
	Group_stylesheet* stylesheet = parent_class_ptr(Group_stylesheet, m_s);
	RtfDocument* doc = stylesheet->m_doc;

	KDWAutoFreeAlloc* alloc = doc->GetAllocater();

	UINT sti = stiUser;
	if (m_attrs[0].prop == rtf_s)
	{
		stylesheet->m_style = 
			doc->m_stylesheet.NewStyle(m_attrs[0].value, mso_sgcParagraph);		
	}
	else
	{
		stylesheet->m_style = 
			doc->m_stylesheet.NewStyle(0, mso_sgcParagraph);
		sti = stiNormal;
	}

	doc->m_spanPr.Reset();
	doc->m_paraPr.Reset();

	UINT i;
	for (i = 0; i < m_attrs.size(); ++i)
	{
		HRESULT hr = SpanBase_AddAttribute(
			&doc->m_spanPr,
			doc,
			m_attrs[i].prop,
			m_attrs[i].value
			);
		if (SUCCEEDED(hr))
			continue;
		
		hr = Para_AddAttribute(
			&doc->m_paraPr,
			doc,
			m_attrs[i].prop,
			m_attrs[i].value);
		if (SUCCEEDED(hr))
			continue;

		StyleBase_AddAttribute(
			stylesheet->m_style,
			doc,
			m_attrs[i].prop,
			m_attrs[i].value
			);
	}

	RtfParaPr* pPr = _MsoAlloc(alloc, RtfParaPr);
	*pPr = doc->m_paraPr;

	RtfSpanPr* spanPr = _MsoAlloc(alloc, RtfSpanPr);
	*spanPr = doc->m_spanPr;
	
	stylesheet->m_style->SetProperites(mso_sgcParagraph, (RtfPropData*)pPr);
	stylesheet->m_style->SetProperites(mso_sgcCharacter, (RtfPropData*)spanPr);
	
	StyleBase_AddContent(m_stylename, stylesheet);
	if(sti != stiNormal)
		sti = StiFromStyleName(stylesheet->m_style->GetName());
	stylesheet->m_style->Update(stylesheet->m_doc, sti);
	return S_OK;
}

// -------------------------------------------------------------------------

STDMETHODIMP RtfGroup_cs::StartGroup(
									 const RtfAttribute* attr,
									 const RtfAttribute* attrEnd, 
									 int& fDest)
{
	m_attrs.clear();
	m_stylename.clear();
	m_attrs.insert(m_attrs.end(), attr, attrEnd);	
	return S_OK;
}

STDMETHODIMP RtfGroup_cs::AddAttributes(
										const RtfAttribute* attr,
										const RtfAttribute* attrEnd)
{
	m_attrs.insert(m_attrs.end(), attr, attrEnd);
	return S_OK;
}

STDMETHODIMP RtfGroup_cs::AddContent(
						LPCSTR pContent,
						int cch)
{	
	if (pContent[cch-1] == ';')
		--cch;
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_stylename.append(wchBuf.begin(), szRet);
	return S_OK;
}

STDMETHODIMP RtfGroup_cs::AddContent(
		LPCWSTR pContent,
		int cch)
{
	m_stylename.append(pContent, cch);
	return S_OK;
}

STDMETHODIMP RtfGroup_cs::EndGroup()
{	
	Group_stylesheet* stylesheet = parent_class_ptr(Group_stylesheet, m_cs);
	RtfDocument* doc = stylesheet->m_doc;

	KDWAutoFreeAlloc* alloc = doc->GetAllocater();
	
	UINT i=0;
	stylesheet->m_style = doc->m_stylesheet.NewStyle(m_attrs[i++].value, mso_sgcCharacter);	

	const RtfAttribute* attrBegin = &m_attrs[i];

	doc->m_spanPr.ResetByWord();
	for (; i < m_attrs.size(); ++i)
	{
		HRESULT hr = SpanBase_AddAttribute(
			&doc->m_spanPr,
			doc,
			m_attrs[i].prop,			
			m_attrs[i].value
			);
		if (SUCCEEDED(hr))
			continue;

		StyleBase_AddAttribute(
			stylesheet->m_style,
			doc,
			m_attrs[i].prop,
			m_attrs[i].value
			);
	}

	UINT cb = (m_attrs.size()-1) * sizeof(RtfAttribute);

	RtfSpanPr* spanPr = 
		(RtfSpanPr*)alloc->Alloc(
			sizeof(RtfSpanPr) + 
			sizeof(MsoKernData) +
			cb);
	*spanPr = doc->m_spanPr;

	MsoKernData* attrs = (MsoKernData*)(spanPr + 1);
	attrs->cb = cb;
	CopyMemory(_MsoPdata(attrs), attrBegin, cb);

	stylesheet->m_style->SetProperites(mso_sgcCharacter, (RtfPropData*)spanPr);

	StyleBase_AddContent(m_stylename, stylesheet);
	UINT sti = StiFromStyleName(stylesheet->m_style->GetName());
	stylesheet->m_style->Update(stylesheet->m_doc, sti);
	return S_OK;
}

// -------------------------------------------------------------------------
// Group_stylesheet
STDMETHODIMP Group_stylesheet::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{	
	fDest |= rtf_destTrue;
//	MakeNormalStyle(fDest);
	return S_OK;
}

STDMETHODIMP Group_stylesheet::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_s: // ������ʽ
		*ppsubGroup = &m_s;
		m_s.m_doc = m_doc;
		break;
	case rtf_cs: // �ַ���ʽ
		*ppsubGroup = &m_cs;
		m_cs.m_doc = m_doc;
		break;
	case rtf_ts: // ������ʽ
		*ppsubGroup = &_group_skipped;
		break;
	default:
		if (fDest1987)
			return E_UNEXPECTED;
		else // ������ʽ
		{
			*ppsubGroup = &m_s;
			m_s.m_doc = m_doc;
		}
	}
	return S_OK;
}

STDMETHODIMP Group_stylesheet::EndGroup()
{
	m_doc->m_spanPr.Reset();
	m_doc->m_paraPr.Reset();
	m_doc->m_stylesheet.UpdateAllStyles(m_doc);
	return S_OK;
}