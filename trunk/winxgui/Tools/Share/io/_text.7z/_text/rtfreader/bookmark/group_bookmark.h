/* -------------------------------------------------------------------------
//	�ļ���		��	group_bookmark.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 21:21:18
//	��������	��	
//
//	$Id: group_bookmark.h,v 1.7 2006/07/27 02:39:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_BOOKMARK_H__
#define __GROUP_BOOKMARK_H__

// -------------------------------------------------------------------------
// class Group_bkmkstart

class Group_bkmkstart : public Group_Base
{
public:
	RtfDocument* m_doc;

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch)
	{
		INT szWchBuf = cch*2 + 10, szRet;
		std::vector<WCHAR> wchBuf(szWchBuf);
		szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
		return m_doc->MarkBookmarkBegin(wchBuf.begin(), szRet);
	}	
};

// -------------------------------------------------------------------------
// class Group_bkmkend

class Group_bkmkend : public Group_Base
{
public:
	RtfDocument* m_doc;

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch)
	{
		INT szWchBuf = cch*2 + 10, szRet;
		std::vector<WCHAR> wchBuf(szWchBuf);
		szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);		
		return m_doc->MarkBookmarkEnd(wchBuf.begin(), szRet);
	}	
};

#endif /* __GROUP_BOOKMARK_H__ */
