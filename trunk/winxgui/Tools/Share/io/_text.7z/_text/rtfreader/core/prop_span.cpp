/* -------------------------------------------------------------------------
//	�ļ���		��	prop_span.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 16:38:52
//	��������	��	
//
//	$Id: prop_span.cpp,v 1.94 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htm/length_unit.h"
#include "../texttable/texttable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//--------------------------------------------------------------------------------
//���������������


STDMETHODIMP SpanBase_Lang_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch(attrName)
	{	
	case rtf_lang:
		spanPr->rglid[rtf_lidAscii] = attrValue;
		_MemSetInt(mask->rglid[rtf_lidAscii]);
		break;
	case rtf_langnp:
		spanPr->rglid[rtf_lidAscii] = attrValue;
		_MemSetInt(mask->rglid[rtf_lidAscii]);
		break;
	case rtf_langfe:		
		spanPr->rglid[rtf_lidFastEast] = attrValue;
		_MemSetInt(mask->rglid[rtf_lidFastEast]);
		break;
	case rtf_langfenp:		
		spanPr->rglid[rtf_lidFastEast] = attrValue;
		_MemSetInt(mask->rglid[rtf_lidFastEast]);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP SpanBase_Font_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{	
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch(attrName)
	{	
	case rtf_i:			//---����
		spanPr->fItalic = attrValue!=0;		
		_MemSetInt(mask->fItalic);
		break;
	case rtf_b:
		spanPr->fBold = attrValue!=0;
		_MemSetInt(mask->fBold);
		break;
	case rtf_fs:		//---�ֺ�		
		spanPr->hps = attrValue;
		_MemSetInt(mask->hps);
		break;
	case rtf_f:			//---����
		{
			UINT fId = context->GetFontId(attrValue);
			spanPr->rgftc[spanPr->iftc] = fId;
			_MemSetInt(mask->rgftc[spanPr->iftc]);

			spanPr->fId = fId;
			_MemSetInt(mask->fId);
			UINT charset = context->GetFontTable().GetCharset(fId);
			if (context->m_fHaveAf)
			{				
				switch(charset)
				{
				case SYMBOL_CHARSET:
					spanPr->rgftc[rtf_ftcAscii] = fId;
					_MemSetInt(mask->rgftc[rtf_ftcAscii]);
					spanPr->rgftc[rtf_ftcOther] = fId;
					_MemSetInt(mask->rgftc[rtf_ftcOther]);
					spanPr->iftc = rtf_ftcOther;
					_MemSetInt(mask->iftc);
					spanPr->idctHint = 0;
					_MemSetInt(mask->idctHint);
					break;
					
				case HANGEUL_CHARSET:
				case SHIFTJIS_CHARSET:
				case GB2312_CHARSET:
				case CHINESEBIG5_CHARSET:
					spanPr->iftc = rtf_ftcFastEast;					
					spanPr->idctHint = 1;
					_MemSetInt(mask->iftc);
					_MemSetInt(mask->idctHint);					
					break;
				default:
					spanPr->iftc = rtf_ftcAscii;					
					spanPr->idctHint = 0;
					_MemSetInt(mask->iftc);
					_MemSetInt(mask->idctHint);					
					break;
				}
				spanPr->rgftc[spanPr->iftc] = fId;
				_MemSetInt(mask->rgftc[spanPr->iftc]);
			}
			else
			{
				spanPr->rgftc[0] = 
				spanPr->rgftc[1] = 
				spanPr->rgftc[2] = fId;
				_MemSetInt(mask->rgftc[0]);
				_MemSetInt(mask->rgftc[1]);
				_MemSetInt(mask->rgftc[2]);				
				switch(charset)
				{
				case HANGEUL_CHARSET:
				case SHIFTJIS_CHARSET:
				case GB2312_CHARSET:
				case CHINESEBIG5_CHARSET:
					spanPr->idctHint = 1;
					_MemSetInt(mask->idctHint);					
					break;
				default:
					spanPr->idctHint = 0;
					_MemSetInt(mask->idctHint);
					break;
				}
			}
		}
		break;
	case rtf_af:
		{
			(BOOL&)context->m_fHaveAf = TRUE;
			UINT fId = context->GetFontId(attrValue);
			spanPr->rgftc[spanPr->iftc] = fId;
			_MemSetInt(mask->rgftc[spanPr->iftc]);
		}
		break;
	case rtf_loch:
		spanPr->iftc = rtf_ftcAscii;
		spanPr->idctHint = 0;
		_MemSetInt(mask->iftc);
		_MemSetInt(mask->idctHint);
		break;
	case rtf_hich:
		spanPr->iftc = rtf_ftcOther;		
		spanPr->idctHint = 1;
		_MemSetInt(mask->iftc);
		_MemSetInt(mask->idctHint);
		break;
	case rtf_dbch:
		spanPr->iftc = rtf_ftcFastEast;
		spanPr->idctHint = 1;
		_MemSetInt(mask->iftc);
		_MemSetInt(mask->idctHint);
		break;
	case rtf_cf:		//---������ɫ		
		spanPr->crTextColor = context->m_colortbl.GetColor(attrValue);
		_MemSetInt(mask->crTextColor);
		break;
	case rtf_highlight: //---����		
		spanPr->icoHighlight = MatchRGB2Ico(context->m_colortbl.GetColor(attrValue));
		_MemSetInt(mask->icoHighlight);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//--------------------------------------------------------------------------------
//���ӡ�Ч��������


STDMETHODIMP SpanBase_Effect_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch(attrName)
	{	
	case rtf_strike:		
		spanPr->fStrike = attrValue;
		_MemSetInt(mask->fStrike);
		break;
	case rtf_striked:		
		spanPr->fDStrike = attrValue;
		_MemSetInt(mask->fDStrike);
		break;
	case rtf_super:		
		spanPr->iss = mso_isssup;
		_MemSetInt(mask->iss);
		break;
	case rtf_sub:
		spanPr->iss = mso_isssub;
		_MemSetInt(mask->iss);		
		break;
	case rtf_nosupersub:
		spanPr->iss = mso_issnone;
		_MemSetInt(mask->iss);
		break;
	case rtf_shad:		
		spanPr->fShadow = attrValue;
		_MemSetInt(mask->fShadow);
		break;
	case rtf_outl:		
		spanPr->fOutline = attrValue;
		_MemSetInt(mask->fOutline);
		break;
	case rtf_embo:		
		spanPr->fEmboss = attrValue;
		_MemSetInt(mask->fEmboss);
		break;
	case rtf_impr:		
		spanPr->fImprint = attrValue;
		_MemSetInt(mask->fImprint);
		break;
	case rtf_scaps:		
		spanPr->fSmallCaps = attrValue;
		_MemSetInt(mask->fSmallCaps);
		break;
	case rtf_caps:		
		spanPr->fCaps = attrValue;
		_MemSetInt(mask->fCaps);
		break;
	case rtf_v:		
		spanPr->fVanish = attrValue;
		_MemSetInt(mask->fVanish);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//--------------------------------------------------------------------------------
//���ӡ��»��ߡ�����


void SetKul(RtfSpanPr* spanpr,int attrValue,int accordValue)
{
	if(!attrValue)
		spanpr->kul = 0;
	else
		spanpr->kul = accordValue;	
}


STDMETHODIMP SpanBase_Kul_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch(attrName)
	{	
	case rtf_ul:		//---�»�������
		SetKul(spanPr,attrValue,mso_ulSingle);		
		_MemSetInt(mask->kul);
		break;
	case rtf_ulw:
		SetKul(spanPr,attrValue,mso_ulByWord);
		_MemSetInt(mask->kul);
		break;
	case rtf_uldb:
		SetKul(spanPr,attrValue,mso_ulDouble);
		_MemSetInt(mask->kul);
		break;
	case rtf_uld:
		SetKul(spanPr,attrValue,mso_ulDotted);
		_MemSetInt(mask->kul);
		break;		
	case rtf_ulth:
		SetKul(spanPr,attrValue,mso_ulThick);
		_MemSetInt(mask->kul);
		break;
	case rtf_uldash:
		SetKul(spanPr,attrValue,mso_ulDash);
		_MemSetInt(mask->kul);
		break;		
	case rtf_uldashd:
		SetKul(spanPr,attrValue,mso_ulDotDash);
		_MemSetInt(mask->kul);
		break;
	case rtf_uldashdd:
		SetKul(spanPr,attrValue,mso_ulDotDotDash);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulwave:
		SetKul(spanPr,attrValue,mso_ulWave);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulhwave:
		SetKul(spanPr,attrValue,mso_ulWavyHeavy);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulldash:
		SetKul(spanPr,attrValue,mso_ulDashLong);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulnone:
		SetKul(spanPr,attrValue,mso_ulNone);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulthd:
		SetKul(spanPr,attrValue,mso_ulDottedHeavy);
		_MemSetInt(mask->kul);
		break;	
	case rtf_ulthdash:
		SetKul(spanPr,attrValue,mso_ulDashedHeavy);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulthdashd:
		SetKul(spanPr,attrValue,mso_ulDashDotHeavy);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulthdashdd:
		SetKul(spanPr,attrValue,mso_ulDashDotDotHeavy);
		_MemSetInt(mask->kul);
		break;
	case rtf_ulthldash:
		SetKul(spanPr,attrValue,mso_ulDashLongHeavy);
		_MemSetInt(mask->kul);
		break;
	case rtf_ululdbwave:
		SetKul(spanPr,attrValue,mso_ulWavyDouble);
		_MemSetInt(mask->kul);
		break;	
	case rtf_ulc:		//---�»�����ɫ
		spanPr->crKulColor = context->m_colortbl.GetColor(attrValue);
		_MemSetInt(mask->crKulColor);
		return S_OK;
	default:
		return E_UNEXPECTED;
	}	
	return S_OK;
}

//--------------------------------------------------------------------------------
//���ӡ������ı�������


STDMETHODIMP SpanBase_AllText_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	HRESULT hr=SpanBase_Kul_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	switch(attrName)
	{	
	case rtf_accdot:		//---���غ�
		attrValue = (attrValue == 0 ? 0 : mso_underdot);
		spanPr->kcd = attrValue;
		_MemSetInt(mask->kcd);
		break;
	case rtf_acccomma:		
		attrValue = (attrValue == 0 ? 0 : mso_overcommasg);
		spanPr->kcd = attrValue;
		_MemSetInt(mask->kcd);
		break;
	case rtf_accnone:
		spanPr->kcd = mso_kcdNone;
		_MemSetInt(mask->kcd);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//---------------------------------------------------------------------------
//�����ַ��������

STDMETHODIMP SpanBase_Space_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch(attrName)	
	{
	case rtf_charscalex:	//---����		
		spanPr->wCharScale = attrValue;
		_MemSetInt(mask->wCharScale);
		break;	
	case rtf_expnd:			//---���
		spanPr->dxaSpace = pt_to_twip(attrValue*4);
		_MemSetInt(mask->dxaSpace);
		break;
	case rtf_expndtw:		
		spanPr->dxaSpace = attrValue;
		_MemSetInt(mask->dxaSpace);
		break;	
	case rtf_up:			//---λ��		
		spanPr->hpsPos = attrValue;
		_MemSetInt(mask->hpsPos);
		break;
	case rtf_dn:		
		spanPr->hpsPos = -attrValue;
		_MemSetInt(mask->hpsPos);
		break;	
	case rtf_kerning:		//---Ϊ��������ּ��
		spanPr->hpsKern = attrValue;
		_MemSetInt(mask->hpsKern);
		break;	
	case rtf_cgrid:			//---����������ĵ��������������		
		spanPr->fcgrid = attrValue != 0;
		_MemSetInt(mask->fcgrid);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//---------------------------------------------------------------------------
//�߿�͵���

STDMETHODIMP SpanBase_BrcAndShd_AddAttribute(
											RtfSpanPr* spanPr,
											RtfSpanContext* context,
											RtfControl attrName,
											int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	HRESULT hr = Brc_AddAttribute(*context->m_brc, context, attrName, attrValue);
	if (SUCCEEDED(hr))
	{
		_MemSetInt(mask->brc);
		return hr;
	}
	hr = GetChPattern(spanPr->shd,attrName,attrValue);
	if (SUCCEEDED(hr))
	{
		_MemSetInt(mask->shd);
		return hr;
	}
	switch(attrName)
	{	
	case rtf_chbrdr:		//---�ַ��߿�
		context->m_brc = &spanPr->brc;
		_MemSetInt(mask->brc);
		break;
	case rtf_chcfpat:
		spanPr->shd.put_ForeColor(context->m_colortbl.GetColor(attrValue));
		_MemSetInt(mask->shd);
		break;
	case rtf_chcbpat:
		spanPr->shd.put_BackColor(context->m_colortbl.GetColor(attrValue));
		_MemSetInt(mask->shd);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//---------------------------------------------------------------------------
//��������Ч������


STDMETHODIMP SpanBase_Animtext_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch(attrName)
	{
	case rtf_animtext:		
		spanPr->sfxtText = attrValue;
		_MemSetInt(mask->sfxtText);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//---------------------------------------------------------------------------

STDMETHODIMP SpanBase_AddAttribute(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	HRESULT hr=SpanBase_Font_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;	
	
	hr=SpanBase_Effect_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	
	hr=SpanBase_AllText_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	
	hr=SpanBase_Space_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;

	hr=SpanBase_BrcAndShd_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	
	hr=SpanBase_Animtext_AddAttribute(spanPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	
	hr=SpanBase_Lang_AddAttribute(spanPr, context, attrName, attrValue);
	if(SUCCEEDED(hr))
		return hr;
	return E_UNEXPECTED;
}

// -------------------------------------------------------------------------
STDMETHODIMP Span_AddSpecChar(RtfSpanPr* spanPr,
							  RtfSpanContext* context,
							  RtfControl attrName,
							  int attrValue)
{
	switch (attrName) // ռλ��
	{	
	case rtf_tcf:
		context->AddContent(__X(" \\f "), 3);
		break;
	case rtf_tcl:
		context->AddContent(__X(" \\l "), 3);
		break;
	case rtf_tcn:
		context->AddContent(__X(" \\n "), 3);
		break;
	case rtf_sect:
		context->EndSection();
		break;
	case rtf_par:
		context->EndParagraph();
		break;
	case rtf_chftn:
		context->AddFndEndRef();
		break;
	case rtf_cell:		
		if(!context->m_trow.m_fhoriMerge)
			context->EndCell();
		else
		{
			UINT8 iCurCell = context->m_trow.m_itc;
			if(!context->m_trow.IsIgnoreCell(iCurCell))
			{					
				context->m_backupParaPr.Restore(&(context->m_paraPr));				
				context->EndCell();
			}
			else if(context->m_trow.IstcHoriFirstMerge(iCurCell))
			{
				//���ݶ�������
				context->m_backupParaPr.Backup(context->m_paraPr);
			}
			++context->m_trow.m_itc;
		}
		break;
	case rtf_row:			
		context->EndTableRow();
		break;
	case rtf_nestcell:
		context->EndNestCell();
		break;
	case rtf_chdate:
		{				
			WCHAR szMsg[] = __X(" DATE  \\@ \"M/d/yyyy\"");
			context->AddField(mso_fltDate, szMsg);			
		}
		break;
	case rtf_chdpl:
		{				
			WCHAR szMsg[] = __X(" DATE \\@ \"dddd, MMMM d, yyyy\"");
			context->AddField(mso_fltDate, szMsg);				
		}
		break;
	case rtf_chdpa:
		{				
			WCHAR szMsg[] = __X(" DATE \\@ \"ddd, MMM d, yyyy\"");
			context->AddField(mso_fltDate, szMsg);			
		}
		break;
	case rtf_chtime:			
		{
			WCHAR szMsg[] = __X(" TIME  \\@ \"h:mm:ss am/pm\"");
			context->AddField(mso_fltTime, szMsg);				
		}
		break;
	case rtf_chftnsepc:		
		context->AddPlaceHolder(0x04);		
		break;
	case rtf_chftnsep:			
		context->AddPlaceHolder(0x03);
		break;
	case rtf_chpgn:			
		context->AddPlaceHolder(0);				
		break;
	case rtf_sectnum:			
		context->AddPlaceHolder(0x0C);				
		break;
	case rtf_chatn:
		if(context->GetCurSubdocType() == DW_SUBDOC_ANNOTATION)
			context->AddPlaceHolder(0x05);
		break;
	case rtf_emspace:			
		context->AddPlaceHolder(0x2003);
		break;
	case rtf_enspace:
		context->AddPlaceHolder(0x2002);
		break;
	case rtf_emdash:
		context->AddSpecChar(0x2014);
		break;
	case rtf_endash:
		context->AddSpecChar(0x2013);
		break;
	case rtf_bullet:
		context->AddSpecChar(0x2022);
		break;
	case rtf_lquote:
		context->AddSpecChar(0x2018);
		break;
	case rtf_rquote:			
		context->AddSpecChar(0x2019);
		break;
	case rtf_ldblquote:
		context->AddSpecChar(0x201C);
		break;
	case rtf_rdblquote:	
		context->AddSpecChar(0x201D);			
		break;	
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

#ifndef SetPlainProp
#define SetPlainProp(mem, val)\
{\
	if(!mask.mem)\
	{\
		_MemSetInt(mask.mem);\
		prop->mem = val;\
	}\
}
#endif

STDMETHODIMP AddPlain(RtfSpanPr* prop)
{
	RtfSpanPr::MaskType& mask = prop->mask;		
	SetPlainProp(fBold, ChpxDefault_fBold);	
	SetPlainProp(fItalic, ChpxDefault_fItalic);	
	SetPlainProp(crTextColor, ChpxDefault_crTextColor);	
	SetPlainProp(kul, ChpxDefault_kul);	
	SetPlainProp(crKulColor, ChpxDefault_crKulColor);
	SetPlainProp(kcd, ChpxDefault_kcd);	
	SetPlainProp(fStrike, ChpxDefault_fStrike);
	SetPlainProp(fDStrike, ChpxDefault_fDStrike);
	SetPlainProp(iss, ChpxDefault_iss);
	SetPlainProp(fShadow, ChpxDefault_fShadow);
	SetPlainProp(fOutline, ChpxDefault_fOutline);
	SetPlainProp(fEmboss, ChpxDefault_fEmboss);
	SetPlainProp(fImprint, ChpxDefault_fImprint);
	SetPlainProp(fSmallCaps, ChpxDefault_fSmallCaps);
	SetPlainProp(fCaps, ChpxDefault_fCaps);
	SetPlainProp(fVanish, ChpxDefault_fVanish);
	SetPlainProp(wCharScale, ChpxDefault_wCharScale);
	SetPlainProp(dxaSpace, ChpxDefault_dxaSpace);
	SetPlainProp(hpsPos, ChpxDefault_hpsPos);
	SetPlainProp(hpsKern, ChpxDefault_hpsKern);
	SetPlainProp(fcgrid, ChpxDefault_fcgrid);
	SetPlainProp(sfxtText, ChpxDefault_sfxtText);	
	return S_OK;
}

STDMETHODIMP Span_AddMix(RtfSpanPr* spanPr,
						 RtfSpanContext* context,
						 RtfControl attrName,
						 int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	switch (attrName) // ������
	{	
	case rtf_plain:
		spanPr->Reset();
		AddPlain(spanPr);		
		break;
	case rtf_cs:
		spanPr->istd = attrValue;
		_MemSetInt(mask->istd);
		break;
	case rtf_deleted:
		spanPr->fRMarkDel = attrValue!=0;
		_MemSetInt(mask->fRMarkDel);
		break;
	case rtf_revauthdel:
		spanPr->ibstRMarkDel = attrValue;
		_MemSetInt(mask->ibstRMarkDel);
		break;
	case rtf_revdttmdel:
		{
			union
			{
				UINT32 dttmVal;
				DTTM dttm;
			}dttmDel;
			dttmDel.dttmVal = attrValue;
			spanPr->dttmRMarkDel = dttmDel.dttm;
			_MemSetInt(mask->dttmRMarkDel);
		}		
		break;
	case rtf_revised:
		spanPr->fRMark = attrValue!=0;
		_MemSetInt(mask->fRMark);
		break;
	case rtf_revauth:
		spanPr->ibstRMark = attrValue;
		_MemSetInt(mask->ibstRMark);
		break;
	case rtf_revdttm:
		{
			union
			{
				UINT32 dttmVal;
				DTTM dttm;
			}dttmRev;
			dttmRev.dttmVal = attrValue;
			spanPr->dttmRMark = dttmRev.dttm;
			_MemSetInt(mask->dttmRMark);
		}
		break;
	default:
		return TableRow_AddAttribute(
			context->m_trow,context->m_tblPos, context, attrName, attrValue);
	}
	return S_OK;
}
STDMETHODIMP Span_AddAttribute(
							   RtfSpanPr* spanPr,
							   RtfSpanContext* context,
							   RtfControl attrName,
							   int attrValue)
{
	RtfSpanPr::MaskType* mask = &spanPr->mask;
	HRESULT hr = SpanBase_AddAttribute(spanPr, context, attrName, attrValue);
	if (SUCCEEDED(hr))
	{
		spanPr->fIsDirty = TRUE;
		return hr;
	}
	hr = Span_AddSpecChar(spanPr, context, attrName, attrValue);
	if (SUCCEEDED(hr))
	{		
		return hr;
	}
	hr = Span_AddMix(spanPr, context, attrName, attrValue);
	if (SUCCEEDED(hr))
	{
		spanPr->fIsDirty = TRUE;
		return hr;	
	}
	return E_UNEXPECTED;
}