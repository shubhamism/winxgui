/* -------------------------------------------------------------------------
//	�ļ���		��	group_textstream.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 1:29:10
//	��������	��	
//
//	$Id: group_textstream.h,v 1.32 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_TEXTSTREAM_H__
#define __GROUP_TEXTSTREAM_H__


#ifndef __GROUP_SHPPICT_H__
#include "../drawing/group_shppict.h"
#endif

#ifndef __GROUP_BOOKMARK_H__
#include "../bookmark/group_bookmark.h"
#endif

// -------------------------------------------------------------------------
class Group_field;
class Group_tc;
class Group_shppict;
class Group_shp_toplevel;
class Group_object;
class RtfGroup_footnote;
class RtfGroup_atrfstart;
class RtfGroup_atrfend;
class RtfGroup_atnid;
class RtfGroup_atnauthor;
class RtfGroup_annotation;
class Group_nesttableprops;
class Group_field2;
class Group_TextStream : public Group_Base
{
protected:
	RtfGrpObject<Group_bkmkstart> m_bkmkstart;
	RtfGrpObject<Group_bkmkend> m_bkmkend;
	RtfGrpObject<Group_uc> m_uc;
	
	Group_nesttableprops* m_nesttableprops;
	Group_object* m_object;
	Group_field2* m_field;
	Group_tc* m_tc;
	Group_shppict* m_shppict;
	Group_shp_toplevel* m_shp;	
	RtfGroup_footnote* m_footnote;
	Group_TextStream* m_subTextStrm;
	ks_string m_incPicPath;
	// annotation
	RtfGroup_atrfstart* m_atrfstart;
	RtfGroup_atrfend* m_atrfend;
	RtfGroup_atnid* m_atnid;
	RtfGroup_atnauthor* m_atnauthor;
	RtfGroup_annotation* m_annotation;
	
	RtfBackup_RtfSpanPr m_spanPrBackup;
	RtfBackup_RtfParaPr m_paraPrBackup;
	RtfBackup_RtfTableRowPr m_trowBackup;
	RtfBackup_RtfTablePos m_tblPosBackup;
	RtfBackup_RtfSpanPr m_spanPrParaStyleBackup;	
public:
	RtfDocument* m_doc;
	Group_TextStream();
	~Group_TextStream();
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue, 
		int& fDest);

	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);

	STDMETHODIMP AddContent(
		LPCWSTR pContent,
		int cch);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,		
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
	
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
//	$Log: group_textstream.h,v $
//	Revision 1.32  2006/09/11 08:00:23  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.31  2006/08/30 08:19:24  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.30  2006/07/31 06:29:16  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.29  2006/07/03 06:50:46  xulingjiao
//	�޸�IncludePicture��ͼƬ��ʾ������������
//	
//	Revision 1.28  2006/06/30 14:24:11  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.27  2006/06/30 09:42:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.26  2006/06/05 07:35:14  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.25  2006/06/05 06:47:00  xulingjiao
//	�޸������BUG
//	
//	Revision 1.24  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.23  2006/03/21 04:22:53  xulingjiao
//	�޸��û�������BUG
//	
//	Revision 1.22  2006/03/10 01:05:20  xulingjiao
//	�����ͼƬ��ʧ
//	
//	Revision 1.21  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.20  2006/03/01 01:49:56  xulingjiao
//	�޸����BUG
//	
//	Revision 1.19  2006/02/27 08:19:51  xulingjiao
//	rtfreader����mask
//	

#endif /* __GROUP_TEXTSTREAM_H__ */
