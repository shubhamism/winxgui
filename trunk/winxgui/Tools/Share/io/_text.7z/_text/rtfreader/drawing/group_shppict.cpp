/* -------------------------------------------------------------------------
//	�ļ���		��	group_shppict.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-10 16:38:21
//	��������	��	
//
//	$Id: group_shppict.cpp,v 1.22 2006/08/03 02:08:32 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_shppict.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Group_picprop

STDMETHODIMP Group_picprop::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	switch (attrName)
	{
	case rtf_defshp:
		m_fDefShape = (attrValue != 0);
		break;	
	case rtf_shplid:
		// ��¼SHAPE ID
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_picprop::EnterSubGroup(
						   RtfControl grSubName,						   
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_sp:
		*ppsubGroup = &m_sp;
		m_sp.m_doc = m_doc;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_pict
STDMETHODIMP Group_pict::AddBinary(
								   LPCVOID pData,
								   int cbData)
{	
	if (!m_picprop.m_fDefShape)
	{		
		m_blip = m_doc->GetBlipStore().NewBlip(pData, cbData, m_blipType);
		ASSERT(m_blip.Good());
	}
	return S_OK;
}

STDMETHODIMP Group_pict::EnterSubGroup(
						   RtfControl grSubName,						   
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_picprop:
		{			
			*ppsubGroup = &m_picprop;
			m_picprop.m_doc = m_doc;
			m_picprop.m_sp.Init(&m_opt, &m_info);
		}
		break;
	case rtf_blipuid:
		*ppsubGroup = &_group_skipped;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP_(void) Group_pict::_AddPict()
{
	if(m_doc->GetCurrentFieldType() != mso_fltIncludePicture)
	{
		KDWShape shape = m_doc->AddInlinePicture(
		MulDiv(m_info.m_cxaShape, m_info.m_picscalex, 100),
		MulDiv(m_info.m_cyaShape, m_info.m_picscaley, 100)
		);
		if(m_blip.Good())
			m_opt.m_opt[0].AddPropFix(msopt_pib, m_blip);
		m_opt.UpdateShape(shape);		
	}
	else
	{
		m_doc->m_includePictureOpt = m_info;
	}
}

STDMETHODIMP Group_pict::EndGroup()
{		
	_AddPict();
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_shppict

STDMETHODIMP Group_shppict::EnterSubGroup(
										  RtfControl grSubName,										  
										  BOOL fDest1987,
										  RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_pict:
		*ppsubGroup = &m_pict;
		m_pict.m_opt.Reset();
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}
