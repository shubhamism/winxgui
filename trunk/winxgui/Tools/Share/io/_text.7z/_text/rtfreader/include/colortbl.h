/* -------------------------------------------------------------------------
//	�ļ���		��	colortbl.h
//	������		��	���὿
//	����ʱ��	��	2006-2-26 22:12:09
//	��������	��	
//
//	$Id: colortbl.h,v 1.1 2006/02/27 01:53:01 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFRCOLORTBL_H__
#define __RTFRCOLORTBL_H__

// class RtfColorTable - ��ɫ��
class RtfColorTable
{
private:
	std::vector<COLORREF> m_colors;
public:
	STDMETHODIMP_(void) Reset(){m_colors.clear();}	
	STDMETHODIMP_(void) Add(COLORREF rgb){m_colors.push_back(rgb);}
	STDMETHODIMP_(void) AddDefault(){m_colors.push_back(RtfDefaultColor);}
	STDMETHODIMP_(COLORREF) GetColor(UINT index) const
	{
		if (index < m_colors.size())
			return m_colors[index];
		else
			return RtfDefaultColor;
	}
};
// -------------------------------------------------------------------------
//	$Log: colortbl.h,v $
//	Revision 1.1  2006/02/27 01:53:01  xulingjiao
//	��������
//	

#endif /* __COLORTBL_H__ */
