/* -------------------------------------------------------------------------
//	�ļ���		��	group_fldinst2.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-30 17:01:06
//	��������	��	
//
//	$Id: group_fldinst2.cpp,v 1.11 2006/09/21 06:29:05 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <mso/filefmt/word/field/fieldinstr.h>
#include "group_fldinst2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP_(int) Group_fldinst2::GetCp()
{
	return m_cpFldinstStart;
}

STDMETHODIMP_(ks_wstring&) Group_fldinst2::GetIncludePicturePath()
{
	return m_incPic;
}

STDMETHODIMP Group_fldinst2::StartGroup(
		RtfControl grName,
		int grValue, 
		int& fDest)
{
	m_incPic.clear();
	m_cpFldinstStart = m_doc->GetFcMax();
	return Group_TextStream::StartGroup(grName, grValue, fDest);
}

STDMETHODIMP Group_fldinst2::AddContent(
		LPCSTR pContent,
		int cch)
{	
	m_doc->AddContent(pContent, cch, m_doc->m_dop.DefCodePage);
	return S_OK;
}

STDMETHODIMP Group_fldinst2::EndGroup()
{
	m_incPic.clear();
	const KDWTextPool& textpool = m_doc->GetCurSubdoc()->TextPool();
	INT cpMax = textpool.size();
	CP cpFldinst;
	m_doc->GetCpFieldInst(cpFldinst, m_cpFldinstStart);
	WCHAR wch;
	WCHAR strFLT[MAX_PATH] = __X("");
	INT iStrFLT = 0;
	while(cpFldinst<cpMax)
	{
		wch = textpool[cpFldinst];
		if(isalpha(wch))
			break;
		if(wch == '=')
			break;
		++cpFldinst;
	}	
	while(cpFldinst<cpMax)
	{
		wch = textpool[cpFldinst];
		if(!isalpha(wch))
		{
			if(wch == '=')
				strFLT[iStrFLT++] = wch;
			break;
		}
		strFLT[iStrFLT++] = wch;
		++cpFldinst;
	}
	strFLT[iStrFLT] = '\0';
	USES_CONVERSION;
	FLT flt;
	HRESULT hr = _GetFLT(flt, W2A(strFLT), iStrFLT);	
	if(flt == mso_fltIncludePicture)
	{
		int count = 0, go=1;
		while(cpFldinst<cpMax && go)
		{
			wch = textpool[cpFldinst];
			switch(wch)
			{
			case '\\':
				if(count%2)
				{
					m_incPic.append(1, wch);
					++cpFldinst;
				}
				else
				{
					if(m_incPic.empty())
						cpFldinst=_SkipSwitch(textpool, cpFldinst);
					else
						go = 0;
				}				
				break;
			case '\"':
				++count;
				if(count%2)
					m_incPic.clear();
				else
					go=0;
				++cpFldinst;
				break;
			default:
				if(count%2)
				{
					m_incPic.append(1, wch);
					++cpFldinst;
				}
				else
				{
					if(isspace(wch))
					{						
						if(m_incPic.empty())
						{
							++cpFldinst;
							continue;
						}					
					}
					m_incPic.append(1, wch);
					++cpFldinst;
				}		
				break;
			}
		}
	}	
	m_doc->SetCurrentFieldType(flt);
	return Group_TextStream::EndGroup();
}