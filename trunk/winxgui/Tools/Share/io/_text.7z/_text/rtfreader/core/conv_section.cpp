/* -------------------------------------------------------------------------
//	�ļ���		��	conv_section.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-23 14:28:48
//	��������	��	
//
//	$Id: conv_section.cpp,v 1.32 2006/08/03 09:26:37 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#if (0)
#define RTF_NO_SEPX
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP ConvertSepx(KDWPropBuffer& propx, RtfSectionPr* sec)
{		
	AddPropFixNotDefval(propx, sprmSBkc, sec->bkc, SectDefault_bkc);
	AddPropFixNotDefval(propx, sprmSFTitlePage, sec->fTitlePage, SectDefault_fTitlePage);
	AddPropFixNotDefval(propx, sprmSFEndnote, sec->fEndNote, SectDefault_fEndNote);
	AddPropFixNotDefval(propx, sprmSDmBinOther, sec->dmBinOther, SectDefault_dmBinOther);
	AddPropFixNotDefval(propx, sprmSDmBinFirst, sec->dmBinFirst, SectDefault_dmBinFirst);
	AddPropFixNotDefval(propx, sprmSiHeadingPgn, sec->iHeadingPgn, SectDefault_iHeadingPgn);
	AddPropFixNotDefval(propx, sprmScnsPgn, sec->cnsPgn, SectDefault_cnsPgn);
	AddPropFixNotDefval(propx, sprmSNfcPgn, sec->nfcPgn, SectDefault_nfcPgn);
	AddPropFixWhatEver(propx, sprmSPgnStart, sec->pgnStart);
	AddPropFixNotDefval(propx, sprmSFPgnRestart, sec->fPgnRestart, SectDefault_fPgnRestart);
	AddPropFixNotDefval(propx, sprmSNLnnMod, sec->nLnnMod, SectDefault_nLnnMod);
	AddPropFixNotDefval(propx, sprmSLnnMin, sec->lnnMin, SectDefault_lnnMin);	
	AddPropFixNotDefval(propx, sprmSDxaLnn, sec->dxaLnn, 0);
	AddPropFixNotDefval(propx, sprmSLnc, sec->lnc, SectDefault_lnc);
	AddPropFixWhatEver(propx, sprmSXaPage, sec->xaPage);
	AddPropFixWhatEver(propx, sprmSYaPage, sec->yaPage);
	AddPropFixWhatEver(propx, sprmSDxaLeft, sec->dxaLeft);
	AddPropFixWhatEver(propx, sprmSDxaRight, sec->dxaRight);
	AddPropFixWhatEver(propx, sprmSDyaTop, sec->dyaTop);
	AddPropFixWhatEver(propx, sprmSDyaBottom, sec->dyaBottom);
	AddPropFixWhatEver(propx, sprmSDzaGutter, sec->dzaGutter);
	AddPropFixWhatEver(propx, sprmSDyaHdrTop, sec->dyaHdrTop);
	AddPropFixWhatEver(propx, sprmSDyaHdrBottom, sec->dyaHdrBottom);
	AddPropFixNotDefval(propx, sprmSVjc, sec->vjc, SectDefault_vjc);
	AddPropFixNotDefval(propx, sprmSFBiDi, sec->fBiDi, SectDefault_fBiDi);
	AddPropFixNotDefval(propx, sprmSTextFlow, sec->wTextFlow, SectDefault_wTextFlow);
	AddPropFixNotDefval(propx, sprmSDxtCharSpace, sec->dxtCharSpace, SectDefault_dxtCharSpace);
	AddPropFixNotDefval(propx, sprmSDyaLinePitch, sec->dyaLinePitch, SectDefault_dyaLinePitch);
	AddPropFixNotDefval(propx, sprmSFNPos, sec->FNPos, SectDefault_FNPos);
	AddPropFixNotDefval(propx, sprmSFNNumFmt, sec->FNNumFmt, SectDefault_FNNumFmt);
	AddPropFixNotDefval(propx, sprmSENNumFmt, sec->ENNumFmt, SectDefault_ENNumFmt);
	AddPropFixNotDefval(propx, sprmSFNNumStart, sec->FNNumStart, SectDefault_FNNumStart);
	AddPropFixNotDefval(propx, sprmSENStart, sec->ENStart, SectDefault_ENStart);
	AddPropFixNotDefval(propx, sprmSFNRestart, sec->FNRestart, SectDefault_FNRestart);
	AddPropFixNotDefval(propx, sprmSENRestart, sec->ENRestart, SectDefault_ENRestart);
	AddPropFixNotDefval(propx, sprmSDmPaperReq, sec->dmPaperReq, SectDefault_dmPaperReq);
	if(sec->dmOrientPage==2)
		propx.AddPropFix(sprmSBOrientation, sec->dmOrientPage);
	//βעλ�������ĵ�����@todo
	AddPropFixNotDefval(propx, sprmSClm, sec->clm, SectDefault_clm);
	AddPropFixNotDefval(propx, sprmSLBetween, sec->fLBetween, SectDefault_fLBetween);
	AddPropFixNotDefval(propx, sprmSCcolumns, sec->ccolM1, SectDefault_ccolM1);
	AddPropFixNotDefval(propx, sprmSDxaColumns, sec->dxaColumns, SectDefault_dxaColumns);	
	//-----------------����
	AddPropFixNotDefval(propx, sprmSFEvenlySpaced, sec->fEvenlySpaced, SectDefault_fEvenlySpaced);
	{
		int i;		
		for(i=0; i<sec->iColWidth; ++i)
		{
			union
			{
				INT32 width;
				struct
				{
					INT32 iCol : 8;
					INT32 dxaColWidth : 16;
					INT32 reserve : 8;
				};
			};
			iCol = i;
			dxaColWidth = sec->rgdxaColumnWidth[i];
			reserve = 0;		
			propx.AddPropFix(sprmSDxaColWidth,width);
		}
		for(i=0; i<sec->iColSpace; ++i)
		{
			union
			{
				INT32 spa;
				struct
				{
					INT32 iCol : 8;
					INT32 dxaColSpacing : 16;
					INT32 reserve : 8;
				};
			};
			iCol = i;
			dxaColSpacing = sec->rgdxaColumnSpace[i];
			reserve = 0;
			propx.AddPropFix(sprmSDxaColSpacing,spa);
		}	
	}
	{
		UINT32& topVal = (UINT32&)sec->brcTop.get_Brc();
		if(topVal != 0)
		{
			propx.AddPropFix(sprmSBrcTop,topVal);
			propx.AddPropVar(sprmSBrcTopEx,&sec->brcTop,sizeof(KDWBrc));
		}
	}
	{
		UINT32& bottomVal = (UINT32&)sec->brcBottom.get_Brc();
		if(bottomVal != 0)
		{
			propx.AddPropFix(sprmSBrcBottom, bottomVal);
			propx.AddPropVar(sprmSBrcBottomEx,&sec->brcBottom,sizeof(KDWBrc));
		}
	}
	{
		UINT32& leftVal = (UINT32&)sec->brcLeft.get_Brc();
		if(leftVal != 0)
		{
			propx.AddPropFix(sprmSBrcLeft, leftVal);
			propx.AddPropVar(sprmSBrcLeftEx,&sec->brcLeft,sizeof(KDWBrc));
		}
	}
	{
		UINT32& rightVal = (UINT32&)sec->brcRight.get_Brc();
		if(rightVal != 0)
		{
			propx.AddPropFix(sprmSBrcRight, rightVal);
			propx.AddPropVar(sprmSBrcRightEx,&sec->brcRight,sizeof(KDWBrc));
		}
	}

	{
		USHORT pgbVal = sec->pgbProp.pgbProp;
		if(pgbVal && pgbVal != 0x20)
			propx.AddPropFix(sprmSPgbProp, pgbVal);
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: conv_section.cpp,v $
//	Revision 1.32  2006/08/03 09:26:37  xulingjiao
//	�޸�����rtf�ļ��򲻿���BUG
//	
//	Revision 1.31  2006/03/01 01:49:56  xulingjiao
//	�޸����BUG
//	
//	Revision 1.30  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	