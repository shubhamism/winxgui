/* -------------------------------------------------------------------------
//	�ļ���		��	group_footnote.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-6 13:11:51
//	��������	��	
//
//	$Id: group_footnote.cpp,v 1.12 2006/09/21 10:42:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_footnote.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP RtfGroup_footnote::StartGroup(
		RtfControl grName,
		int grValue, 
		int& fDest)
{
	m_doc->m_rtf_subdoc = DW_SUBDOC_FOOTNOTE;
	m_doc->m_fHaveEnter = FALSE;	
	return Group_TextStream::StartGroup(grName, grValue, fDest);
}

STDMETHODIMP RtfGroup_footnote::AddAttribute(
		RtfControl attrName,
		int attrValue)
{
	switch(attrName)
	{
	case rtf_ftnalt:
		m_doc->m_rtf_subdoc = DW_SUBDOC_ENDNOTE;
		break;
	}
	return Group_TextStream::AddAttribute(attrName, attrValue);
}

STDMETHODIMP RtfGroup_footnote::EnterFootEndNote()
{		
	return m_doc->EnterFndEndBody(m_doc->m_rtf_subdoc);
}

STDMETHODIMP RtfGroup_footnote::AddContent(
		LPCWSTR pContent,
		int cch)
{
	EnterFootEndNote();
	return Group_TextStream::AddContent(pContent, cch);
}

STDMETHODIMP RtfGroup_footnote::AddContent(
		LPCSTR pContent,
		int cch)
{
	EnterFootEndNote();
	return Group_TextStream::AddContent(pContent, cch);
}

STDMETHODIMP RtfGroup_footnote::EnterSubGroup(
		RtfControl grSubName,		
		BOOL fDest1987,
		RtfGroup** ppsubGroup)
{
	EnterFootEndNote();
	return Group_TextStream::EnterSubGroup(grSubName, fDest1987, ppsubGroup);
}

STDMETHODIMP RtfGroup_footnote::EndGroup()
{
	EnterFootEndNote();
	m_doc->m_paraPr.fInTable = 0;
	m_doc->m_paraPr.nTableLayer = 0;
	m_doc->EndParagraph();
	Group_TextStream::EndGroup();
	m_doc->LeaveFndEndBody();	
	return S_OK;
}