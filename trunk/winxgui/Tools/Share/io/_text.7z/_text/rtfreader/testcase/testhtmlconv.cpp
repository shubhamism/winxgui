/* -------------------------------------------------------------------------
//	�ļ���		��	htmlconv.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-30 10:23:13
//	��������	��	
//
//	$Id: testhtmlconv.cpp,v 1.10 2006/06/14 03:32:58 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class Htmlconv : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(Htmlconv);		
		CPPUNIT_TEST(testTest);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:	
	void testTest()
	{
		testRtf2DocFile("htmlconv/�»���.htm.rtf", 
			"�»���.htm.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(Htmlconv);
// -------------------------------------------------------------------------
//	$Log: testhtmlconv.cpp,v $
//	Revision 1.10  2006/06/14 03:32:58  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.9  2006/03/21 04:22:53  xulingjiao
//	�޸��û�������BUG
//	
//	Revision 1.8  2006/03/14 09:37:13  xulingjiao
//	�޸�html2rtf�����BUG
//	
//	Revision 1.7  2005/05/18 01:47:31  xulingjiao
//	*** empty log message ***
//	