/* -------------------------------------------------------------------------
//	�ļ���		��	prop_section.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 16:39:28
//	��������	��	
//
//	$Id: prop_section.cpp,v 1.49 2006/08/03 09:26:37 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP Section_PageNumber_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_pgndec:	//---ҳ���Ÿ�ʽ
		sectPr->nfcPgn = mso_nfcArabic;
		break;
	case rtf_pgnucrm:
		sectPr->nfcPgn = mso_nfcUCRoman;		
		break;
	case rtf_pgnlcrm:
		sectPr->nfcPgn = mso_nfcLCRoman;
		break;
	case rtf_pgnucltr:
		sectPr->nfcPgn = mso_nfcUCLetter;
		break;
	case rtf_pgnlcltr:
		sectPr->nfcPgn = mso_nfcLCLetter;
		break;
	case rtf_pgnbidia:
		break;
	//case rtf_pgnbidib:
	//	break;
	case rtf_pgnid:
		sectPr->nfcPgn = mso_nfcNumInDash;
		break;
	case rtf_pgnchosung:
		sectPr->nfcPgn = mso_nfcChosung;
		break;
	case rtf_pgncnum:
		sectPr->nfcPgn = mso_nfcCirclenum;
		break;
	case rtf_pgndbnum:
		sectPr->nfcPgn = mso_nfcDbNum1;
		break;
	case rtf_pgndbnumd:
		sectPr->nfcPgn = mso_nfcDbNum2;
		break;
	case rtf_pgndbnumt:
		sectPr->nfcPgn = mso_nfcDbNum3;
		break;
	case rtf_pgndbnumk:
		sectPr->nfcPgn = mso_nfcDbNum4;
		break;
	case rtf_pgndecd:
		sectPr->nfcPgn = mso_nfcDbChar;
		break;
	case rtf_pgnganada:
		sectPr->nfcPgn = mso_nfcGanada;
		break;
	case rtf_pgnzodiac:
		sectPr->nfcPgn = mso_nfcZodiac1;
		break;
	case rtf_pgnzodiacd:
		sectPr->nfcPgn = mso_nfcZodiac2;
		break;
	case rtf_pgngbnum:
		sectPr->nfcPgn = mso_nfcGB1;
		break;
	case rtf_pgngbnumd:
		sectPr->nfcPgn = mso_nfcGB2;
		break;
	case rtf_pgngbnuml:
		sectPr->nfcPgn = mso_nfcGB3;
		break;
	case rtf_pgngbnumk:
		sectPr->nfcPgn = mso_nfcGB4;
		break;
	case rtf_pgnzodiacl:
		sectPr->nfcPgn = mso_nfcZodiac3;
		break;
	case rtf_pgnrestart:	//---ҳ�����¿�ʼ
		sectPr->fPgnRestart = 1;
		break;
	case rtf_pgncont:		//---��ǰ��		
		sectPr->fPgnRestart = 0;
		break;
	case rtf_pgnstarts:		//---��ʼҳ��
		sectPr->pgnStart = attrValue;
		break;
	case rtf_pgnhn:			//---�½���ʼ��ʽ@todo��ȷ��		
		sectPr->iHeadingPgn = attrValue;
		break;
	case rtf_pgnhnsh:		//---ʹ�÷ָ���@todo��ȷ��
		sectPr->cnsPgn = mso_cnsPgnHyphenSep;
		break;
	case rtf_pgnhnsp:
		sectPr->cnsPgn = mso_cnsPgnPeriodSep;
		break;
	case rtf_pgnhnsc:
		sectPr->cnsPgn = mso_cnsPgnColonSep;
		break;
	case rtf_pgnhnsm:
		sectPr->cnsPgn = mso_cnsPgnEmdashSep;
		break;
	case rtf_pgnhnsn:
		sectPr->cnsPgn = mso_cnsPgnHnsnSep;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

//�ֽڷ�����OK

STDMETHODIMP Section_SectBreakType_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_sbknone:
		sectPr->bkc = mso_sbknone;
		break;
	case rtf_sbkcol:
		sectPr->bkc = mso_sbkcol;
		break;
	case rtf_sbkpage:
		sectPr->bkc = mso_sbkpage;
		break;
	case rtf_sbkeven:
		sectPr->bkc = mso_sbkeven;
		break;
	case rtf_sbkodd:
		sectPr->bkc = mso_sbkodd;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP Section_LineNumber_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_linemod:
		sectPr->nLnnMod = attrValue;
		break;
	case rtf_linex:
		sectPr->dxaLnn = attrValue;
		break;
	case rtf_linestarts:
		sectPr->lnnMin = attrValue-1;
		break;
	case rtf_linerestart:
		sectPr->lnc = mso_lnnRestart;
		break;
	case rtf_lineppage:
		sectPr->lnc = mso_lnnPerPage;
		break;
	case rtf_linecont:
		sectPr->lnc = mso_lnnContinue;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP Section_PageInfomation_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_psz:
		sectPr->dmPaperReq = attrValue;
		break;
	case rtf_pgwsxn:
		sectPr->xaPage = attrValue;
		break;
	case rtf_pghsxn:
		sectPr->yaPage = attrValue;
		break;
	case rtf_marglsxn:
		sectPr->dxaLeft = attrValue;
		break;
	case rtf_margrsxn:
		sectPr->dxaRight = attrValue;
		break;
	case rtf_margtsxn:
		sectPr->dyaTop = attrValue;
		break;		
	case rtf_margbsxn:
		sectPr->dyaBottom = attrValue;
		break;
	case rtf_guttersxn:
		sectPr->dzaGutter = attrValue;
		break;
	case rtf_margmirsxn:		//---@todo
		break;
	case rtf_lndscpsxn:			//---@todo		
		sectPr->dmOrientPage = mso_PageLandscape;
		break;
	case rtf_titlepg:		
		sectPr->fTitlePage = (attrValue != 0);
		break;
	case rtf_headery:
		sectPr->dyaHdrTop = attrValue;
		break;
	case rtf_footery:
		sectPr->dyaHdrBottom = attrValue;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP Section_VertAlign_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{		
	switch(attrName)
	{
	case rtf_vertalt:
		sectPr->vjc = mso_PageVertAlignTop;
		break;
	case rtf_vertal:
		sectPr->vjc = mso_PageVertAlignBottom;
		break;
	case rtf_vertalc:
		sectPr->vjc = mso_PageVertCentered;
		break;
	case rtf_vertalj:
		sectPr->vjc = mso_PageVertFullJustified;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP Section_PageBorder_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{	
	switch(attrName)
	{	
	case rtf_pgbrdrt:
		context->m_brc = &sectPr->brcTop;
		break;
	case rtf_pgbrdrb:
		context->m_brc = &sectPr->brcBottom;
		break;
	case rtf_pgbrdrl:
		context->m_brc = &sectPr->brcLeft;
		break;
	case rtf_pgbrdrr:
		context->m_brc = &sectPr->brcRight;
		break;
	case rtf_pgbrdropt:
		if(attrValue == 8)
		{
			sectPr->pgbProp.offsetFrom = mso_pgbFromText;
			sectPr->pgbProp.pageDepth = mso_pgbback;
		}
		else if(attrValue == 32)
		{
			sectPr->pgbProp.offsetFrom = mso_pgbFromEdge;
			sectPr->pgbProp.pageDepth = mso_pgbFront;
		}
		else if(attrValue == 40)
		{
			sectPr->pgbProp.offsetFrom = mso_pgbFromEdge;
			sectPr->pgbProp.pageDepth = mso_pgbback;
		}
		else
		{			
			sectPr->pgbProp.applyTo = attrValue;
		}
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Section_Grid_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{		
	switch(attrName)
	{
	case rtf_sectexpand:
		sectPr->dxtCharSpace = attrValue;
		break;
	case rtf_sectlinegrid:
		sectPr->dyaLinePitch = attrValue;
		break;
	case rtf_sectdefaultcl:
		sectPr->clm = mso_gmNoGrid;
		break;
	case rtf_sectspecifycl:
		sectPr->clm = mso_gmLineAndCharGrid;
		break;
	case rtf_sectspecifyl:
		sectPr->clm = mso_gmLineOnly;
		break;
	case rtf_sectspecifygenN:
		sectPr->clm = mso_gmCharGrid;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP Section_Columns_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_cols:
		sectPr->ccolM1 = attrValue - 1;
		break;
	case rtf_colsx:		
		sectPr->dxaColumns = attrValue;
		break;
	case rtf_colno:		
		sectPr->fEvenlySpaced = 0;
		break;
	case rtf_colsr:		
		(sectPr->rgdxaColumnSpace)[sectPr->iColSpace] = attrValue;
		++(sectPr->iColSpace);
		break;
	case rtf_colw:
		(sectPr->rgdxaColumnWidth)[sectPr->iColWidth] = attrValue;
		++(sectPr->iColWidth);
		break;
	case rtf_linebetcol:
		sectPr->fLBetween = attrValue!=0;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Section_Footnote_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_sftnbj:
		sectPr->FNPos = SectDefault_FNPos;
		break;
	case rtf_sftntj:
		sectPr->FNPos = mso_fpcBeneachText;
		break;	
	case rtf_sftnnar:
		sectPr->FNNumFmt = mso_nfcArabic;
		break;
	case rtf_sftnnalc:
		sectPr->FNNumFmt = mso_nfcLCLetter;
		break;
	case rtf_sftnnauc:
		sectPr->FNNumFmt = mso_nfcUCLetter;
		break;
	case rtf_sftnnrlc:
		sectPr->FNNumFmt = mso_nfcLCRoman;
		break;
	case rtf_sftnnruc:
		sectPr->FNNumFmt = mso_nfcUCRoman;
		break;
	case rtf_sftnnchi:
		sectPr->FNNumFmt = mso_nfcChiManSty;
		break;
	case rtf_sftnnchosung:
		sectPr->FNNumFmt = mso_nfcChosung;
		break;
	case rtf_sftnncnum:
		sectPr->FNNumFmt = mso_nfcCirclenum;
		break;
	case rtf_sftnndbnum:
		sectPr->FNNumFmt = mso_nfcDbNum1;
		break;
	case rtf_sftnndbnumd:
		sectPr->FNNumFmt = mso_nfcDbNum2;
		break;
	case rtf_sftnndbnumt:
		sectPr->FNNumFmt = mso_nfcDbNum3;
		break;
	case rtf_sftnndbnumk:
		sectPr->FNNumFmt = mso_nfcDbNum4;
		break;
	case rtf_sftnndbar:
		sectPr->FNNumFmt = mso_nfcDbChar;
		break;
	case rtf_sftnnganada:
		sectPr->FNNumFmt = mso_nfcGanada;
		break;
	case rtf_sftnngbnum:
		sectPr->FNNumFmt = mso_nfcGB1;
		break;
	case rtf_sftnngbnumd:
		sectPr->FNNumFmt = mso_nfcGB2;
		break;
	case rtf_sftnngbnuml:
		sectPr->FNNumFmt = mso_nfcGB3;
		break;
	case rtf_sftnngbnumk:
		sectPr->FNNumFmt = mso_nfcGB4;
		break;
	case rtf_sftnnzodiac:
		sectPr->FNNumFmt = mso_nfcZodiac1;
		break;
	case rtf_sftnnzodiacd:
		sectPr->FNNumFmt = mso_nfcZodiac2;
		break;
	case rtf_sftnnzodiacl:
		sectPr->FNNumFmt = mso_nfcZodiac3;
		break;
	case rtf_sftnstart:
		sectPr->FNNumStart = attrValue;
		break;
	case rtf_sftnrstcont:
		sectPr->FNRestart = mso_FEnt_continue;
		break;
	case rtf_sftnrestart:
		sectPr->FNRestart = mso_FEnt_persect;
		break;
	case rtf_sftnrstpg:
		sectPr->FNRestart = mso_FEnt_perpage;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Section_Endnote_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{	
	case rtf_saftnnar:
		sectPr->ENNumFmt = mso_nfcArabic;
		break;
	case rtf_saftnnalc:
		sectPr->ENNumFmt = mso_nfcLCLetter;
		break;
	case rtf_saftnnauc:
		sectPr->ENNumFmt = mso_nfcUCLetter;
		break;
	case rtf_saftnnrlc:
		sectPr->ENNumFmt = mso_nfcLCRoman;
		break;
	case rtf_saftnnruc:
		sectPr->ENNumFmt = mso_nfcUCRoman;
		break;
	case rtf_saftnnchi:
		sectPr->ENNumFmt = mso_nfcChiManSty;
		break;
	case rtf_saftnnchosung:
		sectPr->ENNumFmt = mso_nfcChosung;
		break;
	case rtf_saftnncnum:
		sectPr->ENNumFmt = mso_nfcCirclenum;
		break;
	case rtf_saftnndbnum:
		sectPr->ENNumFmt = mso_nfcDbNum1;
		break;
	case rtf_saftnndbnumd:
		sectPr->ENNumFmt = mso_nfcDbNum2;
		break;
	case rtf_saftnndbnumt:
		sectPr->ENNumFmt = mso_nfcDbNum3;
		break;
	case rtf_saftnndbnumk:
		sectPr->ENNumFmt = mso_nfcDbNum4;
		break;
	case rtf_saftnndbar:
		sectPr->ENNumFmt = mso_nfcDbChar;
		break;
	case rtf_saftnnganada:
		sectPr->ENNumFmt = mso_nfcGanada;
		break;
	case rtf_saftnngbnum:
		sectPr->ENNumFmt = mso_nfcGB1;
		break;
	case rtf_saftnngbnumd:
		sectPr->ENNumFmt = mso_nfcGB2;
		break;
	case rtf_saftnngbnuml:
		sectPr->ENNumFmt = mso_nfcGB3;
		break;
	case rtf_saftnngbnumk:
		sectPr->ENNumFmt = mso_nfcGB4;
		break;
	case rtf_saftnnzodiac:
		sectPr->ENNumFmt = mso_nfcZodiac1;
		break;
	case rtf_saftnnzodiacd:
		sectPr->ENNumFmt = mso_nfcZodiac2;
		break;
	case rtf_saftnnzodiacl:
		sectPr->ENNumFmt = mso_nfcZodiac3;
		break;	
	case rtf_saftnrestart:
		sectPr->ENRestart = mso_FEnt_persect;
		break;
	case rtf_saftnrstcont:
		sectPr->ENRestart = mso_FEnt_continue;
		break;
	case rtf_saftnstart:
		sectPr->ENStart = attrValue;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Section_Commix_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{
	switch(attrName)
	{
	case rtf_sectd:		
		sectPr->Reset();		
		sectPr->xaPage = context->m_dop.DefXaPage;
		sectPr->yaPage = context->m_dop.DefYaPage;
		sectPr->dxaLeft = context->m_dop.DefDxaLeft;
		sectPr->dxaRight = context->m_dop.DefDxaRight;
		sectPr->dyaTop = context->m_dop.DefDyaTop;
		sectPr->dyaBottom = context->m_dop.DefDyaBottom;
		sectPr->dzaGutter = context->m_dop.DefDzaGutter;
		sectPr->dmOrientPage = context->m_dop.DefDmOrientPage;
		sectPr->pgbProp.offsetFrom = mso_pgbFromText;
		sectPr->pgbProp.pageDepth = mso_pgbFront;
		sectPr->fEndNote = 0;		
		break;
	case rtf_rtlsect:	//---Bidirectional Controls
		sectPr->fBiDi = mso_RTLSECT;
		break;
	case rtf_ltrsect:
		sectPr->fBiDi = mso_LTRSECT;
		break;
	//case rtf_horzsect:
	//	break;
	//case rtf_vertsect:
	//	break;
	case rtf_stextflow:
		sectPr->wTextFlow = attrValue;
		break;
	case rtf_endnhere:
		sectPr->fEndNote = attrValue != 0;
		break;
	case rtf_binfsxn:
		sectPr->dmBinFirst = attrValue;
		break;
	case rtf_binsxn:
		sectPr->dmBinOther = attrValue;
		break;
	case rtf_sectunlocked:		//---@todo
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Section_AddAttribute(
								  RtfSectionPr* sectPr,
								  RtfSectionContext* context,
								  RtfControl attrName,
								  int attrValue)
{	
	HRESULT hr;
	hr = Section_PageNumber_AddAttribute(sectPr,context,attrName,attrValue);	
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_SectBreakType_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_LineNumber_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_PageInfomation_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_VertAlign_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_PageBorder_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_Grid_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_Columns_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_Commix_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_Footnote_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Section_Endnote_AddAttribute(sectPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	return E_UNEXPECTED;
}

// -------------------------------------------------------------------------
//	$Log: prop_section.cpp,v $
//	Revision 1.49  2006/08/03 09:26:37  xulingjiao
//	�޸�����rtf�ļ��򲻿���BUG
//	
//	Revision 1.48  2006/03/24 01:36:24  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.47  2006/03/23 10:46:43  zhuyie
//	�಻����
//	
//	Revision 1.46  2006/03/07 08:35:54  xulingjiao
//	�޸��Ʊ�λ��BUG
//	
//	Revision 1.45  2006/02/27 08:19:51  xulingjiao
//	rtfreader����mask
//	