/* -------------------------------------------------------------------------
//	�ļ���		��	testbookmark.cpp
//	������		��	���὿
//	����ʱ��	��	2005-1-21 11:45:59
//	��������	��	
//
//	$Id: testbookmark.cpp,v 1.3 2005/08/09 02:46:20 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// -------------------------------------------------------------------------
class TestBookmark : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestBookmark);
		CPPUNIT_TEST(testBookmark);
		CPPUNIT_TEST(testExcel);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testExcel()
	{
		testRtf2DocFile("bookmark.excel/��ǩ.excel.rtf", "bookmark_��ǩ.excel.doc");
	}
	
	void testBookmark()
	{
		testRtf2DocFile("bookmark/��ǩ.rtf", "bookmark_��ǩ.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestBookmark);
