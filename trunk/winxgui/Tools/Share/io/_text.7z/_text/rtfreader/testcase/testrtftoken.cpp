/* -------------------------------------------------------------------------
//	�ļ���		��	testrtftoken.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-26 18:38:32
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <mso/io/rtf/reader.h>

using namespace mso_rtf;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

const char rtfData1[] =
"{\\rtf1\\ansi\\ansicpg936\\uc2 \\deff15\\deflang1033\\deflangfe2052\n\
	{\\fonttbl\n\
		{\\f0\\froman\\fcharset0\\fprq2\n\
			{\\*\\panose 02020603050405020304}Times New Roman;\n\
		}\n\
		{\\f15\\fnil\\fcharset134\\fprq2\n\
			{\\*\\panose 02010600030101010101}\\'cb\\'ce\\'cc\\'e5;\n\
		}\n\
		{\\f20\\fnil\\fcharset134\\fprq2\n\
			{\\* \\panose 02010600030101010101}@\\'cb\\'ce\\'cc\\'e5;\n\
		}\n\
		{\\f145\\fnil\\fcharset0\\fprq2 @\\'cb\\'ce\\'cc\\'e5;}\n\
	}\n\
	{\\colortbl;\\red0\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red0\\green255\\blue0;\\red255\\green0\\blue255;\\red255\\green0\\blue0;\\red255\\green255\\blue0;\\red255\\green255\\blue255;\\red0\\green0\\blue128;\\red0\\green128\\blue128;\\red0\\green128\\blue0;\\red128\\green0\\blue128;\\red128\\green0\\blue0;\\red128\\green128\\blue0;\\red128\\green128\\blue128;\\red192\\green192\\blue192;}\n\
	{\\stylesheet\n\
		{\\qj\\nowidctlpar\\aspalpha\\aspnum\\faauto\\adjustright \\fs21\\kerning2\\loch\\af0\\hich\\af0\\dbch\\f15\\cgrid \\snext0 Normal;}\n\
		{\\*\\cs10 \\additive Default Paragraph Font;}\n\
	}\n\
}";

// -------------------------------------------------------------------------

const char* getRtfCtrl(int ctrl)
{
	return "unknown";
}

void printToken(const RTFTOKEN& token)
{
	/*
	rtf_tokenElementStart		= 0x00,	// {\elemN
	rtf_tokenDestElementStart	= 0x80, // {\* \elemN - element with destination mark
	rtf_tokenElementEnd			= 0x01,	// }
	rtf_tokenAttribute			= 0x02,	// \attrN
	rtf_tokenText				= 0x03,	// ...
	*/
	const char* tokenTypes[] =
	{
		"elementStart",
		"elementEnd",
		"attribute",
		"text",
		"destElementStart"
	};
	int iTokenType = (token.type & 0x0f) + (token.type/0x20);
	printf( tokenTypes[iTokenType] );

	switch (token.type)
	{
	case rtf_tokenElementEnd:
		break;
	case rtf_tokenText:
		printf(" 0x%.2x(%c)", token.chVal, token.chVal);
		break;
	default:
		printf(" %s", getRtfCtrl(token.ctrl));
		if (token.lVal != rtf_nilParam)
			printf(" %d", token.lVal);
	}
	printf("\n");
}

// -------------------------------------------------------------------------

class TestRtfToken : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestRtfToken);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void testData(const void* pData, size_t cb)
	{
		RTFTOKEN token;
		KRtfTokenizer rtfToken(pData, cb);
		for (;;)
		{
			HRESULT hr = rtfToken.Token(token);
			if (hr != S_OK)
				break;
			printToken(token);
		}
	}

public:
	void test()
	{
		testData(rtfData1, sizeof(rtfData1));
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestRtfToken);

// -------------------------------------------------------------------------
