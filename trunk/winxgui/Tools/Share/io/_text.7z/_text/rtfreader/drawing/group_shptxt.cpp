/* -------------------------------------------------------------------------
//	�ļ���		��	group_shptxt.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-12 11:53:50
//	��������	��	
//
//	$Id: group_shptxt.cpp,v 1.4 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_shptxt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP Group_shptxt::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{
	m_doc->EnterTextBox(*m_shape);

	return Group_TextStream::StartGroup(grName, grValue, fDest);
}

STDMETHODIMP Group_shptxt::EndGroup()
{
	Group_TextStream::EndGroup();

	return m_doc->LeaveTextBox();
}