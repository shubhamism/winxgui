/* -------------------------------------------------------------------------
//	�ļ���		��	rtftoken.h
//	������		��	���὿
//	����ʱ��	��	2006-6-30 18:52:33
//	��������	��	
//
//	$Id: rtftoken.h,v 1.1 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __RTFTOKEN_H__
#define __RTFTOKEN_H__

template <class _It>
struct RtfToken
{
	_It first;
	_It last;

	RtfToken() {}
	RtfToken(_It the_first, _It the_last)
		: first(the_first), last(the_last)
	{
	}

	bool empty() const
	{
		return first == last;
	}

	void skipws()
	{
		while (first != last && isspace(*first))
			++first;
	}

	template <class _Type>
	bool skip_until(const _Type& value)
	{
		for (; first != last; ++first)
		{
			if (*first == value)
				return true;
		}
		return false;
	}
};

#endif /* __RTFTOKEN_H__ */
