/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-26 18:39:03
//	��������	��	
//
//	$Id: testcommon.h,v 1.10 2006/03/31 01:55:44 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#include <cppunit/cppunit.h>

// -------------------------------------------------------------------------
#if defined(X_RELEASE_CASE) || defined(_DEBUG)
#define TEST_LOG	printf
#else

inline
STDMETHODIMP_(void) _CppUnit_Log(
								 LPCSTR fmt,
								 ...)
{
	va_list arglist;
	va_start(arglist, fmt);
	vprintf(fmt, arglist);
	vfprintf(stderr, fmt, arglist);
	va_end(arglist);
}

#define TEST_LOG	_CppUnit_Log
#endif

// -------------------------------------------------------------------------
// rtfConvert

STDAPI rtfConvert(
				  IN LPCWSTR rtfFile,
				  IN LPCWSTR docFile);

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(DWORD) testConvert(LPCWSTR szRtfFile, LPCWSTR szDocFile)
{
	static LPCSTR lc = setlocale(LC_ALL, "");
	WCHAR szSrcFile[_MAX_PATH];
	WCHAR szDestFile[_MAX_PATH];
	DWORD tickCount;
	{
		DWORD tickStart = GetTickCount();
		HRESULT hr = rtfConvert(
			GetSystemIniPath(szSrcFile, szRtfFile),
			GetSystemIniPath(szDestFile, szDocFile));
		tickCount = GetTickCount() - tickStart;
		ASSERT_OK(hr);
	}

	LPCWSTR szToken = wcsstr(szRtfFile, __X("rtfrw"));
	if (szToken)
		szRtfFile = szToken+6;
	printf("  TickCount = %-4d\t%S\n", tickCount, szRtfFile);
	return tickCount;
}

// -------------------------------------------------------------------------

#define testRtfPath(from)													\
		L"../../../../Test/office/wps/testcase/rtfrw/" L ## from

#define testRtf2DocFile(from, to)											\
	testConvert(															\
		L"../../../../Test/office/wps/testcase/rtfrw/" L ## from,							\
		L"../../../../Test/office/wps/testcase/output/" L ## to )

// -------------------------------------------------------------------------
// $Log: testcommon.h,v $
// Revision 1.10  2006/03/31 01:55:44  xulingjiao
// �޸����BUG
//
// Revision 1.9  2006/03/23 09:41:25  xulingjiao
// �޸�BUG
//
// Revision 1.8  2005/09/12 01:44:43  xulingjiao
// ������ʽ���б��Ķ��BUGs
//
// Revision 1.7  2004/12/28 07:24:58  xushiwei
// ����batchconvert������
//

#endif /* __TESTCOMMON_H__ */
