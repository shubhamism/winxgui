/* -------------------------------------------------------------------------
//	�ļ���		��	group_fonttbl.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 9:44:33
//	��������	��	
//
//	$Id: group_fonttbl.cpp,v 1.28 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_fonttbl.h"
#include "group_rtf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// Group_panose

STDMETHODIMP Group_panose::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{
	fDest |= rtf_destBinaryMask;
	return S_OK;
}

STDMETHODIMP Group_panose::AddBinary(
									 LPCVOID pData,
									 int cbData
									 )
{
	ASSERT(cbData == sizeof(PANOSE));

	if (cbData == sizeof(PANOSE))
	{
		CopyMemory(&m_panose, pData, cbData);
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// Group_falt
STDMETHODIMP Group_falt::StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
{	
	ciACP = m_doc->m_dop.DefCodePage;
	m_altName.clear();
	return S_OK;
}

STDMETHODIMP Group_falt::AddContent(
									LPCSTR pContent,
									int cch)
{
	if (cch > 0 && pContent[cch-1] == ';')
		--cch;
	if (cch > 0 && pContent[cch-1] == '\x09')
		--cch;
	if(_IsPreDefinedCodePage(ciACP))
	{
		for(INT i=0; i<cch; ++i)
			m_altName.append(1, pContent[i]);
	}
	else
	{
		INT len_wide_buf = cch*2+10;
		std::vector<WCHAR> wide_buf(len_wide_buf);
		INT szRet = MultiByteToWideChar(ciACP, 0, pContent, cch, wide_buf.begin(), len_wide_buf);
		m_altName.append(wide_buf.begin(), szRet);
	}	
	return S_OK;
}

// -------------------------------------------------------------------------
// Group_f
STDMETHODIMP Group_f::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{
	fDest = TRUE;
	m_ifont = grValue;
	m_family = 0;
	m_charset = 0;
	m_fontName.clear();
	m_falt.m_altName.clear();	
	ZeroMemory(&m_panose.m_panose, sizeof(PANOSE));
	return S_OK;
}

STDMETHODIMP Group_f::AddContent(
		IN LPCWSTR pContent,
		IN int cch)
{
	m_fontName.append(pContent, cch);
	return S_OK;
}

STDMETHODIMP Group_f::AddContent(
		LPCSTR pContent,
		int cch)
{
	if (pContent[cch-1] == ';')
		--cch;
	if (cch > 0 && pContent[cch-1] == '\x09')
		--cch;	
	DWORD ciACP = _GetCodePage();
	if(_IsPreDefinedCodePage(ciACP))		
	{
		for(INT i=0; i<cch; ++i)
			m_fontName.append(1, pContent[i]);
	}
	else
	{
		INT len_wide_buf = cch*2+10;
		std::vector<WCHAR> wide_buf(len_wide_buf);
		INT szRet = MultiByteToWideChar(ciACP, 0, pContent, cch, wide_buf.begin(), len_wide_buf);
		m_fontName.append(wide_buf.begin(), szRet);
	}
	return S_OK;
}

STDMETHODIMP Group_f::AddAttribute(
		RtfControl attrName,
		int attrValue)
{
	switch(attrName)
	{
	case rtf_fnil:
		m_family = FF_DONTCARE>>4;
		break;
	case rtf_froman:
		m_family = FF_ROMAN>>4;
		break;
	case rtf_fswiss:
		m_family = FF_SWISS>>4;
		break;
	case rtf_fmodern:
		m_family = FF_MODERN>>4;
		break;
	case rtf_fscript:
		m_family = FF_SCRIPT>>4;
		break;
	case rtf_fdecor:
		m_family = FF_DECORATIVE>>4;
		break;	
	case rtf_fcharset:
		m_charset = attrValue;
		break;
	case rtf_fprq:
		break;
	case rtf_fbias:
		break;
	}
	return S_OK;
}
STDMETHODIMP Group_f::EnterSubGroup(
		RtfControl grSubName,		
		BOOL fDest1987,
		RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_panose:
		*ppsubGroup = &m_panose;
		break;
	case rtf_falt:
		*ppsubGroup = &m_falt;
		m_falt.m_doc = m_doc;
		m_falt.ciACP = _GetCodePage();
		break;
	case rtf_uc:
		*ppsubGroup = &m_uc;
		m_uc.m_parent = this;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_f::EndGroup()
{
	const ks_wstring& fontName = m_fontName;

	if (
		fontName.empty() ||
		fontName.at(0) == '@')
	{
		return S_OK;
	}
	
	KDWFont font;
	ZeroMemory(&font, sizeof(font));
	font.name = fontName.c_str();	
	font.panose = m_panose.m_panose;
	font.fTrueType = 1;
	font.charset = m_charset;
	font.family = m_family;
	font.altername = m_falt.m_altName.c_str();
	CHARSETINFO charsetInfo;
	TranslateCharsetInfo((DWORD*)font.charset, &charsetInfo, TCI_SRCCHARSET);
	font.signature = charsetInfo.fs;
	m_doc->NewFont(m_ifont, font);
	return S_OK;
}

// -------------------------------------------------------------------------
// Group_fonttbl

STDMETHODIMP Group_fonttbl::EnterSubGroup(
						   RtfControl grSubName,						   
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_f:
		m_font.m_doc = m_doc;
		*ppsubGroup = &m_font;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: group_fonttbl.cpp,v $
//	Revision 1.28  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.27  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.26  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.25  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	