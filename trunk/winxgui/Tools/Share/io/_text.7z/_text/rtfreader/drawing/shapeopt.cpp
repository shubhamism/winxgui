/* -------------------------------------------------------------------------
//	�ļ���		��	shapeopt.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-10 9:46:49
//	��������	��	
//
//	$Id: shapeopt.cpp,v 1.19 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "shapeopt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// RtfSpInfo Table

#if (0)

static RtfSpInfo _g_spinfo_table[] =
{
	{ msopt_ShapeType, "shapetype", rtf_vtEnum, rtf_ptElse },
	{ msopt_fFillOK, "ffillok", rtf_vtBoolean, rtf_ptProperties },
	{ msopt_fInlineShape, "fInlineShape", rtf_vtBoolean, rtf_ptUDefProperties },
	{ msopt_fillType, "filltype", rtf_vtEnum, rtf_ptProperties },
	{ msopt_fillBlip, "fillblip", rtf_vtPicture, rtf_ptProperties },
	{ msopt_gtextUNICODE, "gtextunicode", rtf_vtString, rtf_ptProperties },
	{ msopt_fPseudoInline, "fpseudoinline", rtf_vtBoolean, rtf_ptUDefProperties },
};

#else

static RtfSpInfo _g_spinfo_table[] =
{

#include "shapeopt.hxx"

};

#endif

// -------------------------------------------------------------------------
// SpNameToInfoMap

STDMETHODIMP_(const RtfSpNameToInfoMap&) SpNameToInfoMap()
{
	static RtfSpNameToInfoMap theMap;

	for (UINT i = 0; i < countof(_g_spinfo_table); ++i)
	{
		ASSERT(
			theMap.count(_g_spinfo_table[i].spName) == 0);

		theMap.insert(
			RtfSpNameToInfoMap::value_type(
				_g_spinfo_table[i].spName,
				_g_spinfo_table+i) );
	}

	return theMap;
}
