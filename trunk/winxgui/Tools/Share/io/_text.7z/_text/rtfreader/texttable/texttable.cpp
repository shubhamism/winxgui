/* -------------------------------------------------------------------------
//	�ļ���		��	texttable.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-29 10:24:14
//	��������	��	
//
//	$Id: texttable.cpp,v 1.47 2006/09/11 08:00:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "texttable.h"
#include "../include/prop_base.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP Group_nesttableprops::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	HRESULT hr = TableRow_AddAttribute(m_doc->m_trow,m_doc->m_tblPos, m_doc, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;
	hr = Brc_AddAttribute(*m_doc->m_brc,m_doc,attrName,attrValue);
	if (SUCCEEDED(hr))
		return hr;
	switch (attrName)
	{
	case rtf_nestrow:
		m_doc->EndTableRow();
		break;
	default:		
		return Group_TextStream::AddAttribute(attrName, attrValue);
	}
	return S_OK;
}

// -------------------------------------------------------------------------

inline
STDMETHODIMP TableCell_AddAttribute(
								   RtfCellPr& cellPr,
								   RtfTableRowPr& trowPr,
								   RtfTableRowContent* context,
								   RtfControl attrName,
								   int attrValue)
{	
	HRESULT hr;
	hr = GetClPattern(cellPr.shd,attrName,attrValue);
	if (SUCCEEDED(hr))
		return hr;	
	switch(attrName)
	{
	case rtf_tcelld:			//---@tocheck
		cellPr.Reset();
		cellPr.shd.put_Normal();
		break;
	case rtf_clNoWrap:
		cellPr.noWrap = (attrValue!=0);		
		break;
	case rtf_clFitText:
		cellPr.tcFitText = (attrValue!=0);
		break;
	case rtf_clwWidth:
		cellPr.tcWidth = attrValue;
		trowPr.typeCellWidth = mso_vetDxa;
		break;
	case rtf_clcbpat:
		cellPr.shd.put_BackColor(context->m_colortbl.GetColor(attrValue));
		break;
	case rtf_clcfpat:
		cellPr.shd.put_ForeColor(context->m_colortbl.GetColor(attrValue));
		break;
	case rtf_clpadl:			//---word���rtf�����⣬��߾����ϱ߾�
		cellPr.tcMar[mso_tcMarginTop].wVal = attrValue;		
		break;
	case rtf_clpadr:
		cellPr.tcMar[mso_tcMarginRight].wVal = attrValue;		
		break;
	case rtf_clpadt:
		cellPr.tcMar[mso_tcMarginLeft].wVal = attrValue;		
		break;
	case rtf_clpadb:
		cellPr.tcMar[mso_tcMarginBottom].wVal = attrValue;		
		break;
	case rtf_clpadfl:			//---word���rtf�����⣬�ϱ߾�����߾�		
		cellPr.tcMar[mso_tcMarginTop].type = attrValue;		
		break;
	case rtf_clpadfr:
		cellPr.tcMar[mso_tcMarginRight].type = attrValue;		
		break;
	case rtf_clpadft:
		cellPr.tcMar[mso_tcMarginLeft].type = attrValue;		
		break;
	case rtf_clpadfb:
		cellPr.tcMar[mso_tcMarginBottom].type = attrValue;		
		break;
	case rtf_cltxlrtb:
		cellPr.textFlow = mso_tcTextFlow_lr2tb;
		break;
	case rtf_cltxtbrl:
		cellPr.textFlow = mso_tcTextFlow_tb2rl;
		break;
	case rtf_cltxbtlr:
		cellPr.textFlow = mso_tcTextFlow_bt2lr;
		break;
	case rtf_cltxlrtbv:
		cellPr.textFlow = mso_tcTextFlow_lr2tb_v;
		break;
	case rtf_cltxtbrlv:
		cellPr.textFlow = mso_tcTextFlow_tb2rl_v;
		break;		
	case rtf_clvertalt:
		cellPr.vertAlign = mso_tcVAlignTop;
		break;
	case rtf_clvertalc:
		cellPr.vertAlign = mso_tcVAlignCenter;
		break;
	case rtf_clvertalb:
		cellPr.vertAlign = mso_tcVAlignBottom;
		break;
	case rtf_clmgf:	
		trowPr.m_fhoriMerge = 1;
		cellPr.horiMerge = mso_tcHoriFirstMerge;
		break;
	case rtf_clmrg:
		cellPr.horiMerge = mso_tcHoriMerged;
		break;
	case rtf_clvmgf:
		cellPr.vertMerge = mso_tcVertFirstMerge;
		break;
	case rtf_clvmrg:
		cellPr.vertMerge = mso_tcVertMerged;
		break;
	case rtf_clbrdrt:
		context->m_brc = &cellPr.tcBorders[mso_tcBrcTop];
		break;
	case rtf_clbrdrb:
		context->m_brc = &cellPr.tcBorders[mso_tcBrcBottom];
		break;
	case rtf_clbrdrl:
		context->m_brc = &cellPr.tcBorders[mso_tcBrcLeft];
		break;
	case rtf_clbrdrr:
		context->m_brc = &cellPr.tcBorders[mso_tcBrcRight];
		break;
	case rtf_cldglu:
		context->m_brc = &cellPr.tcBorders[mso_tcBrcLT2RB];
		break;
	case rtf_cldgll:
		context->m_brc = &cellPr.tcBorders[mso_tcBrcLB2RT];
		break;
	default:		
		return E_UNEXPECTED;
	}	
	return S_OK;
}

STDMETHODIMP TableRow_Position_AddAttribute(
											KDWTablePos& tblPos,
											RtfControl attrName,
											int attrValue)
{
	switch(attrName)
	{
	case rtf_tdfrmtxtLeft:
		tblPos.leftFromText = attrValue;
		break;
	case rtf_tdfrmtxtRight:
		tblPos.rightFromText = attrValue;
		break;
	case rtf_tdfrmtxtTop:
		tblPos.topFromText = attrValue;
		break;
	case rtf_tdfrmtxtBottom:
		tblPos.bottomFromText = attrValue;
		break;		
	case rtf_tabsnoovrlp:
		tblPos.tblOverlap = (attrValue==0);
		break;
	case rtf_tphcol:
		tblPos.pcHorz = mso_pcHorzText;
		break;
	case rtf_tphmrg:
		tblPos.pcHorz = mso_pcHorzMargin;
		break;
	case rtf_tphpg:
		tblPos.pcHorz = mso_pcHorzPage;
		break;
	case rtf_tposx:
	case rtf_tposnegx:
		tblPos.tblpX = attrValue;
		break;
	case rtf_tposy:
	case rtf_tposnegy:
		tblPos.tblpY = attrValue;
		break;
	case rtf_tposxc:
		tblPos.tblpXSpec = mso_posXSpecCenter;
		break;
	case rtf_tposxi:
		tblPos.tblpXSpec = mso_posXSpecInside;
		break;
	case rtf_tposxl:
		tblPos.tblpXSpec = mso_posXSpecLeft;
		break;
	case rtf_tposxo:
		tblPos.tblpXSpec = mso_posXSpecOutside;
		break;
	case rtf_tposxr:
		tblPos.tblpXSpec = mso_posXSpecRight;
		break;	
	case rtf_tposyb:
		tblPos.tblpYSpec = mso_posYSpecBottom;
		break;
	case rtf_tposyc:
		tblPos.tblpYSpec = mso_posYSpecCenter;
		break;
	case rtf_tposyil:
		break;
	case rtf_tposyin:
		tblPos.tblpYSpec = mso_posYSpecInside;
		break;
	case rtf_tposyout:
		tblPos.tblpYSpec = mso_posYSpecOutside;
		break;
	case rtf_tposyt:
		tblPos.tblpYSpec = mso_posYSpecTop;
		break;
	case rtf_tpvmrg:
		tblPos.pcVert = mso_pcVertMargin;
		break;
	case rtf_tpvpara:
		tblPos.pcVert = mso_pcVertText;
		break;
	case rtf_tpvpg:
		tblPos.pcVert = mso_pcVertPage;
		break;
	default:
		return E_UNEXPECTED;
	}	
	return S_OK;
}

STDMETHODIMP TableRow_AddAttribute(
								   RtfTableRowPr& trowPr,
								   RtfTablePos& tblPos,
								   RtfTableRowContent* context,
								   RtfControl attrName,
								   int attrValue)
{		
	RtfCellPr& cellPr = trowPr.GetCurrentCellPr();
	HRESULT hr = TableCell_AddAttribute(cellPr, trowPr,context,attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;
	hr = TableRow_Position_AddAttribute(tblPos,attrName,attrValue);
	if (SUCCEEDED(hr))
		return hr;
	switch (attrName)
	{
	case rtf_trowd:		
		trowPr.Reset();
		tblPos.Reset();		
		break;	
	case rtf_trleft:
		trowPr.tblInd = attrValue;
		break;
	case rtf_cellx:		
		cellPr.dxa = attrValue;		
		trowPr.NewCell();
		break;
	case rtf_clftsWidth:
		trowPr.typeCellWidth = mso_vetDxa;
		break;
	case rtf_trftsWidth:
		trowPr.tblWidth.type = attrValue;
		break;
	case rtf_trwWidth:
		trowPr.tblWidth.wVal = attrValue;
		break;
	case rtf_trqc:				//---������뷽ʽ
		trowPr.jc = mso_jcCenter;
		break;
	case rtf_trql:
		trowPr.jc = mso_jcLeftJustify;
		break;
	case rtf_trqr:
		trowPr.jc = mso_jcRightJustify;
		break;
	case rtf_trspdl:			//---������
	case rtf_trspdr:		
	case rtf_trspdt:		
	case rtf_trspdb:
		trowPr.tblCellSpacing.wVal = attrValue;
		break;
	case rtf_trspdfl:
	case rtf_trspdfr:
	case rtf_trspdft:		
	case rtf_trspdfb:
		trowPr.tblCellSpacing.type = attrValue;
		break;					
	case rtf_trpaddb:
		trowPr.tblCellMar[mso_tcMarginBottom].wVal = attrValue;
		_MemSetInt(trowPr.tblCellMar[mso_tcMarginBottom].mask.wVal);
		break;
	case rtf_trpaddt:
		trowPr.tblCellMar[mso_tcMarginTop].wVal = attrValue;
		_MemSetInt(trowPr.tblCellMar[mso_tcMarginTop].mask.wVal);
		break;
	case rtf_trpaddl:
		trowPr.tblCellMar[mso_tcMarginLeft].wVal = attrValue;
		_MemSetInt(trowPr.tblCellMar[mso_tcMarginLeft].mask.wVal);
		break;
	case rtf_trpaddr:
		trowPr.tblCellMar[mso_tcMarginRight].wVal = attrValue;
		_MemSetInt(trowPr.tblCellMar[mso_tcMarginRight].mask.wVal);
		break;
	case rtf_trpaddfb:
		trowPr.tblCellMar[mso_tcMarginBottom].type = attrValue;
		if(!trowPr.tblCellMar[mso_tcMarginBottom].mask.wVal)
			trowPr.tblCellMar[mso_tcMarginBottom].wVal = 0;
		break;
	case rtf_trpaddft:
		trowPr.tblCellMar[mso_tcMarginTop].type = attrValue;
		if(!trowPr.tblCellMar[mso_tcMarginTop].mask.wVal)
			trowPr.tblCellMar[mso_tcMarginTop].wVal = 0;
		break;
	case rtf_trpaddfl:
		trowPr.tblCellMar[mso_tcMarginLeft].type = attrValue;
		if(!trowPr.tblCellMar[mso_tcMarginLeft].mask.wVal)
			trowPr.tblCellMar[mso_tcMarginLeft].wVal = 0;
		break;
	case rtf_trpaddfr:
		trowPr.tblCellMar[mso_tcMarginRight].type = attrValue;
		if(!trowPr.tblCellMar[mso_tcMarginRight].mask.wVal)
			trowPr.tblCellMar[mso_tcMarginRight].wVal = 0;
		break;
	case rtf_trbrdrt:			//---����߿�
		context->m_brc = &trowPr.tblBorders[mso_tblBrcTop];
		break;
	case rtf_trbrdrb:
		context->m_brc = &trowPr.tblBorders[mso_tblBrcBottom];
		break;
	case rtf_trbrdrl:
		context->m_brc = &trowPr.tblBorders[mso_tblBrcLeft];
		break;
	case rtf_trbrdrr:
		context->m_brc = &trowPr.tblBorders[mso_tblBrcRight];
		break;
	case rtf_trbrdrh:
		context->m_brc = &trowPr.tblBorders[mso_tblBrcHorzInside];
		break;
	case rtf_trbrdrv:
		context->m_brc = &trowPr.tblBorders[mso_tblBrcVertInside];
		break;
	case rtf_trautofit:
		trowPr.tblFixedLayout = (attrValue != 0); 
		break;
	case rtf_trkeep:
		trowPr.cantSplit = attrValue;
		break;
	case rtf_trhdr:
		trowPr.tblHeader = (attrValue !=0 );
		break;		
	case rtf_trrh:
		if(attrValue==0||attrValue==rtf_nilParam)
			trowPr.trHeight.rule = 0;
		else if(attrValue<0)
			trowPr.trHeight.rule = 2;
		else
			trowPr.trHeight.rule = 1;
		trowPr.trHeight.wVal = abs(attrValue);
		break;
	case rtf_trgaph:		//---@todo
		trowPr.dxaGapHalf = attrValue;
		break;
	case rtf_taprtl:		//---@todo
		break;
	case rtf_trkeepfollow:	//---@todo
		break;
	case rtf_trwWidthB:
		trowPr.trwWidthB.wVal = attrValue;	//@add
		break;
	case rtf_trftsWidthB:
		trowPr.trwWidthB.type = attrValue; //@add
		break;
	case rtf_trwWidthA:
		trowPr.trwWidthA.wVal = attrValue;	//@add		
		break;
	case rtf_trftsWidthA:
		trowPr.trwWidthA.type = attrValue;	//@add
		break;
	case rtf_irow:
		break;
	case rtf_ts:
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: texttable.cpp,v $
//	Revision 1.47  2006/09/11 08:00:24  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.46  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.45  2006/06/05 06:47:00  xulingjiao
//	�޸������BUG
//	
//	Revision 1.44  2006/06/01 09:52:33  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.43  2006/06/01 06:19:46  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.42  2006/06/01 06:15:03  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.41  2006/04/07 00:57:26  xulingjiao
//	�޸�25208;25204;25173;25159��BUG�ڽ�ע�ڲ������������BUGrtfreader����������������BUG
//	
//	Revision 1.40  2006/04/03 07:18:15  xulingjiao
//	�޸�BUG
//	
//	Revision 1.39  2006/03/23 09:41:25  xulingjiao
//	�޸�BUG
//	
//	Revision 1.38  2006/02/27 08:19:55  xulingjiao
//	rtfreader����mask
//	