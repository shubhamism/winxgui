/* -------------------------------------------------------------------------
//	�ļ���		��	group_sp.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-29 23:57:35
//	��������	��	
//
//	$Id: group_sp.cpp,v 1.52 2006/09/11 08:00:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <stl/set.h>
#include "gdiplus/include/gdiplus.h"
#include <mso/dom/text/drawing/drawing_helper.h>
#include "group_sp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Group_sn

STDMETHODIMP Group_sn::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{
	fDest |= rtf_destAnsi;
	m_spInfo = NULL;
	m_filltype = msofillSolid;
	return S_OK;
}

STDMETHODIMP Group_sn::AddBinary(
						LPCVOID pContent,
						int cch)
{
	static const RtfSpNameToInfoMap& theMap = SpNameToInfoMap();	

	std::string spName( (LPCSTR)pContent, cch );
	LPSTR spNameLwr = (LPSTR)spName.c_str();
	strlwr(spNameLwr);

	RtfSpNameToInfoMap::const_iterator it = theMap.find(spName);
	if (it != theMap.end())
	{
		m_spInfo = (*it).second;		
	}
	else
	{
#if defined(_DEBUG)
		std::string spName( (LPCSTR)pContent, cch );
		static std::set<std::string> spNameSet;
		if (spNameSet.count(spName) == 0)
		{
			spNameSet.insert(spName);
			REPORT_ONCEVA(
				"����ʶ������: msopt_%s", spName.c_str()
				);
		}
#endif
		m_spInfo = NULL;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_sv_pict

#ifndef TokenBytes
#define TokenBytes(p, cb)			((const char*&)(p) += (cb))
#endif

STDMETHODIMP Group_sv_pict::AddBinary(
									  LPCVOID pData,
									  int cbData)
{	
	Group_sv* pParent = parent_class_ptr(Group_sv, m_pict);
	const RtfSpInfo* spInfo = pParent->m_spInfo;
	ASSERT(spInfo->spValueType == rtf_vtBLIP &&	spInfo->spPropType == rtf_ptProperties);	
	if (spInfo->spValueType != rtf_vtBLIP)
		return E_UNEXPECTED;	
	if(m_blipType == msoblipWMF)
	{
		INT32 filltype;
		pParent->m_opt->m_opt[0].GetProp(msopt_fillType,filltype);
		if(pParent->m_spInfo->spId == msopt_lineFillBlip)
			filltype = msofillPattern;
		if (cbData == 180)	// windows 2003������ͼ��
		{				
			if(filltype == msofillPattern)
			{
				m_blipType = msoblipDIB;
				TokenBytes(pData, 0x56);
				cbData = 0x50;
			}
		}
		else if(cbData == 172)	//windows xp������ͼ��
		{				
			if(filltype == msofillPattern)
			{
				m_blipType = msoblipDIB;
				TokenBytes(pData, 78);
				cbData = 0x50;
			}
		}
	}
	KDWBlip blip = m_doc->GetBlipStore().NewBlip(pData, cbData, m_blipType);
	ASSERT(blip.Good());
	pParent->m_opt->m_opt[0].ForceAddPropFix((PID)spInfo->spId, blip);
	return S_OK;
}

STDMETHODIMP Group_sv_pict::EndGroup()
{	
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_sv
STDMETHODIMP_(LONG) GetNumber(LPCSTR* pContent)
{	
lpp:	
	LONG num = 0, f = 1;
	while(**pContent)
	{
		if(isdigit(**pContent)||**pContent==L'-')
			break;
		++*pContent;
	}
	if(**pContent == L'-')
	{
		f = -1;
		++*pContent;		
		if(!isdigit(**pContent))
			goto lpp;
	}
	while(**pContent)
	{
		if(!isdigit(**pContent))
			break;
		num = num*10 + (**pContent - L'0');
		++*pContent;
	}
	return num*f;
}

STDMETHODIMP_(void*) GetArrayData(LPCSTR pContent,INT* size = NULL, INT* count = NULL)
{
	*size = GetNumber(&pContent);
	*count = GetNumber(&pContent);
	void* pData = malloc(*size * *count);
	if(!pData)
		return NULL;
	int i;
	switch(*size)
	{
	case 8:
		{
			POINT* points = (POINT*)pData;
			for(i = 0; i<*count; ++i)
			{
				points[i].x = GetNumber(&pContent);				
				points[i].y = GetNumber(&pContent);
			}			
		}
		break;
	case 4:
		{
			INT32* pLongs = (INT32*)pData;
			for(i = 0; i<*count; ++i)
			{
				pLongs[i] = GetNumber(&pContent);				 			
			}
		}
		break;
	case 2:
		{
			INT16* pInts = (INT16*)pData;
			for(i = 0; i<*count; ++i)
			{
				pInts[i] = GetNumber(&pContent);				
			}
		}
		break;
	default:
		free(pData);
		return NULL;
	}	
	return pData;
}

STDMETHODIMP_(void) AddPropArray(
								 KDWShapeOPT& opt,
								 PID pid,
								 LPCSTR pContent)
{
	INT sz, count;	
	void* pData = GetArrayData(pContent,&sz,&count);
	if(pData)
	{			
		switch(sz)
		{
		case 8:
			opt.AddPropArray(pid,(POINT*)pData,count);
			break;
		case 4:
			opt.AddPropArray(pid,(INT32*)pData,count);
			break;
		case 2:
			opt.AddPropArray(pid,(INT16*)pData,count);
			break;
		}
		free(pData);
	}
}

STDMETHODIMP Group_sv::StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
{	
	m_wcontent.clear();
	return S_OK;
}

STDMETHODIMP Group_sv::_AddWContent()
{		
	int cch = m_wcontent.size();
	if(!cch)
		return E_FAIL;	
	LPCWSTR pContent = m_wcontent.begin();
	ASSERT(m_spInfo != NULL);	
	switch (m_spInfo->spValueType)
	{
	case rtf_vtI4:
		{
			INT32 longVal = _MsoAscii2Int(pContent, pContent+cch);
			RtfSpPropType propType = m_spInfo->spPropType;
			if (propType == rtf_ptElse)
			{
				m_opt->m_optElse.ForceAddPropFix(
					m_spInfo->spId,
					longVal);
			}
			else
			{
				ASSERT(
					propType == rtf_ptProperties ||
					propType == rtf_ptUDefProperties
					);
				m_opt->m_opt[propType].ForceAddPropFix(
					m_spInfo->spId,
					longVal);
			}
			break;
		}
	case rtf_vtBOOL:
		{
			BOOL fBoolVal = (pContent[0] != '0');
			RtfSpPropType propType = m_spInfo->spPropType;
			if (propType == rtf_ptElse)
			{
				m_opt->m_optElse.ForceAddPropBool(
					m_spInfo->spId,
					fBoolVal);
			}
			else
			{
				ASSERT(
					propType == rtf_ptProperties ||
					propType == rtf_ptUDefProperties
					);
				m_opt->m_opt[propType].ForceAddPropBool(
					m_spInfo->spId,
					fBoolVal);
			}
			break;
		}
	case rtf_vtSTR:
		{
			RtfSpPropType propType = m_spInfo->spPropType;
			ASSERT(
				propType == rtf_ptProperties ||
				propType == rtf_ptUDefProperties
				);
			int nwvec = (cch+1)*2;
			std::vector<char> wvec(nwvec, '\0');
			memcpy(wvec.begin(), pContent, cch*2);
			m_opt->m_opt[propType].AddPropVar(
				m_spInfo->spId,
				wvec.begin(),
				nwvec);
			break;
		}
	case rtf_vtARRAY:
		{
			RtfSpPropType propType = m_spInfo->spPropType;
			ASSERT(
				propType == rtf_ptProperties ||
				propType == rtf_ptUDefProperties
				);
			USES_CONVERSION;
			AddPropArray(
				m_opt->m_opt[propType],
				m_spInfo->spId,
				W2A(pContent));
			break;
		}	
	case rtf_vtHSHP:
		if(m_spInfo->spId == msopt_hspNext)
		{
			INT32 longVal = _MsoAscii2Int(pContent, pContent + cch);
			m_info->m_hspNext = longVal;
		}
		break;
	default:
		{
			// rtf_vtBLIP, rtf_vtHLINK �ǲ����ڴ˳��ֵġ�
			ASSERT(
				m_spInfo->spValueType == rtf_vtSKIP ||
				m_spInfo->spValueType == rtf_vtShapeID);
			return E_UNEXPECTED;
		}
	}
	m_wcontent.clear();
	return S_OK;
}

STDMETHODIMP Group_sv::EndGroup()
{	
	_AddWContent();
	return S_OK;
}

STDMETHODIMP Group_sv::AddContent(
		LPCWSTR pContent,
		int cch)
{
	m_wcontent.append(pContent, cch);
	return S_OK;
}

STDMETHODIMP Group_sv::AddContent(
						LPCSTR pContent,
						int cch)
{
	ks_wstring uni;
	uni.assign((kfc::codepage_type)m_doc->m_dop.DefCodePage, pContent, cch);
	m_wcontent.append(uni);	
	return S_OK;
}

STDMETHODIMP Group_sv::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_pict:
		*ppsubGroup = &m_pict;
		m_pict.m_doc = m_doc;
		break;
	case rtf_hl:
		*ppsubGroup = &m_hl;
		break;
	case rtf_uc:
		*ppsubGroup = &m_uc;
		m_uc.m_parent = this;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_sp

STDMETHODIMP Group_sp::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_sn:
		*ppsubGroup = &m_sn;
		break;
	case rtf_sv:
		if (m_sn.m_spInfo)
		{			
			*ppsubGroup = &m_sv;
			m_sv.m_doc = m_doc;
			m_sv.m_spInfo = m_sn.m_spInfo;
			if(m_sn.m_spInfo->spId == msopt_pib)
				m_sv.m_info->fPIB = TRUE;
		}
		else
			*ppsubGroup = &_group_skipped;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}
