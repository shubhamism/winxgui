/* -------------------------------------------------------------------------
//	�ļ���		��	group_obj.cpp
//	������		��	���὿
//	����ʱ��	��	2006-3-9 20:34:52
//	��������	��	
//
//	$Id: group_obj.cpp,v 1.2 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_obj.h"
#include "group_result.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// -------------------------------------------------------------------------
Group_object::Group_object() : m_result(NULL)
{
}

Group_object::~Group_object()
{
	RTF_DELETE_GROUP(m_result);
}

STDMETHODIMP Group_object::EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_result:
		if(m_result == NULL)
			m_result = RTF_NEW_GROUP(Group_result);
		m_result->m_doc = m_doc;
		*ppsubGroup = m_result;
		break;
	default:
		*ppsubGroup = &_group_skipped;
	}
	return S_OK;
}