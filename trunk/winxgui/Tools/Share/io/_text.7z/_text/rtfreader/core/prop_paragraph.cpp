/* -------------------------------------------------------------------------
//	�ļ���		��	prop_paragraph.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 16:39:13
//	��������	��	
//
//	$Id: prop_paragraph.cpp,v 1.59 2006/09/04 08:28:19 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP Brc_AddAttribute(
							  KDWBrc& brc,
							  RtfAttrBaseContext* context,
							  RtfControl attrName,
							  int attrValue)
{	
	switch(attrName)
	{
	case rtf_brdrnone:
		brc.put_Delete();
		break;
	case rtf_brdrhair:
		brc.brcType = mso_brcSingle;
		brc.dptLineWidth = 2;
		break;
	case rtf_brdrs:		//---BRCTYPE
		brc.brcType = mso_brcSingle;
		break;
	case rtf_brdrdb:
		brc.brcType = mso_brcDouble;
		break;
	case rtf_brdrdot:
		brc.brcType = mso_brcDot;
		break;
	case rtf_brdrdash:
		brc.brcType = mso_brcDashLarge;
		break;
	case rtf_brdrdashsm:
		brc.brcType = mso_brcDashSmall;
		break;
	case rtf_brdrdashd:
		brc.brcType = mso_brcDotDash;
		break;
	case rtf_brdrdashdd:
		brc.brcType = mso_brcDotDotDash;
		break;
	case rtf_brdrtriple:
		brc.brcType = mso_brcTriple;
		break;
	case rtf_brdrtnthsg:
		brc.brcType = mso_brcThinThickSmall;
		break;
	case rtf_brdrthtnsg:
		brc.brcType = mso_brcThickThinSmall;
		break;
	case rtf_brdrtnthtnsg:
		brc.brcType = mso_brcThinThickThinSmall;
		break;
	case rtf_brdrtnthmg:
		brc.brcType = mso_brcThinThickMedium;
		break;
	case rtf_brdrthtnmg:
		brc.brcType = mso_brcThickThinMedium;
		break;
	case rtf_brdrtnthtnmg:
		brc.brcType = mso_brcThinThickThinMedium;
		break;
	case rtf_brdrtnthlg:
		brc.brcType = mso_brcThinThickLarge;
		break;
	case rtf_brdrthtnlg:
		brc.brcType = mso_brcThickThinLarge;
		break;
	case rtf_brdrtnthtnlg:
		brc.brcType = mso_brcThinThickThinLarge;
		break;
	case rtf_brdrwavy:
		brc.brcType = mso_brcWave;
		break;
	case rtf_brdrwavydb:
		brc.brcType = mso_brcDoubleWave;
		break;
	case rtf_brdrdashdotstr:
		brc.brcType = mso_brcDashDotStroked;
		break;
	case rtf_brdremboss:
		brc.brcType = mso_brcEmboss;
		break;
	case rtf_brdrengrave:
		brc.brcType = mso_brcEngrave;
		break;
	case rtf_brdrw:
		brc.dptLineWidth = (attrValue*8)/20;
		break;
	case rtf_brdrsh:		
		brc.fShadow = attrValue;
		break;
	case rtf_brdrcf:
		brc.crFore = context->m_colortbl.GetColor(attrValue);
		break;
	case rtf_brsp:		
		brc.dptSpace = (attrValue+10)/20;
		break;
	case rtf_brdrart:
		brc.brcType = attrValue+63;
		break;
	case rtf_brdroutset:
		brc.brcType = mso_brcOutset;
		break;
	case rtf_brdrinset:
		brc.brcType = mso_brcInset;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP ParaBase_Normal_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_qc:			//---���뷽ʽ
		paraPr->jc = mso_jcCenter;
		_MemSetInt(mask->jc);
		break;
	case rtf_ql:
		paraPr->jc = mso_jcLeftJustify;
		_MemSetInt(mask->jc);		
		break;
	case rtf_qr:
		paraPr->jc = mso_jcRightJustify;
		_MemSetInt(mask->jc);
		break;
	case rtf_qj:
		paraPr->jc = mso_jcLeftAndRightJustify;
		_MemSetInt(mask->jc);
		break;
	case rtf_qd:
		paraPr->jc = mso_jcMediumJustify;
		_MemSetInt(mask->jc);
		break;
	case rtf_outlinelevel:	//---��ټ���		
		paraPr->lvl = attrValue;
		_MemSetInt(mask->lvl);
		break;
	case rtf_ilvl:			//---�Զ����
		paraPr->ilvl = attrValue;
		_MemSetInt(mask->ilvl);
		break;
	case rtf_ls:
		paraPr->ilfo = attrValue;
		_MemSetInt(mask->ilfo);
		if(!mask->ilvl)
		{
			paraPr->ilvl = 0;
			_MemSetInt(mask->ilvl);
		}
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_Indent_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_fi:
		paraPr->dxaLeft1 = attrValue;
		_MemSetInt(mask->dxaLeft1);
		break;
	case rtf_cufi:		
		paraPr->dxaLeft1Rel = attrValue;
		_MemSetInt(mask->dxaLeft1Rel);		
		break;
	case rtf_li:
	case rtf_lin://todo
		paraPr->dxaLeft = attrValue;
		_MemSetInt(mask->dxaLeft);
		break;
	case rtf_culi:		
		paraPr->dxaLeftRel = attrValue;
		_MemSetInt(mask->dxaLeftRel);
		break;
	case rtf_ri:
	case rtf_rin://todo		
		paraPr->dxaRight = attrValue;
		_MemSetInt(mask->dxaRight);
		break;
	case rtf_curi:		
		paraPr->dxaRightRel = attrValue;
		_MemSetInt(mask->dxaRightRel);
		break;
	case rtf_adjustright:
		paraPr->fAdjustRight = attrValue!= 0;
		_MemSetInt(mask->fAdjustRight);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_Space_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_sb:			//���		
		paraPr->dyaBefore = attrValue;
		_MemSetInt(mask->dyaBefore);
		break;
	case rtf_lisb:		
		paraPr->dyaBeforeRel = attrValue;
		_MemSetInt(mask->dyaBeforeRel);
		break;
	case rtf_sa:		
		paraPr->dyaAfter = attrValue;
		_MemSetInt(mask->dyaAfter);
		break;
	case rtf_lisa:		
		paraPr->dyaAfterRel = attrValue;
		_MemSetInt(mask->dyaAfterRel);
		break;
	case rtf_sbauto:				
		paraPr->fAutoSpacingBefore = attrValue!=0;
		_MemSetInt(mask->fAutoSpacingBefore);
		break;
	case rtf_saauto:		
		paraPr->fAutoSpacingAfter = attrValue!=0;
		_MemSetInt(mask->fAutoSpacingAfter);
		break;
	case rtf_sl:		
		paraPr->lspd.dyaLine = attrValue;
		_MemSetInt(mask->lspd);
		break;
	case rtf_slmult:		
		paraPr->lspd.fMultLinespace = attrValue != 0;
		_MemSetInt(mask->lspd);
		break;
	case rtf_nosnaplinegrid:
		paraPr->fUsePgsuSettings = 0;
		_MemSetInt(mask->fUsePgsuSettings);		
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_Page_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{	
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_sbys:
		paraPr->fSideBySide = attrValue!=0;
		_MemSetInt(mask->fSideBySide);
		break;
	case rtf_widctlpar:			//---��ҳ
		paraPr->fWidowControl = 1;
		_MemSetInt(mask->fWidowControl);
		break;
	case rtf_nowidctlpar:		
		paraPr->fWidowControl = 0;
		_MemSetInt(mask->fWidowControl);
		break;
	case rtf_keep:
		paraPr->fKeep = attrValue!=0;
		_MemSetInt(mask->fKeep);
		break;
	case rtf_keepn:		
		paraPr->fKeepFollow = attrValue!=0;
		_MemSetInt(mask->fKeepFollow);
		break;
	case rtf_pagebb:		
		paraPr->fPageBreakBefore = attrValue!=0;
		_MemSetInt(mask->fPageBreakBefore);
		break;
	case rtf_noline:
		paraPr->fNoLnn = attrValue!=0;
		_MemSetInt(mask->fNoLnn);
		break;
	case rtf_hyphpar:		
		paraPr->fNoAutoHyph = attrValue==0;
		_MemSetInt(mask->fNoAutoHyph);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_Chinese_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_nocwrap:			//---���İ�ʽ	
		paraPr->fKinsoku = 0;
		_MemSetInt(mask->fKinsoku);
		break;
	case rtf_nowwrap:
		paraPr->fWordWrap = 0;
		_MemSetInt(mask->fWordWrap);
		break;
	case rtf_nooverflow:
		paraPr->fOverflowPunct = 0;
		_MemSetInt(mask->fOverflowPunct);
		break;
	case rtf_aspalpha:
		paraPr->fAutoSpaceDE = attrValue!=0;
		_MemSetInt(mask->fAutoSpaceDE);
		break;
	case rtf_aspnum:
		paraPr->fAutoSpaceDN = attrValue!=0;
		_MemSetInt(mask->fAutoSpaceDN);
		break;
	case rtf_toplinepunct:
		paraPr->fTopLinePunct = attrValue!=0;
		_MemSetInt(mask->fTopLinePunct);
		break;
	case rtf_faauto:			//---�ı����뷽ʽ
		paraPr->wAlignFont = mso_faauto;
		_MemSetInt(mask->wAlignFont);
		break;
	case rtf_fahang:
		paraPr->wAlignFont = mso_fahanging;
		_MemSetInt(mask->wAlignFont);
		break;
	case rtf_faroman:
		paraPr->wAlignFont = mso_faroman;
		_MemSetInt(mask->wAlignFont);
		break;
	case rtf_favar:
		paraPr->wAlignFont = mso_favariable;
		_MemSetInt(mask->wAlignFont);
		break;
	case rtf_facenter:
		paraPr->wAlignFont = mso_facentered;
		_MemSetInt(mask->wAlignFont);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}


STDMETHODIMP ParaBase_BrcShd_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{	
	RtfParaPr::MaskType* mask = &paraPr->mask;
	HRESULT hr = GetParaPattern(paraPr->shd,attrName,attrValue);
	if(SUCCEEDED(hr))
	{
		_MemSetInt(mask->shd);
		return hr;
	}
	switch(attrName)
	{		
	case rtf_brdrt:			//---����߿�
		context->m_brc = &paraPr->brcTop;
		_MemSetInt(mask->brcTop);
		break;
	case rtf_brdrl:
		context->m_brc = &paraPr->brcLeft;
		_MemSetInt(mask->brcLeft);
		break;
	case rtf_brdrb:
		context->m_brc = &paraPr->brcBottom;
		_MemSetInt(mask->brcBottom);
		break;
	case rtf_brdrr:
		context->m_brc = &paraPr->brcRight;
		_MemSetInt(mask->brcRight);
		break;
	case rtf_brdrbtw:
		context->m_brc = &paraPr->brcBetween;
		_MemSetInt(mask->brcBetween);
		break;
	case rtf_box:
		context->m_brc = &paraPr->brcBox;
		_MemSetInt(mask->brcBox);
		break;
	case rtf_cfpat:
		paraPr->shd.put_ForeColor(context->m_colortbl.GetColor(attrValue));
		_MemSetInt(mask->shd);
		break;
	case rtf_cbpat:
		paraPr->shd.put_BackColor(context->m_colortbl.GetColor(attrValue));
		_MemSetInt(mask->shd);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_Tab_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_tx:
		paraPr->ktab.put_TabPos(attrValue);
		_MemSetInt(mask->ktab);
		break;
	case rtf_jclisttab:
		paraPr->ktab.put_TabJC(mso_tbdListTab);
		_MemSetInt(mask->ktab);
		break;
	case rtf_tqr:
		paraPr->ktab.put_TabJC(mso_tbdRightTab);
		_MemSetInt(mask->ktab);
		break;
	case rtf_tqc:
		paraPr->ktab.put_TabJC(mso_tbdCenteredTab);
		_MemSetInt(mask->ktab);
		break;
	case rtf_tqdec:
		paraPr->ktab.put_TabJC(mso_tbdDecimalTab);
		_MemSetInt(mask->ktab);
		break;
	case rtf_tb:
		paraPr->ktab.put_TabJC(mso_tbdBar);
		paraPr->ktab.put_TabTLC(mso_tbdNoLeader);
		paraPr->ktab.put_TabPos(attrValue);	
		_MemSetInt(mask->ktab);
		break;
	case rtf_tldot:
		paraPr->ktab.put_TabTLC(mso_tbdDottedLeader);
		_MemSetInt(mask->ktab);
		break;
	case rtf_tlhyph:
		paraPr->ktab.put_TabTLC(mso_tbdHyphenatedLeader);
		_MemSetInt(mask->ktab);
		break;
	case rtf_tlul:
		paraPr->ktab.put_TabTLC(mso_tbdSingleLineLeader);
		_MemSetInt(mask->ktab);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Para_Frame_AddAttribute(
							   RtfParaPr* paraPr,
							   RtfParaContext* context,
							   RtfControl attrName,
							   int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch(attrName)
	{
	case rtf_absw:				//---�����ó��Զ�ʱ������
		paraPr->frame.dxaWidth = attrValue;
		_MemSetInt(mask->frame.dxaWidth);
		break;
	case rtf_absh:		
		if(attrValue<0)		
			paraPr->frame.wHeightAbsOprand.fMinHeight = 0;
		else		
			paraPr->frame.wHeightAbsOprand.fMinHeight = 1;
		paraPr->frame.wHeightAbsOprand.dyaHeight = abs(attrValue);
		_MemSetInt(mask->frame.wHeightAbsOprand);
		break;
	case rtf_phmrg:				
		paraPr->frame.ppcOprand.ppc.pcHorz = mso_pcHorzMargin;
		_MemSetInt(mask->frame.ppcOprand);
		break;
	case rtf_phpg:		
		paraPr->frame.ppcOprand.ppc.pcHorz = mso_pcHorzPage;
		_MemSetInt(mask->frame.ppcOprand);
		break;
	case rtf_phcol:		
		paraPr->frame.ppcOprand.ppc.pcHorz = mso_pcHorzText;
		_MemSetInt(mask->frame.ppcOprand);
		break;
	case rtf_pvmrg:		
		paraPr->frame.ppcOprand.ppc.pcVert = mso_pcVertMargin;
		_MemSetInt(mask->frame.ppcOprand);
		break;
	case rtf_pvpg:		
		paraPr->frame.ppcOprand.ppc.pcVert = mso_pcVertPage;
		_MemSetInt(mask->frame.ppcOprand);		
		break;
	case rtf_pvpara:		
		paraPr->frame.ppcOprand.ppc.pcVert = mso_pcVertText;
		_MemSetInt(mask->frame.ppcOprand);
		break;
	case rtf_posx:
		paraPr->frame.dxaAbs = attrValue;
		_MemSetInt(mask->frame.dxaAbs);
		break;
	case rtf_posnegx:
		paraPr->frame.dxaAbs = attrValue;
		_MemSetInt(mask->frame.dxaAbs);
		break;
	case rtf_posxc:		
		paraPr->frame.dxaAbs = mso_posXSpecCenter;
		_MemSetInt(mask->frame.dxaAbs);		
		break;
	case rtf_posxi:
		paraPr->frame.dxaAbs = mso_posXSpecInside;
		_MemSetInt(mask->frame.dxaAbs);
		break;
	case rtf_posxo:
		paraPr->frame.dxaAbs = mso_posXSpecOutside;
		_MemSetInt(mask->frame.dxaAbs);
		break;
	case rtf_posxr:
		paraPr->frame.dxaAbs = mso_posXSpecRight;
		_MemSetInt(mask->frame.dxaAbs);
		break;
	case rtf_posxl:
		paraPr->frame.dxaAbs = mso_posXSpecLeft;
		_MemSetInt(mask->frame.dxaAbs);
		break;	
	case rtf_posy:
		paraPr->frame.dyaAbs = attrValue;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_posnegy:
		paraPr->frame.dyaAbs = attrValue;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_posyt:
		paraPr->frame.dyaAbs = mso_posYSpecTop;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_posyc:
		paraPr->frame.dyaAbs = mso_posYSpecCenter;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_posyb:
		paraPr->frame.dyaAbs = mso_posYSpecBottom;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_posyin:
		paraPr->frame.dyaAbs = mso_posYSpecInside;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_posyout:
		paraPr->frame.dyaAbs = mso_posYSpecOutside;
		_MemSetInt(mask->frame.dyaAbs);
		break;
	case rtf_abslock:		
		paraPr->frame.fLocked = attrValue;
		_MemSetInt(mask->frame.fLocked);
		break;		
	case rtf_nowrap:
		paraPr->frame.wr = mso_wrapTopBottom;
		_MemSetInt(mask->frame.wr);
		break;
	case rtf_overlay:
		paraPr->frame.wr = mso_wrapNone;
		_MemSetInt(mask->frame.wr);
		break;
	case rtf_dxfrtext:
		break;
	case rtf_dfrmtxtx:
		paraPr->frame.dxaFromText = attrValue;
		_MemSetInt(mask->frame.dxaFromText);
		break;
	case rtf_dfrmtxty:
		paraPr->frame.dyaFromText = attrValue;
		_MemSetInt(mask->frame.dyaFromText);
		break;
	case rtf_dropcapli:
		paraPr->frame.dropCap.lines = attrValue;
		_MemSetInt(mask->frame.dropCap);
		break;
	case rtf_dropcapt:
		paraPr->frame.dropCap.fdct = attrValue;
		_MemSetInt(mask->frame.dropCap);
		break;
	case rtf_absnoovrlp:
		paraPr->frame.fabsnoovrlp = (attrValue!=0);
		_MemSetInt(mask->frame.fabsnoovrlp);
		break;
	case rtf_frmtxlrtb:		
		paraPr->frame.textFlow = mso_textflow_lr2tb;
		_MemSetInt(mask->frame.textFlow);
		break;
	case rtf_frmtxtbrl:
		paraPr->frame.textFlow = mso_textflow_tb2rl;
		_MemSetInt(mask->frame.textFlow);
		break;
	case rtf_frmtxbtlr:
		paraPr->frame.textFlow = mso_textflow_bt2lr;
		_MemSetInt(mask->frame.textFlow);
		break;		
	case rtf_frmtxlrtbv:
		paraPr->frame.textFlow = mso_textflow_lr2tb_v;
		_MemSetInt(mask->frame.textFlow);
		break;
	case rtf_frmtxtbrlv:
		paraPr->frame.textFlow = mso_textflow_tb2rl_v;
		_MemSetInt(mask->frame.textFlow);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_Commix_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	switch(attrName)
	{
	case rtf_sbys:
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP ParaBase_AddAttribute(
								   RtfParaPr* paraPr,
								   RtfParaContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	HRESULT hr;
	hr = ParaBase_Normal_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = ParaBase_Indent_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = ParaBase_Space_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = ParaBase_Page_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = ParaBase_Chinese_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = ParaBase_BrcShd_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = ParaBase_Tab_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	hr = Para_Frame_AddAttribute(paraPr,context,attrName,attrValue);
	if(SUCCEEDED(hr))
		return hr;
	return E_UNEXPECTED;
}

#ifndef SetPardProp
#define SetPardProp(mem, val)\
{\
	if(!mask.mem)\
	{\
		_MemSetInt(mask.mem);\
		prop->mem = val;\
	}\
}
#endif

void AddPard(RtfParaPr* prop)
{
	RtfParaPr::MaskType& mask = prop->mask;		
	SetPardProp(dxaLeft, PapxDefault_dxaLeft);
	SetPardProp(dxaLeft1, PapxDefault_dxaLeft1);
	SetPardProp(dxaLeftRel, PapxDefault_dxaLeftRel);
	SetPardProp(dxaRight, PapxDefault_dxaRight);
	SetPardProp(dxaRightRel, PapxDefault_dxaRightRel);
	SetPardProp(dxaLeft1, PapxDefault_dxaLeft1);
	SetPardProp(dxaLeft1Rel, PapxDefault_dxaLeft1Rel);
	SetPardProp(dyaBefore, PapxDefault_dyaBefore);
	SetPardProp(dyaAfter, PapxDefault_dyaAfter);
	if(!mask.lspd)
	{
		_MemSetInt(mask.lspd);
		prop->lspd.dyaLine = 0xF0;
		prop->lspd.fMultLinespace = 1;
	}
	SetPardProp(fUsePgsuSettings, PapxDefault_fUsePgsuSettings);
	SetPardProp(fWidowControl, RtfPapxDefault_fWidowControl);
	SetPardProp(fKeepFollow, PapxDefault_fKeepFollow);
	SetPardProp(fAutoSpaceDE, RtfPapxDefault_fAutoSpaceDE);	
	SetPardProp(fAutoSpaceDN, RtfPapxDefault_fAtuoSpaceDN);	
	if(!mask.brcBetween)
	{
		prop->brcBetween.put_Nil();
		_MemSetInt(mask.brcBetween);
	}
	if(!mask.brcBottom)
	{
		prop->brcBottom.put_Nil();
		_MemSetInt(mask.brcBottom);
	}
	if(!mask.brcBox)
	{
		prop->brcBox.put_Nil();
		_MemSetInt(mask.brcBox);
	}
	if(!mask.brcLeft)
	{
		prop->brcLeft.put_Nil();
		_MemSetInt(mask.brcLeft);
	}
	if(!mask.brcRight)
	{
		prop->brcRight.put_Nil();
		_MemSetInt(mask.brcRight);
	}
	if(!mask.brcTop)
	{
		prop->brcTop.put_Nil();
		_MemSetInt(mask.brcTop);
	}
	SetPardProp(fInTable, 0);
	/*
	SetPardProp(jc, PapxDefault_]jc);
	SetPardProp(lvl, PapxDefault_lvl);
	SetPardProp(dxaLeft, PapxDefault_dxaLeft);
	SetPardProp(dxaLeftRel, PapxDefault_dxaLeftRel);
	SetPardProp(dxaRight, PapxDefault_dxaRight);
	SetPardProp(dxaRightRel, PapxDefault_dxaRightRel);
	SetPardProp(dxaLeft1, PapxDefault_dxaLeft1);
	SetPardProp(dxaLeft1Rel, PapxDefault_dxaLeft1Rel);
	SetPardProp(dyaBefore, PapxDefault_dyaBefore);
	SetPardProp(dyaBeforeRel, PapxDefault_dyaBeforeRel);
	SetPardProp(dyaAfter, PapxDefault_dyaAfter);
	SetPardProp(dyaAfterRel, PapxDefault_dyaAfterRel);
	SetPardProp(fAutoSpacingBefore, PapxDefault_fAutoSpacingBefore);
	SetPardProp(fAutoSpacingAfter, PapxDefault_fAutoSpacingAfter);
	if(!mask.lspd)
	{
		_MemSetInt(mask.lspd);
		prop->lspd.dyaLine = PapxDefault_fMultLinespace;
		prop->lspd.fMultLinespace = PapxDefault_fMultLinespace;
	}	
	SetPardProp(fUsePgsuSettings, PapxDefault_fUsePgsuSettings);
	SetPardProp(fKeep, PapxDefault_fKeep);
	SetPardProp(fKeepFollow, PapxDefault_fKeepFollow);
	SetPardProp(fPageBreakBefore, PapxDefault_fPageBreakBefore);
	SetPardProp(fNoLnn, PapxDefault_fNoLnn);
	SetPardProp(fNoAutoHyph, PapxDefault_fNoAutoHyph);
	SetPardProp(fKinsoku, PapxDefault_fKinsoku);
	SetPardProp(fWordWrap, PapxDefault_fWordWrap);
	SetPardProp(fOverflowPunct, PapxDefault_fOverflowPunct);
	SetPardProp(fTopLinePunct, PapxDefault_fTopLinePunct);
	SetPardProp(wAlignFont, PapxDefault_wAlignFont);
	SetPardProp(fWidowControl, RtfPapxDefault_fWidowControl);
	SetPardProp(fAdjustRight, RtfPapxDefault_fAdjustRight);
	SetPardProp(fAutoSpaceDE, RtfPapxDefault_fAutoSpaceDE);	
	SetPardProp(fAutoSpaceDN, RtfPapxDefault_fAtuoSpaceDN);	
	*/
}

STDMETHODIMP Para_AddMix(RtfParaPr* paraPr,
						 RtfParaContext* context,
						 RtfControl attrName,
						 int attrValue)
{
	RtfParaPr::MaskType* mask = &paraPr->mask;
	switch (attrName)
	{
	case rtf_pard:
		{
			RtfStyle* styNormal = context->m_stylesheet.GetNormalStyle();
			context->m_spanPrParaStyle = styNormal->SafeGetSpanPr();
			paraPr->Reset();
			AddPard(paraPr);		
		}
		break;
	// ---- ������� ------
	case rtf_itap:
		paraPr->nTableLayer = attrValue;
		context->m_trow.iTblLayer = attrValue;
		_MemSetInt(mask->nTableLayer);
		if(!mask->fInTable && paraPr->nTableLayer > 0)
		{
			paraPr->fInTable = 1;
			_MemSetInt(mask->fInTable);
		}
		break;
	case rtf_intbl:
		paraPr->fInTable = (attrValue != 0);
		_MemSetInt(mask->fInTable);
		if(!mask->nTableLayer)
		{
			paraPr->nTableLayer = 1;
			_MemSetInt(mask->nTableLayer);
		}
		break;
	// ---- ��ʽ��� ------
	case rtf_s:
		{			
			RtfStyle* style = context->m_stylesheet.GetStyle(attrValue);
			if (style == NULL)
			{
				style = context->m_stylesheet.GetNormalStyle();
			}
			if(style->GetType() == mso_sgcParagraph)
			{
				paraPr->istd = attrValue;
				_MemSetInt(mask->istd);
				context->m_spanPrParaStyle = style->SafeGetSpanPr();
			}
			else
			{
				context->m_spanPrParaStyle.istd = attrValue;
			}
		}
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------

STDMETHODIMP Para_AddAttribute(
							   RtfParaPr* paraPr,
							   RtfParaContext* context,
							   RtfControl attrName,
							   int attrValue)
{
	HRESULT hr = ParaBase_AddAttribute(paraPr, context, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;
	hr = Para_AddMix(paraPr, context, attrName, attrValue);
	if (SUCCEEDED(hr))
		return hr;
	return E_UNEXPECTED;
}