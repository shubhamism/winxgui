/* -------------------------------------------------------------------------
//	�ļ���		��	group_info.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 14:44:56
//	��������	��	
//
//	$Id: group_info.cpp,v 1.3 2006/02/27 08:19:49 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_info.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP Group_info::StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
{
	fDest = TRUE;
	return S_OK;
}


STDMETHODIMP Group_info::EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup)
{		
	switch(grSubName)
	{
	case rtf_title:
		*ppsubGroup = &m_grAssocStr;
		m_grAssocStr.uId = ibstAssocTitle;
		m_grAssocStr.m_doc = m_doc;
		break;
	case rtf_subject:
		*ppsubGroup = &m_grAssocStr;
		m_grAssocStr.uId = ibstAssocSubject;
		m_grAssocStr.m_doc = m_doc;
		break;
	case rtf_author:			
		*ppsubGroup = &m_grAssocStr;
		m_grAssocStr.uId = ibstAssocAuthor;
		m_grAssocStr.m_doc = m_doc;
		break;
	case rtf_manager:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_company:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_operator:
		*ppsubGroup = &m_grAssocStr;
		m_grAssocStr.uId = ibstAssocLastRevBy;
		m_grAssocStr.m_doc = m_doc;
		break;
	case rtf_category:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_keywords:
		*ppsubGroup = &m_grAssocStr;
		m_grAssocStr.uId = ibstAssocKeyWords;
		m_grAssocStr.m_doc = m_doc;
		break;
	case rtf_comment:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_version:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_doccomm:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_hlinkbase:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_vern:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_creatim:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_revtim:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_printim:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_buptim:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_edmins:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_nofpages:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_nofwords:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_nofchars:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_nofcharsws:
		*ppsubGroup = &_group_skipped;
		break;
	case rtf_id:
		*ppsubGroup = &_group_skipped;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: group_info.cpp,v $
//	Revision 1.3  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	