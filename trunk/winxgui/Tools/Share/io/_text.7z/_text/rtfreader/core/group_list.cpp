/* -------------------------------------------------------------------------
//	�ļ���		��	group_list.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-4 14:29:28
//	��������	��	
//
//	$Id: group_list.cpp,v 1.47 2006/09/11 08:00:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_list.h"
#include "../include/prop_base.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Group_leveltext
//---��Ÿ�ʽ˵��
STDMETHODIMP Group_leveltext::AddContent(
										 LPCSTR pContent,
										 int cch)
{

	if(pContent[cch-1] == L';')
		--cch;
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_leveltext.append(wchBuf.begin(), szRet);	
	return S_OK;
}


STDMETHODIMP Group_leveltext::StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
{
	m_leveltext.clear();
	return S_OK;
}
STDMETHODIMP Group_leveltext::EndGroup()
{	
	WCHAR* pContent = m_leveltext.begin();
	if (pContent != NULL)
	{
		UINT cchLevelText = *pContent++, cch = m_leveltext.size();
		if(cchLevelText > cch)
			cchLevelText = cch;
		m_level->SetLevelText(pContent, cchLevelText);
	}
	return S_OK;
}
STDMETHODIMP Group_leveltext::EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_uc:
		*ppsubGroup = &m_bullet;
		m_bullet.Init(&m_leveltext);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_levelnumbers

//---�������ռλ��
STDMETHODIMP Group_levelnumbers::AddContent(
						LPCSTR pContent,
						int cch)
{
	if (pContent[cch-1] == ';')	
		--cch;
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);	
	m_level->SetLevelNumbers(wchBuf.begin(), szRet);
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_listlevel
STDMETHODIMP Group_listlevel::StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
{
	m_spanpr.Reset();
	m_papx.Clear();
	tab.put_Nil();
	m_level.SetNoRestart(0);		//@tocheck
	return S_OK;
}

STDMETHODIMP Group_listlevel::EndGroup()	//@tocheck
{		
	KDWPropBuffer chpx;	
	m_spanpr.crKulColor = m_spanpr.crTextColor;
	_MemSetInt(m_spanpr.mask.crKulColor);
	ConvertChpx(chpx, &m_spanpr, m_doc);
	m_level.SetChpx(&chpx);
	if(tab.itbdMac || tab.itbdDelMax)	
		m_papx.AddTabStops(tab.itbdMac,tab.rgdxaTab,tab.rgtbd);
	m_level.SetPapx(&m_papx);
	m_papx.Clear();
	return S_OK;
}

STDMETHODIMP SpanBase_AddAttribute_Ignore(
								   RtfSpanPr* spanPr,
								   RtfSpanContext* context,
								   RtfControl attrName,
								   int attrValue)
{
	switch(attrName)
	{
	case rtf_brdrnone:	
	case rtf_brdrdb:		
	case rtf_brdrdot:
	case rtf_brdrdash:		
	case rtf_brdrdashsm:		
	case rtf_brdrdashd:		
	case rtf_brdrdashdd:		
	case rtf_brdrtriple:		
	case rtf_brdrtnthsg:		
	case rtf_brdrthtnsg:		
	case rtf_brdrtnthtnsg:		
	case rtf_brdrtnthmg:		
	case rtf_brdrthtnmg:		
	case rtf_brdrtnthtnmg:		
	case rtf_brdrtnthlg:		
	case rtf_brdrthtnlg:		
	case rtf_brdrtnthtnlg:		
	case rtf_brdrwavy:		
	case rtf_brdrwavydb:		
	case rtf_brdrdashdotstr:		
	case rtf_brdremboss:		
	case rtf_brdrengrave:
	case rtf_brdrsh:		
	case rtf_brdrcf:		
	case rtf_brsp:		
	case rtf_brdrart:		
	case rtf_chshdng:
	case rtf_chbghoriz:		
	case rtf_chbgvert:
	case rtf_chbgfdiag:
	case rtf_chbgbdiag:			
	case rtf_chbgcross:			
	case rtf_chbgdcross:
	case rtf_chbgdkhoriz:
	case rtf_chbgdkvert:
	case rtf_chbgdkfdiag:
	case rtf_chbgdkbdiag:
	case rtf_chbgdkcross:		
	case rtf_chbgdkdcross:	
	case rtf_chcfpat:
	case rtf_chcbpat:
	case rtf_accdot:		//---���غ�		
	case rtf_acccomma:				
	case rtf_accnone:
		break;
	default:		
		return SpanBase_AddAttribute(spanPr, context, attrName, attrValue);
	}
	return S_OK;
			
}

STDMETHODIMP Group_listlevel::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{		
	switch (attrName)
	{
	case rtf_levelnfc:			//---�����ʽ	
		m_level.SetNfc( (NFC)attrValue );
		break;
	case rtf_levelnfcn:
		m_level.SetNfc( (NFC)attrValue );
		break;
	case rtf_levelstartat:		//---��ʼ���
		m_level.SetStartAt(attrValue);
		break;
	case rtf_leveljc:			//---���λ��	
		m_level.SetJc((JC)attrValue);
		break;
	case rtf_fi:				//---����λ��
		m_papx.AddPropFix(sprmPDxaLeft1, attrValue);	//@add
		m_papx.AddPropFix(sprmPDxaLeft1Ex, attrValue);	//@add
		break;
	case rtf_cufi:
		m_papx.AddPropFix(sprmPDxaLeft1Rel, attrValue);
		break;
	case rtf_s:					//---���������ӵ���ʽ
		m_doc->m_paraPr.istd = attrValue;
		break;
	case rtf_jclisttab:
		tab.put_TabJC(mso_tbdListTab);
		break;
	case rtf_tx:
		tab.put_TabPos(attrValue);
		break;
	case rtf_li:				//---����λ��
		m_papx.AddPropFix(sprmPDxaLeft, attrValue);
		m_papx.AddPropFix(sprmPDxaLeftEx, attrValue);		
		break;
	case rtf_levelold:
		break;
	case rtf_levelprev:
		break;
	case rtf_levelprevspace:
		break;
	case rtf_levelindent:
		break;
	case rtf_levelspace:
		break;
	case rtf_levelfollow:
		m_level.SetIxchFollow((XCHFOLLOW)attrValue);
		break;
	case rtf_levellegal:
		m_level.SetLegal(attrValue != 0);
		break;
	case rtf_levelnorestart:			//---��������¿�ʼ���
		m_level.SetNoRestart(attrValue != 0);
		break;
	case rtf_levelpicture:	{
		KDWPicBullet picbullet;
		HRESULT hr = m_doc->GetPicBullet(attrValue, &picbullet);
		if (FAILED(hr))
			return hr;
		m_level.SetPicBullet(picbullet);
		break;				}	
	default:		
		return SpanBase_AddAttribute_Ignore(&m_spanpr, m_doc, attrName, attrValue);
	}
	return S_OK;
}

STDMETHODIMP Group_listlevel::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_levelnumbers:
		m_levelnumbers.Init(&m_level);
		m_levelnumbers.m_doc = m_doc;
		*ppsubGroup = &m_levelnumbers;
		break;
	case rtf_leveltext:
		m_leveltext.m_level = &m_level;
		m_leveltext.m_doc = m_doc;
		*ppsubGroup = &m_leveltext;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_listname

STDMETHODIMP Group_listname::AddContent(
						LPCSTR pContent,
						int cch)
{
	if (pContent[cch-1]==';')
		--cch;
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_list->SetListName(wchBuf.begin(), szRet);
	return S_OK;
}

// -------------------------------------------------------------------------
// class Group_list
STDMETHODIMP Group_list::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{	
	m_listlevel.m_doc = m_doc;
	m_list = m_listlevel.m_doc->GetListTable().NewList(9);
	m_iLevel = 0;
	m_listid = 0;	
	return S_OK;
}

STDMETHODIMP Group_list::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	switch (attrName)
	{
	case rtf_listid:
		m_listid = attrValue;
		break;
	case rtf_listtemplateid:
		break;
	case rtf_listsimple:		
		break;
	case rtf_listhybrid:
		break;
	case rtf_listrestarthdn:		
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_list::EnterSubGroup(
						   RtfControl grSubName,
						   BOOL fDest1987,
						   RtfGroup** ppsubGroup)
{
	switch (grSubName)
	{
	case rtf_listlevel:
		if (m_iLevel < 9)
		{		
			m_listlevel.m_level = m_list.GetLevel(m_iLevel);
			*ppsubGroup = &m_listlevel;
			++m_iLevel;
			break;
		}
		else
		{
			return E_UNEXPECTED;
		}
	case rtf_listname:
		*ppsubGroup = &m_listname;
		m_listname.m_doc = m_doc;
		m_listname.m_list = &m_list;
		break;
	case rtf_liststylename:
		*ppsubGroup = &_group_skipped;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_list::EndGroup()
{
	m_listlevel.m_doc->SetListId(m_list, m_listid);	
	return S_OK;
}

STDMETHODIMP Group_lfolevel::AddAttribute(IN RtfControl attrName, IN int attrValue)
{
	switch(attrName)
	{
	case rtf_listoverrideformat:
		break;
	case rtf_listoverridestartat:		
		break;
	case rtf_levelstartat:		
		break;
	default:
		ASSERT_ONCE(0);
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_lfolevel::EnterSubGroup(IN RtfControl grSubName,IN BOOL fDest1987, OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_listlevel:
		*ppsubGroup = &_group_skipped;		
		break;
	default:
		ASSERT_ONCE(0);
		return E_UNEXPECTED;
	}
	return S_OK;
}
// -------------------------------------------------------------------------
// class Group_listoverride
STDMETHODIMP Group_listoverride::StartGroup(
						RtfControl grName,
						int grValue,
						int& fDest)
{
	m_ilfo = 0;
	m_iLfoLevel = -1;
	return S_OK;
}

STDMETHODIMP Group_listoverride::EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_lfolevel:
		*ppsubGroup = &m_lfolevel;
		m_lfolevel.m_doc = m_doc;
		++m_iLfoLevel;
		ASSERT_ONCE(m_iLfoLevel < m_cOveride);
		break;
	default:
		ASSERT_ONCE(0);
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_listoverride::AddAttribute(
						  RtfControl attrName,
						  int attrValue)
{
	switch (attrName)
	{
	case rtf_listid:	{
		RtfList listOrg;
		HRESULT hr = m_doc->GetList(attrValue, &listOrg);
		if (FAILED(hr))
			return hr;
		m_listoverride = m_doc->GetListTable().NewListFormatOverride(listOrg);
		break;			}
	case rtf_ls:
		m_ilfo = attrValue;
		break;
	case rtf_listoverridecount:
		m_cOveride = attrValue;
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP Group_listoverride::EndGroup()
{
	ASSERT_ONCE(m_listoverride.Good());
	if (m_listoverride.Good())
	{
		m_doc->SetListOverrideIndex(m_listoverride, m_ilfo);
		// docwrierд��������.
		// Ӧ����������, PlfLFO���ж��LFO
		// LFO����m_cOveride��LFOLVL
		// LFOLVL�ں�LVLF.@todo		
	}
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: group_list.cpp,v $
//	Revision 1.47  2006/09/11 08:00:23  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.46  2006/08/09 04:29:34  xulingjiao
//	#28604
//	
//	Revision 1.45  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.44  2006/04/07 00:57:26  xulingjiao
//	�޸�25208;25204;25173;25159��BUG�ڽ�ע�ڲ������������BUGrtfreader����������������BUG
//	
//	Revision 1.43  2006/03/31 01:55:44  xulingjiao
//	�޸����BUG
//	
//	Revision 1.42  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.41  2006/03/07 08:35:54  xulingjiao
//	�޸��Ʊ�λ��BUG
//	
//	Revision 1.40  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.39  2006/03/01 08:54:12  xulingjiao
//	�޸�BUG
//	
//	Revision 1.38  2006/03/01 06:02:57  xulingjiao
//	������listoverride��.
//	
//	Revision 1.37  2006/02/28 06:38:03  xulingjiao
//	�޸�rtfreader�Ʊ�λת����BUG
//	
//	Revision 1.36  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	