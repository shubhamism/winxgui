// rtfshapeopt.cpp : Defines the entry point for the console application.
// $Id: rtfshapeopt.cpp,v 1.17 2005/09/13 09:26:30 liucong Exp $
//

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define X_NO_AUTOINIT
#define X_NO_DEBUG_STRATEGY
#include <kfc.h>
#include <mso/io/excel/reader.h>
#include <fstream>

#define COLNUM 3

bool isRecognizeType(const XlsCell* pcell)
{	
	LPCWSTR recog[] = 
	{
		L"Boolean",
		L"Angle",
		L"String",
		L"Array",
		L"EMU",
		L"ShapeID",
		L"Long",
		L"Enum",
		L"Color",
		L"Fixed",
		L"Picture",
		L"Twips",
		L"Hyperlink",
		L"SkipData",
	};
	for(int i=0; i<countof(recog); ++i)
	{
		if( !wcsnicmp(recog[i], pcell->value.stringVal.data, pcell->value.stringVal.cch) )
			return true;
	}
	return false;
}

//
// { msopt_fFillOK, "fFillOK", rtf_vtBoolean, rtf_ptProperties },
//
STDMETHODIMP_(void) PutCells(std::ofstream& fout,const XlsCell** pCell, BOOL lowercase)
{
	USES_CONVERSION;

	LPSTR propName = W2A(pCell[0]->value.stringVal.data);
	LPSTR propType = W2A(pCell[2]->value.stringVal.data);

	fout << "	{ msopt_"
		 << propName;

	if (lowercase)
	{
		fout << ", \""
			 << strlwr(propName);
	}
	else
	{
		fout << ", \""
			 << propName;
	}

	if (isRecognizeType(pCell[1]))
	{
		fout << "\", rtf_vt"
			 << W2A(pCell[1]->value.stringVal.data)
			 << ", rtf_pt"
			 << propType
			 << " },\n";
	}
	else
	{
		fout << "\", rtf_vt"
			 << "Enum"
			 << ", rtf_pt"
			 << propType
			 << " },\n";
	}
}

STDMETHODIMP HandleWorksheet(const XlsWorksheet& sheet, std::ofstream& fout, BOOL lowercase)
{
	XlsDimensions outDim;
	HRESULT hr;
	hr = sheet.get_Dimensions(&outDim);	
	if(FAILED(hr))
		return hr;
	int i,j,count;
	for(i = outDim.rwMic+1; i<outDim.rwMac; ++i)
	{			
		count = 0;
		const XlsCell* pCell[COLNUM];
		for(j=outDim.colMic; j<COLNUM; ++j)
		{
			pCell[j] = sheet.get_Cell(i,j);
			if(!pCell[j])
				++count;
		}
		if(count)
			continue;
		PutCells(fout, pCell, lowercase);
	}
	return S_OK;
}

STDMETHODIMP HandleWorkbook(XlsWorkbook& workbook, LPCWSTR szCppFile, BOOL lowercase = TRUE)
{
	XlsWorksheet sheet;
	HRESULT hr = workbook.get_Worksheet(0, &sheet);
	if (FAILED(hr))
		return hr;
	
	USES_CONVERSION;
	std::ofstream fout(W2A(szCppFile));
	if (!fout)
	{
		printf("open file %S failed!\n", szCppFile);
		return E_ACCESSDENIED;
	}
	
	return HandleWorksheet(sheet, fout, lowercase);
}

int main()
{
	LPCWSTR shapeoptPath = __X("..\\drawing\\shapeopt");
	LPCWSTR shapeoptPathSpec = __X("..\\..\\..\\include\\escherfmt\\shapeopt");

	WCHAR drive[_MAX_DRIVE];
	WCHAR dir[_MAX_DIR];
	_wsplitpath(__wargv[0], drive, dir, NULL, NULL);

	WCHAR shapeoptXlsFile[_MAX_PATH];
	_wmakepath(shapeoptXlsFile, drive, dir, shapeoptPath, __X(".xls"));

	WCHAR shapeoptCppFile[_MAX_PATH];
	_wmakepath(shapeoptCppFile, drive, dir, shapeoptPath, __X(".hxx"));

	WCHAR shapeoptCppFileSpec[_MAX_PATH];
	_wmakepath(shapeoptCppFileSpec, drive, dir, shapeoptPathSpec, __X(".hxx"));
	
	XlsWorkbook workbook(shapeoptXlsFile);
	if (workbook.good())
	{
		HandleWorkbook(workbook, shapeoptCppFile, TRUE);
		HandleWorkbook(workbook, shapeoptCppFileSpec, FALSE);
	}
	else
	{
		printf("open file %S failed!\n", shapeoptXlsFile);
	}
	return 0;
}

// -------------------------------------------------------------------------
//	$Log: rtfshapeopt.cpp,v $
//	Revision 1.17  2005/09/13 09:26:30  liucong
//	no message
//	
//	Revision 1.16  2005/01/13 07:35:48  xushiwei
//	����rtf_vtHSHP������id��/rtf_vtSKIP�������ĵ����ݣ�����֧�֡�
//	
//	Revision 1.12  2005/01/12 02:08:36  xushiwei
//	����rtf_vtHLINK����֧�֡�
//	
//	Revision 1.11  2005/01/11 08:57:34  xushiwei
//	*** empty log message ***
//	
//	Revision 1.10  2005/01/11 08:11:01  xushiwei
//	shapeopt.hxx�������ɡ�
//	
//	Revision 1.3  2005/01/07 08:24:35  xushiwei
//	�޸���SST��bug: �п���continue��¼�Ŀ�ʼ����һ��grbitCHR��
//	
//	Revision 1.2  2005/01/07 04:00:18  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2005/01/06 07:35:28  xushiwei
//	�½����̡���������shapeopt����
//	
