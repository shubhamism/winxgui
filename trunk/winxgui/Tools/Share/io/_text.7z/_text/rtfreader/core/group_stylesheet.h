/* -------------------------------------------------------------------------
//	�ļ���		��	group_stylesheet.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 14:42:37
//	��������	��	
//
//	$Id: group_stylesheet.h,v 1.23 2006/08/31 08:23:23 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_STYLESHEET_H__
#define __GROUP_STYLESHEET_H__

typedef Group_Base Group_StyleBase;

// -------------------------------------------------------------------------

class RtfGroup_s : public Group_StyleBase
{
	std::vector<RtfAttribute> m_attrs;
	RtfGrpObject<Group_uc> m_uc;
	ks_wstring m_stylename;
public:
	RtfDocument* m_doc;
	STDMETHODIMP StartGroup(
		const RtfAttribute* attr,
		const RtfAttribute* attrEnd, 
		int& fDest);

	STDMETHODIMP AddAttributes(
		const RtfAttribute* attr,
		const RtfAttribute* attrEnd);

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);
	
	STDMETHODIMP AddContent(
		IN LPCWSTR pContent,
		IN int cch);
		
	STDMETHODIMP EndGroup();

	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
	{
		switch(grSubName)
		{
		case rtf_pn:
			*ppsubGroup = &_group_skipped;
			break;
		case rtf_uc:
			*ppsubGroup = &m_uc;
			m_uc.m_parent = this;
			break;
		default:
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

class RtfGroup_cs : public Group_StyleBase
{
	std::vector<RtfAttribute> m_attrs;
	RtfGrpObject<Group_uc> m_uc;
	ks_wstring m_stylename;
public:
	RtfDocument* m_doc;
	STDMETHODIMP StartGroup(
		const RtfAttribute* attr,
		const RtfAttribute* attrEnd, 
		int& fDest);
		
	STDMETHODIMP AddAttributes(
		const RtfAttribute* attr,
		const RtfAttribute* attrEnd);
	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);

	STDMETHODIMP AddContent(
		LPCWSTR pContent,
		int cch);

	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
	{
		switch(grSubName)
		{
		case rtf_uc:
			*ppsubGroup = &m_uc;
			m_uc.m_parent = this;
			break;
		default:
			return E_UNEXPECTED;
		}
		return S_OK;
	}
	
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------

class Group_stylesheet : public Group_Base
{
private:
	RtfGroup_s m_s;
	RtfGroup_cs m_cs;
private:
	STDMETHODIMP InitNormalVec(std::vector<RtfAttribute>& attrsNormal)
	{
		attrsNormal.push_back(RtfAttribute(rtf_qj, rtf_nilParam));
		attrsNormal.push_back(RtfAttribute(rtf_nowidctlpar, rtf_nilParam));
		attrsNormal.push_back(RtfAttribute(rtf_aspalpha, rtf_nilParam));
		attrsNormal.push_back(RtfAttribute(rtf_aspnum, rtf_nilParam));
		attrsNormal.push_back(RtfAttribute(rtf_faauto, rtf_nilParam));
		attrsNormal.push_back(RtfAttribute(rtf_adjustright, rtf_nilParam));
		attrsNormal.push_back(RtfAttribute(rtf_lang, 1033));
		attrsNormal.push_back(RtfAttribute(rtf_langfe, 2052));
		attrsNormal.push_back(RtfAttribute(rtf_kerning, 2));
		attrsNormal.push_back(RtfAttribute(rtf_fs, RtfChpxDefault_hps));
		attrsNormal.push_back(RtfAttribute(rtf_cgrid, rtf_nilParam));
		return S_OK;
	}
	
public:
	RtfStyle* m_style;
	RtfDocument* m_doc;
	
	friend class RtfGroup_s;
	friend class RtfGroup_cs;

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);

	STDMETHODIMP EndGroup();

	STDMETHODIMP_(void) MakeNormalStyle(int fDest = rtf_destTrue)
	{		
		//
		// -- ����Ĭ�ϵ�������ʽ --
		// {\qj \li0\ri0\nowidctlpar\aspalpha\aspnum\faauto\adjustright
		//	\rin0\lin0\itap0 \fs21\lang1033\langfe2052\kerning2\loch
		//	\f0\hich\af0\dbch\af13\cgrid\langnp1033\langfenp2052 
		//	\snext0 Normal;}
		//
		std::vector<RtfAttribute> attrsNormal;
		InitNormalVec(attrsNormal);		
		const CHAR Normal[] = { 'N', 'o', 'r', 'm', 'a', 'l', ';', '\0' };
		m_s.StartGroup(
			attrsNormal.begin(),
			attrsNormal.end(),
			fDest);
		m_s.AddContent(Normal, countof(Normal)-1);
		m_s.EndGroup();
	}
};

#endif /* __GROUP_STYLESHEET_H__ */
