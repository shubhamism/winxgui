/* -------------------------------------------------------------------------
//	�ļ���		��	group_fldrslt2.cpp
//	������		��	���὿
//	����ʱ��	��	2006-6-30 17:22:26
//	��������	��	
//
//	$Id: group_fldrslt2.cpp,v 1.2 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_fldrslt2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP Group_fldrslt2::StartGroup(
	RtfControl grName,
	int grValue,
	int& fDest)
{
	m_doc->MarkFieldSeparator();
	return Group_TextStream::StartGroup(grName, grValue, fDest);	
}

STDMETHODIMP Group_fldrslt2::AddAttribute(
	RtfControl attrName,
	int attrValue)
{
	switch(attrName)
	{
	case rtf_f:
		m_ifont = attrValue;
		break;	
	}
	return Group_TextStream::AddAttribute(attrName, attrValue);	
}