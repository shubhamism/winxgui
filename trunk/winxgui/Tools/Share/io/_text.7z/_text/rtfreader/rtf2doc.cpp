// rtfshapeopt.cpp : Defines the entry point for the console application.
// $Id: rtf2doc.cpp,v 1.5 2006/07/03 06:50:46 xulingjiao Exp $
//

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define X_NO_AUTOINIT
#define X_NO_DEBUG_STRATEGY
#include <kfc.h>
#include <cassert>
LONG RegistryNewShellCommand(LPCSTR szExt,LPCSTR szShellCommand,LPCSTR szCommand)
{
	LONG ret;
	HKEY extFile,shell,command,compare;
	char val[MAX_PATH];
	LONG cb;	
	ret = RegQueryValue(HKEY_CLASSES_ROOT,szExt,val,&cb);
	if(ret != ERROR_SUCCESS)		
		return ret;
	ret = RegOpenKey(HKEY_CLASSES_ROOT,val,&extFile);
	if(ret != ERROR_SUCCESS)
		return ret;
	ret = RegOpenKey(extFile,"shell",&shell);
	if(ret != ERROR_SUCCESS)
		return ret;
	ret = RegCreateKey(shell,szShellCommand,&compare);
	if(ret != ERROR_SUCCESS)
		return ret;
	ret = RegCreateKey(compare,"command",&command);
	if(ret != ERROR_SUCCESS)
		return ret;
	ret = RegSetValue(compare,"command",REG_SZ,szCommand,strlen(szCommand));
	if(ret != ERROR_SUCCESS)
		return ret;
	RegCloseKey(command);
	RegCloseKey(compare);
	RegCloseKey(shell);
	RegCloseKey(extFile);
	return ERROR_SUCCESS;
}

struct ReturnRegQueryValueEx
{
	ReturnRegQueryValueEx()
	{
		ZeroMemory(this, sizeof(*this));		
	}
	DWORD type, cbByte, cbValName;
	CHAR szValName[MAX_PATH];
	CHAR pByte[MAX_PATH];
};

template<INT nkey>
LONG GetRegValue(LPCSTR* subs, LPCSTR valName, ReturnRegQueryValueEx* out)
{	
	LONG ret; INT i; HKEY hApp[nkey];	
	hApp[0] = HKEY_LOCAL_MACHINE;
	for(i=1; i<nkey; ++i)
	{
		ret = RegOpenKeyEx(hApp[i-1], subs[i], 0, KEY_READ, &hApp[i]);		
		if(ret != ERROR_SUCCESS)
			return ret;		
	}
	for (i = 0, ret = ERROR_SUCCESS; ret == ERROR_SUCCESS; i++)
    { 
        ret = RegEnumValue(hApp[i-1],
                     i,
                     out->szValName,
                     &out->cbValName,
                     NULL,
                     &out->type,
                     (LPBYTE)out->pByte,
                     &out->cbByte);
    }
	if(ret != ERROR_SUCCESS)
	{
		for(i=nkey-1; i>=0; --i)
			RegCloseKey(hApp[i]);
		return ret;
	}
	for(i=nkey-1; i>=0; --i)
		RegCloseKey(hApp[i]);
	return ret;
}

LONG GetWpsInstallRoot(ReturnRegQueryValueEx* out)
{
	LPCSTR subs[] = { "", "SOFTWARE", "Kingsoft", "WPS", "6.0", "Common" };	
	LONG ret = GetRegValue<6>(subs, "InstallRoot", out);
	return ret;
}
int main()
{
	if (__argc < 2)
		return -1;
	char mdlFile[MAX_PATH];
	GetModuleFileName(NULL,mdlFile,MAX_PATH);
	strcat(mdlFile," %1");
	RegistryNewShellCommand(".rtf", "todoc", mdlFile);
	LPCWSTR szSrcFile = __wargv[1];
	WCHAR szDestFile[_MAX_PATH];
	wcscpy(szDestFile, szSrcFile);
	wcscat(szDestFile, __X(".doc"));
	HRESULT hr = E_FAIL;
	ReturnRegQueryValueEx out;	
	GetWpsInstallRoot(&out);
	printf("%s", (LPCSTR)out.pByte);
	HMODULE hMod = LoadLibrary("../../../product/win32d/office6/rtfreader.dll");
	if(hMod)
	{
		typedef HRESULT (*rtfConvertFn)(IN LPCWSTR rtfFile, IN LPCWSTR docFile);
		rtfConvertFn prtfConvert;
		prtfConvert = (rtfConvertFn)GetProcAddress(hMod, "rtfConvert");
		if(prtfConvert)		
			hr = prtfConvert(szSrcFile, szDestFile);		
	}		
	if (FAILED(hr))
		printf("failed!\n");
	else
		printf("ok!\n");
	FreeLibrary(hMod);
	return 0;
}

// -------------------------------------------------------------------------
//	$Log: rtf2doc.cpp,v $
//	Revision 1.5  2006/07/03 06:50:46  xulingjiao
//	�޸�IncludePicture��ͼƬ��ʾ������������
//	
//	Revision 1.4  2006/06/30 14:24:11  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.3  2006/06/30 09:42:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/03/09 08:59:33  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.1  2005/01/07 06:53:47  xushiwei
//	��ɡ�
//	
