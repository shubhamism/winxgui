/* -------------------------------------------------------------------------
//	�ļ���		��	group_obj.h
//	������		��	���὿
//	����ʱ��	��	2006-3-9 20:33:51
//	��������	��	
//
//	$Id: group_obj.h,v 1.2 2006/06/30 14:24:11 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_OBJ_H__
#define __GROUP_OBJ_H__
// -------------------------------------------------------------------------
class Group_result;
class Group_object : public Group_Base
{
private:
	Group_result* m_result;
public:
	Group_object();
	~Group_object();
	RtfDocument* m_doc;
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup);
};
#endif /* __GROUP_OBJ_H__ */
