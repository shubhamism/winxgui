/* -------------------------------------------------------------------------
//	�ļ���		��	testrevsion.cpp
//	������		��	���὿
//	����ʱ��	��	2006-2-9 16:05:05
//	��������	��	
//
//	$Id: testrevsion.cpp,v 1.1 2006/02/09 08:48:42 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// -------------------------------------------------------------------------
class TestRevision : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestRevision);
		CPPUNIT_TEST(testRevTbl);
		CPPUNIT_TEST(testInsert);
		CPPUNIT_TEST(testDelete);
		CPPUNIT_TEST(testDelInsert);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testRevTbl()
	{
		testRtf2DocFile("revision/revtbl.rtf", "revision_revtbl.doc");
	}
	void testInsert()
	{
		testRtf2DocFile("revision/insert.rtf", "revision_insert.doc");
	}
	void testDelete()
	{
		testRtf2DocFile("revision/delete.rtf", "revision_delete.doc");
	}
	void testDelInsert()
	{
		testRtf2DocFile("revision/insert_delete.rtf", "revision_insert_delete.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestRevision);
// -------------------------------------------------------------------------
//	$Log: testrevsion.cpp,v $
//	Revision 1.1  2006/02/09 08:48:42  xulingjiao
//	rtfreader�Ѿ�֧���޶���
//	
