/* -------------------------------------------------------------------------
//	�ļ���		��	group_fldrslt2.h
//	������		��	���὿
//	����ʱ��	��	2006-6-30 17:20:25
//	��������	��	
//
//	$Id: group_fldrslt2.h,v 1.3 2006/09/11 08:00:24 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FLDRSLT2_H__
#define __GROUP_FLDRSLT2_H__

#ifndef __GROUP_TEXTSTREAM_H__
#include "../core/group_textstream.h"
#endif

class Group_fldrslt2 : public Group_TextStream
{	
public:
	int m_ifont;
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);	
};

#endif /* __GROUP_FLDRSLT2_H__ */
