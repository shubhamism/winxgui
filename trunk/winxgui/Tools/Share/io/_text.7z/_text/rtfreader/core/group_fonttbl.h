/* -------------------------------------------------------------------------
//	�ļ���		��	group_fonttbl.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 9:44:44
//	��������	��	
//
//	$Id: group_fonttbl.h,v 1.19 2006/08/31 05:58:51 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_FONTTBL_H__
#define __GROUP_FONTTBL_H__

inline STDMETHODIMP_(BOOL) _IsPreDefinedCodePage(DWORD cp)
{
	if( cp == CP_ACP ||
		cp == CP_OEMCP ||
		cp == CP_MACCP ||
		cp == CP_THREAD_ACP ||
		cp == CP_SYMBOL ||
		cp == CP_UTF7 ||
		cp == CP_UTF8)
		return TRUE;
	return FALSE;
}

class Group_falt : public Group_Base
{
public:	
	RtfDocument* m_doc;
	DWORD ciACP;
	ks_wstring m_altName;
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);	
};

class Group_panose : public Group_Base
{
public:
	PANOSE m_panose;

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);

	STDMETHODIMP AddBinary(
		LPCVOID pData,
		int cbData);
};

// -------------------------------------------------------------------------

class Group_f : public Group_Base
{
private:
	RtfGrpObject<Group_panose> m_panose;
	RtfGrpObject<Group_falt> m_falt;
	RtfGrpObject<Group_uc> m_uc;
	ks_wstring m_fontName;
	UINT m_ifont;
	UINT8 m_family;
	UINT8 m_charset;	
private:
	STDMETHODIMP_(DWORD) _GetCodePage()
	{
		DWORD ciACP = m_doc->m_dop.DefCodePage;
		CHARSETINFO chsinfo;
		if( TranslateCharsetInfo((DWORD*)m_charset, &chsinfo, TCI_SRCCHARSET) )
			ciACP = chsinfo.ciACP;
		return ciACP;
	}	
public:
	RtfDocument* m_doc;

	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);

	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch);

	STDMETHODIMP AddContent(
		IN LPCWSTR pContent,
		IN int cch);

	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);

	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------

class Group_rtf;

class Group_fonttbl : public Group_Base
{
private:
	RtfGrpObject<Group_f> m_font;	

public:
	RtfDocument* m_doc;	

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
};

// -------------------------------------------------------------------------
//	$Log: group_fonttbl.h,v $
//	Revision 1.19  2006/08/31 05:58:51  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.18  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.17  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.16  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	
#endif /* __GROUP_FONTTBL_H__ */
