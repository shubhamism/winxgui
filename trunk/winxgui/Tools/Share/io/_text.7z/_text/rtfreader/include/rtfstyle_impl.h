/* -------------------------------------------------------------------------
//	�ļ���		��	rtfstyle_impl.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-18 11:32:21
//	��������	��	
//
//	$Id: rtfstyle_impl.h,v 1.12 2006/02/22 01:14:18 xulingjiao Exp 
$
// -----------------------------------------------------------------------*/
#ifndef __RTFSTYLE_IMPL_H__
#define __RTFSTYLE_IMPL_H__

#ifndef __RTFSTYLE_H__
#include "rtfstyle.h"
#endif

#ifndef __MSO_FILEFMT_WORD_CORE_STYLESTI_H__
#include <mso/filefmt/word/core/stylesti.h>
#endif

#ifndef __STL_STRING_H__
#include <stl/string.h>
#endif
// -------------------------------------------------------------------------
// GetStyleNameToStiMap
typedef std::map<std::string, UINT> StyleNameToStiMap;

STDMETHODIMP_(const StyleNameToStiMap&) GetStyleNameToStiMap()
{
	static StyleNameToStiMap theMap;

	for (UINT i = 0; i < countof(_g_stiFriendlyName); ++i)
	{
		std::string stiName = _g_stiFriendlyName[i];
		strlower(stiName);

		ASSERT(stiName == "stiunknown" || theMap.count(stiName) == 0);

		theMap.insert(
			StyleNameToStiMap::value_type(stiName, i) );
	}

	return theMap;
}

// -------------------------------------------------------------------------
// StiFromStyleName

STDMETHODIMP_(UINT) StiFromStyleName(IN MsoKernStr* styleNameW)
{
	static const StyleNameToStiMap& theMap = GetStyleNameToStiMap();
	
	UINT cch = styleNameW->Size();
	
	std::string styleName;
	styleName.resize(cch);

	std::string::iterator it = styleName.begin();
	for (UINT i = 0; i < cch; ++i)
	{
		*it++ = tolower(styleNameW->_data[i]);
	}

	StyleNameToStiMap::const_iterator itFind = theMap.find(styleName);
	if (itFind != theMap.end())
	{
		return (*itFind).second;
	}
	else
	{
		return stiUser;
	}
}

// -------------------------------------------------------------------------
// DefaultPr
RtfParaPr g_pPrDefaultByWord;
RtfSpanPr g_spanPrDefaultByWord;

inline
STDMETHODIMP_(int) _InitDefaultPr()
{
	g_pPrDefaultByWord.ResetByWord();
	g_spanPrDefaultByWord.ResetByWord();
	return 0;
}

static g_resultInitDefaultPr = _InitDefaultPr();

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(void) RtfStyle::_UpdateParaPr(IN KDWStyle& style, IN const RtfParaPr& baseOn)
{
	RtfPropData* data = propx[mso_sgcParagraph-1];
	ASSERT(data);
	if (data)
	{
		KDWPropBuffer papx;
		RtfParaPr& pPr = *(RtfParaPr*)data;
		papx.AddIstd(m_styleIdByWord);
		AddPard(&pPr);
		ConvertPapx(papx, &pPr, &baseOn);
		style.SetSprmList(mso_sgcParagraph, &papx);
	}
}

inline
STDMETHODIMP_(void) RtfStyle::_UpdateSpanPr(IN KDWStyle& style, IN const RtfSpanPr& baseOn)
{
	RtfPropData* data = propx[mso_sgcCharacter-1];
	ASSERT(data);
	
	if (data)
	{
		KDWPropBuffer chpx;
		RtfSpanPr& spanPr = *(RtfSpanPr*)data;
		chpx.AddPropFix(sprmCIstd,  m_styleIdByWord);
		AddPlain(&spanPr);
		ConvertChpx(chpx, &spanPr, &baseOn);
		style.SetSprmList(mso_sgcCharacter, &chpx);
	}
}

/*
@fn Update
@brief
	����RtfStyle�����ݣ�����һ��KDWStyle������KDWDocument����ʽ����

��
@arg [in] doc
	������KDWStyle��������ĸ�doc����ʽ���С�
@*/
RTF_STYLE_API_(void) RtfStyle::Update(
	IN RtfDocument* doc, UINT sti)
{	
	if (sti == stiNormal)
		doc->m_stylesheet.m_styNormal = this;

	KDWStyle style;
	HRESULT hr = doc->GetStyleSheet().NewStyle(
		sti,
		name,
		(STYLE_SGC)basestd.sgc,
		&style
		);
	ASSERT_OK(hr);

	if (FAILED(hr))
		return;

	m_styleIdByWord = style.GetIndex();
}

STDMETHODIMP_(void) RtfStyle::_UpdateData(IN RtfDocument* doc)
{
	const RtfStyleSheet& stylesheet = doc->m_stylesheet;

	KDWStyle style;
	HRESULT hr = doc->GetStyleSheet().GetStyle(m_styleIdByWord, &style);
	ASSERT_OK(hr);

	if (FAILED(hr))
		return;

	RtfStyle* baseOn;
	if (basestd.istdBase != stiNil)
	{
		baseOn = stylesheet.GetStyle(basestd.istdBase);
		if (baseOn == this)
			baseOn = NULL;
		else if (baseOn)
			style.SetBaseStyle(baseOn->m_styleIdByWord);
	}
	else
		baseOn = NULL;

	style.SetNextStyle(
		stylesheet.GetStyleIdByWord(basestd.istdNext) );
	
	if (basestd.istdLink)	
		style.SetLinkStyle(	stylesheet.GetStyleIdByWord(basestd.istdLink) );

	style.SetHiddenUI(basestd.fHidden);
	style.SetSemiHidden(!basestd.fSemiNoHidden);
	style.SetAutoRedefine(basestd.fAutoRedef);
	
	switch (basestd.sgc)
	{
	case mso_sgcParagraph:
		_UpdateParaPr(style, baseOn->SafeGetParaPr());
		_UpdateSpanPr(style, baseOn->SafeGetSpanPr());
		break;

	case mso_sgcCharacter:
		_UpdateSpanPr(style, baseOn->SafeGetSpanPr());
		break;

	default:
		ASSERT_ONCE(0);
	}
}
#endif /* __RTFSTYLE_IMPL_H__ */
