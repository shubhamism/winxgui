/* -------------------------------------------------------------------------
//	�ļ���		��	group_annotation.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-6 13:19:22
//	��������	��	
//
//	$Id: group_annotation.cpp,v 1.6 2006/07/27 02:39:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "group_annotation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP RtfGroup_atrfstart::StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
{
	m_atnRefId.clear();
	m_atnRefStartCp = m_doc->GetMainSubdoc()->TextPool().size();
	return S_OK;
}

STDMETHODIMP RtfGroup_atrfstart::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{	
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_atnRefId.assign(wchBuf.begin(), szRet);
	return S_OK;
}

STDMETHODIMP RtfGroup_atrfstart::EndGroup()
{
	m_doc->MarkAtnRefBegin(m_atnRefId, m_atnRefStartCp);	
	return S_OK;
}

STDMETHODIMP RtfGroup_atrfend::StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
{
	m_atnRefId.clear();
	m_atnRefEndCp = m_doc->GetMainSubdoc()->TextPool().size();
	return S_OK;
}
	
STDMETHODIMP RtfGroup_atrfend::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_atnRefId.assign(wchBuf.begin(), szRet);
	return S_OK;
}

STDMETHODIMP RtfGroup_atrfend::EndGroup()
{	
	m_doc->MarkAtnRefEnd(m_atnRefId, m_atnRefEndCp);	
	return S_OK;
}

STDMETHODIMP RtfGroup_atnid::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);	
	m_doc->SetAnnotationUser(wchBuf.begin(), szRet, TRUE);
	return S_OK;
}

STDMETHODIMP RtfGroup_atnauthor::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);	
	m_doc->SetAnnotationUser(wchBuf.begin(), szRet, FALSE);
	return S_OK;
}

STDMETHODIMP RtfGroup_atnref::StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
{
	m_ref->clear();
	return S_OK;
}
	
STDMETHODIMP RtfGroup_atnref::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_ref->assign(wchBuf.begin(), szRet);
	return S_OK;
}

STDMETHODIMP RtfGroup_atndate::StartGroup(
		IN RtfControl grName,
		IN int grValue,
		IN OUT int& fDest)
{
	m_date->clear();
	return S_OK;
}
	
STDMETHODIMP RtfGroup_atndate::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{
	INT szWchBuf = cch*2 + 10, szRet;
	std::vector<WCHAR> wchBuf(szWchBuf);
	szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);
	m_date->assign(wchBuf.begin(), szRet);
	return S_OK;
}

STDMETHODIMP RtfGroup_annotation::EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
{
	switch(grSubName)
	{
	case rtf_atnref:
		*ppsubGroup = &m_atnref;
		m_atnref.m_doc = m_doc;
		m_atnref.m_ref = &m_ref;
		break;
	case rtf_atndate:
		*ppsubGroup = &m_atndate;
		m_atndate.m_doc = m_doc;
		m_atndate.m_date = &m_date;
		break;
	default:
		EnterEnterAnnotation();
		return Group_TextStream::EnterSubGroup(grSubName, fDest1987, ppsubGroup);
	}
	return S_OK;
}


STDMETHODIMP RtfGroup_annotation::EnterEnterAnnotation()
{
	if(!m_fHasEnter)
	{
		m_doc->EnterAnnotation(m_ref, m_date);
		m_fHasEnter = TRUE;
	}
	return S_OK;
}

STDMETHODIMP RtfGroup_annotation::StartGroup(
	IN RtfControl grName,
	IN int grValue,
	IN OUT int& fDest)
{
	Group_TextStream::StartGroup(grName, grValue, fDest);
	m_fHasEnter = FALSE;
	m_date.clear();
	m_ref.clear();
	return S_OK;
}

STDMETHODIMP RtfGroup_annotation::AddContent(
	IN LPCSTR pContent,
	IN int cch)
{
	EnterEnterAnnotation();
	return Group_TextStream::AddContent(pContent, cch);
}

STDMETHODIMP RtfGroup_annotation::AddBinary(
	IN LPCVOID pData,
	IN int cbData)
{
	EnterEnterAnnotation();
	return Group_TextStream::AddBinary(pData, cbData);
}

STDMETHODIMP RtfGroup_annotation::EndGroup()
{	
	EnterEnterAnnotation();
	m_doc->LeaveAnnotation();
	Group_TextStream::EndGroup();
	return S_OK;
}
// -------------------------------------------------------------------------
//	$Log: group_annotation.cpp,v $
//	Revision 1.6  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.5  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.4  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	