/* -------------------------------------------------------------------------
//	�ļ���		��	group_pict.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-29 18:41:17
//	��������	��	
//
//	$Id: group_pict.h,v 1.19 2006/07/12 03:01:06 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_PICT_H__
#define __GROUP_PICT_H__

// -------------------------------------------------------------------------
// class Group_pict_Base

class Group_pict_Base : public Group_Base
{
protected:
	RtfBlipType m_blipType;

public:
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{
		//
		//��ʾ������һ��binary group����content�����ַ�������binarydata��
		//
		fDest |= rtf_destBinary;
		
		m_blipType = msoblipERROR;
		return S_OK;
	}
	
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue)
	{		
		switch (attrName)
		{
		case rtf_jpegblip:
			m_blipType = msoblipJPEG;
			break;
		case rtf_pngblip:
			m_blipType = msoblipPNG;
			break;
		case rtf_wmetafile:
			m_blipType = msoblipWMF;
			break;
		case rtf_emfblip:
			m_blipType = msoblipEMF;
			break;
		case rtf_dibitmap:
			m_blipType = msoblipDIB;
			break;
		case rtf_macpict:
			m_blipType = msoblipPICT;
			break;
		case rtf_wbitmap:
			m_blipType = msoblipWBITMAP;			
			break;
		case rtf_pmmetafile:
			ASSERT(0);
			break;
		case rtf_picscalex:
			break;
		default:			
			return E_UNEXPECTED;
		}
		return S_OK;
	}
};

#endif /* __GROUP_PICT_H__ */
