/* -------------------------------------------------------------------------
//	�ļ���		��	group_info.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-10 14:45:07
//	��������	��	
//
//	$Id: group_info.h,v 1.12 2006/08/09 04:31:07 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_INFO_H__
#define __GROUP_INFO_H__
// -------------------------------------------------------------------------
class Group_AssocString : public Group_Base
{
public:
	UINT uId;
	RtfDocument* m_doc;	
	ks_wstring m_unicodes;
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest)
	{
		fDest = TRUE;
		m_unicodes.clear();
		return S_OK;
	}	
	STDMETHODIMP AddContent(
		LPCSTR pContent,
		int cch)
	{		
		INT szWchBuf = cch*2 + 10, szRet;
		std::vector<WCHAR> wchBuf(szWchBuf);
		szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);		
		m_unicodes.append(wchBuf.begin(), szRet);
		return S_OK;		
	}
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
	{
		switch(grSubName)
		{
		case rtf_uc:
			*ppsubGroup = this;
			break;
		default:
			ASSERT_ONCE(0);
			*ppsubGroup = &_group_skipped;			
		}
		return S_OK;
	}
	STDMETHODIMP EndGroup()
	{
		m_unicodes.append(1, '\0');
		return m_doc->GetAssocTable().Add(uId, m_unicodes.begin());
	}
};
class Group_info : public Group_Base
{	
	RtfGrpObject<Group_AssocString> m_grAssocStr;	
public:
	RtfDocument* m_doc;
	STDMETHODIMP StartGroup(
		RtfControl grName,
		int grValue,
		int& fDest);
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);	
};

// -------------------------------------------------------------------------
//	$Log: group_info.h,v $
//	Revision 1.12  2006/08/09 04:31:07  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.11  2006/08/09 04:29:34  xulingjiao
//	#28604
//	
//	Revision 1.10  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.9  2006/03/07 08:35:54  xulingjiao
//	�޸��Ʊ�λ��BUG
//	
//	Revision 1.8  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.7  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	

#endif /* __GROUP_INFO_H__ */
