/* -------------------------------------------------------------------------
//	�ļ���		��	group_revtbl.h
//	������		��	���὿
//	����ʱ��	��	2006-2-9 15:12:50
//	��������	��	
//
//	$Id: group_revtbl.h,v 1.5 2006/07/27 02:39:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_REVTBL_H__
#define __GROUP_REVTBL_H__
// -------------------------------------------------------------------------

class Group_revuser : public Group_Base
{
public:
	RtfDocument* m_doc;
	STDMETHODIMP AddContent(
		IN LPCSTR pContent,
		IN int cch)
	{
		if(cch<=0)
			return E_FAIL;
		--cch;
		while(cch>=0 && pContent[cch] == ';')
			--cch;
		++cch;
		INT szWchBuf = cch*2 + 10, szRet;
		std::vector<WCHAR> wchBuf(szWchBuf);
		szRet = MultiByteToWideChar(m_doc->m_dop.DefCodePage, 0, pContent, cch, wchBuf.begin(), szWchBuf);		
		m_doc->GetRevisionUsers().Add(wchBuf.begin(), szRet);
		return S_OK;
	}
};

class Group_revtbl : public Group_Base
{
private:
	RtfGrpObject<Group_revuser> m_user;
public:
	RtfDocument* m_doc;
	STDMETHODIMP EnterSubGroup(
		IN RtfControl grSubName,
		IN BOOL fDest1987,
		OUT RtfGroup** ppsubGroup)
	{
		switch(grSubName)
		{
		case rtf_blank:
			*ppsubGroup = &m_user;
			m_user.m_doc = m_doc;
			break;
		default:
			ASSERT_ONCE(0);
			*ppsubGroup = &_group_skipped;
			return E_FAIL;
		}
		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: group_revtbl.h,v $
//	Revision 1.5  2006/07/27 02:39:50  xulingjiao
//	�޸�27986�ŵ�BUG
//	
//	Revision 1.4  2006/03/23 09:41:24  xulingjiao
//	�޸�BUG
//	
//	Revision 1.3  2006/03/06 01:39:48  xulingjiao
//	�������ӵ�rtfparser��Ϊrtfsimpleparser��.
//	
//	Revision 1.2  2006/02/27 08:19:49  xulingjiao
//	rtfreader����mask
//	

#endif /* __GROUP_REVTBL_H__ */
