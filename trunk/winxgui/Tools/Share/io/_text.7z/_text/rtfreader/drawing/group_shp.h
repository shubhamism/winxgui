/* -------------------------------------------------------------------------
//	�ļ���		��	group_shp.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-29 23:59:47
//	��������	��	
//
//	$Id: group_shp.h,v 1.16 2006/10/18 08:19:45 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __GROUP_SHP_H__
#define __GROUP_SHP_H__

#ifndef __GROUP_SP_H__
#include "group_sp.h"
#endif

#ifndef __GROUP_SHPTXT_H__
#include "group_shptxt.h"
#endif

// -------------------------------------------------------------------------
// class Group_shpinst
typedef KDWShapeAnchor RtfShapeAnchor;

class Group_shp_child;
class Group_shpinst : public Group_Base
{
private:
	RtfGrpObject<Group_sp> m_sp;

	Group_shptxt* m_shptxt;
	Group_shp_child* m_shpchild;

	RtfShape m_shape;
	RtfShapeOPT m_opt;
	RtfShapeInfo m_info;
	RtfShapeAnchor m_anchor;

	MSOSPID m_shplid;
private:
	STDMETHODIMP_(void) SetLinkInfo()
	{
		RtfDocument* doc = m_doc;
		if(doc)
		{
			doc->m_textboxes.AddIdMap(m_shplid, m_shape.__GetSpid());
			if(m_info.m_hspNext != -1)
			{				
				doc->m_textboxes.SetLinkInfo(m_shplid, m_info.m_hspNext);
				m_info.m_hspNext = -1;
			}
		}
	}
public:	
	RtfDocument* m_doc;
	STDMETHODIMP_(void) Reset()
	{
		m_shptxt = NULL;
		m_shpchild = NULL;
		m_opt.Reset();
		m_info.Reset();
	}
	Group_shpinst()
	{
		Reset();
	}
	~Group_shpinst();

public:
	// top-level shape
	// @@todo: �����anchor��ʼ�����δ����rtfĬ�ϵġ���Ҫȷ�ϡ�
	
	STDMETHODIMP NewShape(
		BOOL fgroup,
		RtfDocument* doc)
	{
		m_shape = doc->AddShape(fgroup);
		if (!m_shape.Good())
			return E_ACCESSDENIED;

		m_sp.Init(&m_opt, &m_info);
		m_opt.Reset();
		m_anchor.SetData(0, 0, 0x100, 0x100);
		return S_OK;
	}

	STDMETHODIMP_(void) UpdateShape()
	{
		ASSERT(
			m_shape.Good() &&		
			!m_shape.IsChildShape() );

		SetLinkInfo();

		m_shape.SetClientAnchor(m_anchor);		
		m_opt.UpdateShape(m_shape);
	}
	
public:
	// child shape
	
	STDMETHODIMP_(void) NewChildShape(
		BOOL fgroup,
		RtfShape grpshape)
	{
		ASSERT(
			grpshape.Good() &&
			grpshape.IsGroupShape() );

		m_shape = grpshape.NewShape(fgroup);
		ASSERT(
			m_shape.Good());

		m_sp.Init(&m_opt, &m_info);
		m_opt.Reset();
	}

	STDMETHODIMP_(void) UpdateChildShape()
	{
		SetLinkInfo();
		m_opt.UpdateChildShape(m_shape);
	}
	
public:
	STDMETHODIMP AddAttribute(
		RtfControl attrName,
		int attrValue);

	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
};

// -------------------------------------------------------------------------
// class Group_shprslt

typedef Group_Skipped Group_shprslt;

// -------------------------------------------------------------------------
// class Group_shp_toplevel

class Group_shp_toplevel : public Group_Base
{
public:
	RtfGrpObject<Group_shpinst> m_shpinst;
	RtfDocument* m_doc;
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
	
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// class Group_shp_child

class Group_shp_child : public Group_Base
{
public:
	RtfGrpObject<Group_shpinst> m_shpinst;	
	RtfDocument* m_doc;
	STDMETHODIMP EnterSubGroup(
		RtfControl grSubName,
		BOOL fDest1987,
		RtfGroup** ppsubGroup);
	
	STDMETHODIMP EndGroup();
};

// -------------------------------------------------------------------------
// class Group_shpgrp_toplevel, Group_shpgrp_child

typedef Group_shp_toplevel Group_shpgrp_toplevel;
typedef Group_shp_child Group_shpgrp_child;
#endif /* __GROUP_SHP_H__ */
