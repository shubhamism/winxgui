/* -------------------------------------------------------------------------
//	�ļ���		��	testfootnote.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-6 13:03:12
//	��������	��	
//
//	$Id: testfootnote.cpp,v 1.2 2005/01/12 10:11:06 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestFootnote : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestFootnote);
		CPPUNIT_TEST(testFootnote);
		CPPUNIT_TEST(testCustFootnote);
		CPPUNIT_TEST(testEndnote);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testFootnote()
	{
		testRtf2DocFile("footnote/footnote.rtf", "footnote_footnote.doc");
	}
	void testCustFootnote()
	{
		testRtf2DocFile("footnote/footnote_cust.rtf", "footnote_footnote_cust.doc");
	}
	void testEndnote()
	{
		testRtf2DocFile("footnote/endnote.rtf", "footnote_endnote.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestFootnote);

// -------------------------------------------------------------------------
//	$Log: testfootnote.cpp,v $
//	Revision 1.2  2005/01/12 10:11:06  xushiwei
//	��ɽ�עβע��
//	���ӽ�עβע��ذ�����
//	
//	Revision 1.1  2005/01/06 05:10:20  xushiwei
//	���ӽ�עβע������
//	
