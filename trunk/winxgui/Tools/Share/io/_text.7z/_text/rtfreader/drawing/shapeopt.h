/* -------------------------------------------------------------------------
//	�ļ���		��	shapeopt.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-1-10 9:45:34
//	��������	��	
//
//	$Id: shapeopt.h,v 1.23 2006/08/07 07:44:00 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __SHAPEOPT_H__
#define __SHAPEOPT_H__

__USING_MSO_ESCHER

// -------------------------------------------------------------------------
// RtfSpValueType

enum RtfSpValueType
{
	rtf_vtI4		= 0,
	rtf_vtBOOL		= 1,
	rtf_vtBLIP		= 2,
	rtf_vtSTR		= 3,
	rtf_vtARRAY		= 4,
	rtf_vtHLINK		= 5,
	rtf_vtHSHP		= 6,
	rtf_vtSKIP		= 7,
	rtf_vtMAX,
	rtf_vtBoolean	= rtf_vtBOOL,
	rtf_vtAngle		= rtf_vtI4,
	rtf_vtString	= rtf_vtSTR,
	rtf_vtArray		= rtf_vtARRAY,
	rtf_vtEMU		= rtf_vtI4,
	rtf_vtShapeID	= rtf_vtHSHP,
	rtf_vtLong		= rtf_vtI4,
	rtf_vtEnum		= rtf_vtI4,
	rtf_vtColor		= rtf_vtI4,
	rtf_vtFixed		= rtf_vtI4,
	rtf_vtPicture	= rtf_vtBLIP,
	rtf_vtTwips		= rtf_vtI4,
	rtf_vtHyperlink	= rtf_vtHLINK,
	rtf_vtSkipData	= rtf_vtSKIP,
};

enum RtfSpPropType
{
	rtf_ptProperties	 = 0,
	rtf_ptUDefProperties = 1,
	rtf_ptElse			 = 2,
};

// -------------------------------------------------------------------------
// struct MsoShapeElseOPT

#define msopt_ShapeType			( (PID)0 )
#define msopt_groupBottom		( (PID)1 )
#define msopt_groupLeft			( (PID)2 )
#define msopt_groupRight		( (PID)3 )
#define msopt_groupTop			( (PID)4 )
#define msopt_relRotation		( (PID)5 )
#define msopt_longValArrayMax	( (PID)6 )
#define msopt_relBottom			msopt_groupBottom
#define msopt_relLeft			msopt_groupLeft
#define msopt_relRight			msopt_groupRight
#define msopt_relTop			msopt_groupTop

#define msopt_fInitiator		( (PID)0x8000 )
#define msopt_fFlipV			( (PID)0x8001 )
#define msopt_fFlipH			( (PID)0x8002 )
#define msopt_fChangePage		( (PID)0x8003 )
#define msopt_boolValArrayMax	( (PID)0x8004 )
#define msopt_fRelFlipH			msopt_fFlipH
#define msopt_fRelFlipV			msopt_fFlipV
#define msopt_fRelChangePage	msopt_fChangePage

struct MsoShapeElseOPT
{
	INT32 longVal[msopt_longValArrayMax];
	UINT8 boolVal[msopt_boolValArrayMax & 0x0f];

public:
	__forceinline void Reset()
	{
		ZeroMemory(this, sizeof(MsoShapeElseOPT));
		longVal[msopt_ShapeType] = msosptPictureFrame;
		longVal[msopt_relRight] =
		longVal[msopt_relBottom] = 0;//0x100;
	}

	__forceinline void ForceAddPropFix(
		IN PID pid,
		IN INT32 oprand)
	{
		ASSERT(pid < msopt_longValArrayMax);
		longVal[pid] = oprand;
	}

	__forceinline void ForceAddPropBool(
		IN PID pid,
		IN BOOL fBool)
	{
		ASSERT(pid < msopt_boolValArrayMax);
		boolVal[pid & 0x0f] = fBool;
	}
};

// -------------------------------------------------------------------------
// RtfShapeOPT

typedef PID RtfPropID;
typedef MSOSPT RtfShapeType;

struct RtfShapeInfo
{
	RtfShapeInfo()
	{	
		Reset();
	}
	void Reset()
	{
		m_hspNext = -1;
		fPIB = FALSE;
		m_cxaShape = m_cyaShape = 0;
		m_picscalex = m_picscaley = 100;
	}
	MSOSPID m_hspNext;
	BOOL fPIB;
	INT m_cxaShape;
	INT m_cyaShape;
	INT m_picscalex;
	INT m_picscaley;
};

struct RtfShapeOPT
{
	MsoShapeOPT m_opt[2];
	MsoShapeElseOPT m_optElse;	
public:
	RtfShapeOPT()
	{
		Reset();
	}
	STDMETHODIMP_(void) Reset()
	{
		m_optElse.Reset();		
	}
	STDMETHODIMP_(void) UpdateShape(KDWShape shape)
	{
		ASSERT(
			shape.Good() );

		shape.SetShapeType( (MSOSPT)m_optElse.longVal[msopt_ShapeType] )
			.SetFlipV( m_optElse.boolVal[msopt_fFlipV & 0x0f] )
			.SetFlipH( m_optElse.boolVal[msopt_fFlipH & 0x0f] )
			.SetProperties(m_opt[0])
			.SetUDefProperties(m_opt[1]);
	}

	STDMETHODIMP_(void) UpdateChildShape(KDWShape shape)
	{
		ASSERT(
			shape.Good() &&
			shape.IsChildShape() );

		UpdateShape(shape);

		shape.SetChildAnchor(
			m_optElse.longVal[msopt_relLeft],
			m_optElse.longVal[msopt_relTop],
			m_optElse.longVal[msopt_relRight],
			m_optElse.longVal[msopt_relBottom]);
	}
};

// -------------------------------------------------------------------------
// RtfSpInfo

struct RtfSpInfo
{
	PID spId;
	LPCSTR spName;
	RtfSpValueType spValueType;
	RtfSpPropType spPropType;
};

// -------------------------------------------------------------------------
// RtfSpNameToInfoMap

typedef std::string RtfSpNameType;
typedef std::map<RtfSpNameType, RtfSpInfo*> RtfSpNameToInfoMap;

STDMETHODIMP_(const RtfSpNameToInfoMap&) SpNameToInfoMap();

// -------------------------------------------------------------------------
// helper

inline
STDMETHODIMP_(const RtfSpNameToInfoMap&) GetSpNameToInfoMap()
{
	static const RtfSpNameToInfoMap& theMap = SpNameToInfoMap();
	return theMap;
}
#endif /* __SHAPEOPT_H__ */
