// testescherrdr.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "testcase/testcommon.h"

int main()
{
	TestApp app;
	return 0;
}
