/* -------------------------------------------------------------------------
//	�ļ���		��	testbasic2.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-10-28 17:25:37
//	��������	��	
//
//	$Id: testmagic2.cpp,v 1.2 2006/01/09 05:50:16 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <algorithm>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

#define a(i, j)	matrix[(i)*n+(j)]

inline void print(int* matrix, size_t m, size_t n, const char* msg = NULL)
{
	printf("%s\n", msg ? msg : "");

	for (size_t i = 0; i < m; ++i)
	{
		for (size_t j = 0; j < n; ++j)
		{
			printf("%3d ", a(i, j));
		}
		printf("\n");
	}
	if (msg != NULL)
	{
		getchar();
	}
}

inline void clean(int* matrix, size_t m, size_t n)
{
	for (size_t i = 0; i < m; ++i)
	{
		int aii = a(i, i);
		if (aii == 0)
		{
			continue;
		}
		for (size_t j = 0; j < n; ++j)
		{
			ASSERT(a(i, j) % aii == 0);
			a(i, j) /= aii;
		}
	}
}

inline size_t trans(
					int matrix[], // m��=10��n��=16+1
					size_t m,
					size_t n,
					size_t icolswap[], // ncolswap��
					size_t ncolswap
					)
{
	size_t trytimes_max = m;

	for (size_t i = 0; i < m; ++i)
	{
		for (size_t it = i; it < m; ++it)
		{
			if (a(it, i) != 0) // Ok, ���Խ����н���
			{
				if (it != i) // ����i, it������
				{
					for (size_t j = 0; j < n; ++j)
					{
						std::swap(a(i, j), a(it, j));
					}
					//print(matrix, 10, 17, "after rowswap");
				}
				goto lzTrans;
			}
		}

		// �н������У������Ƿ���Խ����н���
		for (size_t try_times = i; try_times < trytimes_max; ++try_times)
		{
			for (size_t j = i; ++j < ncolswap; )
			{
				if (a(i, j) != 0) // Ok, ���Խ����н���
				{
					std::swap(icolswap[i], icolswap[j]);
					for (size_t it = 0; it < m; ++it)
					{
						std::swap(a(it, i), a(it, j));
					}
					//print(matrix, 10, 17, "after colswap");
					goto lzTrans;
				}
			}
			
			// ������һ��ȫ��0����������������ȥ��
			--trytimes_max;
			for (size_t j = 0; j < n; ++j)
			{
				std::swap(a(i, j), a(trytimes_max, j));
			}
		}
		break;

lzTrans:
		int aii = a(i, i);
		for (size_t it = 0; it < m; ++it)
		{
			int aiti = a(it, i);
			if (aiti != 0 && it != i)
			{
				for (size_t j = 0; j < n; ++j)
				{
					a(it, j) = aii * a(it, j) - aiti * a(i, j); 
				}
			}
		}
		//print(matrix, 10, 17, "after trans");
	}
	return trytimes_max;
}

#undef a

// -------------------------------------------------------------------------

void test_matrix_trans()
{
	int matrix[] =
	{
		1, 1, 1, 1,		0, 0, 0, 0,		0, 0, 0, 0,		0, 0, 0, 0,		30,
		0, 0, 0, 0,		1, 1, 1, 1,		0, 0, 0, 0,		0, 0, 0, 0,		30,
		0, 0, 0, 0,		0, 0, 0, 0,		1, 1, 1, 1,		0, 0, 0, 0,		30,
		0, 0, 0, 0,		0, 0, 0, 0,		0, 0, 0, 0,		1, 1, 1, 1,		30,
		1, 0, 0, 0,		1, 0, 0, 0,		1, 0, 0, 0,		1, 0, 0, 0,		30,
		0, 1, 0, 0,		0, 1, 0, 0,		0, 1, 0, 0,		0, 1, 0, 0,		30,
		0, 0, 1, 0,		0, 0, 1, 0,		0, 0, 1, 0,		0, 0, 1, 0,		30,
		0, 0, 0, 1,		0, 0, 0, 1,		0, 0, 0, 1,		0, 0, 0, 1,		30,
		1, 0, 0, 0,		0, 1, 0, 0,		0, 0, 1, 0,		0, 0, 0, 1,		30,
		0, 0, 0, 1,		0, 0, 1, 0,		0, 1, 0, 0,		1, 0, 0, 0,		30,
	};

	size_t icolswap[16];
	for (int i = 0; i < countof(icolswap); ++i)
		icolswap[i] = i;

	ASSERT(countof(matrix) == 10 * 17);

	size_t nfact = trans(matrix, 10, 17, icolswap, 16);
	clean(matrix, nfact, 17);

	printf("\nnfact = %d\n\n", nfact);
	for (int i = 0; i < countof(icolswap); ++i)
		printf("%3d ", icolswap[i]);
	printf("\n");
	print(matrix, 10, 17);
}

// -------------------------------------------------------------------------

class TestExBasic : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestExBasic);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
		test_matrix_trans();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestExBasic);

// -------------------------------------------------------------------------
//	$Log: testmagic2.cpp,v $
//	Revision 1.2  2006/01/09 05:50:16  xushiwei
//	magic2
//	
//	Revision 1.1  2006/01/09 05:15:14  xushiwei
//	*** empty log message ***
//	
