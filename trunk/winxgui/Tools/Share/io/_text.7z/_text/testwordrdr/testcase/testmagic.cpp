/* -------------------------------------------------------------------------
//	�ļ���		��	testmagic.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-12-21 13:54:39
//	��������	��	
//
//	$Id: testmagic.cpp,v 1.3 2006/01/09 05:50:16 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
// class Magic

typedef unsigned OpType;

enum ConstValue
{
	dimValue = 4,											// ά��
	sizeValue = dimValue * dimValue,						// ���ݸ���
	sumValue = sizeValue * (sizeValue-1) / 2 / dimValue,	// ����
};

enum OpCode
{
	opFill	= 0x00000,	// ���(��������n) arg1, arg2 ... argn
	opCalc	= 0x10000,	// ����(��������n=4) ��������(arg1), arg2, arg3, arg4
	opLT	= 0x20000,	// С��(��������n=2) arg1, arg2
	opcodeMask = 0xf0000,
};

const OpType _g_sprmList[] = // ���dimValue != 4����Ҫ��д����
{
	opFill|3,		0, 1, 2,
	opLT  |2,		1, 2,
	opCalc|4,		3, 0, 1, 2,
	opFill|3,		4, 5, 6,
	opCalc|4,		7, 4, 5, 6,
	opFill|1,		8,
	opCalc|4,		12, 0, 4, 8,
	opCalc|4,		9, 3, 6, 12,
	opCalc|4,		13, 1, 5, 9,
	opFill|1,		10,
	opCalc|4,		11, 8, 9, 10,
	opCalc|4,		14, 2, 6, 10,
	opCalc|4,		15, 0, 5, 10,
};

const OpType* _g_sprmEnd = _g_sprmList + sizeof(_g_sprmList)/sizeof(OpType);

class Magic
{
private:
	bool m_isUsed[sizeValue];			// ��Щ���ù��ˡ�
	unsigned m_nFillValue[sizeValue];	// ������ֵ��
	unsigned m_nResultCount;

	void _Calc(const OpType* arg, const OpType* sprmNext)
	{
		unsigned nCalcValue = sumValue;
		for (int i = 1; i < dimValue; ++i)
			nCalcValue -= m_nFillValue[arg[i]];

		if (nCalcValue >= sizeValue || m_isUsed[nCalcValue])
			return;

		m_nFillValue[arg[0]] = nCalcValue;
		m_isUsed[nCalcValue] = true;
		_Exec(sprmNext);
		m_isUsed[nCalcValue] = false;
	}

	void _Fill(const OpType* arg, const OpType* sprmNext)
	{
		for (unsigned nValue = 0; nValue < sizeValue; ++nValue)
		{
			if (!m_isUsed[nValue])
			{
				m_nFillValue[*arg] = nValue;
				m_isUsed[nValue] = true;
				if (arg+1 == sprmNext)
					_Exec(sprmNext);
				else
					_Fill(arg+1, sprmNext);
				m_isUsed[nValue] = false;
			}
		}
	}

	void _LT(const OpType* arg, const OpType* sprmNext)
	{
		if (m_nFillValue[arg[0]] < m_nFillValue[arg[1]])
		{
			_Exec(sprmNext);
		}
	}

	void _Exec(const OpType* sprm)
	{
		if (sprm == _g_sprmEnd)
		{
#if (1) // �Ƿ�������
			const unsigned* nValue = m_nFillValue;
			++m_nResultCount;
			printf("\n---> result %d:\n", m_nResultCount);
			for (int i = 0; i < dimValue; ++i)
			{
				for (int j = 0; j < dimValue; ++j)
				{
					printf("%2d ", 1 + *nValue++);
				}
				printf("\n");
			}
#endif
		}
		else
		{
			const OpType opcode = (*sprm & opcodeMask);
			const OpType oplen = (*sprm++ & ~opcodeMask);
			const OpType* sprmNext = sprm + oplen;
			if (opcode == opCalc)
				_Calc(sprm, sprmNext);
			else if (opcode == opFill)
				_Fill(sprm, sprmNext);
			else
				_LT(sprm, sprmNext);
		}
	}

public:
	void Run()
	{
		DWORD tick1 = GetTickCount();

		m_nResultCount = 0;
		for (int i = 0; i < sizeValue; ++i)
			m_isUsed[i] = false;

		_Exec(_g_sprmList);
		
		DWORD tick2 = GetTickCount();
		printf("\n--> elapsed %d ticks!\n", tick2 - tick1);
	}
};

// -------------------------------------------------------------------------

class TestMagic : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestMagic);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
		Magic magic;
		magic.Run();
	}
};

//CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestMagic);

// -------------------------------------------------------------------------
//	$Log: testmagic.cpp,v $
//	Revision 1.3  2006/01/09 05:50:16  xushiwei
//	magic2
//	
//	Revision 1.2  2006/01/09 05:07:13  xushiwei
//	�޸���ʾ��Ϣ��
//	
//	Revision 1.1  2005/12/21 05:50:15  xushiwei
//	class Magic
//	
