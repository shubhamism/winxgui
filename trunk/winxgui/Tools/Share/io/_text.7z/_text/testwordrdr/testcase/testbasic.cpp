/* -------------------------------------------------------------------------
//	�ļ���		��	testbasic.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-6-21 19:59:02
//	��������	��	
//
//	$Id: testbasic.cpp,v 1.4 2005/12/21 05:50:15 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <mso/dom/rotext.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestBasic : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestBasic);
		CPPUNIT_TEST(testBasic);
//		CPPUNIT_TEST(testFastSave);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testBasic()
	{
/*		KDRDocument doc;
		HRESULT hr = doc.OpenDocument(L"c:\\test.doc");
		ASSERT_OK(hr);

		const KDRDrawingGroup& dgg = doc.GetDrawingGroup();
		const KDRDrawing& dgMain = doc.GetDrawing(0);

		doc.Close();
*/	}

	void testFastSave()
	{
		// "docrw/fastsave/��ϸ���˵����.doc"
	}

/*	static UINT GetCodePageFromLang(UINT lang)
	{
		char codepage[16];
		GetLocaleInfoA(
			MAKELCID(lang, SORT_DEFAULT),
			LOCALE_IDEFAULTCODEPAGE,
			codepage,
			countof(codepage));
		return atoi(codepage);
	}

	void testCodePage()
	{
		const char szStr[] = "\x93\xf1\x81\x41";
		UINT codepage = GetCodePageFromLang(2052);
		WCHAR szStrW[32];
		WCHAR szStrWRef[] = { 0x4e8c, 0x3001, 0x00 };

		enum { CP_MAX = 2000 };
		for (UINT i = 1; i < CP_MAX; ++i)
		{
			if (IsValidCodePage(i))
			{
				int count = MultiByteToWideChar(
					i, 0, szStr, sizeof(szStr)-1, szStrW, 32
					);
				if (count == 2)
				{
					if (wcsncmp(szStrW, szStrWRef, 2) == 0)
					{
						CPINFOEXA info;
						GetCPInfoExA(i, 0, &info);
						printf("\n--------- CodePage: %d(0x%x) ---------\n", i, i);
						printf(
							"Name = %s\n"
							"MaxCharSize = %d\n"
							"UnicodeDefaultChar = 0x%.4x\n",
							info.CodePageName,
							info.MaxCharSize,
							info.UnicodeDefaultChar
							);
						codepage = i;
					}
				}
			}
		}
	}
*/
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestBasic);

// -------------------------------------------------------------------------
//	$Log: testbasic.cpp,v $
//	Revision 1.4  2005/12/21 05:50:15  xushiwei
//	class Magic
//	
//	Revision 1.3  2005/12/20 02:44:48  xushiwei
//	����ȷ����doc�ĵײ��ܡ�
//	
//	Revision 1.2  2005/10/27 02:07:36  xushiwei
//	test docreader(v2)
//	
//	Revision 1.1  2005/07/01 05:25:57  xushiwei
//	�����������̡�
//	
