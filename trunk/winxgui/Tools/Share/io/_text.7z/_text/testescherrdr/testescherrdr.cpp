// testescherrdr.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "testcase/testcommon.h"

int main()
{
	for (UINT i = 1; i < __argc; ++i)
	{
		if (__wargv[i][0] != '/')
		{
			LPCWSTR szSrcFile = __wargv[i];
			
			WCHAR szDestFile[_MAX_PATH];
			wcscpy(szDestFile, szSrcFile);
			wcscat(szDestFile, __X(".doc"));
			
			printf("processing %S ... ", szSrcFile);

			ConvertEscher2Doc(szSrcFile, szDestFile);
			return 0;
		}
	}
	{
		TestApp app;
		return 0;
	}
}
