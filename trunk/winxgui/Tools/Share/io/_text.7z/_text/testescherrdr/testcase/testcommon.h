/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:32:48
//	��������	��	
//
//	$Id: testcommon.h,v 1.3 2005/06/29 02:23:11 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif

#ifndef __MSO_IO_ESCHER_READER_H__
#include <mso/io/escher/reader.h>
#endif

__USING_MSO_ESCHER;

// -------------------------------------------------------------------------

#ifndef __MSO_IO_WORD_WRITER_H__
#include <mso/io/word/writer.h>
#endif

#ifndef __MSO_IO_WORD_ESCHER_ESCHER_H__
#include <mso/io/word/escher/escher.h>
#endif

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(LPCWSTR) GetTestSrcPath(LPCWSTR szRelPath)
{
	static WCHAR testPath[_MAX_PATH];
	return GetSystemIniPath(testPath, szRelPath);
}

inline
STDMETHODIMP_(LPCWSTR) GetTestOutputPath(LPCWSTR szRelPath)
{
	static WCHAR testPath[_MAX_PATH];
	return GetSystemIniPath(testPath, szRelPath);
}

#define testRtfPath(from)												\
		GetTestSrcPath(L"../../win32d/testcase/rtfrw/" L ## from)

#define testSrcPath(from)												\
		GetTestSrcPath(L"../../win32d/testcase/eschrw/" L ## from)

#define testOutputPath(to)												\
		GetTestOutputPath(L"../../win32d/testcase/output/" L ## to)

// -------------------------------------------------------------------------
// $Log: testcommon.h,v $
// Revision 1.3  2005/06/29 02:23:11  xushiwei
// ֧��TextBox��Ŀǰ�����ı���
//
// Revision 1.2  2005/06/23 06:46:31  xushiwei
// ֧�ִ�Excel/PowerPointճ���Ķ���
// ����Ҫ����ColorScheme���⡣
//
// Revision 1.1  2005/06/23 01:08:04  xushiwei
// �������һ��escher reader��ܡ�
//

#endif /* __TESTCOMMON_H__ */
