/* -------------------------------------------------------------------------
//	�ļ���		��	testbasic.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-6-21 19:59:02
//	��������	��	
//
//	$Id: testbasic.cpp,v 1.7 2005/06/29 02:42:48 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

__USING_MSO_RTF

// -------------------------------------------------------------------------

class DefaultTextHandler : public RtfTextHandlerBase
{
public:
	STDMETHODIMP_(void) AddContent(LPCWSTR szContent, UINT cch)
	{
	}
};

class TestBasic : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestBasic);
		CPPUNIT_TEST(test3rdToDoc);
		CPPUNIT_TEST(testTextBox);
		CPPUNIT_TEST(testPicture);
		CPPUNIT_TEST(testGroup);
		CPPUNIT_TEST(testBasic);
		CPPUNIT_TEST(testRtfText);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testRtfText()
	{
		DefaultTextHandler textHandler;
		ParseRtfText(
			testRtfPath("core/plat.rtf"),
			&textHandler);
	}

	void test3rdToDoc()
	{
		ConvertEscher2Doc(
			testSrcPath("excel.esch"), testOutputPath("esch_excel.doc"));
		ConvertEscher2Doc(
			testSrcPath("textbox_excel.esch"), testOutputPath("esch_textbox_excel.doc"));
	}

	void testTextBox()
	{
		ConvertEscher2Doc(
			testSrcPath("textbox_arttext.esch"), testOutputPath("esch_textbox_arttext.doc"));
//		ConvertEscher2Doc(
//			testSrcPath("textbox.esch"), testOutputPath("esch_textbox.doc"));
	}

	void testPicture()
	{
		ConvertEscher2Doc(
			testSrcPath("picture.esch"), testOutputPath("esch_picture.doc"));
	}

	void testGroup()
	{
		ConvertEscher2Doc(
			testSrcPath("group.esch"), testOutputPath("esch_group.doc"));
	}

	void testBasic()
	{
		ConvertEscher2Doc(
			testSrcPath("basic.esch"), testOutputPath("esch_basic.doc"));
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestBasic);

// -------------------------------------------------------------------------
//	$Log: testbasic.cpp,v $
//	Revision 1.7  2005/06/29 02:42:48  xushiwei
//	1��KDWDocCore����VerifyLastChar��
//	2��LeaveTextBoxʱ����VerifyLastChar��������һ���ַ��Ƿ�Ϊ0x0d��
//	
//	Revision 1.6  2005/06/29 02:23:11  xushiwei
//	֧��TextBox��Ŀǰ�����ı���
//	
//	Revision 1.5  2005/06/24 01:32:40  xushiwei
//	����ͼƬ֧�֣�BlipStore����
//	
//	Revision 1.4  2005/06/23 06:46:31  xushiwei
//	֧�ִ�Excel/PowerPointճ���Ķ���
//	����Ҫ����ColorScheme���⡣
//	
//	Revision 1.3  2005/06/23 05:30:54  xushiwei
//	֧����϶���
//	
//	Revision 1.2  2005/06/23 03:43:51  xushiwei
//	��ɶ���Ļ������ԣ�ShapeOPT����
//	
//	Revision 1.1  2005/06/23 01:08:04  xushiwei
//	�������һ��escher reader��ܡ�
//	
