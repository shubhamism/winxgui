/* -------------------------------------------------------------------------
//	�ļ���		��	htmlprop.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-13 15:03:20
//	��������	��	
//
//	$Id: htmlprop.h,v 1.14 2005/04/04 10:49:58 xushiwei Exp $
// -----------------------------------------------------------------------*/
/*
#ifndef __htmlPROP_H__
#define __htmlPROP_H__
#include "../rtfreader/include/rtfprop.h"
#define MAXTABNUM 65
class HtmlDocument;

#define CH_LINEBR 0x0d
#define HtmlDefaultColor 0xff000000


struct HtmlSpanBasePr
{
	UINT8	fBold;
	UINT8	fItalic;
	UINT8	fOutline;
	UINT8	fSmallCaps;	
	
	UINT8	fCaps;
	UINT8	fVanish;
	UINT8	fStrike;
	UINT8	fShadow;
	
	UINT8	fEmboss;
	UINT8	fImprint;
	UINT8	fDStrike;

	KDWBrc	brc;	
	KDWShd	shd;
	UINT8	sfxtText;

	UINT8	iftc;
	UINT16	rgftc[ftcMax];

	UINT16	hps;
	UINT16	hpsKern;

	UINT8	iss;
	UINT8	kul;
	UINT16	wCharScale;
	
	INT32	dxaSpace;
	
	COLORREF crTextColor;	// ȡ��ico
	COLORREF crHighlight;	// ȡ��icoHighlight

	// ---------------------------
	COLORREF crKulColor;
	UINT16	 hpsPos;		//--super/subscript position in half points; positive means text is raised; negative means text is lowered.]
	UINT8	 kcd;
	UINT8	 fcgrid;

public:
	STDMETHODIMP_(void) ConvertChpx(
		KDWPropBuffer& chpx,
		const HtmlSpanBasePr* baseOn) const;
};

inline
STDMETHODIMP_(void) HtmlSpanBasePr::ConvertChpx(
		KDWPropBuffer& propx,
		const HtmlSpanBasePr* baseOn) const
{
	_AddFixProp(sprmCRgFtc0, rgftc[rtf_ftcAscii]);
	_AddFixProp(sprmCRgFtc1, rgftc[rtf_ftcFastEast]);
	_AddFixProp(sprmCRgFtc2, rgftc[rtf_ftcOther]);

	_AddColorProp(sprmCIco, sprmCTextColor, crTextColor);
	_AddFixProp(sprmCKul,kul);
	_AddFixProp(sprmCKulColor,crKulColor);
	_AddFixProp(sprmCIss,iss);

	_AddFixProp(sprmCHps, hps);

	_AddBooleanProp(sprmCFItalic, fItalic);
	_AddBooleanProp(sprmCFBold, fBold);
	_AddBooleanProp(sprmCFOutline, fOutline);
	_AddBooleanProp(sprmCFSmallCaps, fSmallCaps);
	_AddBooleanProp(sprmCFCaps, fCaps);
	_AddBooleanProp(sprmCFVanish, fVanish);
	_AddBooleanProp(sprmCFStrike, fStrike);
	_AddBooleanProp(sprmCFDStrike, fDStrike);
	_AddBooleanProp(sprmCFShadow, fShadow);
	_AddBooleanProp(sprmCFEmboss, fEmboss);
	_AddBooleanProp(sprmCFImprint, fImprint);	

	_AddBrcProp(sprmCBrc, sprmCBrcEx, brc);
	_AddShdProp(sprmCShd, sprmCShdEx, shd);
		
	//------------------
	_AddFixProp(sprmCKcd,kcd);
	_AddFixProp(sprmCHpsPos,hpsPos);
	_AddFixProp(sprmCDxaSpace,dxaSpace);
	_AddFixProp(sprmCCharScale,wCharScale);	
	_AddFixProp(sprmCHpsKern,hpsKern);
	_AddFixProp(sprmCFUsePgsuSettings,fcgrid);
	_AddFixProp(sprmCSfxText,sfxtText);	
	_AddFixProp(sprmCHighlight,crHighlight);
}

struct HtmlSpanPr : HtmlSpanBasePr
{
	// ---- �޶�(������޶�����ʽ��ͬ) ----
	
	UINT8	fRMarkDel;
	UINT8	fRMark;
	UINT8	fPropMark;

#if defined(_DEBUG_DIRTY) && defined(X_CC_VC)
	UINT8 __inn_fIsDirty;
	UINT8 get_Dirty() const
	{
		return __inn_fIsDirty;
	}
	void put_Dirty(UINT8 fDirty)
	{
		__inn_fIsDirty = fDirty;
	}
	__declspec(property(get=get_Dirty,put=put_Dirty)) UINT8 fIsDirty;
#else
	UINT8	fIsDirty;
#endif

	UINT16	ibstRMark;
	UINT16	ibstRMarkDel;
	UINT16	ibstPropRMark;
	UINT16	reserved22;

	DTTM	dttmRMark;
	DTTM	dttmRMarkDel;
	DTTM	dttmPropRMark;

	UINT16	istd;
	UINT16	reserved2;
	
public:
	STDMETHODIMP_(void) Reset();	
	STDMETHODIMP_(void) ConvertChpx(
		KDWPropBuffer& chpx,
		HtmlDocument* doc) const;
};

inline
STDMETHODIMP_(void) HtmlSpanPr::ConvertChpx(
		KDWPropBuffer& chpx,
		HtmlDocument* doc) const
{		
}

inline
STDMETHODIMP_(void) HtmlSpanPr::Reset()
{
	ZeroMemory(this, sizeof(this));
	hps = HtmlChpxDefault_hps;
	wCharScale = ChpxDefault_wCharScale;
	crTextColor = HtmlDefaultColor;
	crKulColor = HtmlDefaultColor;
	fcgrid = ChpxDefault_fcgrid;
	brc.put_Nil();
	shd.put_Pattern(mso_patAutomatic);
	shd.put_ForeColor(HtmlDefaultColor);
	shd.put_BackColor(HtmlDefaultColor);		
	rgftc[ftcFastEast] = DW_DEFAULT_FASTEAST_FONT;
}

struct HtmlParaBasePr
{
	UINT8	jc;
	UINT8	fKeep;
	UINT8	fKeepFollow;
	UINT8	fPageBreakBefore;

	UINT8	lvl;
	UINT8	ilvl;
	UINT16	ilfo;

	INT32	dxaRight;	
	INT32	dxaRightRel;
	INT32	dxaLeft;
	INT32	dxaLeftRel;
	INT32	dxaLeft1;
	INT32	dxaLeft1Rel;
	
	LSPD	lspd;

	UINT8	fWidowControl;
	UINT8	fAdjustRight;
	UINT8	fAutoSpacingBefore;
	UINT8	fAutoSpacingAfter;
	
	INT32	dyaBefore;
	INT32	dyaBeforeRel;
	INT32	dyaAfter;
	INT32	dyaAfterRel;

	UINT8	fKinsoku;
	UINT8	fUsePgsuSettings;
	UINT8	fWordWrap;
	UINT8	fTopLinePunct;

	UINT8	fOverflowPunct;
	UINT8	fAutoSpaceDE;
	UINT8	fAtuoSpaceDN;
	UINT8	fNoAutoHyph;

	UINT8	fNoLnn;
	UINT8	fSideBySide;	
	UINT16	wAlignFont;
	
	KDWBrc	brcTop;
	KDWBrc	brcLeft;
	KDWBrc	brcBottom;
	KDWBrc	brcRight;
	KDWBrc	brcBetween;
	KDWBrc	brcBar;
	KDWShd	shd;

	KDWTab	ktab;
	KDWFrame frame;

public:	
	STDMETHODIMP_(void) ConvertPapx(
		KDWPropBuffer& propx,
		const HtmlParaBasePr* baseOn) const;
};

inline
STDMETHODIMP_(void) HtmlParaBasePr::ConvertPapx(
		KDWPropBuffer& propx,
		const HtmlParaBasePr* baseOn) const
{
	_AddFixProp(sprmPIlvl, ilvl);
	_AddFixProp(sprmPIlfo, ilfo);

	_AddFixProp(sprmPOutLvl,lvl);

	_AddFixPropEx(sprmPJc, sprmPJcEx, jc);
	
	_AddFixPropEx(sprmPDxaLeft1, sprmPDxaLeft1Ex, dxaLeft1);
	_AddFixProp(sprmPDxaLeft1Rel, dxaLeft1Rel);

	_AddFixPropEx(sprmPDxaLeft, sprmPDxaLeftEx, dxaLeft);
	_AddFixProp(sprmPDxaLeftRel, dxaLeftRel);

	_AddFixPropEx(sprmPDxaRight, sprmPDxaRightEx, dxaRight);
	_AddFixProp(sprmPDxaRightRel, dxaRightRel);

	_AddFixProp(sprmPDyaBefore,dyaBefore);	
	_AddFixProp(sprmPDyaBeforeRel,dyaBeforeRel);

	_AddFixProp(sprmPDyaAfter,dyaAfter);
	_AddFixProp(sprmPDyaAfterRel,dyaAfterRel);

	_AddFixProp(sprmPFDyaBeforeAuto,fAutoSpacingBefore);
	_AddFixProp(sprmPFDyaAfterAuto,fAutoSpacingAfter);	
	
	_AddFixProp(sprmPFAdjustRight,fAdjustRight);
	_AddFixProp(sprmPDyaLine,lspd);
	_AddFixProp(sprmPFUsePgsuSettings,fUsePgsuSettings);
	_AddFixProp(sprmPFWidowControl,fWidowControl);
	_AddFixProp(sprmPFKeep,fKeep);
	_AddFixProp(sprmPFKeepFollow,fKeepFollow);
	_AddFixProp(sprmPFPageBreakBefore,fPageBreakBefore);
	_AddFixProp(sprmPFNoLineNumb,fNoLnn);
	_AddFixProp(sprmPFNoAutoHyph,fNoAutoHyph);
	_AddFixProp(sprmPFKinsoku,fKinsoku);
	_AddFixProp(sprmPFWordWrap,fWordWrap);
	_AddFixProp(sprmPFOverflowPunct,fOverflowPunct);
	_AddFixProp(sprmPFAutoSpaceDE,fAutoSpaceDE);
	_AddFixProp(sprmPFAutoSpaceDN,fAtuoSpaceDN);
	_AddFixProp(sprmPFTopLinePunct,fTopLinePunct);
	_AddFixProp(sprmPWAlignFont,wAlignFont);

	// --- �߿�
	_AddBrcProp(sprmPBrcTop, sprmPBrcTopEx, brcTop);
	_AddBrcProp(sprmPBrcLeft, sprmPBrcLeftEx, brcLeft);
	_AddBrcProp(sprmPBrcBottom, sprmPBrcBottomEx, brcBottom);
	_AddBrcProp(sprmPBrcRight, sprmPBrcRightEx, brcRight);
	_AddBrcProp(sprmPBrcBetween, sprmPBrcBetweenEx, brcBetween);

	// --- ����
	_AddShdProp(sprmPShd, sprmPShdEx, shd);
	
	// --- �Ʊ�λ
	if (ktab.itbdMac > 0)
	{
		propx.AddTabStops(ktab.itbdMac, ktab.rgdxaTab, ktab.rgtbd);
	}

	// --- ͼ�Ŀ�
	_AddFixProp(sprmPDxaWidth,frame.dxaWidth);
	_AddFixProp(sprmPWHeightAbs,frame.wHeightAbsOprand.oprand);	
	_AddFixProp(sprmPPc,frame.ppcOprand.oprand);
	_AddFixProp(sprmPDxaAbs,frame.dxaAbs);
	_AddFixProp(sprmPDyaAbs,frame.dyaAbs);
	_AddFixProp(sprmPFLocked,frame.fLocked);
	_AddFixProp(sprmPDxaFromText,frame.dxaFromText);
	_AddFixProp(sprmPDyaFromText,frame.dyaFromText);
	_AddFixProp(sprmPWr,frame.wr);
	_AddFixProp(sprmPDcs,frame.dropCap);
	_AddFixProp(sprmPCantOverlap,frame.fabsnoovrlp);
	_AddFixProp(sprmPFrameTextFlow,frame.textFlow);
}

struct HtmlParaPr : HtmlParaBasePr
{
	// ---- ������� ------
	UINT32 nTableLayer;	
	
	// ---- ��ʽ��� ------
	UINT16	istd;
	
	// ---- �޶�(������޶�����ʽ��ͬ) ----

public:	
	STDMETHODIMP_(void) Reset();	
	STDMETHODIMP_(void) ConvertPapx(
		KDWPropBuffer& propx,
		HtmlDocument* doc) const;
};

inline
STDMETHODIMP_(void) HtmlParaPr::ConvertPapx(
		KDWPropBuffer& propx,
		HtmlDocument* doc) const
{
}

inline
STDMETHODIMP_(void) HtmlParaPr::Reset()
{
	ZeroMemory(this, sizeof(this));
	lspd.dyaLine = PapxDefault_dyaLine;
	lspd.fMultLinespace = PapxDefault_fMultLinespace;
	jc = mso_jcLeftJustify;
	fKinsoku = PapxDefault_fKinsoku;
	fOverflowPunct = PapxDefault_fOverflowPunct;
	wAlignFont = mso_faauto;
	lvl = PapxDefault_lvl;
	fAdjustRight = HtmlPapxDefault_fAdjustRight;
	brcTop.put_Nil();
	brcLeft.put_Nil();
	brcBottom.put_Nil();
	brcRight.put_Nil();
	brcBetween.put_Nil();
	brcBar.put_Nil();
	fUsePgsuSettings = PapxDefault_fUsePgsuSettings;
	fWordWrap = PapxDefault_fWordWrap;
	shd.put_Pattern(mso_patAutomatic);
	shd.put_ForeColor(HtmlDefaultColor);
	shd.put_BackColor(HtmlDefaultColor);
	ktab.put_Nil();
	frame.put_Nil();
}
#endif
*/
