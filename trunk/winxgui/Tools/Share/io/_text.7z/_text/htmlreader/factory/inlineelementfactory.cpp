/* -------------------------------------------------------------------------
//	�ļ���		��	inlineelementfactory.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-4 16:35:03
//	��������	��	
//
//	$Id: inlineelementfactory.cpp,v 1.3 2005/04/08 08:46:38 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "inlineelementfactory.h"
#include "core/element_span.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
InlineElementFactory::InlineElementFactory()
{
	m_span = NULL;
	m_tt = NULL;
	m_i = NULL;
	m_b = NULL;
	m_big = NULL;
	m_small = NULL;
	m_strike = NULL;
	m_s = NULL;
	m_u = NULL;
}
InlineElementFactory::~InlineElementFactory()
{
	delete m_span;
	delete m_tt;
	delete m_i;
	delete m_b;
	delete m_big;
	delete m_small;
	delete m_strike;
	delete m_s;
	delete m_u;
}
LPVOID InlineElementFactory::GetElement(HtmlElementCtrl subctrl)
{
	switch(subctrl)
	{
	case html_span:
		m_span = new HtmlElement_span;
		m_span->m_doc = m_doc;		
		return m_span;
	case html_tt:
		m_tt = new HtmlElement_tt;
		m_tt->m_doc = m_doc;		
		return m_tt;		
	case html_i:
		m_i = new HtmlElement_i;
		m_i->m_doc = m_doc;
		return m_i;
	case html_b:
		m_b = new HtmlElement_b;
		m_b->m_doc = m_doc;
		return m_b;
	case html_big:
		m_big = new HtmlElement_big;
		m_big->m_doc = m_doc;
		return m_big;
	case html_small:
		m_small = new HtmlElement_small;
		m_small->m_doc = m_doc;
		return m_small;
	case html_strike:
		m_strike = new HtmlElement_strike;
		m_strike->m_doc = m_doc;
		return m_strike;
	case html_s:
		m_s = new HtmlElement_s;
		m_s->m_doc = m_doc;
		return m_s;
	case html_u:
		m_u = new HtmlElement_u;
		m_u->m_doc = m_doc;
		return m_u;
	default:
		return NULL;
	}
}

// -------------------------------------------------------------------------
//	$Log: inlineelementfactory.cpp,v $
//	Revision 1.3  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
//	Revision 1.2  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	