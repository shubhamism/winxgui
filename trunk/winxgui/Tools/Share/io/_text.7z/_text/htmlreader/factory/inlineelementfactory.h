/* -------------------------------------------------------------------------
//	�ļ���		��	inlineelementfactory.h
//	������		��	���὿
//	����ʱ��	��	2005-4-4 16:34:37
//	��������	��	
//
//	$Id: inlineelementfactory.h,v 1.3 2005/04/08 08:46:38 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __INLINEELEMENTFACTORY_H__
#define __INLINEELEMENTFACTORY_H__
#include "elementfactory.h"
#include "core/element_inline.h"
// -------------------------------------------------------------------------

class HtmlElement_span;
class HtmlElement_tt;
class HtmlElement_i;
class HtmlElement_b;
class HtmlElement_big;
class HtmlElement_small;
class HtmlElement_strike;
class HtmlElement_s;
class HtmlElement_u;

class InlineElementFactory : public ElementFactory
{
	HtmlElement_span* m_span;
	HtmlElement_tt* m_tt;
	HtmlElement_i* m_i;
	HtmlElement_b* m_b;
	HtmlElement_big* m_big;
	HtmlElement_small* m_small;
	HtmlElement_strike* m_strike;
	HtmlElement_s* m_s;
	HtmlElement_u* m_u;
public:
	HtmlDocument* m_doc;
	InlineElementFactory();
	~InlineElementFactory();
	STDPROC_(LPVOID) GetElement(HtmlElementCtrl subctrl);
};

// -------------------------------------------------------------------------
//	$Log: inlineelementfactory.h,v $
//	Revision 1.3  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
//	Revision 1.2  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	

#endif /* __INLINEELEMENTFACTORY_H__ */
