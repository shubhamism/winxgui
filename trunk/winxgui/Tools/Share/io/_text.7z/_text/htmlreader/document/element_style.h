/* -------------------------------------------------------------------------
//	�ļ���		��	element_style.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-4-20 15:58:57
//	��������	��	
//
//	$Id: element_style.h,v 1.3 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/
#ifndef __ELEMENT_STYLE_H__
#define __ELEMENT_STYLE_H__

// -------------------------------------------------------------------------

class HtmlElement_style : public HtmlElementBase
{	
public:
	HtmlDocument* m_doc;
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
	{	
		return S_OK;
	}
	STDMETHODIMP Characters(
		IN LPCWSTR chars,
		IN UINT length);
private:
	STDMETHODIMP NewStyle(LPWSTR selector, LPWSTR stylevalue);
};

// -------------------------------------------------------------------------
//

STDMETHODIMP HtmlElement_style::NewStyle(LPWSTR selector, LPWSTR stylevalue)
{
	ParseStyleValue parse;
	HandleStyleValue handle;
	KDWPropBuffer para, span;
	handle.m_doc = m_doc;
	handle.para = &para;
	handle.span = &span;
	
	parse.Parse(stylevalue, &handle);
	
	KDWStyle style;
	m_doc->GetStyleSheet().NewStyle
		(stiUser, selector, mso_sgcParagraph, &style);
	style.SetBaseStyle(m_doc->stylesheet.GetBaseStyleId());
	style.SetSprmList(mso_sgcParagraph, &para);
	style.SetSprmList(mso_sgcCharacter, &span);
	
	m_doc->stylesheet.Insert(selector, style.GetIndex());
	return S_OK;
}

STDMETHODIMP HtmlElement_style::Characters(
										   IN LPCWSTR chars,
										   IN UINT length)
{
	LPWSTR dupstr = _wcsdup(chars);
	LPWSTR pstart = dupstr, stylevalue;
	LPWSTR selector = dupstr;
	do
	{
		//��ȡѡ���
		pstart = wcschr(pstart, '{');
		if(!pstart)
			break;
		*pstart++ = '\0';
		CutHeadEndSpace(&selector);
		selector = _wcslwr(selector);
		//��ȡ��ʽֵ
		stylevalue = pstart;
		pstart = wcschr(pstart, '}');
		if(!pstart)
			break;
		*pstart++ = '\0';
		//����
		printf("%S\n%S\n", selector, stylevalue);
		NewStyle(selector, stylevalue);
		selector = pstart;
	}while(1);
	free(dupstr);
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: element_style.h,v $
//	Revision 1.3  2005/04/22 07:43:01  zhangqingyuan
//	*** empty log message ***
//	
//	Revision 1.1  2005/04/20 08:04:28  xushiwei
//	��cvs�ָ���
//	

#endif /* __ELEMENT_STYLE_H__ */
