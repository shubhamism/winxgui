/* -------------------------------------------------------------------------
//	�ļ���		��	BlockElementFactory.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-4 15:05:17
//	��������	��	
//
//	$Id: blockelementfactory.cpp,v 1.2 2005/04/06 08:41:12 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "blockelementfactory.h"
#include "core/element_p.h"
#include "core/element_div.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
BlockElementFactory::BlockElementFactory()
{
	p = NULL;
	div = NULL;
}

BlockElementFactory::~BlockElementFactory()
{
	delete p;
	delete div;
}

LPVOID BlockElementFactory::GetElement(HtmlElementCtrl subctrl)
{
	switch(subctrl)
	{
	case html_p:
		p = new HtmlElement_p;
		p->m_doc = m_doc;
		return p;
	case html_div:
		div = new HtmlElement_div;
		div->m_doc = m_doc;
		return div;
	default:
		return NULL;
	}
}

// -------------------------------------------------------------------------
//	$Log: blockelementfactory.cpp,v $
//	Revision 1.2  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	
