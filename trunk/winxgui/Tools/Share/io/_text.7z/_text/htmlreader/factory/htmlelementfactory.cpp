/* -------------------------------------------------------------------------
//	�ļ���		��	htmlelementfactory.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-4 15:48:36
//	��������	��	
//
//	$Id: htmlelementfactory.cpp,v 1.1 2005/04/04 10:49:58 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htmlelementfactory.h"
#include "document/element_html.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
HtmlElementFactory::HtmlElementFactory()
{
	head = NULL;
	body = NULL;
}

HtmlElementFactory::~HtmlElementFactory()
{
	delete head;
	delete body;
}

LPVOID HtmlElementFactory::GetElement(HtmlElementCtrl subctrl)
{
	switch(subctrl)
	{
	case html_head:
		head = new HtmlElement_head;
		head->m_doc = m_doc;		
		return head;
	case html_body:
		body = new HtmlElement_body;
		body->m_doc = m_doc;
		return body;
	default:
		return NULL;
	}
}
// -------------------------------------------------------------------------
//	$Log: htmlelementfactory.cpp,v $
//	Revision 1.1  2005/04/04 10:49:58  xushiwei
//	*** empty log message ***
//	
