/* -------------------------------------------------------------------------
//	�ļ���		��	htmlelementfactory.h
//	������		��	���὿
//	����ʱ��	��	2005-4-4 15:46:22
//	��������	��	
//
//	$Id: htmlelementfactory.h,v 1.1 2005/04/04 10:49:58 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __HTMLELEMENTFACTORY_H__
#define __HTMLELEMENTFACTORY_H__
// -------------------------------------------------------------------------
#include "elementfactory.h"

class HtmlElement_head;
class HtmlElement_body;

class HtmlElementFactory : public ElementFactory
{
private:
	HtmlElement_head* head;
	HtmlElement_body* body;
public:
	HtmlDocument* m_doc;
	HtmlElementFactory();
	~HtmlElementFactory();
	STDPROC_(LPVOID) GetElement(HtmlElementCtrl subctrl);
};

// -------------------------------------------------------------------------
//	$Log: htmlelementfactory.h,v $
//	Revision 1.1  2005/04/04 10:49:58  xushiwei
//	*** empty log message ***
//	

#endif /* __HTMLELEMENTFACTORY_H__ */
