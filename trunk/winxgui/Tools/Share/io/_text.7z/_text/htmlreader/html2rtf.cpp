// $Id: html2rtf.cpp,v 1.6 2005/04/22 07:43:01 zhangqingyuan Exp $
//

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define X_NO_AUTOINIT
#define X_NO_DEBUG_STRATEGY
#include <kso/io/html/html2rtf.h>
#include <kfc.h>

int main()
{
	if (__argc < 2)
		return -1;

	LPCWSTR szSrcFile = __wargv[1];

	WCHAR szDestFile[_MAX_PATH];
	wcscpy(szDestFile, szSrcFile);
	wcscat(szDestFile, __X(".rtf"));

	WCHAR szDestFile2[_MAX_PATH];
	wcscpy(szDestFile2, szSrcFile);
	wcscat(szDestFile2, __X(".htm"));

	printf("processing %S ... ", szSrcFile);
	
	HRESULT hr = E_FAIL;
	try
	{
		hr = VerifyConvertHtml2Rtf(szSrcFile, szDestFile, szDestFile2);
	}
	catch (...)
	{
	}

	if (FAILED(hr))
	{
		printf("failed!\n");
		getchar();
	}
	else
	{
		printf("ok!\n");
	}
	return 0;
}

// -------------------------------------------------------------------------
//	$Log: html2rtf.cpp,v $
//	Revision 1.6  2005/04/22 07:43:01  zhangqingyuan
//	*** empty log message ***
//	
//	Revision 1.4  2005/04/19 09:53:10  xushiwei
//	1��ConvertHtml2Rtf => VerifyConvertHtml2Rtf��
//	
//	Revision 1.3  2005/04/01 10:01:05  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2005/02/05 02:45:51  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2005/01/23 03:52:52  xushiwei
//	��ɡ�
//	
