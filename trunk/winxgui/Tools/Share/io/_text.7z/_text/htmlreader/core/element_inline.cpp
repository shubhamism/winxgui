/* -------------------------------------------------------------------------
//	�ļ���		��	element_inline.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-8 13:11:22
//	��������	��	
//
//	$Id: element_inline.cpp,v 1.2 2005/04/08 09:22:30 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "element_inline.h"
#include "include/parsestylevalue.h"
#include "factory/inlineelementfactory.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// -------------------------------------------------------------------------
// HtmlElement_inline
STDMETHODIMP_(void) HtmlElement_inline::NewInlineElementFactory()
{
	m_factory = new InlineElementFactory;
	m_factory->m_doc = m_doc;
}

STDMETHODIMP_(void) HtmlElement_inline::DeleteInlineElementFactory()
{
	delete m_factory;	
}

STDMETHODIMP_(void) HtmlElement_inline::BackupData()
{
	m_backupPara = m_doc->para;
	m_backupSpan = m_doc->span;
}

STDMETHODIMP_(void) HtmlElement_inline::RestoreData()
{
	m_doc->para = m_backupPara;
	m_doc->span = m_backupSpan;
}

STDMETHODIMP HtmlElement_inline::Characters(
		IN LPCWSTR chars,
		IN UINT length)
{	
	m_doc->AddContent(chars, length);
	return S_OK;
}
STDMETHODIMP HtmlElement_inline::EnterSubElement(
	IN HtmlElementCtrl subctrl,
	OUT HtmlElement** subhandler)
{	
	ASSERT(m_factory);
	*subhandler = (HtmlElement*)m_factory->GetElement(subctrl);
	return S_OK;
}


STDMETHODIMP HtmlElement_inline::EndElement(
		IN HtmlElementCtrl element)
{
	RestoreData();
	DeleteInlineElementFactory();
	return S_OK;
}

STDMETHODIMP HtmlElement_inline::AddAttributes(
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	for(; attr!=attrEnd; ++attr)
	{
		switch(attr->attr)
		{
		case html_attr_id:
			break;
		case html_attr_class:
			break;
		case html_attr_lang:
			break;
		case html_attr_dir:
			break;
		case html_attr_title:
			break;
		case html_attr_style:
			{
				ParseStyleValue psv;
				HandleStyleValue handle;
				handle.elementtype = html_inline;
				handle.para = &m_doc->para;
				handle.span = &m_doc->span;
				handle.m_doc = m_doc;
				psv.Parse(attr->value, &handle);
				m_doc->PutRgBRC(html_inline);
				m_doc->PutSHD(html_inline);
			}
			break;
		case html_attr_onclick:
			break;
		case html_attr_ondblclick:
			break;
		case html_attr_onmousedown:
			break;
		case html_attr_onmouseup:
			break;
		case html_attr_onmouseover:
			break;
		case html_attr_onmousemove:
			break;
		case html_attr_onmouseout:
			break;
		case html_attr_onkeypress:
			break;
		case html_attr_onkeydown:
			break;
		case html_attr_onkeyup:
			break;
		default:
			return E_UNEXPECTED;
		}
	}
	return S_OK;	
}
// -------------------------------------------------------------------------
// HtmlElement_i
STDMETHODIMP HtmlElement_i::StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	NewInlineElementFactory();

	BackupData();
	m_doc->span.AddPropFix(sprmCFItalic, TRUE);
	AddAttributes(attr, attrEnd);
	return S_OK;
}

// -------------------------------------------------------------------------
// HtmlElement_b
STDMETHODIMP HtmlElement_b::StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	NewInlineElementFactory();
	BackupData();
	m_doc->span.AddPropFix(sprmCFBold, TRUE);
	AddAttributes(attr, attrEnd);
	return S_OK;
}

// -------------------------------------------------------------------------
// HtmlElement_big
STDMETHODIMP HtmlElement_big::StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	NewInlineElementFactory();

	BackupData();
	m_doc->span.AddPropFix(sprmCHps, 27);
	AddAttributes(attr, attrEnd);
	return S_OK;
}

// -------------------------------------------------------------------------
// HtmlElement_small
STDMETHODIMP HtmlElement_small::StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	NewInlineElementFactory();

	BackupData();
	m_doc->span.AddPropFix(sprmCHps, 21);
	AddAttributes(attr, attrEnd);
	return S_OK;
}

// -------------------------------------------------------------------------
// HtmlElement_strike
STDMETHODIMP HtmlElement_strike::StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	NewInlineElementFactory();

	BackupData();
	m_doc->span.AddPropFix(sprmCFStrike, TRUE);
	AddAttributes(attr, attrEnd);
	return S_OK;
}

// -------------------------------------------------------------------------
// HtmlElement_u
STDMETHODIMP HtmlElement_u::StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
{
	NewInlineElementFactory();

	BackupData();
	m_doc->span.AddPropFix(sprmCKul, mso_ulSingle);
	m_doc->span.AddPropFix(sprmCKulColor, HtmlDefaultColor);
	AddAttributes(attr, attrEnd);
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: element_inline.cpp,v $
//	Revision 1.2  2005/04/08 09:22:30  xushiwei
//	�����˶��ַ����ƺͱ߿�Ĵ���
//	
//	Revision 1.1  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
