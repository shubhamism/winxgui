/* -------------------------------------------------------------------------
//	�ļ���		��	htmlreader.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-2-5 9:49:25
//	��������	��	
//
//	$Id: htmlreader.cpp,v 1.11 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "document/element_html.h"
#include <htmldoc.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class Html2DocHandler : public HtmlDispatcher
{
private:
	HtmlElement_html m_html;
	HtmlDocument m_doc;
	
public:
	Html2DocHandler(IN IStorage* pDocStorage)
		: HtmlDispatcher(&m_html)
	{
		m_html.m_doc = &m_doc;
		m_doc.NewDocument(pDocStorage);
	}
	~Html2DocHandler()
	{
		m_doc.Close();
	}
};

// -------------------------------------------------------------------------

BOOL APIENTRY DllMain( HANDLE hModule, 
					  DWORD  ul_reason_for_call, 
					  LPVOID lpReserved
					  )
{
	//SetBreakAlloc(1407);
    return TRUE;
}

// -------------------------------------------------------------------------

EXPORTAPI htmlExport(IN IStream* htmlStrm, IN IStorage* docStg)
{
	Html2DocHandler* handler = new Html2DocHandler(docStg);
	HtmlParser<Html2DocHandler> parser(htmlStrm);
	
	HRESULT hr = parser.Parse(handler);
	ASSERT_OK(hr);
	
	delete handler;
	return hr;
}

EXPORTAPI htmlExportEx(IN LPCWSTR htmlFile, IN IStorage* docStg)
{
	Html2DocHandler* handler = new Html2DocHandler(docStg);
	HtmlParser<Html2DocHandler> parser(htmlFile);
	
	HRESULT hr = parser.Parse(handler);
	ASSERT_OK(hr);
	
	delete handler;
	return hr;
}

EXPORTAPI htmlConvert(IN LPCWSTR htmlFile, IN LPCWSTR docFile)
{
	ks_stdptr<IStorage> spRootStg;
	
	HRESULT hr = StgCreateDocfile(
		docFile, STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE, 0, &spRootStg);
	ASSERT_OK(hr);
	
	if (FAILED(hr))
		return hr;
	
	return htmlExportEx(htmlFile, spRootStg);
}

// -------------------------------------------------------------------------
//	$Log: htmlreader.cpp,v $
//	Revision 1.11  2005/04/22 07:43:01  zhangqingyuan
//	*** empty log message ***
//	
//	Revision 1.9  2005/04/20 08:04:27  xushiwei
//	��cvs�ָ���
//	
//	Revision 1.8  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	
//	Revision 1.5  2005/03/02 03:28:43  xushiwei
//	ȷ��Close�����á�
//	
//	Revision 1.4  2005/03/02 03:19:13  xushiwei
//	������ɹ��ܡ�
//	
//	Revision 1.2  2005/02/05 03:39:56  xushiwei
//	����htmlreader���̡�
//	
