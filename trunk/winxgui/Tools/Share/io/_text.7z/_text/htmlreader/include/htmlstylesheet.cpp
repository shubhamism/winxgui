/* -------------------------------------------------------------------------
//	�ļ���		��	htmlstylesheet.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-5 15:52:17
//	��������	��	
//
//	$Id: htmlstylesheet.cpp,v 1.2 2005/04/06 08:41:12 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htmlstylesheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP_(void) HtmlStyleSheet::Insert(LPCWSTR stylename, UINT id)
{
	m_map.insert(value_type(stylename, id));	
}

UINT HtmlStyleSheet::LookUp(LPCWSTR stylename)
{		
	if(m_map.count(stylename))
		return m_map[stylename];
	else
		return style_not_exist;
}

STDMETHODIMP_(void) HtmlStyleSheet::SetBaseStyleId(UINT id)
{
	m_basestyleid = id;	
}

UINT HtmlStyleSheet::GetBaseStyleId()
{
	return m_basestyleid;
}
// -------------------------------------------------------------------------
//	$Log: htmlstylesheet.cpp,v $
//	Revision 1.2  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	
