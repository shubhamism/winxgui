/* -------------------------------------------------------------------------
//	�ļ���		��	handlestylevalue.h
//	������		��	���὿
//	����ʱ��	��	2005-4-1 19:09:23
//	��������	��	
//
//	$Id: handlestylevalue.h,v 1.6 2005/04/08 09:22:30 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __HANDLESTYLEVALUE_H__
#define __HANDLESTYLEVALUE_H__

#include "../include/kso/io/html/parser/htmltypes.h"

class handle_text_decoration
{
public:
	handle_text_decoration(KDWPropBuffer* span)
	{
		m_span = span;		
	}
	STDMETHODIMP HandleValue(LPWSTR szAttrValue)
	{		
		return AddAttribute_text_decoration(m_span, szAttrValue);
	}
private:
	KDWPropBuffer* m_span;	
};

class handle_one_border
{
public:
	handle_one_border(KDWBrc& brc) : m_brc(brc)
	{
	}
	STDMETHODIMP HandleValue(LPWSTR szAttrValue)
	{		
		if(szAttrValue[0] == '#')//����ɫ
		{
			m_brc.crFore = get_color(szAttrValue);
		}
		else if(isdigit(szAttrValue[0]))
			m_brc.dptLineWidth = get_border_width(szAttrValue,wcslen(szAttrValue));
		else
		{
			UINT16 style = get_border_style(szAttrValue);
			if(style != mso_brcNone)
				m_brc.brcType = style;
			else
				m_brc.crFore = get_color(szAttrValue);
		}
		return S_OK;
	}
private:
	KDWBrc& m_brc;
};

class HandleStyleValue
{
public:
	UINT32 elementtype;
	HtmlDocument* m_doc;
	KDWPropBuffer* span;
	KDWPropBuffer* para;	
	HandleStyleValue();	
	STDMETHODIMP HandleValue(htmlprop_t name, LPWSTR value);
private:
	STDMETHODIMP AddAttribute_span(htmlprop_t name, LPWSTR value);
	STDMETHODIMP AddAttribute_para(htmlprop_t name, LPWSTR value);	
	STDMETHODIMP AddAttribute_brc(htmlprop_t name, LPWSTR value);	
	STDMETHODIMP AddAttribute_text_decorations(LPWSTR value);
	STDMETHODIMP AddAttribute_one_border(KDWBrc& brc, LPWSTR value);
	STDMETHODIMP AddAttribute_shd(htmlprop_t name, LPWSTR value);
	STDMETHODIMP AddAttribute_location(htmlprop_t name, LPWSTR value);
};
#endif /* __HANDLESTYLEVALUE_H__ */
