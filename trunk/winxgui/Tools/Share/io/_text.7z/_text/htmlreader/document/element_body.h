/* -------------------------------------------------------------------------
//	�ļ���		��	element_body.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-3-2 11:41:01
//	��������	��	
//
//	$Id: element_body.h,v 1.14 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/
#ifndef __ELEMENT_BODY_H__
#define __ELEMENT_BODY_H__

class HtmlDocument;

class HtmlElement_body : public HtmlElementBase
{
public:
	HtmlDocument* m_doc;

	STDMETHODIMP EnterSubElement(
		IN HtmlElementCtrl subctrl,
		OUT HtmlElement** subhandler);	
};

// -------------------------------------------------------------------------
// $Log: element_body.h,v $
// Revision 1.14  2005/04/22 07:43:01  zhangqingyuan
// *** empty log message ***
//
// Revision 1.13  2005/04/20 08:04:28  xushiwei
// ��cvs�ָ���
//

#endif /* __ELEMENT_BODY_H__ */
