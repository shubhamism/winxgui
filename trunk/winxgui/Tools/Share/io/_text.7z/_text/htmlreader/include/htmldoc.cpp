/* -------------------------------------------------------------------------
//	�ļ���		��	htmldoc.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-6 10:07:30
//	��������	��	
//
//	$Id: htmldoc.cpp,v 1.10 2005/04/08 10:00:14 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "htmldoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
STDMETHODIMP HtmlDocument::NewDocument(
	IN IStorage* pStorage)
{
	Base::NewDocument(pStorage);
	Base::NewNullSepxSection();
	InitState();
	return S_OK;
}

STDMETHODIMP_(void) HtmlDocument::InitState()
{
	InitBrcs(rgBrc, IMaxBRC);
	chBrc.put_Nil();
	shd.put_Pattern(mso_patAutomatic);
	shd.put_ForeColor(HtmlDefaultColor);
	shd.put_BackColor(HtmlDefaultColor);
	chshd.put_Pattern(mso_patAutomatic);
	chshd.put_ForeColor(HtmlDefaultColor);
	chshd.put_BackColor(HtmlDefaultColor);
	para.AddIstd(0);
	KDWStyle normal;
	NewNormalStyle(normal);
	para.AddPropFix(sprmPIstd, normal.GetIndex());
}

STDMETHODIMP_(void) HtmlDocument::PutRgBRC(UINT elementtype, BOOL beInit)
{
	switch(elementtype)
	{
	case html_p:
		AddBrcs(para, rgBrc);
		if(beInit)
			InitRgBRC();
		break;
	case html_inline:
		span.AddPropFix(sprmCBrc, (UINT32&)chBrc.get_Brc());
		span.AddPropVar(sprmCBrcEx, (LPVOID)&chBrc, sizeof(KDWBrc));
		if(beInit)
			chBrc.put_Nil();
		break;		
	}		
}

STDMETHODIMP_(void) HtmlDocument::PutSHD(UINT elementtype, BOOL beInit)
{	
	switch(elementtype)
	{
	case html_p:
		shd.put_Pattern(mso_patAutomatic);
		para.AddPropVar(sprmPShdEx, &shd, sizeof(KDWShd));
		if(beInit)
		{
			shd.put_Pattern(mso_patAutomatic);
			shd.put_ForeColor(HtmlDefaultColor);
			shd.put_BackColor(HtmlDefaultColor);
		}
		break;
	case html_inline:
		chshd.put_Pattern(mso_patAutomatic);
		span.AddPropVar(sprmCShdEx, &chshd, sizeof(KDWShd));
		if(beInit)
		{
			chshd.put_Pattern(mso_patAutomatic);
			chshd.put_ForeColor(HtmlDefaultColor);
			chshd.put_BackColor(HtmlDefaultColor);
		}
		break;
	}	
}
STDMETHODIMP_(void) HtmlDocument::InitRgBRC()
{
	InitBrcs(rgBrc);
}
STDMETHODIMP HtmlDocument::NewParagraph()
{		
	Base::NewParagraph(&para);
	return S_OK;
}
STDMETHODIMP HtmlDocument::EndParagraph()
{		
	AddContent(0x0d);		
	return S_OK;
}
STDMETHODIMP HtmlDocument::AddContent(IN LPCWSTR cont, IN UINT cch)
{
	int i;
	std::vector<WCHAR> buffer;
	for(i=0; i<cch; ++i)
	{
		if(cont[i] != '\r' && cont[i] != '\n')
			buffer.push_back(cont[i]);
	}
	Base::NewSpan(&span);
	Base::AddContent(buffer.begin(), buffer.size());
	return S_OK;
}
STDMETHODIMP HtmlDocument::AddContent(IN WCHAR ch)
{	
	Base::NewSpan(&span);
	Base::AddContent(ch);
	return S_OK;
}
STDMETHODIMP_(void) HtmlDocument::NewNormalStyle(KDWStyle& normal)
{
	KDWPropBuffer para, span;
	para.AddIstd(0);
	para.AddPropFix(sprmPFWidowControl, TRUE);
	span.AddPropFix(sprmCHps, 24);
	span.AddPropFix(sprmCRgLid0, 0x409);
	span.AddPropFix(sprmCRgLid0Ex, 0x409);
	span.AddPropFix(sprmCRgLid1, 0x804);
	span.AddPropFix(sprmCRgLid1Ex, 0x804);
	
	Base::GetStyleSheet().NewStyle
		(stiUser, __X("��ͨ(��վ)"), mso_sgcParagraph, &normal);
	normal.SetSprmList(mso_sgcParagraph, &para);
	normal.SetSprmList(mso_sgcCharacter, &span);
	
	stylesheet.SetBaseStyleId(normal.GetIndex());	
	stylesheet.Insert(__X("��ͨ(��վ)"), normal.GetIndex());
}
// -------------------------------------------------------------------------
//	$Log: htmldoc.cpp,v $
//	Revision 1.10  2005/04/08 10:00:14  xushiwei
//	4��8��
//	
//	Revision 1.9  2005/04/08 09:22:30  xushiwei
//	�����˶��ַ����ƺͱ߿�Ĵ���
//	
//	Revision 1.8  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
//	Revision 1.7  2005/04/07 10:02:41  xushiwei
//	�����˵���
//	
//	Revision 1.6  2005/04/06 02:15:39  xushiwei
//	����htmldoc.cpp
//	
//	Revision 1.12  2005/04/05 01:25:27  xushiwei
//	�޸�AddAttribute_line_height
//	Revision 1.4  2005/03/16 03:18:28  xushiwei
//	��ȡ�ı�����
//	Revision 1.1  2005/03/02 03:19:13  xushiwei
//	������ɹ��ܡ�
//	
// -------------------------------------------------------------------------
//	$Log: htmldoc.cpp,v $
//	Revision 1.10  2005/04/08 10:00:14  xushiwei
//	4��8��
//	
//	Revision 1.9  2005/04/08 09:22:30  xushiwei
//	�����˶��ַ����ƺͱ߿�Ĵ���
//	
//	Revision 1.8  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
//	Revision 1.7  2005/04/07 10:02:41  xushiwei
//	�����˵���
//	
//	Revision 1.6  2005/04/06 02:15:39  xushiwei
//	����htmldoc.cpp
//	
