/* -------------------------------------------------------------------------
//	�ļ���		��	method.h
//	������		��	���὿
//	����ʱ��	��	2005-4-1 18:57:57
//	��������	��	
//
//	$Id: method.h,v 1.8 2005/04/07 10:02:41 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __METHOD_H__
#define __METHOD_H__
#include "../include/kso/io/html/parser/htmltypes.h"

class HtmlDocument;
inline
void CutHeadEndSpace(LPWSTR* pszStr)
{
	int i;
	LPWSTR szStr = *pszStr;	
	for(i=0; i<wcslen(*pszStr); ++i)
	{
		if(!isspace((*pszStr)[i]))
			break;
		++szStr;
	}
	for(i=wcslen(*pszStr)-1; i>=0; --i)
	{
		if(isspace((*pszStr)[i]))
			(*pszStr)[i]='\0';
		else
			break;
	}
	*pszStr = szStr;
}

inline
UNIT_TYPE GetUnitType(LPWSTR szAttrValue)
{
	UNIT_TYPE ret;
	LPWSTR pStart = szAttrValue, pEnd = szAttrValue+wcslen(szAttrValue);
	while(pStart!=pEnd)
	{
		if(!isdigit(*pStart))
			break;
		++pStart;
	}
	if(!wcsnicmp(pStart,__X("em"),2))
		ret = unit_em;
	else if(!wcsnicmp(pStart,__X("ex"),2))
		ret = unit_ex;
	else if(!wcsnicmp(pStart,__X("px"),2))
		ret = unit_px;
	else if(!wcsnicmp(pStart,__X("in"),2))
		ret = unit_in;
	else if(!wcsnicmp(pStart,__X("cm"),2))
		ret = unit_cm;
	else if(!wcsnicmp(pStart,__X("mm"),2))
		ret = unit_mm;
	else if(!wcsnicmp(pStart,__X("pt"),2))
		ret = unit_pt;
	else if(!wcsnicmp(pStart,__X("pc"),2))
		ret = unit_pc;
	else if(!wcsnicmp(pStart,__X("%"),1))
		ret = unit_percentage;
	else
		ret = unit_none;
	return ret;
}

inline
JC GetJc(LPCWSTR szJc)
{
	if(!wcsicmp(szJc,__X("left")))
		return mso_jcLeftJustify;
	else if(!wcsicmp(szJc,__X("right")))
		return mso_jcRightJustify;
	else if(!wcsicmp(szJc,__X("center")))
		return mso_jcCenter;
	else if(!wcsicmp(szJc,__X("justify")))
		return mso_jcLeftAndRightJustify;
	else
		return mso_jcLeftJustify;
}

inline
DOUBLE px2pt(DOUBLE px)
{
	int pxsPerinch = GetDeviceCaps(GetDC(NULL),LOGPIXELSX);
	DOUBLE inchs = px / pxsPerinch;
	return inchs*72;
}

inline
DOUBLE ToPt(DOUBLE value, UNIT_TYPE unitType)
{
	switch(unitType)
	{
	case unit_px:
		return px2pt(value);
	case unit_in:
		return value*72;
	case unit_cm:
		return value*(567.36/20);
	case unit_mm:
		return value*(56.736/20);
	case unit_pt:
		return value;
	case unit_pc:
		return value*12;
	case unit_em:
	case unit_ex:
	case unit_none:
	default:
		return px2pt(value);
	}
}

inline
size_t FindFirstSpace(LPWSTR* szAttrValue)
{
	CutHeadEndSpace(szAttrValue);
	size_t i;
	for(i=0; i<wcslen(*szAttrValue); ++i)
	{
		if(isspace((*szAttrValue)[i]))
			return i;
	}
	return 0;
}

inline
UINT32 get_font_size(LPWSTR szAttrValue)
{		
	if(!wcsicmp(szAttrValue, __X("xx_small")))
		return 7.5*2;
	else if(!wcsicmp(szAttrValue, __X("x_small")))
		return 10*2;
	else if(!wcsicmp(szAttrValue, __X("small")))
		return 12*2;
	else if(!wcsicmp(szAttrValue, __X("medium")))
		return 13.5*2;
	else if(!wcsicmp(szAttrValue, __X("large")))
		return 18*2;
	else if(!wcsicmp(szAttrValue, __X("x_large")))
		return 24*2;
	else if(!wcsicmp(szAttrValue, __X("xx_large")))
		return 36*2;
	else if(!wcsicmp(szAttrValue, __X("smaller")))
		return get_font_size_invalid;
	else if(!wcsicmp(szAttrValue, __X("larger")))
		return get_font_size_invalid;
	else	
	{
		UNIT_TYPE tp = GetUnitType(szAttrValue);
		if(tp != unit_percentage)
		{			
			USES_CONVERSION;
			DOUBLE value = atof(W2A(szAttrValue));
			if(value)
			{
				return ToPt(value, tp)*2;
			}
		}
		else
			;//@todo
	}
	return get_font_size_invalid;
}

inline
COLORREF get_color(LPWSTR szColorValue)
{		
	int i, crRed = 0, crGreen = 0, crBlue = 0, digs[6];
	if(szColorValue[0] == '#')
	{
		++szColorValue;
		if(wcslen(szColorValue)<6)
			return HtmlDefaultColor;
		for(i=0; i<6; ++i)
		{
			digs[i] = _KsoXDigit(szColorValue[i]);
			if(digs[i] == -1)
				return HtmlDefaultColor;
		}
		crRed = (crRed << 4) | digs[0];
		crRed = (crRed << 4) | digs[1];
		crGreen = (crGreen << 4) | digs[2];
		crGreen = (crGreen << 4) | digs[3];
		crBlue = (crBlue << 4) | digs[4];
		crBlue = (crBlue << 4) | digs[5];
		return RGB(crRed,crGreen,crBlue);
	}
	else
	{		
		szColorValue = _wcslwr(szColorValue);
		if(GetHtmlColorToIdMap().count(szColorValue))
			return GetHtmlColorToIdMap()[szColorValue];
		else
		{
			if(!wcsnicmp(szColorValue,__X("rgb"),3))
			{
				szColorValue+=3;
				CutHeadEndSpace(&szColorValue);
				if(szColorValue[0]=='(' && szColorValue[wcslen(szColorValue)-1]==')')
				{
					LPWSTR redStr, greenStr, blueStr;
					redStr = ++szColorValue;
					greenStr = wcschr(szColorValue, ',');
					if(!greenStr)
						return HtmlDefaultColor;
					*greenStr++ = '\0';
					blueStr = wcschr(greenStr, ',');
					if(!blueStr)
						return HtmlDefaultColor;
					*blueStr++ = '\0';
					crRed = _wtoi(redStr);
					crGreen = _wtoi(greenStr);
					crBlue = _wtoi(blueStr);
					return RGB(crRed, crGreen, crBlue);
				}
			}
		}
	}
	return HtmlDefaultColor;
}
inline
BOOL get_font_style(LPWSTR szAttrValue)
{		
	if( !wcsicmp(szAttrValue, __X("italic")) ||
	    !wcsicmp(szAttrValue, __X("oblique")) )
		return TRUE;
	else
		return FALSE;	
}
inline
BOOL get_font_weight(LPWSTR szAttrValue)
{	
	if( !wcsicmp(szAttrValue, __X("bold")) ||
		!wcsicmp(szAttrValue, __X("bolder")) ||
		!wcsicmp(szAttrValue, __X("lighter")) ||
		!wcsicmp(szAttrValue, __X("100")) ||
		!wcsicmp(szAttrValue, __X("200")) ||
		!wcsicmp(szAttrValue, __X("300")) ||
		!wcsicmp(szAttrValue, __X("400")) ||
		!wcsicmp(szAttrValue, __X("500")) ||
		!wcsicmp(szAttrValue, __X("600")) ||
		!wcsicmp(szAttrValue, __X("700")) ||
		!wcsicmp(szAttrValue, __X("800")) ||
		!wcsicmp(szAttrValue, __X("900"))
		)
		return TRUE;
	else
		return FALSE;	
}

inline
STDMETHODIMP AddAttribute_text_decoration(KDWPropBuffer* span, LPWSTR szAttrValue)
{	
	if( !wcsicmp(szAttrValue, __X("underline")) )
	{		
		span->AddPropFix(sprmCKul, mso_ulSingle);
		span->AddPropFix(sprmCKulColor, HtmlDefaultColor);		
	}
	else if( !wcsicmp(szAttrValue, __X("line-through")))
		span->AddPropFix(sprmCFStrike, TRUE);		
	else if( !wcsicmp(szAttrValue, __X("none")))
	{
		span->AddPropFix(sprmCKul, mso_ulNone);
		span->AddPropFix(sprmCKulColor, HtmlDefaultColor);
		span->AddPropFix(sprmCFStrike, FALSE);		
	}
	else
		return E_UNEXPECTED;
	return S_OK;
}

inline
BOOL get_font_variant(LPWSTR szAttrValue)
{	
	if( !wcsicmp(szAttrValue, __X("small-caps")))
		return TRUE;
	else
		return FALSE;	
}

inline
BOOL get_text_transform(LPWSTR szAttrValue)
{	
	if( !wcsicmp(szAttrValue, __X("uppercase")))
		return TRUE;
	else
		return FALSE;	
}

inline
BOOL get_visibility(LPWSTR szAttrValue)
{		
	if( !wcsicmp(szAttrValue, __X("hidden")))
		return TRUE;
	else
		return FALSE;	
}

inline
INT32 get_value(LPWSTR szAttrValue, UINT32 multiby)
{
	UNIT_TYPE tp = GetUnitType(szAttrValue);
	if(tp!=unit_percentage)
	{
		USES_CONVERSION;
		DOUBLE value = atof(W2A(szAttrValue));
		if(value)
		{
			return ToPt(value,tp)*multiby;			
		}
	}
	else
		;	//@todo
	return get_value_invalid;
}

inline
UINT8 get_text_align(LPWSTR szAttrValue)
{		
	return GetJc(szAttrValue);	
}

inline
STDMETHODIMP AddAttribute_line_height(KDWPropBuffer* para, LPWSTR szAttrValue)
{
	UNIT_TYPE tp = GetUnitType(szAttrValue);
	USES_CONVERSION;
	DOUBLE value = atof(W2A(szAttrValue));
	if(!value)
		return E_UNEXPECTED;
	LSPD lspd;
	if(tp!=unit_percentage && tp!=unit_none)
	{		
		lspd.fMultLinespace = 0;
		lspd.dyaLine = ToPt(value,tp)*20;		
	}
	else
	{
		lspd.fMultLinespace = 1;		
		if(tp != unit_none)
			lspd.dyaLine = 240*(value/100);
		else
			lspd.dyaLine = 240*value;
	}
	para->AddPropFix(sprmPDyaLine, lspd);
	return S_OK;
}

inline
STDMETHODIMP AddAttribute_margin(KDWPropBuffer* para, LPWSTR szAttrValue)
{
	size_t ispace = FindFirstSpace(&szAttrValue);
	INT32 beforeValue = get_value(szAttrValue, 20);
	if(beforeValue != get_value_invalid)
		para->AddPropFix(sprmPDyaBefore, beforeValue);
	if(!ispace)
	{
		para->AddPropFix(sprmPDyaAfter, beforeValue);		
		para->AddPropFix(sprmPDxaLeft, beforeValue);
		para->AddPropFix(sprmPDxaLeftEx, beforeValue);
		para->AddPropFix(sprmPDxaRight, beforeValue);
		para->AddPropFix(sprmPDxaRightEx, beforeValue);
		return S_OK;
	}

	szAttrValue+=ispace;
	ispace = FindFirstSpace(&szAttrValue);
	INT32 rightValue = get_value(szAttrValue, 20);
	if(rightValue != get_value_invalid)
	{
		para->AddPropFix(sprmPDxaRight, rightValue);
		para->AddPropFix(sprmPDxaRightEx, rightValue);
	}
	if(!ispace)
	{			
		para->AddPropFix(sprmPDyaAfter, beforeValue);
		para->AddPropFix(sprmPDxaLeft, rightValue);
		para->AddPropFix(sprmPDxaLeftEx, rightValue);		
		return S_OK;
	}
	szAttrValue+=ispace;
	ispace = FindFirstSpace(&szAttrValue);
	INT32 afterValue = get_value(szAttrValue, 20);
	if(afterValue != get_value_invalid)
		para->AddPropFix(sprmPDyaAfter, afterValue);		
	if(!ispace)
	{
		para->AddPropFix(sprmPDxaLeft, rightValue);
		para->AddPropFix(sprmPDxaLeftEx, rightValue);		
		return S_OK;
	}
	szAttrValue+=ispace;
	ispace = FindFirstSpace(&szAttrValue);
	INT32 leftValue = get_value(szAttrValue, 20);
	if(leftValue != get_value_invalid)
	{
		para->AddPropFix(sprmPDxaLeft, leftValue);
		para->AddPropFix(sprmPDxaLeftEx, leftValue);
	}	
	return S_OK;
}

inline
UINT16 get_border_style(LPWSTR szAttrValue)
{			
	if( !wcsicmp(szAttrValue, __X("solid")) )
		return mso_brcSingle;
	else if( !wcsicmp(szAttrValue, __X("dotted")) )
		return mso_brcDot;
	else if( !wcsicmp(szAttrValue, __X("dashed")) )
		return mso_brcDashLarge;
	else if( !wcsicmp(szAttrValue, __X("double")) )
		return mso_brcDouble;
	else if( !wcsicmp(szAttrValue, __X("groove")) )
		return mso_brcEngrave;
	else if( !wcsicmp(szAttrValue, __X("ridge")) )
		return mso_brcEmboss;
	else if( !wcsicmp(szAttrValue, __X("inset")) )
		return mso_brcInset;
	else if( !wcsicmp(szAttrValue, __X("outset")) )
		return mso_brcOutset;
	else
		return mso_brcNone;	
}

inline
UINT16 get_border_width(LPWSTR szAttrValue, size_t ispace)
{
	UNIT_TYPE tp = GetUnitType(szAttrValue);
	USES_CONVERSION;
	DOUBLE value = atof(W2A(szAttrValue));
	*(szAttrValue+ispace) = '\0';
	if(value)
		return ToPt(value,tp)*8;
	else
	{
		if(!wcsicmp(szAttrValue,__X("thin")))
			return 0.25*8;
		else if(!wcsicmp(szAttrValue,__X("medium")))
			return 1.5*8;
		else if(!wcsicmp(szAttrValue,__X("thick")))
			return 3*8;
	}
	return 0;
}

inline
STDMETHODIMP_(void) AddBrc(KDWPropBuffer& para, const KDWBrc& brc, UINT brctype)
{
	switch(brctype)
	{
	case ILeftBRC:
		para.AddPropFix(sprmPBrcLeft, (UINT32&)brc.get_Brc());
		para.AddPropVar(sprmPBrcLeftEx, (LPVOID)(&brc), sizeof(BRCEX));
		break;
	case IRightBRC:
		para.AddPropFix(sprmPBrcRight, (UINT32&)brc.get_Brc());
		para.AddPropVar(sprmPBrcRightEx, (LPVOID)(&brc), sizeof(BRCEX));
		break;
	case ITopBRC:
		para.AddPropFix(sprmPBrcTop, (UINT32&)brc.get_Brc());
		para.AddPropVar(sprmPBrcTopEx, (LPVOID)(&brc), sizeof(BRCEX));
		break;
	case IBottomBRC:
		para.AddPropFix(sprmPBrcBottom, (UINT32&)brc.get_Brc());
		para.AddPropVar(sprmPBrcBottomEx, (LPVOID)(&brc), sizeof(BRCEX));
		break;		
	}	
}

inline
STDMETHODIMP_(void) InitBrcs(KDWBrc* rgBrc, UINT count = IMaxBRC)
{
	for(int i=0; i<count; ++i)
	{
		rgBrc[i].put_Nil();
	}
}

inline
STDMETHODIMP_(void) AddBrcs(KDWPropBuffer& para, KDWBrc* rgBrc, UINT count = IMaxBRC, BOOL beReset = TRUE)
{
	for(UINT i=0; i<count; ++i)
		AddBrc(para, rgBrc[i], i);
	if(beReset)
		InitBrcs(rgBrc, count);
}

template<class HandleType>
STDMETHODIMP HandlePropvalueList(LPCWSTR szAttrValue, HandleType* handle)
{
	LPWSTR pDup = _wcsdup(szAttrValue);
	LPWSTR pStart = pDup, valuestr;
	size_t ispace;
	HRESULT hr;
	do
	{
		ispace = FindFirstSpace(&pStart);
		valuestr = pStart;
		if(!ispace)
		{
			CutHeadEndSpace(&valuestr);
			hr = handle->HandleValue(valuestr);
			free(pDup);
			return hr;
		}
		pStart+=ispace;
		*pStart++ = '\0';
		CutHeadEndSpace(&valuestr);
		handle->HandleValue(valuestr);
		valuestr = pStart;
	}while(1);	
}
#endif /* __METHOD_H__ */
