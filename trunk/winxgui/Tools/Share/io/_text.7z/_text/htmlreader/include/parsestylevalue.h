/* -------------------------------------------------------------------------
//	�ļ���		��	parsestylevalue.h
//	������		��	���὿
//	����ʱ��	��	2005-4-1 19:02:47
//	��������	��	
//
//	$Id: parsestylevalue.h,v 1.2 2005/04/04 10:49:58 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __PARSESTYLEVALUE_H__
#define __PARSESTYLEVALUE_H__
#include "include/method.h"
#include "include/handlestylevalue.h"
class ParseStyleValue
{
private:	
	htmlpropname_to_id_map propnameMap;	
private:
	STDMETHODIMP HandleProp(LPWSTR pSubStart, HandleStyleValue* handle);
public:
	ParseStyleValue();
	STDMETHODIMP Parse(LPCWSTR szStyleAttr, HandleStyleValue*);
};
#endif /* __PARSESTYLEVALUE_H__ */
