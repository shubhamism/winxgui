/* -------------------------------------------------------------------------
//	�ļ���		��	element_inline.h
//	������		��	���὿
//	����ʱ��	��	2005-4-8 13:10:31
//	��������	��	
//
//	$Id: element_inline.h,v 1.1 2005/04/08 08:46:38 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __ELEMENT_INLINE_H__
#define __ELEMENT_INLINE_H__
#include "factory/inlineelementfactory.h"
// -------------------------------------------------------------------------
//TT, I, B, BIG, SMALL, STRIKE, S, and U
class InlineElementFactory;
class HtmlElement_inline : public HtmlElementBase
{
public:
	HtmlDocument* m_doc;
	STDMETHODIMP Characters(
		IN LPCWSTR chars,
		IN UINT length);
	STDMETHODIMP EnterSubElement(
		IN HtmlElementCtrl subctrl,
		OUT HtmlElement** subhandler);
	STDMETHODIMP EndElement(
		IN HtmlElementCtrl element);	
	STDMETHODIMP_(void) BackupData();
	STDMETHODIMP_(void) RestoreData();
	STDMETHODIMP_(void) NewInlineElementFactory();
	STDMETHODIMP_(void) DeleteInlineElementFactory();	
	STDMETHODIMP AddAttributes(
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);
protected:
	InlineElementFactory* m_factory;
	KDWPropBuffer m_backupPara, m_backupSpan;	
};

class HtmlElement_tt : public HtmlElement_inline
{
public:	
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd)
	{
		return S_OK;
	}
};
class HtmlElement_i : public HtmlElement_inline
{
public:
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);	
};
class HtmlElement_b : public HtmlElement_inline
{	
public:
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);	
};

class HtmlElement_big : public HtmlElement_inline
{
public:
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);	
};
class HtmlElement_small : public HtmlElement_inline
{
public:	
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);	
};
class HtmlElement_strike : public HtmlElement_inline
{
public:
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);	
};

class HtmlElement_s : public HtmlElement_strike
{
public:	
};
class HtmlElement_u : public HtmlElement_inline
{
public:	
	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);	
};
// -------------------------------------------------------------------------
//	$Log: element_inline.h,v $
//	Revision 1.1  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	

#endif /* __ELEMENT_INLINE_H__ */
