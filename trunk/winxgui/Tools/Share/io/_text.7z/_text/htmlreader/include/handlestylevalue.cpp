/* -------------------------------------------------------------------------
//	�ļ���		��	handlestylevalue.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-1 19:20:20
//	��������	��	
//
//	$Id: handlestylevalue.cpp,v 1.7 2005/04/08 09:22:30 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "include/method.h"
#include "handlestylevalue.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
HandleStyleValue::HandleStyleValue()
{
}
STDMETHODIMP HandleStyleValue::HandleValue(htmlprop_t name, LPWSTR value)
{
	HRESULT hr = AddAttribute_span(name, value);
	if(SUCCEEDED(hr))
		return hr;
	hr = AddAttribute_para(name, value);
	if(SUCCEEDED(hr))
		return hr;
	hr = AddAttribute_brc(name, value);
	if(SUCCEEDED(hr))
		return hr;
	hr = AddAttribute_shd(name, value);
	if(SUCCEEDED(hr))
		return hr;
	hr = AddAttribute_location(name, value);
	if(SUCCEEDED(hr))
		return hr;
	return E_UNEXPECTED;
}

STDMETHODIMP HandleStyleValue::AddAttribute_span(htmlprop_t name, LPWSTR value)
{
	if(!span || !m_doc)
	{
		ASSERT(0);
		return E_FAIL;
	}
	switch(name)
	{			
	case html_font_family:
		break;
	case html_font_size:		
		{					
			UINT32 hps = get_font_size(value);
			if(hps != get_font_size_invalid)
				span->AddPropFix(sprmCHps, hps);
		}
		break;
	case html_color:
		span->AddPropFix(sprmCTextColor, get_color(value));		
		break;
	case html_font_style:
		span->AddPropFix(sprmCFItalic, get_font_style(value));		
		break;
	case html_font_weight:
		span->AddPropFix(sprmCFBold, get_font_weight(value));		
		break;
	case html_text_decoration:
		AddAttribute_text_decorations(value);		
		break;
	case html_font_variant:
		span->AddPropFix(sprmCFSmallCaps, get_font_variant(value));		
		break;
	case html_text_transform:
		span->AddPropFix(sprmCFCaps, get_text_transform(value));		
		break;
	case html_visibility:
		span->AddPropFix(sprmCFVanish, get_visibility(value));		
		break;
	case html_letter_spacing:
		{			
			INT32 val = get_value(value, 20);
			if(val != get_value_invalid)
				span->AddPropFix(sprmCDxaSpace, val);				
		}
		break;
	case html_vertical_align:
		if(isdigit(value[0]))
		{
			INT32 val = get_value(value, 2);
			if(val != get_value_invalid)			
				span->AddPropFix(sprmCHpsPos, val);
		}
		else if(!wcsicmp(value, __X("sub")))
			span->AddPropFix(sprmCIss, mso_isssub);
		else if(!wcsicmp(value, __X("super")))
			span->AddPropFix(sprmCIss, mso_isssup);			
		else
			return AddAttribute_para(html_vertical_align, value);
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP HandleStyleValue::AddAttribute_para(htmlprop_t name, LPWSTR value)
{
	if(!para || !m_doc)
	{
		ASSERT(0);
		return E_FAIL;
	}
	switch(name)
	{
	case html_vertical_align:
		if(!wcsicmp(value, __X("baseline")))
			para->AddPropFix(sprmPWAlignFont, mso_faroman);
		else if(!wcsicmp(value, __X("top")))
			para->AddPropFix(sprmPWAlignFont, mso_fahanging);
		else if(!wcsicmp(value, __X("middle")))
			para->AddPropFix(sprmPWAlignFont, mso_facentered);
		else if(!wcsicmp(value, __X("bottom")))
			para->AddPropFix(sprmPWAlignFont, mso_favariable);
		else if(!wcsicmp(value, __X("text-top")))
			return S_OK;
		else if(!wcsicmp(value, __X("text-bottom")))
			return S_OK;
		else
			return S_OK;
		break;
	case html_text_align:
		para->AddPropFix(sprmPJc, get_text_align(value));
		para->AddPropFix(sprmPJcEx, get_text_align(value));
		break;	
	case html_margin_left:
		{			
			INT32 val = get_value(value, 20);
			if(val != get_value_invalid)
			{
				para->AddPropFix(sprmPDxaLeft, val);
				para->AddPropFix(sprmPDxaLeftEx, val);
			}			
		}
		break;
	case html_margin_right:
		{			
			INT32 val = get_value(value, 20);
			if(val != get_value_invalid)
			{
				para->AddPropFix(sprmPDxaRight, val);
				para->AddPropFix(sprmPDxaRightEx, val);				
			}
		}
		break;
	case html_margin_top:
		{		
			INT32 val = get_value(value, 20);
			if(val != get_value_invalid)
			{
				para->AddPropFix(sprmPDyaBefore, val);
			}
		}				
		break;
	case html_margin_bottom:
		{		
			INT32 val = get_value(value, 20);
			if(val != get_value_invalid)
				para->AddPropFix(sprmPDyaAfter, val);
		}				
		break;
	case html_text_indent:
		{		
			INT32 val = get_value(value, 20);
			if(val != get_value_invalid)
			{
				para->AddPropFix(sprmPDxaLeft1, val);
				para->AddPropFix(sprmPDxaLeft1Ex, val);				
			}
		}				
		break;
	case html_line_height:		
		AddAttribute_line_height(para, value);
		break;
	case html_word_spacing:
		//normal | <����>
		break;
	case html_margin:		
		AddAttribute_margin(para, value);
		break;
	case html_list_style_iamge:
		break;
	case html_list_style_type:		
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP HandleStyleValue::AddAttribute_text_decorations(LPWSTR szAttrValue)
{
	handle_text_decoration handle(span);
	HandlePropvalueList<handle_text_decoration>(szAttrValue, &handle);
	return S_OK;	
}

STDMETHODIMP HandleStyleValue::AddAttribute_one_border(KDWBrc& brc, LPWSTR szAttrValue)
{
	handle_one_border handle(brc);
	return HandlePropvalueList<handle_one_border>(szAttrValue, &handle);
}
STDMETHODIMP HandleStyleValue::AddAttribute_brc(htmlprop_t name, LPWSTR value)
{
	if(!para || !m_doc)
		return E_FAIL;
	switch(name)
	{
	case html_border_top://����ֵΪstyle,width,color��д
		switch(elementtype)
		{
		case html_p:
			AddAttribute_one_border(m_doc->rgBrc[ITopBRC], value);
			break;
		case html_inline:
			AddAttribute_one_border(m_doc->chBrc, value);
			break;
		}
		break;
	case html_border_top_style:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[ITopBRC].brcType = get_border_style(value);
			break;
		case html_inline:
			m_doc->chBrc.brcType = get_border_style(value);
			break;
		}
		break;
	case html_border_top_width:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[ITopBRC].dptLineWidth = get_border_width(value,wcslen(value));
			break;
		case html_inline:
			m_doc->chBrc.dptLineWidth = get_border_width(value,wcslen(value));
			break;
		}		
		break;
	case html_border_top_color:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[ITopBRC].crFore = get_color(value);			
			break;
		case html_inline:
			m_doc->chBrc.crFore = get_color(value);
			break;
		}
		break;
	case html_border_left:
		switch(elementtype)
		{
		case html_p:
			AddAttribute_one_border(m_doc->rgBrc[ILeftBRC], value);
			break;
		case html_inline:
			AddAttribute_one_border(m_doc->chBrc, value);			
			break;
		}		
		break;
	case html_border_left_style:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[ILeftBRC].brcType = get_border_style(value);
			break;
		case html_inline:
			m_doc->chBrc.brcType = get_border_style(value);
			break;
		}
		break;
	case html_border_left_width:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[ILeftBRC].dptLineWidth = get_border_width(value,wcslen(value));
			break;
		case html_inline:
			m_doc->chBrc.dptLineWidth = get_border_width(value,wcslen(value));
			break;
		}		
		break;
	case html_border_left_color:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[ILeftBRC].crFore = get_color(value);
			break;
		case html_inline:
			m_doc->chBrc.crFore = get_color(value);			
			break;
		}
		break;
	case html_border_right:
		switch(elementtype)
		{
		case html_p:
			AddAttribute_one_border(m_doc->rgBrc[IRightBRC],value);
			break;
		case html_inline:
			AddAttribute_one_border(m_doc->chBrc,value);
			break;
		}		
		break;
	case html_border_right_style:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[IRightBRC].brcType = get_border_style(value);
			break;
		case html_inline:
			m_doc->chBrc.brcType = get_border_style(value);
			break;
		}
		break;
	case html_border_right_width:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[IRightBRC].dptLineWidth = get_border_width(value,wcslen(value));
			break;
		case html_inline:
			m_doc->chBrc.dptLineWidth = get_border_width(value,wcslen(value));
			break;
		}		
		break;
	case html_border_right_color:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[IRightBRC].crFore = get_color(value);
			break;
		case html_inline:
			m_doc->chBrc.crFore = get_color(value);
			break;
		}				
		break;
	case html_border_bottom:
		switch(elementtype)
		{
		case html_p:
			AddAttribute_one_border(m_doc->rgBrc[IBottomBRC],value);
			break;
		case html_inline:
			AddAttribute_one_border(m_doc->chBrc,value);
			break;
		}						
		break;
	case html_border_bottom_style:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[IBottomBRC].brcType = get_border_style(value);
			break;
		case html_inline:
			m_doc->chBrc.brcType = get_border_style(value);
			break;
		}
		break;
	case html_border_bottom_width:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[IBottomBRC].dptLineWidth = get_border_width(value,wcslen(value));
			break;
		case html_inline:
			m_doc->chBrc.dptLineWidth = get_border_width(value,wcslen(value));
			break;
		}		
		break;
	case html_border_bottom_color:
		switch(elementtype)
		{
		case html_p:
			m_doc->rgBrc[IBottomBRC].crFore = get_color(value);
			break;
		case html_inline:
			m_doc->chBrc.crFore = get_color(value);
			break;
		}				
		break;
	case html_border:				
		switch(elementtype)
		{
		case html_p:
			{
			LPWSTR bottomStr = _wcsdup(value);
			LPWSTR leftStr = _wcsdup(value);
			LPWSTR rightStr = _wcsdup(value);
			AddAttribute_one_border(m_doc->rgBrc[ITopBRC], value);
			AddAttribute_one_border(m_doc->rgBrc[IBottomBRC], bottomStr);
			AddAttribute_one_border(m_doc->rgBrc[ILeftBRC], leftStr);
			AddAttribute_one_border(m_doc->rgBrc[IRightBRC], rightStr);
			free(bottomStr);
			free(leftStr);
			free(rightStr);
			}
			break;
		case html_inline:
			AddAttribute_one_border(m_doc->chBrc, value);			
			break;
		}			
		break;
	case html_border_style:
		switch(elementtype)
		{
		case html_p:
			{
			LPWSTR bottomStr = _wcsdup(value);
			LPWSTR leftStr = _wcsdup(value);
			LPWSTR rightStr = _wcsdup(value);
			m_doc->rgBrc[ITopBRC].brcType = get_border_style(value);
			m_doc->rgBrc[IBottomBRC].brcType = get_border_style(bottomStr);
			m_doc->rgBrc[ILeftBRC].brcType = get_border_style(leftStr);
			m_doc->rgBrc[IRightBRC].brcType = get_border_style(rightStr);
			free(bottomStr);
			free(leftStr);
			free(rightStr);
			}
			break;
		case html_inline:
			m_doc->chBrc.brcType = get_border_style(value);
			break;
		}						
		break;
	case html_border_width:
		switch(elementtype)
		{
		case html_p:
			{
			LPWSTR bottomStr = _wcsdup(value);
			LPWSTR leftStr = _wcsdup(value);
			LPWSTR rightStr = _wcsdup(value);
			size_t len = wcslen(value);
			m_doc->rgBrc[ITopBRC].dptLineWidth = get_border_width(value,len);
			m_doc->rgBrc[IBottomBRC].dptLineWidth = get_border_width(bottomStr,len);
			m_doc->rgBrc[ILeftBRC].dptLineWidth = get_border_width(leftStr,len);
			m_doc->rgBrc[IRightBRC].dptLineWidth = get_border_width(rightStr,len);
			free(bottomStr);
			free(leftStr);
			free(rightStr);
			}
			break;
		case html_inline:
			m_doc->chBrc.dptLineWidth = get_border_width(value,wcslen(value));
			break;
		}
		break;
	case html_border_color:
		switch(elementtype)
		{
		case html_p:
			{
			LPWSTR bottomStr = _wcsdup(value);
			LPWSTR leftStr = _wcsdup(value);
			LPWSTR rightStr = _wcsdup(value);					
			m_doc->rgBrc[ITopBRC].crFore = get_color(value);
			m_doc->rgBrc[IBottomBRC].crFore = get_color(bottomStr);
			m_doc->rgBrc[ILeftBRC].crFore = get_color(leftStr);
			m_doc->rgBrc[IRightBRC].crFore = get_color(rightStr);
			free(bottomStr);
			free(leftStr);
			free(rightStr);
			}
			break;
		case html_inline:
			m_doc->chBrc.crFore = get_color(value);
			break;
		}		
		break;
	case html_padding_top:
		{
			INT32 val = get_value(value, 1);
			if(val != get_value_invalid)
				m_doc->rgBrc[ITopBRC].dptSpace = val;
		}
		break;
	case html_padding_left:
		{
			INT32 val = get_value(value, 1);
			if(val != get_value_invalid)
				m_doc->rgBrc[ILeftBRC].dptSpace = val;
		}				
		break;
	case html_padding_right:
		{
			INT32 val = get_value(value, 1);
			if(val != get_value_invalid)
				m_doc->rgBrc[IRightBRC].dptSpace = val;
		}
		break;
	case html_padding_bottom:
		{
			INT32 val = get_value(value, 1);
			if(val != get_value_invalid)
				m_doc->rgBrc[IBottomBRC].dptSpace = val;
		}
		break;
	default:
		return E_UNEXPECTED;	
	}
	return S_OK;
}

STDMETHODIMP HandleStyleValue::AddAttribute_shd(htmlprop_t name, LPWSTR value)
{	
	switch(name)
	{
	case html_background_color:
		switch(elementtype)
		{
		case html_p:
			m_doc->shd.crBack = get_color(value);
			break;
		case html_inline:
			m_doc->chshd.crBack = get_color(value);
			break;
		}		
		break;
	case html_background_image:
		break;
	case html_background_position_y:		
		break;
	case html_background_position:
		break;
	case html_background_repeat:
		break;
	case html_background:
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP HandleStyleValue::AddAttribute_location(htmlprop_t name, LPWSTR value)
{
	switch(name)
	{
	case html_float:
		break;
	case html_position:
		break;
	case html_left:
		break;
	case html_top:
		break;
	case html_width:
		break;
	case html_height:
		break;
	case html_z_index:
		break;
	case prop_id_max:
		break;
	default:
		return E_UNEXPECTED;
	}
	return S_OK;
}	
// -------------------------------------------------------------------------
//	$Log: handlestylevalue.cpp,v $
//	Revision 1.7  2005/04/08 09:22:30  xushiwei
//	�����˶��ַ����ƺͱ߿�Ĵ���
//	
//	Revision 1.6  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
//	Revision 1.5  2005/04/07 10:02:41  xushiwei
//	�����˵���
//	
//	Revision 1.4  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	
//	Revision 1.3  2005/04/06 02:15:39  xushiwei
//	����htmldoc.cpp
//	
