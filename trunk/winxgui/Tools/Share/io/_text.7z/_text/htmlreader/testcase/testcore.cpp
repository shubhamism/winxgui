/* -------------------------------------------------------------------------
//	�ļ���		��	testcore.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2005-3-2 11:30:32
//	��������	��	
//
//	$Id: testcore.cpp,v 1.12 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestCore : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestCore);
		CPPUNIT_TEST(testBasic);
		//CPPUNIT_TEST(test2Basic);
		//CPPUNIT_TEST(testStyle);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testBasic()
	{
		testHtml2DocFile("core/p.htm", "core_p.doc");
	}
	void test2Basic()
	{
		testHtml2DocFile("core/span.htm", "core_span.doc");
	}
	void testStyle()
	{
		testHtml2DocFile("core/style.htm", "core_style.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestCore);

// -------------------------------------------------------------------------
//	$Log: testcore.cpp,v $
//	Revision 1.12  2005/04/22 07:43:01  zhangqingyuan
//	*** empty log message ***
//	
//	Revision 1.12  2005/04/20 07:13:10  xushiwei
//	��cvs�ָ���
//	
//	Revision 1.9  2005/04/06 08:41:12  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	
//	Revision 1.1  2005/03/02 03:43:33  xushiwei
//	���Ӳ��԰�����
//	
