/* -------------------------------------------------------------------------
//	�ļ���		��	parsestylevalue.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-1 19:04:08
//	��������	��	
//
//	$Id: parsestylevalue.cpp,v 1.4 2005/04/06 02:15:39 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "parsestylevalue.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

STDMETHODIMP ParseStyleValue::HandleProp(LPWSTR pSubStart, HandleStyleValue* handle)
{
	LPWSTR pAttrValue;
	pAttrValue = wcschr(pSubStart,':');
	if(!pAttrValue)
		return E_UNEXPECTED;
	*pAttrValue = '\0';

	CutHeadEndSpace(&pSubStart);
	pSubStart = _wcslwr(pSubStart);

	++pAttrValue;
	CutHeadEndSpace(&pAttrValue);

	if(propnameMap.count(pSubStart))
		handle->HandleValue(propnameMap[pSubStart], pAttrValue);
	else
	{
		ASSERT(0);
		return E_UNEXPECTED;
	}
	return S_OK;
}

ParseStyleValue::ParseStyleValue() : propnameMap(GetHtmlPropnameToIdMap())
{
}	
STDMETHODIMP ParseStyleValue::Parse(LPCWSTR szStyleAttr, HandleStyleValue* handle)
{			
	LPWSTR pDup = _wcsdup(szStyleAttr);
	LPWSTR pSubStart = pDup;
	LPWSTR pSubEnd;
	do
	{
		pSubEnd = wcschr(pSubStart,';');
		if(!pSubEnd)
		{
			CutHeadEndSpace(&pSubStart);
			HandleProp(pSubStart, handle);
			break;
		}
		*pSubEnd = '\0';
		CutHeadEndSpace(&pSubStart);			
		HandleProp(pSubStart, handle);
		pSubStart = pSubEnd+1;
	}while(1);
	free(pDup);
	return S_OK;
}

// -------------------------------------------------------------------------
//	$Log: parsestylevalue.cpp,v $
//	Revision 1.4  2005/04/06 02:15:39  xushiwei
//	����htmldoc.cpp
//	