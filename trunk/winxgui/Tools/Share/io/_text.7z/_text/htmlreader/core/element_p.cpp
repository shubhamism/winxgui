/* -------------------------------------------------------------------------
//	�ļ���		��	element_p.cpp
//	������		��	���὿
//	����ʱ��	��	2005-4-1 18:00:38
//	��������	��	
//
//	$Id: element_p.cpp,v 1.9 2005/04/08 09:22:30 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "element_p.h"
#include "include/parsestylevalue.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

STDMETHODIMP HtmlElement_p::StartElement(
	IN HtmlElementCtrl element,
	IN const HtmlAttribute* attr,
	IN const HtmlAttribute* attrEnd)
{	
	m_backupPara = m_doc->para;
	m_backupSpan = m_doc->span;

	UINT id = m_doc->stylesheet.LookUp(__X("p"));
	if(id != style_not_exist)
	{
		m_doc->para.AddPropFix(sprmPIstd, id);
		m_doc->stylesheet.SetBaseStyleId(id);
	}
	for(;attr!=attrEnd;++attr)
	{
		switch(attr->attr)
		{
		case html_attr_id:
			break;
		case html_attr_class:			
			break;
		case html_attr_lang:
			break;
		case html_attr_title:
			break;
		case html_attr_style:
			{
				ParseStyleValue psv;
				HandleStyleValue handle;
				handle.elementtype = element;
				handle.para = &m_doc->para;
				handle.span = &m_doc->span;
				handle.m_doc = m_doc;
				psv.Parse(attr->value, &handle);
				m_doc->PutRgBRC(html_p);
				m_doc->PutSHD(html_p);
			}
			break;
		case html_attr_align:
			m_doc->para.AddPropFix(sprmPJc, GetJc(attr->value));
			m_doc->para.AddPropFix(sprmPJcEx, GetJc(attr->value));			
			break;
		}
	}
	m_doc->NewParagraph();
	return S_OK;
}
STDMETHODIMP HtmlElement_p::EndElement(
IN HtmlElementCtrl element)
{
	m_doc->EndParagraph();
	m_doc->span = m_backupSpan;
	m_doc->para = m_backupPara;
	return S_OK;
}

STDMETHODIMP HtmlElement_p::Characters(
	IN LPCWSTR chars,
	IN UINT length)
{
	m_doc->AddContent(chars,length);
	return S_OK;
}

STDMETHODIMP HtmlElement_p::EnterSubElement(
	IN HtmlElementCtrl subctrl,
	OUT HtmlElement** subhandler)
{
	m_factory.m_doc = m_doc;
	*subhandler = (HtmlElement*)m_factory.GetElement(subctrl);	
	return S_OK;
}
// -------------------------------------------------------------------------
//	$Log: element_p.cpp,v $
//	Revision 1.9  2005/04/08 09:22:30  xushiwei
//	�����˶��ַ����ƺͱ߿�Ĵ���
//	
//	Revision 1.8  2005/04/08 08:46:38  xushiwei
//	�����˶�Font style elements�Ĵ���
//	
//	Revision 1.7  2005/04/07 10:02:41  xushiwei
//	�����˵���
//	
//	Revision 1.6  2005/04/06 08:41:11  xushiwei
//	������border: 3px solid #000������ֵ��˳����������bug
//	