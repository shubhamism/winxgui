/* -------------------------------------------------------------------------
//	�ļ���		��	element_p.h
//	������		��	��ʽΰ
//	����ʱ��	��	2005-3-2 11:43:15
//	��������	��	
//
//	$Id: element_p.h,v 1.11 2005/04/08 08:46:38 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __ELEMENT_P_H__
#define __ELEMENT_P_H__

#include "factory/inlineelementfactory.h"

// -------------------------------------------------------------------------
class HtmlElement_p : public HtmlElementBase
{
	InlineElementFactory m_factory;
	HtmlElement_inline m_inline;
	KDWPropBuffer m_backupPara, m_backupSpan;
public:
	HtmlDocument* m_doc;

	STDMETHODIMP StartElement(
		IN HtmlElementCtrl element,
		IN const HtmlAttribute* attr,
		IN const HtmlAttribute* attrEnd);
	
	STDMETHODIMP EndElement(
	IN HtmlElementCtrl element);	

	STDMETHODIMP Characters(
		IN LPCWSTR chars,
		IN UINT length);	

	STDMETHODIMP EnterSubElement(
		IN HtmlElementCtrl subctrl,
		OUT HtmlElement** subhandler);
};
#endif /* __ELEMENT_P_H__ */
