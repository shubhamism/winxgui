/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-10-26 18:39:03
//	��������	��	
//
//	$Id: testcommon.h,v 1.7 2005/04/22 07:43:01 zhangqingyuan Exp $
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#include <cppunit/cppunit.h>

// -------------------------------------------------------------------------
#if defined(X_RELEASE_CASE) || defined(_DEBUG)
#define TEST_LOG	printf
#else

inline
STDMETHODIMP_(void) _CppUnit_Log(
								 LPCSTR fmt,
								 ...)
{
	va_list arglist;
	va_start(arglist, fmt);
	vprintf(fmt, arglist);
	vfprintf(stderr, fmt, arglist);
	va_end(arglist);
}

#define TEST_LOG	_CppUnit_Log
#endif

// -------------------------------------------------------------------------
// htmlConvert

STDAPI htmlConvert(
				  IN LPCWSTR htmlFile,
				  IN LPCWSTR docFile);

// -------------------------------------------------------------------------

inline
STDMETHODIMP_(DWORD) testConvert(LPCWSTR htmlFile, LPCWSTR docFile)
{
	static LPCSTR lc = setlocale(LC_ALL, "");
	WCHAR szSrcFile[_MAX_PATH];
	WCHAR szDestFile[_MAX_PATH];
	DWORD tickCount;
	{
		DWORD tickStart = GetTickCount();
		HRESULT hr = htmlConvert(
			GetSystemIniPath(szSrcFile, htmlFile),
			GetSystemIniPath(szDestFile, docFile));
		tickCount = GetTickCount() - tickStart;
		ASSERT_OK(hr);
	}

	LPCWSTR szToken = wcsstr(htmlFile, __X("htmlrw"));
	if (szToken)
		htmlFile = szToken+7;
	printf("  TickCount = %-4d\t%S\n", tickCount, htmlFile);
	return tickCount;
}

// -------------------------------------------------------------------------

#define testHtmlPath(from)													\
		L"../../win32d/testcase/htmlrw/" L ## from

#define testHtml2DocFile(from, to)											\
	testConvert(															\
		L"../../win32d/testcase/htmlrw/" L ## from,							\
		L"../../win32d/testcase/output/" L ## to )

// -------------------------------------------------------------------------
// $Log: testcommon.h,v $
// Revision 1.7  2005/04/22 07:43:01  zhangqingyuan
// *** empty log message ***
//
// Revision 1.7  2005/04/20 07:45:36  xushiwei
// ��cvs�ָ���
//
// Revision 1.4  2005/04/06 08:41:12  xushiwei
// ������border: 3px solid #000������ֵ��˳����������bug
//
// Revision 1.1  2005/02/05 04:02:00  xushiwei
// �½����԰�����
//

#endif /* __TESTCOMMON_H__ */
