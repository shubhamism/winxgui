// rtfseprator.cpp : Defines the entry point for the console application.
// $Id: htmlseprator.cpp,v 1.30 2005/04/01 10:01:05 xushiwei Exp $
//

#pragma warning(disable:4786)
#include "kfc.h"

#include <kso/io/html/parser.h>
__USING_KSO_HTML;

#undef __NAMETOID_TBL_H__
#include <kso/io/html/parser/nametoid_tbl.h>

#include <fstream>
#include <algorithm>

struct ARGUMENT
{
	htmlctlname_to_id_map* newelemMap;
	htmlctlname_to_id_map* newattrMap;
	INT* elem_id;
	INT* attr_id;
};
class htmlsepratorHandler : public HtmlHandlerBase
{
public:
	htmlsepratorHandler(ARGUMENT* argA) : _arg(argA)
	{			
	}		
	STDMETHODIMP StartElement(
		IN htmlelement element)
	{
		if(strstr(element,":"))
			return E_FAIL;		
		char plwr[MAX_CTRLLEN];
		INT len = strlen(element);
		std::transform(&element[0],&element[len],&plwr[0],tolower);
		plwr[len]='\0';
		if(!_arg->newelemMap->count(plwr))
		{			
			_arg->newelemMap->insert(htmlctlname_to_id_map::value_type(plwr,(*(_arg->elem_id))++));
		}
		return S_OK;
	}

	STDMETHODIMP AddAttribute(
		IN htmlattribute attr,
		IN htmlvalue value)
	{
		if(strstr(attr,":"))
			return E_FAIL;		
		char plwr[MAX_CTRLLEN];
		INT len = strlen(attr);
		std::transform(&attr[0],&attr[len],&plwr[0],tolower);
		plwr[len]='\0';
		if(!_arg->newattrMap->count(plwr))
		{
			_arg->newattrMap->insert(htmlctlname_to_id_map::value_type(plwr,(*(_arg->attr_id))++));
		}		
		return S_OK;
	}	
private:
	ARGUMENT* _arg;
};
// -------------------------------------------------------------------------

void WriteToFile(const htmlctlname_to_id_map& amap, LPCSTR cppFile, LPCSTR hppFile,LPCSTR preFix,INT oldCount=0)
{			
	htmlctlname_to_id_map::const_iterator it;
	std::ofstream os_cpp(cppFile);
	std::ofstream os_h(hppFile);
	std::map<int,std::string> intstrmap;
	std::map<int,std::string>::const_iterator iter;
	for(it=amap.begin();it!=amap.end();++it)
	{
		intstrmap.insert(std::map<int,std::string>::value_type((*it).second,(*it).first));
	}	
	iter=intstrmap.begin();
	std::advance(iter,oldCount);
	for(;iter!=intstrmap.end();++iter)
	{				
		std::for_each((*iter).second.begin(),(*iter).second.end(),tolower);
		
		os_cpp<<"\t{ \""<<(*iter).second.c_str()<<"\""<<", "<<preFix<<(*iter).second.c_str()<<" },\n";
		os_h<<"\t"<<preFix<<(*iter).second.c_str()<<" = "<<(*iter).first<<",\n";
	}	
}	
STDMETHODIMP SingleSep(
					 IN LPCWSTR szFile,
					 IN SD_FILEINFO_ARG fiArg,
					 IN LPVOID pParam
					 )
{	
	ARGUMENT* arg = (ARGUMENT*)(pParam);	
	printf("Parsing-->%S\n",szFile);	
	WCHAR* ext = wcsrchr(szFile,'.');
	HRESULT hr;
	if(!wcscmp(ext,__X(".html"))||!wcscmp(ext,__X(".htm")))
	{
		HtmlParser<htmlsepratorHandler> parser(szFile);
		htmlsepratorHandler handler(arg);
		hr = parser.Parse(&handler);
	}	
	return hr;
}

STDMETHODIMP BatchSep(LPCWSTR szDirpath,ARGUMENT* arg)
{
	_XScanDirectory(szDirpath,SingleSep,SD_SCAN_SUBDIR,(void*)arg);
	return S_OK;
}
int main()
{	
	ARGUMENT arg;
	htmlctlname_to_id_map attrMap,elemMap;	
	int i;
	for(i=0; i<countof(_g_elem_to_id_table); ++i)
	{
		elemMap.insert(htmlctlname_to_id_map::value_type(_g_elem_to_id_table[i].name,_g_elem_to_id_table[i].id));
	}		
	for(i=0; i<countof(_g_attr_to_id_table); ++i)
	{
		attrMap.insert(htmlctlname_to_id_map::value_type(_g_attr_to_id_table[i].name,_g_attr_to_id_table[i].id));
	}
	INT init_elem_id = countof(_g_elem_to_id_table),init_attr_id = countof(_g_attr_to_id_table);
	arg.newattrMap = &attrMap;
	arg.newelemMap = &elemMap;
	arg.elem_id = &init_elem_id;
	arg.attr_id = &init_attr_id;
	BatchSep(__X("C:\\Downloads\\html40"),&arg);
	WriteToFile(elemMap,"c:\\html_elemtoid.cpp","c:\\html_elemtoid.h","html_",countof(_g_elem_to_id_table));
	WriteToFile(attrMap,"c:\\html_attrtoid.cpp","c:\\html_attrtoid.h","html_attr_",countof(_g_attr_to_id_table));
	return 0;
}

// -------------------------------------------------------------------------
//	$Log: htmlseprator.cpp,v $
//	Revision 1.30  2005/04/01 10:01:05  xushiwei
//	*** empty log message ***
//	
//	Revision 1.28  2005/03/03 01:39:06  xushiwei
//	*** empty log message ***
//	
//	Revision 1.27  2005/03/02 09:05:30  xushiwei
//	*** empty log message ***
//	
//	Revision 1.26  2005/03/02 08:55:10  xushiwei
//	OK
//	