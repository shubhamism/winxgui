/* -------------------------------------------------------------------------
//	�ļ���		��	docPack.h
//	������		��	����
//	����ʱ��	��	2006-9-12 14:43:30
//	��������	��	
//
//	$Id: wmlPackage.h,v 1.3 2006/10/27 05:56:33 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOCPACK_H__
#define __DOCPACK_H__

#ifndef __MSO_IO_PACKAGING_PACKAGING_H__
#include <mso/io/packaging/packaging.h>
#endif


// -------------------------------------------------------------------------
namespace mso { namespace xml12 { namespace wordml
{
	using namespace mso;
	using namespace mso::IO::Packaging;

	
	class WmlPackage;
	class WmlPart : public mso::MsoObject
	{
		MSO_HEAP_DISPOSE
	public:
		STDPROC_(const PackagePart*) GetPart() PURE;
		STDPROC_(const Package*) GetPackage() PURE;
	};


	class WmlFontTable : public WmlPart
	{
		MSO_HEAP_DISPOSE
	public:
		WmlFontTable(const PackagePart* part, const Package* package)
		{
			m_mainPart = part;
			m_mainPack = package;
		}
		STDMETHODIMP_(const PackagePart*) GetPart()
		{
			return m_mainPart;
		}
		STDMETHODIMP_(const Package*) GetPackage()
		{
			return m_mainPack;
		}

	private:
		const PackagePart* m_mainPart;
		const Package* m_mainPack;
	};

	class WmlStyles : public WmlPart
	{
		MSO_HEAP_DISPOSE
	public:
		WmlStyles(const PackagePart* part, const Package* package)
		{
			m_mainPart = part;
			m_mainPack = package;
		}
		STDMETHODIMP_(const PackagePart*) GetPart()
		{
			return m_mainPart;
		}
		STDMETHODIMP_(const Package*) GetPackage()
		{
			return m_mainPack;
		}

	private:
	 	const PackagePart* m_mainPart;
		const Package* m_mainPack;
	};

	class WmlDocument : public WmlPart
	{
		MSO_HEAP_DISPOSE
	public:
		STDMETHODIMP_(WmlFontTable*) GetFontTable()
		{
			const PackagePart* part = m_mainPack->GetPart(L"/word/fontTable.xml");
			if (part)
			{
				m_fontTablePart = new WmlFontTable(part, m_mainPack);
				return m_fontTablePart.get();
			}
			return NULL;
		}

		STDMETHODIMP_(WmlStyles*) GetStyles()
		{
			const PackagePart* part = m_mainPack->GetPart(L"/word/styles.xml");
			if (part)
			{
				m_stylesPart = new WmlStyles(part, m_mainPack);
				return m_stylesPart.get();
			}
			return NULL;
		}
		
	public:
		STDMETHODIMP_(const PackagePart*) GetPart()
		{
			return m_mainPart;
		}
		STDMETHODIMP_(const Package*) GetPackage()
		{
			return m_mainPack;
		}

	private:
		friend class WmlPackage;
		WmlDocument(
			IN const PackagePart* part, IN const Package* package)
		{
			m_mainPart = part;
			m_mainPack = package;
		}

	private:
		const PackagePart* m_mainPart;
		const Package* m_mainPack;

		MsoOwnershipPtr<WmlFontTable> m_fontTablePart;
		MsoOwnershipPtr<WmlStyles> m_stylesPart;
	};

	

	class WmlPackage :	public MsoObject
	{
		MSO_HEAP_DISPOSE
	public:
		static
		STDMETHODIMP_(MsoOwnershipPtr<WmlPackage>) Open(
			IN LPCWSTR fileName, IN UINT grfMode
			)
		{
			return new WmlPackage(fileName, grfMode);
		}
		
	public:
		STDMETHODIMP_(BOOL) Good()
		{
			// return m_mainPack.Good();
			return TRUE;
		}
		
		STDMETHODIMP_(void) Close()
		{
			m_mainPack->Close();
		}

	protected:
		WmlPackage(LPCWSTR fileName, IN UINT grfMode)
		{
			m_mainPack = Package::Open(fileName, grfMode);
		}

	public:
		 STDMETHODIMP_(WmlDocument*) GetDocument()
		 {
			 //
			 // @@note:
			 //	 Ӧ���Ǵ�package��rels��ʼ��������ʱ��ʵ�֡�
			 //
			 const PackagePart* part = m_mainPack->GetPart(L"/word/document.xml");
			 m_docPart = new WmlDocument(part, m_mainPack.get());

			 return m_docPart.get();
		 }

	private:
		MsoOwnershipPtr<Package> m_mainPack;
		MsoOwnershipPtr<WmlDocument> m_docPart;
	};


	
}}} // mso::xml12::word


// -------------------------------------------------------------------------
//	$Log: wmlPackage.h,v $
//	Revision 1.3  2006/10/27 05:56:33  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.2  2006/10/19 07:44:22  chenghui
//	���ִ������
//	
//	Revision 1.1  2006/09/20 09:42:36  wangdong
//	*** empty log message ***
//	
//	Revision 1.1  2006/09/19 08:22:46  wangdong
//	*** empty log message ***
//	

#endif /* __DOCPACK_H__ */ 
