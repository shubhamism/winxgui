/* -------------------------------------------------------------------------
//	�ļ���		��	wmlsectPrAttrTrans.h
//	������		��	chenghui
//	����ʱ��	��	2006-10-12 14:57:19
//	��������	��	
//
//	$Id: wmlsectPrAttrTrans.h,v 1.2 2006/10/19 07:44:22 chenghui Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLSECTPRATTRTRANS_H__
#define __WMLSECTPRATTRTRANS_H__

#ifndef __DWTARGET_H__
#include "dwDocTarget.h"
#endif

// -------------------------------------------------------------------------

using namespace mso::xml12;
// -------------------------------------------------------------------------

XmlEnumPair txSectbdpDisplay[] = 
{
	xE("allPages",		mso_pgbAllDoc)
	xE("firstPage",		mso_pgbFirst)
	xE("notFirstPage",	mso_pgbExpFirst)
};

static
STDMETHODIMP_(void) WmlAddPageBordersAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		static
		XmlEnumMap _mapDisplay(txSectbdpDisplay, countof(txSectbdpDisplay), mso_pgbAllDoc);

		SpgbProp Spgb = {0};
		XmlRoAttr* pRoAttr = 0;
		if (pRoAttr = attr->GetByName(w::zOrder)) 
		{
			if (__L("front") == pRoAttr->Str())
				Spgb.pageDepth = mso_pgbFront;
			else	//back
				Spgb.pageDepth = mso_pgbback;
		}

		if (pRoAttr = attr->GetByName(w::display)) 
			Spgb.applyTo = _mapDisplay.Find(pRoAttr->Str());

		if (pRoAttr = attr->GetByName(w::offsetFrom)) 
		{
			if (__L("text") == pRoAttr->Str())
				Spgb.offsetFrom = mso_pgbFromText;
			else	//page
				Spgb.offsetFrom = mso_pgbFromEdge;
		}

		buffer->AddPropFix(sprmSPgbProp, *(INT16*)&Spgb);
	}
}

static
STDMETHODIMP_(void) WmlAddColumnsAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
#pragma pack(1)
	struct __KDWCol
	{
		UINT8 icol;
		INT16 value;
	};
#pragma pack()
	
	if (attr->Count() > 0)
	{
		XmlRoAttr* pRoAttr = 0;
		UINT nCols = 0;
		if (pRoAttr = attr->GetByName(w::num))
		{
			nCols = pRoAttr->Decimal();
			if (nCols <= 1)
				return;
			
			buffer->AddPropFix(sprmSCcolumns, --nCols);
		}

		if (pRoAttr = attr->GetByName(w::sep))
			buffer->AddPropFix(sprmSLBetween, pRoAttr->OnOff());

		BOOL EqualW = TRUE;
		if (pRoAttr = attr->GetByName(w::equalWidth))
		{
			EqualW = pRoAttr->OnOff();
			buffer->AddPropFix(sprmSFEvenlySpaced, EqualW);
		}

		if (pRoAttr = attr->GetByName(w::space))
			buffer->AddPropFix(sprmSDxaColumns, pRoAttr->UTwips());

		if (!EqualW && nCols > 1)
		{
			UINT iCol = 0; 
			for (INT i = 0; i < attr->Count(); i++)
			{
				XmlName Id;
				XmlRoAttr* pAttrCol = attr->GetAt(i, &Id);
				if (w::col == Id)
				{
					XmlRoAttr* pAttr = pAttrCol->GetByName(w::w);
					if (pAttr)
					{
						__KDWCol Width;
						Width.icol = iCol;
						Width.value = pAttr->UTwips();
						buffer->AddPropFix(sprmSDxaColWidth, *(INT32*)&Width);
					}

					pAttr = pAttrCol->GetByName(w::space);
					if (pAttr && iCol < nCols)
					{
						__KDWCol Spacing;
						Spacing.icol = iCol;
						Spacing.value = pAttr->UTwips();
						buffer->AddPropFix(sprmSDxaColSpacing, *(INT32*)&Spacing);
					}

					++iCol;
				}
			}
		}
	}
}
// -------------------------------------------------------------------------
//	$Log: wmlsectPrAttrTrans.h,v $
//	Revision 1.2  2006/10/19 07:44:22  chenghui
//	���ִ������
//	
//	Revision 1.1  2006/10/13 02:30:23  chenghui
//	*** empty log message ***
//	

#endif /* __WMLSECTPRATTRTRANS_H__ */
