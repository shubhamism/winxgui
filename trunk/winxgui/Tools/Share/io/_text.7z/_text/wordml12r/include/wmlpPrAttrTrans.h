/* -------------------------------------------------------------------------
//	�ļ���		��	wmlpPrAttrTrans.h
//	������		��	chenghui
//	����ʱ��	��	2006-10-9 15:14:51
//	��������	��	
//
//	$Id: wmlpPrAttrTrans.h,v 1.6 2006/10/20 07:51:22 chenghui Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLPPRATTRTRANS_H__
#define __WMLPPRATTRTRANS_H__

#ifndef __DWTARGET_H__
#include "dwDocTarget.h"
#endif
// -------------------------------------------------------------------------
using namespace mso::xml12;

// -------------------------------------------------------------------------


XmlEnumPair txRuleMap[] = 
{
	xE("auto",		mso_ruleAuto)
	xE("exact",		mso_ruleExact)
	xE("atLeast",	mso_ruleAtLeast)
};

static
STDMETHODIMP_(void) WmlAddSpacingAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	static
	XmlEnumMap _mapLine(txRuleMap, countof(txRuleMap), mso_ruleAuto);

	if (attr->Count() > 0)
	{
		LSPD Lspd;
		short nLineSpace = 0;
		MSORULE nLineRule;
		
		XmlRoAttr* pRoAttr = attr->GetByName(w::before);
		if (pRoAttr)
			buffer->AddPropFix(sprmPDyaBefore, pRoAttr->UTwips());
		
		if (pRoAttr = attr->GetByName(w::beforeLines))
			buffer->AddPropFix(sprmPDyaBeforeRel, pRoAttr->Decimal());
		
		if (pRoAttr = attr->GetByName(w::beforeAutospacing))
			buffer->AddPropFix(sprmPFDyaBeforeAuto, TRUE);
		
		if (pRoAttr = attr->GetByName(w::after))
			buffer->AddPropFix(sprmPDyaAfter, pRoAttr->UTwips());
		
		if (pRoAttr = attr->GetByName(w::afterLines))
			buffer->AddPropFix(sprmPDyaAfterRel, pRoAttr->Decimal());
		
		if (pRoAttr = attr->GetByName(w::afterAutospacing))
			buffer->AddPropFix(sprmPFDyaAfterAuto, TRUE);
		
		if (pRoAttr = attr->GetByName(w::line))
			nLineSpace = pRoAttr->Twips();
		
		if (pRoAttr = attr->GetByName(w::lineRule))
			nLineRule = (MSORULE)_mapLine.Find(pRoAttr->Str());

		if (nLineSpace > 0)
		{
			switch(nLineRule) 
			{
			case mso_ruleAuto:
				{
					Lspd.dyaLine = nLineSpace;
					Lspd.fMultLinespace = TRUE;
				}
				break;
			case mso_ruleExact:
				{
					Lspd.dyaLine = -1 * nLineSpace;
					Lspd.fMultLinespace = FALSE;
				}
				break;
			case mso_ruleAtLeast:
				{
					Lspd.dyaLine = nLineSpace;
					Lspd.fMultLinespace = FALSE;
				}
				break;
			}

			buffer->AddPropFix(sprmPDyaLine, *(UINT32*)&Lspd);
		}
	}
}

static
STDMETHODIMP_(void) WmlAddIndentAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		XmlRoAttr* pRoAttr = attr->GetByName(w::left);
		if (pRoAttr) 
		{
			buffer->AddPropFix(sprmPDxaLeft, pRoAttr->Twips());
			buffer->AddPropFix(sprmPDxaLeftEx, pRoAttr->Twips());
		}
		
		if (pRoAttr = attr->GetByName(w::leftChars))
			buffer->AddPropFix(sprmPDxaLeftRel, pRoAttr->Decimal());
		
		if (pRoAttr = attr->GetByName(w::right))
		{
			buffer->AddPropFix(sprmPDxaRight, pRoAttr->Twips());
			buffer->AddPropFix(sprmPDxaRightEx, pRoAttr->Twips());
		}
		
		if (pRoAttr = attr->GetByName(w::rightChars))
			buffer->AddPropFix(sprmPDxaRightRel, pRoAttr->Decimal());
		
		if (pRoAttr = attr->GetByName(w::hanging))
		{
			buffer->AddPropFix(sprmPDxaLeft1, -1 * pRoAttr->Twips());
			buffer->AddPropFix(sprmPDxaLeft1Ex, -1 * pRoAttr->Twips());
		}
		
		if (pRoAttr = attr->GetByName(w::hangingChars))
			buffer->AddPropFix(sprmPDxaLeft1Rel, -1 * pRoAttr->Decimal());
		
		if (pRoAttr = attr->GetByName(w::firstLine))
		{
			buffer->AddPropFix(sprmPDxaLeft1, pRoAttr->Twips());
			buffer->AddPropFix(sprmPDxaLeft1Ex, pRoAttr->Twips());
		}
		
		if (pRoAttr = attr->GetByName(w::firstLineChars))
			buffer->AddPropFix(sprmPDxaLeft1Rel, pRoAttr->Decimal());
		
	}
}

static
STDMETHODIMP_(void) WmlAddFrameAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		XmlRoAttr* pRoAttr = 0;
		//�����³�
		{
			static
			XmlEnumPair txDropCapMap[] = 
			{
				xE("none",		mso_dctNone)
				xE("drop",		mso_dctNormal)
				xE("margin",	mso_dctInMargin)
			};

			static
			XmlEnumMap _mapDC(txDropCapMap, countof(txDropCapMap), mso_dctNone);
			
			DCS dcs = {0};
			if (pRoAttr = attr->GetByName(w::dropCap))
				dcs.fdct = _mapDC.Find(pRoAttr->Str());
			
			if (pRoAttr = attr->GetByName(w::lines))
				dcs.lines = pRoAttr->Decimal();
			
			if (dcs.fdct != mso_dctNone)
			{
				buffer->AddPropFix(sprmPDcs, *(INT16*)&dcs);
			}
		}

		//FrameHeight
		{
			static
			XmlEnumMap _mapFHeight(txRuleMap, countof(txRuleMap), mso_ruleAuto);
			
			SprmPWHeightAbsOprand FHeight = {0};
			
			if (pRoAttr = attr->GetByName(w::h))
				FHeight.dyaHeight = pRoAttr->UTwips();
			
			if (pRoAttr = attr->GetByName(w::hRule))
			{
				MSORULE rule = (MSORULE)_mapFHeight.Find(pRoAttr->Str());
				switch(rule)
				{
				case mso_ruleExact:
					FHeight.fMinHeight = 0;
					break;
				case mso_ruleAtLeast:
					FHeight.fMinHeight = 1;
					break;
				default:
					ASSERT(0);
					break;
				}
			}
			
			if (FHeight.dyaHeight > 0) 
			{
				buffer->AddPropFix(sprmPWHeightAbs, *(INT16*)&FHeight);
			}
		}

			
		{
			static
			XmlEnumPair txFrameWrapMap[] =
			{
				xE("auto",		mso_FrWrapAround)
				xE("notBeside",	mso_FrWrapAround)
				xE("around",	mso_FrWrapAround)
				xE("tight",		mso_FrWrapAround)
				xE("through",	mso_FrWrapAround)
				xE("none",		mso_FrWrapNone)
			};
			
			static
			XmlEnumMap _mapWrap(txFrameWrapMap, countof(txFrameWrapMap), mso_FrWrapNone);
			
			if (pRoAttr = attr->GetByName(w::warp))
				buffer->AddPropFix(sprmPWr, _mapWrap.Find(pRoAttr->Str()));
		}

		{
			static
			XmlEnumPair txPCHorzMap[] = 
			{
				xE("text",		mso_pcHorzText)
				xE("margin",	mso_pcHorzMargin)
				xE("page",		mso_pcHorzPage)
			};

			static
			XmlEnumPair txPCVertMap[] = 
			{
				xE("text",		mso_pcVertText)
				xE("margin",	mso_pcVertMargin)
				xE("page",		mso_pcVertPage)
			};

			static
			XmlEnumMap _mapPCH(txPCHorzMap, countof(txPCHorzMap), mso_pcHorzText);
			static
			XmlEnumMap _mapPCV(txPCVertMap, countof(txPCVertMap), mso_pcVertText);

			SprmPPcOprand Pc = {0};
			if (pRoAttr = attr->GetByName(w::hAnchor))
				Pc.pcHorz = _mapPCH.Find(pRoAttr->Str());

			if (pRoAttr = attr->GetByName(w::vAnchor))
				Pc.pcVert = _mapPCV.Find(pRoAttr->Str());
				
			buffer->AddPropFix(sprmPPc, *(INT8*)&Pc);
		}

		{
			static
			XmlEnumPair txXAlignMap[] = 
			{
				xE("left",		mso_posXSpecLeft)
				xE("center",	mso_posXSpecCenter)
				xE("right",		mso_posXSpecRight)
				xE("inside",	mso_posXSpecInside)
				xE("outside",	mso_posXSpecOutside)
			};

			static
			XmlEnumMap _mapxAlign(txXAlignMap, countof(txXAlignMap), mso_posXSpecLeft);

			if (pRoAttr = attr->GetByName(w::xAlign))
				buffer->AddPropFix(sprmPDxaAbs, _mapxAlign.Find(pRoAttr->Str()));
		}		

		{
			static
			XmlEnumPair txYAlignMap[] = 
			{
				xE("inline",	mso_posYSpecAuto)
				xE("top",		mso_posYSpecTop)
				xE("center",	mso_posYSpecCenter)
				xE("bottom",	mso_posYSpecBottom)
				xE("inside",	mso_posYSpecInside)
				xE("outside",	mso_posYSpecOutside)
			};
			
			static
			XmlEnumMap _mapyAlign(txYAlignMap, countof(txYAlignMap), mso_posYSpecAuto);

			if (pRoAttr = attr->GetByName(w::yAlign))
				buffer->AddPropFix(sprmPDyaAbs, _mapyAlign.Find(pRoAttr->Str()));
		}

		if (pRoAttr = attr->GetByName(w::w))
			buffer->AddPropFix(sprmPDxaWidth, pRoAttr->UTwips());
		if (pRoAttr = attr->GetByName(w::vSpace))
			buffer->AddPropFix(sprmPDyaFromText, pRoAttr->UTwips());			
		if (pRoAttr = attr->GetByName(w::hSpace))
			buffer->AddPropFix(sprmPDxaFromText, pRoAttr->UTwips());
		if (pRoAttr = attr->GetByName(w::x))
			buffer->AddPropFix(sprmPDxaAbs, pRoAttr->Twips());
		if (pRoAttr = attr->GetByName(w::y))
			buffer->AddPropFix(sprmPDyaAbs, pRoAttr->Twips());
		if (pRoAttr = attr->GetByName(w::anchorLock))
			buffer->AddPropFix(sprmPFLocked, pRoAttr->OnOff());
	}
}

enum { mso_tbdClearTab = -1 };

static
XmlEnumPair txTabJC[] = 
{
	xE("clear",			mso_tbdClearTab)
	xE("left",			mso_tbdLeftTab)
	xE("center",		mso_tbdCenteredTab)
	xE("right",			mso_tbdRightTab)
	xE("decimal",		mso_tbdDecimalTab)
	xE("bar",			mso_tbdBar)
	xE("list",			mso_tbdListTab)
};

static
XmlEnumPair txTabTLC[] =
{
	xE("none",			mso_tbdNoLeader)
	xE("dot",			mso_tbdDottedLeader)
	xE("hyphen",		mso_tbdHyphenatedLeader)
	xE("underscore",	mso_tbdSingleLineLeader)
	xE("heavy",			mso_tbdHeavyLineLeader)
	xE("middleDot",		mso_tbdDottedLeader)
};

static
STDMETHODIMP_(void) WmlAddTabsAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		static
		XmlEnumMap _mapjc(txTabJC, countof(txTabJC), mso_tbdLeftTab);

		static
		XmlEnumMap _maptlc(txTabTLC, countof(txTabTLC), mso_tbdNoLeader);

		KDWTab dwTab;
		for (INT i = 0; i < attr->Count(); i++)
		{
			XmlName Id;
			XmlRoAttr* pAttrTab = attr->GetAt(i, &Id);
			ASSERT(pAttrTab);

			if (w::tab == Id) 
			{
				XmlRoAttr* pAttr = 0;
				if (pAttr = pAttrTab->GetByName(w::val))
				{
					INT tabjc = _mapjc.Find(pAttr->Str());
					if (mso_tbdClearTab != tabjc)
						dwTab.put_TabJC((TBD_JC)tabjc);
					else
						continue;
				}

				if (pAttr = pAttrTab->GetByName(w::leader)) 
					dwTab.put_TabTLC((TBD_TLC)_maptlc.Find(pAttr->Str()));

				if (pAttr = pAttrTab->GetByName(w::pos))
					dwTab.put_TabPos(pAttr->Twips());
			}
		}

		if (dwTab.itbdMac > 0)
			buffer->AddTabStops(dwTab.itbdDelMax, dwTab.rgdxaDel, dwTab.itbdMac, 
								dwTab.rgdxaTab, dwTab.rgtbd);
	}
}

static
STDMETHODIMP_(void) WmlAddpStyleAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		KDWStyleMap styleMap = docTarget->GetStyleMap();
		
		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr)
		{
			KDWFontMap::const_iterator i = styleMap.find(pRoAttr->Str());
			buffer->SetPapxIstd(i->second);
		}
	}
}
// -------------------------------------------------------------------------
//	$Log: wmlpPrAttrTrans.h,v $
//	Revision 1.6  2006/10/20 07:51:22  chenghui
//	��ʽ
//	
//	Revision 1.5  2006/10/16 02:28:59  chenghui
//	*** empty log message ***
//	
//	Revision 1.4  2006/10/13 03:19:33  chenghui
//	�Ʊ�λ�޸�
//	
//	Revision 1.3  2006/10/13 03:09:17  chenghui
//	*** empty log message ***
//	
//	Revision 1.2  2006/10/13 02:30:05  chenghui
//	*** empty log message ***
//	
//	Revision 1.1  2006/10/11 07:09:20  chenghui
//	*** empty log message ***
//	

#endif /* __WMLPPRATTRTRANS_H__ */
