/* -------------------------------------------------------------------------
//	�ļ���		��	stdafx.h
//	������		��	����
//	����ʱ��	��	2006-8-29 10:38:29
//	��������	��	
//
//	$Id: stdafx.h,v 1.5 2006/10/25 02:33:50 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __STDAFX_H__
#define __STDAFX_H__

// -------------------------------------------------------------------------
#define X_RELEASE_CASE
#define X_RELEASE_QUALITY_TIMER

#ifndef __INCLUDE_KFC_H__
#include <kfc.h>
#endif

#pragma prompt("����ǰ���ȶ���Ҫ�ǵ�ȥ��ǰ�������ꡣ")


#ifndef __MSO_DOM_TEXTV2_H__
#include <mso/dom/textv2.h>
#endif

#ifndef __MSO_MSO_H__
#include "mso/mso.h"
#endif

#ifndef __LENGTH_UNIT_H__
#include "htm/length_unit.h"
#endif



// -------------------------------------------------------------------------
//	$Log: stdafx.h,v $
//	Revision 1.5  2006/10/25 02:33:50  xulingjiao
//	*** empty log message ***
//	
//	Revision 1.4  2006/09/21 08:12:42  wangdong
//	�����ĵ���
//	
//	Revision 1.3  2006/09/20 09:42:36  wangdong
//	*** empty log message ***
//	
//	Revision 1.2  2006/09/19 08:22:45  wangdong
//	*** empty log message ***
//	
//	Revision 1.1  2006/09/01 02:05:07  wangdong
//	*** empty log message ***
//	

#endif /* __STDAFX_H__ */
