/* -------------------------------------------------------------------------
//	�ļ���		��	wmldrawing/wmlshapetarget.h
//	������		��	���὿
//	����ʱ��	��	2006-10-20 17:23:41
//	��������	��	
//
//	$Id: wmlshapetarget.h,v 1.8 2006/10/27 05:56:36 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLDRAWING_WMLSHAPETARGET_H__
#define __WMLDRAWING_WMLSHAPETARGET_H__
#ifndef __DWTARGET_H__
#include "dwDocTarget.h"
#endif

#ifndef __WMLDRAWING_VML_VMLSHAPECOLLECTOR_H__
#include "vml/vmlshapecollector.h"
#endif

// �������洢һ��shape(����child shape��top level shape)���ռ�������������ݡ�
// ShapeCollector��ʾ���������ռ���
class ShapeTarget
{	
public:		
	STDMETHODIMP NewShape(
		BOOL fGroup,
		KDWDocTarget* docTarget,
		WmlSpt spt)
	{		
		m_shp = docTarget->AddShape(fGroup);
		m_spt = spt;
		m_opt.Reset();
		m_anchor.Reset();
		return S_OK;
	}
	STDMETHODIMP UpdateShape(BOOL fChild)
	{
		m_anchor.Update();
		if(fChild)
			m_opt.UpdateChildShape(m_shp);
		else
		{
			m_shp.SetClientAnchor(m_anchor);
			m_opt.UpdateShape(m_shp);
			m_shp.SetShapeType((MSOSPT)m_spt);
		}
		return S_OK;
	}	
public:	
	STDMETHODIMP NewChildShape(
		BOOL fgroup,
		WmlShape grpshape,
		WmlSpt spt)
	{		
		if(!grpshape.IsGroupShape())
			return E_FAIL;		
		m_shp = grpshape.NewShape(fgroup);
		m_spt = spt;
		m_opt.Reset();
		m_anchor.Reset();		
		return S_OK;
	}	
	STDMETHODIMP_(WmlShape) GetShape()
	{
		return m_shp;
	}	
private:
	WmlShape		m_shp;	
	WmlSpt			m_spt;
	WmlShapeOPT		m_opt;
	WmlShapeAnchor	m_anchor;
};

typedef ShapeTarget VmlShapeTarget;

inline STDMETHODIMP_(WmlSpt) GetSpt(XmlName elemName)
{
	switch(elemName)
	{
	case v::rect:
		return msosptRectangle;
	case v::oval:
		return msosptEllipse;
	}
	return msosptNotPrimitive;
}
#endif /* __WMLDRAWING_WMLSHAPETARGET_H__ */
