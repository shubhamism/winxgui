/* -------------------------------------------------------------------------
//	�ļ���		��	dwTarget.h
//	������		��	����
//	����ʱ��	��	2006-9-15 11:19:36
//	��������	��	
//
//	$Id: dwDocTarget.h,v 1.4 2006/10/20 07:51:22 chenghui Exp $
// -----------------------------------------------------------------------*/
#ifndef __DWTARGET_H__
#define __DWTARGET_H__

typedef std::map<ks_wstring, UINT> KDWFontMap;
typedef std::map<ks_wstring, UINT> KDWStyleMap;

struct KDWStyleRelationShip
{	
	INT nIstd;
	ks_wstring basedOn;
	ks_wstring next;
	ks_wstring link;

	struct KDWStyleRelationShipMark
	{
		BOOL basedOn;
		BOOL next;
		BOOL link;
		KDWStyleRelationShipMark()
		{
			memset(this, 0, sizeof(KDWStyleRelationShipMark));
		}
	} mark;	

	BOOL GetValid()
	{
		return mark.basedOn || mark.next || mark.link;
	}
};

typedef std::vector<KDWStyleRelationShip> KDWStyleRelationShipMap;
// -------------------------------------------------------------------------
class KDWDocTarget : public KDWDocument
{
	KDWFontMap m_fontMap;
	KDWStyleMap m_styleMap;
	KDWStyleMap m_latentStylesMap;

	KDWStyleRelationShipMap m_styleRelation;


public:	
	STDMETHODIMP_(KDWFontMap&) GetFontMap()
	{
		return m_fontMap;
	}

	STDMETHODIMP_(KDWStyleMap&)	GetStyleMap()
	{
		return m_styleMap;
	}

	STDMETHODIMP_(KDWStyleMap&)	GetLatentStylesMap()
	{
		return m_latentStylesMap;
	}

	STDMETHODIMP_(KDWStyleRelationShipMap&) GetStyleRelation()
	{
		return m_styleRelation;
	}
};


// -------------------------------------------------------------------------
//	$Log: dwDocTarget.h,v $
//	Revision 1.4  2006/10/20 07:51:22  chenghui
//	��ʽ
//	
//	Revision 1.3  2006/10/19 07:44:21  chenghui
//	���ִ������
//	
//	Revision 1.2  2006/10/18 08:19:47  xulingjiao
//	���Ӵ���vml������������
//	
//	Revision 1.1  2006/09/20 09:42:36  wangdong
//	*** empty log message ***
//	
//	Revision 1.1  2006/09/19 08:22:46  wangdong
//	*** empty log message ***
//	

#endif /* __DWTARGET_H__ */
