/* -------------------------------------------------------------------------
//	�ļ���		��	wmlrPrAttrTrans.h
//	������		��	chenghui
//	����ʱ��	��	2006-10-9 15:18:22
//	��������	��	
//
//	$Id: wmlrPrAttrTrans.h,v 1.5 2006/10/20 07:51:22 chenghui Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLRPRATTRTRANS_H__
#define __WMLRPRATTRTRANS_H__

#ifndef __DWTARGET_H__
#include "dwDocTarget.h"
#endif

// -------------------------------------------------------------------------

using namespace mso::xml12;

// -------------------------------------------------------------------------
XmlEnumPair txFontHintMap[] =
{
	xE("default",	mso_FHintDefault)
	xE("eastAsia",	mso_FHintEastAsia)
	xE("cs",		mso_FHintCs)
};

static
STDMETHODIMP_(void) WmlAddFontAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		static
		XmlEnumMap _mapHint(txFontHintMap, countof(txFontHintMap), mso_FHintDefault);

		KDWFontMap Fontmap = docTarget->GetFontMap();

		XmlRoAttr* pRoAttr = attr->GetByName(w::hint);
		if (pRoAttr)
			buffer->AddPropFix(sprmCIdctHint, _mapHint.Find(pRoAttr->Str()));
		
		pRoAttr = attr->GetByName(w::ascii);
		if (pRoAttr)
		{
			KDWFontMap::const_iterator i = Fontmap.find(pRoAttr->Str());
			if (i != Fontmap.end())
				buffer->AddPropFix(sprmCRgFtc0, i->second);
		}
		
		pRoAttr = attr->GetByName(w::hAnsi);
		if (pRoAttr)
		{
			KDWFontMap::const_iterator i = Fontmap.find(pRoAttr->Str());
			if (i != Fontmap.end())
				buffer->AddPropFix(sprmCRgFtc1, i->second);
		}
		
		pRoAttr = attr->GetByName(w::eastAsian);
		if (pRoAttr)
		{
			KDWFontMap::const_iterator i = Fontmap.find(pRoAttr->Str());
			if (i != Fontmap.end())
				buffer->AddPropFix(sprmCRgFtc2, i->second);
		}
		
		pRoAttr = attr->GetByName(w::cs);
		if (pRoAttr)
		{
			KDWFontMap::const_iterator i = Fontmap.find(pRoAttr->Str());
			if (i != Fontmap.end())
				buffer->AddPropFix(sprmCFtcBi, i->second);
		}
		
		pRoAttr = attr->GetByName(w::asciiTheme);
		if (pRoAttr)
		{
		}
		
		pRoAttr = attr->GetByName(w::hAnsiTheme);
		if (pRoAttr)
		{
		}
		
		pRoAttr = attr->GetByName(w::fareastTheme);
		if (pRoAttr)
		{
		}
		
		pRoAttr = attr->GetByName(w::cstheme);
		if (pRoAttr)
		{
		}
	}
}

static
STDMETHODIMP_(void) WmlAddColorAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr)
			buffer->AddPropFix(sprmCCusColor, pRoAttr->hexColor());
		
		pRoAttr = attr->GetByName(w::themeColor);
		if (pRoAttr)
		{
		}
		
		pRoAttr = attr->GetByName(w::themeTint);
		if (pRoAttr)
		{
		}

		pRoAttr = attr->GetByName(w::themeShade);
		if (pRoAttr)
		{
		}
	}
}


XmlEnumPair txUnderLineMap[] =
{
	xE("single",			mso_ulSingle)
	xE("words",				mso_ulByWord)
	xE("double",			mso_ulDouble)
	xE("thick",				mso_ulThick)
	xE("dotted",			mso_ulDotted)
	xE("dottedHeavy",		mso_ulDottedHeavy)
	xE("dash",				mso_ulDash)
	xE("dashedHeavy",		mso_ulDashedHeavy)
	xE("dashLong",			mso_ulDashLong)
	xE("dashLongHeavy",		mso_ulDashLongHeavy)
	xE("dotDash",			mso_ulDotDash)
	xE("dashDotHeavy",		mso_ulDashDotHeavy)
	xE("dotDotDash",		mso_ulDotDotDash)
	xE("dashDotDotHeavy",	mso_ulDashDotDotHeavy)
	xE("wave",				mso_ulWave)
	xE("wavyHeavy",			mso_ulWavyHeavy)
	xE("wavyDouble",		mso_ulWavyDouble)
	xE("none",				mso_ulNone)
};


static
STDMETHODIMP_(void) WmlAddUnderLineAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		static
		XmlEnumMap _mapUL(txUnderLineMap,  countof(txUnderLineMap), mso_ulNone);
		
		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr)
			buffer->AddPropFix(sprmCKul, _mapUL.Find(pRoAttr->Str()));
		
		if (pRoAttr = attr->GetByName(w::color))
			buffer->AddPropFix(sprmCKulColor, pRoAttr->hexColor());
			
		if (pRoAttr = attr->GetByName(w::themeColor))
		{
		}
		
		if (pRoAttr = attr->GetByName(w::themeTint))
		{
		}

		if (pRoAttr = attr->GetByName(w::themeShade))
		{
		}

	}
}

static
STDMETHODIMP_(void) WmlAddFitTextAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		FITTEXT fittext = {0};

		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr)
			fittext.value = pRoAttr->UTwips();

		if (pRoAttr = attr->GetByName(w::id))
		{
		}

		buffer->AddPropVar(sprmCFitText, &fittext, sizeof(FITTEXT));
	}
}


XmlEnumPair txlytBrackets[] = 
{
	xE("none",			mso_tioBracketsNone)
	xE("round",			mso_tioBracketsRound)
	xE("square",		mso_tioBracketsSquare)
	xE("angle",			mso_tioBracketsAngle)
	xE("curly",			mso_tioBracketsCurly)
};

static
STDMETHODIMP_(void) WmlAddAsianLayoutAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		static
		XmlEnumMap _map(txlytBrackets, countof(txlytBrackets), mso_tioBracketsNone);

		ASIANLAYOUT lyt = {0};

		XmlRoAttr* pRoAttr = 0;
		if (pRoAttr = attr->GetByName(w::id))
			lyt.type = pRoAttr->Decimal();

		if (pRoAttr = attr->GetByName(w::combineBrackets))
			lyt.brackets = _map.Find(pRoAttr->Str());

		if (pRoAttr = attr->GetByName(w::vertCompress))
			lyt.compress = pRoAttr->OnOff();

		if (pRoAttr = attr->GetByName(w::combine)) {
		}

		if (pRoAttr = attr->GetByName(w::vert)) {
		}

		buffer->AddPropVar(sprmCAsianLayout, &lyt, sizeof(lyt));
	}
}


XmlEnumPair txMSOLID[] =
{
	xE("ar-SA",				mso_lidArabic)
	xE("bg-BG",				mso_lidBulgarian)
	xE("ca-ES",				mso_lidCatalan)
	xE("zh-TW",				mso_lidTraditionalChinese)
	xE("zh-CN",				mso_lidSimplifiedChinese)
	xE("cs-CZ",				mso_lidCzech)
	xE("da-DK",				mso_lidDanish)
	xE("en-US",				mso_lidUSEnglish)
	xE("en-UK",				mso_lidUKEnglish)
	xE("ko-KR",				mso_lidKorean)
	xE("ja-JP",				mso_lidJapanese)
	xE("el-GR",				mso_lidGreek)
};//δ��

static
STDMETHODIMP_(void) WmlAddLanguageAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		static
		XmlEnumMap _map(txMSOLID, countof(txMSOLID), mso_lidNoProofing);
		
		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr) 
		{
			MSOLID lid = (MSOLID)_map.Find(pRoAttr->Str());
			buffer->AddPropFix(sprmCRgLid0, lid);
			buffer->AddPropFix(sprmCRgLid0Ex, lid);
		}

		if (pRoAttr = attr->GetByName(w::eastAsian))
		{
			MSOLID lid = (MSOLID)_map.Find(pRoAttr->Str());
			buffer->AddPropFix(sprmCRgLid1, lid);
			buffer->AddPropFix(sprmCRgLid1Ex, lid);
		}

		if (pRoAttr = attr->GetByName(w::bidi))
		{
		}
	}
}

static
STDMETHODIMP_(void) WmlAddrStyleAttribute(
	IN mso::xml12::XmlRoAttr* attr,
	IN KDWDocTarget* docTarget,
	IN KDWPropBuffer* buffer
	)
{
	if (attr->Count() > 0)
	{
		KDWStyleMap styleMap = docTarget->GetStyleMap();
		
		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr)
		{
			KDWFontMap::const_iterator i = styleMap.find(pRoAttr->Str());
			buffer->AddPropFix(sprmCIstd, i->second);
		}
	}
}
// -------------------------------------------------------------------------
//	$Log: wmlrPrAttrTrans.h,v $
//	Revision 1.5  2006/10/20 07:51:22  chenghui
//	��ʽ
//	
//	Revision 1.4  2006/10/19 07:38:31  chenghui
//	*** empty log message ***
//	
//	Revision 1.3  2006/10/16 02:28:59  chenghui
//	*** empty log message ***
//	
//	Revision 1.2  2006/10/13 02:30:05  chenghui
//	*** empty log message ***
//	
//	Revision 1.1  2006/10/11 07:09:20  chenghui
//	*** empty log message ***
//	

#endif /* __WMLRPRATTRTRANS_H__ */
