/* -------------------------------------------------------------------------
//	�ļ���		��	wmldrawing/wmlshapeopt.h
//	������		��	���὿
//	����ʱ��	��	2006-10-20 17:22:51
//	��������	��	
//
//	$Id: wmlshapeopt.h,v 1.4 2006/10/23 06:17:47 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLDRAWING_WMLSHAPEOPT_H__
#define __WMLDRAWING_WMLSHAPEOPT_H__

#include "wmlshapetypedef.h"
__USING_MSO_ESCHER

enum WmlSpValueType
{
	Wml_vtI4		= 0,
	Wml_vtBOOL		= 1,
	Wml_vtBLIP		= 2,
	Wml_vtSTR		= 3,
	Wml_vtARRAY		= 4,
	Wml_vtHLINK		= 5,
	Wml_vtHSHP		= 6,
	Wml_vtSKIP		= 7,
	Wml_vtMAX,
	Wml_vtBoolean	= Wml_vtBOOL,
	Wml_vtAngle		= Wml_vtI4,
	Wml_vtString	= Wml_vtSTR,
	Wml_vtArray		= Wml_vtARRAY,
	Wml_vtEMU		= Wml_vtI4,
	Wml_vtShapeID	= Wml_vtHSHP,
	Wml_vtLong		= Wml_vtI4,
	Wml_vtEnum		= Wml_vtI4,
	Wml_vtColor		= Wml_vtI4,
	Wml_vtFixed		= Wml_vtI4,
	Wml_vtPicture	= Wml_vtBLIP,
	Wml_vtTwips		= Wml_vtI4,
	Wml_vtHyperlink	= Wml_vtHLINK,
	Wml_vtSkipData	= Wml_vtSKIP,
};

enum WmlSpPropType
{
	Wml_ptProperties	 = 0,
	Wml_ptUDefProperties = 1,
	Wml_ptElse			 = 2,	
};

#define msopt_ShapeType			( (PID)0 )

#define msopt_longValArrayMax	( (PID)6 )
#define msopt_boolValArrayMax	( (PID)0x8004 )

#define msopt_groupBottom		( (PID)1 )
#define msopt_groupLeft			( (PID)2 )
#define msopt_groupRight		( (PID)3 )
#define msopt_groupTop			( (PID)4 )
#define msopt_relRotation		( (PID)5 )
#define msopt_relBottom			msopt_groupBottom
#define msopt_relLeft			msopt_groupLeft
#define msopt_relRight			msopt_groupRight
#define msopt_relTop			msopt_groupTop

#define msopt_fFlipV			( (PID)0x8001 )
#define msopt_fFlipH			( (PID)0x8002 )
#define msopt_fRelFlipH			msopt_fFlipH
#define msopt_fRelFlipV			msopt_fFlipV

struct WmlShapeElseOPT
{
	INT32 longVal[msopt_longValArrayMax];
	UINT8 boolVal[msopt_boolValArrayMax & 0x0f];

public:
	__forceinline void Reset()
	{
		ZeroMemory(this, sizeof(WmlShapeElseOPT));
		longVal[msopt_ShapeType] = msosptPictureFrame;
		longVal[msopt_relRight] =
		longVal[msopt_relBottom] = 0x100;
	}

	__forceinline void ForceAddPropFix(
		IN PID pid,
		IN INT32 oprand)
	{
		ASSERT(pid < msopt_longValArrayMax);
		longVal[pid] = oprand;
	}

	__forceinline void ForceAddPropBool(
		IN PID pid,
		IN BOOL fBool)
	{
		ASSERT(pid < msopt_boolValArrayMax);
		boolVal[pid & 0x0f] = fBool;
	}
};


enum
{
	opt_normal,
	opt_userdefined,
	opt_max,
};
// �������洢�����б�
class WmlShapeOPT
{
public:	
	WmlShapeOPT()
	{
		Reset();
	}
	STDMETHODIMP_(void) Reset()
	{
		m_optElse.Reset();		
	}
	STDMETHODIMP UpdateShape(WmlShape shape)
	{
		ASSERT(	shape.Good() );
		shape.SetShapeType( (MSOSPT)m_optElse.longVal[msopt_ShapeType] )
			.SetFlipV( m_optElse.boolVal[msopt_fFlipV & 0x0f] )
			.SetFlipH( m_optElse.boolVal[msopt_fFlipH & 0x0f] )
			.SetProperties(m_opt[opt_normal])
			.SetUDefProperties(m_opt[opt_userdefined]);
		return S_OK;
	}

	STDMETHODIMP_(void) UpdateChildShape(WmlShape shape)
	{
		ASSERT(
			shape.Good() &&
			shape.IsChildShape() );

		UpdateShape(shape);
		shape.SetChildAnchor(
			m_optElse.longVal[msopt_relLeft],
			m_optElse.longVal[msopt_relTop],
			m_optElse.longVal[msopt_relRight],
			m_optElse.longVal[msopt_relBottom]);
	}
	STDMETHODIMP_(MsoShapeOPT&) GetUsrdefOPT()
	{
		return m_opt[opt_userdefined];
	}
	STDMETHODIMP_(MsoShapeOPT&) GetNormalOPT()
	{
		return m_opt[opt_normal];
	}
	STDMETHODIMP_(WmlShapeElseOPT) GetElseOPT()
	{
		return m_optElse;
	}
private:
	MsoShapeOPT m_opt[opt_max];
	WmlShapeElseOPT m_optElse;
};
#endif /* __WMLDRAWING_WMLSHAPEOPT_H__ */
