/* -------------------------------------------------------------------------
//	�ļ���		��	wmlDefAttrTrans.h
//	������		��	����
//	����ʱ��	��	2006-9-21 11:24:54
//	��������	��	
//
//	$Id: wmlDefAttrTrans.h,v 1.9 2006/10/19 07:44:22 chenghui Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLDEFATTRTRANS_H__
#define __WMLDEFATTRTRANS_H__

#ifndef __MSO_XML12_XMLFX_XMLATTR_H__
#include <mso/xml12/xmlFx/xmlAttr.h>
#endif

// -------------------------------------------------------------------------
using namespace mso::xml12;

// -------------------------------------------------------------------------
STDMETHODIMP_(void) WmlAttr_rPr(
	IN mso::xml12::XmlRoAttr* attr,
	IN class KDWDocTarget* docTarget,
	IN class KDWPropBuffer* buffer
	);

STDMETHODIMP_(void) WmlAttr_pPr(
	IN mso::xml12::XmlRoAttr* attr,
	IN class KDWDocTarget* docTarget,
	IN class KDWPropBuffer* buffer
	);

STDMETHODIMP_(void) WmlAttr_sectPr(
	IN mso::xml12::XmlRoAttr* attr,
	IN class KDWDocTarget* docTarget,
	IN class KDWPropBuffer* buffer
	);


// -------------------------------------------------------------------------
template<
	UINT sprm,
	mso::xml12::XmlEnumPair* Map, UINT MapSize, UINT defVal
	>
struct __WmlEnum
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		static
		XmlEnumMap _map(Map, MapSize, defVal);

		buffer->AddPropFix(
			sprm, _map.Find(attr->Str())
			);
	}
};

#define WmlEnum(sprm, Map, defVal) \
	__WmlEnum<sprm, Map, countof(Map), defVal>::T


// -------------------------------------------------------------------------
template<UINT sprm>
struct WmlOnOff
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		XmlRoAttr* pRoAttr = attr->GetByName(w::val);
		if (pRoAttr)
			buffer->AddPropFix(sprm, pRoAttr->OnOff());
		else
			buffer->AddPropFix(sprm, TRUE);
	};
};

template<UINT sprm>
struct WmlDecimal
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		buffer->AddPropFix(sprm, attr->Decimal());
	};
};

template<UINT sprm>
struct WmlUDecimal
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		buffer->AddPropFix(sprm, attr->UDecimal());
	};
};

template<UINT sprm>
struct WmlTwips
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		buffer->AddPropFix(sprm, attr->UTwips());
	};
};

template<UINT sprm>
struct WmlSignedTwips
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		buffer->AddPropFix(sprm, attr->Twips());
	};
};

// -------------------------------------------------------------------------

static
STDMETHODIMP AddBrcAttribute(KDWBrc&	brc, 
							 mso::xml12::XmlRoAttr*	attr);

template<UINT sprm, UINT sprmEx>
struct __WmlBrc
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		if (attr->Count() > 0)
		{
			KDWBrc Brc;
			AddBrcAttribute(Brc, attr);

			buffer->AddPropFix(sprm,	(UINT)&Brc.get_Brc());
			buffer->AddPropVar(sprmEx,	&Brc,	sizeof(Brc));
		}		
	};
};

#define mso_brcNil		0xFFFF

static
XmlEnumPair txBorderTypeMap[] = 
{
	xE("nil",					mso_brcNil)
	xE("none",					mso_brcNone)
	xE("single",				mso_brcSingle)
	xE("thick",					mso_brcThick)
	xE("double",				mso_brcDouble)
	xE("dotted",				mso_brcDot)
	xE("dashed",				mso_brcDashLarge)
	xE("dotDash",				mso_brcDotDash)
	xE("dotDotDash",			mso_brcDotDotDash)
	xE("triple",				mso_brcTriple)
	xE("thinThickSmallGap",		mso_brcThinThickSmall)
	xE("thickThinSmallGap",		mso_brcThickThinSmall)
	xE("thinThickThinSmallGap",	mso_brcThinThickThinSmall)
	xE("thinThickMediumGap",	mso_brcThinThickMedium)
	xE("thickThinMediumGap",	mso_brcThickThinMedium)
	xE("thinThickThinMediumGap",mso_brcThinThickThinMedium)
	xE("thinThickLargeGap",		mso_brcThinThickLarge)
	xE("thickThinLargeGap",		mso_brcThickThinLarge)
	xE("thinThickThinLargeGap",	mso_brcThinThickThinLarge)
	xE("wave",					mso_brcWave)
	xE("doubleWave",			mso_brcDoubleWave)
	xE("dashSmallGap",			mso_brcDashSmall)
	xE("dashDotStroked",		mso_brcDashDotStroked)
	xE("threeDEmboss",			mso_brcEmboss)
	xE("threeDEngrave",			mso_brcEngrave)
	xE("outset",				mso_brcOutset)
	xE("inset",					mso_brcInset)
};

static
STDMETHODIMP AddBrcAttribute(KDWBrc&	brc, 
							 mso::xml12::XmlRoAttr*	attr)
{
	static
	XmlEnumMap _map(txBorderTypeMap, countof(txBorderTypeMap), mso_brcSingle);

	XmlRoAttr* pRoAttr = attr->GetByName(w::val);
	if (pRoAttr)
	{
		UINT Val = _map.Find(pRoAttr->Str());
		if (Val == mso_brcNil)
		{
			brc.put_Nil();
		}
		else
			brc.brcType = Val;
	}

	if (pRoAttr = attr->GetByName(w::color))
		brc.put_Color((COLORREF)pRoAttr->hexColor());

	if (pRoAttr = attr->GetByName(w::themeColor))
	{
	}

	if (pRoAttr = attr->GetByName(w::themeTint))
	{
	}

	if (pRoAttr = attr->GetByName(w::themeShade))
	{
	}

	if (pRoAttr = attr->GetByName(w::sz))
		brc.dptLineWidth = pRoAttr->hexLong();

	if (pRoAttr = attr->GetByName(w::space))
		brc.dptSpace = pRoAttr->hexLong();

	if (pRoAttr = attr->GetByName(w::shadow))
		brc.fShadow = pRoAttr->OnOff();

	if (pRoAttr = attr->GetByName(w::frame))
		brc.fFrame = pRoAttr->OnOff();

	return S_OK;
}


#define	WmlBrc(sprm, sprmEx) \
		__WmlBrc<sprm, sprmEx>::T

// -------------------------------------------------------------------------
static
XmlEnumPair txShdStyle[] = 
{
	xE("nil",					mso_patNil)
	xE("clear",					mso_patAutomatic)
	xE("solid",					mso_patSolid)
	xE("horzStripe",			mso_patDarkHorizontal)
	xE("vertStripe",			mso_patDarkVertical)
	xE("reverseDiagStripe",		mso_patDarkForwardDiagonal)
	xE("diagStripe",			mso_patDarkBackwardDiagonal)
	xE("horzCross",				mso_patDarkCross)
	xE("diagCross",				mso_patDarkDiagonalCross)
	xE("thinHorzStripe",		mso_patHorizontal)
	xE("thinVertStripe",		mso_patVertical)
	xE("thinReverseDiagStripe",	mso_patForwardDiagonal)
	xE("thinDiagStripe",		mso_patBackwardDiagonal)
	xE("thinHorzCross",			mso_patCross)
	xE("thinDiagCross",			mso_patDiagonalCross)
	xE("pct5",					mso_pat5Percent)
	xE("pct10",					mso_pat10Percent)
	xE("pct12",					mso_pat12Percent)
	xE("pct15",					mso_pat15Percent)
	xE("pct20",					mso_pat20Percent)
	xE("pct25",					mso_pat25Percent)
	xE("pct30",					mso_pat30Percent)
	xE("pct35",					mso_pat35Percent)
	xE("pct37",					mso_pat37Percent)
	xE("pct40",					mso_pat40Percent)
	xE("pct45",					mso_pat45Percent)
	xE("pct50",					mso_pat50Percent)
	xE("pct55",					mso_pat55Percent)
	xE("pct60",					mso_pat60Percent)
	xE("pct62",					mso_pat62Percent)
	xE("pct65",					mso_pat65Percent)
	xE("pct70",					mso_pat70Percent)
	xE("pct75",					mso_pat75Percent)
	xE("pct80",					mso_pat80Percent)
	xE("pct85",					mso_pat85Percent)
	xE("pct87",					mso_pat87Percent)
	xE("pct90",					mso_pat90Percent)
	xE("pct95",					mso_pat95Percent)
}; 

template<UINT sprm,  UINT sprmEx>
struct __WmlShd
{
	static
	STDMETHODIMP_(void) T(
		IN mso::xml12::XmlRoAttr* attr,
		IN KDWDocTarget* docTarget,
		IN KDWPropBuffer* buffer
		)
	{
		if (attr->Count() > 0)
		{
			static
			XmlEnumMap _mapShd(txShdStyle, countof(txShdStyle), mso_patNil);

			KDWShd shdex;

			XmlRoAttr* pRoAttr = attr->GetByName(w::val);
			if (pRoAttr)
				shdex.ipat = _mapShd.Find(pRoAttr->Str());

			if (pRoAttr = attr->GetByName(w::color))
				shdex.crFore = pRoAttr->hexColor();

			if (pRoAttr = attr->GetByName(w::themeColor))
			{
			}
			
			if (pRoAttr = attr->GetByName(w::themeTint))
			{
			}
			
			if (pRoAttr = attr->GetByName(w::themeShade))
			{
			}

			if (pRoAttr = attr->GetByName(w::fill))
				shdex.crBack = pRoAttr->hexColor();

			if (pRoAttr = attr->GetByName(w::themeFill))
			{
			}
			
			if (pRoAttr = attr->GetByName(w::themeFillTint))
			{
			}
			
			if (pRoAttr = attr->GetByName(w::themeFillShade))
			{
			}

			buffer->AddPropFix(sprm, *(INT16*)&(shdex.get_Shd()));
			buffer->AddPropVar(sprmEx, &shdex, sizeof(shdex));
		}
	}
};
#define	WmlShd(sprm, sprmEx) \
		__WmlShd<sprm, sprmEx>::T



// -------------------------------------------------------------------------

// -------------------------------------------------------------------------
//	$Log: wmlDefAttrTrans.h,v $
//	Revision 1.9  2006/10/19 07:44:22  chenghui
//	���ִ������
//	
//	Revision 1.8  2006/10/16 02:28:59  chenghui
//	*** empty log message ***
//	
//	Revision 1.7  2006/10/13 02:30:05  chenghui
//	*** empty log message ***
//	
//	Revision 1.6  2006/10/11 09:05:43  wangdong
//	����OnOff��ʵ�֡�
//	
//	Revision 1.5  2006/10/11 07:09:20  chenghui
//	*** empty log message ***
//	
//	Revision 1.4  2006/10/10 07:07:32  wangdong
//	��AttrVal�Ķ����´��롣
//	
//	Revision 1.3  2006/09/21 06:34:36  wangdong
//	AttrInfo Map���ٸ���sprm���κ��߼���
//	
//	Revision 1.2  2006/09/21 06:19:06  wangdong
//	����Ŀ¼��
//	
//	Revision 1.1  2006/09/21 06:06:07  wangdong
//	����map��ɡ�
//	

#endif /* __WMLDEFATTRTRANS_H__ */
