/* -------------------------------------------------------------------------
//	�ļ���		��	wmldrawing/wmlshapetypedef.h
//	������		��	���὿
//	����ʱ��	��	2006-10-20 17:24:08
//	��������	��	
//
//	$Id: wmlshapetypedef.h,v 1.6 2006/10/27 05:56:36 xulingjiao Exp $
// -----------------------------------------------------------------------*/
#ifndef __WMLDRAWING_WMLSHAPETYPEDEF_H__
#define __WMLDRAWING_WMLSHAPETYPEDEF_H__

typedef KDWShape WmlShape;
typedef UINT32 WmlShapeID;
typedef UINT32 RealShapID;

struct WmlShapeAnchor : public KDWShapeAnchor
{	
	WmlShapeAnchor()
	{
		Reset();
	}
	STDMETHODIMP_(void) Reset()
	{
		//@todo
	}
	STDMETHODIMP_(void) Update()
	{
		xaRight = xaLeft+xWidth;
		yaBottom = yaTop+yHeight;
	}
	INT xWidth, yHeight;
};

// ��дspt��ʾshape type
typedef ks_string WmlSptId;
typedef INT WmlSpt, WmlZorder;

#endif /* __WMLDRAWING_WMLSHAPETYPEDEF_H__ */
