/* -------------------------------------------------------------------------
//	�ļ���		��	stylesheet.h
//	������		��	����
//	����ʱ��	��	2006-3-29 9:15:36
//	��������	��	
//	$Id: stylesheet.h,v 1.8 2006/06/01 02:02:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __STYLESHEET_H__
#define __STYLESHEET_H__

#ifndef __PROPPRODUCTOR_H__
#include "../propproductor.h"
#endif

// -------------------------------------------------------------------------
template<class DWType>
class KRdrStyleSheetWriter
{
	KRdrContext<DWType>* m_rdrContext;
public:
	KRdrStyleSheetWriter(
		IN KRdrContext<DWType>* rdrContext)
	{
		m_rdrContext = rdrContext;
	}

public:
	STDMETHODIMP_(void) Write(
		IN DWType* dwDocument)
	{
		using KRdrCore::RdrStyleMap;
		RdrStyleMap& styleMap = 
			m_rdrContext->GetStyleMap();
		
		
		const KDRStyleSheet& srcSheet = 
			m_rdrContext->GetDRDoc()->GetStyleSheet();
		DWType::DWStyleSheet& destSheet = 
			dwDocument->GetStyleSheet();

		for (UINT i = 0; i < srcSheet.Count(); ++i)
		{
			const KDRStyle* drStyle = NULL;
			srcSheet.GetStyle(i, &drStyle);
			if (drStyle == NULL)
				continue;

			DWType::DWStyle dwStyle;
			destSheet.NewStyle(
				drStyle->GetSti(),
				drStyle->GetName(),
				drStyle->GetType(),
				&dwStyle
				);

			styleMap.insert(
				std::make_pair(drStyle->GetIndex(), dwStyle.GetIndex())
				);
		}


		const KRdrCore::RdrFontMap& fontMap = m_rdrContext->GetFontMap();

		KRdrCore::RdrFontMap::const_iterator iffn;
		iffn = fontMap.find(srcSheet.get_DefaultFont_ASCII());
		if (iffn != fontMap.end())
			destSheet.put_DefaultFont_ASCII(iffn->second);

		iffn = fontMap.find(srcSheet.get_DefaultFont_FarEast());
		if (iffn != fontMap.end())
			destSheet.put_DefaultFont_FarEast(iffn->second);

		iffn = fontMap.find(srcSheet.get_DefaultFont_Complex());
		if (iffn != fontMap.end())
			destSheet.put_DefaultFont_Complex(iffn->second);
		
		
		KRdrCore::RdrStyleMap::const_iterator i = styleMap.begin();

		for (; i != styleMap.end(); ++i)
		{
			const KDRStyle* drStyle = NULL;
			srcSheet.GetStyle(i->first, &drStyle);

			DWType::DWStyle dwStyle;
			destSheet.GetStyle(i->second, &dwStyle);

			dwStyle.SetAutoRedefine(drStyle->GetAutoRedefine());
			dwStyle.SetHiddenUI(drStyle->GetHiddenUI());
			dwStyle.SetSemiHidden(drStyle->GetSemiHidden());

			RdrStyleMap::const_iterator ibase = 
				styleMap.find(drStyle->GetBaseStyle());
			if (ibase != styleMap.end())
				dwStyle.SetBaseStyle(ibase->second);

			RdrStyleMap::const_iterator inext = 
				styleMap.find(drStyle->GetNextStyle());
			if (inext != styleMap.end())
				dwStyle.SetNextStyle(inext->second);

			RdrStyleMap::const_iterator ilink = 
				styleMap.find(drStyle->GetLinkStyle());
			if (ilink != styleMap.end())
				dwStyle.SetLinkStyle(ilink->second);


			if (drStyle->GetChpx())
			{
				dwStyle.SetSprmList(
					mso_sgcCharacter,
					KRdrPropProductor<DWType>::Instance()->GetStyChpBuf(m_rdrContext, drStyle));
			}
	
			if(m_rdrContext->GetStyContext()->HasStylePap(drStyle->GetIndex()))
			{
				dwStyle.SetSprmList(
					mso_sgcParagraph,
					KRdrPropProductor<DWType>::Instance()->GetStyPapBuf(m_rdrContext, dwDocument, drStyle));
			}

			//@���ӱ�����ʽ��֧��
			if(m_rdrContext->GetStyContext()->HasStyleTap(drStyle->GetIndex()))
			{
				dwStyle.SetSprmList(
					mso_sgcTextTable,
					KRdrPropProductor<DWType>::Instance()->GetStyTapBuf(m_rdrContext, drStyle));
			}
			
		}
	}
};



// -------------------------------------------------------------------------

#endif /* __STYLESHEET_H__ */

// $Log: stylesheet.h,v $
// Revision 1.8  2006/06/01 02:02:29  zhuyunfeng
// �޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//
// Revision 1.7  2006/05/31 06:11:05  zhuyunfeng
// *** empty log message ***
//
// Revision 1.6  2006/05/30 00:58:09  zhuyunfeng
// *** empty log message ***
//
// Revision 1.5  2006/05/26 05:31:19  zhuyunfeng
// ��ɱ���ת��
//
// Revision 1.4  2006/05/25 02:52:17  zhuyunfeng
// ������ɱ�����ʽ�Ĵ���������ϸ����
//
// Revision 1.3  2006/05/16 07:12:53  zhuyunfeng
// *** empty log message ***
//
// Revision 1.2  2006/05/15 09:05:58  zhuyunfeng
// *** empty log message ***
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
