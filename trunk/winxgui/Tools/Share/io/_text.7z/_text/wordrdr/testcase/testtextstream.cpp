/* -------------------------------------------------------------------------
//	�ļ���		��	testtextstream.cpp
//	������		��	����
//	����ʱ��	��	2006-2-22 15:38:02
//	��������	��	
//	$Id: testtextstream.cpp,v 1.7 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------


static WCHAR* GetFileName(WCHAR* buf, WCHAR* szFileName, WCHAR* szPath)
{
	wcscpy(buf, szPath);
	return wcscat(buf, szFileName);
}


class TestTextStream : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestTextStream);
		CPPUNIT_TEST(TestChpx);
		CPPUNIT_TEST(testStreamWriter);
		CPPUNIT_TEST(testBasic);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void TestChpx()
	{

		
		SEARCHREC Rec;
		WCHAR buf[256];
		HANDLE handle = _XFindFirstW(_SearchPath, faAnyFile, &Rec);
		
		
		while(_XFindNextW(handle, &Rec))
		{
			memset(buf, 0, 512);
			KDWDocumentType docu;
		    docu.NewDocument(GetFileName(buf, Rec.szFileName, _SavePath));
			
			memset(buf, 0, 512);
			KWordRdr<KDWDocumentType> wordRdr;
			wordRdr.OpenDocument(GetFileName(buf, Rec.szFileName, _OpenPath));

		    wordRdr.Write(&docu);

		    wordRdr.Close();
		    docu.Close();
		}

		_XFindClose(handle);
		

		/*
		
		KDWDocument docu;
		docu.NewDocument(testOutputPath("wordrdr_Chpx.doc"));


		KWordRdr<KDWDocument> wordRdr;
		//wordRdr.OpenDocument(testSrcPath("core/chpx.doc"));
		wordRdr.OpenDocument(L"C:\\3.doc");
		wordRdr.Write(&docu);
		wordRdr.Close();

		docu.Close();
		*/
		
	}
	void testStreamWriter()
	{
		KDWDocumentType docu;
		docu.NewDocument(testOutputPath("wordrdr_testStreamHost.doc"));


		KWordRdr<KDWDocumentType> wordRdr;
		wordRdr.OpenDocument(testSrcPath("�ۺ�/008_�����浥.doc"));
		wordRdr.Write(&docu);
		wordRdr.Close();

		docu.Close();
	}
	void testBasic()
	{
		KDWDocumentType docu;
		docu.NewDocument(testOutputPath("wordrdr_fastsave_044_InfoLitStandards2001(quick).doc"));


		KWordRdr<KDWDocumentType> wordRdr;
		//wordRdr.OpenDocument(testSrcPath("fastsave/020_�Ͷ���ͬ(quick).doc"));
		wordRdr.OpenDocument(testSrcPath("fastsave/044_InfoLitStandards2001(quick).doc"));
		
		wordRdr.Write(&docu);
		wordRdr.Close();

		docu.Close();
	}
};


CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestTextStream);

// -------------------------------------------------------------------------
//	$Log: testtextstream.cpp,v $
//	Revision 1.7  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.6  2006/03/01 02:18:01  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.5  2006/02/28 09:19:33  wangdong
//	���°�����
//	
//	Revision 1.4  2006/02/28 05:39:53  wangdong
//	���°�����
//	
//	Revision 1.3  2006/02/28 03:29:50  wangdong
//	���������������
//	
//	Revision 1.2  2006/02/23 02:54:48  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/02/22 08:32:17  wangdong
//	���̽������е�һ�����԰�����
//	
