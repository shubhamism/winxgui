/* -------------------------------------------------------------------------
//	�ļ���		��	mapper.h
//	������		��	����
//	����ʱ��	��	2006-3-28 16:09:36
//	��������	��	
//	$Id: mapper.h,v 1.8 2006/06/01 02:02:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __CORE_PROPERTY_MAPPER_H__
#define __CORE_PROPERTY_MAPPER_H__

#ifndef __RDRPAP_DEF_H__
#include <mso/dom/text/property/rdrpap_def.h>
#endif

#ifndef __RDRCHP_DEF_H__
#include <mso/dom/text/property/rdrchp_def.h>
#endif

// -------------------------------------------------------------------------

template<class MapType, class ValueType>
__forceinline
STDMETHODIMP_(ValueType) __getmapProp(const MapType& map, ValueType value)
{
	MapType::const_iterator i = map.find(value);
	if(i != map.end())
		return i->second;
	return value;
}


template<class RdrContext, class DWType>
STDMETHODIMP_(void)	mapPapx(
	RdrContext* rdrContext, DWType* dwDoc, RdrPap& pap)
{
	if(pap.get_ilfo() != 0x07ff)
		pap.put_ilfo(rdrContext->GetLfo(
			pap.get_ilfo(), dwDoc));

	pap.put_istd(
		__getmapProp(rdrContext->GetStyleMap(), pap.get_istd()));
}

template<class RdrContext>
STDMETHODIMP_(void) mapChpx( 
	RdrContext* rdrContext, RdrChp& chp)
{
	chp.put_ftcAscii(
		__getmapProp(rdrContext->GetFontMap(), chp.get_ftcAscii()));
	chp.put_ftcFE(
		__getmapProp(rdrContext->GetFontMap(), chp.get_ftcFE()));
	chp.put_ftcOther(
		__getmapProp(rdrContext->GetFontMap(), chp.get_ftcOther()));
	chp.put_istd(
		__getmapProp(rdrContext->GetStyleMap(), chp.get_istd()));
	chp.symbol().put_Value(
		__getmapProp(rdrContext->GetFontMap(), chp.symbol().get_Value()));

}


// -------------------------------------------------------------------------

#endif /* __CORE_PROPERTY_MAPPER_H__ */

// $Log: mapper.h,v $
// Revision 1.8  2006/06/01 02:02:29  zhuyunfeng
// �޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//
// Revision 1.7  2006/05/31 06:11:12  zhuyunfeng
// *** empty log message ***
//
// Revision 1.6  2006/05/30 01:10:46  zhuyunfeng
// *** empty log message ***
//
// Revision 1.5  2006/05/15 09:08:10  zhuyunfeng
// *** empty log message ***
//
// Revision 1.4  2006/05/15 09:06:23  zhuyunfeng
// *** empty log message ***
//
// Revision 1.3  2006/04/05 08:55:38  zhuyunfeng
// *** empty log message ***
//
// Revision 1.2  2006/04/05 06:40:21  wangdong
// ���Symbol��
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
