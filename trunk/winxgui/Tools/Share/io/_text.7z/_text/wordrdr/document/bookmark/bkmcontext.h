/* -------------------------------------------------------------------------
//	�ļ���		��	bkmcontext.h
//	������		��	����
//	����ʱ��	��	2006-4-4 14:29:00
//	��������	��	
//	$Id: bkmcontext.h,v 1.1 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __BKMCONTEXT_H__
#define __BKMCONTEXT_H__


// -------------------------------------------------------------------------
template<class DWType>
class KRdrBkmContext
{
	std::vector<const KDRImage*> m_PicBullets;
	KDRRange m_rgPicBullets;

public:
	STDMETHODIMP_(void) Open(
		const KDRDocument* drDoc)
	{
		m_rgPicBullets.cp = m_rgPicBullets.cpNext = -1;
		LocateBulletsRange(drDoc);
	}
	STDMETHODIMP_(void) Close()
	{
	}

private:
	STDMETHODIMP_(void) LocateBulletsRange(
		const KDRDocument* drDoc)
	{
		const KDRPlcfBkf& bkf  = drDoc->GetBookMarks().GetStarts(SUBDOC_MAIN);
		if (bkf.Count())
		{
			UINT index = bkf.Count() - 1;
			const KDRPlcfBkf::ItemType item = bkf.Item(index);
			
			const WCHAR bkmName[] = __X("_PictureBullets");
			if (wcsnicmp(bkmName, item.pStrBuf, item.cch) == 0)
			{
				const KDRPlcfBkl& bkl = drDoc->GetBookMarks().GetEnds(SUBDOC_MAIN);
				m_rgPicBullets.cp = 
					bkf.Item(index).range.cp;
				m_rgPicBullets.cpNext = 
					bkl.Item(index).range.cp;

				ASSERT(
					m_rgPicBullets.cp < m_rgPicBullets.cpNext
					);
				ASSERT(
					m_rgPicBullets.cpNext <= drDoc->GetPlcfChp(SUBDOC_MAIN).GetLastItemCP()
					);
			}
		}
	}

public:
	STDMETHODIMP_(KDRRange) GetPicBulletsRange() const
	{
		return m_rgPicBullets;
	}
};


// -------------------------------------------------------------------------

#endif /* __BKMCONTEXT_H__ */

// $Log: bkmcontext.h,v $
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
