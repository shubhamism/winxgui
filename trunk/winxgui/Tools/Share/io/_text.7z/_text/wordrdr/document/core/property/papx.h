/* -------------------------------------------------------------------------
//	�ļ���		��	papx.h
//	������		��	����
//	����ʱ��	��	2006-3-27 15:54:41
//	��������	��	
//	$Id: papx.h,v 1.3 2006/04/06 03:22:45 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __CORE_PROPERTY_PAPX_H__
#define __CORE_PROPERTY_PAPX_H__

#ifndef __CORE_PROPERTY_DATA_H__
#include "data.h"
#endif


// -------------------------------------------------------------------------
class __RdrPapxData : public __RdrPropxData
{
public:
	STDMETHODIMP_(UINT16*) getIstd() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)_MsoPdata(m_propx);
	}
	STDMETHODIMP_(UINT16*) getIlfo() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)m_Ilfo;
	}

private:
	UINT8* m_Istd;
	UINT8* m_Ilfo;


protected:
	enum { cbIstd = sizeof(UINT16) };

	__RdrPapxData()
	{
		ZeroMemory(this, sizeof(__RdrPapxData));
		__RdrPropxData::Reset();
		m_size = cbIstd;
	}

	__forceinline
	STDMETHODIMP_(void) Read(
		const UINT8* begin, const UINT8* end)
	{
		if (begin == end)
			return;

		UINT8* curr = 
			(UINT8*)_MsoPdata(m_propx) + m_size;


		KSprm sprm;
		KEnumSprmList sprmList(begin, end - begin);
		while(sprmList.Next(sprm) == S_OK)
		{
			switch(sprm.opcode)
			{
			case sprmPIlfo:
				m_Ilfo = _rdr_OprBegin(curr);
				break;
			case sprmPHugePapx:
			case sprmPHugeTapx:
			case sprmPSprmExtend:
				_rdr_SkipSprm();
				break;
			case 0:
				_rdr_SkipSprm();
				break;
			}

			if (sprm.IsFixSprm())
				_rdr_AddPropFix(curr, sprm.opcode, sprm.GetFixOprand());
			else
				_rdr_AddPropVar(curr, sprm.opcode, sprm.GetOprand(), sprm.oplen);
		}

		m_size = curr - (UINT8*)_MsoPdata(m_propx);
		ASSERT(m_size <= m_propx->cb);
	}
};


class KRdrPapx : public __RdrPapxData
{
public:
	KRdrPapx(
		const KDRMergePropx* propx, 
		KDRDataStrmRef dataStrm, 
		MsoAutoFreeAlloc* alloc)
	{
		ReadPropx(
			propx->pPropx, propx->cbPropx, 
			propx->pFastSavePropx, propx->cbFastSavePropx, 
			dataStrm, alloc
			);
	}
	KRdrPapx(const KDRPropx* propx,
		KDRDataStrmRef dataStrm, 
		MsoAutoFreeAlloc* alloc)
	{
		ReadPropx(
			_DRPropxPdata(propx), propx->cb, 
			NULL, 0, 
			dataStrm, alloc
			);
	}

private:
	STDMETHODIMP_(void) ReadAtFC(FC fc, KDRDataStrmRef dataStrm)
	{
		dataStrm.seek(fc);
		size_t cb = 0;
		dataStrm.read(&cb, 2);
		if (cb)
		{
			UINT8* data = (UINT8*)_alloca(cb);
			dataStrm.read(data, cb);

			Read(data, data + cb);
		}
	}

	__forceinline
	STDMETHODIMP_(BOOL) IsHuge(
		const void* propx, size_t cb, KSprm& sprm) const
	{
		KEnumSprmList sprmList((const UINT8*)propx, cb);
		sprmList.Next(sprm);
		
		return (sprm.opcode == sprmPHugePapx ||
				sprm.opcode == sprmPHugeTapx ||
				sprm.opcode == sprmPSprmExtend
				);
	}

	__forceinline
	STDMETHODIMP_(void) ReadPropx(
		const void* propx, size_t cb, 
		const void* extra, size_t cbExtra,
		KDRDataStrmRef dataStrm,
		MsoAutoFreeAlloc* alloc)
	{
		if (propx == NULL || cb == 0)
			return;


		size_t cbAlloc = cb + cbExtra;
		FC fcHuge = -1;
		FC fcExt  = -1;

		KSprm sprmHuge;
		if (IsHuge((UINT8*)propx + cbIstd, cb - cbIstd, sprmHuge))
		{
			fcHuge = *(FC*)sprmHuge.oprand;
			dataStrm.seek(fcHuge);

			size_t cbHuge = 0;
			dataStrm.read(&cbHuge, 2);
			cbAlloc += cbHuge;

			//
			// @@note:
			//	��sprmPHugeTapx���ǻ��ٴγ���sprmPSprmExtend��
			//
			if (
				cbHuge && 
				sprmHuge.opcode == sprmPHugeTapx
				)
			{
				enum { oplen = 2 };
				enum { cbSprmExt = oplen + sizeof(FC) };

				UINT8* dataHuge = (UINT8*)_alloca(cbSprmExt);
				dataStrm.read(dataHuge, cbSprmExt);
				if (*(UINT16*)dataHuge == sprmPSprmExtend)
				{
					fcExt = *(FC*)(dataHuge + oplen);
					dataStrm.seek(fcExt);

					size_t cbExt = 0;
					dataStrm.read(&cbExt, 2);
					cbAlloc += cbExt;
				}
			}
		}

		m_propx = _MsoAllocKernData(alloc, cbAlloc);
		m_propx->cb = cbAlloc;

		
		*getIstd() = *(UINT16*)propx;
		if (fcHuge != -1)
		{
			if (fcExt != -1)
				ReadAtFC(fcExt, dataStrm);
			ReadAtFC(fcHuge, dataStrm);
		}
		Read((const UINT8*)propx + cbIstd, (const UINT8*)propx + cb);
		Read((const UINT8*)extra, (const UINT8*)cbExtra);

	}
};


// -------------------------------------------------------------------------

#endif /* __CORE_PROPERTY_PAPX_H__ */

// $Log: papx.h,v $
// Revision 1.3  2006/04/06 03:22:45  wangdong
// *** empty log message ***
//
// Revision 1.2  2006/04/05 08:18:57  wangdong
// ����0 sprm����ȡsprmPSprmExtend
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
