/* -------------------------------------------------------------------------
//	�ļ���		��	rdrcontext.h
//	������		��	����
//	����ʱ��	��	2006-3-29 17:03:28
//	��������	��	
//	$Id: rdrcontext.h,v 1.2 2006/05/15 09:00:27 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __RDRCONTEXT_H__
#define __RDRCONTEXT_H__


#ifndef __STL_MAP_H__
#include <stl/map.h>
#endif



// -------------------------------------------------------------------------
class KRdrCore
{
	MsoAutoFreeAlloc* m_alloc;
public:
	STDMETHODIMP_(MsoAutoFreeAlloc*) GetAlloc()
	{
		return m_alloc;
	}

public:
	typedef std::map<UINT16, UINT16>	RdrFontMap;
	typedef std::map<UINT16, UINT16>	RdrStyleMap;
	typedef std::map<UINT, UINT>		RdrUserMap;


private:
	RdrFontMap	m_fontMap;
	RdrStyleMap m_styleMap;
	RdrUserMap m_atnUserMap;
	RdrUserMap m_revUserMap;

public:
	STDMETHODIMP_(RdrFontMap&) GetFontMap()
	{
		return m_fontMap;
	}
	STDMETHODIMP_(RdrStyleMap&) GetStyleMap()
	{
		return m_styleMap;
	}
	STDMETHODIMP_(RdrUserMap&) GetAtnUserMap()
	{
		return m_atnUserMap;
	}
	STDMETHODIMP_(RdrUserMap&) GetRevUserMap()
	{
		return m_revUserMap;
	}

public:
	STDMETHODIMP_(void) Open(
		MsoAutoFreeAlloc* alloc)
	{
		m_alloc = alloc;
	}
	STDMETHODIMP_(void) Close()
	{
		m_fontMap.clear();
		m_styleMap.clear();
		m_atnUserMap.clear();
		m_revUserMap.clear();
		m_alloc = NULL;
	}
};



// -------------------------------------------------------------------------
#ifndef __BKMCONTEXT_H__
#include "bookmark/bkmcontext.h"
#endif

#ifndef __DGCONTEXT_H__
#include "drawing/dgcontext.h"
#endif

#ifndef __FLDCONTEXT_H__
#include "field/fldcontext.h"
#endif

#ifndef __RDR_LISTS_H__
#include "core/lists.h"
#endif

#ifndef __STYLECONTEXT_H__
#include "core/stylecontext.h"
#endif

template<class DWType>
class KRdrContext : public KRdrCore, public KRdrLists<DWType>
{
	const KDRDocument* m_drDoc;
	KRdrDgContext<DWType> m_dgContext;
	KRdrFldContext<DWType> m_fldContext;
	KRdrBkmContext<DWType> m_bkmContext;
	KRdrStyleContext       m_styContext;

public:
	STDMETHODIMP Open(
		IN const KDRDocument* drDoc, 
		IN MsoAutoFreeAlloc* alloc)
	{
		//
		// @@note:
		//	Context��Open�����໥�����������������Open˳��
		//
		KRdrCore::Open(alloc);

		m_bkmContext.Open(drDoc);
		m_dgContext.Open(drDoc, m_bkmContext.GetPicBulletsRange());
		KRdrLists<DWType>::Open(this, &m_dgContext, drDoc);
		m_fldContext.Open(drDoc);

		//@add
		m_styContext.Open(drDoc);

		m_drDoc = drDoc;

		return S_OK;
	}
	STDMETHODIMP Close()
	{
		m_drDoc = NULL;

		m_fldContext.Close();
		KRdrLists<DWType>::Close();
		m_dgContext.Close();
		m_bkmContext.Close();

		KRdrCore::Close();

		return S_OK;
	}
	
public:
	STDMETHODIMP_(const KDRDocument*) GetDRDoc()
	{
		return m_drDoc;
	}
	STDMETHODIMP_(KRdrDgContext<DWType>*) GetDGContext()
	{
		return &m_dgContext;
	}
	STDMETHODIMP_(KRdrFldContext<DWType>*) GetFldContext()
	{
		return &m_fldContext;
	}
	STDMETHODIMP_(KRdrBkmContext<DWType>*) GetBkmContext()
	{
		return &m_bkmContext;
	}
	STDMETHODIMP_(KRdrStyleContext*) GetStyContext()
	{
		return &m_styContext;
	}
};

// -------------------------------------------------------------------------

#endif /* __RDRCONTEXT_H__ */

// $Log: rdrcontext.h,v $
// Revision 1.2  2006/05/15 09:00:27  zhuyunfeng
// *** empty log message ***
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
