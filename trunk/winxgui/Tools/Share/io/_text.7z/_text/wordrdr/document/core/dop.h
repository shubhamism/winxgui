/* -------------------------------------------------------------------------
//	�ļ���		��	dop.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-27 14:28:49
//	��������	��	
//
//	$Id: dop.h,v 1.1 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DOP_H__
#define __DOP_H__

// -------------------------------------------------------------------------
template <class DWType> inline
STDMETHODIMP WriteDop(const KDRDocument* drDoc, DWType* dwDoc)
{
	HRESULT hr = E_FAIL;
	
	DOP dop;
	FCLCB recInfo;
	hr = drDoc->GetRecInfo(Dop, &recInfo);
	CHECK(hr);
	hr = drDoc->GetRecord(recInfo, &dop);
	CHECK(hr);
	
	{
		DWType::DWDocProperties& dwDop = dwDoc->GetDop();
		ASSERT(sizeof(dwDop.dop) >= recInfo.lcb);
		memcpy(&dwDop.dop, &dop, recInfo.lcb);
	}

KS_EXIT:
	return hr;
}

// -------------------------------------------------------------------------
//	$Log: dop.h,v $
//	Revision 1.1  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.1  2006/03/27 06:53:05  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __DOP_H__ */
