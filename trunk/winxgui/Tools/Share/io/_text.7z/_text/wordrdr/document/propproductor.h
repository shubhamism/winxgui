/* -------------------------------------------------------------------------
//	�ļ���		��	propproductor.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-05-31 17:16:22
//	��������	��	��ʱ��������ת�����̵��࣬�Ժ���ں˴����϶�������������
//
//	$Id: propproductor.h,v 1.6 2006/06/09 07:32:05 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __PROPPRODUCTOR_H__
#define __PROPPRODUCTOR_H__

#ifndef __DWTYPE_H__
#include "../include/dwtype.h"
#endif

#ifndef __CORE_PROPERTY_MAPPER_H__
#include "./core/property/mapper.h"
#endif

#ifndef __PAPITEM_H__
#include <mso/dom/text/property/papitem.h>
#endif

#ifndef __CHPITEM_H__
#include <mso/dom/text/property/chpitem.h>
#endif

#ifndef __PROPCONVERT_H__
#include <mso/dom/text/property/propconvert.h>
#endif

#ifndef __MSO_DOM_ROTEXT_H__
#include <mso/dom/rotext.h>
#endif

using namespace PROP_CONVERT;

template <class DWType>
class KRdrContext;
// -------------------------------------------------------------------------
template <class DWType>
class KRdrPropProductor
{
public:
	static KRdrPropProductor* Instance()
	{
		if(m_Instance == NULL)
			m_Instance = new KRdrPropProductor<DWType>();
		return m_Instance;
	}
protected:
	KRdrPropProductor() { m_nCurPapIstd = 0; };

public:
	STDMETHODIMP_(DWType::DWPropBuffer*) GetStyChpBuf(
		IN KRdrContext<DWType>* pRdrContext,
		IN const KDRStyle* pStyle)
	{
		static RdrChp baseChp;
		static RdrChp origChp;
		
		if(pStyle && pRdrContext)
		{
			baseChp.Reset();
			origChp.Reset();
			pRdrContext->GetStyContext()->GetStyleMergeChp(
				pStyle->GetIndex(),
				origChp);
			mapChpx(pRdrContext, origChp);
			
			pRdrContext->GetStyContext()->GetStyleMergeChp(
				pStyle->GetBaseStyle(),
				baseChp);
			mapChpx(pRdrContext, baseChp);

			m_propBuf.Clear();
			Chp2Sprms() (baseChp, origChp, m_propBuf);
		}
		else
		{
			m_propBuf.Clear();
		}

		return &m_propBuf;
	}
	STDMETHODIMP_(DWType::DWPropBuffer*) GetStyPapBuf(
		IN KRdrContext<DWType>* pRdrContext,
		IN DWType*   pDwDoc,
		IN const KDRStyle* pStyle)
	{
		static RdrPap basePap;
		static RdrPap origPap;
	
		if(pStyle && pRdrContext)
		{
			basePap.Reset();
			origPap.Reset();
			
			pRdrContext->GetStyContext()->GetStyleMergePap(
				pStyle->GetIndex(),
				origPap);
		
			mapPapx(pRdrContext, pDwDoc, origPap);

			pRdrContext->GetStyContext()->GetStyleMergePap(
				pStyle->GetBaseStyle(),
				basePap);
			
			mapPapx(pRdrContext, pDwDoc, basePap);

			m_propBuf.Clear();
			Pap2Sprms() (basePap, origPap, m_propBuf);
		}
		else
		{
			m_propBuf.Clear();
		}

		return &m_propBuf;
	}
	STDMETHODIMP_(DWType::DWPropBuffer*) GetStyTapBuf(
		IN KRdrContext<DWType>* pRdrContext,
		IN const KDRStyle* pStyle)
	{
		static RdrTap baseTap;
		static RdrTap origTap;
	
		if(pStyle && pRdrContext)
		{
			baseTap.Reset();
			origTap.Reset();
			
			pRdrContext->GetStyContext()->GetStyleMergeTap(
				pStyle->GetIndex(),
				origTap);
			pRdrContext->GetStyContext()->GetStyleMergeTap(
				pStyle->GetBaseStyle(),
				baseTap);
            m_propBuf.Clear();
			Tap2Sprms() (baseTap, origTap, m_propBuf);
		}
		else
		{
			m_propBuf.Clear();
		}

		return &m_propBuf;
	}

	STDMETHODIMP_(DWType::DWPropBuffer*) GetLstChpBuf(
		IN KRdrCore* pRdrContext,
		IN const RdrChp& origChp)
	{
		static RdrChp baseChp;
	
		baseChp.Reset();
		mapChpx(pRdrContext, baseChp);
		m_propBuf.Clear();
		Chp2Sprms() (baseChp, origChp, m_propBuf);
	
		return &m_propBuf;
	}

	STDMETHODIMP_(DWType::DWPropBuffer*) GetLstPapBuf(
		IN const KDRPropx* pDrPropx)
	{
		static RdrPap basePap;
		static RdrPap origPap;
	
		if(pDrPropx)
		{
			basePap.Reset();
			origPap.Reset();
	
			Sprms2Pap() ((UINT8*)((UINT16*)pDrPropx + 1), pDrPropx->cb, origPap);
			m_propBuf.Clear();
			Pap2Sprms() (basePap, origPap, m_propBuf, FALSE);
		}
		else
		{
			m_propBuf.Clear();
		}

		return &m_propBuf;
	}

	STDMETHODIMP_(DWType::DWPropBuffer*) GetNormalChpBuf(
		IN KRdrContext<DWType>* pRdrContext,
		IN RdrChp& origChp)
	{
		static RdrChp baseChp;
	
		if(pRdrContext)
		{
			baseChp.Reset();
			mapChpx(pRdrContext, origChp);

			UINT16 nIstd = m_nCurPapIstd;
			if(origChp.get_istd() != 0xa)
				nIstd = origChp.get_istd();

			pRdrContext->GetStyContext()->GetStyleMergeChp(
				nIstd,
				baseChp);
			mapChpx(pRdrContext, baseChp);
			m_propBuf.Clear();
			Chp2Sprms() (baseChp, origChp, m_propBuf);
		}
		else
		{
			m_propBuf.Clear();
		}
		return &m_propBuf;
	}
	STDMETHODIMP_(DWType::DWPropBuffer*) GetBreakChpBuf(
		IN KRdrContext<DWType>* pRdrContext,
		IN RdrChp& origChp)
	{
		BOOL fPic = origChp.get_fSpec();
		origChp.put_fSpec(0);
		DWType::DWPropBuffer* ret = GetNormalChpBuf(pRdrContext, origChp);
		origChp.put_fSpec(fPic);
		
		return ret;
	}

	STDMETHODIMP_(DWType::DWPropx*) GetPapx(
		IN KRdrContext<DWType>* pRdrContext,
		IN DWType* pDwDoc,
		IN KRdrPapItem& papItem)
	{
		ASSERT(papItem.IsNeedNotConvert());
		DWType::DWPropx* ret = papItem.GetPropx(pDwDoc->GetAllocator());
		UINT8* pSprms = (UINT8*)ret + sizeof(UINT);
		UINT16 nIstd = TokenVal(pSprms, UINT16);
		*((UINT16*)(pSprms - 2)) = __getmapProp(pRdrContext->GetStyleMap(), nIstd);

		UINT16 cbSprms = ret->cb - 2;
		KSprm sprm;
		KEnumSprmList sprmList(pSprms, cbSprms);
		while(S_OK == sprmList.Next(sprm))
		{
			if(sprm.opcode == sprmPIlfo)
			{
				UINT16 ilfo = (UINT16)sprm.GetFixOprand();
				*((UINT16*)(const_cast<UINT8*>(sprm.oprand))) =
					pRdrContext->GetLfo(ilfo, pDwDoc);

				break;
			}
		}

		return ret;
	}

	STDMETHODIMP_(DWType::DWPropx*) GetChpx(
		IN KRdrContext<DWType>* pRdrContext,
		IN DWType* pDwDoc,
		IN KRdrChpItem& chpItem)
	{
		ASSERT(chpItem.IsNeedNotConvert());
		DWType::DWPropx* ret = chpItem.GetPropx(pDwDoc->GetAllocator());
		UINT8* pSprms = (UINT8*)ret + sizeof(UINT);
		UINT16 cbSprms = ret->cb;

		KSprm sprm;
		KEnumSprmList sprmList(pSprms, cbSprms);
		while(S_OK == sprmList.Next(sprm))
		{
#define MAP_PROP(map, type)        \
	*((type*)(const_cast<UINT8*>(sprm.oprand))) = __getmapProp(map, (type)sprm.GetFixOprand())

			switch(sprm.opcode)
			{
			case sprmCRgFtc0:
				MAP_PROP(pRdrContext->GetFontMap(), UINT16);
				break;
			case sprmCRgFtc1:
				MAP_PROP(pRdrContext->GetFontMap(), UINT16);
				break;
			case sprmCRgFtc2:
				MAP_PROP(pRdrContext->GetFontMap(), UINT16);
				break;
			case sprmCIstd:
				MAP_PROP(pRdrContext->GetStyleMap(), UINT16);
				break;
			case sprmCSymbol:
				MAP_PROP(pRdrContext->GetFontMap(), UINT32);
				break;
			default:
				break;
			}

#undef MAP_PROP
		}

		return ret;
	}

	STDMETHODIMP_(DWType::DWPropBuffer*) GetPapBuf(
		IN KRdrContext<DWType>* pRdrContext,
		IN DWType*   pDwDoc,
		IN KRdrPapItem& papItem)
	{
		static RdrPap basePap;
		static RdrTap baseTap;

		if(pRdrContext)
		{
			basePap.Reset();
			mapPapx(pRdrContext, pDwDoc, papItem);
			m_nCurPapIstd = papItem.get_istd();
			pRdrContext->GetStyContext()->GetStyleMergePap(
				papItem.get_istd(),
				basePap);
			mapPapx(pRdrContext, pDwDoc, basePap);
			
			m_propBuf.Clear();
			Pap2Sprms() (basePap, papItem, m_propBuf);

			if(papItem.get_fTtp() || papItem.get_fTtp2())
			{
				baseTap.Reset();
				Pap2SprmsExtend() (basePap, papItem, m_propBuf);
				UINT16 nTistd = m_nCurPapIstd;
				if(papItem.getTap().get_istd() != 0)
					nTistd = papItem.getTap().get_istd();

				pRdrContext->GetStyContext()->GetStyleMergeTap(
					nTistd,
					baseTap);
				Tap2Sprms() (baseTap, papItem.getTap(), m_propBuf);
			}
		}
		else
		{
			m_propBuf.Clear();
		}
		
		return &m_propBuf;
	}

private:
    static KRdrPropProductor* m_Instance;
	DWType::DWPropBuffer m_propBuf;
	UINT16 m_nCurPapIstd;
};

template <class DWType>
KRdrPropProductor<DWType>* KRdrPropProductor<DWType>::m_Instance = NULL;

// -------------------------------------------------------------------------
//	$Log: propproductor.h,v $
//	Revision 1.6  2006/06/09 07:32:05  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.5  2006/06/07 06:39:38  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.4  2006/06/02 01:30:38  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.3  2006/06/02 00:24:46  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/06/01 08:15:08  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/06/01 02:02:50  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __PROPPRODUCTOR_H__ */
