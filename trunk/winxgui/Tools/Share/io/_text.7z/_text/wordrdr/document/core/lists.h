/* -------------------------------------------------------------------------
//	�ļ���		��	lists.h
//	������		��	����
//	����ʱ��	��	2006-3-29 9:50:30
//	��������	��	
//	$Id: lists.h,v 1.5 2006/06/01 08:15:01 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __RDR_LISTS_H__
#define __RDR_LISTS_H__

#ifndef __STL_MAP_H__
#include <stl/map.h>
#endif

#include "property/mapper.h"


// -------------------------------------------------------------------------
template<class DWType>
class KRdrLists
{
	typedef std::map<UINT16, UINT16> LfoMap;
	LfoMap m_lfoMap;

	KRdrCore* m_rdrCore;
	const KDRDocument* m_drDoc;
	KRdrDgContext<DWType>* m_dgContext;

public:
	STDMETHODIMP_(void) Open(
		IN KRdrCore* rdrCore, 
		IN KRdrDgContext<DWType>* dgContext, 
		IN const KDRDocument* drDoc)
	{
		m_rdrCore = rdrCore;
		m_drDoc = drDoc;
		m_dgContext = dgContext;
	}
	STDMETHODIMP_(void) Close()
	{
		m_rdrCore = NULL;
		m_drDoc = NULL;
		m_dgContext = NULL;
		m_lfoMap.clear();
	}

public:
	STDMETHODIMP_(UINT16) GetLfo(
		UINT16 lfo, DWType* dwDoc)
	{
		LfoMap::const_iterator i = m_lfoMap.find(lfo);
		if (i != m_lfoMap.end())
			return i->second;
	

		const KDRListTable& drLists = 
			m_drDoc->GetListTable();
		
		UINT16 newLfo = lfo;
		if(lfo > 0 && lfo <= drLists.Count())
		{
			const KDRList& drList = drLists.Item(lfo);
			if (drList.Good())
				newLfo = NewLfo(drList, dwDoc);
		}

		m_lfoMap.insert(
				std::make_pair(lfo, newLfo)
				);
		return newLfo;
	}

	
private:
	template<class DWType>
	STDMETHODIMP_(UINT16) NewLfo(
		const KDRList& drList, DWType* dwDoc)
	{
		DWType::DWListTable& dwLists = 
			dwDoc->GetListTable();
		DWType::DWList dwList = dwLists.NewList(
			drList.GetLevelCount()
			);


		for(int i = 0; i < drList.GetLevelCount(); ++i)
		{
			UINT iStartAt = drList.GetLevelStartAt(i);
			UINT16 istd   = drList.GetLevelIstd(i);
			const KDRListLevel& lstlvl = drList.GetLevel(i); 

			DWType::DWListLevel& dwLvl = dwList.GetLevel(i);
			dwLvl.SetStartAt(iStartAt);

			dwLvl.SetIxchFollow(lstlvl.GetIxchFollow());
			dwLvl.SetLinkStyle(istd);
			dwLvl.SetLegal(lstlvl.GetLegal());
			dwLvl.SetNfc(lstlvl.GetNfc());
			dwLvl.SetJc(lstlvl.GetJc());
			dwLvl.SetXst(lstlvl.GetXst(), lstlvl.GetXstLen());
			dwLvl.SetLevelNumbers(lstlvl.GetrgbxchNums());
			dwLvl.SetNoRestart(lstlvl.GetNoRestart());
			dwLvl.SetRestartAfterLevel(lstlvl.GetRestartAfterLevel());

			RdrChp chp;
			const KDRPropx* pDrPropx = lstlvl.GetChpx(m_drDoc);
			Sprms2Chp() ((UINT8*)((UINT16*)pDrPropx + 1), pDrPropx->cb, chp);
			mapChpx(m_rdrCore, chp);

			dwLvl.SetChpx(
				KRdrPropProductor<DWType>::Instance()->GetLstChpBuf(
					m_rdrCore, chp));

			dwLvl.SetPapx(
				KRdrPropProductor<DWType>::Instance()->GetLstPapBuf(
					lstlvl.GetPapx(m_drDoc)));


			if( chp.get_fPicBullet() &&
				chp.get_iPicBullet() != -1
				)
			{
				DWType::DWPicBullet bullet = 
					m_dgContext->NewPicBullet(chp.get_iPicBullet(), dwDoc);
				if (bullet._innerData.Good())
					dwLvl.SetPicBullet(bullet);
			}
		}	
		
		return dwLists.NewListFormatOverride(dwList).GetIndex();
	}

};


// -------------------------------------------------------------------------

#endif /* __LISTS_H__ */

// $Log: lists.h,v $
// Revision 1.5  2006/06/01 08:15:01  zhuyunfeng
// *** empty log message ***
//
// Revision 1.4  2006/06/01 02:02:29  zhuyunfeng
// �޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//
// Revision 1.3  2006/04/06 08:54:19  wangdong
// ������
//
// Revision 1.2  2006/04/05 08:54:40  zhuyunfeng
// *** empty log message ***
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
