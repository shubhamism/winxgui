/* -------------------------------------------------------------------------
//	�ļ���		��	drawing.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-15 17:07:51
//	��������	��	
//
//	$Id: drawing.h,v 1.6 2006/06/01 02:02:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __DRAWING_H__
#define __DRAWING_H__

#ifndef __BREAKITER_H__
#include "document/core/breakiter.h"
#endif

#ifndef __MSO_DOM_TEXT_DRAWING_SHAPECONVERT_H__
#include <mso/dom/text/drawing/shapeconvert.h>
#endif


// -------------------------------------------------------------------------
template<class WRHandl> 
class KRdrDgHandler : public KWRBreakHandler<WRHandl>
{
	typedef WRHandl::DWType DWType;
	DWType* m_dwDoc;

public:
	KRdrDgHandler(IN DWType* dwDoc)
		: m_dwDoc(dwDoc)
	{}
	
public:
	STDMETHODIMP OnBreak(
		IN KWRTextStreamHost<WRHandl>* host,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		ASSERT(chp.get_fSpec());
		if (!chp.get_fSpec())
			return S_FALSE;
				
		KRdrContext<DWType>* rdrContext = host->GetRdrContext();
		KRdrDgContext<DWType>* dgContext = rdrContext->GetDGContext();
		const KDRDocument* drDoc = rdrContext->GetDRDoc();


		const FSPA* fspa = &drDoc->GetShapePositions(docType).Data(br.Index);
		const MsoROShape& drShape = dgContext->FindDRShape(fspa->spid);

		if (drShape.Good())
		{
			//mapChpx(rdrContext, chpx);
			m_dwDoc->NewSpan(
				KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(rdrContext, chp));
			
			DWType::DWShapeAnchor anchor;
			anchor.SetData(
				fspa->xaLeft,
				fspa->yaTop,
				fspa->xaRight,
				fspa->yaBottom,
				(FSPA_XREL)fspa->bx,
				(FSPA_YREL)fspa->by,
				(FSPA_TEXTWRAP)fspa->wr,
				(FSPA_TEXTWRAPTYPE)fspa->wrk,
				fspa->fAnchorLock
				);

			DWType::DWShape dwShape = 
				m_dwDoc->AddShape(anchor, drShape.IsGroupShape());
			
			addShape(
				drShape, dwShape, docType, host
				);
		}

		return S_OK;
	}

	
private:
	STDMETHODIMP_(void) addShape(
		const MsoROShape& drShape, 
		DWType::DWShape& dwShape,
		SUBDOC_TYPE docType,
		KWRTextStreamHost<WRHandl>* host)
	{
		addSingle(drShape, dwShape, docType, host);
		if (drShape.IsGroupShape())
		{
			for (UINT i = 0; i < drShape.GetChildCount(); ++i)
			{
				MsoROShape child = drShape.GetChildShape(i);
				addShape(
					child, dwShape.NewShape(child.IsGroupShape()), 
					docType, host
					);
			}
		}
	}
	STDMETHODIMP_(void) addSingle(
		const MsoROShape& drShape, 
		DWType::DWShape& dwShape, 
		SUBDOC_TYPE docType,
		KWRTextStreamHost<WRHandl>* host)
	{
		KRdrDgContext<DWType>* dgContext = 
			host->GetRdrContext()->GetDGContext();


		MsoShapeConvertBase::SetShape(
			&drShape, &dwShape, 
			dgContext, &m_dwDoc->GetBlipStore()
			);

		if (drShape.HasTextBox())
		{
			const KDRRange* rgTxbx = 
				dgContext->FindDRTxbx(drShape.GetShapeID());
			if (rgTxbx)
			{
				SUBDOC_TYPE txbxType = 
					( (docType == SUBDOC_MAIN) ? SUBDOC_TEXTBOX : SUBDOC_HEADER_TEXTBOX );
				m_dwDoc->EnterTextBox(dwShape);
					host->Write(txbxType, *rgTxbx);
				m_dwDoc->LeaveTextBox();
			}
		}
		dgContext->MapDWShape(drShape.GetShapeID(), dwShape);

	}
};


// -------------------------------------------------------------------------
//	$Log: drawing.h,v $
//	Revision 1.6  2006/06/01 02:02:29  zhuyunfeng
//	�޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//	
//	Revision 1.5  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.2  2006/03/22 09:27:18  zhuyunfeng
//	��wordrdr���̽����ع�
//	
//	Revision 1.1  2006/03/20 07:33:25  zhuyunfeng
//	������Drawing�Ĵ���
//	

#endif /* __DRAWING_H__ */
