/* -------------------------------------------------------------------------
//	�ļ���		��	wordreader_impl.h
//	������		��	����
//	����ʱ��	��	2006-2-22 15:41:56
//	��������	��	
//	$Id: wordreader_impl.h,v 1.2 2006/06/08 02:28:28 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __WORDREADER_IMPL_H__
#define __WORDREADER_IMPL_H__


// -------------------------------------------------------------------------
#ifndef __RDRCONTEXT_H__
#include "rdrcontext.h"
#endif


// -------------------------------------------------------------------------
#include "core/fonts.h"
#include "core/lists.h"
#include "core/stylesheet.h"
#include "core/users.h"
#include "core/dop.h"
#include "core/textstream.h"
#include "bookmark/bookmark.h"



// -------------------------------------------------------------------------
template<class DWType> inline
STDMETHODIMP KWordRdr<DWType>::OpenDocument(
	IN IStorage* pStorage
	)
{
	if (
		pStorage == NULL
		)
	{
		return E_INVALIDARG;
	}

	return m_drDoc.OpenDocument(pStorage);
}

template<class DWType> inline
STDMETHODIMP KWordRdr<DWType>::OpenDocument(
	IN LPCWSTR lpszFileName,
	IN UINT grfMode
	)
{
	ks_stdptr<IStorage> spStorage;
	HRESULT hr = StgOpenStorage(
		lpszFileName, 0, grfMode, NULL, 0, &spStorage);
	ASSERT_OK(hr);
	if (SUCCEEDED(hr))
		hr = OpenDocument(spStorage);

	return hr;
}

template<class DWType> inline
STDMETHODIMP KWordRdr<DWType>::Write(
	IN DWType* dwDoc)
{
	if (
		dwDoc == NULL
		)
	{
		return E_INVALIDARG;
	}
	

	KRdrContext<DWType> rdrContext;
	rdrContext.Open(
		&m_drDoc, dwDoc->GetAllocater()
		);

	{
		WriteDop(&m_drDoc, dwDoc);

		KRdrRevUserWriter<DWType> revUserWriter(&rdrContext);
		revUserWriter.Write(dwDoc);

		KRdrAtnUserWriter<DWType> atnUserWriter(&rdrContext);
		atnUserWriter.Write(dwDoc);

		KRdrFontsWriter<DWType> fontsWriter(&rdrContext);
		fontsWriter.Write(dwDoc);

		KRdrStyleSheetWriter<DWType> styleSheetWriter(&rdrContext);
		styleSheetWriter.Write(dwDoc);

		KRdrTextStreamWriter<DWType> streamWriter(rdrContext);
		streamWriter.Write(dwDoc);

		KRdrBkmWriter<DWType> bkmWriter(&rdrContext);
		bkmWriter.Write(dwDoc);
	}

	rdrContext.Close();

	return S_OK;
}

template<class DWType> inline
STDMETHODIMP_(void) KWordRdr<DWType>::Close()
{
	m_drDoc.Close();
}


// -------------------------------------------------------------------------

#endif /* __WORDREADER_IMPL_H__ */

// $Log: wordreader_impl.h,v $
// Revision 1.2  2006/06/08 02:28:28  zhuyunfeng
// *** empty log message ***
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
// Revision 1.6  2006/02/28 08:30:26  wangdong
// ��ʧ��ʱ������ASSERT��
//
// Revision 1.5  2006/02/23 02:50:40  zhuyunfeng
// *** empty log message ***
//
// Revision 1.4  2006/02/22 09:39:04  wangdong
// *** empty log message ***
//
// Revision 1.3  2006/02/22 09:06:34  wangdong
// �������̡�
//
// Revision 1.2  2006/02/22 08:57:56  wangdong
// �������̡�
//
// Revision 1.1  2006/02/22 08:32:17  wangdong
// ���̽������е�һ�����԰�����
//
