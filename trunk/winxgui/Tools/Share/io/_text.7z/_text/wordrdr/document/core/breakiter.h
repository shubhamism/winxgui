/* -------------------------------------------------------------------------
//	�ļ���		��	breakiter.h
//	������		��	����
//	����ʱ��	��	2006-2-24 14:09:02
//	��������	��	
//	$Id: breakiter.h,v 1.18 2006/06/01 02:02:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __BREAKITER_H__
#define __BREAKITER_H__

#ifndef __STL_LIST_H__
#include "stl/list.h"
#endif


// -------------------------------------------------------------------------
enum WRBreakType
{
	BreakType_Annotation,		// 0x05
	BreakType_Drawing,			// 0x08
	BreakType_Picture,			// 0x01
	BreakType_FieldBegin,		// 0x13
	BreakType_FieldSep,			// 0x14
	BreakType_FieldEnd,			// 0x15
	BreakType_Footnote,			// 0x02
	BreakType_Endnote,			// 0x02
	BreakType_NoteRef,			// 0x02
	BreakType_Max,
};

struct WRBreak
{
	WRBreakType Type;
	CP			Cp;
	UINT		Index;

	bool operator <(const WRBreak& rhs) const
	{
		return Cp < rhs.Cp;
	}
};



// -------------------------------------------------------------------------
template<class WRHandl>
class KWRTextStreamHost;

template<class WRHandl>
struct _HandlContext;

struct RdrChp;


template<class WRHandl>
struct KWRBreakHandler
{
	STDPROC OnBreak(
		IN KWRTextStreamHost<WRHandl>* host,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp
		) PURE;

	virtual ~KWRBreakHandler() PURE;
};

template<class DWType> inline
KWRBreakHandler<DWType>::~KWRBreakHandler() { }



// -------------------------------------------------------------------------

class KWRBreakIter
{
public:
	STDMETHODIMP_(BOOL) Next()
	{
		if (m_Cursor != m_BreakList.end())
		{
			++m_Cursor;
			return TRUE;
		}
		return FALSE;
	}
	STDMETHODIMP_(void) LowerBound(IN CP Cp)
	{
		WRBreak br;
		br.Cp = Cp;
		m_Cursor = std::lower_bound(
			m_BreakList.begin(), 
			m_BreakList.end(), br
			);
	}
	STDMETHODIMP_(BOOL) Eof()
	{
		return m_Cursor == m_BreakList.end();
	}

public:
	STDMETHODIMP_(CP) Tell()
	{
		return m_Cursor->Cp;
	}
	STDMETHODIMP_(WRBreakType) Type()
	{
		return m_Cursor->Type;
	}
	STDMETHODIMP_(UINT) Index()
	{
		return m_Cursor->Index;
	}
	STDMETHODIMP_(const WRBreak&) Value()
	{
		return *m_Cursor;
	}

public:
	STDMETHODIMP_(void) Init(
		IN const KDRDocument* DrDocument, 
		IN SUBDOC_TYPE docType)
	{
		if (DrDocument->GetTextPool(docType).size() > 0)
		{
			collectAnnotation(
				DrDocument, m_BreakList, docType
				);
			collectFootnote(
				DrDocument, m_BreakList, docType
				);
			collectEndnote(
				DrDocument, m_BreakList, docType
				);
			collectField(
				DrDocument, m_BreakList, docType
				);
			collectDrawing(
				DrDocument, m_BreakList, docType);
			
			m_BreakList.sort();
		}
		m_Cursor = m_BreakList.end();
	}


private:
	typedef std::list<WRBreak> BreakListType;

	BreakListType m_BreakList;
	BreakListType::const_iterator m_Cursor;


private:
	STDMETHODIMP_(void) collectAnnotation(
		IN const KDRDocument* DrDocument, 
		IN BreakListType& breakList,
		IN SUBDOC_TYPE docType);
	STDMETHODIMP_(void) collectFootnote(
		IN const KDRDocument* DrDocument, 
		IN BreakListType& breakList,
		IN SUBDOC_TYPE docType);
	STDMETHODIMP_(void) collectEndnote(
		IN const KDRDocument* DrDocument, 
		IN BreakListType& breakList,
		IN SUBDOC_TYPE docType);
	STDMETHODIMP_(void) collectField(
		IN const KDRDocument* DrDocument, 
		IN BreakListType& breakList,
		IN SUBDOC_TYPE docType);
	STDMETHODIMP_(void) collectDrawing(
		IN const KDRDocument* DrDocument,
		IN BreakListType& breakList,
		IN SUBDOC_TYPE docType);
};


// -------------------------------------------------------------------------
inline
STDMETHODIMP_(void) KWRBreakIter::collectFootnote(
	IN const KDRDocument* DrDocument, 
	IN BreakListType& breakList, 
	IN SUBDOC_TYPE docType)
{
	if(docType != SUBDOC_MAIN)
		return;

	const KDRFootnotePositions& ftnPos = 
		DrDocument->GetFootnotes().GetPositions();
    UINT nCount = ftnPos.Count();

	for(int i = 0; i < nCount; ++i)
	{
		WRBreak br;
		br.Cp = ftnPos.Range(i).cp;
		br.Index = i;
		br.Type = BreakType_Footnote;
		breakList.push_back(br);
	}
}

inline
STDMETHODIMP_(void) KWRBreakIter::collectEndnote( 
	IN const KDRDocument* DrDocument, 
	IN BreakListType& breakList, 
	IN SUBDOC_TYPE docType)
{
	if(docType != SUBDOC_MAIN)
		return ;
	const KDREndnotePositions& ednPos =
		DrDocument->GetEndnotes().GetPositions();
	UINT nCount = ednPos.Count();

	for(int i = 0; i < nCount; ++i)
	{
		WRBreak br;
		br.Cp = ednPos.Range(i).cp;
		br.Index = i;
		br.Type = BreakType_Endnote;
		breakList.push_back(br);
	}
}

inline
STDMETHODIMP_(void) KWRBreakIter::collectAnnotation(
	IN const KDRDocument* DrDocument, 
	IN BreakListType& breakList, 
	IN SUBDOC_TYPE docType)
{
	if (docType != SUBDOC_MAIN)
		return;

	const KDRAtnRefs& AtnRefs =
		DrDocument->GetAnnotations().GetRefs();
	
	UINT cAtn = AtnRefs.Count();
	for (UINT i = 0; i < cAtn; ++i)
	{
		WRBreak br;
		br.Cp = AtnRefs.Item(i).cpBreak;
		br.Type = BreakType_Annotation;
		br.Index = i;

		m_BreakList.push_back(br);
	}
	
}

inline
STDMETHODIMP_(void) KWRBreakIter::collectField(
	IN const KDRDocument* DrDocument, 
	IN BreakListType& breakList,
	IN SUBDOC_TYPE docType)
{
	const KDRFields& Fields =
		DrDocument->GetFields(docType);
	UINT nFields = Fields.Count();

	for(UINT i = 0; i < nFields; ++i)
	{
		WRBreak br;
		br.Cp = Fields.GetCP(i);
		switch(Fields.Item(i).GetMarkType())
		{
		case 0x13:
			br.Type = BreakType_FieldBegin;
			break;
		case 0x14:
			br.Type = BreakType_FieldSep;
			break;
		case 0x15:
			br.Type = BreakType_FieldEnd;
			break;
		default:
			br.Type = BreakType_Max;
			break;
		}
		br.Index = i;
		m_BreakList.push_back(br);
	}
}

inline
STDMETHODIMP_(void) KWRBreakIter::collectDrawing(
	IN const KDRDocument* DrDocument, 
	IN BreakListType& breakList, 
	IN SUBDOC_TYPE docType)
{
	if(docType == SUBDOC_MAIN
		|| docType == SUBDOC_HEADERFOOTER)
	{
		const KDRShpPos& shpPos = DrDocument->GetShapePositions(docType);
		for(int i = 0; i < shpPos.Count(); ++i)
		{
			WRBreak br;
			br.Cp = shpPos.Range(i).cp;
			br.Type = BreakType_Drawing;
			br.Index = i;
			m_BreakList.push_back(br);
		}
	}
}


// -------------------------------------------------------------------------

#endif /* __BREAKITER_H__ */

// $Log: breakiter.h,v $
// Revision 1.18  2006/06/01 02:02:29  zhuyunfeng
// �޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//
// Revision 1.17  2006/04/05 06:40:21  wangdong
// ���Symbol��
//
// Revision 1.16  2006/04/05 05:56:06  wangdong
// �����˽�ע��
//
// Revision 1.15  2006/04/05 03:13:40  wangdong
// �����˽�עβע���ռ���
//
// Revision 1.14  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
// Revision 1.12  2006/03/24 06:39:34  zhuyunfeng
// �����ע
//
// Revision 1.11  2006/03/22 09:28:32  zhuyunfeng
// ��wordrdr���̽����ع�
//
// Revision 1.10  2006/03/20 07:35:35  zhuyunfeng
// ����OnBreak�ӿڣ�����_HandlContext��
//
// Revision 1.9  2006/03/15 08:45:53  zhuyunfeng
// ���ӶԶ���Ĵ���
//
// Revision 1.8  2006/03/06 09:40:52  zhuyunfeng
//  �滻�漰��KDWDocument�е����ͣ�����д�������֧��
//
// Revision 1.7  2006/03/01 02:15:30  zhuyunfeng
// ΪOnBreak����һ�����ĵ����͵Ĳ���
//
// Revision 1.6  2006/02/28 07:11:55  wangdong
// ʵ����ע��δʵ���û���
//
// Revision 1.5  2006/02/28 05:33:28  wangdong
// �����ṹ��
//
// Revision 1.4  2006/02/28 03:32:54  wangdong
// ��sort��
//
// Revision 1.3  2006/02/28 03:29:50  wangdong
// ���������������
//
// Revision 1.2  2006/02/28 01:22:19  wangdong
// δ��ɡ�
//
// Revision 1.1  2006/02/24 08:51:11  wangdong
// ��һ����⣬δ��ɡ�
//
