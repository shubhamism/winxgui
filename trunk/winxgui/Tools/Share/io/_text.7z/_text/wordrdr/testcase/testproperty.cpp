/* -------------------------------------------------------------------------
//	�ļ���		��	testproperty.cpp
//	������		��	����
//	����ʱ��	��	2006-3-27 17:22:14
//	��������	��	
//	$Id: testproperty.cpp,v 1.1 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#include "testcommon.h"
#include <document/core/property/chpx.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class TestProperty : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestProperty);
		CPPUNIT_TEST(testChpx);
	CPPUNIT_TEST_SUITE_END();

	void testChpx()
	{
		KDWDocumentType docu;
		docu.NewDocument(testOutputPath("wordrdr_core_chpx.doc"));

		KWordRdr<KDWDocumentType> wordRdr;
		wordRdr.OpenDocument(testSrcPath("core/chpx.doc"));
		wordRdr.Write(&docu);
		wordRdr.Close();

		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestProperty);


// -------------------------------------------------------------------------
//	$Log: testproperty.cpp,v $
//	Revision 1.1  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
