/* -------------------------------------------------------------------------
//	�ļ���		��	wordrdr.cpp
//	������		��	����
//	����ʱ��	��	2006-2-22 11:47:11
//	��������	��	
//	$Id: wordrdr.cpp,v 1.5 2006/05/29 07:28:53 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#include <document/wordreader.h>
#include <dwtype.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// -------------------------------------------------------------------------
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

KComModule _Module;


// -------------------------------------------------------------------------
EXPORTAPI wordrdr_ReadFile(
	IN LPCWSTR File, IN DWORD grfMode, IN KDWDocument* pDocument)
{
	KWordRdr<KDWDocumentType> rdr;
	HRESULT hr = rdr.OpenDocument(File, grfMode);
	KS_CHECK(hr);

	hr = rdr.Write((KDWDocumentType*)pDocument);
	rdr.Close();
	KS_CHECK(hr);

KS_EXIT:
	return hr; 
}

EXPORTAPI wordrdr_ReadStorage(
	IN IStorage* pStorage, OUT KDWDocument* pDocument)
{
	KWordRdr<KDWDocumentType> rdr;
	HRESULT hr = rdr.OpenDocument(pStorage);
	KS_CHECK(hr);

	hr = rdr.Write((KDWDocumentType*)pDocument);
	rdr.Close();
	KS_CHECK(hr);

KS_EXIT:
	return hr; 
}

// -------------------------------------------------------------------------
//	$Log: wordrdr.cpp,v $
//	Revision 1.5  2006/05/29 07:28:53  wangdong
//	*** empty log message ***
//	
//	Revision 1.4  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.3  2006/03/22 09:26:39  zhuyunfeng
//	��wordrdr���̽����ع�
//	
//	Revision 1.2  2006/03/14 06:52:24  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/02/22 08:32:17  wangdong
//	���̽������е�һ�����԰�����
//	
