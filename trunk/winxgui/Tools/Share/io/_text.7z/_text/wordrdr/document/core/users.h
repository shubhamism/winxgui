/* -------------------------------------------------------------------------
//	�ļ���		��	users.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-24 15:44:30
//	��������	��	
//
//	$Id: users.h,v 1.1 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __USERS_H__
#define __USERS_H__


// -------------------------------------------------------------------------
template<class DWType>
class KRdrAtnUserWriter
{
	KRdrContext<DWType>* m_rdrContext;
public:
	KRdrAtnUserWriter(IN KRdrContext<DWType>* rdrContext)
	{
		m_rdrContext = rdrContext;
	}
	
public:
	STDMETHODIMP Write(DWType* dwDoc)
	{
		const KDRUsers& drUsers =
			m_rdrContext->GetDRDoc()->GetAnnotations().GetUsers();

		KDRUsers::const_iterator i = drUsers.begin();
		for (; i != drUsers.end(); ++i)
		{
			DWType::DWUsers& dwUsers = 
				dwDoc->GetAnnotationUsers();

			UINT usrid;
			dwUsers.Add(
				i->szUserName, i->szUserNameAbbr, &usrid);
		
			m_rdrContext->GetAtnUserMap().insert(
				std::make_pair(i - drUsers.begin(), usrid));
		}
		return S_OK;
	}
};


// -------------------------------------------------------------------------
template<class DWType>
class KRdrRevUserWriter
{
	KRdrContext<DWType>* m_rdrContext;
public:
	KRdrRevUserWriter(IN KRdrContext<DWType>* rdrContext)
	{
		m_rdrContext = rdrContext;
	}
	
public:
	STDMETHODIMP Write(DWType* pDwDocument)
	{
		const KDRSttbfRMark& sttbfrMark = 
			m_rdrContext->GetDRDoc()->GetSttbfRMark();

		for(int i = 0; i < sttbfrMark.Count(); ++i)
		{
			UINT usrid;
			pDwDocument->GetRevisionUsers().Add(
				sttbfrMark.Item(i).pStrBuf,
				__X("Unknown"),
				&usrid);

			m_rdrContext->GetAtnUserMap().insert(
				std::make_pair(i, usrid));
		}

		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: users.h,v $
//	Revision 1.1  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.1  2006/03/24 07:35:59  zhuyunfeng
//	д���û��޶��б�
//	

#endif /* __REVISIONUSRHANDL_H__ */
