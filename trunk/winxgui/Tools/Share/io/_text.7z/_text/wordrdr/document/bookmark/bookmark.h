/* -------------------------------------------------------------------------
//	�ļ���		��	bookmark.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-28 17:52:17
//	��������	��	
//
//	$Id: bookmark.h,v 1.3 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __BOOKMARK_H__
#define __BOOKMARK_H__

// -------------------------------------------------------------------------

template <class DWType>
class KRdrBkmWriter
{
	KRdrContext<DWType>* m_drContext;
public:
	KRdrBkmWriter(IN KRdrContext<DWType>* drContext)
	: m_drContext(drContext)
	{
	}

public:
	STDMETHODIMP Write(DWType* dwDoc)
	{
		const KDRBookMarks& drBkms = m_drContext->GetDRDoc()->GetBookMarks();
		DWType::DWBookmarks& dwBkms = dwDoc->GetBookmarks();


		const SUBDOC_TYPE curDocType = dwDoc->GetCurSubdocType();

		for(UINT  i = 0; i < SUBDOC_MAX; ++i)
		{
			const KDRPlcfBkf& bkf = drBkms.GetStarts((SUBDOC_TYPE)i);
		    const KDRPlcfBkl& bkl = drBkms.GetEnds((SUBDOC_TYPE)i);
			if(bkf.Count() > 0)
				dwDoc->SwitchSubdoc((SUBDOC_TYPE)i);

			for(int j = 0; j < bkf.Count(); ++j)
			{
				ASSERT(bkf.Item(j).range.cp
					<= bkl.Item(j).range.cp);

				if(bkf.Item(j).range.cp
					<= bkl.Item(j).range.cp)
				{
					HRESULT hr = dwBkms.NewBookmark(
							bkf.Item(j).pStrBuf,
							bkf.Item(j).range.cp,
							bkl.Item(j).range.cp);
				    VERIFY_OK(hr);
				}		
			}	
		}
		dwDoc->SwitchSubdoc(curDocType);

		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: bookmark.h,v $
//	Revision 1.3  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.2  2006/03/29 03:13:45  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/03/28 10:01:08  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __BOOKMARK_H__ */
