/* -------------------------------------------------------------------------
//	�ļ���		��	chpx.h
//	������		��	����
//	����ʱ��	��	2006-3-27 15:54:41
//	��������	��	
//	$Id: chpx.h,v 1.6 2006/05/19 02:55:30 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __CORE_PROPERTY_CHPX_H__
#define __CORE_PROPERTY_CHPX_H__

#ifndef __CORE_PROPERTY_DATA_H__
#include "data.h"
#endif


// -------------------------------------------------------------------------
class __RdrChpxData : public __RdrPropxData
{
public:
	STDMETHODIMP_(BOOL) isData() const
	{
		if (!Good()) 
			return FALSE;
		return m_fData;
	}
	STDMETHODIMP_(BOOL) isSpec() const
	{
		if (!Good()) 
			return FALSE;
		return m_fSpec;
	}
	STDMETHODIMP_(BOOL) isOle2() const
	{
		if (!Good()) 
			return FALSE;
		return m_fOle2;
	}
	STDMETHODIMP_(BOOL) isPicBullet() const
	{
		if (!Good()) 
			return FALSE;
		return m_fPicBullet;
	}
	
public:
	STDMETHODIMP_(UINT16*) getIstd() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)m_Istd;
	}
	STDMETHODIMP_(UINT16*) getPicBulletIndex() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)m_PicBulletIndex;
	}
	STDMETHODIMP_(const UINT32*) getPicLocation() const
	{
		if (!Good()) 
			return NULL;
		return (UINT32*)&m_PicLocation;
	}
	STDMETHODIMP_(UINT16*) getFtc0() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)m_Ftc0;
	}
	STDMETHODIMP_(UINT16*) getFtc1() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)m_Ftc1;
	}
	STDMETHODIMP_(UINT16*) getFtc2() const
	{
		if (!Good()) 
			return NULL;
		return (UINT16*)m_Ftc2;
	}
	STDMETHODIMP_(UINT32*) getSymbol() const
	{
		if (!Good())
			return NULL;
		return (UINT32*)m_Symbol;
	}

	__forceinline
	STDMETHODIMP_(void) AppendSpecSprm()
	{
		UINT8* curr = 
			(UINT8*)_AutoFreePdata(m_propx) + m_size;

		if(isSpec() && ((m_size + 3) < m_propx->cb))
		{
			_rdr_AddPropFix(curr, sprmCFSpec, 0x1);
			m_size += 3;
		}
	    
		if(getPicLocation() && ((m_size + 6) < m_propx->cb))
		{
			_rdr_AddPropFix(curr, sprmCPicLocation, *(getPicLocation()));
			m_size += 6;
		}
		
		if(isOle2() && ((m_size + 3) < m_propx->cb))
		{
			_rdr_AddPropFix(curr, sprmCFOle2, 0x1);
			m_size += 3;
		}
	}

private:
	BOOL m_fData;
	BOOL m_fSpec;
	BOOL m_fOle2;
	BOOL m_fPicBullet;
	UINT32 m_PicLocation;

private:
	UINT8* m_Istd;
	UINT8* m_PicBulletIndex;
	UINT8* m_Ftc0;
	UINT8* m_Ftc1;
	UINT8* m_Ftc2;
	UINT8* m_Symbol;


protected:
	__RdrChpxData()
	{
		ZeroMemory(this, sizeof(__RdrChpxData));
		__RdrPropxData::Reset();
	}
	
	__forceinline
	STDMETHODIMP_(void) Read(
		const UINT8* begin, const UINT8* end)
	{
		if (begin == end)
			return;

		UINT8* curr = 
			(UINT8*)_MsoPdata(m_propx) + m_size;

		KSprm sprm;
		KEnumSprmList sprmList(begin, end - begin);
		while(sprmList.Next(sprm) == S_OK)
		{
			switch(sprm.opcode)
			{
			case sprmCFSpec:
				m_fSpec = sprm.GetFixOprand();
				_rdr_SkipSprm();
				break;
			case sprmCFOle2:
				m_fOle2 = sprm.GetFixOprand();
				_rdr_SkipSprm();
				break;
			case sprmCPicLocation:
				m_PicLocation = sprm.GetFixOprand();
				_rdr_SkipSprm();
				break;
            case sprmCFData:
				m_fData = sprm.GetFixOprand();
				_rdr_SkipSprm();
				break;

			case sprmCFPicBullet:
				m_fPicBullet = sprm.GetFixOprand();
				break;
				
			case sprmCRgFtc0:
				m_Ftc0 = _rdr_OprBegin(curr);
				break;
			case sprmCRgFtc1:
				m_Ftc1 = _rdr_OprBegin(curr);
				break;
			case sprmCRgFtc2:
				m_Ftc2 = _rdr_OprBegin(curr);
				break;
			case sprmCPicBulletIndex:
				m_PicBulletIndex = _rdr_OprBegin(curr);
				break;
			case sprmCIstd:
				m_Istd = _rdr_OprBegin(curr);
				break;
			case sprmCSymbol:
				m_Symbol = _rdr_OprBegin(curr);
				break;
			case 0:
				_rdr_SkipSprm();
				break;
			}

			if (sprm.IsFixSprm())
				_rdr_AddPropFix(curr, sprm.opcode, sprm.GetFixOprand());
			else
				_rdr_AddPropVar(curr, sprm.opcode, sprm.GetOprand(), sprm.oplen);
		}

		m_size = curr - (UINT8*)_MsoPdata(m_propx);
		ASSERT(m_size <= m_propx->cb);
	}

};


class KRdrChpx : public __RdrChpxData
{
public:
	KRdrChpx() {}; //temp
	KRdrChpx(const KDRMergePropx* propx, MsoAutoFreeAlloc* alloc)
	{
		ReadPropx(propx->pPropx, propx->cbPropx, 
			propx->pFastSavePropx, propx->cbFastSavePropx, alloc);
	}
	KRdrChpx(const KDRPropx* propx, MsoAutoFreeAlloc* alloc) 
	{
		ReadPropx(
			_DRPropxPdata(propx), propx->cb, NULL, 0, alloc);
	}

private:
	__forceinline
	STDMETHODIMP_(void) ReadPropx(
		const void* propx, size_t cb, 
		const void* extra, size_t cbExtra,
		MsoAutoFreeAlloc* alloc)
	{
		m_propx = _AutoFreeAllocKernData(alloc, cb + cbExtra);
		m_propx->cb = cb + cbExtra;
		
		Read((const UINT8*)propx, (const UINT8*)propx + cb); 
		Read((const UINT8*)extra, (const UINT8*)extra + cbExtra); 
	}
};



// -------------------------------------------------------------------------

#endif /* __CORE_PROPERTY_CHPX_H__ */

// $Log: chpx.h,v $
// Revision 1.6  2006/05/19 02:55:30  zhuyunfeng
// *** empty log message ***
//
// Revision 1.5  2006/04/06 08:37:50  zhuyunfeng
// *** empty log message ***
//
// Revision 1.4  2006/04/06 03:22:45  wangdong
// *** empty log message ***
//
// Revision 1.3  2006/04/05 08:18:57  wangdong
// ����0 sprm����ȡsprmPSprmExtend
//
// Revision 1.2  2006/04/05 06:40:21  wangdong
// ���Symbol��
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
