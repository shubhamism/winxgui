/* -------------------------------------------------------------------------
//	�ļ���		��	dgcontext.h
//	������		��	����
//	����ʱ��	��	2006-3-31 15:46:57
//	��������	��	
//	$Id: dgcontext.h,v 1.3 2006/06/01 02:02:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __DGCONTEXT_H__
#define __DGCONTEXT_H__


// -------------------------------------------------------------------------
template<class DWType>
class KRdrDgContext
{
	const MsoROBlipStore* m_drBlipStore;
	KDRWordDocumentStrm* m_docStrm;
	const KDRDocument* m_drDoc;
	KDRRange m_rgPicBullets;

public:
	STDMETHODIMP_(const MsoROShape&) FindDRShape(IN MSOSPID spid) const
	{
		RdrShapeMap::const_iterator i = m_drAnchorShapeMap.find(spid);
		if (i != m_drAnchorShapeMap.end())
			return i->second;
		static MsoROShape nullsp;
		return nullsp;
	}
	STDMETHODIMP_(const KDRRange*) FindDRTxbx(INT32 lid) const
	{
		RdrTxbxMap::const_iterator i = m_txbxMap.find(lid);
		if (i != m_txbxMap.end())
			return &i->second;
		return NULL;
	}

public:
	STDMETHODIMP_(void) MapDWShape(
		MSOSPID drspid, DWType::DWShape& shape)
	{
		ASSERT(m_dwShapeMap.find(drspid) == m_dwShapeMap.end());
		m_dwShapeMap[drspid] = shape;
	}

public:
	STDMETHODIMP_(void) Link(MSOSPID spid, MSOSPID spidNext)
	{
		ASSERT(m_txbxLinkMap.find(spid) == m_txbxLinkMap.end());
		m_txbxLinkMap[spid] = spidNext;
	}
	STDMETHODIMP_(DWType::DWBlip) NewBlip(
		UINT pib, DWType::DWBlipStore* blipStore)
	{
		const MsoROBlip& drBlip = 
			 m_drBlipStore->GetBlipWithDelayStrm(pib - 1, m_docStrm);
		DWType::DWBlip blip = blipStore->NewBlip(drBlip);
		blip.__AssignRef(0);

 		return blip;
	}

public:
	STDMETHODIMP_(DWType::DWPicBullet) NewPicBullet(
		UINT iPicBullet, DWType* dwDoc)
	{
		CHECK_BOOL(iPicBullet < (m_rgPicBullets.cpNext - m_rgPicBullets.cp));
		{
			RdrPicBulletMap::const_iterator i = m_picBulletMap.find(iPicBullet);
			if (i != m_picBulletMap.end())
				return i->second;

			
			const KDRPlcfChp& plcfChp = 
				m_drDoc->GetPlcfChp(SUBDOC_MAIN);

			CP cp0x01 = m_rgPicBullets.cp + iPicBullet;
			
			UINT iChp = plcfChp.LowerBound(cp0x01);
			if (iChp < plcfChp.Count())
			{
				MsoAutoFreeAlloc alloc;
				RdrChp chp;
				KDRMergePropx propx = plcfChp.Data(iChp);
				Sprms2Chp() ((const UINT8*)propx.pPropx, propx.cbPropx, chp);
				
				//KRdrChpx chpx(&plcfChp.Data(iChp), &alloc);
				CHECK_BOOL(chp.get_picLocation() != -1);

				KDREmbedShapes& shapes = m_drDoc->GetEmptyEmbedShapes();
				KDREmbedShape embshp = 
					shapes.Read(
					m_drDoc, chp.get_picLocation(), cp0x01);
				ASSERT(embshp.Good());
				if (embshp.Good())
				{
					const KDRBseTable* bseTable = embshp.m_bseTable;
					if (bseTable->Count())
					{
						DWType::DWBlip blip = MsoShapeConvertBase::GetEmbShpBlip(
								bseTable,
								bseTable->Count() - 1,
								&dwDoc->GetBlipStore()
								);

						if(blip.Good())
						{
							DWType::DWPicBullet bullet = 
								dwDoc->GetPicBullets().NewPicBullet(blip);
							m_picBulletMap.insert(std::make_pair(iPicBullet, bullet));

							return bullet;
						}
					}
				}
			}
		}

	KS_EXIT:
		return DWType::DWPicBullet();
	}


public:
	STDMETHODIMP_(VOID) Open(
		IN const KDRDocument* drDoc, IN KDRRange rgPicBullets)
	{
		m_drDoc = drDoc;
		m_rgPicBullets = rgPicBullets;

		for (UINT i = 0; i < 2; ++i)
			ScanDRShapes(drDoc->GetDrawing(i));
		
		ScanDRTxbxs(drDoc->GetTxbxTxt());
		ScanDRTxbxs(drDoc->GetHdrTxbxTxt());

		m_drBlipStore = &drDoc->GetDrawingGroup().GetBlipStore();
		m_docStrm = &drDoc->GetDocFile().getWordDocumentStrm();
	}

	STDMETHODIMP_(VOID) Close()
	{
		MakeLink();
		m_drAnchorShapeMap.clear();
		m_txbxLinkMap.clear();
		m_dwShapeMap.clear();
		m_txbxMap.clear();
		m_picBulletMap.clear();
	}


private:
	typedef std::map<MSOSPID, MsoROShape> RdrShapeMap;
	RdrShapeMap m_drAnchorShapeMap;

	typedef std::map<MSOSPID, DWType::DWShape> RdrDWShapeMap;
	RdrDWShapeMap m_dwShapeMap;

	typedef std::map<MSOSPID, MSOSPID> RdrTxbxLinkMap;
	RdrTxbxLinkMap m_txbxLinkMap;

	typedef std::map<UINT32, KDRRange> RdrTxbxMap;
	RdrTxbxMap m_txbxMap;

	typedef std::map<UINT32, DWType::DWPicBullet> RdrPicBulletMap;
	RdrPicBulletMap m_picBulletMap;
	

private:
	STDMETHODIMP_(void) MakeLink()
	{
		RdrTxbxLinkMap::const_iterator i = m_txbxLinkMap.begin();
		for (; i != m_txbxLinkMap.end(); ++i)
		{
			KDWShape& shape = m_dwShapeMap[i->first];
			KDWShape& shapeNext = m_dwShapeMap[i->second];
			if (shape.Good() && shapeNext.Good())
				shape.SetNextShape(shapeNext);
		}
	}
	STDMETHODIMP_(void) ScanDRShapes(
		IN const KDRDrawing& drawing)
	{
		if (drawing.Good())
		{
			const MsoROShape& root = drawing.GetRootShape();
			if (root.Good())
			{
				for (UINT j = 0; j < root.GetChildCount(); ++j)
				{
					const MsoROShape& shape = root.GetChildShape(j);
					m_drAnchorShapeMap.insert(
						std::make_pair(shape.GetShapeID(), shape) 
						);
				}
			}
		}
	}
	template<class PlfcTxbxs>
	STDMETHODIMP_(void) ScanDRTxbxs(IN const PlfcTxbxs& txbxs)
	{
		for (UINT i = 0; i < txbxs.Count(); ++i)
		{
			if (txbxs.Data(i).lid != 0)
			{
				KDWRange range = txbxs.Range(i);
				--range.cpNext;
				ASSERT(range.cp < range.cpNext);
				m_txbxMap.insert(
					std::make_pair(txbxs.Data(i).lid, range) 
					);
			}
		}
	}
};


// -------------------------------------------------------------------------

#endif /* __DGCONTEXT_H__ */

// $Log: dgcontext.h,v $
// Revision 1.3  2006/06/01 02:02:29  zhuyunfeng
// �޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//
// Revision 1.2  2006/05/17 01:28:58  wangdong
// *** empty log message ***
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
