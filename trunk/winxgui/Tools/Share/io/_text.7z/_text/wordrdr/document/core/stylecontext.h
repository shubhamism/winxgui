/* -------------------------------------------------------------------------
//	�ļ���		��	stylecontext.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-05-15 10:02:21
//	��������	��	
//
//	$Id: stylecontext.h,v 1.8 2006/06/08 02:28:08 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __STYLECONTEXT_H__
#define __STYLECONTEXT_H__

#ifndef __STYLEMGRBASE_H__
#include <mso/dom/text/stylemgr/stylemgrbase.h>
#endif

//------------------------------------------------------------------------
// KRdrStyleContext

class KRdrStyleContext : public KStyleMgrBase
{
	const KDRDocument* m_drDoc;
public:
	STDMETHODIMP_(void) Open(IN const KDRDocument* drDoc)
	{
		KStyleMgrBase::Open(drDoc->GetAllocator());
		m_drDoc = drDoc;
	}
	STDMETHODIMP_(BOOL) HasStyleChp(IN const UINT istd)
	{
		const KDRStyle* pDrSty = NULL;
		if(istd != stiNil)
			m_drDoc->GetStyleSheet().GetStyle(istd, &pDrSty);
		return (pDrSty != NULL) && (pDrSty->GetChpx() != NULL);
	}
	STDMETHODIMP_(BOOL) HasStyleTap(IN const UINT istd)
	{
		const KDRStyle* pDrSty = NULL;
		if(istd != stiNil)
			m_drDoc->GetStyleSheet().GetStyle(istd, &pDrSty);
		return (pDrSty != NULL) && (pDrSty->GetTextTablePropx() != NULL);
	}
	STDMETHODIMP_(BOOL) HasStylePap(IN const UINT istd)
	{
		const KDRStyle* pDrSty = NULL;
		if(istd != stiNil)
			m_drDoc->GetStyleSheet().GetStyle(istd, &pDrSty);
		return (pDrSty != NULL) && (pDrSty->GetPapx() != NULL);
	}

private:
	virtual STDMETHODIMP DoGetStylePap(IN const UINT16 nIstd, RdrPap& pap) const
	{
		const KDRStyle* pDrSty = NULL;	
		if(S_OK == m_drDoc->GetStyleSheet().GetStyle(nIstd, &pDrSty))
		{
			const KDRPropx* pPropx = pDrSty->GetPapx();
			if(pPropx)
			{
				Sprms2Pap() (
					(UINT8*)pPropx + 2 * sizeof(UINT16),
					pPropx->cb - sizeof(UINT16),
					pap);
				pap.put_istd(nIstd);
			}

			return S_OK;
		}
		else
		{
			return S_FALSE;
		}
	}
	virtual STDMETHODIMP DoGetStyleChp(IN const UINT16 nIstd, RdrChp& chp) const
	{
		const KDRStyle* pDrSty = NULL;
		if(S_OK == m_drDoc->GetStyleSheet().GetStyle(nIstd, &pDrSty))
		{
			const KDRPropx* pPropx = pDrSty->GetChpx();
			
			if(pPropx)
			{
				Sprms2Chp() (
					(UINT8*)pPropx + sizeof(UINT16),
					pPropx->cb,
					chp);
			}
			
			return S_OK;
		}
		else
		{
			return S_FALSE;
		}

	}
	virtual STDMETHODIMP DoGetStyleTap(IN const UINT16 nIstd, RdrTap& tap) const
	{
		const KDRStyle* pDrSty = NULL;
		if(S_OK == m_drDoc->GetStyleSheet().GetStyle(nIstd, &pDrSty))
		{
			const KDRPropx* pPropx = pDrSty->GetTextTablePropx();
			
			if(pPropx)
			{
				Sprms2Tap() (
					(UINT8*)pPropx + sizeof(UINT16),
					pPropx->cb,
					tap);
			}
		
			return S_OK;
		}
		else
		{
			return S_FALSE;
		}
	}
	virtual STDMETHODIMP_(UINT16) DoGetBaseIstd(IN const UINT16 nIstd) const
	{
		const KDRStyle* pDrSty = NULL;
		if(S_OK == m_drDoc->GetStyleSheet().GetStyle(nIstd, &pDrSty))
			return pDrSty->GetBaseStyle();
		else
			return stiNil;
	}
};





// -------------------------------------------------------------------------
//	$Log: stylecontext.h,v $
//	Revision 1.8  2006/06/08 02:28:08  zhuyunfeng
//	Ϊ��ʽ���ṩ�˻������
//	
//	Revision 1.7  2006/06/06 01:23:19  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.6  2006/05/31 06:11:05  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.5  2006/05/30 00:58:09  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.4  2006/05/26 05:31:19  zhuyunfeng
//	��ɱ���ת��
//	
//	Revision 1.3  2006/05/25 02:52:17  zhuyunfeng
//	������ɱ�����ʽ�Ĵ���������ϸ����
//	
//	Revision 1.2  2006/05/19 02:55:11  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/05/15 09:05:58  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __STYLECONTEXT_H__ */
