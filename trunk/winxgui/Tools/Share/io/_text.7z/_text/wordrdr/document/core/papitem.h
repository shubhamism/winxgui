/* -------------------------------------------------------------------------
//	�ļ���		��	papitem.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-05-15 15:18:08
//	��������	��	
//
//	$Id: papitem.h,v 1.6 2006/05/31 07:47:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __PAPITEM_H__
#define __PAPITEM_H__

#ifndef __PROPCONVERT_H__
#include <mso/dom/text/property/propconvert.h>
#endif

using namespace PROP_CONVERT;

// -------------------------------------------------------------------------

template <class DWType>
class KRdrPapItem
{
	KDRRange m_range;
	KRdrContext<DWType>& m_rdrContext;
	RdrPap m_pap;
	RdrTap* m_pTap;
public:
	KRdrPapItem(const KDRRange& rg, 
		const KDRMergePropx* propx, 
		KRdrContext<DWType>& rdrContext)
		: m_range(rg), m_rdrContext(rdrContext), m_pTap(NULL)
	{
		Init(propx);
	}
	~KRdrPapItem()
	{
		delete m_pTap;
	}

public:
	inline
	STDMETHODIMP_(const KDRRange&) getRange() const
	{
		return m_range;
	}
	inline
	STDMETHODIMP_(RdrPap&) getPap() 
	{
		return m_pap;	
	}
	inline
	STDMETHODIMP_(const RdrPap&) getPap() const
	{
		return m_pap;
	}
	inline
	STDMETHODIMP_(RdrTap&) getTap()
	{
		ASSERT(m_pTap != NULL);
		return *m_pTap;
	}
	inline
	STDMETHODIMP_(const RdrTap&) getTap() const
	{
		if(m_pTap)
			return *m_pTap;
		return GetEmptyTap();
	}

private:
	STDMETHODIMP_(void) Init(const KDRMergePropx* propx)
	{
		const UINT8* pPropx = (const UINT8*)propx->pPropx;
		const UINT8* pFastSavePropx = (const UINT8*)propx->pFastSavePropx;
		size_t cbPropx = propx->cbPropx;
		size_t cbFastSavePropx = propx->cbFastSavePropx;

		if(pPropx == NULL || cbPropx == 0)
			return;

		UINT nIstd = TokenVal(pPropx, UINT16);
		cbPropx -= sizeof(UINT16);
		
		m_rdrContext.GetStyContext()->GetStyleMergePap(nIstd, m_pap);
	
		FC fcHuge = -1;
		FC fcExt  = -1;
		KSprm sprmHuge;
		KDRDataStrmRef dataStrm = m_rdrContext.GetDRDoc()->GetDocFile().getDataStrm();

		if(IsHuge(pPropx, cbPropx, sprmHuge))
		{
			fcHuge = *(FC*)sprmHuge.oprand;
			dataStrm.seek(fcHuge);
			
			size_t cbHuge = 0;
			dataStrm.read(&cbHuge, 2);

			//
			// @@note:
			//	��sprmPHugeTapx���ǻ��ٴγ���sprmPSprmExtend��
			//
			if (
				cbHuge && 
				sprmHuge.opcode == sprmPHugeTapx
				)
			{
				enum { oplen = 2 };
				enum { cbSprmExt = oplen + sizeof(FC) };

				UINT8* dataHuge = (UINT8*)_alloca(cbSprmExt);
				dataStrm.read(dataHuge, cbSprmExt);
				if (*(UINT16*)dataHuge == sprmPSprmExtend)
				{
					fcExt = *(FC*)(dataHuge + oplen);
					dataStrm.seek(fcExt);

					size_t cbExt = 0;
					dataStrm.read(&cbExt, 2);

					ReadAtFC(fcExt, dataStrm, m_rdrContext.GetAlloc()->Alloc(cbExt));
				}
			}

			ReadAtFC(fcHuge, dataStrm, m_rdrContext.GetAlloc()->Alloc(cbHuge));
		}

		if(pFastSavePropx)
			Read(pFastSavePropx, cbFastSavePropx);

		Read(pPropx, cbPropx);
	}

	__forceinline
	STDMETHODIMP_(BOOL) IsHuge(
		const void* propx, size_t cb, KSprm& sprm) const
	{
		KEnumSprmList sprmList((const UINT8*)propx, cb);
		sprmList.Next(sprm);
		
		return (sprm.opcode == sprmPHugePapx ||
				sprm.opcode == sprmPHugeTapx ||
				sprm.opcode == sprmPSprmExtend
				);
	}

	STDMETHODIMP_(void) ReadAtFC(
		FC fc, 
		KDRDataStrmRef dataStrm,
		void* pSprms)
	{
		dataStrm.seek(fc);
		size_t cb = 0;
		dataStrm.read(&cb, 2);
		if (cb)
		{
			dataStrm.read(pSprms, cb);
			Read((const UINT8*)pSprms, cb);
		}
	}
	STDMETHODIMP_(void) Read(
		const UINT8* pSprms,
		size_t cbSprms)
	{
		if(pSprms == NULL || cbSprms == 0)
		{
			return;
		}
		Sprms2Pap() (pSprms, cbSprms, m_pap);
		if(m_pap.get_fTtp() || m_pap.get_fTtp2())
		{
			if(!m_pTap)
				m_pTap = new RdrTap();
			Sprms2Tap() (pSprms, cbSprms, *m_pTap);
		}
	}

};

// -------------------------------------------------------------------------
//	$Log: papitem.h,v $
//	Revision 1.6  2006/05/31 07:47:29  zhuyunfeng
//	ʹ��Chp֮ǰ���޸�
//	
//	Revision 1.5  2006/05/30 00:58:09  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.4  2006/05/26 05:31:19  zhuyunfeng
//	��ɱ���ת��
//	
//	Revision 1.3  2006/05/23 09:08:45  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/05/16 07:12:53  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/05/15 09:05:58  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __PAPITEM_H__ */
