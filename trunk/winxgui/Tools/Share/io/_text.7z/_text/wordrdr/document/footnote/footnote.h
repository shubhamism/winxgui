/* -------------------------------------------------------------------------
//	�ļ���		��	ftnetn.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-27 17:37:04
//	��������	��	
//
//	$Id: footnote.h,v 1.3 2006/06/01 02:02:29 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __FTNETN_H__
#define __FTNETN_H__

#ifndef __BREAKITER_H__
#include "document/core/breakiter.h"
#endif


// -------------------------------------------------------------------------
struct footnoteMarker
{
	typedef KDRFootnotePositions notePos;
	typedef KDRFootnoteTextRanges noteRanges;
	enum { docType = SUBDOC_FOOTNOTE };

	static
	STDMETHODIMP_(const notePos&) GetPos(const KDRDocument* drDoc)
	{
		return drDoc->GetFootnotes().GetPositions();
	}
	static
	STDMETHODIMP_(const noteRanges&) GetRanges(const KDRDocument* drDoc)
	{
		return drDoc->GetFootnotes().GetTextRanges();
	}

	template<class DWType> static
	STDMETHODIMP Enter(DWType* dwDoc, BOOL fCustom)
	{
		return dwDoc->EnterFootnotes(fCustom);
	}
	template<class DWType> static
	STDMETHODIMP Leave(DWType* dwDoc)
	{
		return dwDoc->LeaveFootnotes();
	}
};


// -------------------------------------------------------------------------
struct endnoteMarker
{
	typedef KDREndnotePositions notePos;
	typedef KDREndnoteTextRanges noteRanges;
	enum { docType = SUBDOC_ENDNOTE };

	static
	STDMETHODIMP_(const notePos&) GetPos(const KDRDocument* drDoc)
	{
		return drDoc->GetEndnotes().GetPositions();
	}
	static
	STDMETHODIMP_(const noteRanges&) GetRanges(const KDRDocument* drDoc)
	{
		return drDoc->GetEndnotes().GetTextRanges();
	}

	template<class DWType> static
	STDMETHODIMP Enter(DWType* dwDoc, BOOL fCustom)
	{
		return dwDoc->EnterEndnotes(fCustom);
	}
	template<class DWType> static
	STDMETHODIMP Leave(DWType* dwDoc)
	{
		return dwDoc->LeaveEndnotes();
	}
};



// -------------------------------------------------------------------------
template<class WRHandl, class noteMaker>
class KRdrNoteHandler : public KWRBreakHandler<WRHandl>
{
	typedef WRHandl::DWType DWType;
	DWType* m_dwDoc;
	
public:
	KRdrNoteHandler(IN DWType* dwDoc)
		: m_dwDoc(dwDoc)
	{}

public:
	STDMETHODIMP OnBreak(
		IN KWRTextStreamHost<WRHandl>* host,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		const KDRDocument* drDoc = 
			host->GetRdrContext()->GetDRDoc();

		const noteMaker::notePos& pos = 
			noteMaker::GetPos(drDoc);
		const noteMaker::noteRanges& ranges = 
			noteMaker::GetRanges(drDoc);


		//mapChpx(host->GetRdrContext(), chpx);
		//m_dwDoc->NewSpan(chpx.Detach());
		m_dwDoc->NewSpan(
			KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(
				host->GetRdrContext(), chp));

		BOOL fCustom = (pos.Data(br.Index) == 0);
		noteMaker::Enter(m_dwDoc, fCustom);
			
			host->Write(
				(SUBDOC_TYPE)noteMaker::docType, 
				ranges.Range(br.Index)
				);

		noteMaker::Leave(m_dwDoc);


		return S_OK;
	}
};


// -------------------------------------------------------------------------
template<class WRHandl>
struct KRdrFootnoteHandler : 
			KRdrNoteHandler<WRHandl, footnoteMarker>
{
	typedef KRdrNoteHandler<WRHandl, footnoteMarker> BaseType;
	KRdrFootnoteHandler(IN DWType* dwDoc) 
		: BaseType(dwDoc)
	{}
	
};

template<class WRHandl>
struct KRdrEndnoteHandler : 
			KRdrNoteHandler<WRHandl, endnoteMarker>
{
	typedef KRdrNoteHandler<WRHandl, endnoteMarker> BaseType;
	KRdrEndnoteHandler(IN DWType* dwDoc) 
		: BaseType(dwDoc)
	{}
};


// -------------------------------------------------------------------------
template<class WRHandl>
class KRdrNoteRefHandler : public KWRBreakHandler<WRHandl>
{
	typedef WRHandl::DWType DWType;
	DWType* m_dwDoc;
	
public:
	KRdrNoteRefHandler(IN DWType* dwDoc)
		: m_dwDoc(dwDoc)
	{}

public:
	STDMETHODIMP OnBreak(
		IN KWRTextStreamHost<WRHandl>* host,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		m_dwDoc->NewSpan(
			KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(
				host->GetRdrContext(), chp));
		m_dwDoc->AddFndEndRef();

		return S_OK;
	}
};


// -------------------------------------------------------------------------
//	$Log: footnote.h,v $
//	Revision 1.3  2006/06/01 02:02:29  zhuyunfeng
//	�޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//	
//	Revision 1.2  2006/04/05 05:56:06  wangdong
//	�����˽�ע��
//	
//	Revision 1.1  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	


#endif /* __FTNETN_H__ */
