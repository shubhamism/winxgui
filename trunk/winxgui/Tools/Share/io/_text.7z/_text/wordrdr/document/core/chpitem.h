/* -------------------------------------------------------------------------
//	�ļ���		��	chpitem.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-05-19 11:00:43
//	��������	��	
//
//	$Id: chpitem.h,v 1.5 2006/06/02 00:24:46 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __CHPITEM_H__
#define __CHPITEM_H__

#ifndef __PROPCONVERT_H__
#include <mso/dom/text/property/propconvert.h>
#endif

using namespace PROP_CONVERT;

// -------------------------------------------------------------------------
class KRdrChpx;
template <class DWType>
class KRdrChpItem
{
	KDRRange m_range;
	KRdrContext<DWType>& m_rdrContext;
	RdrChp m_chp;

public:
	KRdrChpItem(const KDRRange& rg, 
		const KDRMergePropx* propx, 
		KRdrContext<DWType>& rdrContext,
		UINT16 papIstd)
		: m_range(rg), m_rdrContext(rdrContext)
	{
		Init(propx, papIstd);
	}
public:
	inline
	STDMETHODIMP_(const KDRRange&) getRange() const
	{
		return m_range;
	}
	inline
	STDMETHODIMP_(RdrChp&) getChp() 
	{
		return m_chp;	
	}
	inline
	STDMETHODIMP_(const RdrChp&) getChp() const
	{
		return m_chp;
	}
private:
	STDMETHODIMP_(void) Init(const KDRMergePropx* propx, UINT16 papIstd)
	{
		const UINT8* pPropx = (const UINT8*)propx->pPropx;
		const UINT8* pFastSavePropx = (const UINT8*)propx->pFastSavePropx;
		size_t cbPropx = propx->cbPropx;
		size_t cbFastSavePropx = propx->cbFastSavePropx;
		
		UINT16 nIstd = 10; //Ĭ��Ϊ10
		FindCIstd(pPropx, cbPropx, nIstd);
		if(nIstd == 10)
			nIstd = papIstd;

		m_rdrContext.GetStyContext()->GetStyleMergeChp(nIstd, m_chp);

		if(pPropx == NULL || cbPropx == 0)
			return;

		Sprms2Chp() (pPropx, cbPropx, m_chp);
	}
};

// -------------------------------------------------------------------------
//	$Log: chpitem.h,v $
//	Revision 1.5  2006/06/02 00:24:46  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.4  2006/06/01 02:02:29  zhuyunfeng
//	�޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//	
//	Revision 1.3  2006/05/31 07:47:29  zhuyunfeng
//	ʹ��Chp֮ǰ���޸�
//	
//	Revision 1.2  2006/05/30 00:58:09  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/05/19 02:55:11  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __CHPITEM_H__ */
