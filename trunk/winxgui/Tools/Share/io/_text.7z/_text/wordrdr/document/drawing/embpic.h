/* -------------------------------------------------------------------------
//	�ļ���		��	embpic.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-22 16:47:52
//	��������	��	
//
//	$Id: embpic.h,v 1.3 2006/06/02 00:24:46 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __EMBPIC_H__
#define __EMBPIC_H__

#ifndef __BREAKITER_H__
#include "document/core/breakiter.h"
#endif

#ifndef __MSO_DOM_TEXT_DRAWING_SHAPECONVERT_H__
#include <mso/dom/text/drawing/shapeconvert.h>
#endif



// -------------------------------------------------------------------------
template<class WRHandl> 
class KRdrEmbPicHandler : public KWRBreakHandler<WRHandl>
{	
	typedef WRHandl::DWType DWType;
	DWType* m_dwDoc;

public:
	KRdrEmbPicHandler(IN DWType* dwDoc)
		: m_dwDoc(dwDoc)
	{
	}

public:
	STDMETHODIMP OnBreak(
		IN KWRTextStreamHost<WRHandl>* host,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		KDRRange rgPicBullet = 
			host->GetRdrContext()->GetBkmContext()->GetPicBulletsRange();
		if (
			br.Cp >= rgPicBullet.cp && br.Cp < rgPicBullet.cpNext
			)
		{
			return S_FALSE;
		}


		//mapChpx(host->GetRdrContext(), chpx);
		m_dwDoc->NewSpan(
			KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(
				host->GetRdrContext(), chp)
			);
		
		const KDRDocument* drDoc = host->GetRdrContext()->GetDRDoc();
		KDREmbedShapes& shapes = 
			drDoc->GetEmptyEmbedShapes();

		const KDREmbedShape embshp = 
			shapes.Read(
				drDoc,
				chp.get_picLocation(),
				br.Cp);

		//ASSERT(embshp.Good());
		if(embshp.Good())
		{
			const KDRPICF* picf = embshp.m_picf;
			DWType::DWShape dwShape = 
				m_dwDoc->AddInlinePicture(
					picf->dxaGoal * picf->mx / 1000, 
					picf->dyaGoal * picf->my / 1000);
			DWType::DWBlipStore& blipStore = m_dwDoc->GetBlipStore();
			MsoShapeConvert::Convert(&embshp, &dwShape, &blipStore);	
		}
		else
		{
			m_dwDoc->AddInlinePicture(0, 0);
		}

		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: embpic.h,v $
//	Revision 1.3  2006/06/02 00:24:46  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/06/01 02:02:29  zhuyunfeng
//	�޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//	
//	Revision 1.1  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.3  2006/03/30 02:49:30  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/03/24 07:38:06  zhuyunfeng
//	�޸�bug
//	
//	Revision 1.1  2006/03/22 09:27:11  zhuyunfeng
//	��wordrdr���̽����ع�
//	

#endif /* __EMBPIC_H__ */
