/* -------------------------------------------------------------------------
//	�ļ���		��	metadata.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-03-23 11:08:35
//	��������	��	
//
//	$Id: metadata.h,v 1.7 2006/03/31 03:08:09 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __METADATA_H__
#define __METADATA_H__

#ifndef __KSO_IO_V6_FILTERSTD_FILTER_H__
#include "kso/io/v6/filterstd/filter.h"
#endif

#ifndef __KSO_SUMMARY_SUMMARY_STGWRITE_TOOL_H__
#include "kso/summary/summary_stgwrite_tool.h"
#endif

// -------------------------------------------------------------------------
// KWRMetaDataHandler

class KWRMetaDataHandler
{
public:
	KWRMetaDataHandler(IN const KDRDocSource* pDrDocument)
		: m_pDrDocument(pDrDocument)
	{}

public:
	template <class DWDocument>
	STDMETHODIMP WriteMeta(DWDocument* pDwDocument)
	{
		HRESULT hr = E_FAIL;
		if(!m_pDrDocument->GetMetaData().Good())
			return S_FALSE;

		{
			IPropertySetStorage* pPropSetStg = 
			pDwDocument->GetPropertySetStorage();

			if (pPropSetStg && !m_spCustomPropStg)
			{
				hr = pPropSetStg->Open(
						FMTID_SummaryInformation,
						STGM_READWRITE|STGM_SHARE_EXCLUSIVE,
						&m_spCustomPropStg);
				
				if (STG_E_FILENOTFOUND == hr)
					hr = pPropSetStg->Create(
							FMTID_SummaryInformation,
							NULL,
							PROPSETFLAG_DEFAULT,
							STGM_CREATE|STGM_READWRITE|STGM_SHARE_EXCLUSIVE,
							&m_spCustomPropStg);
				KS_CHECK(hr);

				WriteMetaData();
			}
		}
			
KS_EXIT:
		return hr;
	}

private:

	typedef HRESULT (__stdcall KDRMetaData::*GetStrFunc)(BSTR __RPC_FAR *);
	typedef HRESULT (__stdcall KDRMetaData::*GetDateFunc)(DATE __RPC_FAR *);
	typedef HRESULT (__stdcall KDRMetaData::*GetLongFunc)(long __RPC_FAR *);
	
	inline STDMETHODIMP WriteMetaItemStr(
		IN const PROPID propid, 
		IN KDRMetaData& metaData,
		IN GetStrFunc func)
	{
		BSTR szMetaItem;
		HRESULT hr = (metaData.*func)(&szMetaItem);

		if(S_OK == hr)
		{
			hr = WriteProp(propid, szMetaItem);
			if(szMetaItem)
				SysFreeString(szMetaItem);
		}
		return hr;
 	}

	inline STDMETHODIMP WriteMetaItemDate(
		IN const PROPID propid,
		IN KDRMetaData& metaData,
		IN GetDateFunc func)
	{
		DATE date;
		HRESULT hr = (metaData.*func)(&date);

		if(S_OK == hr)
			hr = WriteProp(propid, date);
		return hr;
	}

	inline STDMETHODIMP WriteMetaItemLong(
		IN const PROPID propid,
		IN KDRMetaData& metaData,
		IN GetLongFunc func)
	{
		long data;
		HRESULT hr = (metaData.*func)(&data);

	    if(S_OK == hr)
			hr = WriteProp(propid, data);
		return hr;
	}

	STDMETHODIMP_(void) WriteMetaData()
	{
		KDRMetaData& metaData = 
			(KDRMetaData&)m_pDrDocument->GetMetaData();
		ASSERT(metaData.Good());
		HRESULT hr = E_FAIL;
		#define WRITEBSTR( propid, func )                     \
			hr = WriteMetaItemStr(propid, metaData, func);    \
			VERIFY_OK(hr)

        #define WRITEDATE( propid, func )                     \
		    hr = WriteMetaItemDate(propid, metaData, func);   \
		    VERIFY_OK(hr)
        
		#define WRITELONG( propid, func )                     \
		    hr = WriteMetaItemLong(propid, metaData, func);   \
		    VERIFY_OK(hr)

		WRITEBSTR(PIDSI_SUBJECT, metaData.GetSubject);
		WRITEBSTR(PIDSI_TITLE, metaData.GetTitle);
		WRITEBSTR(PIDSI_AUTHOR, metaData.GetAuthor);
		WRITEBSTR(PIDSI_KEYWORDS, metaData.GetKeywords);
		WRITEBSTR(PIDSI_COMMENTS, metaData.GetComments); 
		WRITEBSTR(PIDSI_TEMPLATE, metaData.GetTemplate);
		WRITEBSTR(PIDSI_LASTAUTHOR, metaData.GetLastAuthor);
		WRITEBSTR(PIDSI_REVNUMBER, metaData.GetRevisionNumber);
		WRITEBSTR(PIDSI_THUMBNAIL, metaData.GetThumbNail);
		WRITEBSTR(PIDSI_APPNAME, metaData.GetApplicationName);

		WRITEDATE(PIDSI_EDITTIME, metaData.GetEditTime);
		WRITEDATE(PIDSI_LASTPRINTED, metaData.GetLastPrinted);
		WRITEDATE(PIDSI_CREATE_DTM, metaData.GetCreateTime);
		WRITEDATE(PIDSI_LASTSAVE_DTM, metaData.GetLastSaveTime);

		WRITELONG(PIDSI_PAGECOUNT, metaData.GetPageCount);
		WRITELONG(PIDSI_WORDCOUNT, metaData.GetWordCount);
		WRITELONG(PIDSI_CHARCOUNT, metaData.GetCharCount);
		WRITELONG(PIDSI_DOC_SECURITY, metaData.GetSecurity);
	}

	template<class T>
	STDMETHODIMP WriteProp(PROPID propid, T Value)
	{
		if (m_spCustomPropStg)
			return WritePropVariant(m_spCustomPropStg, propid, Value);
		return E_FAIL;
	}

private:
	const KDRDocSource* m_pDrDocument;
	ks_stdptr<IPropertyStorage> m_spCustomPropStg;

};

// -------------------------------------------------------------------------
//	$Log: metadata.h,v $
//	Revision 1.7  2006/03/31 03:08:09  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.6  2006/03/30 06:55:19  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.5  2006/03/28 10:01:22  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.4  2006/03/28 08:59:39  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.3  2006/03/28 07:39:03  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/03/24 07:36:33  zhuyunfeng
//	�޸Ľӿ�
//	
//	Revision 1.1  2006/03/23 07:17:54  zhuyunfeng
//	���Ԫ����д��
//	

#endif /* __METADATA_H__ */
