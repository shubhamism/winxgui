/* -------------------------------------------------------------------------
//	�ļ���		��	field.h
//	������		��	���Ʒ�
//	����ʱ��	��	2006-02-28 17:12:15
//	��������	��	
//
//	$Id: field.h,v 1.9 2006/06/02 00:24:46 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __FIELD_H__
#define __FIELD_H__

#ifndef __BREAKITER_H__
#include "document/core/breakiter.h"
#endif

#ifndef __STL_STACK_H__
#include <stl/stack.h>
#endif


// -----------------------------------------------------------------------
template <class WRHandl>
class KRdrFieldHandler : public KWRBreakHandler<WRHandl>
{
	typedef WRHandl::DWType DWType;
	DWType* m_dwDoc;

public:
	KRdrFieldHandler(IN DWType* dwDoc) 
		: m_dwDoc(dwDoc)
	{
	}

public:
	STDMETHODIMP OnBreak(
		IN KWRTextStreamHost<WRHandl>* host,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		switch(br.Type)
		{
		case BreakType_FieldBegin:
			WriteFieldBegin(
				host->GetRdrContext(), docType, br, chp
				);
			break;
		case BreakType_FieldSep:
			WriteFieldSep(
				host->GetRdrContext(), docType, br, chp
				);
			break;
		case BreakType_FieldEnd:
			WriteFieldEnd(
				host->GetRdrContext(), docType, br, chp
				);
			break;
		}

		return S_OK;
	}

private:
	STDMETHODIMP WriteFieldBegin(
		IN KRdrContext<DWType>* rdrContext,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		const KDRFields& fields = 
			rdrContext->GetDRDoc()->GetFields(docType);

		FLT flt = (FLT)fields.Item(br.Index).GetFieldType();
		if(flt == mso_fltNone)
			return S_FALSE;

		rdrContext->GetFldContext()->pushFlt(flt);

		//mapChpx(rdrContext, chpx);
		m_dwDoc->NewSpan(
			KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(
				rdrContext, chp));
		m_dwDoc->MarkFieldBegin(flt, FALSE);

		return S_OK;
	}

	STDMETHODIMP WriteFieldSep(
		IN KRdrContext<DWType>* rdrContext,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		if (rdrContext->GetFldContext()->topFlt() == mso_fltNone)
			return S_FALSE;
		
		
		MsoKernData* propxExtra = NULL;
		
		FLT flt = rdrContext->GetFldContext()->topFlt();
		if ( (flt == mso_fltEmbedObject || flt == mso_fltLink) 
			&& chp.get_fOle2() && chp.get_picLocation() != -1
			)
		{
			IStorage* objPool = 
				rdrContext->GetDRDoc()->GetDocFile().getObjectPool();
			ASSERT(objPool);

			if (objPool)
			{
				WCHAR szSubStgName[32];
				szSubStgName[0] = '_';
				_ultow(chp.get_picLocation(), szSubStgName+1, 10);

				ks_stdptr<IStorage> stgOle;
				objPool->OpenStorage(
						szSubStgName,
						NULL,
						STGM_READ|STGM_SHARE_EXCLUSIVE,
						0,
						0,
						&stgOle);
				m_dwDoc->CloneOleStorage(
					chp.get_picLocation(), stgOle
					);

				DWType::DWPropBuffer propBuf;
				propBuf.ForceAddPropFix(sprmCPicLocation, chp.get_picLocation());

//				RdrChp extraChp;
//				extraChp.put_fSpec(TRUE);
//				extraChp.put_picLocation(chp.get_picLocation());
//				extraChp.put_fOle2(TRUE);
//
//				DWType::DWPropBuffer* pBuf =
//					KRdrPropProductor<DWType>::Instance()->GetNormalChpBuf(
//						rdrContext, extraChp);

				propxExtra = propBuf.GetData(
					m_dwDoc->GetAllocator()
					);
			}
			
		}

		//mapChpx(rdrContext, chpx);
		m_dwDoc->NewSpan(
			KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(
				rdrContext, chp));

		m_dwDoc->MarkFieldSeparator(propxExtra);

		return S_OK;
	}

	STDMETHODIMP WriteFieldEnd(
		IN KRdrContext<DWType>* rdrContext,
		IN SUBDOC_TYPE docType,
		IN const WRBreak& br,
		IN RdrChp& chp)
	{
		if(rdrContext->GetFldContext()->topFlt() == mso_fltNone)
			return S_FALSE;

		const KDRFields& fields = 
			rdrContext->GetDRDoc()->GetFields(docType);
		const KDRField& field = 
			fields.Item(br.Index);

		//mapChpx(rdrContext, chpx);
		m_dwDoc->NewSpan(
			KRdrPropProductor<DWType>::Instance()->GetBreakChpBuf(
				rdrContext, chp));

		m_dwDoc->SetCurrentFieldLock(field.GetFLocked());
		m_dwDoc->MarkFieldEnd();

		rdrContext->GetFldContext()->popFlt();
		return S_OK;
	}
};

// -------------------------------------------------------------------------
//	$Log: field.h,v $
//	Revision 1.9  2006/06/02 00:24:46  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.8  2006/06/01 02:02:29  zhuyunfeng
//	�޸�wordrdr�����Դ������̣��������е����Զ�ʹ�ýṹ���ʾ�������Ĳ���ͨ������������ʱ����
//	
//	Revision 1.7  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.3  2006/03/22 09:27:29  zhuyunfeng
//	��wordrdr���̽����ع�
//	
//	Revision 1.2  2006/03/20 07:34:05  zhuyunfeng
//	�޸����д��
//	
//	Revision 1.1  2006/03/01 02:16:49  zhuyunfeng
//	*** empty log message ***
//	

#endif /* __FIELD_H__ */
