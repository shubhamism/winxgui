/* -------------------------------------------------------------------------
//	�ļ���		��	dwtype.h
//	������		��	����
//	����ʱ��	��	2006-3-10 15:15:33
//	��������	��	
//	$Id: dwtype.h,v 1.8 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __DWTYPE_H__
#define __DWTYPE_H__

#ifndef __MSO_DOM_TEXTV2_H__
#include <mso/dom/textv2.h>
#endif


// -------------------------------------------------------------------------
struct KDWDocumentType : KDWDocument
{
	typedef KDWStyleSheet		DWStyleSheet;
	typedef KDWStyle			DWStyle;
	typedef KDWFont				DWFont;
	typedef KDWFontTable		DWFontTable;
	typedef KDWPropBuffer		DWPropBuffer;
	typedef KDWPropx            DWPropx;
	typedef KDWListTable		DWListTable;
	typedef KDWList				DWList;
	typedef KDWListFormatOverride DWListFormatOverride;
	typedef KDWListLevel		DWListLevel;
	typedef KDWBlip             DWBlip;
	typedef KDWPicBullet        DWPicBullet;
	typedef KDWShapeAnchor      DWShapeAnchor;
	typedef KDWShape            DWShape;
	typedef KDWBlipStore        DWBlipStore;
	typedef KDWUsers            DWUsers;
	typedef KDWDocProperties	DWDocProperties;
	typedef KDWBookmarks		DWBookmarks;
	
	
};


// -------------------------------------------------------------------------


#endif /* __DWTYPE_H__ */
// -------------------------------------------------------------------------
//	$Log: dwtype.h,v $
//	Revision 1.8  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.4  2006/03/24 07:38:36  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.3  2006/03/20 07:31:41  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/03/15 05:54:25  zhuyunfeng
//	�������Ͷ���
//	
//	Revision 1.1  2006/03/10 06:59:05  wangdong
//	����ת�����ˡ�
//	
//	Revision 1.4  2006/03/10 06:51:45  wangdong
//	΢��������
//	
//	Revision 1.3  2006/03/10 01:27:35  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.2  2006/03/06 09:48:44  zhuyunfeng
//	*** empty log message ***
//	
//	Revision 1.1  2006/03/06 09:38:23  zhuyunfeng
//	�����滻KDWDocument���������͵���
//	

