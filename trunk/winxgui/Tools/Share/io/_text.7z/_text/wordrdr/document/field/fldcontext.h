/* -------------------------------------------------------------------------
//	�ļ���		��	fldcontext.h
//	������		��	����
//	����ʱ��	��	2006-4-3 14:31:32
//	��������	��	
//	$Id: fldcontext.h,v 1.1 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __FLDCONTEXT_H__
#define __FLDCONTEXT_H__


// -------------------------------------------------------------------------
template<class DWType>
class KRdrFldContext
{
	std::stack<FLT> m_fltStack;
public:
	STDMETHODIMP_(void) pushFlt(FLT flt)
	{
		m_fltStack.push(flt);
	}
	STDMETHODIMP_(void) popFlt()
	{
		ASSERT(!m_fltStack.empty());
		if (!m_fltStack.empty())
			m_fltStack.pop();
	}
	STDMETHODIMP_(FLT) topFlt() const
	{
		return m_fltStack.top();
	}

public:
	STDMETHODIMP_(void) Open(const KDRDocument* drDoc)
	{
	}
	STDMETHODIMP_(void) Close()
	{
		ASSERT(m_fltStack.empty());
	}
};



// -------------------------------------------------------------------------

#endif /* __FLDCONTEXT_H__ */

// $Log: fldcontext.h,v $
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
