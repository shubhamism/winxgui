/* -------------------------------------------------------------------------
//	�ļ���		��	testtextstream.cpp
//	������		��	����
//	����ʱ��	��	2006-2-22 15:38:02
//	��������	��	
//	$Id: testcomment.cpp,v 1.2 2006/04/05 01:27:44 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class TestComment : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestComment);
		CPPUNIT_TEST(testBasic);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testBasic()
	{
		KDWDocumentType docu;
		docu.NewDocument(testOutputPath("wordrdr_comment_basic.doc"));

		KWordRdr<KDWDocumentType> wordRdr;
		wordRdr.OpenDocument(testSrcPath("comment/basic.doc"));
		wordRdr.Write(&docu);
		wordRdr.Close();

		docu.Close();
	}
};


CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestComment);

// -------------------------------------------------------------------------
//	$Log: testcomment.cpp,v $
//	Revision 1.2  2006/04/05 01:27:44  wangdong
//	WordRdr�ع� ��
//	
//	Revision 1.1  2006/02/28 09:19:33  wangdong
//	���°�����
//	
