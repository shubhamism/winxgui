/* -------------------------------------------------------------------------
//	�ļ���		��	textstream.h
//	������		��	����
//	����ʱ��	��	2006-2-22 14:59:36
//	��������	��	
//	$Id: textstream.h,v 1.30 2006/06/07 06:40:20 zhuyunfeng Exp $
// -----------------------------------------------------------------------*/
#ifndef __TEXTSTREAM_H__
#define __TEXTSTREAM_H__

#ifndef __STREAMHOST_H__
#include "streamhost.h"
#endif

#ifndef __STREAMHANDL_H__
#include "streamhandl.h"
#endif


#ifndef __PROPCONVERT_H__
#include <mso/dom/text/property/propconvert.h>
#endif

using namespace PROP_CONVERT;

// -----------------------------------------------------------------------
#include "annotation/annotation.h"
#include "drawing/drawing.h"
#include "drawing/embpic.h"
#include "field/field.h"
#include "footnote/footnote.h"


// -----------------------------------------------------------------------
template<class DWType> 
class KRdrTextStreamWriter
{
	KRdrContext<DWType>& m_rdrContext;

	typedef KWRTextStreamHandl<DWType> HandlType;
	HandlType* m_handl;
	typedef KWRTextStreamHost<HandlType> HostType;
	HostType* m_host;
   	
public:
	KRdrTextStreamWriter(IN KRdrContext<DWType>& rdrContext)
		: m_rdrContext(rdrContext)
	{
		m_host = NULL;
		m_handl = NULL;
	}
	~KRdrTextStreamWriter()
	{
		delete m_host;
		delete m_handl;
	}

public:
	STDMETHODIMP Write(IN DWType* dwDoc)
	{
		if (
			m_host == NULL
			)
		{
		   m_handl = new HandlType;
		   m_host = new HostType(m_rdrContext, m_handl);
		}


		m_handl->Open(&m_rdrContext, dwDoc);
		configHandle(dwDoc, m_handl);

		HRESULT hr = writeMainDoc(dwDoc);
		
		m_handl->Close();  


		return hr;
	}

private:
	STDMETHODIMP writeMainDoc(DWType* dwDoc)
	{
		const KDRDocument* drDoc = m_rdrContext.GetDRDoc();
		const KDRPlcfsed& plcfSed = drDoc->GetPlcfsed();
		
		for (UINT i = 0; i < plcfSed.Count(); ++i)
		{
			const KDRPlcfsed::ItemType item = plcfSed.Item(i, drDoc);
			writeSec(dwDoc, item, i);

			KDRRange range = item.range;
			if (i == plcfSed.Count() - 1)
			{
				CP cpMax = drDoc->GetTextPool(SUBDOC_MAIN).size();
				if (range.cpNext > cpMax)
					range.cpNext = cpMax;
			}

			m_host->Write(
				SUBDOC_MAIN, range
  				);
		} 

		return S_OK;
	}

	STDMETHODIMP_(void) writeSec(
		DWType* dwDoc, const KDRPlcfsed::ItemType& item, UINT iSec)
	{
		const KDRPropx* sepx = item.prop;

		RdrSep sep;
		Sprms2Sep() ((UINT8*)((UINT16*)sepx + 1), sepx->cb, sep);

		DWType::DWPropBuffer propBuf;
		Sep2Sprms() (sep, propBuf);
		dwDoc->NewSection(&propBuf);

		writeHdr(dwDoc, iSec);
	}

	STDMETHODIMP_(void) writeHdr(
		IN DWType* dwDoc,
		IN UINT iSec)
	{
		using KDRPlcfhdd::HeaderFooterType;

		const KDRPlcfhdd& plcfhdd = m_rdrContext.GetDRDoc()->GetPlcfhdd();
		const KDRPlcfChp& plcfChp = m_rdrContext.GetDRDoc()->GetPlcfChp(SUBDOC_HEADERFOOTER);
		INT nChpIndex = 0;
		if (!plcfhdd.IsEmpty())
		{
			for (UINT i = 0; i < KDRPlcfhdd::firstFooter + 1; ++i)
			{
				KDRRange rg = plcfhdd.Item(iSec, (HeaderFooterType)i);
				if(rg.cp == rg.cpNext)
					continue;

				// {{
				// ĳЩ������plcfhdd�ж�����range������ĳ����߽���
				// ��ʱ������������֪��û�и����� zyf
				nChpIndex = plcfChp.UpperBound(rg.cp) - 1;
				if(rg.cp != plcfChp.Range(nChpIndex).cp)
				{
					((KDRPlcfChp&)plcfChp).ModifyCP(nChpIndex, rg.cp);
				}
				// }}

				dwDoc->EnterHeaderFooter((HeaderFooterType)i);           
					--rg.cpNext;
					m_host->Write(SUBDOC_HEADERFOOTER, rg);          
				dwDoc->LeaveHeaderFooter();
			}
		}
	}


private:
	static 
	STDMETHODIMP_(void) configHandle(
		IN DWType* dwDoc, IN HandlType* handl)
	{
		handl->AddHandl(
			BreakType_Annotation, new KRdrAtnHandler<HandlType>(dwDoc)
			);
		handl->AddHandl(
			BreakType_Drawing, new KRdrDgHandler<HandlType>(dwDoc)
			);
 		handl->AddHandl(
 			BreakType_Picture, new KRdrEmbPicHandler<HandlType>(dwDoc)
 			);
		handl->AddHandl(
			BreakType_FieldBegin, new KRdrFieldHandler<HandlType>(dwDoc)
			);
		handl->AddHandl(
			BreakType_FieldSep, new KRdrFieldHandler<HandlType>(dwDoc)
			);
		handl->AddHandl(
			BreakType_FieldEnd, new KRdrFieldHandler<HandlType>(dwDoc)
			);
		handl->AddHandl(
			BreakType_Footnote, new KRdrFootnoteHandler<HandlType>(dwDoc)
			);
		handl->AddHandl(
			BreakType_Endnote, new KRdrEndnoteHandler<HandlType>(dwDoc)
			);
		handl->AddHandl(
			BreakType_NoteRef, new KRdrNoteRefHandler<HandlType>(dwDoc)
			);
	}
};


// -------------------------------------------------------------------------

#endif /* __TEXTSTREAM_H__ */

// $Log: textstream.h,v $
// Revision 1.30  2006/06/07 06:40:20  zhuyunfeng
// *** empty log message ***
//
// Revision 1.29  2006/05/30 06:10:54  zhuyunfeng
// ��ɽڵ�д��
//
// Revision 1.28  2006/05/15 09:05:58  zhuyunfeng
// *** empty log message ***
//
// Revision 1.27  2006/04/11 01:48:58  zhuyunfeng
// *** empty log message ***
//
// Revision 1.26  2006/04/06 03:22:45  wangdong
// *** empty log message ***
//
// Revision 1.25  2006/04/05 06:40:21  wangdong
// ���Symbol��
//
// Revision 1.24  2006/04/05 05:56:06  wangdong
// �����˽�ע��
//
// Revision 1.23  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//
// Revision 1.18  2006/03/24 07:37:26  zhuyunfeng
// ��һЩ���������Ƴ��������Ĵ�������
//
// Revision 1.17  2006/03/23 01:42:33  zhuyunfeng
// �޸��ع������е�BUG
//
// Revision 1.16  2006/03/22 09:28:32  zhuyunfeng
// ��wordrdr���̽����ع�
//
// Revision 1.15  2006/03/20 07:35:35  zhuyunfeng
// ����OnBreak�ӿڣ�����_HandlContext��
//
// Revision 1.14  2006/03/15 05:57:08  zhuyunfeng
// *** empty log message ***
//
// Revision 1.13  2006/03/14 06:54:15  zhuyunfeng
// *** empty log message ***
//
// Revision 1.12  2006/03/10 01:28:16  zhuyunfeng
// *** empty log message ***
//
// Revision 1.11  2006/03/06 01:18:11  zhuyunfeng
// Ϊwrite��������һ��ӳ�������
//
// Revision 1.10  2006/02/28 05:36:19  wangdong
// ����й¶��
//
// Revision 1.9  2006/02/28 05:33:28  wangdong
// �����ṹ��
//
// Revision 1.8  2006/02/28 03:36:11  wangdong
// ������const��
//
// Revision 1.7  2006/02/28 03:29:50  wangdong
// ���������������
//
// Revision 1.6  2006/02/28 01:22:19  wangdong
// δ��ɡ�
//
// Revision 1.5  2006/02/23 06:25:31  zhuyunfeng
// *** empty log message ***
//
// Revision 1.4  2006/02/23 06:11:49  zhuyunfeng
// *** empty log message ***
//
// Revision 1.3  2006/02/23 02:50:04  zhuyunfeng
// ������KDRDocument������KDWDocumentд�����ĵ��Ĳ��԰���
//
// Revision 1.2  2006/02/22 09:39:04  wangdong
// *** empty log message ***
//
// Revision 1.1  2006/02/22 09:04:25  wangdong
// ����λ�á�
//
// Revision 1.2  2006/02/22 08:57:45  wangdong
// ����Ϊ��Ա������
//
// Revision 1.1  2006/02/22 08:32:17  wangdong
// ���̽������е�һ�����԰�����
//
