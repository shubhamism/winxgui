/* -------------------------------------------------------------------------
//	�ļ���		��	data_impl.h
//	������		��	����
//	����ʱ��	��	2006-3-27 15:54:41
//	��������	��	
//	$Id: data.h,v 1.3 2006/04/06 08:54:19 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __CORE_PROPERTY_DATA_H__
#define __CORE_PROPERTY_DATA_H__

#ifndef __DOCFILE_SPRM2TYPE_H__
#include <mso\dom\text\docfile\sprm2type.h>
#endif


// -----------------------------------------------------------------------
__forceinline
STDMETHODIMP_(void) __rdr_BufferAdd(UINT8*& begin, LPCVOID buf, UINT len)
{
	CopyMemory(begin, buf, len);
	begin = begin + len;
}

__forceinline 
STDMETHODIMP_(void) _rdr_AddPropVar(
	UINT8*& begin, UINT16 op, LPCVOID oprand, UINT oplen)
{
	ASSERT(_DW_GetOpLen(op) == -1);

	UINT16 w[2];
	w[0] = op;
	_DW_ByteSwapShort(w[0]);
	switch (op)
	{
	case sprmTDefTable:
	case sprmTDefTable10:
		w[1] = oplen+1;
		_DW_ByteSwapShort(w[1]);
		__rdr_BufferAdd(begin, w, 4);
		break;
		
	case sprmPChgTabs:
		AssertPChgTabs(oprand, oplen);
		if (oplen > 255)
		{
			w[1] = 0xffff;
			__rdr_BufferAdd(begin, w, 3);
			break;
		}
		// else
		// same as normal...
		
	default:
		ASSERT(oplen < 0x100);
		*((UINT8*)w + 2) = (UINT8)oplen;
		__rdr_BufferAdd(begin, w, 3);
	}
	__rdr_BufferAdd(begin, oprand, oplen);
}

__forceinline 
STDMETHODIMP_(void) _rdr_AddPropFix(
	UINT8*& begin, UINT16 op, INT32 oprand)
{
	int oplen = _DW_GetOpLen(op);
	ASSERT(oplen > 0 && oplen <= 4);

	char w[8];
	*(INT16*)(w+0) = op;
	*(INT32*)(w+2) = oprand;
	__rdr_BufferAdd(begin, w, 2+oplen);
}


// -----------------------------------------------------------------------
class __RdrPropxData
{
protected:
	AutoFreeKernData* m_propx; // m_propx->cb => capacity
	size_t m_size;

	STDMETHODIMP_(void) Reset()
	{
		m_propx = _AutoFreeNullKernData();
		m_size = 0;
	}

public:
	template<class PropBuffer>
	STDMETHODIMP_(void) Write(PropBuffer& prop) const
	{
		if (Good())
			prop.AddProps(_MsoPdata(m_propx), m_size);
	}
	__forceinline
	STDMETHODIMP_(AutoFreeKernData*) getData(MsoAutoFreeAlloc* alloc) const
	{
		if (!Good())
			return _AutoFreeNullKernData();
			
		AutoFreeKernData* data = _MsoAllocKernData(alloc, m_propx->cb);
		CopyMemory(_MsoPdata(data), 
			_MsoPdata(m_propx), m_size
			);
		data->cb = m_size;
		return data;
	}
	__forceinline
	STDMETHODIMP_(AutoFreeKernData*) Detach()
	{
		AutoFreeKernData* tmp = m_propx;
		tmp->cb = m_size;
		m_propx = _AutoFreeNullKernData();
		m_size = 0;
		return tmp;
	}

	STDMETHODIMP_(BOOL) Good() const
	{
		return m_propx->cb;
	}
};


// -----------------------------------------------------------------------
#define _rdr_SkipSprm() continue
#define _rdr_OprBegin(p) ((p) + 2)



// -----------------------------------------------------------------------
#endif /* __CORE_PROPERTY_DATA_IMPL_H__ */

// $Log: data.h,v $
// Revision 1.3  2006/04/06 08:54:19  wangdong
// ������
//
// Revision 1.2  2006/04/06 03:22:45  wangdong
// *** empty log message ***
//
// Revision 1.1  2006/04/05 01:27:44  wangdong
// WordRdr�ع� ��
//

