/* -------------------------------------------------------------------------
//	�ļ���		��	testreader.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-26 15:42:22
//	��������	��	
//
//	$Id: testreader.cpp,v 1.5 2005/01/04 01:30:04 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <mso/io/excel/reader.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class DumpWorksheet : public XlsWorksheetBase
{
public:
	STDMETHODIMP put_Dimensions(
		IN const XlsDimensions& dim)
	{
		printf(
			"\ndim: (%d,%d) - (%d,%d)",
			dim.rwMic, dim.colMic, dim.rwMac, dim.colMac);
		return S_OK;
	}
	
	STDMETHODIMP put_Cell(
		IN UINT row,
		IN UINT col,
		IN UINT ixfe,
		IN XlsNumber num)
	{
		printf(
			"\n(%d,%d) = %lf", row, col, num);
		return S_OK;
	}
	
	STDMETHODIMP put_Cell(
		IN UINT row,
		IN UINT col,
		IN UINT ixfe,
		IN const XlsString& str,
		IN const XlsStringRun* runs = NULL,
		IN UINT crun = 0)
	{
		ks_string strA(str.data, str.cch);
		printf(
			"\n(%d,%d) = %s", row, col, strA.c_str());
		return S_OK;
	}

	STDMETHODIMP put_FormulaCell(
		IN UINT row,
		IN UINT col,
		IN const XlsValue& value,
		IN const XlsFormula& formula)
	{
		printf(
			"\n(%d,%d) = formula", row, col);
		return S_OK;
	}

	STDMETHODIMP_(void) dump()
	{
	}
};

template <class Worksheet>
STDMETHODIMP_(void) testWorkbookImpl(
								 IN LPCWSTR szFile,
								 IN Worksheet& worksheet)
{
	USES_CONVERSION;

	WCHAR szExcelFile[_MAX_PATH];

	XlsWorkbook workbook(
		GetSystemIniPath(szExcelFile, szFile) );
	
	UINT nSheetCount = workbook.get_SheetCount();

	XlsBoundSheet sheetinfo;
	workbook.get_SheetInfo(0, &sheetinfo);
	printf("\n------- sheet: %s ---------",  W2A(sheetinfo.name));

	HRESULT hr = workbook.get_Worksheet(0, &worksheet);
	ASSERT_OK(hr);

	workbook.dump();
	worksheet.dump();
}

STDMETHODIMP_(void) testWorkbook(IN LPCWSTR szFile)
{
	DumpWorksheet worksheet;
	testWorkbookImpl(szFile, worksheet);	
}

STDMETHODIMP_(void) testWorkbook2(IN LPCWSTR szFile)
{
	XlsWorksheet worksheet;
	testWorkbookImpl(szFile, worksheet);
}

#define dumpWorkbook(src)													\
	testWorkbook2(															\
		L"../../win32d/testcase/xlsrw/" L##src)

// -------------------------------------------------------------------------

class TestParser : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestParser);
	//	CPPUNIT_TEST(testClipShapeOPT);
	//	CPPUNIT_TEST(testClip1);
		CPPUNIT_TEST(testSampleExcel);
	//	CPPUNIT_TEST(testSampleET);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testClip1()
	{
		dumpWorkbook("clipboard/1.xls");
		dumpWorkbook("clipboard/2.xls");
		dumpWorkbook("clipboard/3.xls");
	}
	void testClipShapeOPT()
	{
		dumpWorkbook("clipboard/shapeopt.xls");
	}
	void testSampleExcel()
	{
		dumpWorkbook("sample/2001TV��ҵ��Ԥ��-2.xls");
	}
	void testSampleET()
	{
		dumpWorkbook("sample/2001TV��ҵ��Ԥ��.xls");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestParser);

// -------------------------------------------------------------------------
//	$Log: testreader.cpp,v $
//	Revision 1.5  2005/01/04 01:30:04  xushiwei
//	*** empty log message ***
//	
//	Revision 1.4  2004/12/30 08:22:58  xushiwei
//	*** empty log message ***
//	
//	Revision 1.3  2004/12/28 01:29:19  xushiwei
//	*** empty log message ***
//	
//	Revision 1.2  2004/12/27 03:56:00  xushiwei
//	1��ɾ��XlsDocument�࣬������XlsWorkbook��ϲ���
//	2������XlsWorkbook�Ĺ��캯��������open��close������
//	
//	Revision 1.1  2004/12/27 02:02:43  xushiwei
//	��ܳ��ɡ�
//	
//	
