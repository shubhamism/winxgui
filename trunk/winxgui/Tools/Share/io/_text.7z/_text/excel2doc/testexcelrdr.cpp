// testdw.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <cppunit/cppunit.h>
#include <kso/linklib.h>
#include <mso/io/excel/reader.h>

int main()
{
	TestApp app;
	_CppUnit_FilterCase(L"testexcelrdr", 0, 0);
	return 0;
}

