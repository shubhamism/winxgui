/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:32:48
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif

#ifndef __MSO_IO_WORD_WRITER_H__
#include <mso/io/word/writer.h>
#endif

__USING_MSO_ESCHER;

// -------------------------------------------------------------------------

inline
STDMETHODIMP CreateDocfile(
						   IN LPCWSTR szFile,
						   OUT IStorage** ppRootStg)
{
	WCHAR szDocFile[_MAX_PATH];
	return StgCreateDocfile(
		GetSystemIniPath(szDocFile, szFile),
		STGM_READWRITE|STGM_SHARE_EXCLUSIVE|STGM_CREATE,
		0,
		ppRootStg);
}

inline
STDMETHODIMP_(KDWBlip) NewBlip(
							   IN KDWDocument& docu,
							   IN LPCWSTR szImgFile,
							   IN MSOBLIPTYPE blipType = msoblipUNKNOWN)
{
	WCHAR szFile[_MAX_PATH];
	return docu.GetBlipStore().NewBlip(
		GetSystemIniPath(szFile, szImgFile), blipType);	
}

inline
STDMETHODIMP_(KDWPicBullet) NewBullet(
							   IN KDWDocument& docu,
							   IN LPCWSTR szImgFile,
							   IN MSOBLIPTYPE blipType = msoblipUNKNOWN)
{
	WCHAR szFile[_MAX_PATH];
	KDWBlip blip = docu.GetBlipStore().NewBlip(
		GetSystemIniPath(szFile, szImgFile),
		blipType);	
	return docu.GetPicBullets().NewPicBullet(blip);
}

// -------------------------------------------------------------------------

#endif /* __TESTCOMMON_H__ */
