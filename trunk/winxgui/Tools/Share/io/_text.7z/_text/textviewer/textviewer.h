
#if !defined(AFX_TEXTVIEWER_H__60F4819F_4E1E_4AD0_BAC2_8E5111615540__INCLUDED_)
#define AFX_TEXTVIEWER_H__60F4819F_4E1E_4AD0_BAC2_8E5111615540__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#define MAX_LOADSTRING 100
// Global Variables:
extern HINSTANCE hInst;								// current instance
extern TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
extern TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text

ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
HWND CreateRichEdit(HWND hParent);
void SetTitle(HWND hWnd, LPSTR buf, LPCSTR title, UINT cp, UINT delta);
#endif // !defined(AFX_TEXTVIEWER_H__60F4819F_4E1E_4AD0_BAC2_8E5111615540__INCLUDED_)
