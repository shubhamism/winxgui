#ifndef __FILLTEXT_H__
#define __FILLTEXT_H__

#include <kso/io/textencoding.h>
 
class TextViewer
{
public:
	explicit TextViewer(KRichEditCtrl& richedit) : streamRichEdit(richedit)
	{		
	}	
	STDMETHODIMP ViewText(LPCWSTR szFile,UINT selCp = KFC_CP_UNKNOWN)
	{		
		UINT cp;
		ks_stdptr<IStream> spOutputStrm;
		_kso_ConvertStream(
			&spOutputStrm,
			szFile,
			NULL,
			selCp,
			KFC_GUESSENCODING_BUFSIZE,
			&cp
			);

		STATDELTA delta = StatEncoding(cp, szFile);
		
		CHAR buf[500];
		USES_CONVERSION;
		SetTitle(GetParent(HWND(streamRichEdit.GetRichEdit())), buf,W2A(szFile),cp, delta);
		
		WCHAR wchHead;
		spOutputStrm->Read(&wchHead, 2, NULL);
		ASSERT(wchHead == 0xfeff);
		LARGE_INTEGER org;
		LISet32(org, 0);
		spOutputStrm->Seek(org, STREAM_SEEK_SET, NULL);

		streamRichEdit.StreamRichEdit(
			spOutputStrm,
			IOStreamRichEdit::INACT,
			SF_UNICODE|SF_TEXT);
		return S_OK;
	}	
private:	
	IOStreamRichEdit streamRichEdit;
};

#endif
