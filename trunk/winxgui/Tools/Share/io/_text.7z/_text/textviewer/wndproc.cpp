#include "stdafx.h"
#include "textviewer.h"
#include "filltext.h"

#define LARGESTFTSIZE 330
#define LARGERFTSIZE 290
#define MEDIUMFTSIZE 250
#define SMALLERFTSIZE 200
#define SMALLESTFTSIZE 180

WNDPROC rich_defproc;
//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT APIENTRY hookProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return CallWindowProc(rich_defproc, hWnd, message,wParam, lParam);
}

/*
void SetTitle(HWND hWnd, LPSTR buf, LPCSTR title, UINT cp)
{
	CPINFOEXA info;
	info.CodePageName[0] = '\0';
	GetCPInfoExA(cp, 0, &info);
	char* pcpgname = strrchr(info.CodePageName,'(');
	USES_CONVERSION;
	if(pcpgname)
	{
		char* pLastSpace = strrchr(pcpgname,' ');
		if(pLastSpace)
			sprintf(buf,"%s - [%s] - (%s","textviewer",title,pLastSpace+1);
		else
			sprintf(buf,"%s - [%s] - %s","textviewer",title,pcpgname);
	}

	else
	{		
		sprintf(buf,"%s - [%s] - (%s)","textviewer",title,"ucs");
	}	
	SetWindowText(hWnd,buf);
}*/

void SetTitle(HWND hWnd, LPSTR buf, LPCSTR title, UINT cp, UINT delta)
{
	CPINFOEXA info;
	info.CodePageName[0] = '\0';
	if (
		GetCPInfoExA(cp, 0, &info) &&
		*info.CodePageName
		)
	{
		sprintf(buf,"CP: %s, ��: %d - [%s]",info.CodePageName, delta, title);
	}
	else
		sprintf(buf,"CP: Unicode - [%s]",title);
	SetWindowText(hWnd,buf);
}

UINT CALLBACK CFHookProc(
							HWND hdlg,      // handle to dialog box
							UINT uiMsg,     // message identifier
							WPARAM wParam,  // message parameter
							LPARAM lParam   // message parameter
							)
{
	return 0;
}


LPSTR GetFileNameFromTitle(LPSTR szCurFile,INT maxSize, HWND hWnd)
{
	GetWindowText(hWnd,szCurFile,maxSize);
	char* pFirst = strchr(szCurFile, '[');
	if(pFirst)
	{
		char* pLast = strchr(szCurFile, ']');
		if(pLast)
		{
			*pLast = '\0';
			return pFirst+1;
		}
	}
	return NULL;
}


void SetCharFormat(KRichEditCtrl& richedit, LONG ftSize = MEDIUMFTSIZE)
{
	CHARFORMAT chfmt;
	ZeroMemory(&chfmt,sizeof(chfmt));
	chfmt.cbSize = sizeof(chfmt);
	chfmt.dwMask = CFM_FACE | CFM_SIZE | CFM_BOLD;
	chfmt.yHeight = ftSize;
//	strcpy(chfmt.szFaceName,"Times New Roman");
	strcpy(chfmt.szFaceName,"����");
	richedit.SetCharFormat(chfmt,SCF_ALL);
}

INT GetCheckStateFromRadiomenu(HMENU hmenu)
{
	for(int i=0; i<GetMenuItemCount(hmenu); ++i)
	{
		UINT state = GetMenuState(hmenu,i,MF_BYPOSITION);
		if(state&MF_CHECKED)
			return i;
	}
	return -1;
}

enum sizeidx
{	
	ilargest,
	ilarger,
	imedium,
	ismaller,
	ismallest,
};

enum cpidx
{
	iauto,
	ibig5 = 2,
	ieuc_kr,
	igb,
	ishiftjs,
	iutf8,
};

void ViewFile(KRichEditCtrl& richedit, LPCSTR szFile, HMENU hpop0, HMENU hpop1)
{		
	INT iCheck0 = GetCheckStateFromRadiomenu(hpop0),
		iCheck1 = GetCheckStateFromRadiomenu(hpop1);	
	LONG ftSize;
	UINT cp;
	switch(iCheck0)
	{
	case imedium:
		ftSize = MEDIUMFTSIZE;
		break;
	case ilargest:
		ftSize = LARGESTFTSIZE;
		break;
	case ilarger:
		ftSize = LARGERFTSIZE;
		break;
	case ismaller:
		ftSize = SMALLERFTSIZE;
		break;
	case ismallest:
		ftSize = SMALLESTFTSIZE;
		break;
	default:
		ftSize = MEDIUMFTSIZE;
		break;
	}	
	TextViewer view(richedit);
	USES_CONVERSION;
	switch(iCheck1)
	{
	case iauto:
		cp = KFC_CP_UNKNOWN;
		break;
	case ibig5:
		cp = KFC_CP_BIG5;
		break;
	case ieuc_kr:
		cp = KFC_CP_EUC_Korea;
		break;
	case igb:
		cp = KFC_CP_GB2312;
		break;
	case ishiftjs:
		cp = KFC_CP_ShiftJIS;
		break;
	case iutf8:
		cp = KFC_CP_UTF8;
		break;
	default:
		cp = KFC_CP_UNKNOWN;
	}
	SetCharFormat(richedit,ftSize);
	view.ViewText(A2W(szFile),cp);
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static KRichEditCtrl richedit;
	static LONG ftSize = MEDIUMFTSIZE;
	static HMENU hmenu, hPopmenu, hPopmenu1;
	static INT idxmax0,idxmax1;
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	HRESULT hr;

	switch (message)
	{
		case WM_CREATE:
			{			
			richedit = CreateRichEdit(hWnd);			
			rich_defproc = (WNDPROC)SetWindowLong((HWND)richedit,GWL_WNDPROC,(LONG)hookProc);
			HRESULT hr;
			if(IsSpaceString(szTitle))
				hr=GetOpenFileA(hWnd,szTitle,MAX_LOADSTRING,"(*.txt)\0*.txt\0\0");
			SetCharFormat(richedit);
			if(FAILED(hr))
				break;
			hmenu = GetSubMenu(GetMenu(hWnd),1);
			hPopmenu = GetSubMenu(hmenu,0);
			hPopmenu1 = GetSubMenu(hmenu,1);
			idxmax0 = GetMenuItemCount(hPopmenu)-1;
			idxmax1 = GetMenuItemCount(hPopmenu1)-1;
			CheckMenuRadioItem(hPopmenu,0,idxmax0,imedium,MF_BYPOSITION);
			CheckMenuRadioItem(hPopmenu1,0,idxmax1,iauto,MF_BYPOSITION);
			ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
			}
			break;
		case WM_SIZE:
			if((HWND)richedit)
				MoveWindow(richedit,0,0,LOWORD(lParam),HIWORD(lParam),TRUE);
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam);
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case IDM_OPEN:					
					hr = GetOpenFileA(hWnd,szTitle,MAX_LOADSTRING,"(*.txt)\0*.txt\0\0");
					if(SUCCEEDED(hr))
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
				   break;
				case IDM_LARGEST:					
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu,0,idxmax0,ilargest,MF_BYPOSITION);					
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				case IDM_LARGER:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu,0,idxmax0,ilarger,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				case IDM_MEDIUM:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu,0,idxmax0,imedium,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}					
					break;
				case IDM_SMALLER:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu,0,idxmax0,ismaller,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				case IDM_SMALLEST:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu,0,idxmax0,ismallest,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				case IDM_BIG5:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu1,0,idxmax1,ibig5,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}					
					break;
				case IDM_EUCKR:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu1,0,idxmax1,ieuc_kr,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}					
					break;
				case IDM_GB:					
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu1,0,idxmax1,igb,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				case IDM_SHIFTJIS:					
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu1,0,idxmax1,ishiftjs,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;				
				case IDM_UTF:					
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu1,0,idxmax1,iutf8,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				case IDM_AUTO:
					if(!IsSpaceString(szTitle))
					{
						CheckMenuRadioItem(hPopmenu1,0,idxmax1,iauto,MF_BYPOSITION);
						ViewFile(richedit,szTitle,hPopmenu,hPopmenu1);
					}
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;			
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);			
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			SetWindowLong((HWND)richedit,GWL_WNDPROC,(LONG)rich_defproc);
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}