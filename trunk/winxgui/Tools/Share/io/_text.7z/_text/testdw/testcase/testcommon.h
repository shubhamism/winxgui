/* -------------------------------------------------------------------------
//	�ļ���		��	testcommon.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:32:48
//	��������	��	
//
//	$Id: testcommon.h,v 1.5 2005/10/26 01:21:56 wangdong Exp $
// -----------------------------------------------------------------------*/
#ifndef __TESTCOMMON_H__
#define __TESTCOMMON_H__

#ifndef __CPPUNIT_CPPUNIT_H__
#include <cppunit/cppunit.h>
#endif



__USING_MSO_ESCHER;

// -------------------------------------------------------------------------
#define testPath(file)		L"../../../../Test/office/wps/testcase/doctarget/" L##file
#define testXlsPath(file)	L"../../../../Test/office/wps/testcase/xlsrw/" L##file

// -------------------------------------------------------------------------

inline
STDMETHODIMP CreateDocfile(
						   IN LPCWSTR szFile,
						   OUT IStorage** ppRootStg)
{
	WCHAR szDocFile[_MAX_PATH];
	return StgCreateDocfile(
		GetSystemIniPath(szDocFile, szFile),
		STGM_READWRITE|STGM_SHARE_EXCLUSIVE|STGM_CREATE,
		0,
		ppRootStg);
}

inline
STDMETHODIMP_(KDWBlip) NewBlip(
							   IN KDWDocument& docu,
							   IN LPCWSTR szImgFile,
							   IN MSOBLIPTYPE blipType = msoblipUNKNOWN)
{
	WCHAR szFile[_MAX_PATH];
	return docu.GetBlipStore().NewBlip(
		GetSystemIniPath(szFile, szImgFile), blipType);	
}

inline
STDMETHODIMP_(KDWPicBullet) NewBullet(
							   IN KDWDocument& docu,
							   IN LPCWSTR szImgFile,
							   IN MSOBLIPTYPE blipType = msoblipUNKNOWN)
{
	WCHAR szFile[_MAX_PATH];
	KDWBlip blip = docu.GetBlipStore().NewBlip(
		GetSystemIniPath(szFile, szImgFile),
		blipType);	
	return docu.GetPicBullets().NewPicBullet(blip);
}

// -------------------------------------------------------------------------
// $Log: testcommon.h,v $
// Revision 1.5  2005/10/26 01:21:56  wangdong
// �������µ���ע��APIģ�͡�
//
// Revision 1.4  2004/12/27 08:58:40  xushiwei
// ֧�ֽ�һ��Worksheetת��Ϊ���ֱ����롣
// ������ز��԰�����
//

#endif /* __TESTCOMMON_H__ */
