/* -------------------------------------------------------------------------
//	�ļ���		��	testembpic2.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-1 10:36:20
//	��������	��	
//
//	$Id: testembpic2.cpp,v 1.9 2005/05/30 04:55:14 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestEmbPic2 : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestEmbPic2);
		CPPUNIT_TEST(testEmbSimple);
		CPPUNIT_TEST(testEmbPic);
		CPPUNIT_TEST(testEmbLink);
		CPPUNIT_TEST(testEmbPicFill);
		CPPUNIT_TEST(testEmbLineFill);
		CPPUNIT_TEST(testEmbPicWithFill);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testEmbSimple()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb2_shape_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		docu.AddInlinePicture(0x4EC, 0x618)
			.SetShapeType(msosptLine);

		{
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, msofillPattern);//MSOFILLTYPE
		opt.AddPropFix(msopt_fillColor, RGB(0,0,255));
		opt.AddPropFix(msopt_fillBlip, blipFill2);
		
		docu.AddInlinePicture(0x9EC, 0xB18)
			.SetShapeType(msosptNoSmoking)
			.SetProperties(opt);
		}
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	
	void testEmbLink()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb2_pic(link)_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWShapeOPT opt;
		opt.AddPropFix(msopt_pibFlags, 6 | msoblipflagLinkToFile);
		opt.AddPropVar(msopt_pibName, __X("../docrw/ktsj.jpg"), 18*2, 1);
		//opt.AddPropVar(msopt_pibName, __X("ktsj.jpg"), 9*2, 1);
		//opt.AddPropVar(msopt_pibName, __X("../docrw/draw/���ݲ�.png"), 22*2, 1);
		
		docu.AddInlinePicture(0x9EC, 0x918)
			.SetProperties(opt);
		
		docu.AddContent(0x0d);
		docu.Close();
	}
	
	void testEmbPic()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb2_pic_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blip2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		opt.AddPropFix(msopt_pibFlags, msoblipflagComment);
		opt.AddPropVar(msopt_pibName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_pib, blip2);
		
		docu.AddInlinePicture(0x9EC, 0x918)
			.SetProperties(opt);
		
		docu.AddContent(0x0d);
		docu.Close();
	}

	void testEmbLineFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb2_linefill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blipLineFill = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWBlip blipFill = 
			NewBlip(docu, testPath("../docrw/datalayer.png"), msoblipPNG);

		KDWShapeOPT opt;
		opt.AddPropFix(msopt_lineType, msolinePattern);
		opt.AddPropFix(msopt_lineWidth, 0x0129A8*2);
		opt.AddPropFix(msopt_lineFillBlip, blipLineFill);
		opt.AddPropBool(msopt_fLine, TRUE);
		opt.AddPropBool(msopt_fArrowheadsOK, TRUE);
	
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropFix(msopt_fillType, msofillTexture);//MSOFILLTYPE
		opt.AddPropFix(msopt_fillColor, RGB(0,0,255));
		opt.AddPropFix(msopt_fillBlip, blipFill);
		
		docu.AddInlinePicture(0x10EC, 0x1618)
			.SetProperties(opt)
			.SetShapeType(msosptRectangle);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	
	void testEmbPicFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb2_fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, msofillPattern);//MSOFILLTYPE
		opt.AddPropFix(msopt_fillColor, RGB(0,0,255));
		opt.AddPropFix(msopt_fillBlip, blipFill2);
		
		docu.AddInlinePicture(0x4EC, 0x618)
			.SetProperties(opt);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testEmbPicWithFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb2_pic2fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWBlip blip2 = 
			NewBlip(docu, testPath("../docrw/datalayer.png"), msoblipPNG);
		
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;

		opt.AddPropFix(msopt_pibFlags, msoblipflagURL);//MSOBLIPFLAGS
		opt.AddPropVar(msopt_pibName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_pib, blip2);
		
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("ktsj"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, msofillTexture);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill2);
		
		docu.AddInlinePicture(0x20EC, 0x1018)
			.SetProperties(opt);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestEmbPic2);

// -------------------------------------------------------------------------
// $Log: testembpic2.cpp,v $
// Revision 1.9  2005/05/30 04:55:14  xushiwei
// ����֧��INCLUDEPICTURE���ˡ�
//
// Revision 1.8  2005/05/28 09:32:54  xushiwei
// ����link��picture�ļ��������ĵ������
//
// Revision 1.6  2005/05/28 09:27:04  xushiwei
// ֧��link��ʽ�����embpic������includepicture�����õ��ˡ�
//
