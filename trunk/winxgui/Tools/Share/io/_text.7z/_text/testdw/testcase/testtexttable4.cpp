/* -------------------------------------------------------------------------
//	�ļ���		��	testtexttable4.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-3 10:32:46
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class TestTextTablePosAndLook : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestTextTablePosAndLook);
		CPPUNIT_TEST(testLeftIndent);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testLeftIndent()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_leftindent_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);

		{
			KDWPropBuffer cellx;
			KDWPropBuffer rowx;


#define CellCnt 3

			cellx.AddIstd(0);
			cellx.ForceAddPropFix(sprmPFInTable, 1);
			for (int i = 0; i < CellCnt; ++i)
			{
				docu.NewParagraph(&cellx);
				docu.NewSpan(&chpx);
				docu.AddContent('\x07');
			}
#pragma pack(1)
			struct defTable
			{
				UINT8 itcMax;
				INT16 rgdxaCenter[CellCnt + 1];

				defTable()
				{ 
					rgdxaCenter[0] = 0;
					itcMax = CellCnt;
					for (int i = 0; i < CellCnt; ++i)
						rgdxaCenter[i + 1] = rgdxaCenter[i] + 1500;
				}
			};
#pragma pack()
			rowx.AddIstd(0);
			rowx.ForceAddPropFix(sprmPFInTable, 1);
			rowx.ForceAddPropFix(sprmPFTtp, 1);


			KDWValueExt beforeWidth;
			beforeWidth.put_Value(6000);
//			beforeWidth.write(sprmTWidthBefore, rowx);
			
			KDWValueExt leftInd;
			leftInd.put_Value(4000);

			SprmTDefCellMarginOprand opr;
			opr.grbitChg = 0x08;
			opr.type = 0x03;
			opr.wCellMargin = 0x06C;


			rowx.AddPropVar(sprmTDefCellMargin, &opr, sizeof(opr));

//			rowx.ForceAddPropFix(sprmTDxaLeft, 1000);
//			rowx.ForceAddPropFix(sprmTDxaGapHalf, 2000);
//			leftInd.write(sprmTLeftIndent, rowx);
			rowx.AddPropVar(sprmTDefTable, &defTable(), sizeof(defTable));


			docu.NewSpan(&chpx);
			docu.NewParagraph(&rowx);
			docu.AddContent('\x07');

			docu.NewSpan(&chpx);
			docu.NewParagraph(&papx);
			docu.AddContent('\x0d');
		}				
		docu.Close();
	}
};


CPPUNIT_TEST_SUITE_REGISTRATION(TestTextTablePosAndLook);

// -------------------------------------------------------------------------
