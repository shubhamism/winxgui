/* -------------------------------------------------------------------------
//	�ļ���		��	testembpic.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-31 21:12:52
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"

#if defined(DW_EMBPIC_BACKWARD_COMPAT) // ���ļ��Ѿ���ʱ

#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestEmbPic : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestEmbPic);
		CPPUNIT_TEST(testEmbSimple);
		CPPUNIT_TEST(testEmbPic);
		CPPUNIT_TEST(testEmbPicFill);
		CPPUNIT_TEST(testEmbPicWithFill);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testEmbSimple()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb_shape_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		{
		KDWShapeOPT opt;
		KDWShapeOPT optUDef;
		docu.AddInlinePicture(
			0x4EC, 0x618, opt, optUDef, msosptLine);
		}

		{
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		KDWShapeOPT optUDef;
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, 2);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill2);
		
		docu.AddInlinePicture(
			0x9EC, 0xB18, opt, optUDef, msosptRectangle);
		}
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	
	void testEmbPic()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb_pic_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWBlip blip2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		KDWShapeOPT optUDef;
		opt.AddPropFix(msopt_pibFlags, 2);
		opt.AddPropVar(msopt_pibName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_pib, blip2);
		
		docu.AddInlinePicture(0x4EC, 0x618, opt, optUDef, msosptRectangle);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testEmbPicFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb_fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		KDWShapeOPT optUDef;
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, 2);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill2);
		
		docu.AddInlinePicture(0x4EC, 0x618, opt, optUDef);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testEmbPicWithFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb_pic2fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWBlip blip2 = 
			NewBlip(docu, testPath("../docrw/datalayer.png"), msoblipPNG);
		
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		KDWShapeOPT optUDef;

		opt.AddPropFix(msopt_pibFlags, 2);
		opt.AddPropVar(msopt_pibName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_pib, blip2);
		
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("ktsj"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, 2);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill2);
		
		docu.AddInlinePicture(0x20EC, 0x1018, opt, optUDef);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestEmbPic);

// -------------------------------------------------------------------------

#endif // defined(DW_EMBPIC_BACKWARD_COMPAT)
