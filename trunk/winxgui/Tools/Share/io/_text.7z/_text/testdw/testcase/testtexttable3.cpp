/* -------------------------------------------------------------------------
//	�ļ���		��	testtexttable3.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-7 21:03:35
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestTableExtension : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestTableExtension);
		CPPUNIT_TEST(testHugeTapx);
		CPPUNIT_TEST(testSubTableHugeTapx);
		CPPUNIT_TEST(testDiagonals);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	// ����v6б�߱�Ԫ��word�еı��֣�word��֧��б�߱�Ԫ������Ӧ������һ����Ч�ı���
	void testDiagonals()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_diagonals_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			KDWDiagonal diagonals[2];//��������б�ߣ���Ԫ���ڣ������Եģ���wps�е����ԡ�
			diagonals[0].put_Diagonal(55*50, 300*50);
			diagonals[1].put_Diagonal(140*50, 300*50);
			tblPr.typeCellWidth = mso_vetDxa;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);
				
				// cell 11
				docu.rowtbl_NewCell(cellPr, diagonals, 2);
				{
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(__X("diag11\x0d"), 7);
					
					docu.rowtbl_NewDiagonal();
					
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(__X("diag12\x0d"), 7);
					
					docu.rowtbl_NewDiagonal();
					
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(__X("diag13\x0d"), 7);
				}
				
				// cell 12
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell12\x0d"), 7);
				
				// cell 13
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell13\x0d"), 7);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}
	
	void testHugeTapx()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_hugetbl_.doc"), &spRootStg));

		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		KDWRowTablePr tblPr;
		KDWCellPr cellPr;
		cellPr.tcWidth = 500;
		docu.rowtbl_StartTable();
		{
			docu.rowtbl_NewRow(&tblPr);
			for (int i = 0; i < 10; ++i)
			{
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(0x0d);
			}
		}
		docu.rowtbl_EndTable();
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		docu.Close();
	}

	void testSubTableHugeTapx()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_hugesubtbl_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		KDWRowTablePr tblPr;
		KDWCellPr cellPr;
		docu.rowtbl_StartTable();
		{
			docu.rowtbl_NewRow(&tblPr);

			cellPr.tcWidth = 500*10;
			docu.rowtbl_NewCell(cellPr);
			
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);
				cellPr.tcWidth = 450;
				for (int i = 0; i < 10; ++i)
				{
					docu.rowtbl_NewCell(cellPr);
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(0x0d);
				}
			}
			docu.rowtbl_EndTable();

			docu.NewParagraph(&papx);
			docu.NewSpan(&chpx);
			docu.AddContent(0x0d);
		}
		docu.rowtbl_EndTable();
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestTableExtension);

// -------------------------------------------------------------------------
