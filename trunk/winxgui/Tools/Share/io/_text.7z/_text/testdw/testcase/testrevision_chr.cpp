/* -------------------------------------------------------------------------
//	�ļ���		��	testrevision_chr.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-6 10:38:42
//	��������	��	
//
//	$Id: testrevision_chr.cpp,v 1.2 2004/12/08 02:11:24 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestRevision_Character : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestRevision_Character);
		CPPUNIT_TEST(testInsertion);
		CPPUNIT_TEST(testDeletion);
		CPPUNIT_TEST(testFormatChange);
		CPPUNIT_TEST(testMultiFormatChange);
		CPPUNIT_TEST(testMultiOp);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testInsertion()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revchr_insertion_.doc"), &spRootStg));

		KDWDocument doc;
		
		// �����û�:
		UINT usrid;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);

		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		chpx.AddPropFix(sprmCFRMark, 0x81);
		chpx.AddPropFix(sprmCIbstRMark, usrid);
		chpx.AddPropFix(sprmCDttmRMark, (UINT32&)dttm);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		doc.Close();
	}

	void testDeletion()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revchr_deletion_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		chpx.AddPropFix(sprmCFRMarkDel, 0x81);
		chpx.AddPropFix(sprmCIbstRMarkDel, usrid);
		chpx.AddPropFix(sprmCDttmRMarkDel, (UINT32&)dttm);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		chpx.Clear();
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}

	void testFormatChange()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revchr_fmtchg_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		chpx.AddPropFix(sprmCFItalic, 0x01);

		SprmCPropRMarkExOprand oprand;
		oprand.dttmPropRMark = dttm;
		oprand.fPropRMark = 0x01;
		oprand.ibstPropRMark = usrid;
		chpx.AddPropVar(sprmCPropRMarkEx, &oprand, sizeof(oprand));
		chpx.AddPropFix(sprmCFPropRMarkEx, 0x01);
	
		chpx.AddPropFix(sprmCTextColor, 0xff0000);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		chpx.Clear();
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}

	//
	// note:
	//	��������У�����ͼ��ͬһ��������д�������ߵĸ�ʽ�޶�������ʵ����word�����������
	//  ��ˣ�word����֧��MultiFormatChange��
	//
	void testMultiFormatChange()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revchr_fmtchgs_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid, usrid2;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("John"),
			__X("John"),
			&usrid2);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		chpx.AddPropFix(sprmCFItalic, 0x01);
		
		SprmCPropRMarkExOprand oprand;
		oprand.dttmPropRMark = dttm;
		oprand.fPropRMark = 0x01;
		oprand.ibstPropRMark = usrid;
		chpx.AddPropVar(sprmCPropRMarkEx, &oprand, sizeof(oprand));
		chpx.AddPropFix(sprmCFPropRMarkEx, 0x01);
		
		chpx.AddPropFix(sprmCTextColor, 0xff0000);

		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);

		++dttm.hr;
		oprand.dttmPropRMark = dttm;
		oprand.fPropRMark = 0x01;
		oprand.ibstPropRMark = usrid2;

		chpx.AddPropVar(sprmCPropRMarkEx, &oprand, sizeof(oprand));
		chpx.AddPropFix(sprmCFPropRMarkEx, 0x01);
		chpx.AddPropFix(sprmCFBold, 0x01);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		chpx.Clear();
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}

	//
	// note:
	//	��������У�����ͼ��ͬһ�������н��ж���޶�������
	//	����1�����˸þ䣨Insertion��������2����FormatChange������3ɾ���˸þ䣨Deletion����
	//	ʵ�ʲ��ԵĽ��������������ȷʵ���Թ��档����д���ָ������ڴ����ϵ
	//	������FormatChangeָ��Ҫ���޸ĺ��������sprmCPropRMarkEx��֮�⣩��
	//	�����ԣ������������word�ڲ����ýṹ�巽ʽ����chp��Ե�ʡ�
	//
	void testMultiOp()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revchr_multiop_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid1, usrid2, usrid3;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid1);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid1);
		doc.GetRevisionUsers().Add(
			__X("John"),
			__X("John"),
			&usrid2);
		doc.GetRevisionUsers().Add(
			__X("Jam"),
			__X("Jam"),
			&usrid3);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		chpx.AddPropFix(sprmCFRMark, 0x81);
		chpx.AddPropFix(sprmCIbstRMark, usrid1);
		chpx.AddPropFix(sprmCDttmRMark, (UINT32&)dttm);
	
		++dttm.hr;
		SprmCPropRMarkExOprand oprand;
		oprand.dttmPropRMark = dttm;
		oprand.fPropRMark = 0x01;
		oprand.ibstPropRMark = usrid2;
		chpx.AddPropVar(sprmCPropRMarkEx, &oprand, sizeof(oprand));
		chpx.AddPropFix(sprmCFPropRMarkEx, 0x01);
		
		chpx.AddPropFix(sprmCTextColor, 0xff0000);
		
		++dttm.hr;
		chpx.AddPropFix(sprmCFRMarkDel, 0x81);
		chpx.AddPropFix(sprmCIbstRMarkDel, usrid3);
		chpx.AddPropFix(sprmCDttmRMarkDel, (UINT32&)dttm);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
	
		chpx.Clear();
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestRevision_Character);

// -------------------------------------------------------------------------
//	$Log: testrevision_chr.cpp,v $
//	Revision 1.2  2004/12/08 02:11:24  xushiwei
//	�û�KDWUsersʹ�õ�����
//	
//	Revision 1.1  2004/12/06 08:57:50  xushiwei
//	*** empty log message ***
//	
//	
