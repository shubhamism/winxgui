/* -------------------------------------------------------------------------
//	�ļ���		��	testdrawing.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 20:44:05
//	��������	��	
//
//	$Id: testdrawing.cpp,v 1.9 2005/01/21 04:42:18 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include <time.h>
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

__USING_MSO_ESCHER;

// -------------------------------------------------------------------------

class TestDrawings : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestDrawings);
		CPPUNIT_TEST(testNewApi);
		CPPUNIT_TEST(testSimple);
		CPPUNIT_TEST(testZOrder);
		CPPUNIT_TEST(testPosition);
		CPPUNIT_TEST(testHeaderFooter);
		CPPUNIT_TEST(testGroupShape);
		CPPUNIT_TEST(testNullGroupShape);
		CPPUNIT_TEST(testBackgrnd);
		CPPUNIT_TEST(testGrid);
		CPPUNIT_TEST(testShapeIdAlloc);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	//
	// ����shape��ص��µ�api�����ڶ����anchorҲ����������һ����������ʱ�����ˡ�
	//
	void testNewApi()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_shape_newapi_.doc"), &spRootStg));

		KDWDocument docu;
		docu.NewDocument(spRootStg);
		docu.NewNullSepxSection();
		docu.NewNullPapxParagraph();
		docu.NewNullChpxSpan();

		docu.AddShape()
			.SetShapeType(msosptLine);

		KDWShapeAnchor anchor;
		anchor.SetData(0x768, 0x8D4, 0x10EC, 0x1018);
		docu.AddShape()
			.SetClientAnchor(anchor)
			.SetShapeType(msosptRectangle);
		
		docu.AddContent(0x0d);
		docu.Close();
	}

	//
	// ���Զ���id��������Ƿ������⡣ͬʱ�������ɴ�����������ܡ�
	//
	void testShapeIdAlloc()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_shape_idalloc_.doc"), &spRootStg));
		
		KDWDocument docu;
		docu.NewDocument(spRootStg);
		docu.NewNullSepxSection();
		docu.NewNullPapxParagraph();
		docu.NewNullChpxSpan();
		
		srand( time(NULL) );
		srand( rand() );

		for (int i = 0; i < 0x4000; ++i)
		{
			MSOSPT spt = (MSOSPT)((rand() & 0x7f) + 1);
			KDWShapeAnchor anchor;
			anchor.SetData(0x768, 0x8D4, 0x10EC, 0x1018);
			docu.AddShape()
				.SetClientAnchor(anchor)
				.SetShapeType(spt);
			docu.AddContent(0x0c);
		}
		
		docu.AddContent(0x0d);
		docu.Close();
	}
	
	void testSimple()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_simple_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		docu.AddShape(0x168, 0x1D4, 0x4EC, 0x618)
			.SetShapeType(msosptLine);

		docu.AddShape(0x768, 0x8D4, 0x9EC, 0xB18)
			.SetShapeType(msosptRectangle);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testPosition()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_position_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWShapeOPT optUDef;
		//optUDef.AddPropBool(msopt_fXXXX, FALSE);
		//optUDef.AddPropBool(msopt_fXXXX2, FALSE);
		optUDef.AddPropFix(msopt_spXSpec, mso_spXSpecCenter);

		docu.AddShape(0x768, 0x8D4, 0x9EC, 0xB18)
			.SetShapeType(msosptRectangle)
			.SetUDefProperties(optUDef);
				
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testNullGroupShape()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_nullgroup_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWShape grpshape;
		
		grpshape = docu.AddGroupShape(0x50, 0x60, 0x10EC, 0xC18);
		
		grpshape.NewShape(0x168, 0x1D4, 0x4EC, 0x618)
			.SetShapeType(msosptLine);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	
	void testGroupShape()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_group_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWShape grpshape;

		KDWShapeOPT optUDef;
		optUDef.AddPropBool(msopt_fInlineShape, TRUE);
		
		grpshape = docu.AddGroupShape(0x50, 0x60, 0x10EC, 0xC18)
			.SetUDefProperties(optUDef);

		grpshape.NewShape(0x168, 0x1D4, 0x4EC, 0x618)
			.SetShapeType(msosptLine);
		
		grpshape.NewShape(0x768, 0x8D4, 0x9EC, 0xB18)
			.SetShapeType(msosptRectangle);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	
	void testZOrder()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_zorder_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		docu.AddShape(0x168, 0x1D4, 0x5EC, 0x718)
			.SetShapeType(msosptLine)
			.SetZOrder(2);
		
		docu.AddShape(0x468, 0x5D4, 0x9EC, 0xB18)
			.SetShapeType(msosptRectangle)
			.SetZOrder(1);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testHeaderFooter()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_headerfooter_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		KDWShape grpshape;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		
		docu.NewSection(&sepx);
		docu.EnterHeaderFooter(DW_ODD_HEADER);//����ҳüҳ�š�
		{
			docu.NewParagraph(&papx);
			docu.NewSpan(&chpx);
			docu.AddContent(__X("goodmoring"),10);
			docu.AddContent(__X("\x0d"), 1);
		}
		docu.LeaveHeaderFooter();//�뿪ҳüҳ�š�

		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		grpshape=docu.AddGroupShape(0,0,3000,3000);//������϶���
		grpshape.NewShape(0x168, 0x1D4, 0x5EC, 0x718)
			.SetShapeType(msosptLine);//����϶����д���һ���ߡ�
		grpshape.NewShape(0x468, 0x5D4, 0x9EC, 0xB18)
			.SetShapeType(msosptRectangle);//����϶����д���һ�����Ρ�
		
		docu.AddShape(0,3100,5000,5000,mso_spaXRelText,mso_spaYRelText,mso_spaWrTight,mso_spaWrtBoth).SetShapeType(msosptRectangle);//���ĵ�������һ�����Ρ�
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	void testBackgrnd()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_backgrnd_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWShape bgShape = docu.GetBackground();
		KDWShapeOPT opt;
		//opt.ForceAddPropFix(msopt_fillType, msofillSolid);
		opt.AddPropFix(msopt_fillColor, RGB(255, 0, 0));
		opt.ForceAddPropBool(msopt_fFilled, TRUE);
		opt.ForceAddPropBool(msopt_fLine, FALSE);

		bgShape.SetShapeType(msosptRectangle);
		bgShape.SetProperties(opt);

		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	void testGrid()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dg_grid_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWDocProperties& docpro = docu.GetDop();
//struct __iotype DOGRID
//{
//	INT16	xaGrid;		//x-coordinate of the upper left-hand corner of the grid
//	INT16	yaGrid;		//y-coordinate of the upper left-hand corner of the grid
//	INT16	dxaGrid;	//width of each grid square
//	INT16	dyaGrid;	//height of each grid square
//
//	UINT16	dyGridDisplay :7;	//the number of grid squares (in the y direction) between each gridline drawn on the screen. 0 means don't display any gridlines in the y direction.
//	UINT16	fTurnItOff :1;		//suppress display of gridlines
//	UINT16	dxGridDisplay :7;	//the number of grid squares (in the x direction) between each gridline drawn on the screen. 0 means don't display any gridlines in the y direction.
//	UINT16	fFollowMargins :1;	// if true, the grid will start at the left and top margins and ignore xaGrid and yaGrid.
//};
//		docpro.dop.dogrid.xaGrid = 1797;
//		docpro.dop.dogrid.yaGrid = 1440;
//		docpro.dop.dogrid.dxaGrid = 208;
//		docpro.dop.dogrid.dyaGrid = 697;
//		docpro.dop.dogrid.dyGridDisplay = 1;
//		docpro.dop.dogrid.fTurnItOff = 1;
//		docpro.dop.dogrid.dxGridDisplay = 2;
//		docpro.dop.dogrid.fFollowMargins = 1;

		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

};

CPPUNIT_TEST_SUITE_REGISTRATION(TestDrawings);

// -------------------------------------------------------------------------
// $Log: testdrawing.cpp,v $
// Revision 1.9  2005/01/21 04:42:18  xushiwei
// �޸�AllocShapeId��bug������testAllocShapeId������
//
// Revision 1.8  2005/01/14 01:32:27  xushiwei
// ��escherwriter����һ�νϴ�ĵ�����
// 1��ԭ��client����(anchor��textbox��clientdata)��Persist��ʽ�����ʱ��
// 2�������µ�SetClientAnchor��SetClientTextBox��SetClientData��
// ������Щclient anchor��������������һ����������ʱ�����ˡ�
// �����µ�api���԰�����
//
// Revision 1.7  2004/12/27 03:49:59  xushiwei
// ҳüҳ��api������
//
