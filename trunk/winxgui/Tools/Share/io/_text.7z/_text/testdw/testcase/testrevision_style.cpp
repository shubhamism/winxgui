/* -------------------------------------------------------------------------
//	�ļ���		��	testrevision_style.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-7 11:18:32
//	��������	��	
//
//	$Id: testrevision_style.cpp,v 1.2 2004/12/08 02:11:24 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestRevision_Style : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestRevision_Style);
		CPPUNIT_TEST(testFormatChange);
		CPPUNIT_TEST(testNewStyle);
		CPPUNIT_TEST(testDeleteStyle);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testFormatChange()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revstyle_fmtchg_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		
		KDWStyle style;
		doc.GetStyleSheet().NewStyle(
			stiUser,
			__X("MyCreateParagraphStyle"),
			mso_sgcParagraph,
			&style);
		style.SetBaseStyle(0);
		style.SetSprmList(mso_sgcParagraph, &papx);

		KDWPropBuffer papxOrg;
		KDWStyle styleOrg;
		papxOrg.AddIstd(style.GetIndex()); // �ƺ�û����
		style.Revise(usrid, dttm, &styleOrg);
		styleOrg.SetSprmList(mso_sgcParagraph, &papxOrg);

		papx.Clear();
		papx.AddIstd(style.GetIndex());
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}

	void testNewStyle() // word��֧��
	{
	}

	void testDeleteStyle() // word��֧��
	{
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestRevision_Style);

// -------------------------------------------------------------------------
//	$Log: testrevision_style.cpp,v $
//	Revision 1.2  2004/12/08 02:11:24  xushiwei
//	�û�KDWUsersʹ�õ�����
//	
//	Revision 1.1  2004/12/07 09:04:25  xushiwei
//	������ʽ�޶�������
//	
//	
