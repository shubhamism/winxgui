/* -------------------------------------------------------------------------
//	�ļ���		��	testfield_ex.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-24 15:38:39
//	��������	��	
//
//	$Id: testfield_ex.cpp,v 1.1 2004/12/24 08:48:47 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestExField : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestExField);
		CPPUNIT_TEST(test);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void test()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_field_settype_.doc"), &spRootStg));

		KDWDocument doc;
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		
		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);

		doc.MarkFieldBegin();
		{
			WCHAR szMsg[] = __X(" DATE \\@ \"yyyy-MM-dd\"");
			doc.AddContent(szMsg, countof(szMsg)-1);
		}
		doc.SetCurrentFieldType(mso_fltDate);
		doc.MarkFieldSeparator();
		{
			WCHAR szMsg[] = __X("2004-08-20");
			doc.AddContent(szMsg, countof(szMsg)-1);
		}
		doc.MarkFieldEnd();

		doc.AddContent(0x0d);
		doc.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestExField);

// -------------------------------------------------------------------------
//	$Log: testfield_ex.cpp,v $
//	Revision 1.1  2004/12/24 08:48:47  xushiwei
//	������޸ģ�Ϊ��֧��rtf�ļ�������SetCurrentFieldType�������Ӷ����������ԡ�
//	������صİ�����
//	
