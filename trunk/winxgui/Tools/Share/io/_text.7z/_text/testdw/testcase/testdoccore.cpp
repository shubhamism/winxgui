/* -------------------------------------------------------------------------
//	�ļ���		��	testdoccore.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:31:37
//	��������	��	
//
//	$Id: testdoccore.cpp,v 1.29 2006/08/09 01:17:00 wangdong Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <math.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestDocCore : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestDocCore);
		CPPUNIT_TEST(testFirst);
		CPPUNIT_TEST(testConflictChpx);
		CPPUNIT_TEST(testBasic);
		CPPUNIT_TEST(testFontTable);
		CPPUNIT_TEST(testPieceTable);
		CPPUNIT_TEST(testCharCategory);
		CPPUNIT_TEST(testTwoInOne);
		CPPUNIT_TEST(testHorzVert);
		CPPUNIT_TEST(testFitText);

#if defined(_GEN_TABLE_TOOLS)
		CPPUNIT_TEST(testXDigit);
		CPPUNIT_TEST(testCP1252);
#endif
#if !defined(_DEBUG)
		CPPUNIT_TEST(testAutoFreeAlloc); // --> test only release
#endif
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	//
	// ���ż�����򵥵�doc�ļ�
	//
	void testFirst()
	{
		//double db = pow(1 + 0.010759, 12) - 1;

		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_core_first_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		doc.Close();
	}

	//
	// ����ָ��Ĵ����ϵ��
	// ���Խ��������sprmCIcoָ�������sprmCTextColorǰ���֡����ߴ��ڴ����ϵ��
	//
	void testConflictChpx()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_chpx_conflict_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		chpx.AddPropFix(sprmCTextColor, 0x0000ff); // ��ɫ
		chpx.AddPropFix(sprmCIco, 0); // �Զ�ɫ
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		doc.Close();
	}
	
	void testBasic()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_core_basic_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, 0x81);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		papx.AddPropFix(sprmPDxaLeft, 0);
		papx.AddPropFix(sprmPDxaLeftEx, 0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x00\x0d"), 3);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}

	//
	// ��������ʾ����������塣
	//
	void testFontTable()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_core_fonttbl_.doc"), &spRootStg));
		
		KDWDocument doc;
		doc.NewDocument(spRootStg);
		
		KDWPropBuffer sepx;
		doc.NewSection(&sepx);
		
		KDWPropBuffer papx;
		papx.AddIstd(0);
		doc.NewParagraph(&papx);

		KDWFont font;
		ZeroMemory(&font, sizeof(font));
		font.fTrueType = TRUE;
		
		// ����'����'����
		UINT ftcHeiti;
		font.name = __X("����");
		font.family = 0;
		font.charset = 0;
		doc.GetFontTable().Add(font, &ftcHeiti);

		// ����'Courier New'����
		UINT ftcCourierNew;
		font.name = __X("Courier New");
		font.charset = 0;
		font.family = 3;
		doc.GetFontTable().Add(font, &ftcCourierNew);
		
		KDWPropBuffer chpx1;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx1.AddPropFix(sprmCRgFtc0, ftcHeiti);
		chpx1.AddPropFix(sprmCRgFtc1, ftcHeiti);
		chpx1.AddPropFix(sprmCRgFtc2, ftcHeiti);
		chpx1.AddPropFix(sprmCHps, 48*2);
		doc.NewSpan(&chpx1);

		doc.AddContent(__X("����\x0d"), 3);
		
		KDWPropBuffer chpx2;
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		chpx2.AddPropFix(sprmCRgFtc0, ftcCourierNew);
		chpx2.AddPropFix(sprmCRgFtc1, ftcHeiti);
		chpx2.AddPropFix(sprmCRgFtc2, ftcHeiti);
		chpx2.AddPropFix(sprmCHps, 32*2);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("Courier New\x0d"), 12);
		
		doc.Close();
	}

	void testAutoFreeAlloc() // ����AutoFreeAlloc������
	{
		const int Count = 400000;
		typedef long double type;
		_XTracefA("---------------------------------\n");
		{
			_XQualityTimer(__X("new"));
			type* a;
			for (int i = 0; i < Count; ++i)
			{
				a = new type;
				a[0] = i;
				delete a;
			}
		}
		{
			_XQualityTimer(__X("malloc"));
			type* a;
			for (int i = 0; i < Count; ++i)
			{
				a = (type*)malloc(sizeof(type));
				a[0] = i;
				free(a);
			}
		}
		{
			_XQualityTimer(__X("KDWAutoFreeAlloc"));
			KfcAutoFreeAlloc alloc;
			type* a;
			for (int i = 0; i < Count; ++i)
			{
				a = _MsoAlloc(&alloc, type);
				a[0] = i;
			}
		}
	}

	void testCP1252()
	{
		char szData[512];
		for (int i = 0; i < 256; ++i)
			szData[i] = i;
		WCHAR szDataW[512];
		UINT cchW = MultiByteToWideChar(1252, 0, szData, 256, szDataW, 512);
		printf("cchW = %d\n", cchW);
		for (int i = 0; i < cchW/4; ++i)
		{
			printf("0x%.4x, 0x%.4x, 0x%.4x, 0x%.4x,\n",
				szDataW[i*4], szDataW[i*4+1], szDataW[i*4+2], szDataW[i*4+3]);
		}
	}

	void testCharCategory()
	{
		for (int i = 0; i < 256; i+=4)
		{
			if (i >= ' ' && i <= '~'-3)
				printf("\t// '%c', '%c', '%c', '%c',\n", i, i+1, i+2, i+3);
			else
				printf("\t// 0x%.2x, 0x%.2x, 0x%.2x, 0x%.2x,\n", i, i+1, i+2, i+3);

			printf("\tkfc_ccNone, kfc_ccNone, kfc_ccNone, kfc_ccNone,\n\n");
		}
	}
	
	void testXDigit()
	{
		char data[256];
		for (int i = 0; i < 256; ++i)
			data[i] = -1;
		
		data['0'] = 0;
		data['1'] = 1;
		data['2'] = 2;
		data['3'] = 3;
		data['4'] = 4;
		data['5'] = 5;
		data['6'] = 6;
		data['7'] = 7;
		data['8'] = 8;
		data['9'] = 9;
		data['a'] = 0x0a;
		data['b'] = 0x0b;
		data['c'] = 0x0c;
		data['d'] = 0x0d;
		data['e'] = 0x0e;
		data['f'] = 0x0f;
		data['A'] = 0x0a;
		data['B'] = 0x0b;
		data['C'] = 0x0c;
		data['D'] = 0x0d;
		data['E'] = 0x0e;
		data['F'] = 0x0f;

		for (int i = 0; i < 256/4; ++i)
		{
			printf("%2d, %2d, %2d, %2d,\n",
				data[i*4], data[i*4+1], data[i*4+2], data[i*4+3]);
		}
	}
	
	void testPieceTable()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_core_piecetable_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		
		chpx1.AddPropFix(sprmCFBold, TRUE);
		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x0d"), 2);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		

#if (0)
		doc.NewPiece(2, 4);// ʲô��piece?
		doc.NewPiece(2, 4);
		doc.NewPiece(0, 2);
#endif
		
		doc.Close();
	}

	void testTwoInOne()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_chpx_TwoInOne.doc"), &spRootStg));
		
		KDWDocument doc;

		
		KDWPropBuffer chpx;

		ASIANLAYOUT asian = {0};
		asian.type = mso_asianLayoutCombine;
		asian.brackets = mso_tioBracketsSquare;
		
		chpx.AddPropFix(sprmCHps, 44);
		chpx.AddPropVar(
			sprmCAsianLayout, 
			&asian, sizeof(ASIANLAYOUT)
			);

	
		doc.NewDocument(spRootStg);
		doc.NewNullSepxSection();
		
		doc.NewNullPapxParagraph();
		doc.NewSpan(&chpx);
		for (int i = 0; i < 34; ++i)
			doc.AddContent(__X("AAA"), 3);
		doc.NewNullChpxSpan();
		doc.AddContent('\x0d');
		
		doc.Close();
	}
	void testHorzVert()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_chpx_HorzVert.doc"), &spRootStg));
		
		KDWDocument doc;

		
		KDWPropBuffer chpx;

		ASIANLAYOUT asian = {0};
		asian.type = mso_asianLayoutHorzVert;
		asian.compress = mso_horzvertCompressed;
		
		chpx.AddPropFix(sprmCHps, 44);
		chpx.AddPropVar(
			sprmCAsianLayout, 
			&asian, sizeof(ASIANLAYOUT)
			);

	
		doc.NewDocument(spRootStg);
		doc.NewNullSepxSection();
		
		doc.NewNullPapxParagraph();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("AAA"), 3);
		doc.NewNullChpxSpan();
		doc.AddContent('\x0d');
		
		doc.Close();		
	}
	void testFitText()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_chpx_FitText.doc"), &spRootStg));
		
		KDWDocument doc;

		
		KDWPropBuffer chpx;

		FITTEXT fitText = {0};
		fitText.value = 0x0834;
		
		chpx.AddPropFix(sprmCHps, 21);
		chpx.AddPropVar(
			sprmCFitText, 
			&fitText, sizeof(FITTEXT)
			);

	
		doc.NewDocument(spRootStg);
		doc.NewNullSepxSection();
		
		doc.NewNullPapxParagraph();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("AAA"), 3);
		doc.NewNullChpxSpan();
		doc.AddContent('\x0d');
		
		doc.Close();		
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestDocCore);

// -------------------------------------------------------------------------
// $Log: testdoccore.cpp,v $
// Revision 1.29  2006/08/09 01:17:00  wangdong
// ��FitText,TwoInOne�Լ�HorzVert������ϡ�
//
// Revision 1.28  2005/10/26 01:22:05  wangdong
// �������µ���ע��APIģ�͡�
//
// Revision 1.27  2005/05/28 07:18:59  xushiwei
// ����word��fBold֮0x81��0x80����
//
// Revision 1.26  2005/03/01 03:40:54  xushiwei
// ��kfc��allocaterĿ¼����Ϊallocator��
//
// Revision 1.25  2005/02/26 03:38:18  xushiwei
// charcategory��
//
// Revision 1.22  2005/01/04 01:34:28  xushiwei
// ��������xdigit-table��cp1252�ַ�ת������ذ�����
//
// Revision 1.21  2004/12/24 01:23:30  xushiwei
// �޸���ҳüҳ����ط������ṩ�µ�ʵ����
//
// Revision 1.20  2004/12/08 10:03:41  xushiwei
// ����������������
//
// Revision 1.19  2004/12/08 02:11:24  xushiwei
// �û�KDWUsersʹ�õ�����
//

