/* -------------------------------------------------------------------------
//	�ļ���		��	testcrypt.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-26 10:32:37
//	��������	��	
//
//	$Id: testcrypt.cpp,v 1.4 2005/04/26 02:25:46 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testole2.h"
#include "kso/crypt/ksocrypt.h"
#include "kso/linklib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestCrypt : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestCrypt);
		CPPUNIT_TEST(testEncryptDefault);
		CPPUNIT_TEST(testEncryptNoEnc);
		CPPUNIT_TEST(testOleEmbEncrypt);
		CPPUNIT_TEST(testXorEncrypt);
		CPPUNIT_TEST(testOffice97Encrypt);
		CPPUNIT_TEST(testWindowsEncrypt);		
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testWindowsEncrypt()
	{
		ks_stdptr<IStorage> spRootStg;
		
		VERIFY_OK(
			CreateDocfile(testPath("_crypt_windows_.doc"), &spRootStg));
		
		ks_stdptr<IKCryptDocument> spCryptDoc;
		kso_CreateCryptDocument(KCRYPTDOCUMENT_WPS, &spCryptDoc);
		
		ks_bstr providerName;
		ks_bstr algorithmName;
		DWORD nCount = spCryptDoc->GetProviderCount();
		for (DWORD i = 0; i < nCount; ++i)
		{
			ks_stdptr<IKCryptProviderInfo> spProvider;
			spCryptDoc->GetProvider(i, &spProvider);
			if (i == 2)
			{
				spProvider->GetProviderName(&providerName);
				spProvider->GetShortAlgorithmName(&algorithmName);
				TRACEW(
					__X("Provider: %s, Algorithm = %s\n"),
					providerName.c_str(),
					algorithmName.c_str());
			}
		}
		ASSERT(providerName);

		ks_stdptr<IKCryptProviderInfo> spProvider;
		VERIFY_OK(
			spCryptDoc->SetCurretProvider(providerName, algorithmName));
		spCryptDoc->GetCurretProvider(&spProvider);
		spCryptDoc->SetPassword(__X("123"));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		papx.AddPropFix(sprmPDxaLeft, 0);
		papx.AddPropFix(sprmPDxaLeftEx, 0);
		
		doc.NewDocument(spRootStg, spCryptDoc->HasPassword() ? spProvider->GetHandle() : NULL);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x00\x0d"), 3);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}

	void testXorEncrypt()
	{
		ks_stdptr<IStorage> spRootStg;
		
		VERIFY_OK(
			CreateDocfile(testPath("_crypt_xor_.doc"), &spRootStg));
		
		ks_stdptr<IKCryptDocument> spCryptDoc;
		kso_CreateCryptDocument(KCRYPTDOCUMENT_WPS, &spCryptDoc);
		
		ks_stdptr<IKCryptProviderInfo> spProvider;
		VERIFY_OK(
			spCryptDoc->SetCurretProvider(NULL, L"OfficeXor"));
		spCryptDoc->GetCurretProvider(&spProvider);
		spCryptDoc->SetPassword(__X("123"));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		papx.AddPropFix(sprmPDxaLeft, 0);
		papx.AddPropFix(sprmPDxaLeftEx, 0);
		
		doc.NewDocument(spRootStg, spCryptDoc->HasPassword() ? spProvider->GetHandle() : NULL);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x00\x0d"), 3);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}
	
	void testOffice97Encrypt()
	{
		ks_stdptr<IStorage> spRootStg;
		
		VERIFY_OK(
			CreateDocfile(testPath("_crypt_office_.doc"), &spRootStg));
		
		ks_stdptr<IKCryptDocument> spCryptDoc;
		kso_CreateCryptDocument(KCRYPTDOCUMENT_WPS, &spCryptDoc);
		
		DWORD nCount = spCryptDoc->GetProviderCount();
		for (DWORD i = 0; i < nCount; ++i)
		{
			ks_stdptr<IKCryptProviderInfo> spProvider;
			spCryptDoc->GetProvider(i, &spProvider);
		}
		
		ks_stdptr<IKCryptProviderInfo> spProvider;
		VERIFY_OK(
			spCryptDoc->SetCurretProvider(NULL, L"OfficeStandard"));
		spCryptDoc->GetCurretProvider(&spProvider);
		spCryptDoc->SetPassword(__X("123"));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		papx.AddPropFix(sprmPDxaLeft, 0);
		papx.AddPropFix(sprmPDxaLeftEx, 0);
		
		doc.NewDocument(spRootStg, spCryptDoc->HasPassword() ? spProvider->GetHandle() : NULL);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x00\x0d"), 3);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}

	void testEncryptDefault()
	{
		ks_stdptr<IStorage> spRootStg;
		
		VERIFY_OK(
			CreateDocfile(testPath("_crypt_basic_.doc"), &spRootStg));
		
		ks_stdptr<IKCryptDocument> spCryptDoc;
		kso_CreateCryptDocument(KCRYPTDOCUMENT_WPS, &spCryptDoc);
		
		ks_stdptr<IKCryptProviderInfo> spProvider;
		spCryptDoc->GetCurretProvider(&spProvider);
		spCryptDoc->SetPassword(__X("123"));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		papx.AddPropFix(sprmPDxaLeft, 0);
		papx.AddPropFix(sprmPDxaLeftEx, 0);
		
		doc.NewDocument(spRootStg, spCryptDoc->HasPassword() ? spProvider->GetHandle() : NULL);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x00\x0d"), 3);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}
	
	void testEncryptNoEnc()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_crypt_basic_noenc_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		papx.AddPropFix(sprmPDxaLeft, 0);
		papx.AddPropFix(sprmPDxaLeftEx, 0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("a\x00\x0d"), 3);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("bcd\x0d"), 4);
		
		doc.Close();
	}
	
	void testOleEmbEncrypt()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_crypt_oleemb_.doc"), &spRootStg));
		
		ks_stdptr<IKCryptDocument> spCryptDoc;
		kso_CreateCryptDocument(KCRYPTDOCUMENT_WPS, &spCryptDoc);
		
		ks_stdptr<IKCryptProviderInfo> spProvider;
		spCryptDoc->GetCurretProvider(&spProvider);
		spCryptDoc->SetPassword(__X("123"));

		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg, spCryptDoc->HasPassword() ? spProvider->GetHandle() : NULL);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blip = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		opt.AddPropFix(msopt_pib, blip);
		
		//
		// ע�⣺
		//	û�е���.Persist������Ole���󣨵�Ȼ�⽫����Ole��������ݲ���ȷ����
		//	��Ҫ����.Clear���������򽫴����ڴ�й©��
		//
		docu.AddOleEmbed(0x4EC, 0x618, __X("PBrush"))
			.Persist(
			SmartOleStg2(
			testPath("../docrw/ole/ole_emb.doc"),
			__X("_1154266423")))
			.SetProperties(opt);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestCrypt);

// -------------------------------------------------------------------------
//	$Log: testcrypt.cpp,v $
//	Revision 1.4  2005/04/26 02:25:46  xushiwei
//	����testcrypt����Ϊcrypt�ӿڸ��ˡ�
//	
//	Revision 1.3  2005/03/08 03:25:08  xushiwei
//	֧��xor��ʽ���ܡ�office97/2000���ݵļ��ܡ�
//	
//	Revision 1.2  2004/11/26 07:58:10  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2004/11/26 02:46:01  xushiwei
//	*** empty log message ***
//	
