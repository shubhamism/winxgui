/* -------------------------------------------------------------------------
//	�ļ���		��	testfield.cpp
//	������		��	����
//	����ʱ��	��	2004-9-3 4:46:09 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestField : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestField);
		CPPUNIT_TEST(testFields);
		CPPUNIT_TEST(TestTc);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void TestTc()
	{
		ks_stdptr<IStorage> spRootStg;		
		VERIFY_OK(
			CreateDocfile(testPath("_dt_tc_.doc"), &spRootStg));
		
		KDWDocument doc;

		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;

		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		chpx.AddPropFix(sprmCFFldVanish, 0x81);

		//=====================================================
		// test case 1: �������в�������
		doc.NewParagraph(&papx);
		{
			// ����	
			doc.NewSpan(&chpx);
		}		
		doc.AddPlaceHolder('\x13');
		
		WCHAR szMsg[] = __X("tc \\f c \"hard �ҵ�\"");			
		doc.NewSpan(&chpx);
		doc.AddContent(szMsg, wcslen(szMsg));		
		doc.AddPlaceHolder('\x15');
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);
		doc.Close();
	}
#define	InsertField_Time() \
		{ \
			doc.MarkFieldBegin(31, FALSE); \
			{ \
				WCHAR szMsg[] = __X(" DATE \\@ \"h:mm am/pm\""); \
				doc.NewSpan(&chpx); \
				doc.AddContent(szMsg, wcslen(szMsg)); \
			} \
			doc.MarkFieldSeparator(); \
			{ \
				WCHAR szMsg1[] = __X("11:09 AM"); \
				doc.NewSpan(&chpx); \
				doc.AddContent(szMsg1, wcslen(szMsg1)); \
			} \
			doc.MarkFieldEnd(); \
		}

	void testFields()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_fields_.doc"), &spRootStg));
		
		KDWDocument doc;

		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;

		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);

		//=====================================================
		// test case 1: �������в�������
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("field in main doc - Date: ");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldBegin(31, FALSE);		// field type 31: date
		{
			// field code
			WCHAR szMsg[] = __X(" DATE \\@ \"yyyy-MM-dd\"");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldSeparator();
		{
			// field data
			WCHAR szMsg[] = __X("2004-08-20");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldEnd();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		//=====================================================
		// test case 2: �������в���ʱ��
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("field in main doc - Time: ");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		InsertField_Time();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		//=====================================================
		// test case 3: ��header�в�������
		doc.EnterHeaderFooter(DW_ODD_HEADER);
		{
			doc.NewParagraph(&papx);
			{
				WCHAR szMsg[] = __X("field in header - Time: ");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			InsertField_Time();
			doc.NewSpan(&chpx);
			doc.AddContent(__X("\x0d"), 1);
		}
		doc.LeaveHeaderFooter();

		//=====================================================
		// test case 4: ����ע�в�������

		// �û���
		UINT uID_0;
		{
			KDWUsers& theUNI = doc.GetAnnotationUsers();
			UserNameInfo uni_1 = {__X("John Doe"), __X("JDm")};
			theUNI.Add(uni_1, &uID_0);
		}

		// ��עʱ��
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;

		// ��ע��
		HANNOTATION hAnn0;
		doc.BeginAddAnnotation(uID_0, &dttm, &hAnn0);
		{
			WCHAR szAnn[] = __X("field in annotation - time: ");
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx); doc.AddAndRef();
			doc.NewSpan(&chpx); doc.AddContent(szAnn, wcslen(szAnn));

			InsertField_Time();

			doc.NewSpan(&chpx);
			doc.AddContent(__X("\x0d"), 1);
		}
		doc.EndAddAnnotation(hAnn0);

		// ����
		{
			HANNOTATIONREF hAnnRef0;
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText[] = __X("field in annotation:");

			doc.AddContent(szText, wcslen(szText));
			doc.MarkAtnRefBegin(hAnn0, &hAnnRef0);
			doc.MarkAtnRefEnd(hAnnRef0);

			doc.NewSpan(&chpx);
			doc.AddContent(__X("\x0d\x0d"), 2);
		}

		//=====================================================
		// test case 5: �ڽ�ע�в�������
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("field in footnote");
			chpx.Clear(); doc.NewSpan(&chpx); 
			doc.AddContent(szMsg, wcslen(szMsg));

			doc.NewSpan(&chpx);
			doc.EnterFootnotes(FALSE);
			{	// ��ע1: ����
				papx.Clear();
				papx.AddIstd(0);
				doc.NewParagraph(&papx);
				chpx.Clear(); doc.NewSpan(&chpx);
				doc.AddFndEndRef();
				{
					WCHAR szMsg[] = __X("field in footnote: ");
					chpx.Clear(); doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}
				InsertField_Time();

				doc.NewSpan(&chpx);
				doc.AddContent(__X("\x0d"), 1);
			}
			doc.LeaveFootnotes();
			chpx.Clear(); doc.NewSpan(&chpx);
			doc.AddContent(__X("\x0d"), 1);
		}

		//=====================================================
		// test case 6: ��βע�в�������
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("field in endnote");
			chpx.Clear(); doc.NewSpan(&chpx); 
			doc.AddContent(szMsg, wcslen(szMsg));

			doc.NewSpan(&chpx);
			doc.EnterEndnotes(FALSE);
			{	// ��ע1: ����
				papx.Clear();
				papx.AddIstd(0);
				doc.NewParagraph(&papx);
				chpx.Clear();
				doc.NewSpan(&chpx);
				doc.AddFndEndRef();
				{
					WCHAR szMsg[] = __X("field in endnote: ");
					chpx.Clear(); doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}
				InsertField_Time();

				doc.NewSpan(&chpx);
				doc.AddContent(__X("\x0d"), 1);
			}
			doc.LeaveEndnotes();
			chpx.Clear(); doc.NewSpan(&chpx);
			doc.AddContent(__X("\x0d"), 1);
		}

		//=====================================================
		// test case 7: �������в���ϲ����� (�޷ָ�������)
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("���Ժϲ��ַ�(field without separator): ");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldBegin(49, FALSE);		// field type 31: date
		{
			// field data
			{
				WCHAR szMsg[] = __X("eq \\o(\\s\\up 5(");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("�ϲ�");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("),\\s\\do 2(");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("����");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("))");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
		}
		doc.MarkFieldEnd();

		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		//=====================================================
		// test case : ��עƴ�� (�޷ָ�������)
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("����ƴ��(field without separator): ");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldBegin(49, FALSE);
		{
			// field data
			{
				WCHAR szMsg[] = __X("EQ \\* jc2 \\* \"Font:����\" \\* hps10 \\o\\ad(\\s\\up 9(");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("jia");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("),��)");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
		}
		doc.MarkFieldEnd();
		doc.MarkFieldBegin(49, FALSE);
		{
			{
				WCHAR szMsg[] = __X("EQ \\* jc2 \\* \"Font:����\" \\* hps10 \\o\\ad(\\s\\up 9(");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("pin");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("),ƴ)");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
		}
		doc.MarkFieldEnd();
		doc.MarkFieldBegin(49, FALSE);
		{
			{
				WCHAR szMsg[] = __X("EQ \\* jc2 \\* \"Font:����\" \\* hps10 \\o\\ad(\\s\\up 9(");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("yin");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("),��)");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
		}
		doc.MarkFieldEnd();

		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		//=====================================================
		// test case : �������в���ϲ����� (�޷ָ�������)
		doc.NewParagraph(&papx);
		{
			// ����
			WCHAR szMsg[] = __X("���Դ�Ȧ�ַ�(field without separator): ");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldBegin(49, FALSE);
		{
			// field data
			{
				WCHAR szMsg[] = __X("eq \\o\\ac(��,");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("��");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X(")");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
		}
		doc.MarkFieldEnd();
		doc.MarkFieldBegin(49, FALSE);
		{
			// field data
			{
				WCHAR szMsg[] = __X("eq \\o\\ac(��,");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X("Ȧ");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
			{
				WCHAR szMsg[] = __X(")");
				doc.NewSpan(&chpx);
				doc.AddContent(szMsg, wcslen(szMsg));
			}
		}
		doc.MarkFieldEnd();

		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		//=====================================================
		chpx.Clear();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		doc.Close();
		
	}
};


CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestField);
