/* -------------------------------------------------------------------------
//	�ļ���		��	testlist_nfc.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-11-29 17:39:54
//	��������	��	
//
//	$Id: testlist_nfc.cpp,v 1.1 2004/12/06 08:57:50 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

inline
LPCWSTR GetNFCName(UINT nfc)
{
	static LPCWSTR szNFCCode[] =
	{
		__X("nfcArabic		"),
		__X("nfcUCRoman		"),
		__X("nfcLCRoman		"),
		__X("nfcUCLetter	"),
		__X("nfcLCLetter	"),
		__X("nfcOrdinal		"),
		__X("nfcCardtext	"),
		__X("nfcOrdtext		"),
		__X("nfcHex			"),
		__X("nfcChiManSty	"),
		__X("nfcDbNum1		"),
		__X("nfcDbNum2		"),
		__X("nfcAiueo		"),
		__X("nfcIroha		"),
		__X("nfcDbChar		"),
		__X("nfcSbChar		"),
		__X("nfcDbNum3		"),
		__X("nfcDbNum4		"),
		__X("nfcCirclenum	"),
		__X("nfcDArabic		"),
		__X("nfcDAiueo		"),
		__X("nfcDIroha		"),
		__X("nfcArabicLZ	"),
		__X("nfcBullet		"),
		__X("nfcGanada		"),
		__X("nfcChosung		"),
		__X("nfcGB1			"),
		__X("nfcGB2			"),
		__X("nfcGB3			"),
		__X("nfcGB4			"),
		__X("nfcZodiac1		"),
		__X("nfcZodiac2		"),
		__X("nfcZodiac3		"),
		__X("nfcTpeDbNum1	"),
		__X("nfcTpeDbNum2	"),
		__X("nfcTpeDbNum3	"),
		__X("nfcTpeDbNum4	"),
		__X("nfcChnDbNum1	"),
		__X("nfcChnDbNum2	"),
		__X("nfcChnDbNum3	"),
		__X("nfcChnDbNum4	"),
		__X("nfcKorDbNum1	"),
		__X("nfcKorDbNum2	"),
		__X("nfcKorDbNum3	"),
		__X("nfcKorDbNum4	"),
		__X("nfcHebrew1		"),
		__X("nfcArabic1		"),
		__X("nfcHebrew2		"),
		__X("nfcArabic2		"),
		__X("nfcHindi1		"),
		__X("nfcHindi2		"),
		__X("nfcHindi3		"),
		__X("nfcHindi4		"),
		__X("nfcThai1		"),
		__X("nfcThai2		"),
		__X("nfcThai3		"),
		__X("nfcViet1		"),
		__X("nfcNumInDash	"),
		__X("nfcLCRus		"),
		__X("nfcUCRus		"),
	};
	return nfc < countof(szNFCCode) ? szNFCCode[nfc] : __X("unknown");
}

// -------------------------------------------------------------------------

class TestListNfc : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestListNfc);
		CPPUNIT_TEST(testListsNfc);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testListsNfc()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_list_nfc_.doc"), &spRootStg));
		
		KDWDocument docu;
		docu.NewDocument(spRootStg);
		
		KDWPropBuffer sepx;
		docu.NewSection(&sepx);
		
		KDWListTable& lists = docu.GetListTable();
		
		for (int nfc = 0; nfc < mso_nfcMax+4; ++nfc)
		{
			KDWList list = lists.NewList(9);
			KDWListFormatOverride lfo = lists.NewListFormatOverride(list);
			KDWListLevel level0 = list.GetLevel(0);
			level0.SetXst(__X("%1"));
			level0.SetNfc((NFC)nfc);
			
			KDWPropBuffer papx;
			KDWPropBuffer chpx;
			chpx.AddPropFix(sprmCFBold, TRUE);
			papx.AddIstd(0);
			papx.AddPropFix(sprmPIlfo, lfo.GetIndex());
			papx.AddPropFix(sprmPIlvl, 0);
			
			docu.NewParagraph(&papx);
			docu.NewSpan(&chpx);
			LPCWSTR pwcs = GetNFCName(nfc);
			docu.AddContent(pwcs, wcslen(pwcs));
			docu.AddContent(__X("\x0d"), 1);
			
			docu.NewParagraph(&papx);
			docu.NewSpan(&chpx);
			docu.AddContent(__X("\x0d"), 1);
			
			papx.Clear();
			papx.AddIstd(0);
			docu.NewParagraph(&papx);
			docu.NewSpan(&chpx);
			docu.AddContent(__X("\x0d"), 1);
		}
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestListNfc);

// -------------------------------------------------------------------------
//	$Log: testlist_nfc.cpp,v $
//	Revision 1.1  2004/12/06 08:57:50  xushiwei
//	*** empty log message ***
//	
//	
