/* -------------------------------------------------------------------------
//	�ļ���		��	testole.cpp
//	������		��	����
//	����ʱ��	��	2004-9-3 4:52:57 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testole2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestOle2Eff : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestOle2Eff);
		CPPUNIT_TEST(testLine);
		CPPUNIT_TEST(testFill);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testLine()
	{
		ks_stdptr<IStorage> spRootStg;
		
		VERIFY_OK(
			CreateDocfile(testPath("_oleeff_line_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blipLineFill = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWBlip blip = 
			NewBlip(docu, testPath("../docrw/datalayer.png"), msoblipPNG);
		
		KDWShapeOPT opt;
		opt.AddPropFix(msopt_lineType, msolinePattern);//MSOLINETYPE,�����ߵ���䷽ʽ��
		opt.AddPropFix(msopt_lineWidth, 0x0129A8*2);//�����ߵĿ��ȡ�
		opt.AddPropFix(msopt_lineFillBlip, blipLineFill);
		opt.AddPropBool(msopt_fLine, TRUE);//�Ƿ����ߡ�
		opt.AddPropBool(msopt_fArrowheadsOK, TRUE);
		opt.AddPropFix(msopt_pib, blip);
		
		//
		//  ע�⣺
		//	û�е���.Persist������Ole���󣨵�Ȼ�⽫����Ole��������ݲ���ȷ����
		//	��Ҫ����.Clear���������򽫴����ڴ�й©��
		//
		KDWShapeAnchor anchor;
		anchor.xaLeft = 0x168;
		anchor.yaTop = 0x1D4;
		anchor.xaRight = 0x16EC;
		anchor.yaBottom = 0x1818;
		anchor.xRel = mso_spaXRelText;
		anchor.yRel = mso_spaYRelText;
		anchor.wrapMode = mso_spaWrDefault;
		anchor.wrapType = mso_spaWrtBoth;
		anchor.fAnchorLock = FALSE;
		docu.AddOleEmbed(anchor, __X("PBrush"))
			.Persist(
				SmartOleStg2(
					testPath("../docrw/ole/ole_emb.doc"),
					__X("_1154266423")))//?
			.SetProperties(opt).SetShapeType(msosptRectangle);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_oleeff_fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		KDWBlip blip = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWBlip blipFill = 
			NewBlip(docu, testPath("../docrw/datalayer.png"), msoblipPNG);
		
		KDWShapeOPT opt;
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, 2);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill);
		opt.AddPropFix(msopt_pib, blip);
		
		//
		// ע�⣺
		//	û�е���.Persist������Ole���󣨵�Ȼ�⽫����Ole��������ݲ���ȷ����
		//	��Ҫ����.Clear���������򽫴����ڴ�й©��
		//
		KDWShapeAnchor anchor;
		anchor.xaLeft = 0x168;
		anchor.yaTop = 0x1D4;
		anchor.xaRight = 0x6EC;
		anchor.yaBottom = 0x818;
		anchor.xRel = mso_spaXRelText;
		anchor.yRel = mso_spaYRelText;
		anchor.wrapMode = mso_spaWrDefault;
		anchor.wrapType = mso_spaWrtBoth;
		anchor.fAnchorLock = FALSE;
		docu.AddOleEmbed(anchor, __X("PBrush"))
			.Persist(
				SmartOleStg2(
					testPath("../docrw/ole/ole_emb.doc"),
					__X("_1154266423")))
			.SetProperties(opt);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestOle2Eff);

// -------------------------------------------------------------------------
