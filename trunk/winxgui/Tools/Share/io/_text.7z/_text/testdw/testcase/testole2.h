/* -------------------------------------------------------------------------
//	�ļ���		��	testole2.h
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-15 19:52:51
//	��������	��	
//
// -----------------------------------------------------------------------*/
#ifndef __TESTOLE2_H__
#define __TESTOLE2_H__

#ifndef __KFC_COM_OLE_H__
#include <kfc/com/ole.h>
#endif

#ifndef __TESTCOMMON_H__
#include "testcommon.h"
#endif

// -------------------------------------------------------------------------

inline
STDMETHODIMP OpenDocfile(
						 IN LPCWSTR szFile,
						 OUT IStorage** ppRootStg)
{
	WCHAR szDocFile[_MAX_PATH];
	return StgOpenStorage(
		GetSystemIniPath(szDocFile, szFile),
		NULL,
		STGM_READ|STGM_TRANSACTED,
		0,
		0,
		ppRootStg);
}

// -------------------------------------------------------------------------

class SmartOleStg
{
private:
	IStorage* m_pRootStg;
	
public:
	SmartOleStg(LPCWSTR szStgFile)
	{
		m_pRootStg = NULL;
		OpenDocfile(szStgFile, &m_pRootStg);
	}
	~SmartOleStg()
	{
		if (m_pRootStg)
			m_pRootStg->Release();
	}
	operator IStorage*() const
	{
		return m_pRootStg;
	}
};

class SmartOleStg2
{
private:
	IStorage* m_pRootStg;
	IStorage* m_pObjectPool;
	IStorage* m_pOleStg;
	
public:
	SmartOleStg2(LPCWSTR szDocFile, LPCWSTR szOleID)
	{
		m_pRootStg = NULL;
		m_pObjectPool = NULL;
		m_pOleStg = NULL;
		OpenDocfile(szDocFile, &m_pRootStg);
		if (m_pRootStg)
		{
			m_pRootStg->OpenStorage(
				__X("ObjectPool"), NULL, STGM_READ|STGM_SHARE_EXCLUSIVE, 0, 0, &m_pObjectPool);
			if (m_pObjectPool)
			{
				m_pObjectPool->OpenStorage(
					szOleID, NULL, STGM_READ|STGM_SHARE_EXCLUSIVE, 0, 0, &m_pOleStg);
			}
		}
	}
	~SmartOleStg2()
	{
		if (m_pOleStg)
			m_pOleStg->Release();
		if (m_pObjectPool)
			m_pObjectPool->Release();
		if (m_pRootStg)
			m_pRootStg->Release();
	}
	operator IStorage*() const
	{
		return m_pOleStg;
	}
};

// -------------------------------------------------------------------------

#endif /* __TESTOLE2_H__ */
