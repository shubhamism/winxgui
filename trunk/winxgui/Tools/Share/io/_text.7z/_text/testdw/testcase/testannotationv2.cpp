/* -------------------------------------------------------------------------
//	�ļ���		��	testatn2.cpp
//	������		��	����
//	����ʱ��	��	2005-10-24 14:23:20
//	��������	��	
//	$Id: testannotationv2.cpp,v 1.1 2005/10/26 01:21:43 wangdong Exp $
// -----------------------------------------------------------------------*/
#include "stdafx.h"
#if defined(__MSO_DOM_TEXTV2_H__)
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------
class TestAnnotation : public TestCase
{
	CPPUNIT_TEST_SUITE(TestAnnotation);
		CPPUNIT_TEST(testAnnotation);
		CPPUNIT_TEST(testSectionEnd);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testSectionEnd()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_annsectendv2_.doc"), &spRootStg));
		
		KDWDocument doc;
		doc.NewDocument(spRootStg);
		KDWPropBuffer sepx;
		doc.NewSection(&sepx);

		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);

		//=============================================
		// �û���
		UINT uID_0, uID_1, uID_2;
		{
			KDWUsers& theUNI = doc.GetAnnotationUsers();//ȡ���ĵ����û�������
			UserNameInfo uni_0 = {__X("dongbo"), __X("db")};
			theUNI.Add(uni_0, &uID_0);//���ĵ����û������������û������õ��û�ID ->uID_0��			

			UserNameInfo uni_1 = {__X("John Doe"), __X("JDm")};
			theUNI.Add(uni_1, &uID_1);//���ĵ����û������������û������õ��û�ID ->uID_1��

			UserNameInfo uni_2 = {__X("Jane Doe"), __X("JDf")};
			theUNI.Add(uni_2, &uID_2);//���ĵ����û������������û������õ��û�ID ->uID_2��
		}
	
		//=============================================
		// ��עʱ��
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;

		//=============================================
		// ��ע��
#define MAKE_ATNBODY(text) \
		do {WCHAR szAnn[] = L##text;	\
			doc.NewParagraph(&papx); \
			doc.NewSpan(&chpx); \
			doc.AddContent(szAnn, wcslen(szAnn)); } while(0)

		//=============================================
		// ����
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText[] = __X("����1����ĳһ������ע��ABC");

			doc.AddContent(szText, wcslen(szText));

			doc.EnterAnnotation(uID_0, dttm, 0);
				MAKE_ATNBODY("AN0\x0d");
			doc.LeaveAnnotation();

			doc.AddContent(__X("\x0d"), 1);
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����2����ĳһ����������ע��A");
			WCHAR szText_1[] = __X("BCD");
			WCHAR szText_2[] = __X("E\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));
			doc.AddContent(szText_1, wcslen(szText_1));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_1));
				MAKE_ATNBODY("AN0 ext\x0d");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_2, wcslen(szText_2));
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����3����ע��Ƕ�ף�A");
			WCHAR szText_1[] = __X("BC");
			WCHAR szText_2[] = __X("1234");
			WCHAR szText_3[] = __X("DE");
			WCHAR szText_4[] = __X("F\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));

			doc.AddContent(szText_1, wcslen(szText_1));
			doc.AddContent(szText_2, wcslen(szText_2));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_2));
					MAKE_ATNBODY("ATN �ڲ�");
			doc.LeaveAnnotation();

			doc.EnterAnnotation(uID_0, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + 1);
					MAKE_ATNBODY("ATN �в�");
			doc.LeaveAnnotation();
			
			doc.AddContent(szText_3, wcslen(szText_3));
			doc.EnterAnnotation(uID_0, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + wcslen(szText_3) + 2);
					MAKE_ATNBODY("ATN ���");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_4, wcslen(szText_4));
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����4����ע���ص���A");
			WCHAR szText_1[] = __X("BC");
			WCHAR szText_2[] = __X("1234");
			WCHAR szText_3[] = __X("DE");
			WCHAR szText_4[] = __X("F\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));

			doc.AddContent(szText_1, wcslen(szText_1));
			doc.AddContent(szText_2, wcslen(szText_2));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_1) + wcslen(szText_2));
				MAKE_ATNBODY("��һ����ע��");
			doc.LeaveAnnotation();

			doc.AddContent(szText_3, wcslen(szText_3));

			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_2) + wcslen(szText_3) + 1);
					MAKE_ATNBODY("�ڶ�����ע��");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_4, wcslen(szText_4));
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����5����ͬ��ע�˵���ע��A");
			WCHAR szText_1[] = __X("BC");
			WCHAR szText_2[] = __X("1234");
			WCHAR szText_3[] = __X("DE");
			WCHAR szText_4[] = __X("F\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));

			doc.AddContent(szText_1, wcslen(szText_1));
			doc.AddContent(szText_2, wcslen(szText_2));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_2));
					MAKE_ATNBODY("db");
			doc.LeaveAnnotation();

			doc.EnterAnnotation(uID_1, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + 1);
					MAKE_ATNBODY("JDm");
			doc.LeaveAnnotation();
			
			doc.AddContent(szText_3, wcslen(szText_3));
			doc.AddContent(szText_4, wcslen(szText_4));

			doc.EnterAnnotation(uID_2, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + wcslen(szText_3) + wcslen(szText_4) + 2);
					MAKE_ATNBODY("JDf");
			doc.LeaveAnnotation();
		}


		doc.NewSection(&sepx);
		doc.NewNullPapxParagraph();
		doc.NewNullChpxSpan();
		doc.AddContent(0x0d);


		doc.Close();

	}
	void testAnnotation()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_annotationv2_.doc"), &spRootStg));
		
		KDWDocument doc;
		doc.NewDocument(spRootStg);
		KDWPropBuffer sepx;
		doc.NewSection(&sepx);

		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);

		//=============================================
		// �û���
		UINT uID_0, uID_1, uID_2;
		{
			KDWUsers& theUNI = doc.GetAnnotationUsers();//ȡ���ĵ����û�������
			UserNameInfo uni_0 = {__X("dongbo"), __X("db")};
			theUNI.Add(uni_0, &uID_0);//���ĵ����û������������û������õ��û�ID ->uID_0��			

			UserNameInfo uni_1 = {__X("John Doe"), __X("JDm")};
			theUNI.Add(uni_1, &uID_1);//���ĵ����û������������û������õ��û�ID ->uID_1��

			UserNameInfo uni_2 = {__X("Jane Doe"), __X("JDf")};
			theUNI.Add(uni_2, &uID_2);//���ĵ����û������������û������õ��û�ID ->uID_2��
		}
	
		//=============================================
		// ��עʱ��
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;

		//=============================================
		// ��ע��
#define MAKE_ATNBODY(text) \
		do {WCHAR szAnn[] = L##text;	\
			doc.NewParagraph(&papx); \
			doc.NewSpan(&chpx); \
			doc.AddContent(szAnn, wcslen(szAnn)); } while(0)

		//=============================================
		// ����
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText[] = __X("����1����ĳһ������ע��ABC");

			doc.AddContent(szText, wcslen(szText));

			doc.EnterAnnotation(uID_0, dttm, 0);
				MAKE_ATNBODY("AN0\x0d");
			doc.LeaveAnnotation();

			doc.AddContent(__X("\x0d"), 1);
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����2����ĳһ����������ע��A");
			WCHAR szText_1[] = __X("BCD");
			WCHAR szText_2[] = __X("E\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));
			doc.AddContent(szText_1, wcslen(szText_1));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_1));
				MAKE_ATNBODY("AN0 ext\x0d");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_2, wcslen(szText_2));
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����3����ע��Ƕ�ף�A");
			WCHAR szText_1[] = __X("BC");
			WCHAR szText_2[] = __X("1234");
			WCHAR szText_3[] = __X("DE");
			WCHAR szText_4[] = __X("F\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));

			doc.AddContent(szText_1, wcslen(szText_1));
			doc.AddContent(szText_2, wcslen(szText_2));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_2));
					MAKE_ATNBODY("ATN �ڲ�");
			doc.LeaveAnnotation();

			doc.EnterAnnotation(uID_0, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + 1);
					MAKE_ATNBODY("ATN �в�");
			doc.LeaveAnnotation();
			
			doc.AddContent(szText_3, wcslen(szText_3));
			doc.EnterAnnotation(uID_0, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + wcslen(szText_3) + 2);
					MAKE_ATNBODY("ATN ���");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_4, wcslen(szText_4));
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����4����ע���ص���A");
			WCHAR szText_1[] = __X("BC");
			WCHAR szText_2[] = __X("1234");
			WCHAR szText_3[] = __X("DE");
			WCHAR szText_4[] = __X("F\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));

			doc.AddContent(szText_1, wcslen(szText_1));
			doc.AddContent(szText_2, wcslen(szText_2));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_1) + wcslen(szText_2));
				MAKE_ATNBODY("��һ����ע��");
			doc.LeaveAnnotation();

			doc.AddContent(szText_3, wcslen(szText_3));

			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_2) + wcslen(szText_3) + 1);
					MAKE_ATNBODY("�ڶ�����ע��");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_4, wcslen(szText_4));
		}
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);

			WCHAR szText_0[] = __X("����5����ͬ��ע�˵���ע��A");
			WCHAR szText_1[] = __X("BC");
			WCHAR szText_2[] = __X("1234");
			WCHAR szText_3[] = __X("DE");
			WCHAR szText_4[] = __X("F\x0d");

			doc.AddContent(szText_0, wcslen(szText_0));

			doc.AddContent(szText_1, wcslen(szText_1));
			doc.AddContent(szText_2, wcslen(szText_2));
			doc.EnterAnnotation(uID_0, dttm, wcslen(szText_2));
					MAKE_ATNBODY("db");
			doc.LeaveAnnotation();

			doc.EnterAnnotation(uID_1, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + 1);
					MAKE_ATNBODY("JDm");
			doc.LeaveAnnotation();
			
			doc.AddContent(szText_3, wcslen(szText_3));
			doc.EnterAnnotation(uID_2, dttm, 
				wcslen(szText_1) + wcslen(szText_2) + wcslen(szText_3) + 2);
					MAKE_ATNBODY("JDf");
			doc.LeaveAnnotation();

			doc.NewSpan(&chpx);
			doc.AddContent(szText_4, wcslen(szText_4));
		}


		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		doc.Close();
	}

};


CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestAnnotation);

#endif
// -------------------------------------------------------------------------
//	$Log: testannotationv2.cpp,v $
//	Revision 1.1  2005/10/26 01:21:43  wangdong
//	�������µ���ע��APIģ�͡�
//	
