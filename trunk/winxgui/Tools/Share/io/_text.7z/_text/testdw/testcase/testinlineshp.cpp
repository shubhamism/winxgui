/* -------------------------------------------------------------------------
//	�ļ���		��	testembdrawing.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-12 9:26:45
//	��������	��	
//
//	$Id: testinlineshp.cpp,v 1.5 2005/07/01 02:43:47 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestEmbShape : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestEmbShape);
		CPPUNIT_TEST(testInlineShapeInTable);
		CPPUNIT_TEST(testBasic);
		CPPUNIT_TEST(testHdrftrEmb);
		CPPUNIT_TEST(testEmbSimple);
		CPPUNIT_TEST(testEmbPic);
		CPPUNIT_TEST(testEmbPicFill);
		CPPUNIT_TEST(testEmbPicWithFill);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	/** bug# 15447
	������
		��������Ƕ������ѡͼ�Σ������wps�ļ�����word�򿪣�������
	���ֲ��裺
		1.�½�һ��wps�ĵ���
		2.����һ����
		3.����һ�����ߣ���ʽ��Ƕ���ͣ�Ƕ�뵽����Ԫ����
		4.�����*.wps
		5.��wordxp�򿪸��ļ�������word2003������
	�����
		��������wordxp������˵��������ԭ��
	*/
	void testInlineShapeInTable()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_intable_.doc"), &spRootStg));
		
		KDWDocument docu;
		docu.NewDocument(spRootStg);
		docu.NewNullSepxSection();

		KDWRowTablePr tblPr;
		KDWCellPr cellPr;
		cellPr.tcWidth = 1720;

		docu.rowtbl_StartTable();
		{
			docu.rowtbl_NewRow(&tblPr);
			docu.rowtbl_NewCell(cellPr);

			docu.NewNullPapxParagraph();
			docu.NewNullChpxSpan();

			KDWShapeOPT optUDef;
			optUDef.AddPropFix(msopt_posrelh, msoposrelhCharacter);
			optUDef.AddPropFix(msopt_posrelv, msoposrelvLine);
			optUDef.AddPropBool(msopt_fInlineShape, TRUE);
			docu.AddInlineShape(0x4EC, 0x618, FALSE)
				.SetShapeType(msosptLine)
				.SetUDefProperties(optUDef);

			docu.AddContent(0x0d);
		}
		docu.rowtbl_EndTable();
		
		docu.NewNullPapxParagraph();
		docu.NewNullChpxSpan();
		docu.AddContent(0x0d);
		docu.Close();
	}

	/** bug# 15447 (����)
	������
		�������msopt_posrelh, msopt_posrelv��word�Ͳ���Ϊ��InlineShape�ˡ�
	ԭ��
		InlineShape������InlinePicture������AddInlinePicture����Ҫ����fInlineShape���ԡ�
	*/
	void testBasic()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_basic_.doc"), &spRootStg));

		KDWDocument docu;
		docu.NewDocument(spRootStg);
		docu.NewNullSepxSection();
		docu.NewNullPapxParagraph();
		docu.NewNullChpxSpan();
		
		KDWShapeOPT optUDef;
		optUDef.AddPropFix(msopt_posrelh, msoposrelhCharacter);
		optUDef.AddPropFix(msopt_posrelv, msoposrelvLine);
		optUDef.AddPropBool(msopt_fInlineShape, TRUE);
		docu.AddInlineShape(0x4EC, 0x618, FALSE)
			.SetShapeType(msosptLine)
			.SetUDefProperties(optUDef);

		docu.AddContent(0x0d);		
		docu.Close();
	}

	void testHdrftrEmb()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_hdrftr_shape_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		//�༭����ҳ��ҳü��
		docu.EnterHeaderFooter(DW_ODD_HEADER);
		{
			docu.NewParagraph(&papx);
			docu.NewSpan(&chpx);
			{
				KDWShapeOPT optUDef;
				optUDef.AddPropBool(msopt_fInlineShape, TRUE);
				KDWShape txbx = 
					docu.AddInlineShape(0x4EC, 0x618, FALSE)
						.SetUDefProperties(optUDef)
						.SetShapeType(msosptTextBox);
				docu.EnterTextBox(txbx);//�����ı���
				{
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(__X("�ı���\x0d"), 4);
				}
				docu.LeaveTextBox();//�뿪�ı���
			}
			{
				KDWShapeOPT optUDef;
				optUDef.AddPropBool(msopt_fInlineShape, TRUE);
				docu.AddInlineShape(0x4EC, 0x618, FALSE)
					.SetUDefProperties(optUDef)
					.SetShapeType(msosptLine);
			}
			docu.AddContent(0x0d);
		}
		docu.LeaveHeaderFooter();
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}

	void testEmbSimple()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_shape_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		
		{
			KDWShapeOPT optUDef;
			optUDef.AddPropBool(msopt_fInlineShape, TRUE);
			
			docu.AddInlineShape(0x4EC, 0x618, FALSE)
				.SetUDefProperties(optUDef)
				.SetShapeType(msosptLine);
		}

		{
			KDWBlip blipFill2 = 
				NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
			
			KDWShapeOPT opt;
			opt.AddPropBool(msopt_fillShape, TRUE);
			opt.AddPropBool(msopt_fFilled, TRUE);
			opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
			opt.AddPropFix(msopt_fillType, 2);
			opt.AddPropFix(msopt_fillColor, 0xFFECCC);
			opt.AddPropFix(msopt_fillBlip, blipFill2);
			
			KDWShapeOPT optUDef;
			optUDef.AddPropBool(msopt_fInlineShape, TRUE);

			docu.AddInlineShape(0x9EC, 0xB18, FALSE)
				.SetShapeType(msosptRectangle)
				.SetUDefProperties(optUDef)
				.SetProperties(opt);
		}
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
	
	void testEmbPic()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_pic_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWBlip blip2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		opt.AddPropFix(msopt_pibFlags, 2);
		opt.AddPropVar(msopt_pibName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_pib, blip2);
		
		KDWShapeOPT optUDef;
		optUDef.AddPropBool(msopt_fInlineShape, TRUE);
		
		docu.AddInlineShape(0x4EC, 0x618, FALSE)
			.SetProperties(opt)
			.SetUDefProperties(optUDef)
			.SetShapeType(msosptRectangle);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testEmbPicFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, 2);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill2);

		KDWShapeOPT optUDef;
		optUDef.AddPropBool(msopt_fInlineShape, TRUE);
		
		docu.AddInlineShape(0x4EC, 0x618, FALSE)
			.SetShapeType(msosptRectangle)
			.SetProperties(opt)
			.SetUDefProperties(optUDef);
		
		chpx.Clear();
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}

	void testEmbPicWithFill()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dgemb3_pic2fill_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		KDWBlip blip2 = 
			NewBlip(docu, testPath("../docrw/datalayer.png"), msoblipPNG);
		
		KDWBlip blipFill2 = 
			NewBlip(docu, testPath("../docrw/ktsj.jpg"), msoblipJPEG);
		
		KDWShapeOPT opt;
		KDWShapeOPT optUDef;
		optUDef.AddPropBool(msopt_fInlineShape, TRUE);
		
		opt.AddPropFix(msopt_pibFlags, 2);
		opt.AddPropVar(msopt_pibName, __X("datalayer"), 10*2, 1);
		opt.AddPropFix(msopt_pib, blip2);
		
		opt.AddPropBool(msopt_fillShape, TRUE);
		opt.AddPropBool(msopt_fFilled, TRUE);
		opt.AddPropVar(msopt_fillBlipName, __X("ktsj"), 10*2, 1);
		opt.AddPropFix(msopt_fillType, 2);
		opt.AddPropFix(msopt_fillColor, 0xFFECCC);
		opt.AddPropFix(msopt_fillBlip, blipFill2);

		docu.AddInlineShape(0x20EC, 0x1018, FALSE)
			.SetProperties(opt)
			.SetShapeType(msosptEllipse)
			.SetUDefProperties(optUDef);
		
		docu.AddContent(__X("\x0d"), 1);
		
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestEmbShape);

// -------------------------------------------------------------------------
// $Log: testinlineshp.cpp,v $
// Revision 1.5  2005/07/01 02:43:47  xushiwei
// bug# 15447 ����
//
// Revision 1.4  2005/06/30 06:47:35  xushiwei
// ����InlineShape��򻯵İ�����
//
// Revision 1.3  2005/03/11 09:08:46  duanyuluo
// ҳüҳ��Ƕ��ʽ����
//
// Revision 1.2  2004/11/18 02:24:50  xushiwei
// *** empty log message ***
//
// Revision 1.1  2004/11/18 02:22:21  xushiwei
// *** empty log message ***
//
