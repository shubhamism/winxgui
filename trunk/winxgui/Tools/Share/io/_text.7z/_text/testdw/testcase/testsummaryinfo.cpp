/* -------------------------------------------------------------------------
//	�ļ���		��	testsummaryinfo.cpp
//	������		��	����
//	����ʱ��	��	2004-11-12 11:46:35 AM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestSummaryInfo : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestSummaryInfo);
		CPPUNIT_TEST(testSummary);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testSummary()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_summaryinfo_.doc"), &spRootStg));

		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);

		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("text"), 4);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		IPropertySetStorage* pPropSetStg;
		pPropSetStg = doc.GetPropertySetStorage();

		IPropertyStorage *pPropStg = NULL;
		HRESULT hr = pPropSetStg->Create( FMTID_SummaryInformation, NULL, PROPSETFLAG_DEFAULT, 
								  STGM_CREATE|STGM_READWRITE|STGM_SHARE_EXCLUSIVE,
								  &pPropStg );
		if( FAILED(hr) ) 
			REPORT("Failed IPropertySetStorage::Create");

		PROPSPEC propspec;
		PROPVARIANT propvarWrite;
		PropVariantInit(&propvarWrite);

		// ����
        propspec.ulKind = PRSPEC_PROPID;
        propspec.propid = PIDSI_AUTHOR;

        propvarWrite.vt = VT_LPSTR;
        propvarWrite.pszVal = "John Doe";

        hr = pPropStg->WriteMultiple( 1, &propspec, &propvarWrite, PID_FIRST_USABLE );
        if( FAILED(hr) )
			REPORT("Failed IPropertyStorage::WriteMultiple");

		// ����
        propspec.ulKind = PRSPEC_PROPID;
        propspec.propid = PIDSI_TITLE;

        propvarWrite.vt = VT_LPSTR;
        propvarWrite.pszVal = "Test summaryinfo";

        hr = pPropStg->WriteMultiple( 1, &propspec, &propvarWrite, PID_FIRST_USABLE );
        if( FAILED(hr) )
			REPORT("Failed IPropertyStorage::WriteMultiple");

		pPropStg->Release();
		pPropStg = NULL;

		doc.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestSummaryInfo);


// -------------------------------------------------------------------------
