/* -------------------------------------------------------------------------
//	�ļ���		��	testfootendnotes.cpp
//	������		��	����
//	����ʱ��	��	2004-9-3 4:36:34 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestFootEndnotes : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestFootEndnotes);
		CPPUNIT_TEST(testFootnote);
		CPPUNIT_TEST(testFootnotesEndNotes);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testFootnote()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_footnote_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("text"), 4);
		
		doc.NewSpan(&chpx);
		doc.EnterFootnotes(FALSE);
		{
			doc.NewParagraph(&papx);
			doc.NewSpan(&chpx);
			doc.AddFndEndRef();

			doc.NewSpan(&chpx);
			doc.AddContent(__X("FN\x0d"), 3);
		}
		doc.LeaveFootnotes();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);
		doc.Close();
	}

	void testFootnotesEndNotes()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_footendnotes_.doc"), &spRootStg));
		
		KDWDocument doc;

		//==========================================================
		// style sheet
		KDWPropBuffer userChp;
		KDWPropBuffer userPap;

		// Ĭ�϶�������
		KDWStyle styNormalChar;
		doc.GetStyleSheet()//��ȡ�ĵ�����ʽ����
			.NewStyle(
			stiNormalChar,
			__X("Ĭ�϶�������"),
			mso_sgcCharacter,
			&styNormalChar);//�½���ʽstyNormalChar��
		userChp.Clear();//���userChp�е������ַ����ԡ�
		styNormalChar.SetSprmList(mso_sgcCharacter, &userChp);//��userChp���ӵ�styNormalChar��ʽ�С�

		// ��ע����
		KDWStyle styFtnRef;
		doc.GetStyleSheet().NewStyle(
			stiFtnRef,
			__X("��ע����"),
			mso_sgcCharacter,
			&styFtnRef);//ȡ���ĵ��ķ��������½�styFtnRefΪ����ע���á���ʽ��
		styFtnRef.SetBaseStyle(styNormalChar.GetIndex());//����styFtnRef�Ļ���ʽΪ��Ĭ�϶������塱��
	//	styFtnRef.SetNextStyle(styFtnRef.GetIndex());

		userChp.Clear();
		userChp.AddPropFix(sprmCIss, 1);//�ϱ�
		styFtnRef.SetSprmList(mso_sgcCharacter, &userChp);//��userChp���ӵ�styFtnRef��ʽ�С�

		// ��ע�ı�
		KDWStyle styFtnText;
		doc.GetStyleSheet().NewStyle(
			stiFtnText,
			__X("��ע�ı�"),
			mso_sgcParagraph,
			&styFtnText);
		styFtnText.SetBaseStyle(0);//����styFtnText�Ļ���ʽ��

		userPap.Clear();
		userPap.AddIstd(styFtnText.GetIndex());
		userPap.AddPropFix(sprmPJc, mso_jcLeftJustify);//�μ�enum JC��
		userPap.AddPropFix(sprmPFUsePgsuSettings, 0);
		styFtnText.SetSprmList(mso_sgcParagraph, &userPap);

		userChp.Clear();
		userChp.AddPropFix(sprmCHps, 0x12);//�����ֺ�ֵ��
		userChp.AddPropFix(sprmCHpsBi, 0x12);
		styFtnText.SetSprmList(mso_sgcCharacter, &userChp);

		// βע����
		KDWStyle styEdnRef;
		doc.GetStyleSheet().NewStyle(
			stiEdnRef,
			__X("βע����"),
			mso_sgcCharacter,
			&styEdnRef);
		userChp.Clear();
		userChp.AddPropFix(sprmCIss, 1);
		styEdnRef.SetBaseStyle(styNormalChar.GetIndex());
		styEdnRef.SetSprmList(mso_sgcCharacter, &userChp);

		// βע�ı�
		KDWStyle styEdnText;
		doc.GetStyleSheet().NewStyle(
			stiEdnText,
			__X("βע�ı�"),
			mso_sgcParagraph,
			&styEdnText);
		styEdnText.SetBaseStyle(0);

		userPap.Clear();
		userPap.AddIstd(styEdnText.GetIndex());
		userPap.AddPropFix(sprmPJc, 0);
		userPap.AddPropFix(sprmPFUsePgsuSettings, 0);
		styEdnText.SetSprmList(mso_sgcParagraph, &userPap);

		userChp.Clear();
		styEdnText.SetSprmList(mso_sgcCharacter, &userChp);

		//==========================================================

		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;

		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);

		//=============================================
	{
		// ��ע1
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("footnote1"), 9);
		
		chpx.Clear();
		chpx.AddPropFix(sprmCIstd, styFtnRef.GetIndex());
		doc.NewSpan(&chpx);
		doc.EnterFootnotes(FALSE);//�����עβע��
		{	// ��ע1: ����
			papx.Clear();
			papx.AddIstd(styFtnText.GetIndex());
			doc.NewParagraph(&papx);

			chpx.Clear();
			chpx.AddPropFix(sprmCIstd, styFtnRef.GetIndex());
			doc.NewSpan(&chpx);
			doc.AddFndEndRef();

			chpx.Clear();
			doc.NewSpan(&chpx);
			doc.AddContent(__X("FN1\x0d"), 4);
		}
		doc.LeaveFootnotes();//�뿪��ע��
		chpx.Clear();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		// ��ע2
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		doc.AddContent(__X("footnote2"), 9);

		doc.EnterFootnotes(TRUE);
		{	// ��ע2: ����
			papx.Clear();
			papx.AddIstd(styFtnText.GetIndex());
			doc.NewParagraph(&papx);

			chpx.Clear();
			chpx.AddPropFix(sprmCIstd, styFtnRef.GetIndex());
			doc.NewSpan(&chpx);
			doc.AddFndEndRef();
			doc.AddContent(__X("userfefine"), 10);

			chpx.Clear();
			doc.NewSpan(&chpx);
			doc.AddContent(__X("FN2\x0d"), 4);
		}
		doc.LeaveFootnotes();

		// ��ע2: ����
		chpx.Clear();
		chpx.AddPropFix(sprmCIstd, styFtnRef.GetIndex());
		doc.NewSpan(&chpx);
		doc.AddContent(__X("userfefine"), 10);

		chpx.Clear();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		// βע1
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("endnote1"), 8);

		// βע1: ����
		chpx.Clear();
		chpx.AddPropFix(sprmCIstd, styEdnRef.GetIndex());
		doc.NewSpan(&chpx);
		doc.EnterEndnotes(FALSE);
		{	// βע1: ����
			papx.Clear();
			papx.AddIstd(styEdnText.GetIndex());
			doc.NewParagraph(&papx);

			chpx.AddPropFix(sprmCIstd, styEdnRef.GetIndex());
			doc.NewSpan(&chpx);
			doc.AddFndEndRef();

			chpx.Clear();
			doc.NewSpan(&chpx);
			doc.AddContent(__X(" EN1\x0d"), 5);
		}
		doc.LeaveEndnotes();
		chpx.Clear();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

		// βע2
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("endnote2"), 8);

		doc.EnterEndnotes(TRUE);
		{	// βע2: ����
			papx.Clear();
			papx.AddIstd(styEdnText.GetIndex());
			doc.NewParagraph(&papx);

			chpx.Clear();
			chpx.AddPropFix(sprmCIstd, styEdnRef.GetIndex());
			doc.NewSpan(&chpx);
			doc.AddFndEndRef();
			doc.AddContent(__X("ednref"), 6);

			chpx.Clear();
			doc.NewSpan(&chpx);
			doc.AddContent(__X(" EN2\x0d"), 5);
		}
		doc.LeaveEndnotes();

		// βע2: ����
		chpx.Clear();
		chpx.AddPropFix(sprmCIstd, styEdnRef.GetIndex());
		doc.NewSpan(&chpx);
		doc.AddContent(__X("ednref"), 6);

		chpx.Clear();
		doc.NewSpan(&chpx);
		doc.AddContent(__X("\x0d"), 1);

	}

		// ====================================================

		doc.Close();
	}

};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestFootEndnotes);


// -------------------------------------------------------------------------
