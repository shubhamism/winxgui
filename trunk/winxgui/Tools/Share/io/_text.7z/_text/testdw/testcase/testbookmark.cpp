/* -------------------------------------------------------------------------
//	�ļ���		��	testbookmark.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:38:28
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestBookmark : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestBookmark);
		CPPUNIT_TEST(testBookmark);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testBookmark()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_bookmark_.doc"), &spRootStg));
		
		KDWDocument doc;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx1);
		doc.AddContent(__X("goodmoring\x0d"), 11);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx2);
		doc.AddContent(__X("wellcome\x0d"), 9);
		
		KDWBookmarks& bookmarks = doc.GetBookmarks();//��ȡ�ĵ�����ǩ��		
		bookmarks.NewBookmark(__X("good")/*��ǩ��*/, 0, 4);//�½���ǩ��
		bookmarks.NewBookmark(__X("well"), 11, 15);//�½���ǩ��
		
		doc.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestBookmark);

// -------------------------------------------------------------------------
