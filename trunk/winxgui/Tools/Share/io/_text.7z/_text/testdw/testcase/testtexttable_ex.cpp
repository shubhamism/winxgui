/* -------------------------------------------------------------------------
//	�ļ���		��	testtexttable_ex.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-27 14:17:25
//	��������	��	
//
//	$Id: testtexttable_ex.cpp,v 1.3 2004/12/30 08:23:20 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"
#include <mso/io/excel/reader.h>
#include <mso/io/word/xlstable/xlstable.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

void testInsertXlsTable(
						IN LPCWSTR szXlsFile,
						IN LPCWSTR szDocFile)
{
	ks_stdptr<IStorage> spRootStg;
	VERIFY_OK(
		CreateDocfile(szDocFile, &spRootStg));
	
	KDWDocument docu;
	KDWPropBuffer sepx;
	KDWPropBuffer papx;
	KDWPropBuffer chpx;
	papx.AddIstd(0);
	sepx.AddPropFix(sprmSXaPage, 12240*2);

	docu.NewDocument(spRootStg);
	docu.NewSection(&sepx);
	
	WCHAR szExcelFile[MAX_PATH];
	GetSystemIniPath(szExcelFile, szXlsFile);
	XlsWorkbook book(szExcelFile);
	XlsWorksheet sheet;
	book.get_Worksheet(0, &sheet);
	
	InsertTextTable(docu, sheet);
	
	docu.NewParagraph(&papx);
	docu.NewSpan(&chpx);
	docu.AddContent(0x0d);
	docu.Close();
}

#define testXls2DocFile(szXlsFile, szDocFile)								\
	testInsertXlsTable(														\
		testXlsPath(szXlsFile), testPath(szDocFile) )

// -------------------------------------------------------------------------

class TestXlsTable : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestXlsTable);
		CPPUNIT_TEST(testClipShapeOPT);
	//	CPPUNIT_TEST(testClip);
	//	CPPUNIT_TEST(testSample);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testClipShapeOPT()
	{
		testXls2DocFile("clipboard/shapeopt.xls", "_xlstbl_shapeopt_.doc");
	}
	void testClip()
	{
		testXls2DocFile("clipboard/1.xls", "_xlstbl_clip1_.doc");
		testXls2DocFile("clipboard/2.xls", "_xlstbl_clip2_.doc");
		testXls2DocFile("clipboard/3.xls", "_xlstbl_clip3_.doc");
	}
	void testSample()
	{
		testXls2DocFile("sample/2001TV��ҵ��Ԥ��.xls", "_xlstbl_2001TV��ҵ��Ԥ��_.doc");
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestXlsTable);

// -------------------------------------------------------------------------
//	$Log: testtexttable_ex.cpp,v $
//	Revision 1.3  2004/12/30 08:23:20  xushiwei
//	*** empty log message ***
//	
//	Revision 1.2  2004/12/27 09:10:19  xushiwei
//	������һ�²����ļ���Ŀ��
//	
//	Revision 1.1  2004/12/27 08:58:40  xushiwei
//	֧�ֽ�һ��Worksheetת��Ϊ���ֱ����롣
//	������ز��԰�����
//	
