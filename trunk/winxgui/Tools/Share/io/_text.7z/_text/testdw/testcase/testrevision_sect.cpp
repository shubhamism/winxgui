/* -------------------------------------------------------------------------
//	�ļ���		��	testrevision_sect.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-6 10:42:14
//	��������	��	
//
//	$Id: testrevision_sect.cpp,v 1.2 2004/12/08 02:11:24 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestRevision_Section : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestRevision_Section);
		CPPUNIT_TEST(testFormatChange);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testFormatChange()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revsect_fmtchg_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		SprmCPropRMarkExOprand oprand;
		oprand.dttmPropRMark = dttm;
		oprand.fPropRMark = 0x01;
		oprand.ibstPropRMark = usrid;
		sepx.AddPropVar(sprmSPropRMarkEx, &oprand, sizeof(oprand));
		sepx.AddPropFix(sprmSFPropRMarkEx, 0x01);
		
		sepx.AddPropFix(sprmSDxaLeft, 3600);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestRevision_Section);

// -------------------------------------------------------------------------
//	$Log: testrevision_sect.cpp,v $
//	Revision 1.2  2004/12/08 02:11:24  xushiwei
//	�û�KDWUsersʹ�õ�����
//	
//	Revision 1.1  2004/12/06 08:57:50  xushiwei
//	*** empty log message ***
//	
//	
