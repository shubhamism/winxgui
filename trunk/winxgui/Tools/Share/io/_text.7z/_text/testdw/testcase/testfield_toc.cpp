/* -------------------------------------------------------------------------
//	�ļ���		��	testfield_toc.cpp
//	������		��	����
//	����ʱ��	��	2004-9-3 4:46:09 PM
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestField_Toc : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestField_Toc);
		CPPUNIT_TEST(testFields_TOC);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	static void AddParaTab(
		KDWPropBuffer& papx)
	{
		INT16 dxa = 8296;
		TBD tbd;
		tbd.jc = mso_tbdRightTab;
		tbd.tlc = mso_tbdDottedLeader;
		tbd.reserved = 0;
		papx.AddTabStops(1, &dxa, &tbd);
	}

	void testFields_TOC()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_dt_fields_toc_.doc"), &spRootStg));
		
		KDWDocument doc;

		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;

		papx.AddIstd(0);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);

		AddParaTab(papx);
		doc.NewParagraph(&papx);

		doc.NewSpan(&chpx);

		// ��һ��field. type = 13
		doc.MarkFieldBegin(mso_fltTOC, FALSE);
		{
			// field code
			WCHAR szMsg[] = __X(" TOC \\o \"1-3\" \\h \\z \\u ");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldSeparator();
		{
			// �ڶ���field. type = 88
			doc.MarkFieldBegin(mso_fltHyperlink, FALSE);
			{
				// field code
				{
					WCHAR szMsg[] = __X(" ");
					doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}
				{
					WCHAR szMsg[] = __X("HYPERLINK \\l \"_Toc1\"");
					doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}
				{
					WCHAR szMsg[] = __X(" ");
					doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}
				{
				//	WCHAR szMsg[] = __X("\x01");
				//	doc.NewSpan(&chpx);
				//	doc.AddContent(szMsg, wcslen(szMsg));
				}
			}
			doc.MarkFieldSeparator();
			{
				{
					WCHAR szMsg[] = __X("Chapter 1 ��һ��");
					doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}
				{
					WCHAR szMsg[] = __X("\t");
					doc.NewSpan(&chpx);
					doc.AddContent(szMsg, wcslen(szMsg));
				}

				// ������field. type = 37
				doc.MarkFieldBegin(mso_fltPageRef, FALSE);
				{
					{
						WCHAR szMsg[] = __X("PAGEREF _Toc1 \\h");
						doc.NewSpan(&chpx);
						doc.AddContent(szMsg, wcslen(szMsg));
					}
					{
						WCHAR szMsg[] = __X("\x01");
						doc.NewSpan(&chpx);
						doc.AddContent(szMsg, wcslen(szMsg));
					}
				}
				doc.MarkFieldSeparator();
				{
					{
						WCHAR szMsg[] = __X("?");
						doc.NewSpan(&chpx);
						doc.AddContent(szMsg, wcslen(szMsg));
					}
				}
				doc.MarkFieldEnd();
			}
			doc.MarkFieldEnd();

			// field data
			WCHAR szMsg[] = __X("\x0d");
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		doc.MarkFieldEnd();
//		doc.NewSpan(&chpx);
//		doc.AddContent(__X("\x0d"), 1);

		//=====================================================

		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		{
			WCHAR szMsg[] = __X("First line after TOC. Ŀ¼���һ��\x0d");
			chpx.Clear();
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		papx.Clear();
		papx.AddIstd(0);
		papx.AddPropFix(sprmPOutLvl, 0);//��ټ���
		doc.NewParagraph(&papx);
		{ 
			CP cpBefore = doc.GetFcMax();
			KDWBookmarks& bookmarks = doc.GetBookmarks();//��ȡ�ĵ�����ǩ��		
			bookmarks.NewBookmark(__X("_Toc1")/*��ǩ��*/, cpBefore, cpBefore);//�½���ǩ��
			WCHAR szMsg[] = __X("Chapter 1 ��һ��\x0d");
			chpx.Clear();
			doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		{
			WCHAR szMsg[] = __X("��������\x0d");
			chpx.Clear(); doc.NewSpan(&chpx);
			doc.AddContent(szMsg, wcslen(szMsg));
		}


		doc.Close();
		
	}

};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestField_Toc);


// -------------------------------------------------------------------------
