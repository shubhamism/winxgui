/* -------------------------------------------------------------------------
//	�ļ���		��	testlist.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-8-8 15:36:02
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestLists : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestLists);
		CPPUNIT_TEST(testLists);
		CPPUNIT_TEST(testListNoUsedCheck);
		CPPUNIT_TEST(testLfo);
		CPPUNIT_TEST(testListApply2Pap);
		CPPUNIT_TEST(testListWord6);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	//
	// docwriter������δʹ�õ�list��⹤����������Կ����Ƿ���ȷ��
	//
	void testListNoUsedCheck()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_list_noused_check_.doc"), &spRootStg));
		
		KDWDocument docu;
		
		KDWListTable& lists = docu.GetListTable();
		
		// list - 1,2,3 ����2δʹ�á�
		KDWList list1 = lists.NewList(9);
		KDWList list2 = lists.NewList(9);
		KDWList list3 = lists.NewList(9);

		list1.GetLevel(0).SetXst(__X("%1")).SetNfc(mso_nfcUCRoman);
		list2.GetLevel(0).SetXst(__X("%1")).SetNfc(mso_nfcOrdinal);
		list3.GetLevel(0).SetXst(__X("%1")).SetNfc(mso_nfcCardtext);
		
		KDWListFormatOverride lfo1 = lists.NewListFormatOverride(list1);
		KDWListFormatOverride lfo3 = lists.NewListFormatOverride(list3);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx1;
		KDWPropBuffer papx2;
		KDWPropBuffer chpx;

		papx1.AddIstd(0);
		papx1.AddPropFix(sprmPIlfo, lfo1.GetIndex());
		papx1.AddPropFix(sprmPIlvl, 0);
		
		papx2.AddIstd(0);
		papx2.AddPropFix(sprmPIlfo, lfo3.GetIndex());
		papx2.AddPropFix(sprmPIlvl, 0);

		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx1);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		docu.NewParagraph(&papx1);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("b\x0d"), 2);
		
		docu.NewParagraph(&papx2);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		docu.NewParagraph(&papx2);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("b\x0d"), 2);

		docu.Close();		
	}

	// ������Ŀ���ǲ���Lfo�е�iStartAt���á�
	void testLfo()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_list_restart_.doc"), &spRootStg));
		
		KDWDocument docu;
		
		KDWListTable& lists = docu.GetListTable();
		KDWList list = lists.NewList(9);
		KDWListFormatOverride lfo = lists.NewListFormatOverride(list);
		KDWListLevel level0 = list.GetLevel(0);
		level0.SetXst(__X("%1"));
		
		KDWListFormatOverride lfo2 = lists.NewListFormatOverride(list);
		KDWList listOverride = lfo2.Override();
		listOverride.GetLevel(0).SetStartAt(100);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx1;
		KDWPropBuffer papx2;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;
		
		chpx1.AddPropFix(sprmCFBold, TRUE);
		chpx2.AddPropFix(sprmCCusColor, RGB(0xff,0,0));
		
		papx1.AddIstd(0);
		papx1.AddPropFix(sprmPIlfo, lfo.GetIndex());
		papx1.AddPropFix(sprmPIlvl, 0);
		
		papx2.AddIstd(0);
		papx2.AddPropFix(sprmPIlfo, lfo2.GetIndex());
		papx2.AddPropFix(sprmPIlvl, 0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx1);
		docu.NewSpan(&chpx1);
		docu.AddContent(__X("a\x0d"), 2);
		
		docu.NewParagraph(&papx2);
		docu.NewSpan(&chpx2);
		docu.AddContent(__X("bcd\x0d"), 4);

		docu.NewParagraph(&papx2);
		docu.NewSpan(&chpx2);
		docu.AddContent(__X("bcd\x0d"), 4);
		
		docu.Close();
	}

	void testLists()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_list_simple_.doc"), &spRootStg));
		
		KDWDocument docu;

		KDWListTable& lists = docu.GetListTable();//ȡ���ĵ����б���
		KDWList list = lists.NewList(9);
		KDWListLevel level0 = list.GetLevel(0);
		KDWListLevel level1 = list.GetLevel(1);
		KDWListLevel level2 = list.GetLevel(2);
		KDWListFormatOverride lfo = lists.NewListFormatOverride(list);

		level0.SetXst(__X("%1"));//����level0Ϊ��1�㡣
		level0.SetNfc(mso_nfcSbChar);//���õ�1��ı���ַ���ʽ��
		level1.SetXst(__X("%2"));
		level1.SetNfc(mso_nfcGB2);
		level2.SetXst(__X("%3"));
		level2.SetNfc(mso_nfcLCRoman);		

		
//--------------------------------------------------------------------------

		KDWPropBuffer papxlvl;

		papxlvl.AddPropFix(sprmPDxaLeft,    0x01a4);
		papxlvl.AddPropFix(sprmPDxaLeft1,   0xfe5c);
		BYTE byData0[] = {0x00, 0x01, 0xa4, 0x01, 0x06};
		papxlvl.AddPropVar(sprmPChgTabs, byData0, sizeof(byData0));
		papxlvl.AddPropFix(sprmPDxaLeftEx,  0x01a4);
		papxlvl.AddPropFix(sprmPDxaLeft1Ex, 0xfe5c);
		level0.SetPapx(&papxlvl);
		papxlvl.Clear();

		papxlvl.AddPropFix(sprmPDxaLeft,    0x0348);
		papxlvl.AddPropFix(sprmPDxaLeft1,   0xfe5c);
		BYTE byData1[] = {0x00, 0x01, 0x48, 0x03, 0x06};
		papxlvl.AddPropVar(sprmPChgTabs, byData1, sizeof(byData1));
		papxlvl.AddPropFix(sprmPDxaLeftEx,  0x0348);
		papxlvl.AddPropFix(sprmPDxaLeft1Ex, 0xfe5c);
		level1.SetPapx(&papxlvl);
		papxlvl.Clear();

		papxlvl.AddPropFix(sprmPDxaLeft,    0x04ec);
		papxlvl.AddPropFix(sprmPDxaLeft1,   0xfe5c);
		BYTE byData2[] = {0x00, 0x01, 0xec, 0x04, 0x06};
		papxlvl.AddPropVar(sprmPChgTabs, byData2, sizeof(byData2));
		papxlvl.AddPropFix(sprmPDxaLeftEx,  0x04ec);
		papxlvl.AddPropFix(sprmPDxaLeft1Ex, 0xfe5c);
		level2.SetPapx(&papxlvl);
		papxlvl.Clear();

//--------------------------------------------------------------------------

		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;
		KDWPropBuffer chpx2;		
		papx.AddIstd(0);
		papx.AddPropFix(sprmPIlfo, lfo.GetIndex());//���ö����������б�������
		papx.AddPropFix(sprmPIlvl, 0);//���ö��������ļ���
		papx.AddPropFix(sprmPDxaLeft,50);//���ö���������50��

		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);

		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx1);
		docu.AddContent(__X("����1\x0d"), 4);

		papx.AddPropFix(sprmPIlfo, lfo.GetIndex());
		papx.AddPropFix(sprmPIlvl, 1);
		papx.AddPropFix(sprmPDxaLeft,50);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx2);
		docu.AddContent(__X("����2\x0d"), 4);

		papx.AddPropFix(sprmPIlfo, lfo.GetIndex());
		papx.AddPropFix(sprmPIlvl, 0);
		papx.AddPropFix(sprmPDxaLeft,50);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx2);
		docu.AddContent(__X("����3\x0d"), 4);
		
		docu.Close();
	}

	// -------------------------------------------------------------------------	
	// ���ԣ�
	//	1. sprmPIlfo sprmPIlvlָ����LVLF��grpplPapx�뵱ǰPapx�Ĺ�ϵ��
	//	2. ����ʽ�м̳�sprmPIlfo sprmPIlvl�������
	void testListApply2Pap()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_list_apply2pap.doc"), &spRootStg));
		
		KDWDocument docu;

		KDWListTable& lists = docu.GetListTable();//ȡ���ĵ����б���
		KDWList list = lists.NewList(9);
		KDWListLevel level0 = list.GetLevel(0);
		KDWListLevel level1 = list.GetLevel(1);
		KDWListLevel level2 = list.GetLevel(2);
		KDWListFormatOverride lfo = lists.NewListFormatOverride(list);

		level0.SetXst(__X("%1"));//����level0Ϊ��1�㡣
		level0.SetNfc(mso_nfcSbChar);//���õ�1��ı���ַ���ʽ��
		
//--------------------------------------------------------------------------
		KDWPropBuffer papxlvl;

		papxlvl.AddPropFix(sprmPDxaLeft,    200);
		papxlvl.AddPropFix(sprmPDxaLeftEx,  200);

		BYTE byData0[] = {0x00, 0x01, 0xa4, 0x10, 0x10};
		papxlvl.AddPropVar(sprmPChgTabs, byData0, sizeof(byData0));

		level0.SetPapx(&papxlvl);
		papxlvl.Clear();


//--------------------------------------------------------------------------
		KDWStyle style;
		docu.GetStyleSheet().NewStyle(
			stiUser, L"Style 1", mso_sgcParagraph, &style);
		{
			KDWPropBuffer chpx;
			KDWPropBuffer papx;

			papx.AddIstd(style.GetIndex());

			papx.AddPropFix(sprmPDxaLeft, 100);
			papx.AddPropFix(sprmPDxaLeftEx, 100);
			
			papx.AddPropFix(sprmPIlfo, lfo.GetIndex());
			papx.AddPropFix(sprmPIlvl, 0);

			BYTE byData0[] = {0x00, 0x01, 0xa4, 0x01, 0x06};
			papx.AddPropVar(sprmPChgTabs, byData0, sizeof(byData0));

			style.SetSprmList(mso_sgcParagraph, &papx);
			style.SetSprmList(mso_sgcCharacter, &chpx);
		}
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;

		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);

		papx.AddIstd(0);

		papx.AddPropFix(sprmPIlfo, lfo.GetIndex());
		papx.AddPropFix(sprmPIlvl, 0);

		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx1);
		docu.AddContent(__X("����1\x0d"), 4);
		
		docu.Close();
	}
	// -------------------------------------------------------------------------	
	// ���ԣ�
	//	LVLF��fWord6ΪTURE�������
	//  �ӽ�����Կ�������ʱ�Զ���ŵ�TAB�����κ��Ʊ�λ���ơ�
	void testListWord6()
	{

		struct _KDWListLevelSPY : KDWListLevel
		{
			using KDWListLevel::m_data;
		};

		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_list_word6.doc"), &spRootStg));
		
		KDWDocument docu;

		KDWListTable& lists = docu.GetListTable();
		KDWList list = lists.NewList(9);
		KDWListLevel level0 = list.GetLevel(0);
		KDWListFormatOverride lfo = lists.NewListFormatOverride(list);

		level0.SetXst(__X("%1"));
		level0.SetNfc(mso_nfcSbChar);
		
//--------------------------------------------------------------------------
		KDWPropBuffer papxlvl;

		BYTE byData0[] = {0x00, 0x01, 0, 10, 0x06};
		papxlvl.AddPropVar(sprmPChgTabs, byData0, sizeof(byData0));

//		papxlvl.AddPropFix(sprmPDxaLeft, 500);
//		papxlvl.AddPropFix(sprmPDxaLeftEx, 500);

		level0.SetIxchFollow((XCHFOLLOW)0);
		level0.SetPapx(&papxlvl);
		papxlvl.Clear();

		// ������fWord6ΪTRUE�Ժ��Զ���ŵ�β������ٶ��뵽�Ʊ�λ��
		((_KDWListLevelSPY*)&level0)->m_data->lvlf.fWord6 = TRUE;
		((_KDWListLevelSPY*)&level0)->m_data->lvlf.dxaSpace = 100;
		((_KDWListLevelSPY*)&level0)->m_data->lvlf.dxaIndent = 1000;

//--------------------------------------------------------------------------
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx1;

		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);

		papx.AddIstd(0);

		papx.AddPropFix(sprmPIlfo, lfo.GetIndex());
		papx.AddPropFix(sprmPIlvl, 0);

		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx1);
		docu.AddContent(__X("����1\x0d"), 4);
		
		docu.Close();
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestLists);

// -------------------------------------------------------------------------
