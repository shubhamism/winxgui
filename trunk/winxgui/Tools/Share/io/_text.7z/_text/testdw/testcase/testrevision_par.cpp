/* -------------------------------------------------------------------------
//	�ļ���		��	testrevision_par.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-12-6 10:41:38
//	��������	��	
//
//	$Id: testrevision_par.cpp,v 1.3 2004/12/08 02:11:24 xushiwei Exp $
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestRevision_Paragraph : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestRevision_Paragraph);
		CPPUNIT_TEST(testFormatChange);
		CPPUNIT_TEST(testAutoNumChange);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	void testFormatChange()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_revpar_fmtchg_.doc"), &spRootStg));
		
		KDWDocument doc;
		
		// �����û�:
		UINT usrid;
		doc.GetRevisionUsers().Add(
			__X("Unknown"),
			__X("Unknown"),
			&usrid);
		doc.GetRevisionUsers().Add(
			__X("xushiwei"),
			__X("xsw"),
			&usrid);
		
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		DTTM dttm;
		dttm.yr   = sysTime.wYear - 1900;
		dttm.mon  = sysTime.wMonth;
		dttm.dom  = sysTime.wDay;
		dttm.wdy  = sysTime.wDayOfWeek;
		dttm.hr   = sysTime.wHour;
		dttm.mint = sysTime.wMinute;
		
		SprmCPropRMarkExOprand oprand;
		oprand.dttmPropRMark = dttm;
		oprand.fPropRMark = 0x01;
		oprand.ibstPropRMark = usrid;
		papx.AddPropVar(sprmPPropRMarkEx, &oprand, sizeof(oprand));
		papx.AddPropFix(sprmPFPropRMarkEx, 0x01);
		
		papx.AddPropFix(sprmPDxaLeft1, 0x023a);
		papx.AddPropFix(sprmPDxaLeft1Ex, 0x023a);
		
		doc.NewDocument(spRootStg);
		doc.NewSection(&sepx);
		
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(__X("abc\x0d"), 4);
		
		papx.Clear();
		papx.AddIstd(0);
		doc.NewParagraph(&papx);
		doc.NewSpan(&chpx);
		doc.AddContent(0x0d);
		
		doc.Close();
	}

	void testAutoNumChange()
	{
	}
};

CPPUNIT_TEST_SUITE_REGISTRATION_DBG(TestRevision_Paragraph);

// -------------------------------------------------------------------------
//	$Log: testrevision_par.cpp,v $
//	Revision 1.3  2004/12/08 02:11:24  xushiwei
//	�û�KDWUsersʹ�õ�����
//	
//	Revision 1.2  2004/12/07 09:08:07  xushiwei
//	*** empty log message ***
//	
//	Revision 1.1  2004/12/06 08:57:50  xushiwei
//	*** empty log message ***
//	
//	
