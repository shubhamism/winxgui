/* -------------------------------------------------------------------------
//	�ļ���		��	testtexttable.cpp
//	������		��	��ʽΰ
//	����ʱ��	��	2004-9-3 10:32:46
//	��������	��	
//
// -----------------------------------------------------------------------*/

#include "stdafx.h"
#include "testcommon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// -------------------------------------------------------------------------

class TestTextTable : public TestCase
{
public:
	CPPUNIT_TEST_SUITE(TestTextTable);
		CPPUNIT_TEST(testDxa);
		CPPUNIT_TEST(testPercent);
		CPPUNIT_TEST(testMergeCell);
		CPPUNIT_TEST(testMergeCell2);
		CPPUNIT_TEST(testPosition);
		CPPUNIT_TEST(testCopyOfTablePr);
		CPPUNIT_TEST(testSameTableCheck1);
		CPPUNIT_TEST(testSameTableCheck2);
		CPPUNIT_TEST(testSameTableCheck3);
		CPPUNIT_TEST(testSubtable);
		CPPUNIT_TEST(testSubtableWithPosition);
		CPPUNIT_TEST(testTableInTextbox);
	CPPUNIT_TEST_SUITE_END();

public:
	void setUp() {}
	void tearDown() {}

public:
	//
	// �����İ汾tblPr����и��ƣ������Ƿ�ȷʵ��ˡ�
	// ��������˸��ƣ����һ��Ӧ��û�е��ơ�
	//
	void testCopyOfTablePr()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_copy_tblPr_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWTablePos tblPos;
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;			
			tblPos.pcVert = mso_pcVertPage;
			tblPos.pcHorz = mso_pcHorzPage;
			tblPos.tblpXSpec = mso_posXSpecCenter;
			tblPos.tblpYSpec = mso_posYSpecCenter;
			tblPr.typeCellWidth = mso_vetDxa;			
			cellPr.tcWidth = 1720;

			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable(&tblPos,5);//��ʼ��������
			{
				docu.rowtbl_NewRow(&tblPr);//�½�һ�С�

				// cell 11
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11: no shd\x0d"), 15);

				//�½�һ�С����tblPr�Ḵ��
				tblPr.shd.put_Pattern(mso_patAutomatic);
				tblPr.shd.put_BackColor(0xC0C0C0);
				docu.rowtbl_NewRow(&tblPr);

				// cell 21
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell21: shd\x0d"), 12);

				tblPr.typeCellWidth = mso_vetPercent;
				tblPr.tblWidth.put_Percent(80*50);
				docu.rowtbl_NewRow(&tblPr);

				// cell 31
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell31\x0d"), 7);
			}
			docu.rowtbl_EndTable();//������������
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}
	void testPosition()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_position_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);

//		docu.NewParagraph(&papx);	
//		docu.NewSpan(&chpx);
//		docu.AddContent(__X("a\x0d"), 2);
			
		{
			KDWTablePos tblPos;//���ñ����λ�����Եġ�
			KDWRowTablePr tblPr;//���ñ�����е����Եġ�
			KDWCellPr cellPr;//���ñ���ĵ�Ԫ������Եġ�
			tblPos.pcVert = mso_pcVertMargin;//��ֱλ��ֵ�����ҳ�߾�(Margin)
			tblPos.pcHorz = mso_pcHorzMargin;//ˮƽλ��ֵ�����ҳ�߾�(Margin)
			tblPos.tblpXSpec = mso_posXSpecCenter;//���ñ����ˮƽλ��Ϊ���С�
			tblPos.tblpYSpec = 0;//���ñ���Ĵ�ֱλ��Ϊ0��
			tblPr.typeCellWidth = mso_vetDxa;//���øñ������е�Ԫ��Ŀ��ȵĶ�����λ���μ�DWValueExtTypeö��ֵ��
			cellPr.tcWidth = 172*4;//��Ԫ��Ŀ��ȡ�
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable(NULL);//&tblPos);//��ʼ��������
			{
				docu.rowtbl_NewRow(&tblPr);//�½�������1��
				// cell 11
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 12
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				docu.rowtbl_NewRow(&tblPr);//�½�������2��
				// cell 21
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 22
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);
			}
			docu.rowtbl_EndTable();//������������

			docu.NewParagraph(&papx);	
			docu.NewSpan(&chpx);
			docu.AddContent(0x0d);
			//docu.AddContent(0x0d);

			//docu.NewParagraph(&papx);
			docu.rowtbl_StartTable(NULL);//&tblPos);//��ʼ��������
			{
				docu.rowtbl_NewRow(&tblPr);//�½�������1��
				// cell 11
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 12
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 13
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				docu.rowtbl_NewRow(&tblPr);//�½�������2��
				// cell 21
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 22
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 23
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);
			}
			docu.rowtbl_EndTable();//������������
		}				
		docu.Close();
	}

	void testSameTableCheck1()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_samecheck1_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWTablePos tblPos;
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			tblPos.pcVert = mso_pcVertPage;
			tblPos.pcHorz = mso_pcVertPage;
			tblPos.tblpXSpec = mso_posXSpecCenter;
			tblPos.tblpYSpec = mso_posYSpecCenter;
			tblPr.typeCellWidth = mso_vetDxa;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable(&tblPos,7);//��ʼ��������
			{
				docu.rowtbl_NewRow(&tblPr);//�½������С�

				// cell 11
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell_pg1\x0d"), 9);
			}
			docu.rowtbl_EndTable();

			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);//�½������С�

				// cell 11
				docu.rowtbl_NewCell(cellPr);//�½���Ԫ��
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell_pg2\x0d"), 9);
			}
			docu.rowtbl_EndTable();			

			tblPos.pcVert = mso_pcVertMargin;
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell_mar\x0d"), 9);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}
	
	void testSameTableCheck2()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_samecheck2_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWTablePos tblPos;
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			tblPos.pcHorz=mso_pcHorzPage;
			tblPos.pcVert=mso_pcVertPage;
			tblPos.tblpXSpec=mso_posXSpecCenter;
			tblPos.tblpYSpec=mso_posYSpecCenter;			
			tblPr.typeCellWidth = mso_vetDxa;
			cellPr.tcWidth = 1720;			
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("top_1\x0d"), 6);
			}
			docu.rowtbl_EndTable();			

			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("top_2\x0d"), 6);
			}
			docu.rowtbl_EndTable();
			
			tblPos.leftFromText=2000;
						
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("top_3\x0d"), 6);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}

	void testSameTableCheck3()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_samecheck3_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWTablePos tblPos;
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			tblPr.typeCellWidth = mso_vetDxa;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("noOverlap\x0d"), 10);
			}
			docu.rowtbl_EndTable();
			
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("noOverlap\x0d"), 10);
			}
			docu.rowtbl_EndTable();
			
			tblPos.tblOverlap = TRUE;//?
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("overlap\x0d"), 8);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}

	void testDxa()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_simple_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);

		{
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			//tblPr.typeCellWidth = mso_vetDxa;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 12
				cellPr.tcWidth=1720*2;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell12\x0d"), 7);
					
				// cell 13
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell13\x0d"), 7);
			}
			docu.rowtbl_EndTable();
			
			tblPr.tblInd = 1720*3;//���øñ���������ֵ��
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 21
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell21\x0d"), 7);				
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}

	void testPercent()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_percent_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			tblPr.typeCellWidth = mso_vetPercent;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);
				
				// cell 12
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell12\x0d"), 7);
				
				// cell 13
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell13\x0d"), 7);
			}
			docu.rowtbl_EndTable();
			
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 21
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell21\x0d"), 7);
				
				// cell 22
				cellPr.tcWidth = 1720/2;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell22\x0d"), 7);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}

	void testMergeCell()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_merge_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			tblPr.typeCellWidth = mso_vetDxa;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				cellPr.vertMerge = mso_tcVertFirstMerge;
				cellPr.horiMerge = mso_tcHoriNoneMerged;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);
				
				// cell 12
				cellPr.vertMerge = mso_tcVertNoneMerged;
				cellPr.horiMerge = mso_tcHoriNoneMerged;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell12\x0d"), 7);
				
				// cell 13				
				cellPr.vertMerge = mso_tcVertNoneMerged;
				cellPr.horiMerge = mso_tcHoriNoneMerged;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell13\x0d"), 7);
				cellPr.vertMerge = 0;
			}
			docu.rowtbl_EndTable();
			
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 21
				cellPr.vertMerge = mso_tcVertMerged;
				cellPr.horiMerge = mso_tcHoriNoneMerged;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell21\x0d"), 7);
				
				// cell 22				
				cellPr.vertMerge = mso_tcVertNoneMerged;
				cellPr.horiMerge = mso_tcHoriNoneMerged;
				cellPr.tcWidth = 1720 * 2;
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell22\x0d"), 7);
				//ˮƽ�ϲ����ޱ�־

//				// cell 23				
//				cellPr.vertMerge = mso_tcVertNoneMerged;
//				cellPr.horiMerge = mso_tcHoriMerged;
//				docu.rowtbl_NewCell(cellPr);
//				docu.NewParagraph(&papx);
//				docu.NewSpan(&chpx);
//				docu.AddContent(__X("cell23\x0d"), 7);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}
	void testMergeCell2()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(CreateDocfile(testPath("_table_Merge2_.doc"),&spRootStg));
		KDWDocument docu;
		KDWPropBuffer sepx, papx, chpx;
		papx.AddIstd(0);
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		//��������
		KDWTablePos tblPos;
		KDWRowTablePr tblPr;
		KDWCellPr cellPr;	

		tblPos.pcVert = mso_pcVertMargin;//��ֱλ��ֵ�����ҳ�߾�(Margin)
		tblPos.pcHorz = mso_pcHorzMargin;//ˮƽλ��ֵ�����ҳ�߾�(Margin)
		tblPos.tblpXSpec = mso_posXSpecCenter;//���ñ����ˮƽλ��Ϊ���С�
		tblPos.tblpYSpec = 0;//���ñ���Ĵ�ֱλ��Ϊ0��
		tblPr.typeCellWidth = mso_vetDxa;//���øñ������е�Ԫ��Ŀ��ȵĶ�����λ���μ�DWValueExtTypeö��ֵ��		
		cellPr.tcWidth = 172*4;//��Ԫ��Ŀ��ȡ�		
		
		docu.rowtbl_StartTable(&tblPos);
		{
			//row 1
			docu.rowtbl_NewRow(&tblPr);
			{
				//cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c11\x0d"),4);
				//cell 12				
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c12\x0d"),4);
				//cell 13
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c13\x0d"),4);
				//cell 14				
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c14\x0d"),4);
				//cell 15				
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c15\x0d"),4);
			}
			//end row 1			
			//row 2
			docu.rowtbl_NewRow(&tblPr);
			{
				//cell 21
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c21\x0d"),4);
				//cell 22
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c22\x0d"),4);
				//cell 23
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c23\x0d"),4);
				//cell 24
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c24\x0d"),4);
				//cell 25
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c25\x0d"),4);
			}
			//end row 2
			//row 3
			docu.rowtbl_NewRow(&tblPr);
			{
				//cell 31
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c31\x0d"),4);
				//cell 32
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c32\x0d"),4);
				//cell 33
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c33\x0d"),4);
				//cell 34
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c34\x0d"),4);
				//cell 35
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("c35\x0d"),4);
			}
			//end row 3
		}
		docu.rowtbl_EndTable();
		docu.Close();
	}

	void testSubtableWithPosition()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_subtable_pos_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWRowTablePr tblPr;
			KDWTablePos tblPos;
			KDWCellPr cellPr;
			tblPr.typeCellWidth = mso_vetPercent;
			tblPos.tblpYSpec = mso_posYSpecBottom;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable(&tblPos);
			{
				docu.rowtbl_NewRow(&tblPr);
				
				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);
				
				docu.rowtbl_NewRow(&tblPr);
				
				// cell 21
				docu.rowtbl_NewCell(cellPr);

				// cell 21's subtable
				KDWRowTablePr subtblPr;
				KDWTablePos subtblPos;
				subtblPr.typeCellWidth = mso_vetPercent;
				subtblPr.tblWidth.put_Percent(30*50);
				subtblPos.tblpY = -108*3;
				docu.rowtbl_StartTable(&subtblPos);
				{
					docu.rowtbl_NewRow(&subtblPr);
					docu.rowtbl_NewCell(cellPr);
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(__X("subtbl\x0d"), 7);
				}
				docu.rowtbl_EndTable();
				
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell12\x0d"), 7);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}

	void testSubtable()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_subtable_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		papx.AddIstd(0);
		
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("a\x0d"), 2);
		
		{
			KDWRowTablePr tblPr;
			KDWCellPr cellPr;
			tblPr.typeCellWidth = mso_vetPercent;
			cellPr.tcWidth = 1720;
			//
			// rowtbl_xxx �������ڵײ�API���ʴ����ݴ��ϲ���ʮ�����⡣
			// ע�⣺
			// һ��Ҫ��֤rowtbl_StartTable����Ĳ�����tblPos��rowtbl_EndTable
			// ǰ��Ч�����Ҳ����޸ģ�����
			//
			docu.rowtbl_StartTable();
			{
				docu.rowtbl_NewRow(&tblPr);

				// cell 11
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell11\x0d"), 7);

				// cell 11's subtable
				KDWRowTablePr subtblPr;
				subtblPr.typeCellWidth = mso_vetPercent;
				subtblPr.tblWidth.put_Percent(30*50);
				docu.rowtbl_StartTable();
				{
					docu.rowtbl_NewRow(&subtblPr);
					docu.rowtbl_NewCell(cellPr);
					docu.NewParagraph(&papx);
					docu.NewSpan(&chpx);
					docu.AddContent(__X("subtbl\x0d"), 7);
				}
				docu.rowtbl_EndTable();

				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(0x0d);
				
				// cell 12
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell12\x0d"), 7);
				
				// cell 13
				docu.rowtbl_NewCell(cellPr);
				docu.NewParagraph(&papx);
				docu.NewSpan(&chpx);
				docu.AddContent(__X("cell13\x0d"), 7);
			}
			docu.rowtbl_EndTable();
		}
		
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}
	void testTableInTextbox()
	{
		ks_stdptr<IStorage> spRootStg;
		VERIFY_OK(
			CreateDocfile(testPath("_table_intextbox_.doc"), &spRootStg));
		
		KDWDocument docu;
		KDWPropBuffer sepx;
		KDWPropBuffer papx;
		KDWPropBuffer chpx;
		KDWShape shape;
		KDWShapeOPT opt; // ��������
		KDWShapeOPT optUDef; // ����ê�㣨���š�����λ�õȣ�����

		papx.AddIstd(0);
		docu.NewDocument(spRootStg);
		docu.NewSection(&sepx);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);

		RECT rc = {2000, 2000, 2000 + 1720 * 2 + 100, 2000 + 200};
		KDWShapeAnchor anchor;
		FSPA_TEXTWRAP wrapMode =  mso_spaWrNone;
		FSPA_TEXTWRAPTYPE wrapType = mso_spaWrtBoth;
		memset(&anchor, 0 , sizeof(anchor));
		anchor.xaLeft = rc.left;//WpsShapeToTwip(rc.left);
		anchor.yaTop = rc.top;//WpsShapeToTwip(rc.top);
		anchor.xaRight = rc.right;//WpsShapeToTwip(rc.right);
		anchor.yaBottom = rc.bottom;//WpsShapeToTwip(rc.bottom);
		anchor.xRel = mso_spaXRelTopOfPage;
		anchor.yRel = mso_spaYRelTopOfPage;
		anchor.wrapMode = wrapMode;
		anchor.wrapType = wrapType;
		anchor.fAnchorLock = FALSE;

		opt.AddPropBool(msopt_fFitShapeToText, TRUE);
		optUDef.AddPropFix(msopt_spXRelTo, mso_spaXRelTopOfPage);
		optUDef.AddPropFix(msopt_spYRelTo, mso_spaYRelTopOfPage);
		shape = docu.AddShape(anchor, FALSE);
		//�������
		docu.EnterTextBox(shape);
		KDWRowTablePr tblPr;
		KDWCellPr cellPr;
		cellPr.tcWidth = 1720;
		docu.rowtbl_StartTable(NULL);//��ʼ��������
		docu.rowtbl_NewRow(&tblPr);//�½�һ�С�
		//cell 11
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		//cell 12
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		docu.rowtbl_EndTable();


		docu.rowtbl_StartTable(NULL);//��ʼ��������
		docu.rowtbl_NewRow(&tblPr);//�½�һ�С�
		//cell 21
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		//cell 22
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		docu.rowtbl_EndTable();


		docu.rowtbl_StartTable(NULL);//��ʼ��������
		docu.rowtbl_NewRow(&tblPr);//�½�һ�С�
		//cell 31
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		//cell 32
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		docu.rowtbl_EndTable();

		docu.rowtbl_StartTable(NULL);//��ʼ��������
		docu.rowtbl_NewRow(&tblPr);//�½�һ�С�
		//cell 41
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		//cell 42
		docu.rowtbl_NewCell(cellPr);
		docu.NewParagraph(&papx);
		docu.NewSpan(&chpx);
		docu.AddContent(0x0d);
		docu.rowtbl_EndTable();

		docu.LeaveTextBox();

		shape.SetShapeType(msosptTextBox);
		shape.SetProperties(opt);
		shape.SetUDefProperties(optUDef);
		
		docu.AddContent(__X("\x0d"), 1);
		docu.Close();
	}
	
};

CPPUNIT_TEST_SUITE_REGISTRATION(TestTextTable);

// -------------------------------------------------------------------------
